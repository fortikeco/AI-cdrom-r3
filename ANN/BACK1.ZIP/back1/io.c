/* ************************************************ */
/* file io.c:  contains most input/output functions */
/*                                                  */
/* Copyright (c) 1991 by Donald R. Tveter           */
/*                                                  */
/* ************************************************ */

#include <stdio.h>
#ifdef INTEGER
#include "ibp.h"
#else
#include "rbp.h"
#endif

#ifdef UNIX
#include <malloc.h>
#define WRITEBIN "w"
#define READBIN "r"
#else
#include <stdlib.h>
#define WRITEBIN "wb"
#define READBIN "rb"
#endif

extern char buffer[buffsize], copyflag, *datafilename, echo, outformat;
extern char outstr[OUTSTRSIZE], *wtfile, wtformat;
extern int bufferend, bufferptr, filestackptr, format[maxformat];
extern FILE *data, *filestack[];
extern LAYER *start;
extern int lastsave, pagesize, readerror, readingpattern, totaliter;
extern INT32 lineno;
extern short nlayers;
extern WTTYPE qmark, toler;
extern FILE *copy;

WTTYPE error;
int bad;

#ifdef INTEGER

short scale(x)     /* returns x as a scaled 16-bit value */
REAL x;
{
 short s;

if (x > 31.999 || x < -32.0)
 {
  sprintf(outstr,"magnitude of %f is too large for the integer",x);
  pg(outstr);
  pg(" representation\n");
  readerror = 1;
  if (x > 31.999) return(MAXSHORT); else return(MINSHORT);
 };
if (x > 0.0) s = x * 1024 + 0.5;
else s = x * 1024 - 0.5;
if (x != 0.0 && s == 0)
 {
  sprintf(outstr,"warning:  magnitude of %f is too small for",x);
  pg(outstr);
  pg(" the integer representation\n");
  return(0);
 };
return(s);
}

REAL unscale(x)  /* returns the REAL value of short x */
short x;
{ return((REAL) x / 1024.0); }

REAL unscaleint(x)  /* returns the REAL value of INT32 x */
INT32 x;
{ return((REAL) x / 1024.0); }

#endif

int pushfile(filename)
char *filename;
{
FILE *file;

bufferptr = 0;
bufferend = 0;
buffer[0] = '\n';
file = fopen(filename,"r");
if (file == NULL)
 {
  sprintf(outstr,"cannot open:, %s\n",filename); pg(outstr);
  return(0);
 };
filestackptr = filestackptr + 1;
if (filestackptr > 3)
 {
  pg("can't stack up any more files\n");
  filestackptr = filestackptr - 1;
  return(0);
 };
filestack[filestackptr] = file;
data = file;
return(1);
} 

void popfile()
{
bufferptr = 0;
bufferend = 0;
buffer[0] = '\n';
if (filestackptr > 0)
 {
  fclose(data);
  filestackptr = filestackptr - 1;
 }
else pg("\nunexpected EOF:  to quit the program, type q\n");
data = filestack[filestackptr];
}

int readch() /* returns the next character in the input buffer */
{ 
 int i, ch2;

if (bufferptr > bufferend) /* then read next line into buffer */
 {
  ch2 = getc(data);
  if (ch2 == EOF) return(ch2);
  i = 0;
  while(ch2 != '\n' && i < buffsize)
   {
    if (ch2 == 13) ch2 = ' '; /* turn a ctrl-M into a blank */
    buffer[i] = ch2;
    i = i + 1;
    ch2 = getc(data);
   };
  if (i == buffsize) pg("line too long\n");
  buffer[i] = '\n';
  bufferend = i;
  bufferptr = 0;
  if (echo == '+') for(i = 0; i <= bufferend; i++) putchar(buffer[i]);
  if (copy && ((data == stdin) || (echo == '+')))
   for (i=0;i<=bufferend;i++) putc(buffer[i],copy);
 }
ch2 = buffer[bufferptr];
bufferptr = bufferptr + 1;
return(ch2);
}

void texterror()
{
int ch2;
pg("unexpected text:  ");
bufferptr = bufferptr - 1;
do {ch2 = readch(); putchar(ch2);} while (ch2 != '\n');
putchar('\n');
bufferptr = bufferptr - 1;
}

char *readstr()
{
short i,start,end;
char *addr, *addr2;
i = bufferptr;
while (buffer[i] == ' ') i = i + 1;
start = i;
while (buffer[i] != ' ' && buffer[i] != '\n') i = i + 1;
end = i-1;
addr = (char *) malloc((int) end-start+2);
addr2 = addr;
for (i=start;i<=end;i++) *addr++ = buffer[i];
bufferptr = end + 1;
*addr = '\0';
return(addr2);
}

int scanfordigit()
{
int sign, ch2;

sign = 1;

restart:
do ch2 = readch(); while (ch2 == ' ' || ch2 == '\n');
if (ch2 >= '0' && ch2 <= '9')
 {
  bufferptr = bufferptr - 1;
  return(sign);
 };
if (ch2 >= 'h' && ch2 <= 'k')
 {
  bufferptr = bufferptr - 1;
  return(0);
 };
          switch (ch2) {
case EOF: readerror = 2;
          return(0);
case '*': while (ch2 != '\n') ch2 = readch();
          goto restart;
case '-': sign = -sign;
          goto restart;
case '?': bufferptr = bufferptr - 1;
          return(0);
default:  readerror = 1;
          return(0);
          };
}

int readint(min,max,command)
int min, max;
char command;
{
int sign, number, ch2;

readerror = 0;
sign = scanfordigit();
if (readerror)
 {
  if (readerror == 1) texterror();
  return(0);
 };
number = 0;
do ch2 = readch(); while (ch2 == ' ');
while (ch2 >= '0' && ch2 <= '9')
 {
  number = number * 10 + (ch2 - '0');
  ch2 = readch();
 };
bufferptr = bufferptr - 1;
number = sign * number;
if (number < min || number > max)
 {
  sprintf(outstr,"out of range value: %d",number); pg(outstr);
  if (data == stdin) pg("\n");
  else {sprintf(outstr," in %c command\n",command); pg(outstr);};
  readerror = 1;
 };
return(number);
}

REAL readreal(op,min,command)
int op;
REAL min;
int command;
{
REAL number, fractpart, divisor, intpart, sign;
int ch2;

readerror = 0;
sign = (REAL) scanfordigit();
if (readerror || (sign == 0 && !readingpattern))
 {
  if (readerror == 1) texterror();
  return(0);
 };
ch2 = readch();
if (ch2 == 'h' && readingpattern) return(unscale(HCODE));
else if (ch2 == 'i' && readingpattern && nlayers >= 3)
  return(unscale(ICODE));
else if (ch2 == 'j' && readingpattern && nlayers >= 4)
  return(unscale(JCODE));
else if (ch2 == 'k' && readingpattern && nlayers >= 5)
  return(unscale(KCODE));
else if (ch2 == '?' && readingpattern)
  return(unscale(qmark));
intpart = 0.0;
while (ch2 >= '0' && ch2 <= '9')
 {
  intpart = 10.0 * intpart + (ch2 - '0');
  ch2 = readch();
 };
fractpart = 0.0;
divisor = 1.0;
if (ch2 == '.')
 {
  ch2 = readch();
  while (ch2 >= '0' && ch2 <= '9')
   {
    fractpart = fractpart * 10.0 + (ch2 - '0');
    divisor = divisor * 10.0;
    ch2 = readch();
   };
 };
bufferptr = bufferptr - 1;
number = sign * (((REAL) intpart) +
                ((REAL) fractpart) / ((REAL) divisor));
if (op == GT && number > min) return(number);
else if (op == GE && number >= min) return(number);
else
 {
  sprintf(outstr,"erroneous value: %f",number); pg(outstr);
  if (data == stdin) pg("\n");
  else {sprintf(outstr," in %c command\n",command); pg(outstr);};
  readerror = 1;
  return(0.0);
 };
}

WTTYPE rdr(op,min,command) /* reads REAL real numbers and converts */
int op;                    /* them to 16-bit integers if necessary */
REAL min;
int command;
{
REAL x;
WTTYPE ix;
 
x = readreal(op,min,command);
if (readerror) return(0);
ix = scale(x);
if (readerror) return(0);
return(ix);
}

REAL readchar()   /* reads data in compressed format */
{
int ch2;
readerror = 0;
ch2 = readch();
do {
          switch (ch2) {
case '\n':
case ' ': ch2 = readch();
          break;
case '1': return(1.0);
case '0': return(0.0);
case '?': return(unscale(qmark));
case '*': do ch2 = readch(); while(ch2 != '\n');
          break;
case 'h': return(unscale(HCODE));
case 'i': if (nlayers >= 3) return(unscale(ICODE));
case 'j': if (nlayers >= 4) return(unscale(JCODE));
case 'k': if (nlayers >= 5) return(unscale(KCODE));
case EOF: readerror = 2;
          return(0.0);
default:  texterror();
          readerror = 1;
          return(0.0);};
} while (0 == 0);
}

int pg(str) /* paging and making a copy function */
char *str;
{
char *ch3,action,cr;
int copying;

copying = copyflag == '+';
ch3 = str;
while (*ch3 != '\0')
   {
     if (*ch3 == '\n')
        {
          putchar('\n');
          if (copying) putc('\n',copy);
#ifndef UNIX
          putchar('\r');
          if (copying) putc('\r',copy);
          if (*ch3++ != '\r') ch3--;
#endif
          lineno = lineno + 1;
          if (pagesize && lineno % pagesize == 0)
             {
               putchar(':');
               action = getchar();
               if (action == 'q')
                  {
                    cr = getchar();
                    return(action);
                  };
             }
        }
     else {putchar(*ch3); if (copying) putc(*ch3,copy); };
     ch3++;
   };
return(0);
}

int printoutunits(printing,layer,printerr)  /* prints values of units */
int printing;                               /* and computes errors */
LAYER *layer;
int printerr;
{
short unitno, fmtbreaknum, maxval, maxunit;
UNIT *u;
WTTYPE upper, middle, diff;

if (printing)
 {
  upper = scale(1.0) - toler;
  middle = scale(0.5);
  unitno = 0;
  fmtbreaknum = 1;
 };
bad = 0;
maxval = -scale(2.0);
maxunit = 0;
error = 0;
u = (UNIT *) layer->units;
while (u != NULL)
 {
  diff = u->tj - u->oj;
  if (diff < 0) diff = -diff;
  if (diff >= toler) bad = 1;
  error = error +  diff;
  if (printing)
   {
    unitno = unitno + 1;
    if (outformat == 'r')
     {
      sprintf(outstr,"%5.2f ",unscale(u->oj)); pg(outstr);
      if (format[fmtbreaknum] == unitno)
       {
        if (pg("\n    ")) return(1);
        if (fmtbreaknum < maxformat - 1) fmtbreaknum = fmtbreaknum + 1;
       }
     }
    else if (outformat == 'a' && printerr)
     {
      if (diff < toler) pg("c");
      else if (u->oj > upper) pg("1");
      else if (u->oj < toler) pg("0");
      else if (u->oj > u->tj) pg("^");
      else pg("v");
      if (format[fmtbreaknum] == unitno)
       {
        pg(" ");
        if (fmtbreaknum < maxformat - 1) fmtbreaknum = fmtbreaknum + 1;
       }
     }
    else 
     {
      if (u->oj > upper) pg("1");
      else if (u->oj > middle) pg("^");
      else if (u->oj < toler) pg("0");
      else pg("v");
      if (format[fmtbreaknum] == unitno)
       {
        pg(" ");
        if (fmtbreaknum < maxformat - 1) fmtbreaknum = fmtbreaknum + 1;
       }
     }
   };
  u = u->next;
 };
if (!printing) return(0);
if (printerr) {sprintf(outstr," (%5.3f)",unscale(error)); pg(outstr);};
if (printerr && !bad) pg(" ok");
if (pg("\n")) return(1); else return(0);
}

void saveweights()    /* saves weights on the file weights */
{
UNIT *u;
LAYER *layer;
WTNODE *w;
WTTYPE wvalue, evalue, dvalue, svalue;
int wtsize;
FILE *weights;

wtsize = WTSIZE;
weights = fopen(wtfile,WRITEBIN);
if (weights == NULL)
 {
  sprintf(outstr,"cannot open: %s\n",wtfile); pg(outstr);
  return;
 };
fprintf(weights,"%d%c",totaliter,wtformat);
if (wtformat == 'b' || wtformat == 'B') fprintf(weights,"%1d",WTSIZE);
fprintf(weights,"   file = %s\r\n",datafilename);
layer = start->next;
while (layer != NULL)
 {
  u = (UNIT *) layer->units;
  while (u != NULL)
   {
    w = (WTNODE *) u->wtlist;
    while (w != NULL)
     {
#ifdef SYMMETRIC
      wvalue = *(w->weight);
      evalue = *(w->eta);
      dvalue = *(w->olddw);
      svalue = 0; /* not worth having in the symmetric version */
#else
      wvalue = w->weight;
      evalue = w->eta;
      dvalue = w->olddw;
      svalue = w->slope;
#endif
      if (wtformat == 'r' || wtformat == 'R')
       {
        fprintf(weights,"%16.10f",unscale(wvalue));
        if (wtformat == 'R')
         {
          fprintf(weights," %16.10f",unscale(evalue));
          fprintf(weights," %16.10f",unscale(dvalue));
#ifdef NEXTVERSION
          fprintf(weights," %16.10f",unscale(svalue));
#endif
         };
        fprintf(weights,"\r\n");
       }
      else  /* binary format; uses the least space */
       {
        fwrite((char *) &wvalue,wtsize,1,weights);
        if (wtformat == 'B')
         {
          fwrite((char *) &evalue,wtsize,1,weights);
          fwrite((char *) &dvalue,wtsize,1,weights);
#ifdef NEXTVERSION
          fwrite((char *) &svalue,wtsize,1,weights);
#endif
         };
       };
      w = w->next;
     };
    u = u->next;
   };
  layer = layer->next;
 };
fflush(weights);
fclose(weights);
lastsave = totaliter;
}

WTTYPE rdb(wtfile,wtsize) /* read binary and convert between sizes */
FILE *wtfile;
int wtsize;
{
int i, ch2;
double dvalue;
float fvalue;
short ivalue;
unsigned char *charptr;

if (wtsize == 2) charptr = (unsigned char *) &ivalue;
else if (wtsize == 4) charptr = (unsigned char *) &fvalue;
else if (wtsize == 8) charptr = (unsigned char *) &dvalue;
else pg("bad weight size\n");
for (i=1;i<=wtsize;i++)
 {
  ch2 = fgetc(wtfile);
  *charptr = (unsigned char) ch2;
  charptr++;
 };
if (WTSIZE == 2 && wtsize == 2) return(ivalue);
else if (WTSIZE == 2 && wtsize == 4) return(scale(fvalue));
else if (WTSIZE == 2 && wtsize == 8) return(scale(dvalue));
else if (WTSIZE == 4 && wtsize == 2) return(ivalue / 1024.0);
else if (WTSIZE == 4 && wtsize == 4) return(fvalue);
else if (WTSIZE == 4 && wtsize == 8) return((float) dvalue);
else if (WTSIZE == 8 && wtsize == 2) return(ivalue / 1024.0);
else if (WTSIZE == 8 && wtsize == 4) return((double) fvalue);
else if (WTSIZE == 8 && wtsize == 8) return(dvalue);
}

void restoreweights()    /* restore weights from the file weights */
{
FILE *weights;
UNIT *u;
LAYER *layer;
WTNODE *w;
int ch2, fileformat, wtsize;
WTTYPE wvalue, evalue, dvalue, svalue;
double temp;

weights = fopen(wtfile,READBIN);
if (weights == NULL)
 {
  pg("cannot open file weights\n");
  return;
 };
fscanf(weights,"%d",&totaliter);
fileformat = getc(weights);
if (fileformat != wtformat) pg("note: weight format mismatch\n");
if (fileformat == 'b' || fileformat == 'B')
 {
  wtsize = getc(weights) - '0';
  if (WTSIZE != wtsize) pg("note: weight sizes mismatched\n");
 }
else wtsize = WTSIZE;
do ch2 = getc(weights); while (ch2 != '\n'); /* skip rest of line */
layer = start->next;
while (layer != NULL)
 {
  u = (UNIT *) layer->units;
  while (u != NULL)
   {
    w = (WTNODE *) u->wtlist;
    while (w != NULL)
     {
      if (fileformat == 'r' || fileformat == 'R')
       {
        fscanf(weights,"%lf",&temp);
        wvalue = scale((REAL) temp);
        if (fileformat == 'R')
         {
          fscanf(weights,"%lf",&temp);
          evalue = scale((REAL) temp);
          fscanf(weights,"%lf",&temp);
          dvalue = scale((REAL) temp);
#ifdef NEXTVERSION
          fscanf(weights,"%lf",&temp);
          svalue = scale((REAL) temp);
#endif
         };
       }
      else
       {
        wvalue = rdb(weights,wtsize);
        if (fileformat == 'B')
         {
          evalue = rdb(weights,wtsize);
          dvalue = rdb(weights,wtsize);
#ifdef NEXTVERSION
          svalue = rdb(weights,wtsize);
#endif
         };
       };
#ifdef SYMMETRIC
      *(w->weight) = wvalue;
      if (fileformat == 'R' || fileformat == 'B')
       {
        *(w->olddw) = dvalue;
        *(w->eta) = evalue;
       }
      else *(w->olddw) = 0;
#else
      w->weight = wvalue;
      if (fileformat == 'R' || fileformat == 'B')
       {
        w->olddw = dvalue;
        w->eta = evalue;
        w->slope = svalue;
       }
      else w->olddw = 0;
#endif
      w = w->next;
     };
    u = u->next;
   };
  layer = layer->next;
 };
fclose(weights);
}

void printweights(u)   /* print the weights leading into unit u */
UNIT *u;

{
WTNODE *w;
UNIT *bunit;
WTTYPE value;
#ifdef INTEGER
INT32 sum, input;
#else
REAL sum, input;
#endif

w = (WTNODE *) u->wtlist;
sum = 0;
pg("layer unit  unit value     weight         input from unit\n");
while (w != NULL)
 {
  bunit = (UNIT *) w->backunit;
#ifdef SYMMETRIC
  value = *(w->weight);
#else
  value = w->weight;
#endif

#ifdef INTEGER
  input = (INT32) value * bunit->oj;
  input = input / 1024;
#else
  input = value * bunit->oj;
#endif
  sum = sum + input;
  sprintf(outstr,"%3d   ",bunit->layernumber); pg(outstr);
  if (bunit->unitnumber == 32767) pg("   t ");
  else {sprintf(outstr,"%4d ",bunit->unitnumber); pg(outstr);};
  sprintf(outstr,"%10.5f  %10.5f  ",unscale(bunit->oj),unscale(value));
  pg(outstr);
  sprintf(outstr,"%18.5f\n",unscaleint(input));
  if (pg(outstr)) return;
  w = w->next;
 };
pg("                                      ");
sprintf(outstr,"sum = %9.5f\n\n",unscaleint(sum)); pg(outstr);
}

void help()
{
int ch2;
pg("\n");
do ch2 = readch(); while (ch2 == ' ' && ch2 != '\n');
        switch(ch2) {

default:
pg("for help type h followed by the letter of the command\n");
if (ch2 == '\n') bufferptr = bufferptr - 1;
break;

case '?':
pg("? prints program status and parameters.\n");
break;

case '*':
pg("* at the beginning of a line makes the line a comment.\n");
break;

case '!':
pg("Enter system commands after the !.\n");
break;

case 'A':
pg("A is used to set details of the algorithm.  One or more of \n");
pg("the following commands can go on the same line as the 'A':\n\n");
pg("a l sets the linear activation function.\n");
pg("a p sets the piecewise linear activation function.\n");
pg("a t sets the piecewise near tanh activation function.\n");
#ifndef INTEGER
pg("a s sets the smooth activation function.\n");
pg("a T sets the smooth near tanh activation function.\n");
#endif
pg("\n");
pg("b + will backpropagate errors even when a unit is close to ");
pg("its target.\n");
pg("b - will not backpropagate errors when a unit is close to its");
pg(" target.\n\n");
pg("D <real> will set the sharpness of the sigmoid to <real>.\n\n");
pg("d d will use the derivatives from the differential step size");
pg(" algorithm.\n");
pg("d F uses Fahlman's derivative in the output layer.\n");
pg("d f uses Fahlman's derivative in all layers.\n");
pg("d o uses the original derivative.\n\n");
pg("g <int> updates weights after every group of <int> patterns if <int> != 0.\n\n");
pg("s <int> will skip for <int> iterations patterns that have been ");
pg("learned.\n\n");
pg("t <int> will take pattern <int> out of the training process.\n");
pg("   To bring it back in, use t 0.\n\n");
pg("u c gives the continuous update method.\n");
#ifndef SYMMETRIC
pg("u d gives the delta-bar-delta update method.\n");
#endif
pg("u p gives the periodic update method.\n");
break;

case 'a':
pg("a <real> sets the momentum parameter, alpha, to <real>.\n");
break;

case 'B':
pg("B <options> sets the following benchmarking options:\n\n");
pg("g <int> sets <int> to be the goal for the number of");
pg(" networks to converge.\n\n");
pg("k <real> sets the range of the initial random");
pg(" weights for each network.\n\n");
pg("m <int> sets the maximum number of networks to try.\n\n");
pg("r <int1> <int2> sets <int1> to be the maximum ");
pg("number of iterations to run.\n  <int2>, if present,");
pg(" sets the rate at which to sample the network.\n  ");
pg("Using r in a B command will initiate benchmarking.\n\n");
pg("t <int> will benchmark with pattern <int> removed");
pg(" from the training set\n  and test it at the");
pg(" sample rate given in the r command.\n");
pg("t f <testfile> will test patterns on <testfile> at ");
pg("the interval given for\n   the sample rate.\n");
pg("t 0 turns off either type of testing.\n");
break;

case 'b':
pg("b <int1> <int2> ... <int20> puts a carriage break");
pg(" after each <inti>\nvalues when the output format");
pg(" is real and inserts a blank after each <inti>\n");
pg("value if the format is condensed.\n");
break;

case 'C':
pg("C clears the network and other relevant parameters");
pg(" so the problem can be re-run\nwith different");
pg(" initial weights.  Added hidden units are not removed.\n");
break;

#ifndef SYMMETRIC
case 'c':
pg("c <int1> <int2> <int3> <int4>  ");
pg("Adds a connection from layer <int1> unit <int2>\n");
pg("   to layer <int3> unit <int4>.\n");
break;
#endif

case 'd':
pg("d is used to set parameters for the delta-bar-delta method.\n");
pg("One or more of the following commands can go on the line:\n\n");
pg("d <real> sets the decay factor to <real>.\n");
pg("e <real> sets the initial eta value to <real>.\n");
pg("k <real> sets kappa to <real>.\n");
pg("m <real> limits the maximum value of each eta to <real>.\n");
#ifdef INTEGER
pg("n <real> sets some noise (integer versions only).");
pg("   Try <real> around 0.005.\n");
#endif
pg("t <real> sets the theta parameter to <real>.\n");
break;

case 'e':
pg("e <real1> <real2> sets eta, the learning rate for the top layer");
pg(" to <real1>\n   and eta2 for the lower layers to <real2>.  If ");
pg("<real2> is not present,\n   eta2 is set to <real1>.\n");
break;

case 'f':
pg("f is used to set the input and output formats for data.\nOne ");
pg("or more of the following commands can go on the line:\n\n");
pg("b + will ring the bell when learning is complete.\n");
pg("b - will not ring the bell when learning is complete.\n\n");
pg("c + will copy i/o to the file, copy.\n");
pg("c - will stop writing to the file, copy.\n\n");
pg("e + echos the input.\ne - does not echo.\n\n");
pg("i c will read pattern values using compressed format.\n");
pg("i r will read pattern values as reals.\n\n");
pg("o a will write node values as analog compressed.\n");
pg("o c will write node values as compressed.\n");
pg("o r will write node values as real.\n\n");
pg("P <int> sets the page size to <int>; 0 means no paging.\n\n");
pg("p c will read patterns in the classification format and ");
pg("summarize the results\n    when testing.\n");
pg("p C will read patterns in the classification format and ");
pg("print every result\n    when testing.\n");
pg("p g will accept general patterns and summarize results when ");
pg("testing.\n");
pg("p G will accept general patterns and print every result when ");
pg("testing.\n\n");
pg("s + will summarize learning status.\n");
pg("s - will not summarize learning status and will");
pg(" list each pattern.\n\n");
pg("u + will give up-to-date statistics on learning.\n");
pg("u - will give statistics one iteration out of date.\n\n");
pg("w b will write the weights as binary.\n");
pg("w B will write the weights, weight changes and etas as binary.\n");
pg("w r will write the weights as real values.\n");
pg("w R will write the weights, weight changes and etas as real");
pg(" values.\n");
break;

#ifndef SYMMETRIC
case 'H':
pg("H <int> <real> adds a hidden unit to layer <int>\n");
pg("Weights are initialized to between -<real> and +<real>.\n");
break;
#endif

case 'h':
pg("h <letter> gives help for command <letter>.\n");
break;

case 'i':
pg("i <inputfile> takes commands from the file.\n");
pg("i takes commands from the current input file.\n");
break;

case 'k':
pg("k <real1> <real2> decreases all the weights in the ");
pg("network whose values\nare greater than <real1> by a");
pg(" random amount between 0 and <real2>.\nWeights ");
pg("less than -<real1> are increased by an amount ");
pg("between 0 and <real2>.\nIf <real1> = 0.0, and a ");
pg("weight = 0.0 then the weight is changed to\na ");
pg("random value between -<real2> and +<real2>.\n");
break;

case 'l':
pg("l <int> prints values of nodes on layer <int>.\n");
break;

case 'm':
pg("m <int1> <int2> ... <intn> makes a network with\n");
pg("<int1> units in the first layer, <int2> units in\n");
pg("the second layer, ... , <intn> units in the nth layer.\n");
break;

case 'n':
pg("n <int> <in1> <out1> ... <ini> <outi> ... <inN> <outN>");
pg(" replaces all\n   training patterns with <int> new ones.\n");
pg("n f <trainfile> reads however many patterns there are on");
pg(" the file.\n");
break;

case 'O':
pg("O <int> will give the output targets for pattern, <int>.\n");
break;

case 'o':
pg("o a outputs node values in analog compressed form.");
pg("\no c outputs node values in compressed form.\n");
pg("o r outputs node values as real.\n");
break;

case 'P':
pg("P lists the outputs for all patterns.\n");
pg("P <int> gives the output for pattern <int>.\n");
pg("P0 gives an up-to-date summary of learning.\n");
break;

case 'p':
pg("p <pat> submits the pattern, <pat>, to the input units.\n");
break;

case 'Q':
pg("Q <real> sets the value of ? in input patterns to <real>.\n");
break;

case 'q':
pg("q ends the program.\n");
break;

case 'R':
pg("R restores weights from the current weights file\n");
break;

case 'r':
pg("r <int1> <int2> runs <int1> iterations thru the ");
pg("patterns.  If <int2> is\npresent, the patterns are ");
pg("printed (or summarized) every <int2> iterations.\n\n");
pg("rw <filename> reads weights from the file, <filename> and sets ");
pg("<filename>\n             to be the current weights file.\n");
pg("rw reads weights from the current weights file.\n");
break;

case 'S':
pg("S <int> saves the weights on the current weights file every <int>");
pg(" iterations.\nS or S 0 saves the weights immediately.\n");
break;

case 's':
pg("s <int1> <int2> ... <intn> sets the random number seeds.\n\n");
pg("sw <filename> saves weights to the file, <filename> and sets ");
pg("<filename>\n              to be the current weights file.\n");
pg("sw saves weights to the current weights file.\n");
break;

#ifdef SYMMETRIC
case 'T':
pg("T <real> freezes all threshold weights at <real>.\n");
break;
#endif

case 't':
pg("t <real> sets <real> as the tolerance used in checking for");
pg(" complete learning.\n");
pg("t f <testfile> tests the patterns on the file.\n");
pg("t f tests the patterns on the current test file.\n");
pg("t tests the patterns on the current test file.\n");
break;

#ifndef SYMMETRIC
case 'W':
pg("W <real> removes links whose weights are less than ");
pg("the absolute value\nof <real>, except links to ");
pg("threshold units are not removed.\n");
break;
#endif

case 'w':
pg("w <int1> <int2>  ");
pg("prints weights into unit <int2> in layer <int1>.\n");
break;

case 'x':
pg("x <int1> <in1> <out1> ... <ini> <outi> ... <inN> <outN>  adds");
pg(" the extra\n   <int1> patterns.\n");
pg("x f <trainfile> adds the extra patterns found on the file.\n");
break;
     }; /* end switch */
pg("\n");
}
