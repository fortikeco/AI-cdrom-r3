Contained herein are a few demo programs to illustrate backpropagation
neural nets.  These programs demonstrate two features that one rarely
finds in bp. neural nets: (1) Newton's Method is used to update weights
and threshold biases, (2) Recurrence is allowed, with "persistent activations".
By "persistent activations" is meant that the activation level of cells in
the neural net is preserved between steps.

Notes on the workings recurrent backpropagation neural nets, and on using
Newton's Method are contained in backprop.doc.

The programs are all written in MicroSoft Quick Basic, version 4.5 to be
run on IBM compatibles but can probably be compiled under compilers accepting
earlier versions of Quick Basic.  They are also written in such a way that they
can be fairly easily translated to Quick C, or Berkeley C (using the curses
package).

They are ...

backprop.bas: A demo Newton's Method recurrent backprop neural net applied to
	      learning the exclusive or function (XOR).  This can be easily
	      modified for other functions (such as a binary adder).

flipflop.bas: A demo illustrating recurrence with "persistent activations".
	      This is a static neural net, no learning takes place.  It
	      simulates the behavior of a flip-flop.

ff.bas:  A demo with the same features as above, which attempts to *learn*
	 a flip-flop, not just simulate one.  No convergence has been observed
	 to date with this particular set-up, though the previous program,
	 flipflop.bas, does illustrate that convergence is theoretically
	 possible.

This software is free for you to use any way you like, but the author bears no
liability for the effects of either it or any of its derivatives.  So if you
accidentally end up producing a neural net from this that ultimately takes over
the planet and enslaves the human population thereby thrusting us into a
thousand years of darkness, don't come crying to me. >:)

Any comments on the programs are welcome.  Just send a response to me at my
e-mail address given below.

------------------------------------------------------------
Mark Hopkins (markh@csd4.csd.uwm.edu)
November 12, 1990
Milwaukee, Wisconsin
