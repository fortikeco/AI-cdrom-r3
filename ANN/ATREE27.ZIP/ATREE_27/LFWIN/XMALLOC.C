#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloc.h>

char far *
xmalloc(n)
unsigned int n;
{
char far *p;

   if ((p = farmalloc(n)) == NULL) {
   /*
      fprintf(stderr, "malloc failed\n");
   */
      exit(0);
   }
   return(p);
}
