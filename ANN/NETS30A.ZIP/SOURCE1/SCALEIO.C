/*=============================*/
/*           NETS              */
/*                             */
/*     a product of the 	   */
/*	Software Technology Branch */
/*  NASA, Johnson Space Center */
/*                             */
/* authors:           		   */
/*       Paul Baffes           */
/*       Steve Bayer           */
/*       Bryan Dulock          */
/*       Linda Jensen          */
/*       Chris Ortiz           */
/*       Gary Riley            */
/*       Robert Shelton        */
/*       Todd Phillips         */
/*=============================*/


/*
----------------------------------------------------------------------
  Code For Scaling IO pairs  (Prefix = SC_) 
----------------------------------------------------------------------
  This code is divided into 3 major sections:

  (1) include files
  (2) global variables
  (3) subroutines
 
----------------------------------------------------------------------
*/


/*
----------------------------------------------------------------------
  INCLUDE FILES
----------------------------------------------------------------------
*/
#include <ctype.h>

#include "common.h"
#include "netio.h"
#include "weights.h"
#include "layer.h"
#include "net.h"


/*
----------------------------------------------------------------------
  GLOBAL VARIABLES
----------------------------------------------------------------------
*/
extern char           IO_str[MAX_LINE_SIZE];
extern char           IO_wkstr[MAX_LINE_SIZE];
extern char           local_wkstr[MAX_LINE_SIZE];
extern char           net_config[MAX_WORD_SIZE];
extern char           net_iop[MAX_WORD_SIZE];
extern char           net_fwt[MAX_WORD_SIZE];
extern char           net_pwt[MAX_WORD_SIZE];
#if MAC_GRAPH
extern int homeVolume;
#endif

static struct bad_list
	{
		float def;
		int index;
		struct bad_list *next;
	} /* end struct */
*new_bad_elt, *bad_input_list, *bad_output_list, *temp_elt;

static int io_size;
static float *scale_max, *scale_min, mxi, mxo, mni, mno;

/*
======================================================================
  ROUTINES IN SCALEIO.C                                                   
======================================================================
  The routines in this file are grouped below by function.  Each routine
  is prefixed by the string "SC_" indicating that it is defined in the 
  "scaleio.c" file.  The types returned by the routines are also shown 
  here so that cross checking is more easily done between these functions
  and the other files which intern them.


  Type Returned                 Routine                                 
  -------------                 -------                                 
    void                        SC_scale_IOpairs
    int 						SC_scale_any_file
======================================================================
*/

/*
 *  SC_scaleIOP(Net)
 *
 *  Scales the I/O pairs in the workfile.net
 *
 */

void SC_scale_IOpairs (np)
Net *np;
{
	char test_char;
	int i, n;
	float t, *temp, C_Sint_to_float();
	FILE *f, *fu;
	char *sys_alloc();
	Sint *Sint_array, C_float_to_Sint();
	
#if MAC_GRAPH
	SFReply	the_reply;
	int   D_Scale_Options(),
		  D_Scale_Anyway();
	float   D_GetDefault();

	InitCursor();
#endif

	bad_input_list=NULL;
	bad_output_list=NULL;
	if (np->num_io_pairs > 0)
	{
		if (np->scale_file_ptr == NULL)
		{
#if !MAC_GRAPH
			sprintf (IO_str, "Scale file name <fname>.scl ");
			IO_print (0);
			strcat (gets(local_wkstr),".scl");
			while ((np->scale_file_ptr=fopen(local_wkstr,READ_TEXT))==NULL)
			{
				sprintf(IO_str,
				" File %s not found\n Re-enter file name or carriage return to create> ",
				local_wkstr);
				IO_print(0);
				if (!strlen(gets(IO_str)))
					break;
				strcat(strcpy(local_wkstr,IO_str),".scl");
			} /* end while */
			if (np->scale_file_ptr==NULL)
			{
				while((np->scale_file_ptr=fopen(local_wkstr,WRITE_TEXT))==NULL)
				{
					sprintf(IO_str, " File %s didn't open for output\n", local_wkstr);
					IO_print (0);
					sprintf (IO_str, " Re-enter file name or carriage return to exit program> ");
					IO_print (0);
					if(!strlen(gets(IO_str)))
						exit(0);
					strcat(strcpy(local_wkstr,IO_str),".scl");
				} /* end while */
				np->scale_file_flag = _IOWRT;
			} /* end inner if */
			else
				np->scale_file_flag = _IOREAD;
#endif
#if MAC_GRAPH
			
			getFName(local_wkstr,&the_reply,TEXT_FILE,LOAD_IT_WITH_NEW,
					         "Select the scale-file:");
			if (the_reply.good == FALSE) return;
			if (the_reply.good == TRUE)
				np->scale_file_ptr=fopen(local_wkstr,READ_TEXT);
			if (np->scale_file_ptr==NULL)
			{
				strcpy(local_wkstr, net_iop);
				for (i = 0; i < MAX_WORD_SIZE; i++)
					if (local_wkstr[i] == '.') break;
					else if (local_wkstr[i] == ENDSTRING)
					{
			   			local_wkstr[i] = '.';
			   			break;
			   		}
			   
				if (i > (MAX_WORD_SIZE - 5)) 
				{
					local_wkstr[MAX_WORD_SIZE - 5] = '.';
					i = MAX_WORD_SIZE - 4;
				}                               
				else   
					i++;
				local_wkstr[i]   = 's';
				local_wkstr[i+1] = 'c';
				local_wkstr[i+2] = 'l';
				local_wkstr[i+3] = ENDSTRING;
				
				getFName(local_wkstr,&the_reply,TEXT_FILE,SAVE_IT_WITH_NEW,
					         "Enter new scale-file name:");
				if (the_reply.good == FALSE) return;
				if((np->scale_file_ptr=fopen(local_wkstr,WRITE_TEXT))==NULL)
				{
					sprintf(IO_str, " File %s didn't open for output\n", local_wkstr);
					IO_print (0);
					return;
				} /* end while */
				np->scale_file_flag = _IOWRT;
			} /* end inner if */
			else
				np->scale_file_flag = _IOREAD;
			SetVol(NULL,homeVolume);
#endif
		} /* end if */
		
		/* At this point np->scale_file_ptr is not NULL!  */
		io_size = np->num_inputs + np->num_outputs;
temp = (float*)sys_alloc((unsigned int)(io_size*sizeof(float)));
		scale_max = (float*)sys_alloc((unsigned int)(io_size*sizeof(float)));
		scale_min = (float*)sys_alloc((unsigned int)(io_size*sizeof(float)));
#if USE_SCALED_INTS
		Sint_array = (Sint*)sys_alloc((unsigned int)(io_size*sizeof(Sint)));
#endif
		for (i = 0; i < io_size; i++)
		{
			scale_max[i]= -HUGE_VAL;
			scale_min[i]= HUGE_VAL;
		}
		if((f=fopen("workfile.net",READ_WRITE_BINARY))==NULL)
		{
			sprintf (IO_str, " Work file didn't open!\n");
			IO_print (0);
		return;
} /* end if */
		if (np->scale_file_flag == _IOWRT)
		{
#if !USE_SCALED_INTS
			for (n = 0; n < np->num_io_pairs; n++)
			{
				fread ((char*)temp, sizeof(float), io_size, f);
				for (i = 0; i < io_size; i++)
				{
					if (temp[i]>scale_max[i])
						scale_max[i] = temp[i];
					if (temp[i]<scale_min[i])
						scale_min[i] = temp[i];
				} /* end for i */
			} /* end for n */
			rewind (f);
			for (i = 0; i < io_size; i++)
			{
				fprintf (np->scale_file_ptr, " %f", scale_min[i]);
				if ((i%6)==5)
					putc ('\n',np->scale_file_ptr);
			} /* end for i */
			if (i%6)
				putc ('\n',np->scale_file_ptr);
			for (i = 0; i < io_size; i++)
			{
				fprintf (np->scale_file_ptr, " %f", scale_max[i]);
				if ((i%6)==5)
					putc ('\n',np->scale_file_ptr);
			} /* end for i */
			if (i%6)
				putc ('\n',np->scale_file_ptr);
			rewind (np->scale_file_ptr);
#endif
#if USE_SCALED_INTS
if (np->io_file_ptr == NULL)
{
sprintf (IO_str, "Must load I/O pairs prior to scaling\n");
IO_print (0);
return;
} /* end if */
/* start reading I/O from np->io_file_ptr */
rewind (np->io_file_ptr);
for (n = 0; n < np->num_io_pairs; n++)
{
while (((test_char=getc(np->io_file_ptr))!='(')
&&!feof(np->io_file_ptr));
for (i = 0; i < io_size; i++)
{
if (fscanf(np->io_file_ptr,"%f",&t)<1)
{
sprintf (IO_str,"A problem has appeared in your I/O pair file\n");
IO_print(0);
return;
} /* end if */
if (t < scale_min[i])
scale_min[i] = t;
if (t > scale_max[i])
scale_max[i] = t;
} /* end for i */
		} /* end for n */
			for (i = 0; i < io_size; i++)
			{
				fprintf (np->scale_file_ptr, " %f", scale_min[i]);
				if ((i%6)==5)
					putc ('\n',np->scale_file_ptr);
			} /* end for i */
			if (i%6)
				putc ('\n',np->scale_file_ptr);
			for (i = 0; i < io_size; i++)
			{
				fprintf (np->scale_file_ptr, " %f", scale_max[i]);
				if ((i%6)==5)
					putc ('\n',np->scale_file_ptr);
			} /* end for i */
			if (i%6)
				putc ('\n',np->scale_file_ptr);
			rewind (np->scale_file_ptr);
#endif
} /* end if */
		else
			if (np->scale_file_flag == _IOREAD)
			{
				for (i = 0; i < io_size; i++)
				{
					if (fscanf(np->scale_file_ptr,"%f",&t) < 1)
					{
						printf (" Bogus scale file contents!\n");
						exit (0);
					} /* end if */
					scale_min[i] = t;
				} /* end for i */
				for (i = 0; i < io_size; i++)
				{
					if (fscanf(np->scale_file_ptr,"%f",&t) < 1)
					{
						printf (" Bogus scale file contents!\n");
						exit (0);
					} /* end if */
					scale_max[i] = t;
				} /* end for i */
				rewind (np->scale_file_ptr);
			} /* end if */
		else
		{
			sprintf (IO_str,"Invalid scale file mode!\n");
IO_print(0);
		return;
} /* end else */
		/* Now scale_max and scale_min have proper values */
		if (np->scale_action==0)
		{
#if !MAC_GRAPH
			sprintf (IO_str,"Choose scaling option\n");
			IO_print(0);
			sprintf (IO_str, "Response            Action\n");
			IO_print(0);
			sprintf (IO_str, "    0               No Scaling\n");
			IO_print(0);
			sprintf (IO_str, "    1               Scale input\n");
			IO_print(0);
			sprintf (IO_str, "    2               Scale output\n");
			IO_print(0);
			sprintf (IO_str, "    3               Scale both input and output\n");
			IO_print(0);
			sprintf (IO_str,"Response> ");
			IO_print (0);
			np->scale_action = atoi(gets(IO_str));
#endif
#if MAC_GRAPH
			if( (np->scale_action = D_Scale_Options()) < 0)
			{
				np->scale_action = 0;
				return;
			}
#endif
		} /* end if */
		if (np->scale_action&SCALE_INPUT)
		{
#if !MAC_GRAPH
			sprintf (IO_str, " Enter respectively minimum and maximum input values <%8.4f %8.4f>",
			mni = 0.15, mxi = 0.85);
			IO_print(0);
			sscanf (gets(IO_str),"%f%f",&mni, &mxi);
			for (i = np->num_inputs-1; i >= 0; i--)
				if ((scale_max[i]-scale_min[i])<=(0.00000001*(scale_max[i]+scale_min[i])))
				{
					sprintf (IO_str,"Input %d has dynamic range %f to %f\n",
					i, scale_min[i], scale_max[i]);
					IO_print(0);
					sprintf(IO_str,"Scale anyway?  <n> ");
					IO_print(0);
					if (gets(IO_str)[0]!='y')
					{
						new_bad_elt = (struct bad_list*)sys_alloc((unsigned int)sizeof(struct bad_list));
						sprintf (IO_str,"Default input <0.0> ");
						IO_print(0);
						new_bad_elt->def = 0.0;
						sscanf(gets(IO_str),"%f",&new_bad_elt->def);
						new_bad_elt->index = i;
						new_bad_elt->next = bad_input_list;
						bad_input_list = new_bad_elt;
					} /* end inner if */
				} /* end outer if */
#endif
#if MAC_GRAPH
			mni = 0.15;
			mxi = 0.85;
			D_Max_MinGeneric("input", &mxi, &mni);
			for (i = np->num_inputs-1; i >= 0; i--)
				if ((scale_max[i]-scale_min[i])<=(0.00000001*(scale_max[i]+scale_min[i])))
					if (D_Scale_Anyway("Input",i, scale_min[i], scale_max[i])==TRUE)
					{
						new_bad_elt = (struct bad_list*)sys_alloc((unsigned int)sizeof(struct bad_list));
						new_bad_elt->def = D_GetDefault("Input",i,0.0);
						new_bad_elt->index = i;
						new_bad_elt->next = bad_input_list;
						bad_input_list = new_bad_elt;
					} /* end if */
#endif
			} /* end if */
		if (np->scale_action&SCALE_OUTPUT)
		{
#if !MAC_GRAPH
			sprintf (IO_str, " Enter respectively minimum and maximum output values <%8.4f %8.4f>",
			mno = 0.15, mxo = 0.85);
			IO_print(0);
			sscanf (gets(IO_str),"%f%f",&mno, &mxo);
			for (i = np->num_outputs-1; i >= 0; i--)
				if ((scale_max[i+np->num_inputs]-scale_min[i+np->num_inputs])<=
					(0.00000001*(scale_max[i+np->num_inputs]+scale_min[i+np->num_inputs])))
				{
					sprintf (IO_str,"Output %d has dynamic range %f to %f\n",
					i, scale_min[i+np->num_inputs], scale_max[i+np->num_inputs]);
					IO_print(0);
					sprintf(IO_str,"Scale anyway?  <n> ");
					IO_print(0);
					if (gets(IO_str)[0]!='y')
					{
						new_bad_elt = (struct bad_list*)sys_alloc((unsigned int)sizeof(struct bad_list));
						sprintf (IO_str,"Default output <%8.4f> ",new_bad_elt->def=0.5*(mxo+mno));
						IO_print(0);
						sscanf(gets(IO_str),"%f",&new_bad_elt->def);
						new_bad_elt->index = i;
						new_bad_elt->next = bad_output_list;
						bad_output_list = new_bad_elt;
					} /* end inner if */
				} /* end outer if */
#endif
#if MAC_GRAPH
			mno = 0.15;
			mxo = 0.85;
			D_Max_MinGeneric("output", &mxo, &mno);
			for (i = np->num_outputs-1; i >= 0; i--)
				if ((scale_max[i+np->num_inputs]-scale_min[i+np->num_inputs])<=
					(0.00000001*(scale_max[i+np->num_inputs]+scale_min[i+np->num_inputs])))
					if (D_Scale_Anyway("Output",i, scale_min[i+np->num_inputs], scale_max[i+np->num_inputs])==TRUE)
					{
						new_bad_elt = (struct bad_list*)sys_alloc((unsigned int)sizeof(struct bad_list));
						new_bad_elt->def = D_GetDefault("Output",i,0.5*(mxo+mno));
						new_bad_elt->index = i;
						new_bad_elt->next = bad_output_list;
						bad_output_list = new_bad_elt;
					} /* end if */
#endif
			} /* end if */
#if USE_SCALED_INTS
rewind (np->io_file_ptr);
#endif
for (n = 0; n < np->num_io_pairs; n++)
			{
#if !USE_SCALED_INTS
				fseek (f, (long)n*io_size*sizeof(float),0);
				fread ((char*)temp, sizeof(float), io_size, f);
#endif
#if USE_SCALED_INTS
while ((getc(np->io_file_ptr)!='(')
&&!feof(np->io_file_ptr));
for (i = 0; i < io_size; i++)
{
if (fscanf(np->io_file_ptr,"%f",&t)<1)
{
sprintf (IO_str,"A problem has developed with your I/O pair file\n");
IO_print(0);
return;
} /* end if */
temp[i] = t;
} /* end for i */
#endif
				if (np->scale_action & SCALE_INPUT)
{
for (i=0,temp_elt=bad_input_list; i < np->num_inputs; i++)
					if (temp_elt == NULL)
						temp[i] = mni+(temp[i]-scale_min[i])*(mxi-mni)/(scale_max[i]-scale_min[i]);
				else
					if (temp_elt->index == i)
					{
						temp[i] = temp_elt->def;
						temp_elt = temp_elt->next;
					} /* end if */
				else
					temp[i] = mni+(temp[i]-scale_min[i])*(mxi-mni)/(scale_max[i]-scale_min[i]);
				} /* end if */
				if (np->scale_action & SCALE_OUTPUT)
{
for (i=0,temp_elt=bad_output_list; i < np->num_outputs; i++)
					if (temp_elt == NULL)
						temp[i+np->num_inputs] = mno+(temp[i+np->num_inputs]-scale_min[i+np->num_inputs])*(mxo-mno)/
							(scale_max[i+np->num_inputs]-scale_min[i+np->num_inputs]);
					else
						if (temp_elt->index == i)
						{
							temp[i] = temp_elt->def;
							temp_elt = temp_elt->next;
						} /* end if */
					else
						temp[i+np->num_inputs] = mno+(temp[i+np->num_inputs]-scale_min[i+np->num_inputs])*(mxo-mno)/
							(scale_max[i+np->num_inputs]-scale_min[i+np->num_inputs]);
} /* end if */
#if USE_SCALED_INTS
for (i = 0; i < io_size; i++)
Sint_array[i] = C_float_to_Sint(temp[i]);
fseek (f, (long)n*io_size*sizeof(Sint), 0);
fwrite ((char*)Sint_array, sizeof(Sint), io_size, f);
#endif
#if !USE_SCALED_INTS
fseek (f, (long)n*io_size*sizeof(float), 0);
fwrite ((char*)temp, sizeof(float), io_size, f);
#endif
			} /* end for n */
			rewind (f);
		if (np->scale_action)
		{
#if !MAC_GRAPH
			sprintf (IO_str, " Write a new file of I/O pairs <n> ");
			IO_print(0);
			if (gets(IO_str)[0]=='y')
			{
				sprintf (IO_str, " File name for scaled I/O pairs> ");
				IO_print(0);
				gets(local_wkstr);
				while ((fu=fopen(strcat(local_wkstr,".iop"),READ_TEXT))!=NULL)
				{
					fclose (fu);
					sprintf (IO_str, " Warning!  File %s will be overwritten\n", local_wkstr);
					IO_print(0);
					sprintf (IO_str, " Press carriage return to confirm or enter new file name> ");
					IO_print(0);
					if (!strlen(gets(IO_str)))
						break;
					strcpy (local_wkstr, IO_str);
				} /* end while */
				while ((fu=fopen(local_wkstr,WRITE_TEXT))==NULL)
				{
					sprintf (IO_str, " File %s didn't open for output\n", local_wkstr);
					IO_print(0);
					sprintf (IO_str, " Enter new file name or press carriage return to exit> ");
					IO_print(0);
					if (!strlen(gets(IO_str)))
					return;
strcat(strcpy(local_wkstr,IO_str),".iop");
				} /* end while */
#endif
#if MAC_GRAPH
/*			strcat(local_wkstr, "Scaled ");*/
/*			strcpy(local_wkstr, net_iop);*/
			strcpy(local_wkstr, "");
			getFName(local_wkstr,&the_reply,TEXT_FILE,SAVE_IT_IOP,"Write a new file of I/O pairs?");
		    if (the_reply.good == TRUE) 
			{				
				if ((fu=fopen(local_wkstr,WRITE_TEXT))==NULL)
				{
					sprintf (IO_str, " File %s didn't open for output\n", local_wkstr);
					IO_print(0);
					fclose (f);
					return;
				} /* end while */
#endif
				for (n = 0; n < np->num_io_pairs; n++)
				{
#if USE_SCALED_INTS
					fread ((char*)Sint_array, sizeof(Sint), io_size, f);
					for (i = 0; i < io_size; i++)
					temp[i] = C_Sint_to_float(Sint_array[i]);
#endif
#if !USE_SCALED_INTS
					fread ((char*)temp, sizeof(float), io_size, f);
#endif
					putc ('(', fu);
					for (i = 0; i < io_size; i++)
					{
						fprintf (fu, " %f", temp[i]);
						if ((i%6)==5)
							putc('\n',fu);
					} /* end for i */
					putc (')', fu);
					if (i%6)
						putc ('\n', fu);
				} /* end for n */
				fclose (fu);
				rewind (f);
			} /* end inner if */
		} /* end outer if */
	fclose (f);
	} /* end if num_io_pairs */
	else
	{
		sprintf (IO_str, " Cannot scale until I/O pairs are loaded\n");
		IO_print(0);
	} /* end else */
} /* end SC_scale_IOpairs */


/*
 *  SC_scale_any_file()
 *    Scales file fin with the current scaling parameters and outputs the new data to file fout
 */
 
int SC_scale_any_file(np, fin, fout)
Net *np;  
FILE *fin, *fout;
{
	int i, test, done, error;
	float temp,tempmx,tempmn;
	char ch, SC_findparen();
	
	done = FALSE;
	error = 0;
	while (!done)
	{
		if (((unsigned int)(SC_findparen(fin))) == EOF)
			break;
		

		putc ('(', fout);
		for (i=0,temp_elt=bad_input_list, tempmx = mxi, tempmn = mni; i < io_size; i++)
		{	
			
			test = fscanf (fin, "%f",&temp);					/* scan for a number */
			
			if (test == EOF)				 					/* if EOF, then we are finished */
			{
				done = TRUE;
				break;
			}
			if (test != 1)					 					/* if input wasn't a number, 	  */
				break;											/*   then go on to next input set */

					
			if (i == np->num_inputs)							/* if the count equals the number of inputs, */
			{
				temp_elt=bad_output_list;						/*   then we switch to convert outputs		 */
				tempmx = mxo;
				tempmn = mno;
			}
			
			/* only scale if scaling is set (it could be set for inputs and not outputs, or vice versa) */	
			if (((i < np->num_inputs) && ((np->scale_action & 1)==1)) ||
				((i >= np->num_inputs) && ((np->scale_action & 2)==2)))
			{
				if (temp_elt == NULL)
					temp = tempmn+(temp-scale_min[i])*(tempmx-tempmn)/(scale_max[i]-scale_min[i]);
				else if (temp_elt->index == i)
					{
						temp = temp_elt->def;
						temp_elt = temp_elt->next;
					} /* end if */
				else
					temp = tempmn+(temp-scale_min[i])*(tempmx-tempmn)/(scale_max[i]-scale_min[i]);
			}
				
			fprintf (fout, " %f", temp);						/* Print scaled value to file */
			if ((i%6)==5)										/* Print a newline after every six numbers */
				putc('\n',fout);
		} 	
		fprintf (fout, " )\n", temp);							/* Print a Close Parenthesis at the end of a data set */
	} /* while */

	return error;
}

/*
 *  SC_findparen()
 *    reads characters from file fp until a open parenthesis is found
 *    returns '(' if '(' is found.
 *    returns EOF if EOF is found.
 */
 
char SC_findparen(fp)
FILE *fp;
{
	char ch;
	
	do
	{
		ch = (char) getc (fp);
		if (feof(fp))
			break;
	} while ((ch != '(')&&!feof(fp));
	
	if (feof(fp))
	return EOF;
	else
	return ch;
}







