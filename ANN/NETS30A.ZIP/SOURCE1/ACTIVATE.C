/*=============================*/
/*           NETS              */
/*                             */
/*     a product of the 	   */
/*	Software Technology Branch */
/*  NASA, Johnson Space Center */
/*                             */
/* authors:           		   */
/*       Paul Baffes           */
/*       Steve Bayer           */
/*       Bryan Dulock          */
/*       Linda Jensen          */
/*       Chris Ortiz           */
/*       Gary Riley            */
/*       Robert Shelton        */
/*       Todd Phillips         */
/*=============================*/


/*
-----------------------------------------------------------------------
  Code For Semi-linear Activation Function (Prefix = A_)
----------------------------------------------------------------------
  This code is divided into 3 major sections:

  (1) include files
  (2) global variables
  (3) subroutines
 
  Each section is further explained below.
----------------------------------------------------------------------
*/



/*
----------------------------------------------------------------------
  INCLUDE FILES
----------------------------------------------------------------------
*/
#include  "common.h"

/*
extern functions:
--------------------------------------------
We use only one extern function-
Sint C_float_to_Sint
*/

extern Sint C_float_to_Sint();
extern char * sys_long_alloc();

/*
----------------------------------------------------------------------
  GLOBAL VARIABLES
----------------------------------------------------------------------
  The only global variable used by this code is a table needed for storing
  all of the values of the semilinear funciton. This table is generated
  to help speed things up when node outputs are being calculated. Rather
  than run the rather long semilinear function, a table reference is 
  made which will generate the appropriate answer.  In short, we pre-
  calculate all possible values for the semilinear funciton and store
  them in a table using the incoming sum value as an index for finding
  the precalculated activation value.
----------------------------------------------------------------------
*/

     /* see "semi_linears" variable below */


/*
======================================================================
  ROUTINES IN NET.C                                                   
======================================================================
  The only routine in this file is one which takes a Sint value which
  represents a sum and returns the semilinear activation value.

  Type Returned                 Routine                                 
  -------------                 -------                                 
                                                                      
    Sint                        A_activation
======================================================================
*/



/*
----------------------------------------------------------------------
  Below is the definition for the global variable "semi_linears". This
  table is of size MAX_SUM.
----------------------------------------------------------------------
*/
extern char IO_str [MAX_LINE_SIZE];
#if  USE_SCALED_INTS
static Sint  *semi_linears;


void	A_initialize()
{
	int i;
	FILE *f = NULL;

	semi_linears = (Sint*)sys_long_alloc((long)MAX_SUM*sizeof(Sint));
	if ((f=fopen("table.act",READ_BINARY))==NULL)
	{
		sprintf (IO_str, "Creating 'table.act', please wait...\n");
		IO_print (0);
		for (i = 0; i < MAX_SUM; i++)
		semi_linears[i] = C_float_to_Sint(1.0/(1.0+exp(-i*0.001)));
		f = fopen("table.act",WRITE_BINARY);
		fwrite((char*)semi_linears, sizeof(Sint), MAX_SUM, f);
		fclose (f);
		sprintf (IO_str, "**** Done. ****\n\n");
		IO_print (0);
	} /* end if */
	else
	{
		fread ((char*)semi_linears, sizeof(Sint), MAX_SUM, f);
		fclose (f);
	} /* end else */
} /* end A_initialize */
#endif

Sint  A_activation(sum)
D_Sint  sum;
/*
----------------------------------------------------------------------
 All that is done here is to take the incoming argument, convert it to
  an index, and then use the 'semi_linears' table to return the value   
  stored for the resulting Sint.  The only trick is to remember that  
  if a NEGATIVE value comes in, then you need to return 1 (in Sint    
  form) minus the value retrieved from 'semi_linears'.                
----------------------------------------------------------------------
*/
{
#if   USE_SCALED_INTS
   static Sint  high_Sint = (MAX_SUM - 1);
   static Sint  low_Sint  = ((MAX_SUM -1) * -1);
   int          isum;

   if (sum > high_Sint) 
      sum = high_Sint;
   else if (sum < low_Sint)
      sum = low_Sint;

   isum = (int) sum;                /* isum = sum as an index the array */
   if (isum >= 0)
      return(semi_linears[isum]);
   return(SINT_SCALE - semi_linears[isum * -1]);
#else
   return( (Sint)(1.0 / (1.0 + exp(-1.0 * sum))) );
#endif

} /* A_activation */

