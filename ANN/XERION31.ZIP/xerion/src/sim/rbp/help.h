
/**********************************************************************
 * $Id: help.h,v 1.3 92/11/30 12:01:13 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

/**********************************************************************
 * These help strings will be automatically registered 
 * and made available to the "whatis" command and "Help"
 * buttons on the GUI
 *
 * THIS FILE SHOULD ONLY BE INCLUDED BY THE FILE "rbp.c"
 * ANY OTHER FILE INCLUDING IT WILL CAUSE NAME CONFLICTS
 *
 **********************************************************************/

#ifndef rbp_help_h
#define rbp_help_h

/*********************************************************************/
char	*helpString_delayCount[] = {
  "Degree of time step slowdown used for viewing the details of network",
  "at each time step.  Basically, a trivial loop from 1 to",
  "delayCount*1000 is used between network time steps.  This may be",
  "used while viewing the \"testing\" of cases (e.g. \"clicking\" on them",
  "in the \"Activations\" window) and only while the \"Each Time Step\"",
  "updating option is turned on in the Activations window. When",
  "viewing, try setting the var to 100 or 1000; performance and ease of",
  "viewing will vary depending on your machine's speed (\"raw\" CPU",
  "speed, memory access speed, screen update speed, etc.), of course.",
  NULL } ;
/*********************************************************************/
char	*helpString_weightCost[] = {
  "Cost associated with magnitude of weights.  It is sometimes useful",
  "to limit the absolute magnitude of weights in this way, in order to",
  "improve the trained net's \"generalization\" capabilities.",
  NULL } ;
/*********************************************************************/
char	*helpString_zeroErrorRadius[] = {
  "Interval of acceptance for agreement between desired output and",
  "target output of a unit.  The degree to which a \"near miss\" will",
  "count as a \"hit\".",
  NULL } ;
/*********************************************************************/

#endif				/* rbp_help_h */
