
/**********************************************************************
 * kcl.h,v 1.5 1993/04/30 16:36:54 xerion Exp
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose is hereby granted without fee, 
 * provided that the above copyright notice appears in all copies and that 
 * both the copyright notice and this permission notice appear in 
 * supporting documentation, and that the name of University of Toronto 
 * not be used in advertising or publicity pertaining to distribution 
 * of the software without specific, written prior permission.  
 * University of Toronto makes no representations about the suitability 
 * of this software for any purpose. It is provided "as is" without 
 * express or implied warranty. 
 *
 * UNIVERSITY OF TORONTO DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS 
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
 * FITNESS, IN NO EVENT SHALL UNIVERSITY OF TORONTO BE LIABLE FOR ANY 
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER 
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF 
 * CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN 
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 **********************************************************************/
#define UNIFORM 1
#define LINEAR  2
#define GAUSSIAN 3

#define EXPONENTIAL 1
#define ONE_OVER_T 2

#define MIN(x, y)	((x) < (y) ? (x) : (y))
#define MAX(x, y)	((x) > (y) ? (x) : (y))

#define PI 3.1415927

#define initialVarianceProportion 0.1
#define finalVarianceProportion 0.5

#ifndef KCL_H
#define KCL_H

/* The following structures must be defined, even if you don't
 * need them in you simulator
 */
typedef struct NetExtensionRec {	/* BIND */
  ProcPtr calculateNeighborhoodDistanceProc; /* NOBIND */
  int   neighborhoodFunction ;          /* netParam: */
  int   prevNeighborhoodFunction ;      /* nosave: */
  int   neighborhoodDecayFunction ;     /* netParam: */
  Real  initialMaxDistance ;            /* netParam: */
  Real  maxDistance ;                   /* netParam: */
  Real  minDistance ;                   /* netParam: */
  Real  prevMaxDistance ;               /* nosave: */
  Real  neighborhoodDecayRate ;         /* netParam: */
  Real  variance ;                      /* netParam: */
  Real  prevVariance ;                  /* nosave: */
  Real  aveVariance ;                   /* nosave: */
  Real  initialVariance ;               /* netParam: */
  Real  initialLearningRate ;           /* netParam: */
  Real  minVariance ;                   /* netParam: */
  Real  radius ;                        /* netParam: */
  int   learningRateDecayFunction ;     /* netParam: */
  Real  learningRateDecay ;             /* netParam: */
  Real  tau ;                           /* netParam: */
  int   unitCounter ;                   /* nosave: */
  int   configured ;                    /* nosave: */
  int   maxXIndex ;   
  int   maxYIndex ;   
  int   curXIndex ;                     /* nosave: */
  int   curYIndex ;                     /* nosave: */
  Unit  **unit ;                        /* NOBIND */
  Unit  winner ;                       /* nosave: */
  Real  minTotalInput ;                 /* nosave: */
} NetExtensionRec ;

typedef struct GroupExtensionRec {	/* BIND */
  int   foo ;
} GroupExtensionRec ;

typedef struct UnitExtensionRec {	/* BIND */
  Unit  *neighbor ;		/* nosave: counter: numNeighbors */
  Real  *distance ;		/* nosave: counter: numNeighbors */
  Real  *neighbWeight ;		/* nosave: counter: numNeighbors */
  int   numNeighbors ;    
  int   lastNeighborIndex ;
  int   x ;
  int   y ;
} UnitExtensionRec ;

typedef struct LinkExtensionRec {	/* BIND */
  int	foo ;
} LinkExtensionRec ;

typedef struct ExampleExtensionRec {	/* BIND */
  int	foo ;
} ExampleExtensionRec ;


#define simpleSigmoid(x) (1.0/(1.0+exp(-(double)(x))))
#define sigmoid(x)       ((x) > 30 ? 			\
			  (1.0) : ((x) < -30 ? (0.0) : simpleSigmoid(x)))

#define sigmoidDeriv(x)	((x)*(1.0 - (x)))

#define MIN(x, y)	((x) < (y) ? (x) : (y))
#define MAX(x, y)	((x) > (y) ? (x) : (y))

#define McurrentEpoch(net)       ((net)->currentEpoch)
#define MbatchSize(net)		 ((net)->batchSize)

#define Mepsilon(net)		 ((net)->mz->epsilon)
#define Mmomentum(net)		 ((net)->mz->alpha)
#define MdirectionMethod(net)	 ((net)->mz->directionMethod)
#define MstepMethod(net)	 ((net)->mz->stepMethod)

#define McalculateNeighborhoodDistanceProc(net) M0(net, extension->calculateNeighborhoodDistanceProc)
#define Mvariance(net)		 ((net)->extension->variance)
#define MprevVariance(net)	 ((net)->extension->prevVariance)
#define MaveVariance(net)	 ((net)->extension->aveVariance)
#define MunitCounter(net)	 ((net)->extension->unitCounter)
#define MinitialVariance(net)	 ((net)->extension->initialVariance)
#define MminVariance(net)	 ((net)->extension->minVariance)
#define MinitialLearningRate(net)((net)->extension->initialLearningRate)
#define MlearningRateDecayFunction(net) ((net)->extension->learningRateDecayFunction)
#define MlearningRateDecay(net)  ((net)->extension->learningRateDecay)
#define Mtau(net)                ((net)->extension->tau)
#define MneighborhoodFunction(net) ((net)->extension->neighborhoodFunction)
#define MprevNeighborhoodFunction(net) ((net)->extension->prevNeighborhoodFunction)
#define MneighborhoodDecayFunction(net) ((net)->extension->neighborhoodDecayFunction)
#define MneighborhoodDecayRate(net) ((net)->extension->neighborhoodDecayRate)
#define MinitialMaxDistance(net) ((net)->extension->initialMaxDistance)
#define MmaxDistance(net)        ((net)->extension->maxDistance)
#define MminDistance(net)        ((net)->extension->minDistance)
#define MprevMaxDistance(net)    ((net)->extension->prevMaxDistance)
#define Munit(net)               ((net)->extension->unit)
#define Mconfigured(net)         ((net)->extension->configured)
#define MmaxXIndex(net)          ((net)->extension->maxXIndex)
#define MmaxYIndex(net)          ((net)->extension->maxYIndex)
#define McurXIndex(net)          ((net)->extension->curXIndex)
#define McurYIndex(net)          ((net)->extension->curYIndex)
#define MminTotalInput(net)       ((net)->extension->minTotalInput)
#define Mwinner(net)             ((net)->extension->winner)
#define Mradius(net)             ((net)->extension->radius)

#endif				/* KCL_H */
