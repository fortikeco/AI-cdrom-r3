/**********************************************************************
 * $Id: cascor.h,v 1.2 93/01/26 10:46:17 drew Exp $
 * 
 * Cascade Correlation Module
 *
 * Originally written by:
 * 	Brion Dolenko
 * 	The University of Manitoba
 * 	Winnipeg, Manitoba, Canada
 *
 * Modified by: 
 *	Drew van Camp
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

#ifndef __cascor_cascor_h
#define __cascor_cascor_h

typedef struct NetExtensionRec {	/* BIND */
  Real		zeroErrorRadius ;	/* netParam: */
  int		maxCC_HiddenUnits;	/* netParam: */
  int		candidates;		/* netParam: */
  int		hiddenUnits;		/* netParam: */
  int		initialMaxIterations;	/* netParam: */
  int		initialMaxFuncEvals;	/* netParam: */
  int		initialRepetitionCount;	/* netParam: */
  Real		candWeightInitMag;	/* netParam: */
  int		cascade;		/* netParam: */
  Real		sigmoidMax;		/* netParam: */
  Real		sigmoidMin;		/* netParam: */
  Real		sigmoidGain;		/* netParam: */
  Boolean	showCandidateMz;	/* netParam: */
  Boolean	trainingOutputs ;	/* invisible: */
  Minimize	candidateMz;
  Sigmoid	sigmoid;
} NetExtensionRec ;	

typedef struct UnitExtensionRec {	/* BIND */
  Real  	activationSum ;		/* nosave: */
  Real		activationAvg ;		/* nosave: */
  Real		errorSum ;		/* nosave: */
  Real		errorAvg ;		/* nosave: */
  Real		corrScore ;		/* nosave: */
  int		numExamples;		/* nosave: */
} UnitExtensionRec ;

typedef struct LinkExtensionRec {	/* BIND */
  int 	corrSign ;			/* nosave: */
  Real  partialCorrScore ; 		/* nosave: */
} LinkExtensionRec ;

#define Mext(obj)			((obj)->extension)

#define MbatchSize(net)			((net)->batchSize)
#define MzeroErrorRadius(net)		(Mext(net)->zeroErrorRadius)
#define MmaxCC_HiddenUnits(net)		(Mext(net)->maxCC_HiddenUnits)
#define Mcandidates(net)		(Mext(net)->candidates)
#define MhiddenUnits(net)		(Mext(net)->hiddenUnits)
#define MinitialMaxIterations(net)	(Mext(net)->initialMaxIterations)
#define MinitialMaxFuncEvals(net)	(Mext(net)->initialMaxFuncEvals)
#define MinitialRepetitionCount(net)	(Mext(net)->initialRepetitionCount)
#define McandWeightInitMag(net)		(Mext(net)->candWeightInitMag)
#define MminAcceptableCorr(net)		(Mext(net)->minAcceptableCorr)
#define Mcascade(net)			(Mext(net)->cascade)
#define MtrainingOutputs(net)		(Mext(net)->trainingOutputs)
#define MsigmoidMax(net)		(Mext(net)->sigmoidMax)
#define MsigmoidMin(net)		(Mext(net)->sigmoidMin)
#define MsigmoidGain(net)		(Mext(net)->sigmoidGain)
#define Msigmoid(net)			(Mext(net)->sigmoid)
#define MshowCandidateMz(net)		(Mext(net)->showCandidateMz)
#define McandidateMz(net)		(Mext(net)->candidateMz)

#define MactivationSum(unit)		(Mext(unit)->activationSum)
#define MactivationAvg(unit)		(Mext(unit)->activationAvg)
#define MerrorSum(unit)			(Mext(unit)->errorSum)
#define MerrorAvg(unit)			(Mext(unit)->errorAvg)
#define McorrScore(unit)		(Mext(unit)->corrScore)
#define MnumExamples(unit)		(Mext(unit)->numExamples)

#define McorrSign(link)			(Mext(link)->corrSign)
#define MpartialCorrScore(link)		(Mext(link)->partialCorrScore)

#define McalculateMean(unit)	((unit)->group->unitOtherUpdateProc)(unit)

/* Masks for groups */
#define CC_HIDDEN	((int)(1<<(HIGHEST_BIT_USED+1)))
#define CANDIDATE	((int)(1<<(HIGHEST_BIT_USED+2)))

/* traces for training */
extern struct TRACE afterOutputPhase ; 		/* BIND */
extern struct TRACE afterCandidatePhase ; 	/* BIND */

#endif				/*  __cascor_cascor_h */
