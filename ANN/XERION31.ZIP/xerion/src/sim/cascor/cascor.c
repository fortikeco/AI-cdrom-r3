/**********************************************************************
 * $Id: cascor.c,v 1.2 93/01/26 10:46:15 drew Exp $
 * 
 * Cascade Correlation Module
 *
 * Originally written by:
 * 	Brion Dolenko
 * 	The University of Manitoba
 * 	Winnipeg, Manitoba, Canada
 *
 * Modified by: 
 *	Drew van Camp
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

#include <stdio.h>
#include <math.h>

#include <xerion/useful.h>
#include <xerion/version.h>
#include <xerion/simulator.h>
#include <xerion/sigmoid.h>
#include <xerion/commands.h>
#include <xerion/minimizeCom.h>
#include "cascor.h"
#include "utils.h"
#include "help.h"

#define MZ_BAD_STOP(m)	(   (m)->mzResultCode == MZSTOPPED 	\
			 || (m)->mzResultCode == MZINTERRUPTED	\
			 || (m)->mzResultCode == MZSYSTEMERROR)
#define MZ_GOOD_STOP(m)	(   (m)->mzResultCode == MZOKFMIN)

/* initialization / deinitialization routines */
static void	initNet     ARGS((Net	net)) ;
static void	deinitNet   ARGS((Net	net)) ;
static void	initGroup   ARGS((Group	group)) ;
static void	initUnit    ARGS((Unit	unit)) ;
static void	deinitUnit  ARGS((Unit	unit)) ;
static void	initLink    ARGS((Link	link)) ;
static void	deinitLink  ARGS((Link	link)) ;

/* commands for Cascade Correlation training and saving */
int	command_cctrain	ARGS((int tokc, char **tokvq)) ;
int	command_ccsave	ARGS((int tokc, char **tokvq)) ;

/*
 * Routines for calculating network error, and link derivatives for
 * the entire network in the output unit training/testing phase
 */
static void	initOutputPhase		ARGS((Net)) ;
static void	calculateNetError	ARGS((Net, ExampleSet));
static void	calculateNetErrorDeriv	ARGS((Net, ExampleSet));

/*
 * Routines for calculating network error, and link derivatives for
 * the entire network in the output-candidate correlation training/testing
 * phase.
 */
static void	initCandidatePhase		ARGS((Net)) ;
static void	calculateNetCorrelation		ARGS((Net, ExampleSet));
static void	calculateNetCorrelationWithCost	ARGS((Net, ExampleSet));
static void	calculateNetCorrelationDeriv	ARGS((Net, ExampleSet));

/* routines to calculate net activations and gradient */
static Proc	allPhaseNetBack		 ARGS((Net	net));
static Proc	outputPhaseNetForward	 ARGS((Net	net));
static Proc	candidatePhaseNetForward ARGS((Net	net));

/* routines to compute mean candidate unit activation and mean output error
   to use when updating candidate weights */
static void	findMeanActivity	ARGS((Unit	unit));
static void	findMeanError		ARGS((Unit	unit));

/* routines to update outputs' incoming weights and candidates' incoming
   weights respectively */
static void	updateOutputLinkDerivs	  ARGS((Unit	unit));
static void	updateCandidateLinkDerivs ARGS((Unit	unit));

/* routine to find the candidate unit with highest correlation score */
static void	electCandidate		ARGS((Unit unit, void *data));

static Minimize	getCurrentNetMinimize ARGS(()) ;

/* traces for during training */
struct TRACE afterOutputPhase ;
struct TRACE afterCandidatePhase ;

/***********************************************************************
*	Name:		main 
*	Description:	the main function, used for the xerion simulator
*	Parameters:	
*		int	argc	- the number of input args
*		char	**argv  - array of argument strings from command 
*				  line
*	Return Value:	
*		int	main	- 0
************************************************************************/
int main(argc, argv)
  int	argc ;
  char	**argv ;
{
  authors = "Brion Dolenko" ;

  registerMask(CC_HIDDEN, "CC_HIDDEN");	/* hidden units */
  registerMask(CANDIDATE, "CANDIDATE"); /* candidate units */ 

  setCreateNetHook (initNet) ;
  setDestroyNetHook (deinitNet) ;
  setCreateGroupHook (initGroup) ;
  setCreateUnitHook (initUnit) ;
  setDestroyUnitHook (deinitUnit) ;
  setCreateLinkHook (initLink) ;
  setDestroyLinkHook (deinitLink) ;

  /*
   * This lets us show either the normal or candidate training 
   * minimize record in the Learning Methods display.
   */
  getMinimizeRecord = getCurrentNetMinimize ;

  /* Perform initialization of the simulator */
  IStandardInit(&argc, argv);

  /* Enter loop that reads commands and handles graphics */
  ICommandLoop(stdin, stdout, NULL);

  return 0 ;
}


/*********************************************************************
 *	Name:		getCurrentNetMinimize
 *	Description:	return the minimize record of the currentNet
 *	Parameters:	NONE
 *	Return Value:
 *	  static Minimize	getCurrentNetMinimize - ibid
 *********************************************************************/
static Minimize	getCurrentNetMinimize() 
{
  if (currentNet == NULL)
    return NULL ;

  if (MshowCandidateMz(currentNet)) {
    if (McandidateMz(currentNet) == NULL)
      McandidateMz(currentNet) = initMinimize(NULL, 0);
  } else {
    if (currentNet->mz == NULL)
      currentNet->mz 	       = initMinimize(NULL, 0);
  }

  syncValues(currentNet, VectorFromWeights) ;

  return (MshowCandidateMz(currentNet) ?
	  McandidateMz(currentNet) : currentNet->mz) ;
}
/********************************************************************/


/***********************************************************************
*	Name:		initNet 
*	Description:	sets the initial* error calculation procedures for
*			the network as well as allocating the memory
*			for the extension record ( * initial = output unit
*			training).
*	Parameters:	
*		Net	net - the net to act on
*	Return Value:	NONE
\***********************************************************************/
static void	initNet(net)
  Net	net ;
{
  Minimize	mz = initMinimize(NULL, 0);

  mz->userData	= net->mz->userData ;
  mz->getNVars	= net->mz->getNVars ;
  mz->getValues	= net->mz->getValues ;
  mz->setValues	= net->mz->setValues ;
  mz->fEval	= net->mz->fEval ;
  mz->gEval	= net->mz->gEval ;
  mz->fgEval	= net->mz->fgEval ;
  mz->valueName	= net->mz->valueName ;
  mz->incIter	= net->mz->incIter ;

  mz->acceptableFuncMin = -10000; /* stop training candidate units when
				     overall correlation score reaches
				     this value. 			*/

  net->calculateErrorDerivProc  = calculateNetErrorDeriv ;
  net->calculateErrorProc       = calculateNetError ;
  net->gradientUpdateProc	= allPhaseNetBack ;
  net->activityUpdateProc	= outputPhaseNetForward ;

  net->extension = (NetExtension)calloc(1, sizeof(NetExtensionRec)) ;

  McandidateMz(net)	= mz ;
  MshowCandidateMz(net)	= FALSE ;
  MtrainingOutputs(net) = TRUE ;

  MweightCost(net)	  = 0.0;
  MzeroErrorRadius(net)   = 0.0;

  /* maximum number of hidden units */
  MmaxCC_HiddenUnits(net) = 20;
  /* number of candidate units. Overwritten if saved net loaded in */
  Mcandidates(net)	  = 4;
 /* maximum magnitude of candidate weight when initialized.	*/
  McandWeightInitMag(net) = 0.5;

  /* = 1 : cascade the hidden units (connect each new hidden unit to
     all previous hidden units.
     = 0 : do not cascade hidden units */
  Mcascade(net) = 1;

  /* parameters for initial minimization (with no hidden units) */
  MinitialMaxIterations(net)	= 0;
  MinitialMaxFuncEvals(net)	= 0;
  MinitialRepetitionCount(net)	= 0;

  /* sigmoid parameters.  The sigmoid function is calculated according to
        sig(x) = (Max - Min) / (1.0 + exp(-Gain * x)) + Min .
     The sigmoid derivative is calculated according to
	sigderiv(y) = Gain * (y - Min) * (1.0 - (y - Min) / (Max - Min)) .
     For logistic, set Max = 1.0, Min = 0.0, Gain = 1.0.
     For tanh, set Max = 1.0, Min = -1.0, Gain = 2.0.			*/

  MsigmoidMax(net)  = 1.0 ;
  MsigmoidMin(net)  = 0.0 ;    
  MsigmoidGain(net) = 1.0 ;   
  Msigmoid(net)     = createSigmoid(0.0, 0.0, 1.0, 1.0) ;
}
/***********************************************************************/
static void	deinitNet(net)
  Net	net ;
{
  if (net->extension)
    free(net->extension) ;
}
/***********************************************************************/

/***********************************************************************
*	Name:		initGroup 
*	Description:	sets the initial update procedures for the units in
*			each group.  For the cascor network, the update
*			update procedures vary depending on the group.
* 
*	Parameters:	
*		Group	group - the group to set the procedures for
*	Return Value:	NONE
************************************************************************/
static void	initGroup(group)
  Group	group ;
{
  /* set activity update proc */
  group->unitActivityUpdateProc = unitForward ;

  /* set gradient update procs and mean calculation procedures */
  if (group->type & OUTPUT) {
    group->unitGradientUpdateProc = updateOutputLinkDerivs ;
    group->unitOtherUpdateProc	  = findMeanError ;
  } else if (group->type & CANDIDATE) {
    group->unitGradientUpdateProc = updateCandidateLinkDerivs ;
    group->unitOtherUpdateProc    = findMeanActivity ;
  } else {
    group->unitGradientUpdateProc = NULL ;
    group->unitOtherUpdateProc	  = group->unitActivityUpdateProc ;
  }
}
/**********************************************************************/

/***********************************************************************
*	Name:		initUnit 
*	Description:	Allocates the memory for the unit extension record
*	Parameters:	
*		Unit	unit - the unit to act on
*	Return Value:	NONE
************************************************************************/
static void	initUnit(unit)
  Unit	unit ;
{
  unit->extension = (UnitExtension)calloc(1, sizeof(UnitExtensionRec)) ;

  MactivationSum(unit)	= 0.0;	/* sum of candidate's activation	*/
  MactivationAvg(unit)	= 0.0;	/* average of candidate's activation	*/
  MerrorSum(unit)	= 0.0;	/* sum of output unit's errors		*/
  MerrorAvg(unit)	= 0.0;	/* average of output unit's errors	*/
  McorrScore(unit)	= 0.0;	/* candidate unit's correlation score
				   (correlation of candidate's activations
				    with output units' errors)		*/
  MnumExamples(unit)	= 0;	/* number of pattern presentations the
				   unit has seen, just to determine when
				   to compute averages			*/
}
/**********************************************************************/
static void	deinitUnit(unit)
  Unit	unit ;
{
  if (unit->extension)
    free(unit->extension) ;
}
/**********************************************************************/

/***********************************************************************
*	Name:		initLink 
*	Description:	Allocates the memory for the link extension record
*	Parameters:	
*		Link	link - the link to act on
*	Return Value:	NONE
***********************************************************************/
static void	initLink(link)
  Link	link ;
{
  link->extension = (LinkExtension)calloc(1, sizeof(LinkExtensionRec)) ;

  /* sign of candidate unit's correlation with output unit's error */
  McorrSign(link) = 0;

 /* a term in the correlation calculation. */
  MpartialCorrScore(link) = 0.0;
}
/**********************************************************************/
static void	deinitLink(link)
  Link	link ;
{
  if (link->extension)
    free(link->extension) ;
}
/**********************************************************************/

/*********************************************************************
 *	Name:		command_ccsave
 *	Description:	command to print out the commands that can be used
 *			to add the cc groups to the original net
 *	Parameters:
 *	  int	tokc - 
 *	  char	**tokv - 
 *	Return Value:
 *	  int	command_ccsave - 
 *********************************************************************/
static void	printUnit	 ARGS((Unit unit, void *data)) ;
static void	printConnections ARGS((Unit unit, void *data)) ;
/**********************************************************************/
int	command_ccsave(tokc, tokv)
  int	tokc ;
  char	**tokv ;
{
  char	*name ;
  FILE	*fp, *tmpFp ;
  Group	candidates, hidden ;

  IUsage("[file]") ;
  if (GiveHelp(tokc)) {
    ISynopsis("print out the commands used to build a cascor network");
    IHelp
      (IHelpArgs,
       "This command is automatically invoked by \"cctrain\" after each output",
       "training phase.  It saves  to  a  file,  the  commands  necessary to",
       "recreate a cascade correlation  network from a base network with  no",
       "hidden units.",
       "SEE ALSO",
       "cctrain, saveWeights",
       NULL) ;
    return 1 ;
  }

  if (currentNet == NULL)
    IErrorAbort("There is no current net.") ;

  /* Parse any command line options */
  name = *tokv ;
  if (tokc == 1) {
    fp = dout ;
  } else if (tokc == 2) {
    fp = IOpenFileOrAbort(tokv[1], "w", NULL) ;
    if (fp == NULL)
      IErrorAbort("Unable to open file %s.", tokv[1]) ;
  } else {
    IErrorAbort(IPrintUsage(name, usage)) ;
  }
  
  /* count the number of units */
  candidates = groupFromName(currentNet, "Candidate");
  hidden     = groupFromName(currentNet, "CC_Hidden");

  if (candidates) {
    fprintf(fp, "addGroup -type CANDIDATE Candidate 0\n") ;
    netForAllUnits(currentNet, CANDIDATE, printUnit, (void *)fp) ;
  }
  if (hidden)
    netForAllUnits(currentNet, CC_HIDDEN, printUnit, (void *)fp) ;

  if (candidates)
    netForAllUnits(currentNet, CANDIDATE, printConnections, (void *)fp) ;
  if (hidden)
    netForAllUnits(currentNet, CC_HIDDEN, printConnections, (void *)fp) ;

  tmpFp = dout ;
  dout = fp ;
  IDoCommandLine("show -set currentNet.extension") ;
  dout = tmpFp ;
  
  fprintf(fp, "loadWeights\n") ;
  tmpFp = dout ;
  dout = fp ;
  IDoCommandLine("saveWeights -binary") ;
  dout = tmpFp ;
  
  
  if (fp != dout)
    ICloseFile(fp, FALSE) ;

  return 1 ;
}
/********************************************************************/
static void	printUnit(unit, data)
  Unit		unit ;
  void		*data ;
{
  FILE		*fp = (FILE *)data ;
  fprintf(fp, "addUnit \"%s\" \"%s\"\n", unit->name, unit->group->name) ;
  fprintf(fp, "disconnectUnits \"Bias\" \"%s\"\n", unit->name) ;
}
/********************************************************************/
static void	printConnections(unit, data)
  Unit		unit ;
  void		*data ;
{
  FILE		*fp = (FILE *)data ;
  unsigned int	idx, numLinks ;
  Link		*link ;

  numLinks = unit->numIncoming ;
  link	   = unit->incomingLink ;
  for (idx = 0 ; idx < numLinks ; ++idx) {
    fprintf(fp, "connectUnits \"%s\" \"%s\"\n",
	    link[idx]->preUnit->name, unit->name) ;
    if (link[idx]->type & FROZEN)
      fprintf(fp, "freezeLink \"%s\"\n", link[idx]->name) ;
  }

  numLinks = unit->numOutgoing ;
  link	   = unit->outgoingLink ;
  for (idx = 0 ; idx < numLinks ; ++idx) {
    if (!(link[idx]->postUnit->group->type & (CANDIDATE | CC_HIDDEN))) {
      fprintf(fp, "connectUnits \"%s\" \"%s\"\n", 
	      unit->name, link[idx]->postUnit->name) ;
      if (link[idx]->type & FROZEN)
	fprintf(fp, "freezeLink \"%s\"\n", link[idx]->name) ;
    }
  }
}
/********************************************************************/

/***********************************************************************
 *	Name:		compare
 *	Description:	compares to pointers to Groups and figures out
 *			which one comes first in groupArray
 *	Parameters:	the pointers to the group
 *	Return Value:	-1, 0, 1 depending on which comes first.
 ***********************************************************************/
static int	compare(p1, p2)
  const void	*p1 ;
  const void	*p2 ;
{
  Group g1 = *(Group *)p1 ;
  Group g2 = *(Group *)p2 ;
  int	returnVal ;

  if (g1->type & OUTPUT) 
    returnVal = 4 ;
  else if (g1->type & CANDIDATE) 
    returnVal = 3 ;
  else if (g1->type & CC_HIDDEN) 
    returnVal = 2 ;
  else if (g1->type & INPUT) 
    returnVal = 1 ;
  else
    returnVal = 0 ;

  if (g2->type & OUTPUT) 
    returnVal -= 4 ;
  else if (g2->type & CANDIDATE) 
    returnVal -= 3 ;
  else if (g2->type & CC_HIDDEN) 
    returnVal -= 2 ;
  else if (g2->type & INPUT) 
    returnVal -= 1 ;
  else
    returnVal  = 0 ;

  return returnVal ;
}
/**********************************************************************/


/*********************************************************************
 *	Name:		addHiddenUnit
 *	Description:	adds a hidden unit to the hidden layer
 *	Parameters:
 *	  Net		net - the network
 *	  char		*name - name of hidden group
 *	  Unit		winner - the winning candidate, used as
 *				a template for the hidden unit
 *	Return Value:
 *	  static void	addHiddenUnit - NONE
 *********************************************************************/
static int	addHiddenUnit(net, name, winner)
  Net		net ;
  char		*name ;
  Unit		winner ;
{
  Group	group = groupFromName(net, name) ;
  Unit	newUnit ;
  Link	*link ;
  int	numLinks, idx ;
  char	unitName[BUFSIZ] ;

  sprintf(unitName, "%s.%d", group->name, group->numUnits);
  newUnit = createUnit(unitName, group);
  connectUnits(unitFromName(net, "Bias"), newUnit, NULL);

  /* connect inputs to new unit */
  netForAllUnits(net, INPUT, connectTo, (void *)newUnit) ;

  /* connect existing hidden units to new unit IFF cascade flag set */
  if (Mcascade(net))
    groupForAllUnits(group, connectTo, (void *)newUnit) ;

  /* connect new unit to outputs */
  netForAllUnits(net, OUTPUT, connectFrom, (void *)newUnit) ;

  /* give the new cc_hidden unit the same weights as the winning candidate */
  link	   = newUnit->incomingLink ;
  numLinks = newUnit->numIncoming ;
  if (numLinks != winner->numIncoming)
    IErrorAbort("Winning cascade unit has wrong number of connections!") ;
  for (idx = 0 ; idx < numLinks ; ++idx)
    linkSetWeight(link[idx], winner->incomingLink[idx]->weight) ;

  /* freeze the incoming, and randomize the outgoing weights */
  freezeLinks   (newUnit, (void *)INCOMING) ;
  randomizeLinks(newUnit, (void *)OUTGOING) ;

  /* connect new unit to candidates IFF cascade flag set */
  if (Mcascade(net))
    netForAllUnits(net, CANDIDATE, connectFrom, (void *)newUnit) ;

  return group->numUnits ;
}
/********************************************************************/

/*********************************************************************
 *	Name:		initCandidateGroup/initHiddenGroup
 *	Description:	initializes the candidate/CC_Hidden group
 *	Parameters:
 *	  Net		net - the net to contain it
 *	  char		*name - the name for the candidate group
 *	Return Value:
 *	  static void	initCandidateGroup - the number of units in 
 *			the group
 *********************************************************************/
static int	initCandidateGroup(net, name)
  Net		net ;
  char		*name ;
{
  Group	group = groupFromName(net, name) ;

  if (group == NULL || group->numUnits == 0) {
    Unit	unit, bias = unitFromName (net, "Bias") ;
    int		idx ;
    char	unitName[BUFSIZ] ;

    if (group)
      destroyGroup(group) ;
    group = createGroup(name, CANDIDATE, net);

    if (group == NULL)
      IErrorAbort("Could not create candidate pool.");

    /* sort the groups */
    qsort(net->group, net->numGroups, sizeof(Group), compare) ;
    for (idx = 0; idx < Mcandidates(net) ; ++idx) {
      sprintf(unitName, "%s.%d", group->name, idx) ;
      unit = createUnit(unitName, group) ;
      if (unit == NULL)
	IErrorAbort("Could not create candidate unit");
      connectUnits(bias, unit, NULL);
      netForAllUnits(net, INPUT | CC_HIDDEN, connectTo,	  (void *)unit) ;
      netForAllUnits(net, OUTPUT,	     connectFrom, (void *)unit) ;
    }
    groupForAllUnits(group, zeroLinks,	 (void *)OUTGOING) ;
    groupForAllUnits(group, freezeLinks, (void *)OUTGOING) ;
  }
  return group->numUnits ;
}
/********************************************************************/
static int	initHiddenGroup(net, name)
  Net		net ;
  char		*name ;
{
  Group	group = groupFromName(net, name) ;

  if (group == NULL || group->numUnits == 0) {
    if (group)
      destroyGroup(group);
    group = createGroup(name, CC_HIDDEN, net);
    qsort(net->group, net->numGroups, sizeof(Group), compare) ;
  }
  return group->numUnits ;
}
/********************************************************************/

/*********************************************************************
 *	Name:		runMinimize
 *	Description:	wrapper for minimize, does all blocking and
 *			unblocking of events, and sets maximums properly.
 *	Parameters:
 *	  Minimize	mz - 
 *	  int		maxIterations - 
 *	  int		maxFuncEvals - 
 *	Return Value:
 *	  static void	runMinimize - 
 *********************************************************************/
static void	runMinimize(mz)
  Minimize	mz ;
{
  mz->nIterations = 0;
  mz->nFuncEvals  = 0;

  unblockDeviceEvents() ;
  blockMiniDisplayDeviceEvents() ;
  minimize(mz, mz->maxFuncEvals, mz->maxIterations) ;
  unblockMiniDisplayDeviceEvents() ;
  blockDeviceEvents() ;
}
/**********************************************************************/
static void	saveNet ARGS((char *baseName)) ;
static void	saveNet(baseName)
  char		*baseName ;
{
  char	command[BUFSIZ] ;
  sprintf(command, "ccsave %s", baseName) ;
  IDoCommandLine(command) ;
}
/**********************************************************************/

/*******************************************************************
 *	Name:		initOutputPhase
 *	Description: 	change back to normal network learning
 *			procedure and unfreeze the output
 *			connections, and freeze the candidate unit
 *			connections
 *	Parameters:
 *	  Net		net - the net to act on
 *	Return Value:
 *	  static void	initOutputPhase - NONE
 *******************************************************************/
static void	initOutputPhase(net)
  Net		net ;
{
  net->calculateErrorProc	 = calculateNetError;
  net->calculateErrorDerivProc   = calculateNetErrorDeriv;
      
  netForAllUnits(net, OUTPUT,    unfreezeLinks, (void *)INCOMING) ;
  netForAllUnits(net, CANDIDATE, freezeLinks,   (void *)INCOMING) ;
  netForAllUnits(net, CANDIDATE, freezeLinks,   (void *)OUTGOING) ;
}
/*******************************************************************
 *	Name:		initCandidatePhase
 *	Description:	change to correlation training, freeze
 *			output links, and unfreeze candidate links.
 *	Parameters:
 *	  Net		net - the net to act on
 *	Return Value:
 *	  static void	initCandidatePhase - NONE
 *******************************************************************/
static void	initCandidatePhase(net)
  Net		net ;
{
  net->calculateErrorDerivProc = calculateNetCorrelationDeriv;
  net->calculateErrorProc      = calculateNetCorrelationWithCost;

  /* disable learning in output units and enable learning in candidates */
  netForAllUnits(net, OUTPUT,	 freezeLinks,    (void *)INCOMING) ;
  netForAllUnits(net, CANDIDATE, unfreezeLinks,  (void *)INCOMING) ;
  netForAllUnits(net, CANDIDATE, randomizeLinks, (void *)INCOMING) ;
}
/******************************************************************/

/***********************************************************************
*	Name:		command_cctrain
*	Description:	train the cascade-correlation network
*			This command MUST be used to train the cascade-
*			correlation network because of the different
*			phases of learning that take place in the
*			cascor algorithm.  Issuing a "train" or
*			"minimize" command will cause the network to
*			train its output weights once and then stop.
*	Parameters: 
*		int	tokc    - the number of command line tokens
*		char	*tokv[] - the vector of tokens
*	Return Value:	
*		int	command_cctrain - 0 on failure, 1 on success
************************************************************************/
int	command_cctrain(tokc, tokv)
  int	tokc ;
  char	**tokv ;
{
  Net		net	    = currentNet ;
  Minimize	candidateMz = McandidateMz(net) ;
  Unit		winner;
  char		*doLayoutCommandStr, *saveFile;
  int		idx;

  IUsage(" [-l <layoutFile>] <saveFile>");
  if (GiveHelp(tokc)) {
    ISynopsis("Builds and trains a cascade-correlation network with automated cross-validation.");
    IHelp
      (IHelpArgs,
       "This  command  MUST be  used to train a cascade-correlation  network",
       "because of the different phases of learning that take  place  in the",
       "cascor  algorithm.   Issuing  a  `train' or `minimize' command  will",
       "cause  the network to  train only its  output  weights once and then",
       "stop.",
       "",
       "Before using this command, a number of things must already have been",
       "done:",
       "",
       "First, a cascade-correlation network with any number of hidden units",
       "(zero and up) must already be loaded into memory.  Candidate  groups",
       "should never be specified in an input file; these will automatically",
       "be created.   Hidden units *must*  have type CC_HIDDEN and *must* be",
       "named `CC_Hidden'.   For new cascade-correlation networks (no hidden",
       "units), the command `addGroup -type CC_HIDDEN CC_Hidden 0' should be",
       "given.",
       "",
       "Second, the minimization parameters must all be set according to the",
       "way you would like the minimization algorithm to work.   Optionally,",
       "you may set  some minimization  parameters for the  candidate weight",
       "training phase differently than for the output training phase.",
       "",
       "There are  two  minimization  records used  during  training.   When",
       "training the output units, \"currentNet.mz\"  is used.  When  training",
       "the  candidate units, \"currentNet.extension.candidateMz\" is used. By",
       "default,  the  \"Learning  Methods\"  display  shows the  output  unit",
       "minimization parameters.  To  show the candidate  unit  minimization",
       "parameters, set the  field \"currentNet.extension.showCandidateMz\" to",
       "1, then refresh the display.",
       "",
       "Also, a few parameters used when training the network with no hidden",
       "units  may be set differently.   These  parameters  just control the",
       "length  of training  time (you  might want to set the no-hidden-unit",
       "training time slightly longer).  They  are part of the net extension",
       "record and are  labelled `initial...'.  Failing to set any  of these",
       "parameters  will make them  default  to  the  parameters  used  when",
       "training the output units.",
       "",
       "A <saveFile> must be supplied.   After each output unit training",
       "phase, the commands to build the  current cascaded  network  will be",
       "saved there.  This allows a network to be rebuilt, and further built",
       "upon at a later time.  To continue from a saved state you must first",
       "build  the  network  as it  was  before training, then  read  in the",
       "<saveFile>.",
       "",
       "The  <layoutFile>  is  optional.   If one  is given,  the  command",
       "`doLayout <layoutFile>'  will automatically be issued every time  a",
       "new  hidden unit is installed, so that the displays will reflect the",
       "growth of  the  network.   ",
       "EXAMPLE",
       "cctrain -l two-spirals.layout two-spirals.net",
       "SEE ALSO",
       "ccsave", 
       NULL) ;
    return 1 ;
  }

  if (net == NULL)
    IErrorAbort("There is no current net.");

  if (net->trainingExampleSet == NULL)
    IErrorAbort("Please load in a training example set.");

  /* Parse command line */
  if (tokc == 2) {
    saveFile = strdup(tokv[1]) ;
    doLayoutCommandStr = NULL ;
  } else if (tokc == 4 && strcmp(tokv[1], "-l") == 0) {
    saveFile = strdup(tokv[3]) ;
    doLayoutCommandStr = (char *)malloc((11 + strlen(tokv[2]))*sizeof(char)) ;
    sprintf(doLayoutCommandStr,"doLayout %s", tokv[2]);
  } else {
    IErrorAbort(IPrintUsage(tokv[0], usage)) ;
  }

  MhiddenUnits(net) = initHiddenGroup   (net, "CC_Hidden") ;
  Mcandidates(net)  = initCandidateGroup(net, "Candidate") ;

  /* train the output units for the first time, if no hidden units yet */
  if (MhiddenUnits(net) == 0) {
    /* save off some minimization parameters */
    Real oldMaxIterations	= net->mz->maxIterations;
    Real oldMaxFuncEvals	= net->mz->maxFuncEvals;
    Real oldRepetitionCount	= net->mz->repetitionCount;

    if (MinitialMaxIterations(net) == 0)
      MinitialMaxIterations(net)   = oldMaxIterations;
    if (MinitialMaxFuncEvals(net) == 0)
      MinitialMaxFuncEvals(net)	   = oldMaxFuncEvals;
    if (MinitialRepetitionCount(net) == 0)
      MinitialRepetitionCount(net) = oldRepetitionCount;
 
    fprintf(dout,"\nThere are currently no hidden units.\n\n");
    fprintf(dout, "Training output units...\n");

    net->mz->repetitionCount = MinitialRepetitionCount(net);
    net->mz->maxFuncEvals    = MinitialMaxFuncEvals(net) ;
    net->mz->maxIterations   = MinitialMaxIterations(net) ;

    runMinimize(net->mz) ;
    IDoTrace(&afterOutputPhase) ;

    net->mz->maxIterations   = oldMaxIterations;
    net->mz->maxFuncEvals    = oldMaxFuncEvals;
    net->mz->repetitionCount = oldRepetitionCount;
    
    if (doLayoutCommandStr)
      IDoCommandLine(doLayoutCommandStr);

    if (MZ_GOOD_STOP(net->mz))	/* acceptable output error */
      return 1;
    else if (MZ_BAD_STOP(net->mz)) /* interrupt or system error */
      return 0;
    else			/* automatically save current net */
      saveNet(saveFile) ;
  }				/* end if */

  /* keep training the network until we have an acceptable output error,
     or until network contains maximum number of hidden units		*/

  while(MhiddenUnits(net) < MmaxCC_HiddenUnits(net)) {

    /* replace the error calculation procedures with the correlation
       calculation ones					*/
    initCandidatePhase(net) ;

    /* activity update procedures set within
     * "CalculateNetCorrelation(Deriv)" train the candidate units	*/
    fprintf(dout, "Training candidate units...\n");
    if (net->batchSize == 0)
      net->batchSize = net->trainingExampleSet->numExamples;
    runMinimize(candidateMz) ;
    IDoTrace(&afterCandidatePhase) ;

    if (MZ_BAD_STOP(candidateMz)) { /* interrupt or system error */
      /* make sure we exit in a sensible state */
      initOutputPhase(net) ;
      return 0;
    }

    /* select winning candidate - after electCandidate called, "winner"
       will point to it.					*/
    calculateNetCorrelation(net, net->trainingExampleSet) ;
    winner = NULL;
    netForAllUnits(currentNet, CANDIDATE, electCandidate, (void *)&winner);
    MhiddenUnits(net) = addHiddenUnit(net, "CC_Hidden", winner) ;

    if (doLayoutCommandStr)
      IDoCommandLine(doLayoutCommandStr);

    /* change back to normal the network learning procedure, with proper
     * connections frozen, then train the outputs again	*/
    initOutputPhase(net) ;

    fprintf(dout, "\nThere %s currently %d hidden unit%s.\n\n", 
	    MhiddenUnits(net) == 1 ? "is" : "are",MhiddenUnits(net),
	    MhiddenUnits(net) == 1 ? "" : "s") ;
    fprintf(dout, "Training output units...\n");
    runMinimize(net->mz) ;
    IDoTrace(&afterOutputPhase) ;

    if (doLayoutCommandStr)
      IDoCommandLine(doLayoutCommandStr);

    if (MZ_GOOD_STOP(net->mz))	/* acceptable output error */
      return 1;
    else if (MZ_BAD_STOP(net->mz)) /* interrupt or system error */
      return 0;
    else			/* automatically save current net */
      saveNet(saveFile) ;
  }				/* end while */

  if (doLayoutCommandStr)
    free(doLayoutCommandStr);
  if (saveFile)
    free(saveFile);
  
  return 1;
}				/* end command_cctrain */

/***********************************************************************
 *	Name:		allPhaseNetBack
 *	Description:	procedure to call gradient functions for groups
 *			in proper order all phases. It only does
 *			CANDIDATE and OUTPUT.
 *	Parameters:
 *		Net	net - the current network
 *	Return Value:
 *		NONE
 ************************************************************************/
static void	groupBack ARGS((Group, void *)) ;
static void	groupBack(group, data)
  Group		group ;
  void		*data ;
{
  MupdateGroupGradients(group) ;
}
/***********************************************************************/
static Proc	allPhaseNetBack(net)
  Net	net;
{
  netForAllGroupsBack(net, CANDIDATE | OUTPUT, groupBack, NULL) ;
}
/***********************************************************************/

/***********************************************************************
 *	Name:		outputPhaseNetForward/candidatePhaseNetForward
 *	Description:	procedure to call activation functions for groups
 *			in proper order for each training phase.
 *			outputPhaseNetForward    - skips the CANDIDATE group
 *			candidatePhaseNetForward - doesn't skip it
 *	Parameters:
 *		Net	net - the current network
 *	Return Value:
 *		NONE
 ************************************************************************/
static void	groupForward ARGS((Group, void *)) ;
static void	groupForward(group, data)
  Group		group ;
  void		*data ;
{
  MupdateGroupActivities(group) ;
}
/***********************************************************************/
static void	outputPhaseNetForward(net)
  Net	net;
{
  netForAllOtherGroups(net, BIAS | INPUT | CANDIDATE, groupForward, NULL) ;
}
/***********************************************************************/
static void	candidatePhaseNetForward(net)
  Net	net;
{
  netForAllOtherGroups(net, BIAS | INPUT, groupForward, NULL) ;
}
/***********************************************************************/


/***********************************************************************
 *	Name:		calculateNetError
 *	Description:	normal error calculation procedure for cascor net.
 *			This procedure is identical to the 
 *			calculateNetError procedure in bp.c
 *			It processes 'MbatchSize(net)' examples
 *	Parameters:	
 *		Net		net        - the net to use
 *		ExampleSet	exampleSet - the examples to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateNetError(net, exampleSet)
  Net		net ;
  ExampleSet	exampleSet ;
{
  int		numExamples ;

  MtrainingOutputs(net)	  = TRUE ;
  net->activityUpdateProc = outputPhaseNetForward ;

  net->error = 0.0 ;
  for (numExamples = 0 ; numExamples < MbatchSize(net) ; ++numExamples) {
    MgetNext(exampleSet) ;
    MupdateNetActivities(net) ;
  }
  if (numExamples <= 0)
    IErrorAbort("calculateNetError: no examples processed") ;

  MevaluateCost(net) ;
}
/***********************************************************************
 *	Name:		calculateNetErrorDeriv
 *	Description:	gradient calculation procedure for cascor net
 *			when output weights are trained.
 *			Identical to "calculateNetErrorDeriv" procedure
 *			in bp.c
 *			It processes 'MbatchSize(net)' examples
 *	Parameters:	
 *		Net		net        - the net to use
 *		ExampleSet	exampleSet - the examples to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateNetErrorDeriv(net, exampleSet)
  Net		net ;
  ExampleSet	exampleSet ;
{
  int		idx, numExamples ;

  MtrainingOutputs(net)	  = TRUE ;
  net->activityUpdateProc = outputPhaseNetForward ;

  /* zero the net error and all derivative fields in the links */
  net->error = 0.0 ;
  for (idx = 0 ; idx < net->numLinks ; ++idx)
    net->links[idx]->deriv = 0.0 ;
    
  /* For each example	- zero the derivative fields in the units
   *			- do a forward pass updating the activities
   *			- do a backward pass updating the derivatives
   */
  for (numExamples = 0 ; numExamples < MbatchSize(net) ; ++numExamples) {
    MgetNext(exampleSet) ;
    netForAllUnits(net, ALL, zeroUnitDerivs, NULL) ;
    MupdateNetActivities(net) ;
    MupdateNetGradients(net) ;
  }

  if (numExamples <= 0)
    IErrorAbort("calculateNetErrorDeriv: no examples processed") ;

  /* update the cost after everything else is done */
  MevaluateCostAndDerivs(net) ;
}


/***********************************************************************
 *	Name:		calculateNetCorrelation
 *	Description:	correlation calculation procedure for cascor net
 *			when candidate units being trained
 *			This procedure just checks the correlation, without
 *			actually updating the link derivatives.
 *			It processes 'MbatchSize(net)' examples
 *	Parameters:	
 *		Net		net - the net to use
 *		ExampleSet	exampleSet - the examples to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateMean ARGS((Unit, void *)) ;
static void	calculateMean(unit, data)
  Unit		unit ;
  void		*data ;
{
  McalculateMean(unit) ;
}
/***********************************************************************/
static void	calculateNetCorrelation(net, exampleSet)
  Net		net ;
  ExampleSet	exampleSet ;
{
  int		numExamples ;

  MSsetScale  (Msigmoid(net), MsigmoidMax(net) - MsigmoidMin(net)) ;
  MSsetSquash (Msigmoid(net), MsigmoidGain(net)) ;
  MSsetYOffset(Msigmoid(net), MsigmoidMin(net)) ;

  MtrainingOutputs(net)	  = FALSE ;
  net->activityUpdateProc = candidatePhaseNetForward ;

  /* compute mean values and covariances */
  net->error = 0.0;
  netForAllUnits (net, CANDIDATE | OUTPUT, zeroSums, NULL);
  for (numExamples = 0; numExamples < MbatchSize(net); ++numExamples) {
    MgetNext(exampleSet);
    MupdateNetActivities(net) ;
    netForAllUnits(net, OUTPUT | CANDIDATE, calculateMean, NULL) ;
  }

  if (numExamples <= 0)
    IErrorAbort("calculateNetCorrelation: no examples processed");
}
/***********************************************************************/
static void	calculateNetCorrelationWithCost(net, exampleSet)
  Net		net ;
  ExampleSet	exampleSet ;
{
  calculateNetCorrelation(net, exampleSet) ;

  /* update the cost */
  MevaluateCost(net) ;
}
/***********************************************************************
 *	Name:		calculateNetCorrelationDeriv
 *	Description:	gradient calculation procedure for cascor net
 *			when candidate units being trained
 *			It processes 'MbatchSize(net)' examples
 *	Parameters:	
 *		Net		net - the net to use
 *		ExampleSet	exampleSet - the examples to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateNetCorrelationDeriv(net, exampleSet)
  Net		net ;
  ExampleSet	exampleSet ;
{
  int		idx, numExamples ;

  /* first compute mean values and correlations */
  /* zero the activation and error sums */
  calculateNetCorrelation(net, exampleSet) ;

  /* NOW compute candidate weight derivatives.  */

  /* zero the derivative fields in the links, first */
  for (idx = 0 ; idx < net->numLinks ; ++idx)
    net->links[idx]->deriv = 0.0 ;

  /* For each example	- zero the derivative fields in the units
   *			- do a forward pass updating the activities
   *			- do a backward pass updating the derivatives
   */
  Mreset(exampleSet);
  for (numExamples = 0 ; numExamples < MbatchSize(net) ; ++numExamples) {
    MgetNext(exampleSet) ;
    netForAllUnits(net, ALL, zeroUnitDerivs, NULL) ;
    MupdateNetActivities(net) ;
    MupdateNetGradients(net) ;
  }

  if (numExamples <= 0)
    IErrorAbort("calculateNetCorrelationDeriv: no examples processed") ;

  /* update the cost after everything else is done */
  MevaluateCostAndDerivs(net) ;
}
/***********************************************************************/


/***********************************************************************
*	Name:		findMeanActivity
*	Description:	Computes a candidate unit's average activation 
*			over the entire training set.  THIS FUNCTION
*			ONLY FOR USE BY CANDIDATE UNITS DURING PRE- 
*			CANDIDATE LINK TRAINING PHASE (ie: averaging phase).
*	Parameters:
*		Unit	unit - the candidate unit of concern
*	Return value:
*		NONE
************************************************************************/
static void	findMeanActivity(unit)
  Unit	unit ;
{
  MactivationSum(unit) += unit->output;
  if (++MnumExamples(unit) == currentNet->batchSize)
    MactivationAvg(unit) = MactivationSum(unit) / MnumExamples(unit) ;
}

/***********************************************************************
*	Name:		findMeanError
*	Description:	Computes an output unit's average error over the
*			entire training set.  THIS FUNCTION ONLY FOR USE 
*			BY OUTPUT UNITS DURING PRE- CANDIDATE LINK
*			TRAINING PHASE (ie: averaging phase).
*	Parameters:
*		Unit	unit - the output unit of concern
*	Return value:
*		NONE
************************************************************************/
static void	findMeanError(unit)
  Unit unit;
{
  Link	*incoming   = unit->incomingLink ;
  int	numIncoming = unit->numIncoming ;
  Real	error;			/* output unit's error */
  int	idx;			/* just a loop counter */
  Real	corrScoreForOutput;	/* correlation between candidate's
				   output and output unit's error */

  error = unitError(unit) ;
  MerrorSum(unit) += error ;
  if (++MnumExamples(unit) == currentNet->batchSize)
    MerrorAvg(unit) = MerrorSum(unit) / MnumExamples(unit) ;

  for (idx = 0; idx < numIncoming; ++idx) {
    Link	link	= incoming[idx];
    Unit	preUnit	= link->preUnit;

    if (preUnit->group->type & CANDIDATE) {
      MpartialCorrScore(link) += error * preUnit->output;
      if (MnumExamples(unit) == currentNet->batchSize) {
	corrScoreForOutput =	  
	  MpartialCorrScore(link) - MactivationAvg(preUnit) * MerrorSum(unit) ;
	McorrSign(link)	     = corrScoreForOutput < 0.0 ? -1 : 1;
	McorrScore(preUnit) += McorrSign(link)*corrScoreForOutput;
	unit->net->error    -= McorrSign(link)*corrScoreForOutput;
      }
    }
  }
}

/***********************************************************************
*	Name:		updateOutputLinkDerivs
*	Description:	Procedure to update an output unit's incoming links'
*			derivatives.  THIS FUNCTION ONLY FOR USE BY OUTPUT
*			UNITS DURING OUTPUT LINK TRAINING PHASE.
*	Parameters:
*		Unit	unit - the output unit with incoming links to update
*	Return value:
*		NONE
************************************************************************/
static Proc	updateOutputLinkDerivs(unit)
  Unit unit;
{
  int idx;
  int numIncoming = unit->numIncoming;
  Link *incoming = unit->incomingLink;

  unit->inputDeriv
    = 2.0*unitError(unit)*MSderivative(Msigmoid(unit->net), unit->totalInput) ;

  for (idx = 0; idx < numIncoming; ++idx) {
    Link	link = incoming[idx];
    link->deriv += unit->inputDeriv * link->preUnit->output;
    /* no error to pass back since this isn't backprop */
  }
}

/***********************************************************************
*	Name:		updateCandidateLinkDerivs
*	Description:	Procedure to update a candidate unit's incoming links'
*			derivatives.  THIS FUNCTION ONLY FOR USE BY CANDIDATE
*			UNITS DURING CANDIDATE LINK TRAINING PHASE.
*	Parameters:
*		Unit	unit - the candidate unit with incoming links to update
*	Return value:
*		NONE
************************************************************************/
static Proc	updateCandidateLinkDerivs(unit)
  Unit unit;
{
  int	numOutgoing = unit->numOutgoing;
  int	numIncoming = unit->numIncoming;
  Link	*incoming  = unit->incomingLink;
  Link	*outgoing  = unit->outgoingLink;
  Real	inputDeriv = MSderivative(Msigmoid(unit->net), unit->totalInput) ;
  int	outidx, inidx ;

  for (outidx = 0; outidx < numOutgoing; ++outidx) {
    Link	outlink		   = outgoing[outidx];
    int		correlationSign	   = McorrSign(outlink);
    Unit	postUnit	   = outlink->postUnit;
    Real	outputUnitError	   = unitError(postUnit);
    Real	avgOutputUnitError = MerrorAvg(postUnit);

    for (inidx = 0; inidx < numIncoming; ++inidx) {
      Link	inlink = incoming[inidx];
      inlink->deriv -= (correlationSign
			* (outputUnitError - avgOutputUnitError)
			* inputDeriv * inlink->preUnit->output) ;
    }
  }
}

/***********************************************************************\
 *	Name:		electCandidate
 *	Description:	a candidate with the highest correlation score
 *			seen so far will "elect" itself the winner by
 *			setting "winner" to point to it.
 *			To use this routine:
 *
 *		winner = NULL;
 *		groupForAllUnits(candGroup,electCandidate,&winner);
 *
 *	Parameters:
 *		Net	net - the network
 *		void 	*data - pointer to the winner
 *	Return Value:
 *		static void electCandidate - NONE
\***********************************************************************/
static void	electCandidate(unit, data)
  Unit		unit;
  void		*data;
{
  Unit		*winner = (Unit *)data ;
  if (*winner == NULL || McorrScore(unit) > McorrScore(*winner))
    *winner = unit;
}
/*******************************THE END!******************************/
