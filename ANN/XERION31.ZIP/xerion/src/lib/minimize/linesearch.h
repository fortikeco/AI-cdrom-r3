
/**********************************************************************
 * $Id: linesearch.h,v 1.2 92/11/30 11:30:49 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/


extern void updateBest ARGS((Minimize, int, Real *));
extern void initBest ARGS((Minimize, Real *));
extern int getBestByD
  ARGS((Minimize, int, Real *, Real *, Real *, Real *,
	double *, double *, double *));
extern int getBestByF
  ARGS((Minimize, int, Real *, Real *, Real *, Real *,
	RealVecFunc, VecProc, Real2VecFunc,
	double *, double *, double *));
extern double fPrecision ARGS((Minimize, double));
extern int funcValueOK ARGS((Minimize, double, double));

extern void plotLineSearch
  ARGS((Minimize, int, Real *, Real *,
	RealVecFunc, VecProc, Real2VecFunc, double));


extern void insertLSData
  ARGS((Minimize, int, double, double, double, int, int));

extern double	machineEpsilon();
extern double	dotProduct ARGS((int, Real *, Real *));
extern Real	vectorLength ARGS((int, Real *));
extern int	sameVector ARGS((int n, Real *x, Real *y)) ;
extern void	copyVector ARGS((int, Real *, Real *));
extern Real	*moveInDirection ARGS((int, Real *, Real *, double, Real *));
