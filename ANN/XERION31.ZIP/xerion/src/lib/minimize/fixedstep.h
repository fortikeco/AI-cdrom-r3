extern int fixedStep
  ARGS((Minimize, int, Real*, Real*, Real*, Real*,
	RealVecFunc, VecProc, Real2VecFunc,
	double, double*, double*, double*));
