
/***********************************************************************
 * $Id: patchlevel.h,v 1.2 93/04/14 10:52:12 drew Exp $
 ***********************************************************************/

#ifndef __xerion_patchlevel_h
#define __xerion_patchlevel_h

#define PATCH_LEVEL 2

#endif


