
/**********************************************************************
 * $Id: traverse.h,v 1.2 92/11/30 11:32:05 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

#ifndef SIM_TRAVERSE_H
#define SIM_TRAVERSE_H

extern void	unitForAllLinks	     ARGS((Unit  unit, Mask  linkMask,
					   LinkDataProc  proc, void  *data)) ;
extern void	unitForAllOtherLinks ARGS((Unit  unit, Mask  linkMask,
					   LinkDataProc  proc, void  *data)) ;

extern void	groupForAllUnits       ARGS((Group  group, UnitDataProc  proc, 
					     void   *data));
extern void	groupForAllUnitsBack   ARGS((Group  group, UnitDataProc  proc, 
					     void  *data));
extern void	groupForAllUnitsRandom ARGS((Group  group, UnitDataProc  proc, 
					     void  *data));


extern void	netForAllGroups       ARGS((Net      net,  Mask   mask, 
					    GroupDataProc proc, void *data)) ;
extern void	netForAllGroupsBack   ARGS((Net      net,  Mask   mask, 
					    GroupDataProc proc, void *data)) ;
extern void	netForAllGroupsRandom ARGS((Net      net,  Mask   mask, 
					    GroupDataProc proc, void *data)) ;
extern void	netForAllUnits        ARGS((Net      net,  Mask   mask,
					    UnitDataProc proc, void *data)) ;
extern void	netForAllUnitsBack    ARGS((Net      net,  Mask   mask,
					    UnitDataProc proc, void *data)) ;
extern void	netForAllUnitsRandom  ARGS((Net      net,  Mask   mask,
					    UnitDataProc proc, void *data)) ;

extern void	netForAllOtherGroups       ARGS((Net      net,  Mask   mask, 
					    GroupDataProc proc, void *data)) ;
extern void	netForAllOtherGroupsBack   ARGS((Net      net,  Mask   mask, 
					    GroupDataProc proc, void *data)) ;
extern void	netForAllOtherGroupsRandom ARGS((Net      net,  Mask   mask, 
					    GroupDataProc proc, void *data)) ;
extern void	netForAllOtherUnits        ARGS((Net      net,  Mask   mask,
					    UnitDataProc proc, void *data)) ;
extern void	netForAllOtherUnitsBack    ARGS((Net      net,  Mask   mask,
					    UnitDataProc proc, void *data)) ;
extern void	netForAllOtherUnitsRandom  ARGS((Net      net,  Mask   mask,
					    UnitDataProc proc, void *data)) ;

#endif
