
/***********************************************************************
 *	This is a dummy file that can be compiled if you do not have
 *	the necessary libraries to compile the X routines.
 *	COMPILE EITHER THIS FILE OR ALL THE OTHERS IN THIS DIRECTORY.
 *	NOT BOTH.
 ***********************************************************************/

/***********************************************************************
 *	Name:		dummy
 *	Description:	just a dummy routine that returns 0. No need to
 *			call it, it just gives the compiler and archiver
 *			something to deal with.
 *	Parameters:	NONE
 *	Return Value:	0
 ***********************************************************************/
int	dummy() {
  return 0 ;
}
/**********************************************************************/
