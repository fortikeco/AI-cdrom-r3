#define lines2_width 4
#define lines2_height 4
static char lines2_bits[] = {
   0x02, 0x04, 0x08, 0x01};
