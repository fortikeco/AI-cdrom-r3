#define solid_width 1
#define solid_height 1
static char solid_bits[] = {
   0x01};
