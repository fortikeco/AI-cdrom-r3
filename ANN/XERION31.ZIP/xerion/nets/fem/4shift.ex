
tag:Left Shift
1 0 0 0 0 0 0 1,
1;

tag:Left Shift
0 1 0 0 1 0 0 0,
1;

tag:Right Shift
1 0 0 0 0 1 0 0,
0;

tag:Right Shift
0 0 0 1 1 0 0 0,
0;

tag:Left Shift
0 0 1 0 0 1 0 0,
1;

tag:Right Shift
0 0 1 0 0 0 0 1,
0;

tag:Left Shift
0 0 0 1 0 0 1 0,
1;

tag:Right Shift
0 1 0 0 0 0 1 0,
0;


