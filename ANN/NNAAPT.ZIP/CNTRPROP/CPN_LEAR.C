/***************************************************************/
/*                  FILE CPN_LERN.C                            */
/***************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "cpn_prod.c"

int finished = 0;  /* boolean var for finished training or not */
int *DONE_OUT; /* boolean array for done for output layer or not */

/**************************************************************/
/* Purpose : Trains the hidden layer of the network.          */
/* Algorithm :                                                */
/*         Call prop_to_hidden;                               */
/*         for I varies from 0..no of input nodes loop        */
/*           Calculate change in weight of hidden layer's     */
/*                 Ith node;                                  */
/*           Adjust corresponding weight;                     */
/*         end loop;                                          */
/**************************************************************/
     
learn_input()
{
 int I, J;
 float CONN_WT;
 float Delta;

 prop_to_hidden();
 
 for(I=0; I<TOTAL_INOUT_NODES; I++)
  {
   CPN.HIDDEN_LAYER[WIN_NODE].WT_PTRS[I] =
      CPN.HIDDEN_LAYER[WIN_NODE].WT_PTRS[I] +  alpha *
      (CPN.INPUT_LAYER[I].OUTPUTS - CPN.HIDDEN_LAYER[WIN_NODE].WT_PTRS[I]);
   Delta = CPN.INPUT_LAYER[I].OUTPUTS  - 
              CPN.HIDDEN_LAYER[WIN_NODE].WT_PTRS[I];   
  /*printf("Delta(%d)(%d) : %f \n", I, WIN_NODE, Delta);*/   
   LEARNING_ERROR[PATTERN_NO][I] = Delta;
  }

}
/********************************************************************/
/* Purpose : Trains output layer of the network.                    */
/* Algorithm : Call prop_to_hidden;                                 */
/*           Calculate change in weight for each node in output layer*/
/*           Adjust the weight;                                     */
/********************************************************************/
                  
learn_output()
{

 int I, J;
 float  diff,
        actual_output,
        Target;

 prop_to_hidden();

/* printf("\n\n"); */
 for(I=0; I<TOTAL_INOUT_NODES; I++)
  { 
  Target = FL_OUTPUTS[PATTERN_NO][I];/* get target value for Ith node */
  CPN.OUTPUT_LAYER[I].WT_PTRS[WIN_NODE] =
    CPN.OUTPUT_LAYER[I].WT_PTRS[WIN_NODE] +
    beta * (Target - CPN.OUTPUT_LAYER[I].WT_PTRS[WIN_NODE]);
  diff = (Target - CPN.OUTPUT_LAYER[I].WT_PTRS[WIN_NODE]);
  OUTPUT_ERROR[PATTERN_NO][I] = diff;
 actual_output = CPN.OUTPUT_LAYER[I].WT_PTRS[WIN_NODE];

/*printf( 
   "Target : %2.4f  Actual: %2.4f \n", Target, actual_output);*/

  }

}
/*********************************************************************/
/* Purpose : Checks if hidden layer completed training or not.       */
/* Algorithm : Assign 1 to DONE;                                     */
/*           If for any node is not a winner yet then                */
/*              DONE is false;                                       */
/*********************************************************************/  
test_if_input_learned()
{
 int I, J;
 float Delta,
       Delta_sq,
       RMS_Error;
 extern float sqrt();

 DONE = 1;
 for(I=0; I<NO_OF_HIDDEN_NODES; I++)
   {
    if (WINNER_FOUND[I] == 0)
      DONE = 0;
   }

 TOTAL_LEARNING_ERROR = 0.0;

 for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
  {
   for(J=0; J<TOTAL_INOUT_NODES; J++)
     {
      Delta = LEARNING_ERROR[I][J];
      Delta_sq = Delta * Delta;
      TOTAL_LEARNING_ERROR = TOTAL_LEARNING_ERROR + Delta_sq;
     }
  }

 /*printf("Total Learning error : %f \n", TOTAL_LEARNING_ERROR);*/
  RMS_Error = (sqrt(TOTAL_LEARNING_ERROR)) / (float)NO_OF_INPUT_PATTERNS;
  if (RMS_Error < 0.05)
    Learned = 1;
  else
    Learned = 0;
  
  printf("\nRMS Error : %f \n ", RMS_Error); 

}

/***********************************************************/
/* Purpose : Checks if the output layer is completely      */
/*           trained or not.                               */
/* Algorithm : Get difference between actual output and    */
/*               desired output;                           */
/*             if difference is greater than error limit   */
/*                then training is not complete;           */
/***********************************************************/
 
test_if_output_learned()

{
 int I, J, T;
 float actual_output,
       Target,
       diff,
       diff_sq,
       RMS_Error2;
 int err = 0;
 float error_limit = 0.01;
 extern float sqrt();

 TOTAL_OUTPUT_ERROR = 0.0;
 for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
  {
   for (J=0; J<NO_OF_OUTPUT_NODES; J++)
   {
     diff = OUTPUT_ERROR[I][J]; 
     diff_sq = diff * diff;
     TOTAL_OUTPUT_ERROR = TOTAL_OUTPUT_ERROR + diff_sq; 
   }
  }

  RMS_Error2 = (sqrt(TOTAL_OUTPUT_ERROR)) / (float) NO_OF_INPUT_PATTERNS;
  printf("RMS Error2 : %f \n ", RMS_Error2); 
  if (RMS_Error2 < 0.05)
    finished = 1;
  else
    finished = 0; 
 }

 /*********************************************************/
/* Purpose : Contains all procedure calls to train the    */
/*            network.                                    */
/* Algorithm : Open output file;                          */
/*             Call read_cpn_size;                        */
/*              Call build_network;                       */
/*              Call init_wts;                            */
/*              Call read_inputs;                         */
/*              Assign 0 to DONE;                         */
/*              while (DONE is false) loop                */
/*               for all the input patterns               */
/*                 set inputs to input layer;             */
/*                 Call learn_inputs;                     */
/*               end for                                  */
/*               Call test_if_input_learned;              */
/*              end while;                                */
/*             Assign DONE to zero;                       */
/*             Assign winner_found array to false;        */
/*             while DONE is false loop                   */
/*               for all input patterns loop              */
/*                 Call set_inputs;                       */
/*                 Call learn_output;                     */
/*                 Call test_if_output_learned for Ith    */
/*                      pattern;                          */             
/*               end for loop;                            */
/*             end while loop;                            */
/*             If DONE is true for all patterns then      */
/*                finished is true;                       */
/*             Close output file;                         */
/**********************************************************/  


train_network()
{
 char file_name[80];
 int I;
 int P =0;

 if ((outfile = fopen("learn_out.out", "w"))==NULL)
   {
    printf("Cannot open the output file for training results. \n ");
    exit(1);
   }
   DONE_OUT = (int *) calloc(NO_OF_INPUT_PATTERNS, sizeof(int));
   for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
      DONE_OUT[I] = 0;

   read_CPN_size();
   build_network();
   read_inputs();
   init_wts();
   normalize_input();
   create_arrays();

   while (Learned==0)
    {
     DONE = 0;
     init_win_array();
     for(PATTERN_NO=0; PATTERN_NO<NO_OF_INPUT_PATTERNS; PATTERN_NO++)
      { 
       set_inputs();
       learn_input();
      }
      test_if_input_learned();
    }

   DONE = 0;
   init_win_array(); 
   printf("Finished training hidden layer\n");
   printf("********************************************\n");
   while (finished==0)
    {
     init_win_array();
     for(PATTERN_NO=0; PATTERN_NO<NO_OF_INPUT_PATTERNS; PATTERN_NO++)
      {
       set_inputs();
       learn_output();
      }
       test_if_output_learned();
       
       P++;
       printf("\nNo of Iterations  : %d \n", P); 
      
    }
  print_outputs();
}

 /******************************************************************/
 /* Purpose : Quits the program.                                   */
/*  Algorithm : Exit;                                              */
 
quit()
 {
  printf(" END OF PROGRAM \n ");
  close(outfile);
  exit(0); 
 }

