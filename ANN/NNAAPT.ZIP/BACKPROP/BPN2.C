/*********************************************************/
/*                 FILE : BPN2.C                         */
/*********************************************************/

/* Purpose : This file contains procedures which will    */
/*           performs error propagating routines.        */
/*                                                       */
/*********************************************************/

#include "bpn1.c"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/**********************************************************/
/* Purpose : Calculates the error on the output layer.    */
/* Algorithm:                                             */
/*           Get no of nodes in output layer;             */
/*           Calculate error using following formula:     */
/*           error = output * (1-output) *                */
/*                            (desired output - output);  */
/*           Move error into corresponding node;          */
/**********************************************************/

compute_output_error()

{
 int I,
     num_nodes;
 float error,
       ACTUAL_OUTPUTS;

 num_nodes = IHO[NO_OF_LAYERS-1];
 for (I=0; I<num_nodes; I++)
  {
   ACTUAL_OUTPUTS = BPN[NO_OF_LAYERS-1].LAYER[I].OUTPUTS;
   error = ACTUAL_OUTPUTS * (1-ACTUAL_OUTPUTS) *
	   (DESIRED[PATTERN_NO][I] - ACTUAL_OUTPUTS);
   BPN[NO_OF_LAYERS-1].LAYER[I].ERRORS = error;
  }
}

/**************************************************************/
/* Purpose : Backpropagates error from upper layer to         */
/*             lower layer.                                   */
/* Algorithm :                                                */
/*           For I in upper layer to lower layer loop         */
/*            For J in no of nodes in lower layer loop        */
/*              assign receiver's error = 0;                  */
/*              for K in no of nodes in current layer loop    */
/*                Get sender's error;                         */
/*                Get current layer's weight;                 */
/*                Multiply them and accumulate in             */
/*                  receiver's error term;                    */
/*               end loop;                                    */
/*               Get lower layer's output;                    */
/*               Calculate error using following formula:     */
/*               error = receiver's error * output *          */
/*                       (1-output);                          */
/*             end loop;                                      */
/*           end loop;                                        */
/**************************************************************/

backpropagate_error()

{ float sender,    /* upper layer's error */
        receiver,  /* lower layer's error */
        conn_wt,
        unit_output;
  int I,J,K;

for (I=NO_OF_LAYERS-1; I>1; I--)
{
 for (J=0; J<IHO[I-1]; J++)
  { receiver = 0.0;
    for (K=0; K<IHO[I]; K++)
     {
      sender = BPN[I].LAYER[K].ERRORS;
      conn_wt = BPN[I].LAYER[K].WT_PTRS[J];
      receiver = receiver + (sender*conn_wt);
     }
    unit_output = BPN[I-1].LAYER[J].OUTPUTS;
    receiver = receiver * unit_output * (1-unit_output);
    BPN[I-1].LAYER[J].ERRORS = receiver;
  }
}
}

/************************************************************/
/* Purpose : Updates all connection weights based on new    */
/*           error values.                                  */
/* Algorithm:                                               */
/*           for I in hidden layer to output layer loop     */
/*             for J in no of nodes in Ith layer loop       */
/*              Get Jth node's error value;                 */
/*              for K in size of wt array loop              */
/*                Get output values ;                       */
/*                Get old weight;                           */
/*                Get last delta;                           */
/*                Calculate new wt using following formula; */
/*                new wt = old wt + (input*eta*error) +     */
/*                         (alpha*last delta);              */
/*                Calculate new last delta value;           */
/*                Move new wt in corresponding node;        */
/*               end loop;                                  */
/*              end loop;                                   */
/*             end loop;                                    */
/************************************************************/

adjust_weights()
{
 int I, J, K;
 float inputs;
 float error;
 float old_wt, new_wt, delta;

 for (I=1; I<NO_OF_LAYERS; I++)
  {
   for (J=0; J<IHO[I]; J++)
   {
    error = BPN[I].LAYER[J].ERRORS;
    for (K=0; K<IHO[I-1]; K++)
      {
       inputs = BPN[I-1].LAYER[K].OUTPUTS;
       old_wt = BPN[I].LAYER[J].WT_PTRS[K];
       delta = BPN[I].LAYER[J].LAST_DELTA[K];
       new_wt = old_wt + (inputs*eta*error) + (alpha*delta);
       BPN[I].LAYER[J].LAST_DELTA[K] = inputs * eta * error;
       BPN[I].LAYER[J].WT_PTRS[K] = new_wt;
      } /* for K */
    } /* for J */
   } /* for I */
}
/*************************************************************/
/* Purpose : Computes RMS error.                             */
/* Algorithm :                                               */
/*           Update pattern no value;                        */
/*           Initialize total error;                         */
/*           Get no of output layer nodes;                   */
/*           Add square of each node's error to total error; */
/*           Calculate RMS error = total error /             */
/*              no of patterns in input set;                 */
/*           If RMS error is less than predefined error limit*/
/*             then assign DONE to TRUE;                     */
/*************************************************************/

compute_RMS_error()

{
 int I, J,
     out_nodes;
 double Sum_error,
       error_sq,
       error;
 int first_RMS_Error = 0;
 extern float sqrt();

 out_nodes = IHO[NO_OF_LAYERS-1];
 for(I=0; I<out_nodes; I++)
   { error = BPN[NO_OF_LAYERS-1].LAYER[I].ERRORS;
     error_sq = error * error;
     total_error = total_error + error_sq;
   }
 if (PATTERN_NO == NO_OF_PATTERNS - 1)
  {
   NO_OF_ITERATIONS++;
   Sum_error = total_error / NO_OF_PATTERNS;
   RMS_error = sqrt(Sum_error);
   if (first_RMS_Error == 0)
     {
      printf(" RMS Error : %f\n", RMS_error);
      first_RMS_Error = 1;
     }
   if (NO_OF_ITERATIONS > 100) 
     {
       printf(" RMS Error : %2.4f\n "  , RMS_error);
       NO_OF_ITERATIONS = 0; }
  total_error = 0.0;
   if (RMS_error <= ERROR_LIMIT)
      DONE = 1;
  }
}
