/**************************************************************/
/*                    FILE BPN3.C                             */
/**************************************************************/
#include <stdio.h>
#include "bpn2.c"

/********************************************************************/
/* Purpose : Contains all procedure calls needed to train the       */
/*           neural network.                                        */
/* Algorithm:                                                       */
/*           Prompt for output file name;                           */
/*           Open output file;                                      */
/*           Call read_values for size of network;                  */
/*           Call build_network;                                    */
/*           Call init_wts to hidden and output layer;              */
/*           Call read_inputs for input patterns;                   */
/*           Initialize pattern no;                                 */
/*           Initialize N ;                                         */
/*           while NOT finished loop                                */
/*             Call set_inputs to apply training input;             */
/*             Call propagate forward to generate an output;        */
/*             Call get_outputs to copy net output values;          */
/*             Call compute_output_error to determine errors;       */
/*             Call compute_RMS_error to get network error;         */
/*             Call back_propagate_error to update error values;    */
/*             Call adjust_weights to modify the network;           */
/*             Call print_contents to print network values;         */
/*             Check if output value is less than error limit       */
/*                finished is true;                                 */
/*            end loop;                                             */
/*            close output file;                                    */
/*            Call save_network_values to save final network wts;   */
/*                                                                  */
/********************************************************************/


train_network()
{

int I = 0;
int Finished = 0;
char s[80];   /* string for file name */
int J = 0;
 
DONE = 0;

printf("\n\n    Enter the output file name : ");
gets(s);

 if ((outfile = fopen(s, "w"))==NULL)
   { printf("Cannot open output file. \n");
     exit(1);
   }
 fprintf(outfile,
          "\n\n          RESULTS OF BACKPROPAGATION NEURAL NETWORK\n\n");

 if ((outfile2 = fopen("train.out", "w"))==NULL)
   { printf("Cannot open output file. \n");
     exit(1); 
   }
 fprintf(outfile2,
          "\n\n          RESULTS OF BACKPROPAGATION NEURAL NETWORK\n\n");
 

 get_parameters();
 get_input_file_names();
 build_network();
 init_wts();
 read_inputs();
 PATTERN_NO = NO_OF_PATTERNS;

 while (Finished == 0)
    {
   set_inputs();
   propagate_forward();
   get_outputs();
   compute_output_error();
   compute_RMS_error();
         
   I++;          /* no of iterations to train */
   if (DONE==1)  /* boolean var - true if error limit has reached */
    { Finished = 1;
      PATTERN_NO = 0;
   /*   for (PATTERN_NO =0; PATTERN_NO<NO_OF_PATTERNS; PATTERN_NO++)
	print_outputs(); */
      close(outfile);
      close(outfile2);
      save_network_values();
    }
   else
    {
     backpropagate_error();
     adjust_weights();
    }
 }
 I = (int) I / NO_OF_PATTERNS;
 printf("Final I : %d\n\n", I);
}
/**********************************************************/
/* Purpose : To test the network in production mode       */
/*           after training.                              */
/* Algorithm:                                             */
/*           Call buildnetwork;                           */
/*           Call read_inputs to get input patterns;      */
/*           Call load_network to get saved weights       */
/*               from traned network;                     */
/*           Call set_inputs to stimulate the network     */
/*               with inputs;                             */
/*           Call propagate_forward to generate an output */
/*           Call get_outputs to get the outputs;         */
/*                                                        */
/**********************************************************/

test_network()

{
 char s[80];   /* string for file name */
 int I;


 printf("\n\n    Enter the output file name : ");
 gets(s);

 if ((outfile = fopen(s, "w"))==NULL)
   { printf("Cannot open output file. \n");
     exit(1);
   }

 fprintf(outfile,
	 " \n\n Output of the Test part of the Program \n\n");

 if ((outfile2 = fopen("test.out", "w"))==NULL)
   { printf("Cannot open output file. \n");
     exit(1);
   }
 
 fprintf(outfile2,
         " \n\n Output of the Test part of the Program \n\n");
 
 get_input_file_names();
 build_network();
 read_inputs();
 init_trained_wts();
 PATTERN_NO = NO_OF_PATTERNS;
 for (I=0; I<NO_OF_PATTERNS; I++)
 {
   set_inputs();
   propagate_forward();
   get_outputs();
   print_outputs();
 }
 close(outfile);
}

/**********************************************************/
/* Purpose : To quit the program.                         */
/* Algorithm : exit;                                      */
/**********************************************************/

quit()
{
 printf("\n\n      END   OF   PROGRAM   \n");
 exit(0);
}

/**********************************************************/
/* Purpose : To save the trained network weight values.   */
/* Algorithm :                                            */
/*           Prompt for the file to save values;          */
/*           Read file name;                              */
/*           Open the file;                               */
/*           Write all weights from each hidden layer     */
/*             and output layer nodes.                    */
/*           Close the file;                              */
/*           Free all allocated memory.                   */
/**********************************************************/

save_network_values()
{

 float wt_value;
 FILE *fp;
 int I, J, K;
 char fl_name[80];

 printf("\n    Enter the file name to save network weights & configuration values : ");
 gets(fl_name);
 if((fp=fopen(fl_name, "w"))==NULL)
   {
    printf("Cannot open save file.\n");
    exit(1);
    }
 
 for(I=1; I<NO_OF_LAYERS; I++)
   {
   for(J=0; J<IHO[I]; J++)
    {
     for(K=0; K<IHO[I-1]; K++)
      {
       /* wt_value = BPN[I].LAYER[J].WT_PTRS[K] ;*/
       fprintf(fp, "%2.4f \n ", BPN[I].LAYER[J].WT_PTRS[K]);
      }
    }
   }
  fclose(fp);

  free(output_array);
  free(INPUTS);
  free(DESIRED);
  for (I=0; I<NO_OF_LAYERS; I++)
    {
     for(J=0; J<IHO[I]; J++)
      {
        free(BPN[I].LAYER[J].WT_PTRS);
        free(BPN[I].LAYER[J].LAST_DELTA);
      }
     free(BPN[I].LAYER);
    }
  free(BPN);
}
/*************************************************************/
