/* Purpose : This file contains procedures which will be     */
/*           used to read network values, build the network, */
/*           initialize the network and propagate the signal */
/*                                                           */
/*************************************************************/

#include "bpn.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


/*****************************************************/
/* Purpose : This procedure reads the input data from */
/*           a text file. The data contains number of */
/*           layers and number of nodes on each layer.*/
/* Algorithm : Open the input file;                   */
/*             Read number of layers;                 */
/*             Print layer info in output file;       */
/*             Read number of nodes for each layer;   */
/*             Print that info in output file;        */
/*             Close input file;                      */
/******************************************************/

 get_parameters()

 {
  char ch[80];

  printf("\n    Enter the Learning Rate Parameter (eta) : ");
  gets(ch);
  eta = atof(ch);
  fprintf(outfile, "\n    The Learning Parameter : %3.2f \n", eta);
  printf("\n    Enter the Momentum Parameter (alpha) : ");
  gets(ch);
  alpha = atof(ch);
  fprintf(outfile, "\n   The Momentum Parameter : %3.2f \n", alpha);
}
/***************************************************************/
get_input_file_names()
{
  FILE *infile;    /* Declaration of an input file */
  char fl_name[80];  /* string for file name */
  char ch[80];
 
  int l1,    /* a variable for number of nodes on a layer */
      I;     /* a loop variable */
 
  printf("\n    Enter the file name to get info of size of BPN : ");
  gets(fl_name);
  fprintf(outfile, "\n\n");

  if ((infile = fopen(fl_name, "r+"))==NULL)
    {
      printf("Cannot open the input file. \n");
      exit(1);
    }
    fscanf(infile, "%d", &NO_OF_LAYERS);
    fprintf(outfile,
       " The BPN has %d layers\n\n", NO_OF_LAYERS);
    IHO = (int *) calloc(NO_OF_LAYERS, sizeof(int));

    for (I=0; I<NO_OF_LAYERS; I++)
       {
	fscanf(infile, "%d", &l1);
        IHO[I] = l1;
	fprintf(outfile, " Layer number %d has %d nodes. \n", I+1,l1);
       }
    fprintf(outfile, "\n\n");
    fclose(infile);

 }

/***********************************************************/
/* Purpose : Builds the neural network structure with the  */
/*           given size and allocates memory for each part */
/*           of structure.                                 */
/* Algorithm: Allocate memory for BPN structure .          */
/*             for I varies from 0 to NO_OF_LAYERS loop    */
/*               Allocate memory for nodesin Ith layer;    */
/*               for J varies from 0 to no_of_nodes loop   */
/*                 Allocate memory for  weight, last delta */
/*                   array in Jth node & Ith layer.        */
/*             Allocate memory for arrays for inputs,      */
/*              outputs, desired outputs.                  */
/***********************************************************/

 build_network()
 {
  int I,J, K, N;          /* loop variables */

  BPN = (struct layer_type *)
        calloc(NO_OF_LAYERS, sizeof(struct layer_type));

  for (I=0; I<NO_OF_LAYERS; I++)
    {
      BPN[I].NO_OF_NODES = IHO[I];
      BPN[I].LAYER = (struct NODE_INFO *)
      calloc(IHO[I], sizeof(struct NODE_INFO));
      for (J=0; J<IHO[I]; J++)
        {
         BPN[I].LAYER[J].WT_PTRS = (float *)
             calloc(IHO[I-1], sizeof(float));
         BPN[I].LAYER[J].LAST_DELTA = (float *)
             calloc(IHO[I-1], sizeof(float));
         }
    }
  
}

/**************************************************************/
/* Purpose : Initializes hidden, output layers' connection    */
/*           weights using file containing random numbers.    */
/* Algorithm: Open input file of random numbers;              */
/*            for I varies from 1 to no of layers loop        */
/*              for J varies from 0 to no of nodes in Ith layer*/
/*                for K varies from 0 to no of nodes in  prev  */
/*                   layer                                     */
/*                  Read weight;                               */
/*                  Assign weight;                             */
/*                  Assign last delta values to 0;             */
/*                end loop;                                    */
/*              end loop;                                      */
/*             end loop;                                       */
/*             close file.                                     */
/***************************************************************/

init_wts()
{

 float weight, wt;
 int I,J,K;
 extern float pow();

 for (I=1; I<NO_OF_LAYERS; I++)
  {
    for (J=0; J<IHO[I]; J++)
    {
     for (K=0; K<IHO[I-1]; K++)
      {
       wt = rand();
       weight = (wt/(0.5 * (pow(2.0, 32.0) - 1.0))) - 0.5;
  
       BPN[I].LAYER[J].WT_PTRS[K] = weight;
       BPN[I].LAYER[J].LAST_DELTA[K] = 0.0;
       } 
     }  
   }
 }

/***************************************************************/
/* Purpose : Reads input training set.                         */
/* Algorithm:                                                  */
/*           Prompt for input file name;                       */
/*           Read the file name;                               */
/*           Open input file;                                  */
/*           Assign number of input nodes;                     */
/*           Read all input values into input array;           */
/*           Close file;                                       */
/***************************************************************/

read_inputs()

{
 int I, J, K, X, Y,
     int_no, 
     desi_no,
     in_nodes;
 float fl_no, fl_no2;
 FILE *inputs_fl, *desi_fl;
 char fl_name[80];
 char s[80];

 printf("\n    Enter the Input Patterns' file name : ");
 gets(fl_name);

 if ((inputs_fl = fopen(fl_name, "r+")) == NULL)
   { printf("Error opening Training set file\n");
     exit(1);
   }
 printf("\n    Enter number of input patterns in the file : ");
 gets(s);
 NO_OF_PATTERNS = atoi(s);

 printf("\n    Enter the Desired Outputs' file name : ");
 gets(fl_name);
 
 if ((desi_fl = fopen(fl_name, "r+")) == NULL)
   { printf("Error opening Desired data set file\n");
     exit(1);
   }

 in_nodes = IHO[0];  /* no of nodes in input layer */

  INPUTS = (float **) calloc(NO_OF_PATTERNS, sizeof(float));

  for(K=0; K<NO_OF_PATTERNS; K++)
    INPUTS[K] = (float *) calloc(IHO[0], sizeof(float));

  DESIRED = (float **) calloc(NO_OF_PATTERNS, sizeof(float));
  for(K=0; K<NO_OF_PATTERNS; K++)
    DESIRED[K] = (float *) calloc(IHO[NO_OF_LAYERS-1], sizeof(float));

  output_array = (float **) calloc(NO_OF_PATTERNS, sizeof(float));
  for(K=0; K<NO_OF_PATTERNS; K++)
    output_array[K] = (float *) calloc(IHO[NO_OF_LAYERS-1], sizeof(float));


 for(I=0; I<NO_OF_PATTERNS; I++)
   {
     for (J=0; J<in_nodes; J++)
     {
      fscanf(inputs_fl, "%d", &int_no);
      fscanf(desi_fl, "%d", &desi_no);
      if (int_no > 0)
        fl_no = 0.9;
      else
        fl_no = 0.1;
      if (desi_no > 0)
         fl_no2 = 0.9;
      else
         fl_no2 = 0.1;

      INPUTS[I][J] = fl_no;
      DESIRED[I][J] = fl_no2;
     }
   }
 fclose(inputs_fl);
 fclose(desi_fl);

}

/***********************************************************/
init_trained_wts()

{
 FILE *wt_file;
 char fl_name[80];
 float weight;     
 int I,J,K;

 printf("\n    Enter the file name which has the Final weights : ");
 gets(fl_name);
 printf("\n");

 if ((wt_file = fopen(fl_name, "r+"))==NULL)
    { printf("Cannot open input file for random numbers. \n");
      exit(1);
    }
 for (I=1; I<NO_OF_LAYERS; I++)
  {
   for (J=0; J<IHO[I]; J++)
    {
     for (K=0; K<IHO[I-1]; K++)
      {  
       fscanf(wt_file, "%f", &weight);
       BPN[I].LAYER[J].WT_PTRS[K] = weight;
       BPN[I].LAYER[J].LAST_DELTA[K] = 0.0;
       } 
     }
   }
   fclose(wt_file);
 }
 /**************************************************************/
 
/***********************************************************/
/* Purpose : Assigns input training values to input layer  */
/*           nodes.                                        */
/* Algorithm:                                              */
/*           Get no of nodes in input layer;               */
/*           Get pattern no;                               */
/*           Assign input values in input nodes from input */
/*             array;                                      */
/***********************************************************/

set_inputs()

{
 int I, no_of_nodes;

 no_of_nodes = IHO[0];
 if (PATTERN_NO < NO_OF_PATTERNS-1)
    PATTERN_NO++;
 else
    PATTERN_NO = 0;

 for(I=0; I<no_of_nodes; I++)
   BPN[0].LAYER[I].OUTPUTS = INPUTS[PATTERN_NO][I];

}

/*********************************************************/
/* Purpose : Performs forward signal propagation for each*/
/*           layer, from current  layer to upper layer.  */
/* Algorithm :                                           */
/*           For I in no of layers loop                  */
/*            for J in no of nodes in upper layer loop   */
/*             Initialize Net value to zero;             */
/*             for K in no of nodes in current layer loop*/
/*               Get weight from upper layer Jth node ;  */
/*               Multiply weight and current layer Kth   */
/*                 node's output;                        */
/*               Accumulate product in Net;              */
/*             end loop;                                 */
/*               Compute propagated output using sigmoid */
/*                  tranfer function;                    */
/*             end loop;                                 */
/*            end loop;                                  */
/*********************************************************/

propagate_forward()
{
 float wt;
 float Net;
 int I, J, K;
 extern float exp();

 for (I=0; I<NO_OF_LAYERS-1; I++)
   {
     for (J=0; J<BPN[I+1].NO_OF_NODES; J++)
     { Net = 0.0;
      for (K=0; K<BPN[I].NO_OF_NODES; K++)
      {
        wt = BPN[I+1].LAYER[J].WT_PTRS[K];
        Net = Net + (wt*BPN[I].LAYER[K].OUTPUTS);
      }
/*     if (I == NO_OF_LAYERS-2)
        BPN[I+1].LAYER[J].OUTPUTS = Net;
     else */
/* Sigmoid function is used for both hidden & output layer */
	BPN[I+1].LAYER[J].OUTPUTS = 1.0 / (1.0 + exp(-Net));

     } /* for J */

  } /* for I */
}
/*************************************************************/
/* Purpose : Copies output values of output layer in array.  */
/* Algorithm :                                               */
/*           for I in no of nodes in output layer loop       */
/*              Assign output value in output array;         */
/*************************************************************/

get_outputs()
{
 int num_nodes = BPN[NO_OF_LAYERS-1].NO_OF_NODES;
 int n = NO_OF_LAYERS-1;
 int I, J;

 for (I=0; I<num_nodes; I++)
   output_array[PATTERN_NO][I] = BPN[n].LAYER[I].OUTPUTS;

}

/*************************************************************/

print_outputs()
{
int I, J, K, num , Input;
float fl_no;
int Out_nodes = IHO[NO_OF_LAYERS-1];
int In_nodes = IHO[0];

 
 J = 1;
  fprintf(outfile2, " Desired Output : \n"); 
  for(I=0; I<Out_nodes; I++)
   {
  
    fl_no = DESIRED[PATTERN_NO][I];
    
    if (fl_no > 0.5)
      Input = 1;
    else
      Input = 0;

    fprintf(outfile, "%d ", Input);
    fprintf(outfile2, "%d ", Input);

    J++;
     if (J > 30)
       {
        fprintf(outfile, "\n");
        fprintf(outfile2, "\n"); 
        J = 1;
       }
 
    }
   fprintf(outfile, "\n\n");
   fprintf(outfile2, "\n\n");

  fprintf(outfile2, " Actual Output : \n");
  J = 1; K = 1;
  for(I=0; I<Out_nodes; I++)
    {
     fprintf(outfile, " %2.4f ", output_array[PATTERN_NO][I]);
     J++;
     if (J > 8)
       {
        fprintf(outfile, "\n");
        J = 1;
       }  
     fl_no = output_array[PATTERN_NO][I];
     if (fl_no > 0.6)
       num = 1;
     else
       {
       if (fl_no < 0.40)
         num = 0;
       else
        num = 5;
        }
     fprintf(outfile2, "%d ", num);
     K++;
     if (K > 30)
       {
        fprintf(outfile2, "\n");
        K = 1;
       } 
     }
  fprintf(outfile, "\n\n\n\n");
  fprintf(outfile2, "\n\n\n\n");
}

/***********************************************************/


