/************************************************************/
/*                      ART1.C                              */
/************************************************************/

/* Purpose : This file contains procedures needed to train  */
/*           the ART1 network.                              */
/************************************************************/
 
#include <stdio.h>
#include <stdlib.h>
#include "art1_ini.c"

/***********************************************************/
/* Purpose : To compute the activation values of the input */
/*           vector and the outputs for the F1 layer.      */
/* Algorithm:Calculate F1 nodes' activations using formula:*/
/*           Ii / 1 + A1(Ii + B1) + C1;                    */
/*           If activation > 0.0 then                      */
/*             Output of F1 layer node is 1.0;             */
/*           else Output is 0.0;                           */
/*                                                         */
/***********************************************************/
   
prop_to_F1()

{
 int I, J;
 float INPUT_VALUE;

 for (I=0; I<F1_NODES; I++)
 {
  /* Convert input into float */
  INPUT_VALUE = (float)INPUTS[PATTERN_NO][I];  

  ART1.F1_LAYER[I].OUTPUTS =
       INPUT_VALUE / (1.0 + A1 * (INPUT_VALUE + B1) +C1);
  
  if (ART1.F1_LAYER[I].OUTPUTS > 0.0)
    ART1.F1_LAYER[I].OUTPUTS = 1.0;
  else
    ART1.F1_LAYER[I].OUTPUTS = 0.0;
  }
/* for(I=0; I<F1_NODES; I++)
  {
   fprintf(outfile, "F1 Layer Outputs : ");
   fprintf(outfile, "  %2.4f \n ", ART1.F1_LAYER[I].OUTPUTS);
  }
   fprintf(outfile, "\n");*/
}

/*******************************************************************/
/* Purpose : To propagate signals from F1 layer to F2 layer.       */
/*           Find winning node in F2 layer.                        */
/* Algorithm :                                                     */
/*       Initialize F2 layer outputs to zero.                      */
/*       for I in no of F2 layer nodes loop                        */
/*         for J in 1..no of F1 layer nodes loop                   */
/*           Compute activation of the Jth node by adding          */
/*            product of F1 layer's output to corresponding weight;*/     
/*         end loop;                                               */
/*         Inhibit the sum;                                        */
/*         Find max of the sum;                                    */
/*       end loop;                                                 */
/*       F2 layer node with the highest sum is the winner;         */ 
/*       Assign winning node's output to 1.0;                      */
/*                                                                 */
/*******************************************************************/
 
prop_to_F2()
 {
  int I, J, F2_WIN_NODE;
  float Sum = 0.0;
  float Largest = -100.0;  /*Initial activation, some small value */

  for(I=0; I<F2_NODES; I++)
    ART1.F2_LAYER[I].OUTPUTS = 0.0;

  for(I=0; I<F2_NODES; I++)
    {
     Sum = 0.0;
     for(J=0; J<F1_NODES; J++)
       {
       Sum = Sum +
	 (ART1.F1_LAYER[J].OUTPUTS * ART1.F2_LAYER[I].WT_PTRS[J]);
       }
     Sum = Sum * ART1.INHIBITED[I];
/*     fprintf(outfile, "Sum : %2.4f ", Sum);*/
     if (Sum > Largest)
      {
       F2_WIN_NODE = I;
       Largest = Sum;
      }
   }
   
   ART1.F2_LAYER[F2_WIN_NODE].OUTPUTS = 1.0;
   F2_WINNER = F2_WIN_NODE;
   for(J=0; J<F2_NODES; J++)
    {
     OUTPUT_VEC[J] = (int)ART1.F2_LAYER[J].OUTPUTS; 
    }
}
/******************************************************************/
/* Purpose : To propagate signals from F2 winner back to F1 layer.*/
/* Algorithm : for I in 1..F1 nodes loop                          */
/*              Get weight from F1 layer's Ith node's weight from */
/*                winning index of wt array;                      */
/*              Get Ith input pattern value;                      */
/*              Compute new activity of the F1 layer' Ith node by */
/*               formula:                                         */
/*                Ii + D1*WTi + C1 / 1 + A1(Ii+D1*WTi) + C1;      */
/*              if new_activity > 0.0 then                        */
/*               F1 node's output = 1.0;                          */
/*              else                                              */
/*               F1 node's output = 0.0;                          */
/******************************************************************/
      
prop_back_to_F1()
{
int I, J;
float NEW_ACTIVITY, WTi;
float INPUT_VALUE;

for(I=0; I<F1_NODES; I++)
 {
  WTi = ART1.F1_LAYER[I].WT_PTRS[F2_WINNER];
  INPUT_VALUE = (float)INPUTS[PATTERN_NO][I];
/*  fprintf(outfile, "WTi : %f and INPUT_VALUE %f \n", WTi, INPUT_VALUE);*/
  NEW_ACTIVITY = (INPUT_VALUE + (D1 * WTi) - B1)
	     / (1.0 + A1 * (INPUT_VALUE + (D1 * WTi)) + C1);
/*  fprintf(outfile, "New_activity : %2.4f \n ", NEW_ACTIVITY); */
  if (NEW_ACTIVITY > 0.0)
    ART1.F1_LAYER[I].OUTPUTS = 1.0;
  else
    ART1.F1_LAYER[I].OUTPUTS = 0.0;
  }
/* fprintf(outfile, "\n");*/
 }

/**********************************************************/
/* Purpose : To compare input vector to activation values */
/*           on F1 layer.                                 */
/* Algorithm :                                            */
/*           Initialize magnitude of input values and     */
/*              magnitude of F1 layer's outputs to zero.  */
/*           Calculate magnitude of input values;         */
/*           Calculate magnitude of F1 outputs;           */
/*           Assign mag of F1 outputs to F1 layer magn    */      
/*           Compare two magnitudes;                      */
/*                                                        */
/**********************************************************/
             
 match_values()

 {
 int I, J;
 float magX, magI;

 magX = 0.0;
 magI = 0.0;

 for(I=0; I<F1_NODES; I++)
  {
   magX = magX + ART1.F1_LAYER[I].OUTPUTS;
   magI = magI + (float)INPUTS[PATTERN_NO][I];
  }
/*  fprintf(outfile, "magX : %f   magI : %f \n", magX, magI);*/
  F1_magnitude = magX;
  match_value = magX / magI;
  
}

/***********************************************************/
/* Purpose : To update weights of F1 layer nodes and F2    */
/*           nodes.                                        */
/* Algorithm :                                             */
/*           Compute F2 layer's connection weight using    */
/*           following formula for each node               */ 
/*           Wt = L / (L-1+F1 layer's magn) * input value  */
/*           Assign weights on F1 layer nodes from winning */
/*           node are equal to input value.                */ 
/*                                                         */
/***********************************************************/

update_wts()
{
 int I, J;

/* fprintf(outfile, "F2 layers wts after update : \n");*/
   for (J=0; J<F1_NODES; J++)
    {
     ART1.F2_LAYER[F2_WINNER].WT_PTRS[J] =
	  (L / (L - 1.0 + F1_magnitude)) * (float)INPUTS[PATTERN_NO][J];
   }
/* for(I=0; I<F2_NODES; I++)
  {
   for(J=0; J<F1_NODES; J++)
    {  fprintf(outfile, " %2.4f ", ART1.F2_LAYER[I].WT_PTRS[J]);
    }
         fprintf(outfile, "\n");
  }
  
 fprintf(outfile, "\n F1 layer wt update : \n");*/
 for(I=0; I<F1_NODES; I++)
   {
       ART1.F1_LAYER[I].WT_PTRS[F2_WINNER] = (float)INPUTS[PATTERN_NO][I];
    }
/*  for (I=0; I<F1_NODES; I++)
   { for(J=0; J<F2_NODES; J++)
       { fprintf(outfile, " %2.4f  ", ART1.F1_LAYER[I].WT_PTRS[J]);
        }
   fprintf(outfile, "\n");
  }
 
  fprintf(outfile, "\n");*/
}
/***************************************************************/
/* Purpose : To train the ART1 network.                        */
/* Algorithm : Open output file for training results;          */
/*           Call read_ART1_size to get size of network;       */
/*           Call build_network;                               */
/*           Call init_wts to initialize network layers with   */
/*           connection weights;                               */
/*           Call read_inputs;                                 */
/*           Assign pattern no to zero;                        */
/*           while pattern no < no of patterns loop            */
/*             Assign DONE to zero;                            */
/*             Assign Inhibited vector values to 1;            */
/*             while not DONE loop                             */
/*               Call prop_to_F1;                              */
/*               Call prop_to_F2;                              */
/*               Call prop_back_to_F1;                         */
/*               Call match_values;                            */
/*               if match_value < RHO then                     */
/*                 Assign Inhibited[winning_node] to 0.0;      */
/*               else                                          */
/*                 DONE is true;                               */
/*               end if;                                       */
/*             end loop;                                       */
/*             Call update_wts;                                */
/*             Increment pattern no;                           */
/*           end loop;                                         */
/*           Print the contents of output vector which is      */
/*            list of winning nodes for each character;        */
/*           close output file;                                */
/***************************************************************/
     
train_network()
{
 int I, J, N;

 outfile = fopen("art1_trn.out", "w");

 read_ART1_size();
 build_network();
 init_wts();
 read_inputs();
 PATTERN_NO = 0;
 
 while (PATTERN_NO < NO_OF_INPUT_PATTERNS)
  {
   DONE = 0;
   for(I=0; I<F2_NODES; I++)
    {
     ART1.INHIBITED[I] = 1.0;
     }

 while (DONE == 0)
  {
   prop_to_F1();
   prop_to_F2();
   prop_back_to_F1();
   match_values();

   if (match_value < RHO)
     {
      ART1.INHIBITED[F2_WINNER] = 0.0; 
     }
   else
     DONE = 1;
  }
 fprintf(outfile, 
   "Output Vector with Winning Node after training pattern no %d\n",
    PATTERN_NO);
 for(I=0; I<F2_NODES; I++)
   {
    fprintf(outfile, "%d" ,OUTPUT_VEC[I]);
   } 
 fprintf(outfile, "\n"); 
 O_VEC[PATTERN_NO].WIN_NODE = F2_WINNER+1;
 
  update_wts();
 PATTERN_NO++;
}
 N=0;
fprintf(outfile, "\n\n       Character List with Winninig Node Number \n\n");
for(I=0; I<F2_NODES; I++)
 {
  fprintf(outfile, " %c ", O_VEC[I].ALPHA_CH);
  fprintf(outfile, " %d ", O_VEC[I].WIN_NODE);
  N++;
  if(N==10)
  {
   fprintf(outfile, "\n");
   N=0;
  }
 }
fprintf(outfile, "\n");  
close(outfile);
}
/*************************************************************/
/* Purpose : To test the network after it is trained.        */
/* Algorithm : Prompt for the input pattern no to be tested; */
/*            Read pattern no;                               */
/*            Call prop_to_F1;                               */
/*            Call prop_to_F2;                               */
/*            Call get_outputs to print result;              */
/*************************************************************/

test_network()
{
 int I, J;
 char ch[80];
 
 printf("\n     Enter the pattern number you want to test : ");
 gets(ch);
 PATTERN_NO = atoi(ch);
 prop_to_F1();
 prop_to_F2();
 get_outputs();

}
/*******************************************************/
/* Purpose : To quit the program.                      */

quit()
{
 printf("   End of Program \n");
 exit(0);
}
/*******************************************************/
 

