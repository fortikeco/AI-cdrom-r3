/*************************************************************/
/*                  FILE ART1MAIN.C                          */
/*************************************************************/
/* Purpose : This is the main program for the ART1 simulator.*/
/*           It displays menu on the screen and the user can */
/*           has an option to chhose from to train the network*/
/*           or to test it or to quit.                       */
/* Algorithm : Clear the screen;                             */
/*             for ever loop                                 */
/*               display the menu;                           */
/*               Prompt for the choice;                      */
/*               Read users choice;                          */
/*               Perform corresponding procedure;            */
/*             end loop;                                     */
/*************************************************************/

#include "art1.c"

char ch[80];
int choice, I;

main()

{
 for(I=0; I<15; I++)
   printf("\n");
 if ((test_fl = fopen("art1_tst.out", "w"))==NULL)
   {
    printf("Cannot open output file for testing. \n");
    exit(1);
   } 
 for(;;)
 {
   printf("                1 : Train the Neural Network.  \n\n");
   printf("                2 : Test the Trained Neural Network. \n\n");
   printf("                3 : Quit. \n\n");

   do
    {
     printf("    Enter your choice between 1 to 3 : ");
     gets(ch);
     choice = atoi(ch);
    }
    while (choice < 1 || choice > 3);

    switch (choice)
    {
      case 1 : train_network();
	       break;
      case 2 : test_network();
	       break;
      case 3 : quit();
	       break;
     }
  }
 close(test_fl);
}

