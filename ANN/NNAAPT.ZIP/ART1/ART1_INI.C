/************************************************************/
/*                      ART1_INIT.C                         */
/************************************************************/
/*                                                          */
/* Purpose : This file contains procedures which will be    */
/*           used to read network values, to build ART1     */
/*           network, to initialize the network with inputs,*/ 
/*           procedure to compute the weights and initialize*/
/*           the network layers with the weights, etc.      */ 
/*                                                          */
/************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "art1.h"


/**************************************************************/
/* Purpose : Reads the input data from a text file. The data  */
/*           contains number of nodes in each layer.          */
/* Algorithm : Prompt for the input file name;                */
/*             Prompt for the parameters;                     */
/*             Read number of nodes for each layer from       */
/*                 input file;                                */
/*             Print no of nodes in each layer to output file;*/
/*             Close input file;                              */
/**************************************************************/

read_ART1_size()

{
 FILE *fp;
 char file_name[80];
 char ch[80];

 printf("\n\n");
 printf(" Enter the file name to get size of ART1 network : ");
 gets(file_name);

 if ((fp = fopen(file_name, "r+"))==NULL)
    {
     printf("Cannot open info file. \n");
     exit(1);
    }
 printf("\n");

 fscanf(fp, "%d", &F1_NODES);
 fscanf(fp, "%d", &F2_NODES);

 fclose(fp);
 fprintf(outfile, "            ** ART1 NEURAL NETWORK ** \n\n");
 fprintf(outfile, "       The F1 layer has %d nodes.\n", F1_NODES);
 fprintf(outfile, "       The F2 Layer has %d nodes.\n", F2_NODES);
 fprintf(outfile, "\n A1 : %2.4f, B1 : %2.4f, C1 : %2.4f, D1 : %2.4f\n", 
            A1, B1, C1, D1);
 fprintf(outfile, "       L : %2.4f,    RHO : %2.4f\n", L, RHO);
 fprintf(outfile, " \n\n");

}

/************************************************************************/
/* Purpose : Builds neural network structure with the given size and    */
/*           allocate memory for each layer and each node of the        */
/*           network.                                                   */
/* Algorithm :                                                          */
/*           Allocate memory for each layer;                            */
/*           Allocate memory for the weight arrays;                     */
/************************************************************************/

build_network()
{

int I, J;

ART1.F1_LAYER = (struct art1_node *)
		  calloc(F1_NODES, sizeof(struct art1_node));
ART1.F2_LAYER = (struct art1_node *)
		   calloc(F2_NODES, sizeof(struct art1_node));
ART1.INHIBITED = (float *) calloc(F2_NODES, sizeof(float));

for(I=0; I<F1_NODES; I++)
  {
   ART1.F1_LAYER[I].WT_PTRS = (float *)
	    calloc(F2_NODES, sizeof(float));
  }
for(J=0; J<F2_NODES; J++)
  {
   ART1.F2_LAYER[J].WT_PTRS = (float *)
	    calloc(F1_NODES, sizeof(float));
  }

}
/*******************************************************************/
/* Purpose : Computes the initial weights for F1, F2 layers. Then  */
/*           assigns these weights to all the nodes.               */      
/* Algorithm: Compute initial weight for F1 layer nodes;           */
/*           Initialize F1 layer nodes with the weight;            */
/*           Compute initial weight for F2 layer nodes;            */
/*           Initialize F2 layer nodes with the computed weight.   */  
/*******************************************************************/

init_wts()
{

float F1_wt,
      F2_wt;
int I, J, K;
float NO_OF_F1_NODES;

 F1_wt = ((B1 - 1.0) / D1) + 0.2;
fprintf(outfile, "F1 layer wt : %f \n", F1_wt);
for(J=0; J<F1_NODES; J++)
  {
   for(K=0; K<F2_NODES; K++)
      {
       ART1.F1_LAYER[J].WT_PTRS[K] = F1_wt;
      }
  }
  NO_OF_F1_NODES = (float)F1_NODES;  /* type conversion */

  F2_wt = (L / (L - 1.0 + NO_OF_F1_NODES)) - 0.1;
 fprintf(outfile, "F2 layer wt : %f \n", F2_wt);
for(J=0; J<F2_NODES; J++)
  {
   for(K=0; K<F1_NODES; K++)
    {
     ART1.F2_LAYER[J].WT_PTRS[K] = F2_wt;
    }
  }
}
/****************************************************************/
/* Purpose : Reads input data from input file and puts it in the*/
/*           input array and desired array.                     */
/* Algorithm:Prompt for the input file name;                    */
/*           Open input file;                                   */
/*           Prompt for the number of patterns in the input data*/
/*           Read number of patterns;                           */
/*           Allocate memory for Input array of size of number  */
/*              of nodes in F1 layer ;                          */
/*           Read input data in input array ;                   */
/****************************************************************/

read_inputs()
{

int I, J, K, N, a_input;
FILE *inputs_fl,
     *alpha_fl;
char file_name[80];
char ch[80];
int a_desired;
char CH;


printf(" Enter the file name for Inputs : ");
gets(file_name);
if ((inputs_fl = fopen(file_name, "r+"))==NULL)
  {
   printf("Cannot open Inputs file. \n");
   exit(1);
  }

printf("\n");
printf(" Enter number Input Patterns : ");
gets(ch);
NO_OF_INPUT_PATTERNS = atoi(ch);

INPUTS = (int *) calloc(NO_OF_INPUT_PATTERNS, sizeof(int));
for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
 {
  INPUTS[I] = (int *)
	    calloc(F1_NODES, sizeof(int));
 }

 for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
  {
   for(J=0; J<F1_NODES; J++)
    {
     fscanf(inputs_fl, "%d", &a_input);
     INPUTS[I][J] = a_input;
    }
  }
  OUTPUT_VEC = (int *) calloc(F2_NODES, sizeof(int));
  O_VEC = (struct out_rec *) calloc(F2_NODES, sizeof(struct out_rec));   
  if ((alpha_fl = fopen("alpha.dat", "r+"))==NULL)
   {
    printf("Cannot open Inputs file. \n");
    exit(1);
   }
  for(I=0; I<F2_NODES; I++)
   {
    CH = fgetc(alpha_fl);
    O_VEC[I].ALPHA_CH = CH;
   }
  close(alpha_fl);
}

/**************************************************************/
/* Purpose : To get and print the result of testing the trained*/
/*           network during testing mode.                      */
/* Algorithm : Assign F2_layer's outputs to output_vec;        */
/*           Print contents of output_vec;                     */
/***************************************************************/
 
get_outputs()
{
 int I, J;
 
for(I=0; I<F2_NODES; I++)
  {
   OUTPUT_VEC[I] = (int)ART1.F2_LAYER[I].OUTPUTS;
  }
fprintf(test_fl, 
     "     The result of the Test for Input Pattern %d : \n\n",
        PATTERN_NO);
for(J=0; J<F2_NODES; J++)
 { 
  fprintf(test_fl, "%d ", OUTPUT_VEC[J]);
 }
 fprintf(test_fl, "\n\n");
}



