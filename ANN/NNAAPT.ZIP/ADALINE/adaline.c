/*****************************************/
/*          ADALINE.C                    */
/*                                       */
/*****************************************/


#include      <stdio.h>
#include      <math.h>
#include      "ada.h"


int			sz;
int			training;
int			multiple_inputs = 0;
int			max_cycles;
float 		acc_error = .0001;
float 		mu = 0.5;
FILE          *input_file;
FILE          *weight_file;
FILE          *save_file;


prod(struct net *net)
{
	float			*input_array;
	int			i, j;
	double			output;
	int			input_count;
	float			temp;

	if (!multiple_inputs)
 		{

		   /* initialize shift register */
		   net->input = (float *)calloc((size_t)sz, sizeof(float) );	
		   if (net->input == NULL)
			  {
			  	printf("unable to allocate net->input\n");
				return;
			  }
         
         /*read in size number of input values*/
	 	   for (i = sz-1; i >= 0; i--)
			  {
			  fscanf(input_file, "%f", &temp);
			  net->input[i] = temp;
			  }
		   input_count = sz;
		   fscanf(input_file, "%f");
		   net->output = get_sum(sz, net);

		   while (input_count <= MAX_INPUTS) 
			{
	   		/* shift input array right and get new value */
				for (i = sz - 1; i > 0; i--)
		   			{
		   				j = i-1;
						net->input[i] = net->input[j];
		   			}
				fscanf(input_file, "%f %f", &temp);
				net->input[0] = temp;
				input_count++;
				net->output = get_sum(sz, net);

				printf("output  %f\n\n", net->output);
	   	} /* end while */

		}  /* end if not multiple inputs */
	
	else
		{
		   /* initialize shift register */
		   net->input = (float *)calloc((size_t)sz, sizeof(float) );	
		   if (net->input == NULL)
			  {
			  	printf("unable to allocate net->input\n");
				return;
			  }

			/* load input vector */
			for (i = 0; i < sz; i++)
			   {
				fscanf(input_file, "%f", &temp);
			   	net->input[i] = temp;
			   }

			net->output = get_sum (sz, net);
			net->output = bin_unit(net->output);

			if (net->output == 1)
			   printf("\n\n\n UNFRIENDLY AIRCRAFT \n\n\n");
			else
			if (net->output == -1) printf("\n\n\n friendly aircraft \n\n\n");
		    else printf("\n\n\ndon't know what happened here\n\n");

			
		}

  fclose(input_file);
	
}

train(struct net *net)
{

	double         **inputs;
	double         **targets;

	float			*input_array;
	int            i, j;
	double			output, error;
	float			target;
	int            input_count;
	float          temp;
	int			image, cycles;
   float          **buff;

	error = 1.0;


		if (!multiple_inputs)
 		{

		   /* initialize shift register */
		   net->input = (float *)calloc((size_t)sz, sizeof(float) );	
		   if (net->input == NULL)
			  {
			  	printf("unable to allocate net->input\n");
				return;
			  }
         
         /*read in size number of input values*/
	 	   for (i = sz-1; i >= 0; i--)
			  {
			  fscanf(input_file, "%f", &temp);
			  net->input[i] = temp;
			  }
		   input_count = sz;
		   fscanf(input_file, "%f", &target);
		   net->output = get_sum(sz, net);
		   error = find_err(net, (double)target);

		   while ( (error > acc_error)  && (input_count <= MAX_INPUTS) )
			{
	   		/* shift input array right and get new value */
				for (i = sz - 1; i > 0; i--)
		   			{
		   				j = i-1;
						net->input[i] = net->input[j];
		   			}
				fscanf(input_file, "%f %f", &temp, &target);
				net->input[0] = temp;
				input_count++;
				net->output = get_sum(sz, net);
				error = find_err(net, (double)target);

				printf("target  %f, output  %f, error  %f, wt1  %f, wt2  %f, wt3  %f\n\n",
				        target, net->output, error, net->weights[0], net->weights[1], net->weights[2]);
	   	} /* end while */

		}  /* end if not multiple inputs */
      else
		   {
		    /* read input stuff into buffer */
			buff = (float **) calloc(4, sizeof(float *) );
		    for	 (i = 0; i < 4; i++)
			   {
			   	buff[i] = (float *)calloc(sz+1, sizeof(float) ); 
			   	for (j = 0; j < sz; j++)
				  {
				  	fscanf(input_file, "%f", &temp);
					buff[i][j] = temp/sz;
				  }	/*  end for j */
				fscanf(input_file, "%f", &temp);
				buff[i][j] = temp;
printf("buff target value = %f\n", buff[i][j]);
			   } /* end for i */
		   	net->input = (float *)calloc(sz, sizeof(float) );
			if (net->input == NULL)
			   {
			   	printf("unable to allocate net->input\n");
				return;
			   }
			image = 0;
			cycles = 0;
			while  ( (error > acc_error)	&& (cycles < max_cycles) )
			   {
			   		
				 for (j = 0; j < sz; j++)
					   {
				   	   	net->input[j] = buff[image][j];
					   }
				 target = buff[image][j]; 
				 net->output = get_sum(sz, net);
			     error = find_err(net, (double)target);
				 printf("target  %f   output  %f   error  %f\n",
				        target, net->output, error);
				 image++;
			     if (image == 4)
					{
						image = 0;
						cycles++;
					}

			   }  /* end while */

		   }  /*  end else */


  fclose(input_file);
}	/* end train */


double find_err(net, target)
struct net    *net;
double		target;
{
	double		error;
   double		sum;
	double		difference;

	sum = net->output;
	difference =  target - sum;
	error =   (difference * difference);
   modify_weights(sz, net, mu, difference);

	return(sqrt(error));
}


double get_random_number()
{
	double    random_number;

	random_number =  (double) ( ( (rand() % 100) / 100.0) );
	return(random_number);
}






double get_sum(sz, net)
int			sz;
struct net	*net;  
{
	double		sum;
	int		i;
	double	    *wgt_ptr;
	float      *npt_ptr;

	wgt_ptr = net->weights;
	npt_ptr = net->input;

	sum = 0.0;
	for (i = 0; i < sz; i++)
		{
		sum += (npt_ptr[i] * wgt_ptr[i]);
		}

	return(sum);
}



int bin_unit(value)
double		value;
{
	int	bin_value;

	if (value >= 0.0) bin_value = 1;
		else bin_value = (-1);
	return(bin_value);
}






void modify_weights(sz, net,  mu, difference)
int			sz;
struct net	*net;   
double		mu;
double		difference;
{
	double		gradient;
   double		*wgt_ptr;
   float     	*npt_ptr;
	int		i;

	wgt_ptr = net->weights;
	npt_ptr = net->input;
	for (i = 0; i < sz; i++)
		{
			net->weights[i] += 2 * mu * difference * net->input[i];
		}
	 
}



int is_it(str1, str2)
char *str1, *str2;
{
	if (strcmp(str1, str2)==0)
		return(1);
	else
		return(0);
}


void  pause(void)
{
	int	ch;

	fflush(stdin);
	while(!kbhit());
	ch = getch();
}



main()
{
	char       choice[5];
	char		err[5];
	char		filename[15];
	int        quit, i, size;
	char       learn_rate[5];
   struct net *net;
	float      temp;

	quit = 0;

while (quit != 1)
{
	printf("1 - Initialize system\n");
	printf("2 - Choose mode\n");
	printf("3 - Load weights from file\n");
	printf("4 - Run\n");
	printf("5 - Save weights to file\n");
	printf("q - Quit\n");
	printf("\n");
	printf("   Your selection: ");

	scanf("%s", choice);

	if (is_it(choice, "1")==1)
		{
			printf("Enter number of inputs: ");
			scanf("%s", choice);
			if (is_it(choice, "1") == 1)
			   {
			   	multiple_inputs = 0;
				printf("Enter number of taps: ");
				scanf("%s", choice);
				sz = atoi(choice);
			   }
			else
			   {
			   	multiple_inputs = 1;
				sz = atoi(choice);
			   }

		   /* initialize net */
		   net = (struct net *)calloc(1, sizeof(struct net) );
		   if (net == NULL)
			  {
			  	printf("unable to allocate net\n");
				return;
			  }

		   /* initialize weights */
			net->weights = (double *)calloc(sz, sizeof(double) );	
		    if (net->weights == NULL)
			   {
			   	printf("Unable to obtain space for weights\n");
				pause();
				return;
			   }
			for (i = 0; i < sz; i++)
			   {
			   	net->weights[i] =  get_random_number();
			   }

		}
	else
	if (is_it(choice, "2")==1)
		{
			printf("Training or Production? (t/p): ");
			scanf("%s", choice);
			if (is_it(choice, "t") == 1)
			   {
			   	training = 1;
				}
			else
				if (is_it(choice, "p") == 1) training = 0;
		}
	else
	if (is_it(choice, "3")== 1)
		{
			printf("Enter name of weight file: ");
			scanf("%s", filename);
			weight_file = fopen(filename, "r");
			if (weight_file == NULL)
			   {
			   	printf("Unable to open file");
				pause();
			   }
			fscanf(weight_file, "%d", &size);
			if (sz != size)
			   {
printf("sz = %d   size = %d\n", sz, size);
			   	printf("weight file incompatible with initialized system");
				pause();
				exit();
			   }
			for (i = 0; i < sz; i++)
			   {
			   	fscanf(weight_file, "%f", &temp);
				net->weights[i] = temp;
			   }
		}
	else
	if (is_it(choice, "4")==1)
		{
			/* get input file name */
			printf("Enter name of input file: ");
		    scanf("%s", filename);
		    input_file = fopen(filename, "r");
			if (input_file == NULL)
			   {
			   	printf("Unable to open file");
				pause();
			   }
			if (training == 1)
			   {
				/* get error criteria  */
				printf("Enter value for acceptable error: ");
		    	scanf("%s", err);
          	acc_error = atof(err);

				/* get mu              */
				printf("Enter value for mu: ");
		    	scanf("%s",	learn_rate);
				mu = atof(learn_rate);

				/* get max cycles      */
				printf("Enter maximum number of cycles: ");
		    	scanf("%d", &max_cycles);

				train(net);
			   }
		   	else prod(net);
		}
	else
	if (is_it(choice, "5")==1)
		{
		     printf("Enter name of file to save to: ");
			 scanf("%s", filename);
			 save_file = fopen(filename, "w");
			 if (save_file == NULL)
				{
					printf("Unable to open file");
					pause();
				}
			 fprintf(save_file,"%d\n", sz);
			 for (i = 0; i < sz; i++)
				{
					fprintf(save_file,"%f\n", net->weights[i]); 
				}
		}
	else
	if(is_it(choice, "q")==1) quit = 1;

} /* end while quit != 1 */



}



