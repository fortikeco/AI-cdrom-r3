
/*  Ada.h  */




#define      MAX_INPUTS        190


double	   get_random_number();
double       get_sum(int, struct net *);
int          bin_unit(double);
double       find_err(struct net *, double);
void 		   modify_weights(int, struct net *, double, double);
void         pause(void);



struct net
{
 int		size;
 float    *input;
 double   *weights;
 double   output;
 double	error;
 float	mu;
 float	acc_err;
};
