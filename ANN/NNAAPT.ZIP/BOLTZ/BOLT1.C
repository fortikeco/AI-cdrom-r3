/*********************************************************/
/*                    FILE : BOLTZMN1.C                  */
/*********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "bolt.h"

read_network_values()

{
 FILE *infile;
 char ch[80];

 Seed = 1;
 printf("\n\n");
 printf("  Enter the number of Visible nodes for the Boltzmann Network : ");
 gets(ch);
 I_NODES = atoi(ch);

 printf("\n\n  Enter the number of Hidden nodes for the Boltzmann Network : ");
 gets(ch);
 H_NODES = atoi(ch);
 TOTAL_NODES = I_NODES + H_NODES;


 printf("\n\n  Enter no of loops : ");
 gets(ch);
 NO_of_LOOPS = atoi(ch);

 fprintf(outfile, "         ***  BOLTZMANN COMPLETION NETWORK  ***\n\n");
 fprintf(outfile, "       The Visible or Input Layer has %d Nodes. \n", I_NODES);
 fprintf(outfile, "       The Hidden Layer has %d Nodes. \n", H_NODES);
 fprintf(outfile, "       Total Nodes In the Network : %d \n\n", TOTAL_NODES);
 fprintf(outfile, "       No of Loops : %d \n\n", NO_of_LOOPS);
 fprintf(outfile, "       Threshold : %2.4f \n\n", LIMIT); 

}

 /********************************************************************/

 build_network()
 {
  int I, J, SZ, passes;
  FILE *infile;
  char fl_name[80];
  double rand_no;
  float temp;
  extern float pow();

  BOLTZMN_NET.NET_LAYER = (struct NODE_TYPE *)
	calloc(TOTAL_NODES, sizeof(struct NODE_TYPE));

  for(I=0; I<TOTAL_NODES; I++)
    {
     BOLTZMN_NET.NET_LAYER[I].WT_PTRS = (float *)
	calloc(TOTAL_NODES, sizeof(float));
    }


  for(I=0; I<TOTAL_NODES; I++)
    {
    for(J=I; J<TOTAL_NODES; J++)
     {
      rand_no = rand();
      rand_no = (rand_no / (0.5 * (pow(2.0, 32.0) - 1.0))  );

      BOLTZMN_NET.NET_LAYER[I].WT_PTRS[J] = rand_no;
      BOLTZMN_NET.NET_LAYER[J].WT_PTRS[I] = rand_no;
     }

    }

 for(I=I_NODES; I<TOTAL_NODES; I++)
    BOLTZMN_NET.NET_LAYER[I].OUTPUTS = (float)(I % 2);

 printf("\n\n  Enter the file name to get Annealing values : ");
 gets(fl_name);
 if ((infile = fopen(fl_name, "r+"))==NULL)
    {
     printf("Cannot open input file for Annealing Values.\n");
     exit(1);
    }
  printf("\n");
  fscanf(infile, "%d", &SZ);
  BOLTZMN_NET.ANNEALING.SIZE_OF_ANNEALING_ARRAY = SZ;
 
  BOLTZMN_NET.ANNEALING.STEP = (struct ANNEAL *)
	calloc(SZ, sizeof(struct ANNEAL));

  for (I=0; I<SZ; I++)
   {
    fscanf(infile, "%f", &temp);
    BOLTZMN_NET.ANNEALING.STEP[I].TEMP = temp;
    fscanf(infile, "%d", &passes);
    BOLTZMN_NET.ANNEALING.STEP[I].PASSES = passes;
   }
   fclose(infile);

  SZ = ((TOTAL_NODES * (TOTAL_NODES - 1)) / 2)  ;
  SIZE_OF_STATS_ARRAY = SZ;

  BOLTZMN_NET.P_PLUS_STAT = (float *)
	calloc(SZ, sizeof(float));
  BOLTZMN_NET.P_MINUS_STAT = (float *)
	calloc(SZ, sizeof(float));
 }

 /*********************************************************/

 read_training_inputs()
 {
 int I, J, input;
 FILE *infile; 
 char ch[80], fl_name[80];
 
 printf("\n  Enter the file name for Training Inputs : ");
 gets(fl_name);
 if ((infile = fopen(fl_name, "r+"))==NULL)
   { printf("Cannot open the Inputs file. \n");
     exit(1);
   }

 printf("\n\n  Enter the number of Training Input patterns : ");
 gets(ch);
 INPUT_PATTERNS = atoi(ch);

 INPUTS = (int **) calloc(INPUT_PATTERNS, sizeof(int));
 for (I=0; I<INPUT_PATTERNS; I++)
      INPUTS[I] = (int *) calloc(I_NODES, sizeof(int));

 for(I=0; I<INPUT_PATTERNS; I++)
    {
     for(J=0; J<I_NODES; J++)
      {
       fscanf(infile, "%d", &input);
       INPUTS[I][J] = input;
       fprintf(outfile, " %d ", INPUTS[I][J]);
      }
      fprintf(outfile, "\n");
    }
 fclose(infile);

 OUTPUT_VEC = (int **) calloc(INPUT_PATTERNS, sizeof(int));
 for(I=0; I<INPUT_PATTERNS; I++)
     OUTPUT_VEC[I] = (int *) calloc(TOTAL_NODES, sizeof(int));
 
}


/**************************************************************/
 
build_test_network()

{
  int I, J, SZ, passes;
  FILE *infile, *wt_fle;
  char fl_name[80];
  float temp, wt;
  extern float pow();
 
 printf("\n\n  Enter the file name to get network values previously saved: ");
 gets(fl_name);
 if ((wt_fle = fopen(fl_name, "r+"))==NULL)
    {
     printf("Cannot open input file for network Values.\n");
     exit(1);
    }
  printf("\n");
 
  fscanf(wt_fle, "%d", &I_NODES);
  fscanf(wt_fle, "%d", &H_NODES);
  fscanf(wt_fle, "%d", &NO_of_LOOPS);
  TOTAL_NODES = I_NODES + H_NODES;
 
  BOLTZMN_NET.NET_LAYER = (struct NODE_TYPE *)
        calloc(TOTAL_NODES, sizeof(struct NODE_TYPE));
 
  for(I=0; I<TOTAL_NODES; I++)
    {
     BOLTZMN_NET.NET_LAYER[I].WT_PTRS = (float *)
        calloc(TOTAL_NODES, sizeof(float));
    }
 
  for(I=0; I<TOTAL_NODES; I++)
    {
    for(J=I; J<TOTAL_NODES; J++)
     {   
      fscanf(wt_fle, "%f", &wt); 
      BOLTZMN_NET.NET_LAYER[I].WT_PTRS[J] = wt;
      BOLTZMN_NET.NET_LAYER[J].WT_PTRS[I] = wt;
     }   
    } 
 for(I=I_NODES; I<TOTAL_NODES; I++)
    BOLTZMN_NET.NET_LAYER[I].OUTPUTS = (float)(I % 2);
 
 printf("\n\n  Enter the file name to get Annealing values : ");
 gets(fl_name);
 if ((infile = fopen(fl_name, "r+"))==NULL)
    {
     printf("Cannot open input file for Annealing Values.\n");
     exit(1);
    }
  printf("\n");
  fscanf(infile, "%d", &SZ);
  BOLTZMN_NET.ANNEALING.SIZE_OF_ANNEALING_ARRAY = SZ;
 
  BOLTZMN_NET.ANNEALING.STEP = (struct ANNEAL *)
        calloc(SZ, sizeof(struct ANNEAL));

  for (I=0; I<SZ; I++)
   {
    fscanf(infile, "%f", &temp);
    BOLTZMN_NET.ANNEALING.STEP[I].TEMP = temp;
    fscanf(infile, "%d", &passes);
    BOLTZMN_NET.ANNEALING.STEP[I].PASSES = passes;
   }
   fclose(infile);
   fclose(wt_fle);

  Test_OUTPUTS = (int *) calloc(TOTAL_NODES, sizeof(int));
}


/********************************************************************/



read_test_inputs()
{
 int I, J, input;
 char fl_name[80];
 char ch[80];
 FILE *infile2;
 
 printf("\n  Enter the file name for  Test Inputs : ");
 gets(fl_name);
 if ((infile2 = fopen(fl_name, "r+"))==NULL)
   { printf("Cannot open the Test Inputs file. \n");
     exit(1);
   }
 

   INPUTS2 = (int **) calloc(INPUT_PATTERNS, sizeof(int));
   for (I=0; I<INPUT_PATTERNS; I++)
     {   
      INPUTS2[I] = (int *) calloc(I_NODES, sizeof(int));
     }   
 
 for(I=0; I<INPUT_PATTERNS; I++)
    {
     for(J=0; J<I_NODES; J++)
      {  
       fscanf(infile2, "%d", &input);
       INPUTS2[I][J] = input;
      }  
    }
  fclose(infile2);

 }

 /***********************************************************/
 init_stat_array()

 {
  int I, SZ;

  SZ = SIZE_OF_STATS_ARRAY;
  for(I=0; I<SZ; I++)
   {
    BOLTZMN_NET.P_PLUS_STAT[I]  = 0.0;
    BOLTZMN_NET.P_MINUS_STAT[I] = 0.0;
   }
 }

/*****************************************************************/

 set_training_inputs()
 {
 
  int I;


  if (PATTERN_NO < INPUT_PATTERNS - 1)
    PATTERN_NO++;
  else
    PATTERN_NO = 0;

     for (I=0; I<I_NODES; I++)
        BOLTZMN_NET.NET_LAYER[I].OUTPUTS = (float)INPUTS[PATTERN_NO][I];
   
 }

/******************************************************************/ 

set_test_inputs()
{
  int I;
  char ch[2];
  char str[80];
 
  ch[1] = '\0';   /*end of string character*/ 
  printf("\n\n Enter a test pattern : ");
  gets(str);
 
  for(I=0; I<I_NODES; I++)
   {  
    ch[0] = str[I]; 
    BOLTZMN_NET.NET_LAYER[I].OUTPUTS = atof(ch);  
   }
 
}

 /***********************************************************/
 get_trained_outputs()
 {
 int I, J;

    J = PATTERN_NO;

   for(I=0; I<TOTAL_NODES; I++)
     {
      OUTPUT_VEC[J][I] = (int)BOLTZMN_NET.NET_LAYER[I].OUTPUTS;
     }
  
 }

/*************************************************************/
 get_test_outputs()
 {
   int I;
 
   for(I=0; I<TOTAL_NODES; I++)
      Test_OUTPUTS[I] = (int)BOLTZMN_NET.NET_LAYER[I].OUTPUTS;
 
 }
 
/**************************************************************/

 print_outputs()
 { 
 int I, J;

  for(J=0; J<INPUT_PATTERNS; J++)
   {
    for(I=0; I<I_NODES; I++)
     {   
      printf("%d", OUTPUT_VEC[J][I]);
     }   
     printf( "\n");
   }  
 }
 
/*************************************************************/

 print_final_wts()

 {
  int I, J, N;
  float wt;

  fprintf(outfile, " FINAL WTS :\n\n");
  for(I=0; I<TOTAL_NODES; I++)
    { N = 1;
      fprintf(outfile, "\n\n");
     for(J=0; J<TOTAL_NODES; J++)
      {
       wt = BOLTZMN_NET.NET_LAYER[I].WT_PTRS[J];
       fprintf(outfile, "%2.4f ", wt);
       N++;
       if (N > 6)
         { N = 1;
           fprintf(outfile, "\n");
         } 
      }
      fprintf(outfile, "\n");
    }
    fprintf(outfile, "\n\n");
 }

/***********************************************************/
 
int rand_gen(Range)
 int Range;

{
 int  Rand_no;
 
   Seed = (Seed*2743 + 5973) % (int)(pow(2.0, 10.0));
   Rand_no = ((Range * Seed) / (int)(pow(2.0, 10.0)));
   return Rand_no;
}
 
 



