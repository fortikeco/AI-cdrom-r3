/*************************************************************/
/*                      FILE : BOLTZMN2.C                    */
/*************************************************************/

#include <stdio.h>
#include <math.h>
#include "bolt1.c"

/************************************************************/
propagate()

{
 int I, J, N,
     threshold,
     first_conn,
     node_no,
     rand_no,
     unclamped_index;
  float net_input,
	th,
	Prob_of_ON;
  extern float exp();
  char ch[80];

  unclamped_index = I_NODES ;
  first_conn = 0;

  for(I=0; I<TOTAL_NODES; I++)
    {
     if (CLAMPED == 1)
      {
/*       rand_no = rand() % (H_NODES); */
        rand_no = rand_gen(H_NODES);
       node_no = rand_no + unclamped_index;
      }
     else
      /* node_no = rand() % (TOTAL_NODES); */
      node_no = rand_gen(TOTAL_NODES);
 
     net_input = 0.0;
     for(J=first_conn; J<TOTAL_NODES; J++)
       {
	net_input = net_input +
	  (BOLTZMN_NET.NET_LAYER[J].OUTPUTS *
	   BOLTZMN_NET.NET_LAYER[node_no].WT_PTRS[J]);
	}

      net_input = net_input -
	 (BOLTZMN_NET.NET_LAYER[node_no].OUTPUTS *
	  BOLTZMN_NET.NET_LAYER[node_no].WT_PTRS[node_no]);

      Prob_of_ON = 1.0 / (1.0 + exp((-net_input) / BOLTZMN_NET.TEMPERATURE));
    fprintf(outfile, "%f ", net_input);      
      th = Prob_of_ON  * 10000.0;
      th = th + 0.5;  /* round up the value */      
      threshold = (int)th;

/*      rand_no = rand() % 10000; */
      rand_no = rand_gen(10000);
    
      if (rand_no <= threshold)
	BOLTZMN_NET.NET_LAYER[node_no].OUTPUTS = 1.0;
      else
	BOLTZMN_NET.NET_LAYER[node_no].OUTPUTS = 0.0;

     /* rand_no = rand(); */      
     } /* for I */
  fprintf(outfile, "\n\n"); 
 }

/***********************************************************/
anneal()
{
 int steps, passes, STEP_NO, I, J;

 steps = BOLTZMN_NET.ANNEALING.SIZE_OF_ANNEALING_ARRAY;
 for(STEP_NO=0; STEP_NO<steps; STEP_NO++)
   {
    passes = BOLTZMN_NET.ANNEALING.STEP[STEP_NO].PASSES;
    BOLTZMN_NET.CURRENT_ANNEAL = STEP_NO;
    BOLTZMN_NET.TEMPERATURE = BOLTZMN_NET.ANNEALING.STEP[STEP_NO].TEMP;

    for(I=0; I<passes; I++)
       propagate();
    }
}

/***********************************************************/
cal_pplus()

{
 int I, TRIALS, SZ;

 TRIALS = INPUT_PATTERNS * NO_of_LOOPS;
 SZ = SIZE_OF_STATS_ARRAY;

 for(I=0; I<SZ; I++)

    BOLTZMN_NET.P_PLUS_STAT[I] =
	 BOLTZMN_NET.P_PLUS_STAT[I] / (float)TRIALS;
}

/************************************************************/
cal_pminus()

{
 int I, TRIALS, SZ;

  TRIALS = INPUT_PATTERNS * NO_of_LOOPS;
  SZ = SIZE_OF_STATS_ARRAY;

  for(I=0; I<SZ; I++)
    BOLTZMN_NET.P_MINUS_STAT[I] =
      BOLTZMN_NET.P_MINUS_STAT[I] / (float)TRIALS;

 }

 /************************************************************/

 update_conn()
 {
  int I, J, Index;
  float Delta_Wt;

  Index = 0;
  for(I=0; I<TOTAL_NODES; I++)
    {
     for(J=I+1; J<TOTAL_NODES; J++)
       {
	Delta_Wt = 0.3 *
	 (BOLTZMN_NET.P_PLUS_STAT[Index] - BOLTZMN_NET.P_MINUS_STAT[Index]);

        BOLTZMN_NET.NET_LAYER[I].WT_PTRS[J] = Delta_Wt + 
              BOLTZMN_NET.NET_LAYER[I].WT_PTRS[J] ;
         BOLTZMN_NET.NET_LAYER[J].WT_PTRS[I] =  Delta_Wt + 
              BOLTZMN_NET.NET_LAYER[J].WT_PTRS[I] ;

	Index++;
       }
     }
 }

 /*************************************************************/

 sum_cooccurrence()
 {

  int I, J, K,
      SZ,
      Connect;

   SZ = SIZE_OF_STATS_ARRAY;


     for(I=0; I<NO_of_LOOPS; I++)
     {
      propagate();
      Connect = 0;

      for(J=0; J<TOTAL_NODES; J++)
	{
	 if (BOLTZMN_NET.NET_LAYER[J].OUTPUTS == 1.0)
	   {
	    for(K=J+1; K<TOTAL_NODES; K++)
	     {
	      if (BOLTZMN_NET.NET_LAYER[K].OUTPUTS == 1.0)
		{
		 if (CLAMPED == 1) 
       
                   BOLTZMN_NET.P_PLUS_STAT[Connect] = 
                     BOLTZMN_NET.P_PLUS_STAT[Connect] + 1;
                 else
                    BOLTZMN_NET.P_MINUS_STAT[Connect] = 
                     BOLTZMN_NET.P_MINUS_STAT[Connect] + 1;

		}
		Connect++;
	      }
	    }
	  else
	    Connect = Connect + ((TOTAL_NODES - 1) - J);
	 } /* for J */
     } /* for I */

 }

 /*************************************************************/

 print_stat_diff()

 {
  int I, SZ;
  float diff;

  SZ = SIZE_OF_STATS_ARRAY;
  for(I=0; I<SZ; I++)
    {
     diff = BOLTZMN_NET.P_PLUS_STAT[I] ;
     fprintf(outfile, "for I : %d PPlus = %f ", I, diff);
     diff = BOLTZMN_NET.P_MINUS_STAT[I];
     fprintf(outfile, " PMinus = %f \n", diff);
    }
 }
