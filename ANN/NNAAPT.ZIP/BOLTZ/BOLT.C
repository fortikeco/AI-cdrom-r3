/*************************************************************/
/*                  FILE BOLTZMN.C                           */
/*************************************************************/
/* Purpose : This is the main program for the Boltzmann      */
/*           network.                                        */
/*           It displays menu on the screen and the user can */
/*           has an option to choose from to train the network*/
/*           or to test it or to quit.                       */
/* Algorithm : Clear the screen;                             */
/*             for ever loop                                 */
/*               display the menu;                           */
/*               Prompt for the choice;                      */
/*               Read users choice;                          */
/*               Perform corresponding procedure;            */
/*             end loop;                                     */
/*************************************************************/

#include "bolt3.c"
#include <stdio.h>

char ch[80];
int choice, I;

main()

{

 for(I=0; I<20; I++)
   printf("\n");

 for(;;)
 {
  printf("\n\n\n\n\n");
   printf("                1 : Build the Boltzmann Completion Network.\n\n");
   printf("                2 : Train the Boltzmann Completion Network.\n\n");
   printf("                3 : Build the Trained Network.\n\n");
   printf("                4 : Test the Trained Network. \n\n");
   printf("                5 : Quit. \n\n");

   do
    {
     printf("    Enter your choice between 1 to 4 : ");
     gets(ch);
     choice = atoi(ch);
    }
    while (choice < 1 || choice > 5);

    switch (choice)
    {
      case 1 : init_network();
               break;
      case 2 : train_network();
	       break;
      case 3 : build_test_network();
               break;
      case 4 : test_network();
	       break;
      case 5 : quit();
	       break;
     }
  }

}

