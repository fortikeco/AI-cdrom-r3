/********************************************************/
/*                FILE : BOLTZMN3.C                     */
/********************************************************/

#include <stdio.h>
#include "bolt2.c"

/*******************************************************/

init_network()

{

 int I;

 if ((outfile = fopen("BNET.out", "w"))==NULL)
    {
     printf("Cannot open output file. ");
     exit(1);
    }
 read_network_values();
 build_network();
 read_training_inputs();

}

/**********************************************************/

learn_network()
{
 int I;
 
 Test = 0;
 CLAMPED = 1;
 init_stat_array();

 PATTERN_NO = INPUT_PATTERNS;
 for(I=0; I<INPUT_PATTERNS; I++)
   {
    set_training_inputs();
    anneal();
    sum_cooccurrence();
   }
 cal_pplus();

 PATTERN_NO = INPUT_PATTERNS;
 CLAMPED = 0;
 for(I=0; I<INPUT_PATTERNS; I++)
     { 
      set_training_inputs();
      anneal();
      sum_cooccurrence(); 
      get_trained_outputs();
     } 
  cal_pminus();
  update_conn();
 }

 /***************************************************************/

 test_network()

 {
  int I, J;
  Test = 1;
 
  CLAMPED = 0;
  {
   set_test_inputs();
   anneal();  
   get_test_outputs();

  }
  printf(" \n\n  Result of the Test \n\n");
   
  for(J=0; J<I_NODES; J++)
    printf("%d", Test_OUTPUTS[J]); 
    printf( "\n");
      
   printf( "\n\n");
   
 }

 /***************************************************************/

 quit()
 {
  fclose(outfile);
  printf("\n   END OF PROGRAM \n");
  exit(0);
 }

/***************************************************************/
compute_error()
 {
  int I, J, SZ;
  float diff, total_diff;
  float RMS_error, sum_error;
  extern float sqrt();

  total_diff = 0;
  SZ = SIZE_OF_STATS_ARRAY;

  for(I=0; I<SZ; I++)
    {
      diff = BOLTZMN_NET.P_PLUS_STAT[I] - 
             BOLTZMN_NET.P_MINUS_STAT[I];
      diff = diff * diff;
      total_diff = total_diff + diff;
    } 
  sum_error = (float)total_diff / (float)SZ ;
  RMS_error = sqrt(sum_error);
  printf(" RMS Error : %f \n", RMS_error);

  if (RMS_error <= LIMIT) 
    DONE = 1;
 }

/*****************************************************************/
print_inputs_outputs()

{
 int EQUAL, I, J;

 EQUAL = 1;
  printf("\n\n");
  for(I=0; I<INPUT_PATTERNS; I++)
    {
     for(J=0; J<I_NODES; J++)
      {  
       printf("%d", INPUTS[I][J]);
      }  
      printf("    ");
     for(J=0; J<I_NODES; J++)
        {
         printf("%d", OUTPUT_VEC[I][J]);
        }
      for(J=0; J<I_NODES; J++)
        {
         if (OUTPUT_VEC[I][J] != INPUTS[I][J])
           EQUAL = 0;
        }
         if (EQUAL == 1)
           printf("***");
         else
           printf("   ");
     for(J=I_NODES; J<TOTAL_NODES; J++)
        {
         printf("%d", OUTPUT_VEC[I][J]);
        } 
     printf("\n"); 
     EQUAL = 1;  
    }
} 



/*****************************************************************/

train_network()

 {
  Test = 0;
  DONE = 0;
  while (DONE == 0) 
    {
     learn_network();
     print_inputs_outputs(); 
     compute_error();
    }
  save_network_values();
  printf( "\n\n Result of Training \n");
  print_final_wts(); 
  print_outputs();
}

/*****************************************************************/

    
save_network_values()
{
 
 float wt_value;
 FILE *fp;
 int I, J, K;
 char fl_name[80];
 
 printf("\n    Enter the file name to save final network weights : ");
 gets(fl_name);
 if((fp=fopen(fl_name, "w"))==NULL)
   {
    printf("Cannot open save file.\n");
    exit(1);
    }

 fprintf(fp, "%d %d %d \n", I_NODES, H_NODES, NO_of_LOOPS); 
 for(I=0; I<TOTAL_NODES; I++)
   {
   for(J=I; J<TOTAL_NODES; J++)
    {
       wt_value = BOLTZMN_NET.NET_LAYER[I].WT_PTRS[J]; 
       fprintf(fp, "%f \n ", wt_value);
    }
   }
  fclose(fp);
 
  free(OUTPUT_VEC);
  free(INPUTS);
  free(BOLTZMN_NET);
}
/*************************************************************/
 
