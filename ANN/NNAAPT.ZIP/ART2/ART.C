 


/***************************************************************************
* MODULE NAME:   art.c
* PURPOSE: 
*
* Note:  This code has no user interface.  Number of F1 and F2 units have
*        be hardcoded as does the input filename, the parameters a, b, c,
*        d, e, theta, and rho and number of input patterns
*        Units are on line number
*        Parameters begin on line number
*        Number of input patterns is on line number
*        File name is on line number
***************************************************************************/

#include   <stdio.h>
#include   <alloc.h>
#include   <stdlib.h>
#include   <math.h>



struct F2_layer
{
	float		*units;
	float		*nhbit;
	float		**weights;			 /* bottom up weights */
	int		winner;
	int		no_remaining_units;
};


struct p_layer
{
	float      *units;
	float		**weights;		  /* top down weights */
};



struct network
{
	float				a;
	float				b;
	float				c;
	float				d;
	float				e;
	float				rho;
	float				theta;

	float				*w, *x, *fofx, *v, *u, *q, *fofq, *r;
	struct p_layer     *p; 
	struct F2_layer   	*F2;
	float				w_mag, v_mag, p_mag, u_mag, r_mag, q_mag, uz_ang;
	int                *result_table;
	float				**I;
	int				no_input_patterns;
};
struct network	*art2;

struct network    *init_network();

int				calc_F2(struct network *);
float				calc_w(struct network *, int);
float				calc_v(struct network *);
float				calc_p(struct network *);
float				calc_u(struct network *);
float				calc_r(struct network *);
void				calc_x(struct network *);
float    			calc_q(struct network *);
void				pause(void);
float             calc_uzang();

	int            no_F1_units = 2, no_F2_units = 2;
	int			cycle;
	int			pattern_number = 0;



/**********************************************************************
* Function Name: 	Main
* Purpose: main control loop for program
*          
* Called by: 
* Calls: 
*********************************************************************/
main()
{
	int			vectors_left;
	int 			reset = 0;
	int			i;
	int			remaining_units;

printf("ready to init network\n");
	art2 = init_network();

	read_input_file(art2);
/*   print_input_vectors(art2);  */
/*	print_td_weights(art2);	   
	print_bu_weights(art2);	   
*/
	pattern_number = 0;
	vectors_left = art2->no_input_patterns;
   	remaining_units = no_F2_units;

	for (i = 0; i < art2->no_input_patterns; i++)
	{
			cycle = 0;

			calc_all(art2, pattern_number);

			calc_all(art2, pattern_number);

art2->uz_ang = calc_uzang(art2);		  
printf("uz ang = %f", art2->uz_ang);

			art2->r_mag = calc_r(art2);
printf("r mag = %f\n", art2->r_mag);

			reset =	calc_reset(art2);
			if (reset == 0)
				cycle++;

printf("cycle = %d\n", cycle);

printf("\n\n reset = %d\n", reset);

			while (reset || (cycle < 2) )
		   	{
		        while (reset)
				  {
						art2->F2->nhbit[art2->F2->winner] = 0.0;
printf("nhbit%d  set to %d\n",
		   art2->F2->winner,
		   art2->F2->nhbit[art2->F2->winner]);
					    remaining_units--;

				    if (!remaining_units)
					  {
					    /*some action determined by application*/
/*
print_td_weights(art2);
print_bu_weights(art2);
*/
						return(0);
					  }

				    cycle = 0;

					clear_F1(art2);

					calc_all(art2, pattern_number);
					calc_all(art2, pattern_number);


art2->uz_ang = calc_uzang(art2);		  
printf("uz ang = %f", art2->uz_ang);

					art2->r_mag = calc_r(art2);
					reset = calc_reset(art2);


				  }	/* end while reset */

				art2->F2->winner = calc_F2(art2);
printf("\n\nF2 winner = unit %d \n", art2->F2->winner);


				art2->p_mag = calc_p(art2);
printf("p mag = %f\n", art2->p_mag);

			    calc_q(art2);

				calc_all(art2, pattern_number);

art2->uz_ang = calc_uzang(art2);		  
printf("uz ang = %f", art2->uz_ang);


		    	art2->r_mag = calc_r(art2);
printf("r mag = %f\n", art2->r_mag);

				reset = calc_reset(art2);
			if (reset == 0)
				cycle++;
printf("\n\n reset = %d\n", reset);

		    } /* end while */ 

      art2->result_table[pattern_number] = art2->F2->winner;

		printf("pattern number %d  categorized at node number %d ",
		        pattern_number, art2->F2->winner);

pause();

		modify_weights(art2);

print_td_weights(art2);
print_bu_weights(art2);


		clear_network(art2);
printf("network cleared\n");

   	remaining_units = no_F2_units;

		vectors_left--;

		pattern_number++;

   } /* end for */

}	/* end Main*/



/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
calc_reset(struct network   *art2)							 
{
	float		mismatch_deg;

	mismatch_deg = art2->rho/(art2->e + art2->r_mag);
	if (mismatch_deg > 1.0)
		return(1);
	else return(0);
}



/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
clear_network(struct network   *art2)
{
	clear_output(art2->w);

	clear_output(art2->x);

	clear_output(art2->v);

	clear_output(art2->u);

	clear_output(art2->r);

	clear_output(art2->fofx);

	clear_output(art2->fofq);

	clear_p_output(art2);

	clear_F2(art2);

	set_nhbit(art2);

}


clear_F1(struct network   *art2)
{
	clear_output(art2->w);

	clear_output(art2->x);

	clear_output(art2->v);

	clear_output(art2->u);

	clear_output(art2->r);

	clear_output(art2->fofx);

	clear_output(art2->fofq);

	clear_p_output(art2);

}






/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
clear_p_output(struct network   *art2)
{
	int		i;

	for (i = 0; i < no_F1_units; i++)
		art2->p->units[i] = 0.0;
}



/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
clear_F2(struct network   *art2)
{
	int		j;


	for (j = 0; j < no_F2_units; j++)
		{
			art2->F2->units[j] = 0.0;
		}

	for (j = 0; j < no_F2_units; j++)
		{
			art2->F2->nhbit[j] = 0;
		}
}



/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
set_nhbit(struct network   *art2)
{
	int		j;

	for (j = 0; j < no_F2_units; j++)
		{
			art2->F2->nhbit[j] = 1.0;
		}

	
}



/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
clear_output(float  *layer)
{
	int		i;


	for (i = 0; i < no_F1_units; i++)
		{
      	layer[i] = 0.0;
		}

}


/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
calc_all(struct network  *art2, int  pattern)
{
	art2->w_mag = calc_w(art2, pattern);
printf("w mag = %f\n", art2->w_mag);

	calc_x(art2);

	art2->v_mag = calc_v(art2);
printf("v mag = %f\n", art2->v_mag);

	art2->u_mag = calc_u(art2);
printf("u mag = %f\n", art2->u_mag);

	art2->p_mag = calc_p(art2);
printf("p mag = %f\n", art2->p_mag);

	art2->q_mag = calc_q(art2);

}


/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
float calc_w(struct network  *art2, int pattern)
{

	float		sum = 0.0;
	int		i;

	for (i = 0; i < no_F1_units; i++)
		{
			art2->w[i] = art2->I[pattern][i] + (art2->a*art2->u[i]);
			sum+= art2->w[i] * art2->w[i];
		}
/*
for (i = 0; i < no_F1_units; i++)
	printf("W%d = %f   ", i, art2->w[i]);
printf("\n");
*/
   sum = sqrt((double)sum);

	return(sum);
}



/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
float calc_v(struct network   *art2)
{
	float		sum = 0.0;
	int		i;


	for (i = 0; i < no_F1_units; i++)
		{
			art2->v[i] = art2->fofx[i] + (art2->b * art2->fofq[i]);
/*
if (cycle > 0)
  printf("fofx%d = %f    fofq%d = %f  v%d = %f\n",
	            i, art2->fofx[i],
				 i, art2->fofq[i], i, art2->v[i]);
*/
			sum+= art2->v[i] * art2->v[i];
		}

/*
for (i = 0; i < no_F1_units; i++)
	printf("V%d = %f   ", i, art2->v[i]);
printf("\n");
*/

   sum = sqrt((double)sum);
	return(sum);
}


/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
float calc_uzang(struct network   *art2)
{
	float		ang = 0.0;
	float      dot = 0.0;
	float      mag_z = 0.0;
	int		i;



	for (i = 0; i < no_F1_units; i++)
		{
		   	dot+= art2->u[i] * art2->p->weights[i][art2->F2->winner];
			mag_z += art2->p->weights[i][art2->F2->winner] *
					 art2->p->weights[i][art2->F2->winner];
      }

			mag_z =  sqrt((double)mag_z);
			if (mag_z != 0.0)
			 ang = dot / mag_z;
			else
			 ang = 0.0;
	return(ang);
}



/**********************************************************************
* Function Name: 
* Purpose: 
*          
* Called by: 
* Calls: 
*********************************************************************/
float calc_p(struct network   *art2)
{
	float		sum = 0.0;
	int		i;



	for (i = 0; i < no_F1_units; i++)
		{
		    if (cycle > 0)
				art2->p->units[i] = art2->u[i] +
			    	                (art2->d *
			        	            art2->p->weights[i][art2->F2->winner]);
			else
				art2->p->units[i] = art2->u[i];
			sum+= art2->p->units[i]*art2->p->units[i];

      }


/*
if (cycle > 0)
*/
/*
for (i = 0; i < no_F1_units; i++)
	printf("P%d = %f   ", i, art2->p->units[i]);
printf("\n");
*/

   sum = sqrt((double)sum);
printf("sum = %f\n", sum);

	return(sum);
}




void calc_x(struct network   *art2)
{
	int		i;


	for (i = 0; i < no_F1_units; i++)
		{
			art2->x[i] = art2->w[i] / (art2->e + art2->w_mag);
			if (art2->x[i] > art2->theta)
			    art2->fofx[i] = art2->x[i];
			else
			   art2->fofx[i] = 0;
		}
/*
for (i = 0; i < no_F1_units; i++)
	printf("X%d = %f   ", i, art2->x[i]);
printf("\n");
*/
/*
for (i = 0; i < no_F1_units; i++)
	printf("FofX%d = %f   ", i, art2->fofx[i]);

printf("\n");
*/
}



float calc_u(struct network   *art2)
{
	int		i;
	float		sum = 0.0;


	for (i = 0; i < no_F1_units; i++)
		{
			art2->u[i] = art2->v[i] / (art2->e + art2->v_mag);
			sum+= art2->u[i] * art2->u[i];
		}
/*
for (i = 0; i < no_F1_units; i++)
	printf("U%d = %f   ", i, art2->u[i]);
printf("\n");
*/

   sum = sqrt((double)sum);
	return(sum);
}

float calc_q(struct network  *art2)
{
	int		i;
	float		sum = 0.0;


	for (i = 0; i < no_F1_units; i++)
		{
			art2->q[i] = art2->p->units[i] /
			                      (art2->e + art2->p_mag);
			if (art2->q[i] > art2->theta)
			    art2->fofq[i] = art2->q[i];
			else
			   art2->fofq[i] = 0;
			sum+= art2->q[i] * art2->q[i];
		}
	sum = sqrt( (double)sum);
   return(sum);
}




/*
void calc_q(struct network  *art2)
{
	int		i;
	float		sum = 0.0;


	for (i = 0; i < no_F1_units; i++)
		{
			art2->q[i] = art2->p->units[i] /
			                      (art2->e + art2->p_mag);
			if (art2->q[i] > art2->theta)
			    art2->fofq[i] = art2->q[i];
			else
			   art2->fofq[i] = 0;
			sum+= art2->q[i];
		}

}
*/


float calc_r(struct network   *art2)
{
	int		i;
	float		sum = 0.0;
	float		num, den;



	den = art2->e + art2->u_mag + (art2->c*art2->q_mag);
/*	den = art2->e + art2->u_mag + (art2->c*art2->p_mag); */
	for (i = 0; i < no_F1_units; i++)
		{
		 	num = art2->u[i] + (art2->c*art2->q[i]);
		 /*	num = art2->u[i] + (art2->c*art2->p->units[i]);	*/
			art2->r[i] = num /den;
/*printf("num%d = %f   den%d = %f  R%d = %f\n",
		     i, num, i, den, i, art2->r[i]);	 */

			sum+= art2->r[i]*art2->r[i];
		}
/*if ((cycle > 0) && (pattern_number > 1)) */

printf("\n");

   sum = sqrt((double)sum);
	return(sum);
}



						
int  calc_F2(struct network   *art2)
{
	int		j, i;
	int		max = 0;
	float		dot_prod;
	float		sum;

for (i = 0; i < no_F2_units; i++)
	printf("nhbit%d = %f   ", i, art2->F2->nhbit[i]);
printf("\n");

	for (i = 0; i < no_F2_units; i++)
		{
		    dot_prod = 0.0;
			for (j = 0; j < no_F1_units; j++)
		    	{
			     sum =  art2->p->units[j] *
				        art2->F2->weights[i][j];
			   	 dot_prod+= sum;

			   	 }
			art2->F2->units[i] = dot_prod * art2->F2->nhbit[i];
			if (art2->F2->units[i] > art2->F2->units[max])
			   		max = i;
		}

for (i = 0; i < no_F2_units; i++)
	printf("F2%d = %f   ", i, art2->F2->units[i]);
printf("\n");

/*
print_td_weights(art2);
*/
	return(max);
}




modify_weights(struct network   *art2)
{
	modify_bottom_up_weights(art2);


	modify_top_down_weights(art2);
}




modify_bottom_up_weights(struct network  *art2)
{
	int		i, j;


	i = art2->F2->winner;	

	for (j = 0; j < no_F1_units; j++)

		{
			art2->F2->weights[i][j] = art2->u[j] / (1 - art2->d);			
		}
	
}




modify_top_down_weights(struct network  *art2)
{
	int		i, j;


	j = art2->F2->winner;
	for (i = 0; i < no_F1_units; i++)
		{
			art2->p->weights[i][j] = art2->u[i] / (1 - art2->d);			
		}
}




						 
struct p_layer   *make_p_layer(struct network  *art2)
{
	int		i;

	art2->p = (struct p_layer  *)calloc(1, sizeof(struct p_layer) );
	art2->p->units   = (float *) calloc(no_F1_units, sizeof(float) );
	art2->p->weights = (float **)calloc(no_F1_units, sizeof(float *) );
	for (i = 0; i < no_F1_units; i++)
		{
			art2->p->weights[i] = (float *)calloc(no_F2_units,
			                                       sizeof(float) );
		}
	return(art2->p);
}




struct F2_layer   *make_F2_layer(struct network   *art2)
{
	int		i;


	art2->F2 = (struct F2_layer *)calloc(1, sizeof(struct F2_layer) );
 	art2->F2->units   = (float *) calloc(no_F2_units, sizeof(float) );
	art2->F2->nhbit   = (float *) calloc(no_F2_units, sizeof(float) );
	set_nhbit(art2);
	art2->F2->weights = (float **)calloc(no_F2_units, sizeof(float *) );
	for (i = 0; i < no_F2_units; i++)
		{
			art2->F2->weights[i] = (float *)calloc(no_F1_units,
			                                       sizeof(float) );
		}
	return(art2->F2);
}



init_bu_weights(struct network   *art2)
{
   int		i, j;


	for (i = 0; i < no_F2_units; i++)
		for (j = 0; j < no_F1_units; j++)
		   art2->F2->weights[i][j] = 1.0/ ( (1-art2->d) *
			                              sqrt((double)no_F1_units) );
}




init_td_weights(struct network  *art2)
{
	int		i, j;


	for (i = 0; i < no_F1_units; i++)
		for (j = 0; j < no_F2_units; j++)
		   art2->p->weights[i][j] = 0.00;
}




struct network   *init_network()
{
	int 		i;


	art2        = (struct network *)calloc(1, sizeof(struct network) );
	if (art2 == NULL)
		{
			printf("cannot get space for art2\n");
			return(0);
		}

	art2->a = 0.1;
	art2->b = 0.1;
	art2->c = 0.1;
	art2->d = 0.9;
	art2->e = 0.0;
	art2->rho = 0.98;
	art2->theta = 0.05;
	art2->no_input_patterns = 2;


	art2->I     = (float **)calloc(art2->no_input_patterns, sizeof(float *) );
   for (i = 0; i < art2->no_input_patterns; i++)
		art2->I[i] =  (float *)calloc(no_F1_units, sizeof(float) );

	art2->w     = (float *)calloc(no_F1_units, sizeof(float) );
	art2->x     = (float *)calloc(no_F1_units, sizeof(float) );
	art2->fofx  = (float *)calloc(no_F1_units, sizeof(float) ); 
	art2->v     = (float *)calloc(no_F1_units, sizeof(float) );
	art2->u     = (float *)calloc(no_F1_units, sizeof(float) );
	art2->q     = (float *)calloc(no_F1_units, sizeof(float) ); 
	art2->fofq  = (float *)calloc(no_F1_units, sizeof(float) );
	art2->r     = (float *)calloc(no_F1_units, sizeof(float) );
	art2->p     = make_p_layer(art2);
	art2->F2    = make_F2_layer(art2);

	art2->result_table = (int *)calloc(art2->no_input_patterns, sizeof(int) );

/*	print_network_descrip(art2); */

	init_bu_weights(art2);
printf("bu weights done\n");

	init_td_weights(art2);
printf(" weights done - network initialized\n");
	return(art2);
}


print_network_descrip(struct network *art2)
{
	int	i, j;

	printf("\n Network Description \n\n");
	printf("Parameters\n");
	printf(" a = %4.2f\n b = %4.2f\n c = %4.2f\n d = %4.2f\n e = %4.2f\n rho = %4.2f\n	theta = %4.2f\n",
		      art2->a, art2->b, art2->c, art2->d, art2->e, art2->rho, art2->theta);

	printf("F1 layers\n\n");
	printf(" W \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->w[i]);
	printf(" X \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->x[i]);
	printf(" FofX \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->fofx[i]);
	printf(" V \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->v[i]);
	printf(" U \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->u[i]);
	printf(" Q \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->q[i]);
	printf(" FofQ \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->fofq[i]);
	printf(" R \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->r[i]);
	printf(" P \n");
	for (i = 0; i < no_F1_units; i++)
		printf("unit%d = %f \n", i, art2->p->units[i]);



}




read_input_file(struct network   *art2)
{
	FILE	  	*fp;
	int		i, j;
	float		temp;

	fp = fopen("test.dat", "r");
	if (fp == NULL)
	  {
	  		printf("file not opened");
		    return;
	  }
	for (i = 0; i < art2->no_input_patterns; i++)
		{
			for (j = 0; j < no_F1_units; j++)
				{
			  		fscanf(fp, "%f", &temp);
					art2->I[i][j] = temp; 
/*printf("pattern %d value %d = %4.3f\n", i, j, art2->I[i][j]); */
          	}
		}
}



print_input_vectors(struct network  *art2)
{
	int	i, j, k;

	for (i = 0; i< art2->no_input_patterns; i++)
		{
		 	for (j = 0; j < 8; j++)
		   	 {
		   		for (k = 0; k < 8; k++)
		   			printf(" %4.3f ", art2->I[i][8*j+k]);
		   		printf("\n");
		   	 }
		    printf("\n\n");
		}
}



print_bu_weights(struct network  *art2)
{
	int		i, j;

	for (i = 0; i < no_F2_units; i++)
		for (j = 0; j < no_F1_units; j++)
		   printf("bu weight %d %d = %4.3f\n", i, j, art2->F2->weights[i][j]);
}



print_td_weights(struct network  *art2)
{
	int		i, j;

	for (i = 0; i < no_F1_units; i++)
		for (j = 0; j < no_F2_units; j++)
		   printf("td weight %d %d = %4.3f\n", i, j, art2->p->weights[i][j]);
}



print_table(struct network   *art2)
{
	int		i;

	for (i = 0; i < art2->no_input_patterns; i++)
		printf("pattern number %d  categorized at node number %d\n ",
		        i, art2->result_table[i]);

}

void  pause(void)
{
	int		ch;

	fflush(stdin);
	while(!kbhit());
	ch = getch();

}



