/************************************************************/
/*                      CPN_CPROP.C                          */
/************************************************************/
/*  This file contains the procedures needed to test the    */
/*  CPN in production mode using counter propagation.       */
/*                                                          */
/************************************************************/

#include "cpn_learn.c" 
#include <stdio.h>

/************************************************************/
/* Purpose : Propagates the signal from input layer to      */
/*           hidden layer.  Finds the winning node in hidden*/
/*           layer.                                         */
/* Algorithm : Compute the output for the hidden layer nodes*/
/*             Call compete to find the winner;             */
/************************************************************/

counter_prop_to_hidden()

{
 int I, J, K;

 for(I=0; I<NO_OF_HIDDEN_NODES; I++)
  {
   H_OUTPUT[I] = 0.0;
   for(J=0; J<TOTAL_INOUT_NODES; J++)
     {
      H_OUTPUT[I] = H_OUTPUT[I] + CPN.HIDDEN_LAYER[I].WT_PTRS[J] *
				  CPN.INPUT_LAYER[J].OUTPUTS;
     }
      printf("H Output for %d : %f\n", I, H_OUTPUT[I]);

   }
 compete();

}

/********************************************************************/
/* Purpose : Propagate the signal from hidden layer to output layer.*/
/* Algorithm : Get hidden layers winning node's output which is 1.0;*/
/*           Compute all output layer nodes' output;                */
/*                                                                  */
/********************************************************************/

counter_prop_to_output()
{

 int I;
 float WIN_OUTPUT;

 printf("\nPattern No %d & Winning Node %d\n", PATTERN_NO, WIN_NODE); 
  WIN_OUTPUT = CPN.HIDDEN_LAYER[WIN_NODE].OUTPUTS;
  for(I=NO_OF_OUTPUT_NODES; I<TOTAL_INOUT_NODES; I++)
  {
   CPN.OUTPUT_LAYER[I].OUTPUTS = WIN_OUTPUT *
				CPN.OUTPUT_LAYER[I].WT_PTRS[WIN_NODE];
   printf(" %f ", CPN.OUTPUT_LAYER[I].OUTPUTS);
  }
 printf("\n\n");

}
/***********************************************************/
/* Purpose : Tests the network in production mode.         */
/* Algorithm :  Print heading in output file;              */
/*           call set_inputs;                              */
/*           Call set_inputs_to_zero;                      */
/*           Call prop_to_hidden;                          */
/*           Call prop_to_output;                          */
/*           Print the output;                             */
/***********************************************************/

counter_test_network()
{
 FILE *out2;
 char file_name[80];
 char ch[80];

 if ((out2 = fopen("test2.out", "w"))==NULL)
   {
    printf("Cannot open the output file for the testing results. \n ");
    exit(1);
   }
 read_test_data();
 normalize_test_data();

 init_win_array();
for(PATTERN_NO=0; PATTERN_NO<NO_OF_INPUT_PATTERNS; PATTERN_NO++)
 { 
 set_inputs();
 set_input_nodes_to_zero();
 counter_prop_to_hidden();
 counter_prop_to_output();
/* print_outputs(); */ 
}
 
}

/**************************************************************/

