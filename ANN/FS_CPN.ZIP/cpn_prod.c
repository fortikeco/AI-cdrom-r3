/************************************************************/
/*                      CPN_PROD.C                          */
/************************************************************/
/*  This file contains the procedures needed to test the    */
/*  CPN in production mode.                                 */
/*                                                          */
/************************************************************/

#include "cpn_init.c" 
#include <stdio.h>

/************************************************************/
/* Purpose : Propagates the signal from input layer to      */
/*           hidden layer.  Finds the winning node in hidden*/
/*           layer.                                         */
/* Algorithm : Compute the output for the hidden layer nodes*/
/*             Call compete to find the winner;             */
/************************************************************/

prop_to_hidden()

{
 int I, J, K;

 for(I=0; I<NO_OF_HIDDEN_NODES; I++)
  {
   H_OUTPUT[I] = 0.0;
   for(J=0; J<TOTAL_INOUT_NODES; J++)
     {
      H_OUTPUT[I] = H_OUTPUT[I] + CPN.HIDDEN_LAYER[I].WT_PTRS[J] *
				  CPN.INPUT_LAYER[J].OUTPUTS;
     }
      printf("H Output for %d : %f\n", I, H_OUTPUT[I]);

   }
 compete();

}

/********************************************************************/
/* Purpose : Propagate the signal from hidden layer to output layer.*/
/* Algorithm : Get hidden layers winning node's output which is 1.0;*/
/*           Compute all output layer nodes' output;                */
/*                                                                  */
/********************************************************************/

prop_to_output()
{

 int I;
 float WIN_OUTPUT;

 printf("\nPattern No %d & Winning Node %d \n", PATTERN_NO, WIN_NODE); 
  WIN_OUTPUT = CPN.HIDDEN_LAYER[WIN_NODE].OUTPUTS;
  for(I=0; I<NO_OF_OUTPUT_NODES; I++)
  {
   CPN.OUTPUT_LAYER[I].OUTPUTS = WIN_OUTPUT *
				CPN.OUTPUT_LAYER[I].WT_PTRS[WIN_NODE];
printf(" %f ", CPN.OUTPUT_LAYER[I].OUTPUTS);
  }
 printf("\n\n");

}
/*******************************************************************/
/* Purpose : Finds the winning node in hidden layer of CPN.        */
/* Algorithm : Assign zero to max_output;                          */
/*             Get the max output from hidden layer nodes;         */
/*             If output of the node is greater than max_output    */
/*              and if the node was not winning node before then   */
/*                  Found the winning node;                        */
/*             Assign the winning node number to win_node;         */
/*             Assign 1 to winning node's output;                  */
/*             Assign 0 to all other nodes;                        */
/*                                                                 */
/*******************************************************************/

compete()
{
 int I, J;
 float MAX_OUTPUT,
       WIN_OUTPUT;
 MAX_OUTPUT = 0.0;
 for(I=0; I<NO_OF_HIDDEN_NODES; I++)
   {
    if (H_OUTPUT[I] > MAX_OUTPUT)
      {
       if (WINNER_FOUND[I]==0)
	{ MAX_OUTPUT = H_OUTPUT[I];
	  WIN_NODE = I;
	}
      }
    }
  WIN_OUTPUT = MAX_OUTPUT;

 for(I=0; I<NO_OF_HIDDEN_NODES; I++)
   {
    CPN.HIDDEN_LAYER[I].OUTPUTS = 0.0;
   }
   CPN.HIDDEN_LAYER[WIN_NODE].OUTPUTS = 1.0;
   WINNER_FOUND[WIN_NODE] = 1;
 }

/**********************************************************/
read_test_data()
{
 
 int I, J, K;
 int a_input;
 FILE *prod_in;
 char file_name[80];
 char ch[80];
 
 printf("Enter the file name of the test data file : ");
 gets(file_name);
 if ((prod_in = fopen(file_name, "r+"))==NULL)
   {
    printf("Cannot open the input file for testing data. \n ");
    exit(1);
   }

  printf("\nEnter number of patterns to be tested : ");
  gets(ch);
  NO_OF_INPUT_PATTERNS = atoi(ch); 

  TEST_INPUTS = (float **)
            calloc(NO_OF_INPUT_PATTERNS, sizeof(float));
  for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
   TEST_INPUTS[I] = (float *)
        calloc(TOTAL_INOUT_NODES, sizeof(float));

  for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
    {
    for(J=0; J<NO_OF_INPUT_NODES; J++)
     {
      fscanf(prod_in, "%d", &a_input);
      INPUTS[I][J] = a_input;
     }
    }
  fclose(prod_in);
}

/***************************************************************/
normalize_test_data()
{

 int I, J, K;
  float magnitude,
        normalized_value;
  extern float sqrt();

 /* normalize the input vector */
 for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
  {
   magnitude = 0.0;
   for(J=0; J<NO_OF_INPUT_NODES; J++)
     {
      if (INPUTS[I][J] == 1)
         magnitude = magnitude +
                 ((float)INPUTS[I][J]) * ((float)INPUTS[I][J]);
     }
   normalized_value = 1 / sqrt (magnitude);
  /* printf("Normalized Input for %d : %f \n", I,
            normalized_value); */
   for(K=0; K<NO_OF_INPUT_NODES; K++)
      {  
       if (INPUTS[I][K] > 0)
         TEST_INPUTS[I][K] =  normalized_value;
       else
         TEST_INPUTS[I][K] = 0.0;
       } 
 
 
   for(K=NO_OF_INPUT_NODES; K<TOTAL_INOUT_NODES; K++)
       TEST_INPUTS[I][K] = 0.0;

  } /* for I loop */

}

/*****************************************************************/
set_test_inputs()
{

 int I;

 for(I=0; I<TOTAL_INOUT_NODES; I++)
  CPN.INPUT_LAYER[I].OUTPUTS = TEST_INPUTS[PATTERN_NO][I];

}


/***********************************************************/
/* Purpose : Tests the network in production mode.         */
/* Algorithm :  Print heading in output file;              */
/*           call set_inputs;                              */
/*           Call set_inputs_to_zero;                      */
/*           Call prop_to_hidden;                          */
/*           Call prop_to_output;                          */
/*           Print the output;                             */
/***********************************************************/

test_network()
{
 FILE *out1;
 char file_name[80];
 char ch[80];

 if ((out1 = fopen("test1.out", "w"))==NULL)
   {
    printf("Cannot open the output file for the testing results. \n ");
    exit(1);
   }
 read_test_data();
 normalize_test_data();
 init_win_array();
for(PATTERN_NO=0; PATTERN_NO<NO_OF_INPUT_PATTERNS; PATTERN_NO++)
 { 
 set_test_inputs();
 set_output_nodes_to_zero();
 prop_to_hidden();
 prop_to_output();
/* print_outputs(); */ 
}
 fclose(out1); 
}

/**************************************************************/

