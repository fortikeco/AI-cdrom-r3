/************************************************************/
/*                      CPN_INIT.C                          */
/************************************************************/
/*                                                          */
/* Purpose : This file contains procedures which will be    */
/*           used to read network values, to build CPN, and */
/*           to initialize the network as well as procedure */
/*           to normalize the input data.                   */
/*                                                          */
/************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "cpn.h"


/************************************************************/
/* Purpose : Reads the input data from a text file. The data*/
/*           contains number of nodes in each layer.        */
/* Algorithm : Prompt for the input file name;              */
/*             Prompt for the parameters;                   */
/*             Read number of nodes for each layer from     */
/*                 input file;                              */
/*             Print nodes info in output file;             */
/*             Close input file;                            */
/************************************************************/

read_CPN_size()

{
 FILE *fp;
 char file_name[80];
 char ch[80];

 printf("\n\n");
 printf(" Enter the file name to get info of size of CPN : ");
 gets(file_name);

 if ((fp = fopen(file_name, "r+"))==NULL)
    {
     printf("Cannot open info file. \n");
     exit(1);
    }
 printf("\n");
 printf(" Enter the alpha value : ");
 gets(ch);
 alpha = atof(ch);      /* convert into float */
 printf("\n");

 printf(" Enter the beta value : ");
 gets(ch);
 beta = atof(ch);
 printf("\n");

 fscanf(fp, "%d", &NO_OF_INPUT_NODES);
 fscanf(fp, "%d", &NO_OF_HIDDEN_NODES);
 fscanf(fp, "%d", &NO_OF_OUTPUT_NODES);
 fclose(fp);
 
fprintf(outfile, "            ** COUNTERPROPAGATION NEURAL NETWORK ** \n\n");
 fprintf(outfile, "       3 Layer Network \n\n");
 fprintf(outfile, "       The Input layer has %d nodes.\n",
	 NO_OF_INPUT_NODES);
 fprintf(outfile, "       The Hidden layer has %d nodes.\n",
	 NO_OF_HIDDEN_NODES);
 fprintf(outfile, "       The Output Layer has %d nodes.\n",
	 NO_OF_OUTPUT_NODES);
 fprintf(outfile, " \n\n");

}

/************************************************************************/
/* Purpose : Builds neural network structure with the given size and    */
/*           allocate memory for each layer and each node of the        */
/*           network.                                                   */
/* Algorithm :  Calculate number of nodes for input and output layer;   */
/*           Allocate memory for each layer;                            */
/*           Allocate memory for the weight arrays;                     */
/*           Allocate memory for H_output array;                        */
/*           Allocate memory for winner_found array;                    */
/*           Initialize winner_found array to 0  (false);               */
/************************************************************************/

build_network()
{

int I, J;

TOTAL_INOUT_NODES = NO_OF_INPUT_NODES + NO_OF_OUTPUT_NODES;

CPN.INPUT_LAYER = (struct cpn_node *)
		  calloc(TOTAL_INOUT_NODES, sizeof(struct cpn_node));
CPN.HIDDEN_LAYER = (struct cpn_node *)
		   calloc(NO_OF_HIDDEN_NODES, sizeof(struct cpn_node));
CPN.OUTPUT_LAYER = (struct cpn_node *)
		   calloc(TOTAL_INOUT_NODES, sizeof(struct cpn_node));


for(I=0; I<TOTAL_INOUT_NODES; I++)
  {
   CPN.INPUT_LAYER[I].WT_PTRS = (float *)
      calloc(NO_OF_HIDDEN_NODES, sizeof(float));
   }

for(I=0; I<NO_OF_HIDDEN_NODES; I++)
  {
   CPN.HIDDEN_LAYER[I].WT_PTRS = (float *)
	    calloc(TOTAL_INOUT_NODES, sizeof(float));
  }
for(J=0; J<TOTAL_INOUT_NODES; J++)
  {
   CPN.OUTPUT_LAYER[J].WT_PTRS = (float *)
	    calloc(NO_OF_HIDDEN_NODES, sizeof(float));
  }

  H_OUTPUT = (float *) calloc(NO_OF_HIDDEN_NODES, sizeof(float));

  /* boolean array for winner_found */
  WINNER_FOUND = (int *) calloc(NO_OF_HIDDEN_NODES, sizeof(int));
}
/*******************************************************************/
/* Purpose : Initialize hidden, output layer with initial          */
/*           weights.                                              */
/* Algorithm:          */
/*            Compute hidden layer weights by using the formula:   */
/*            initial weight = 1 / sqrt (number of input nodes)    */
/*            Assign this weight to all hidden nodes;              */
/*******************************************************************/

init_wts()
{

float wt,
      initial_wt;
int I, J, K;
extern float pow();
extern float sqrt();

initial_wt = 1 / sqrt ((float)(NO_OF_INPUT_PATTERNS));

printf("Initial Wt : %f\n", initial_wt);
for(J=0; J<NO_OF_HIDDEN_NODES; J++)
  {
   for(K=0; K<TOTAL_INOUT_NODES; K++)
      {
       CPN.HIDDEN_LAYER[J].WT_PTRS[K] = initial_wt;
      }
  }

printf("\n\n");
for(J=0; J<TOTAL_INOUT_NODES; J++)
  {
   for(K=0; K<NO_OF_HIDDEN_NODES; K++)
    {
     wt = rand(); 
     wt = (wt/(0.5 * (pow(2.0, 32.0) - 1.0))) ; 
     CPN.OUTPUT_LAYER[J].WT_PTRS[K] = wt;
     CPN.INPUT_LAYER[J].WT_PTRS[K] = wt;
    }
  }
}
/****************************************************************/
/* Purpose : Reads input data from input file and puts it in the*/
/*           input array and desired array. Then it normalizes  */
/*           the input data and prepares it for the input layer.*/
/* Algorithm:Prompt for the input file name;                    */
/*           Open input file;                                   */
/*           Prompt for the number of patterns in the input data*/
/*           Read number of patterns;                           */
/*           Allocate memory for Input array of size of number  */
/*              of nodes in input array;                        */
/*           Allocate memory for Desired array of size of number*/
/*             of nodes in Output layer;                        */
/*           Allocate memory for train_array of size of number  */
/*             of nodes in Input and output layer;              */
/*           Read input data in input array ;                   */
/*           Read desired output in desired array;              */
/*           Normalize the data and put it in train_array;      */
/****************************************************************/   

read_inputs()
{

int I, J, K, a_input, a_desired;
FILE *inputs_fl;
char file_name[80];
char ch[80];

printf(" Enter the file name for Inputs : ");
gets(file_name);
if ((inputs_fl = fopen(file_name, "r+"))==NULL)
  {
   printf("Cannot open Inputs file. \n");
   exit(1);
  }

printf("\n");
printf(" Enter number Input Patterns : ");
gets(ch);
NO_OF_INPUT_PATTERNS = atoi(ch);

INPUTS = (int **) calloc(NO_OF_INPUT_PATTERNS, sizeof(int));
for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
  INPUTS[I] = (int *)
	    calloc(NO_OF_INPUT_NODES, sizeof(int));

 DESIRED = (int **) calloc(NO_OF_INPUT_PATTERNS, sizeof(int));

for(J=0; J<NO_OF_INPUT_PATTERNS; J++)
   DESIRED[J] = (int *) calloc(NO_OF_OUTPUT_NODES, sizeof(int));

 
 for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
  {
   for(J=0; J<NO_OF_INPUT_NODES; J++)
    {
     fscanf(inputs_fl, "%d", &a_input);
     INPUTS[I][J] = a_input;
    }
   for(K=0; K<NO_OF_OUTPUT_NODES; K++)
     {
      fscanf(inputs_fl, "%d", &a_desired);
      DESIRED[I][K] = a_desired;
     }
  }
  fclose(inputs_fl);
}
/********************************************************************/

normalize_input()
{
  
  int I, J, K, N;
  float magnitude,
        normalized_value;
  extern float sqrt();



 TRAIN_INPUTS = (float **) calloc(NO_OF_INPUT_PATTERNS, sizeof(float));
 for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
   TRAIN_INPUTS[I] = (float *) calloc(TOTAL_INOUT_NODES, sizeof(float));
  
  /* normalize the input vector */
 for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
  {
   magnitude = 0.0;
   for(J=0; J<NO_OF_INPUT_NODES; J++)
     {
      if (INPUTS[I][J] == 1)
	 magnitude = magnitude + 
                 ((float)INPUTS[I][J]) * ((float)INPUTS[I][J]);
     }
   normalized_value = 1 / sqrt (magnitude);
  /* printf("Normalized Input for %d : %f \n", I, 
            normalized_value); */
   for(K=0; K<NO_OF_INPUT_NODES; K++)
      {  
       if (INPUTS[I][K] > 0)
         TRAIN_INPUTS[I][K] =  normalized_value;
       else
         TRAIN_INPUTS[I][K] = 0.0;
       }  

   magnitude = 0.0;

   for(K=0; K<NO_OF_OUTPUT_NODES; K++)
     {
      if (DESIRED[I][K] == 1)
	magnitude = magnitude + 
                ((float)DESIRED[I][K]) * ((float)DESIRED[I][K]);
     }
     normalized_value = 1 / sqrt (magnitude);
    /*printf("Normalized output : %f \n", normalized_value);*/

    N = 0;
    for(K=NO_OF_INPUT_NODES; K<TOTAL_INOUT_NODES; K++)
      {
       if (DESIRED[I][N] > 0)
         TRAIN_INPUTS[I][K] = normalized_value;
       else
         TRAIN_INPUTS[I][K] = 0.0;
       N++; 
      }   
   }    /* for I loop */

for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
  {
   for(J=0; J<TOTAL_INOUT_NODES; J++)
     {
      printf("%f ", TRAIN_INPUTS[I][J]);
     }
   printf("\n");
  }

}

/***************************************************************/
create_arrays()
{
 
 int I, J, K;  

  FL_INPUTS = (float **) calloc(NO_OF_INPUT_PATTERNS, sizeof(float));
  for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
    FL_INPUTS[I] = (float *) calloc(TOTAL_INOUT_NODES, sizeof(float));
 
  FL_OUTPUTS = (float **) calloc(NO_OF_INPUT_PATTERNS, sizeof(float));
 
  for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
    FL_OUTPUTS[I] = (float *) calloc(TOTAL_INOUT_NODES, sizeof(float));
 
  LEARNING_ERROR = (float **) calloc(NO_OF_INPUT_PATTERNS, sizeof(float));
  for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
    LEARNING_ERROR[I] = (float *) calloc(TOTAL_INOUT_NODES, sizeof(float));
 
  OUTPUT_ERROR = (float **) calloc(NO_OF_INPUT_PATTERNS, sizeof(float));
  for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
    OUTPUT_ERROR[I] = (float *) calloc(TOTAL_INOUT_NODES, sizeof(float));

  for(I=0; I<NO_OF_INPUT_PATTERNS; I++)
    {
   for(J=0; J<NO_OF_INPUT_NODES; J++)
    {
     FL_INPUTS[I][J] = (float) INPUTS[I][J];
     FL_OUTPUTS[I][J+NO_OF_OUTPUT_NODES] = (float)INPUTS[I][J];
     }
    for(K=0; K<NO_OF_OUTPUT_NODES; K++)
     {
      FL_INPUTS[I][J+K] = (float) DESIRED[I][K];
      FL_OUTPUTS[I][K] = (float)DESIRED[I][K];
     }
  }

 }

/**************************************************************************/

init_win_array()
{
 int I, J;
  
 for(I=0; I<NO_OF_HIDDEN_NODES; I++)
    WINNER_FOUND[I] = 0;
}

/***************************************************************/
/* Purpose : Prints the contents of each node in the network.  */
/* Algorithm : Print layer headings;                           */
/*            Print contents of each node in that layer;       */ 
/***************************************************************/

  print_outputs()
  {

  int I, J, K, N;


  fprintf(outfile, "\n\n Hidden Nodes   Output    I-H connection Weights \n ");

  N = 0;
  for(I=0; I<NO_OF_HIDDEN_NODES; I++)

   {
    fprintf(outfile, "  %d            %2.4f  ", I+1,
            CPN.HIDDEN_LAYER[I].OUTPUTS);
    for(J=0; J<NO_OF_INPUT_NODES; J++)
    {
     N++;
     fprintf(outfile, "  %2.4f  ", CPN.HIDDEN_LAYER[I].WT_PTRS[J]);
     if (N==5)
      { N= 0;
        fprintf(outfile, "\n                       ");
      }
    } 
    fprintf(outfile, "\n");
  }
  fprintf(outfile, " \n");
  N = 0;
  fprintf(outfile, "\n\n Output Node   Output   H-O Connection Weights \n ");
   for(I=0; I<TOTAL_INOUT_NODES; I++)
    {
     fprintf(outfile, "   %d          %2.4f  ", I+1, 
             CPN.OUTPUT_LAYER[I].OUTPUTS);
     for(J=0; J<NO_OF_HIDDEN_NODES; J++) 
      {
       N++;
       fprintf(outfile, "  %2.4f ", CPN.OUTPUT_LAYER[I].WT_PTRS[J]);
       if (N>6)
         { N = 0;
           fprintf(outfile, " \n                       ");
         }
      }
      fprintf(outfile, "\n");
   } 
  fprintf(outfile, 
      "\n\n ----------------------------------------------------\n\n");
}
/**************************************************************/
/* Purpose : Sets the training inputs in the input layer.     */
/* Algorithm : For each node in input layer loop              */
/*               Get the output from train_inputs;            */
/**************************************************************/

set_inputs()
{
 int I, J;

 for(I=0; I<TOTAL_INOUT_NODES; I++)
  {
   CPN.INPUT_LAYER[I].OUTPUTS = TRAIN_INPUTS[PATTERN_NO][I];
  }
}
/***************************************************************/
/* Purpose : sets the input layer's output units to zero for    */
/*           production mode.                                  */
/* Algorithm : Set extra nodes output to zero.                 */
/***************************************************************/

set_output_nodes_to_zero()
{

int I;

for(I=NO_OF_INPUT_NODES; I<TOTAL_INOUT_NODES; I++)
  {
   CPN.INPUT_LAYER[I].OUTPUTS = 0.0;
  }
}

/****************************************************************/
/* Purpose : Sets input layer's input nodes to zero for the    */
/*           production mode.                                   */
/* Algorithm : assign output of the input nodes to zero.        */
/****************************************************************/
  
set_input_nodes_to_zero()
{
 int I;

 for(I=0; I<NO_OF_INPUT_NODES; I++)
  CPN.INPUT_LAYER[I].OUTPUTS = 0.0;
}

/***************************************************************/
