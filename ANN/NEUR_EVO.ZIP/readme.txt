This is a bibliography of work relating artificial neural networks
(ANNs) and genetic search.  The Unix bib format is used throughout.
It is organized/oriented for someone familiar with the ANN literature
but less familiar with the genetic search literature.  It includes
some artificial life references.

I am a phd candidate in computer science at Oregon Graduate Institute
interested in tackling ANN architectural design using genetic search.
My particular orientation is to view minimizing interconnections as a
central issue, partly motivated by VLSI implementation issues.

I have started a mailing list for those interested in using genetic
search and ANNs together in various ways.  Mail to
Neuro-evolution-request@cse.ogi.edu for administrivia, answers to
questions, or to have your name added to the list.

Much thanks to the people who helped provide this bibliography by
providing references.   Corrections and additional references are
welcome.


Mike Rudnick			CSnet:	rudnick@cse.ogi.edu
Computer Science & Eng. Dept.	ARPAnet:  rudnick%cse.ogi.edu@relay.cs.net
Oregon Graduate Institute	BITNET:  rudnick%cse.ogi.edu@relay.cs.net
19600 N.W. von Neumann Dr.	UUCP:	{tektronix,verdix}!ogicse!rudnick
Beaverton, OR. 97006-1999	(503) 690-1121 X7390
******************************************************************************


