/*
KNET v3.0, Copyright Peter H. Kosel, 1345 56th St, Sacramento, CA 95819, 1988

Permission to use and retransmit granted by the author, except that
neither this program nor any portion may be sold, or incorporated in a
product which is sold, without the specific permission of the author.





This program demonstrates 'superficial reasoning' with networks of
probabilistic truth tables. What this means will be explained presently.
First, a word of caution. 

CAUTION
The "superficial reasoning" demonstrated by this program has some quirks that
may not be obvious. Particularly, it can identify simple rules such as constancy
of a bit's value or implication of one bit value by one or two other bit
values, but will not recognize complex rules or implication of a bit's value
by a pattern of many bit values. This inability of the program to recognize
complex rules may not be recognized by casual observers. Note carefully: this
program can fail to reject some input patterns which are without precedent in
the patterns it has learned, and can fail to make some inferences justified by
the patterns it has learned.



What is "Superficial Reasoning"?

Superficial reasoning as implemented here is a technique of using a network of
small truth tables to capture simple rules through observation and predict
some aspects of the behavior of an array of binary input values. This program
uses probabilistic truth tables rather than the usual, binary sort of truth
table. A network of small tables consumes much less memory than a complete
truth table for the entire input array would. Notably, if the size of the
small truth tables in the network is increased progressively the number of
truth tables first becomes huge, then (eventually) shrinks until finally when
k=n a single enormous truth table represents the entire input array. You'd
many many megabytes for a probabilistic truth table spanning 25 input bits.


What is a Truth Table, Usually?

The usual truth table is a table showing which patterns of values for a group
of boolean variables are possible. Such a table can be constructed empirically
from observations. Common patterns may be observed repeatedly and rare
patterns may not be observed in constructing truth tables empirically, so any
empirically constructed truth table may not be complete.


What is a Probabilistic Truth Table?

An empirically constructed probabilistic truth table is a table showing how
many times each pattern of values for a group of boolean variables has been
observed to occur. The total of the pattern counts in the table is the total
number of observations. A count is proportional to it's pattern's probability
if the counts are representative. A probabilistic truth table can be rendered
binary by simply making all counts above some criterion value unity and all
others zero.


What the Heck is MinCount?

In converting a probabilistic truth table to a binary truth table you may want
to consider only patterns which have occured more than a certain number of
times as plausible. MinCount specifies the value of that certain number of
times. You can adjust it via the the adjustment menu. 


What is a Network of Probabilistic Truth Tables?

A truth table or probabilistic truth table applies to k boolean values carried
by k input lines. If there are n input lines, where n is larger than k, and if
there is a collection of tables, one table for each combination of k out of n
input lines, then that collection of tables can be called a network of tables.
There are n!/( ( n-k)! k! ) tables in such a network of tables, where '!'
signifies factorials. I call the parameter "k" the logic depth. The network is
COMPLETELY BLIND to any rule or implication involving more than k input bits!
That's why I call what it does "superficial reasoning"!


How Does the Network Learn a Pattern?

In learning a pattern of n boolean values each table is updated according to
the appropriate sub-pattern of k boolean values.


Does This Program Really Store Truth Tables?

Nope. It actually stores layered networks of counts which are used to
reconstruct probabilistic truth tables. What is counted is the effective
number of times each combination of 0, 1, 2, 3 bits occurs true
simultaneously. This trick slows the program down but achieves a memory
savings of roughly 85% at logic depth three, more at greater logic depths. I
haven't figured out how to run this trick with binary tables, only
probabilistic ones. I calculate that, using this layered network trick, the
network memory requirement will stay under that for the monolithic truth table
as k increases toward n and they'll match when k reaches n.


What Kind of Patterns does the Network Learn?

It learns patterns of 25 boolean values you enter in a 5 by 5 grid to
facilitate your (not the program's) visual recognition, as in this "letter E"
example:

1 1 1 1 1
1 0 0 0 0
1 1 1 1 0
1 0 0 0 0
1 1 1 1 1


What is a Learning Weight?

The learning weight solicited when you teach the program a pattern represents
how many times the program should "observe" the pattern. It's a lot easier
than entering the same pattern umpteen times.


What is the numbering system for pattern bits?

The system, used in retrieving individual truth tables, is as follows:

 1  2  3  4  5

 6  7  8  9 10

11 12 13 14 15

16 17 18 19 20

21 22 23 24 25



What is a Hypothesis?

A hypothesis is part or all of a pattern of n boolean values which you enter.
It must indicate not only the boolean values hypothesized but also the bits
for which no value is hypothesized. This is done in this program by using
periods as place markers in an array of values as in this example :

1 . 1 1 1
. . 0 . .
1 . 1 . 0
1 . . . .
. . . . .


What Does the Program Do With Hypotheses?

It reduces them in any of three different ways depending what mode you have
set (see adjustments option, learning test menu), and it makes inferences from
them, or at least the portions it didn't throw out in the reduction.


What are the Hypothesis Reduction Modes?

As explained by the adjustment routine, mode 1 trashes the whole hypothesis if
even one bit is implausible. Mode 3 assumes that if several bits are in
conflict the most commonly conflicting ones are errors and gently trashes only
those most offensive bits, going back then to recheck the remaining bits for
conflicts and possible removal. This process works upward starting with
individual bits in conflict only with themselves, then proceeding to check
conflicts in pairs of bits and finally trios of bits. This avoids situations
where a single bit, constant in all learned patterns and assigned the wrong
value in the hypothesis, seems incompatible with correct bits. Anyway, use
mode 1 for checking hypotheses, mode 3 for correcting them, and mode 2 when
you're in the mood for an intermediate kludge.



What Does it Mean When Inference Shows a Lot of Periods?

The periods signify bits which could go either way, 1 or 0, given what was
left of the hypothesis after reduction. A search routine is provided
which will sniff out complete patterns which seem compatible with the reduced
hypothesis. It's there simply to prove that there are multiple complete
solutions to some hypotheses some times.



Why was this program written, and is it significant?

Well, I got started and couldn't seem to quit.

For one thing, this layered network scheme obviously will do an XOR.
Yet it doesn't have a lot of differences from the things in
Minsky's crude sketches. Maybe Minsky didn't consider that signals could be
added/subtracted to yeild a quantitative result, possibly encoded as a
frequency. I have to admit that Minsky must be smarter than me because reading
his stuff makes my ears ring and my vision go dim.

For another thing, superficial reasoning seems to be a little more thorough
and flexible than a Hopfield net. Hopfield buried his discussion of keeping
the argument bits constant in an odd place in his article and it hasn't been
picked up by most; I checked Matheus and Jorgensen's demo program against the
article and thought it was right, but Hopfield inference SHOULD specify the
argument subset of the input and hold it invariant and the demo didn't.
Hopfield didn't think about truth tables and I think he should have. Hopfield
is smarter than me too. However, he only described a net with equivalent
NetDepth of about 2. Higher values are practical.

Beyond that, I can't say. For my part, I figure my next steps are as follows:

1. Work out algorithms for hypothesis reduction and inference algorithms that
bypass truth table reconstruction and work directly from the counts in the
layered networks.

2. Study ways of taking better advantage of the statistical nature of the
generated database. Notably the probability of a pattern as a whole is no
larger than that of the least probable subpattern.

2. Dream up a hardware implementation, just to see if it can be done on paper.

3. Explore applications. Tentatively it seems that, despite popularity of the
idea of showing the computer examples instead of programming it, a person
could die of old age showing enough examples for a complex problem; the most
likely appications are probably going to be in analyzing existing data and
data that is automatically obtained in machine readable form.



For those who want to compile and run this program, here are a few clues.

This code WILL run under both Lightspeed C (on my Mac) and under TurboC
(on my clone) with the indicated changes: adjust the syntax of the
#include stdio instruction if required and substitute getche() for
getchar() in the Key() routine in Turbo C. The difference in the
code returned by the return key is compensated for empirically when the
program starts up... if this seems klutzy, just modify the setup routine
to set up the keycode for your system (10 for macs, 13 for toshiba laptop).

Unfortunately, this explanatory header makes the sourcecode file too large
for the Turbo C editor... rip it out with another editor (I used the Turbo
Prolog editor) and the file will be manageable.

*/





/*----------------------------------------------------------------------*/

#include "stdio.h" 	/*
					under turbo C on clones use <stdio.h> syntax sometimes;
					on Mac under Lightspeed C use "stdio.h" syntax.
					*/

/*----------------------------------------------------------------------*/



/*------------------------------------------------------------------------*/

/*
PATCH HERE PATCH HERE PATCH HERE PATCH HERE PATCH HERE PATCH HERE 

Key input routine must fetch a keyboard key and echo it to the screen.
All operations using getchar() are routed through this routine to make
patching convenient on systems where getchar() does not echo on the screen.
Use getchar() on Mac under Lightspeed C.
Use getche() instead of getchar() under Turbo C on clones.
*/

char
Key()
/* get a key from user, echoing to screen */
{
/* use this patch under Lightspeed C on Macintosh: */
return getchar();

/* use this patch under Turbo C on clones: */
/* return getche(); */

}

/*------------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

/* Routines from the probmain.c file...  */

	/* principle routines */
	void main();
	void LearnPat();
	void ForgetAll();
	void CheckTable();
	void Adjust();
	void RedInf();
	void Explain();

	/* support routines */
	void 				setup();
	void				FixDepth();
	void 				GetFrame();
	void 				GetHypothesis();
	void 				ShowGrid();
	void 				getreturn();
	unsigned long int 	getvalue();
	char 				Key();

/* Routines from the Bit Table Algorithms file...  */
	unsigned long int 	BitValue();
	void				SetBit();
	void				ClearBit();
	unsigned long int 	TableBitValue();
	void				SetTableBit();
	void				ClearTableBit();

/* Routines from the combalg.c file... */
unsigned long int 	NetSize();
void 				Offset();
void 				BitNumbers();
unsigned long int 	NextOffset();
unsigned long int 	PreviousOffset();

/* other routines */
void				Learn();
void				Reconstruct();
unsigned long int	Reduce();
void				Infer();
void				LineNumSetup();
void				PatNumSetup();
void				Search();
unsigned long int	CheckBit();




/*----------------------------------------------------------------------*/

struct NetInfoBlock
	{
	unsigned long int	offset;			/* C */
	unsigned long int	inputwidth;		/* n */
	unsigned long int	logicdepth;		/* k */
	unsigned long int	*bitnumbers;	/* a[] */
	};

/*
NOTE: This structure is used in various places, in conjunction with the
routines in the combalg.c file, to generate all combinations of k out of
n indices for various purposes and to generate unique storage offsets
for items identified by such combinations of indices.
*/
/*----------------------------------------------------------------------*/



unsigned long int	
	side=5;
/* The number of bits across the input grid. The value can be increased but
only at the risk of running out of memory. A 5 by 5 or smaller array of
input bits is assumed in allocations below, ie an input width of 25 overall. */


unsigned long int	
	InWidth;
/* The number of input lines, equal to side*side when using square input
grid. */


unsigned long int	
	TheDepth=3; 		
/* The number of input lines for a probabilistic truth table which records
how often every possible binary pattern has appeared on those lines. For
a NetDepth value of 3 there are eight possible patterns. TheDepth is
used to control learning and does not vary. NetDepth, an adjustable
equivalent, is used to control access to stored learning.*/


unsigned long int	
	NetDepth=3; 		
/* An effective, adjustable value of TheDepth which is used in accessing
the information stored in learning. */


unsigned long int 
	TableSize=8;
/* The number of possible patterns which can be carried on the number of 
input lines specified by NetDepth above; 8 for NetDepth=3, 4 for 
NetDepth=2, etc. In other words, 2 raised to the power of NetDepth. */


unsigned long int 
	PatNum[8];
/* A list of Pattern Numbers beginning with the pattern that contains
all k bits true, proceding to values that have (k-1) bits true, and 
continuing on through collections of values with fewer and fewer bits
till the 0-bit value "0" is reached, ie 7, 6, 5, 3, 4, 2, 1, 0 for k=3.
'k' here is synonymous with NetDepth and the size of the PatNum array
should be no smaller than TableSize.
This quirky little array is used to reconstruct probabilistic truth
tables, ie tables of counts of how many times each possible pattern of
a particular group of NetDepth input lines has occurred, from counts 
in a series of layered networks showing how many times each combination
of 0, 1, 2 ... NetDepth input lines has occurred true simultaneously.
*/

unsigned long int 
	LineNum[32];
/* A collection of line number groups delimited by trailing zeros. The
non-zero elements are indices to lines in an array of input line numbers
numbered 1 through NetDepth. A LineNum element of zero marks the end of
a group. The number of groups is equal to TableSize, and each group
contains 0 to NetDepth indices. Line number groups reflect numerical 
order with lineNetDepth (rightmost left-to-right numbered array) assigned a
weight of 1.

Sequence of values and groups for NetDepth 3 would be
		Index
Group	Group
0		0			
1		3 0
2		2 0
3		2 3 0
4		1 0
5		1 3 0
6		1 2 0
7		1 2 3 0

*/

	
unsigned long int 
	DataNets[2626];
/* 	The area where learning is stored. 2626 is nominal for testing only.
It provides for 4 network layers covering a 5 by 5 25-bit input array;
layers have 1, 25, 300, and 2300 counts respectively. Note that the layering
scheme provides a memory saving of about 86% compared to a scheme of 2300
tables each with 8 counts. */

unsigned long int 
	*NetPtrs[4];
/*  An array of pointers to individual network layers within DataNets.
For a 5 by 5 25-bit input array, offsets of 0, 1, 26 and 326 are added to
the base address DataNets. */


unsigned long int
	InputArray[64];
/* Space allocated for storage of input patterns. 64 long unsigned integers
provide 1024 contiguous bits on a 16-bit machine, 2048 on a 32-bit system.
Either way, plenty of space; storage of learning is generally the limiting
requirement and approaches InWidth raised to the power of NetDepth as
InWidth increases. */


/*
Similar arrays are used for specifying a hypothetical pattern or partial 
pattern and reporting bits infered from that hypothesis as follows:
*/ 
unsigned long int 
	HypeMask[64], 	/* shows which bits are in hypothesis */
	HypeBits[64],	/* shows hypothesized bit's values */
	InfrMask[64],		/* shows which bits are inferred */
	InfrBits[64];	/* shows inferred bit's values */


unsigned long int 
	MinCount=1;
/* The criterion count to which pattern occurance counts are compared. A
pattern of values which has not occurred at least this many times is
deemed to be implausible in the hypothesis reduction and inference
proceses. Normal value is 1. */ 


unsigned long int 
	Mode=3;
/* A parameter whose value controls the operation of the Reduce routine. The 
permissable values are 1 for peremptory reduction in which entire hypothesis
is blitzed for any inconsistency, 2 for solomonic reduction in which all
lines involved in any conflict are eliminated, and 3 for progressive reducton
in which the most commonly conflicting lines are eliminated progressively 
until no conflicts remain.*/



char
	RtnKey=10; 
/* Value returned by depresion of return or enter key;
varys on different systems. Use 13 for clones under Turbo C. */





/*----------------------------------------------------------------------*/

void
main()
{
/*
first set up system parameters, 
then get selection, execute selection, repeat
*/

char choice;

printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
printf("KNET version 3.0\n");
printf("by Peter H. Kosel, 1345 56th St., Sacramento, CA 95819\n");
printf("\n\n\n\n\n\n\n\n");


setup();
do	{
	printf("\n");
	printf("MAIN MENU:\n\n");
	
	printf("  1. Learn a pattern.\n\n");

	printf("  2. Examine a probabilistic truth table.\n");
	printf("  3. Test hypothesis reduction and inference.\n");
	printf("  4. Search out plausible patterns automatically.\n\n");

	printf("  5. Change operating parameters.\n");
	printf("  6. Forget stored learning.\n");
	printf("  7. Quit.\n\n");
	
	printf("Hit number for option (1 thru 7) ...");
	choice = Key() - '0';
	printf("\n");
	switch(choice)	
		{
		case 1:  LearnPat(); 	break;

		case 2:  CheckTable();	break;
		case 3:  RedInf();		break;
		case 4:  Search();		break;

		case 5:  Adjust();		break;
		case 6:  ForgetAll();	break;
		}
		
	}
while (choice != 7);
}

/*----------------------------------------------------------------------*/




/*----------------------------------------------------------------------*/

void
setup()
{
unsigned long int i;

/* Get actual return key code for this system. */
printf("Return Key Synchronization: hit the RETURN key and NO OTHER...");
RtnKey=13;
do{ RtnKey=Key(); } while (RtnKey==0);
i = RtnKey;
printf("\nCode returned by return key = %lu \n",i);
getreturn();


/* set up NetDepth, TableSize, PatNum[], & LineNum[] values */
FixDepth(TheDepth);

/* Calculate InWidth for square input grid. */
InWidth = side*side;

/* set up NetPtrs */
NetPtrs[0]=DataNets;
for (i=1;i<=NetDepth;i++) NetPtrs[i]=NetPtrs[i-1]+NetSize(InWidth,i-1);

/* Clear appropriate arrays. 
*/
for ( i=0; i<(sizeof(DataNets)/sizeof(i)); i++ ) 
	DataNets[i] = 0;
for ( i=0; i<(sizeof(InputArray)/sizeof(i)); i++ )
	{
	InputArray[i]= 0;
	HypeMask[i]= 0;
	HypeBits[i]= 0;
	InfrMask[i]= 0;
	InfrBits[i]= 0;
	}


}
/*----------------------------------------------------------------------*/




/*----------------------------------------------------------------------*/

void
FixDepth(value)
unsigned long int
	value;
{

NetDepth=value;

/* Calculate the number of bits in a truth table. */
TableSize = 1 << NetDepth;


{
/* PatNum[] setup */
unsigned long int	ThisPat,
					i,
					j,
					ShiftVal,
					BitCount,
					pos;
	
	
ThisPat=TableSize;
for	(i=0; i<=NetDepth; i++)
	{
	
	for	(j=0; j<TableSize; j++)
		{
		ShiftVal = j;
		BitCount=0;
		for(pos=1; pos<=NetDepth; pos++)
			{
			if(ShiftVal & 1) BitCount++;
			ShiftVal = ShiftVal>>1;
			}
		if( BitCount == i )
			{
			ThisPat--; PatNum[ThisPat]=j;
			}
		}
	}
}




{
/* LinNum[] setup */
unsigned long int
	ThisNum,
	i,
	j;
struct NetInfoBlock
	CombBloc;

ThisNum=0;
for	(i=0;i<TableSize;i++)
	{
	j=NetDepth;
	do
		{
		j--;
		if( i & (1<<j) )
			{
			LineNum[ThisNum]=NetDepth-j;
			ThisNum++;
			}
		}while(j!=0);
	LineNum[ThisNum]=0;
	ThisNum++;
	}


}

}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
LearnPat()
{
unsigned long int
	Weight;

GetFrame();
printf("\nPlease enter an observation count...");
Weight=getvalue();
printf("\n\n");
Learn(InWidth, InputArray, NetPtrs, TheDepth, Weight);
}
/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/
void
ForgetAll()
{
unsigned long int
	answer,
	i;

	printf("\n\n\nFORGET ALL STORED LEARNING??  Are you SURE? (y/n)? ...  ");
	answer = Key();
	printf("\n");
	if ((answer=='y')||(answer=='Y'))
		{
		for ( i=0; i<(sizeof(DataNets)/sizeof(i)); i++ ) 
			DataNets[i] = 0;
		printf("OK, it's forgotten.\n");
		getreturn();
		}
}
/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
CheckTable()
/* allows examination of probabilistic truth table for any group of
NetDepth input lines. */
{
unsigned long int 
	i,
	j,
	k,
	n,
	a[8],
	limit,
	IndexGood,
	bit,pattern,
	one=1;
unsigned long int 
	Table[8]; /* enough space for NetDepth <=3 */

k=NetDepth;
n=InWidth;

printf("\n\n");
printf("A Probabilistic truth table shows occurrence counts for\n");
printf("each possible value pattern of a group of bits.\n\n");
printf("Please specify which table you want by it's bit numbers.\n");
printf("Bits in the array are numbered left to right progressively through\n");
printf("the rows from top, starting with '1' for 'first bit, first row'.\n\n");

/* get bit numbers */
for (i=1;i<= k;i++)
    {
	do
		{
		printf("Enter bit number a[%lu] from ",i);
		if (i!=1) 
			{ printf("%lu",(a[i-1]+1));} /* last entry +1 */
		else 
			{printf("%lu",i);} /* 1 */
		limit=n-k+i;
		printf(" to %lu ...",limit);
		a[i]=getvalue();
		if  (
			( (i==1) && (a[i]>=1) && (a[i]<=(n-k+i)) )
            ||
            ( (i>1) && (a[i]>=a[i-1]+1) && (a[i]<=(n-k+i)) )
            )
		{ IndexGood = 1; }
        else 
        { IndexGood = 0; }
        }
    while ( ! IndexGood ) ;
    }

/* Get probtable from bit numbers */
Reconstruct(a, Table);

/* print table heading */
printf("\nPattern occurrence counts so far for bits ");
for (i=1;i<=k;i++)
	{
	printf("%lu",a[i]);
	if(i==k)
		printf(":");
	else
		printf(", ");
	}
printf("\n");

/* print table entries */
	/* for every binary pattern... */
	for (i=0;i<=(TableSize-1);i++)
		{
		/* show the bit values for the pattern */
		pattern = i;
		printf("Pattern:");
		for (j=1;j<=k;j++)
			{
			bit=pattern&(one<<(k-j));
			if(bit)
				{ printf("1 "); }
			else
				{ printf("0 "); }
			}
		/* show count for the pattern */
		printf(" Count:%lu\n",Table[i]);
		}
printf("\n");
getreturn();
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
Adjust()
{
unsigned long int
	choice;



do	{
	printf("\n\nCurrent Status:\n");
	printf("NetDepth = %lu\n",NetDepth);
	printf("MinCount = %lu\n",MinCount);
	printf("Mode = %lu\n\n",Mode);

	printf("ADJUSTMENT MENU:\n");
	
	printf("1. Adjust effective NetDepth.\n");
	printf("2. Adjust the MinCount criterion.\n");
	printf("3. Adjust Hypothesis Reduction Mode.\n");
	printf("4. Leave things as they are.\n\n");
	
	printf("Hit number for option (1 thru 4) ..."); choice = Key() - '0';
	printf("\n\n\n");
	switch(choice)	
		{
		case 1:	/* NetDepth adjustment */
				{
				printf("NetDepth controls effective truth table size.\n");
				printf("You may examine truth tables at various\n");
				printf("NetDepth settings to see results.\n");
				printf("Hypothesis reduction and inference are affected\n");
				printf("by the NetDepth setting. Learning is always to\n");
				printf("depth 3; NetDepth affects only utilization of the \n");
				printf("learned information. Depths of 1, 2, or 3 may be \n");
				printf("selected; higher depths are feasible but not\n");
				printf("implemented here.\n\n");
				do
					{
					printf("Hit number for depth desired (1, 2 or 3)...");
					NetDepth = Key() - '0'; printf("\n");
					}
				while( (NetDepth<1) || (NetDepth>3) );
				FixDepth(NetDepth);
				}
				break;
		
		case 2: /* MinCount adjustment */
				{
				printf("MinCount specifies how many times a pattern must\n");
				printf("occur to be recognized as plausible.\n");
				printf("MinCount's value affects hypothesis reduction\n");
				printf("and inference.\n\n");
				printf("\nEnter a value for MinCount...");
				MinCount=getvalue();
				printf("\n");
				}		
				break;
				
		case 3:	/* Mode adjustment */
				{
printf("\n\nHypothesis Reduction Modes are:\n");
printf("  Mode 1 - entire hypothesis rejected if conflict found.\n");
printf("  Mode 2 - all bits in any conflicting group rejected.\n");
printf("  Mode 3 - most commonly conflicting bits rejected progressively.\n");
				do
				{
				printf("Hit number for mode desired (1, 2 or 3)...");
				Mode = Key() - '0'; printf("\n");
				}
				while( (Mode<1) || (Mode>3) );
				}
				; break;
		}
	}
while (choice != 4);

}
/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/
void
RedInf()
{
/* abort if learned pattern count = 0 */
if(! *NetPtrs[0] )
	{
	printf("\nNo patterns have been learned. Go to main menu item 1!\n");
	getreturn();
	return;
	}

/* get hypothesis */
GetHypothesis();

/* Clean up the hypothesis using current settings of Mode and MinCount */
Reduce	( HypeMask, HypeBits, MinCount, Mode );

/* display cleaned up hypothesis */
printf("\n");
printf("Hypothesis after mode %lu style cleanup:",Mode);
ShowGrid(HypeMask, HypeBits);
getreturn();

/* infer what can be inferred */
Infer ( HypeMask, HypeBits, InfrMask, InfrBits );

/* display what can be inferred from the hypothesis */
printf("\n");
printf("Bits inferred from reduced hypothesis:");
ShowGrid(InfrMask, InfrBits);
getreturn();

/* display resulting composite */
{
unsigned long int
	i;
for(i=1; i<=InWidth; i++)
	{ if( BitValue(InfrMask,i) )
		{
		SetBit(HypeMask,i);
		if( BitValue(InfrBits,i) )
			SetBit(HypeBits,i);
		else
			ClearBit(HypeBits,i);
		}
	}
}
printf("\n");
printf("Composite of inferred bits and surviving hypothesis bits:");
ShowGrid(HypeMask, HypeBits);
getreturn();
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/
void
Explain()
{
printf("explanation not installed yet\n");
getreturn();
}
/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
GetFrame()
/*
Get bit values from user and put them in the input array.
The bits are entered in a square array to aid user visualization.
An alternative would be to solicit answers to an extensive list of
true-or-false questions.
*/

{
unsigned long int
	i,
	row,
	col,
	ThisBit;
char chr, answer;

do	{
	printf("\n");
	printf("Enter a %lu by %lu array of bit values.\n",side,side);
	printf("Use a space, zero or minus for 0, other characters for 1.\n");
	for(row=1;row<=side;row++)
		{
		for	(col=1;col<=side;col++)
			{
			printf(" ");
			chr=Key();
			ThisBit = side*(row-1) + col;
			if ( (chr ==' ') || (chr =='0') || (chr =='-') )
				{
				ClearBit(InputArray,ThisBit);
				}
			else
				{
				SetBit(InputArray,ThisBit);
				}
			}
		printf("\n");
		}	
	printf("\n");
	
	for(i=1; i<=InWidth; i++ ) SetBit(InfrMask,i);
	ShowGrid(InfrMask,InputArray);
	printf("Is this correct?(y/n)...");
	answer = Key();
	printf("\n");
	}
while((answer!='y')&&(answer!='Y'));
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
GetHypothesis()
/*
Get hypothesis bit locations and values to be included and put them in the
masks. The bits are entered in a square array. A period is used to mark
bits which are excluded from the hypothesis. 
*/

{
unsigned long int 	row, col, ThisBit;
char chr, answer;

do	{
	printf("\n");
	printf("A 'hypothesis' is a partial array of bits.\n");
	printf("Enter a %lu by %lu array of bit values.\n",side,side);
	printf("Use a period (.) to mark bits NOT in the hypothesis.\n");
	printf("Mark bits which ARE in the hypothesis with a space\n");
	printf("or a zero for '0' and some other character for 1.\n");
	
	for(row=1;row<=side;row++)
		{
		for	(col=1;col<=side;col++)
			{
			printf(" ");
			chr=Key();
			ThisBit = side*(row-1) + col;
			if ( chr =='.' )
				{
				ClearBit(HypeMask,ThisBit);
				}
			else
				{
				if ( (chr ==' ') || (chr =='0') )
					{
					SetBit(HypeMask,ThisBit);
					ClearBit(HypeBits,ThisBit);
					}
				else
					{
					SetBit(HypeMask,ThisBit);
					SetBit(HypeBits,ThisBit);
					}
				}
			}
		printf("\n");
		}	
	ShowGrid(HypeMask, HypeBits);
	printf("Is this correct?(y/n)...");
	answer = Key();
	printf("\n");
	}
while((answer!='y')&&(answer!='Y'));
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
ShowGrid(GridMask,GridVals)
unsigned long int
	*GridMask,
	*GridVals;
{
unsigned long int 	row, col, ThisBit;
printf("\n");
for(row=1;row<=side;row++)
	{
	for	(col=1;col<=side;col++)
		{
		ThisBit = side*(row-1) + col;
		if (BitValue(GridMask,ThisBit))
			{
			if (BitValue(GridVals,ThisBit))
				printf("*");
			else
				printf("-");
			}
		else
			printf(".");
		printf(" ");
		}
	printf("\n");
	}
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void getreturn()
/* let reader read the output */
{
char chr=0;
printf("hit return...") ;/* issue prompt */
while(chr!=RtnKey)chr=Key();
if (RtnKey==13) printf("\n"); /* space down on clones */
}

/*------------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

unsigned long int
getvalue()
/* get a no-nonsense multidigit decimal integer from keyboard */
{
char chr=0;
unsigned long int value=0;
/* prompt is provided by calling routine */
while(chr!=RtnKey)
	{
	chr=Key();
	if((chr>='0')&&(chr<='9')) value = 10 * value + chr - '0';
	if( !( ((chr>='0')&&(chr<='9')) || (chr==RtnKey) ) )
		{
		value = 0;
		printf(" No you don't!\nTry again...");
		}
	}
printf("\n");
return value;
}

/*------------------------------------------------------------------------*/







/*------------------------------------------------------------------------*/

/* routines in the combalg.c file... */

unsigned long int 	NetSize();
void 				Offset();
void 				BitNumbers();
unsigned long int 	NextOffset();
unsigned long int 	PreviousOffset();

/*----------------------------------------------------------------------*/


unsigned long int
NetSize(n,k)
unsigned long int n,k;
/* find number of truth tables given n, k */

{
unsigned long int S,i;

S = 1;
for (i = 1; i <= k; i = i+1 )
    {
    S = ( S * (n+1-i) ) / i ;
    /* Note that the division always comes out integer for some reason. 
      Try it if you don"t believe! Not a remainder in a carload!
    */
    }
return S;
}


/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/


void
Offset(input)
struct NetInfoBlock *input;
/* find offset from bit numbers */
{
unsigned long int C,z,nn,kk,i;

unsigned long int n,k,*a;

n = input->inputwidth;
k = input->logicdepth;
a = input->bitnumbers;

z = 0;
C = 0;
kk = k;
nn = n;
for( i = 1 ; i <= k ; i = i+1 )
    {
    C = C + NetSize( nn,kk ) - NetSize( (nn + z + 1 - a[i]) , kk );
    kk = kk - 1;
    z = a[i];
    nn = nn - a[i];
    }
input->offset = C;
}


/*----------------------------------------------------------------------*/




/*----------------------------------------------------------------------*/


void
BitNumbers(input)
struct NetInfoBlock *input;
/* find bit numbers from offset */

{
unsigned long int
i /* points to one of k bit numbers */
,R /* not exactly a remainder but... */
,CC ,nn, /* transdimensional dummy values */
C,n,k,*a;

C = input->offset;
n = input->inputwidth;
k = input->logicdepth;
a = input->bitnumbers;

CC = C;
nn = n;
for( i = 1 ; i <= k ; i++ )
    {
    a[i] = n-k+i; /* start with max value */
    R = NetSize(nn,k-i+1) - CC; /*tip off the triangle, top off the pyramid*/
    while ( NetSize(n-a[i]+1,k-i+1) < R ) 
    	{ a[i] = a[i]-1; } /* find a good one */
    CC = NetSize(n-a[i]+1,k-i+1) - R; /* Warp factor 9, Mr Sulu! */
    nn = n-a[i];
    }
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/


unsigned long int
NextOffset(input)
struct NetInfoBlock *input;
/* increment offset and adjust bit numbers */
{
unsigned long int n,k,*a,i;
unsigned long int UnFeasibilityFlag;

n = input->inputwidth;
k = input->logicdepth;
a = input->bitnumbers;

/* look for largest non-max index */
i = k;
while ((i!=1) && ((n-k+i)==a[i]))
	{ i = i - 1 ;}

/* look over what you found */
if (( n - k + i )==a[i])
	{ UnFeasibilityFlag = 1 ;} /* because a[1] is maxed out */
else	
	{ 
	UnFeasibilityFlag = 0;
	input->offset = input->offset + 1;
	a[i]= a[i] + 1; /* increment index you found */
	i= i+1; /* starting with the next bit number if any... */
	while(i<=k)
		{
		/* ... set any higher bit numbers to min value */
		a[i] = a[i-1]+1;
		i = i+1;
		}
	}
return UnFeasibilityFlag;
}


/*----------------------------------------------------------------------*/



/*------------------------------------------------------------------------*/

unsigned long int
PreviousOffset(input)
struct NetInfoBlock *input;
/* decrement offset and adjust bit numbers */

{
unsigned long int n,k,*a,i;
unsigned long int UnFeasibilityFlag;

n = input->inputwidth;
k = input->logicdepth;
a = input->bitnumbers;

/* look for highest ranking non-min index */
i = k;
while ((i!=1) && ((a[i-1]+1)==a[i]))
	{ i = i - 1; }
	
/* look over what you found */
if (a[i]==1)
	{ UnFeasibilityFlag = 1 ;} /* because a[1] is at min=1 */
else
	{ 
	UnFeasibilityFlag = 0 ;
	input->offset = input->offset - 1;
	a[i] = a[i]-1; /* decrement bit number you found */
	i=i+1; /* starting with the next bit number if any... */
	while (i<=k)
		{
		/* ...set any higher bit numbers to max value */
		a[i]=(n-k+i);
		i=i+1;
		}
	}
return UnFeasibilityFlag;
}

/*----------------------------------------------------------------------*/






/* Routines in the Bit Table Algorithms file:  */
	unsigned long int 	BitValue();
	void				SetBit();
	void				ClearBit();
	unsigned long int 	TableBitValue();
	void				SetTableBit();
	void				ClearTableBit();




/*----------------------------------------------------------------------*/

unsigned long int
BitValue(BitArrayAddr, BitOffset)
unsigned long int *BitArrayAddr,BitOffset;

/* fetches the value of a bit out an array of umpteen bits */

{
unsigned long int 
	bit, 
	LUI ;
LUI = sizeof(LUI) * 8; /* number of bits in an unsigned long integer */
bit = 	(
		BitArrayAddr[BitOffset/LUI] /* integer division is rounded off */
		>>
		( LUI - 1 - ( BitOffset % LUI ) )
		)
		& 1;
return bit;
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
SetBit(BitArrayAddr, BitOffset)
unsigned long int *BitArrayAddr,BitOffset;

/* sets the appropriate bit in a multiword bit array to 1*/

{
unsigned long int 
	LUI,
	one = 1 ;
LUI = sizeof(LUI) * 8; /* number of bits in an unsigned long integer */

BitArrayAddr[BitOffset/LUI] = 	BitArrayAddr[BitOffset/LUI] 
								| 
								( one << ( LUI-1 - (BitOffset % LUI) )
								);
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
ClearBit(BitArrayAddr, BitOffset)
unsigned long int *BitArrayAddr,BitOffset;

{
unsigned long int
	mask,
	LUI,
	one = 1;
LUI = sizeof(LUI) * 8; /* number of bits in an unsigned long integer */

mask=0xFFFFFFFF ^ (one << (LUI-1 - (BitOffset % LUI) ));
BitArrayAddr[BitOffset/LUI] = BitArrayAddr[BitOffset/LUI] & mask;
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

unsigned long int
TableBitValue(BitArrayAddr,TableOffset,StateNumber)
unsigned long int *BitArrayAddr,TableOffset,StateNumber;
{
BitValue(BitArrayAddr,TableOffset * TableSize + StateNumber);
}

/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/
void
SetTableBit(BitArrayAddr,TableOffset,StateNumber)
unsigned long int *BitArrayAddr,TableOffset,StateNumber;
{
SetBit(BitArrayAddr,TableOffset * TableSize + StateNumber);
}
/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/
void
ClearTableBit(BitArrayAddr,TableOffset,StateNumber)
unsigned long int *BitArrayAddr,TableOffset,StateNumber;
{
ClearBit(BitArrayAddr,TableOffset * TableSize + StateNumber);
}
/*----------------------------------------------------------------------*/






/*
Learning Algorithm for Layered Probabilistic Network Scheme

Outline of Routine:

for each network (k=0 to k=TheDepth)
for each combination of k (for that network) out of n input lines
if signals on the input lines are all true, increment the appropriate count

Notes:

The layered networks are stored in order of size, smallest first.

Location of each individual network is found by adding the size of the
smaller, preceding networks to the base address of the layered structure.

The combalg routine NextOffset is used to index through combinations
of input lines for each net.

Note that learning uses TheDepth, the permanent net depth setting,
rather than NetDepth, the nominal value which controls access to stored
learning.
*/


/*----------------------------------------------------------------------*/
void
Learn(n, PatLoc, NetPtrs, TheDepth, Weight)
unsigned long int 	n,			/* pattern size in bits */
					*PatLoc,	/* Pointer to pattern bit storage */
					**NetPtrs, 	/* pointer to array of net locations */
					TheDepth,	/* the number of network layers -1, ie
								   number of lines in reconstructed tables */
					Weight;		/* number of times to 'observe' pattern */
/*
Learning Algorithm for Layered Probabilistic Network Scheme
Increment appropriate counts in every network layer.
*/

{
unsigned long int
	NetIndex,
	*NetLoc,
	*CountLoc,
	AllTrue,
	Lines[32],
	i,
	count,
	NoMoreOffsets;
	
struct NetInfoBlock LineComboBlock;

/* General preparation of the info block. */
LineComboBlock.bitnumbers = Lines;
LineComboBlock.inputwidth = n;

/*
Increment the single count in the first, "no-lines" network which
serves as a count of the number of patterns observed
*/
NetLoc = NetPtrs[0];
*NetLoc = *NetLoc + Weight;

/* Loop through remaining network layers */
for ( NetIndex=1; NetIndex<=TheDepth; NetIndex++ )
{
/* set up net location */
NetLoc = NetPtrs[NetIndex];

/* adjust infoblock logicdepth for this network */
LineComboBlock.logicdepth = NetIndex;

/* adjust infoblock offset and "bitnumbers" indices to first offset */
LineComboBlock.offset = 0;
BitNumbers(&LineComboBlock);

/* loop through all offsets, ie all combos of lines */
do	{
	
	/* increment count if all lines are true */
	AllTrue=1;
	for ( i=1; i<=NetIndex; i++ )
		{
		if ( ! BitValue(PatLoc,LineComboBlock.bitnumbers[i]) )
			AllTrue = 0;
		}
	if 	(AllTrue)
		{
		CountLoc = NetLoc + LineComboBlock.offset;
		*CountLoc = *CountLoc + Weight;
		}
	
	/* set up next combination of input lines if possible */
	NoMoreOffsets = NextOffset(&LineComboBlock);
	
	}
	while(!NoMoreOffsets);

} /* end of loop through network layers */

} /* end of routine */
/*----------------------------------------------------------------------*/







/*----------------------------------------------------------------------*/
void
Reconstruct(Lines, Table)
unsigned long int
	*Lines,
	*Table;
/*
Reconstruct() delivers a probabilistic truth table in the Table
array, for the input lines specified in the Lines array. The table is
derived from counts in the layered networks which are updated by the
Learn() routine. 

There are layered networks for 0, 1, 2, ...k out of n input lines.
Each network layer contains counts of how many times each combination
of input lines has been OBSERVED TRUE SIMULTANEOUSLY. The network for 0
input lines contains a single count reflecting the total number of
observations (total of all learning weights).

Counts are first fetched from the layered networks, then the
collection of counts is solved to find the probabilistic truth table.

This is facilitated by 2 precalculated arrays, PatNum[] and LineNum[].
PatNum[] controls conversion of raw counts from the layered networks to
a probabilistic truth table. LineNum[] supports count fetching from the
layered networks. Both arrays are calculated for a specific NetDepth; see
the FixDepth routine for calculation procedures. Note that LineNum[]
contains a sort of simple program in a very simple control language
where any value but zero is used as an index and values of zero
terminate sequences of indices.

Note that this routine is complex and slow because it is generalized
to deal with different NetDepth values.

*/
{
unsigned long int
	Count[8];

/* Fetch counts from the layered networks. */
	{
	unsigned long int
		TheseLines[8],
		ThisLine,
		ThisNum,
		CountPos,
		*CountLoc;
	struct NetInfoBlock
		CombBloc;
	
	ThisNum = 0;
	CombBloc.inputwidth = InWidth;
	CombBloc.bitnumbers = TheseLines;
	
	for	(CountPos=0;CountPos<TableSize;CountPos++)
		{
		CombBloc.logicdepth = 0;
		CombBloc.offset = 0;
		ThisLine = 1;
		while(LineNum[ThisNum] != 0)
			{
			TheseLines[ThisLine] = Lines[LineNum[ThisNum]];
			ThisLine++;
			ThisNum++;
			CombBloc.logicdepth++;
			}
		if(CombBloc.logicdepth) Offset(&CombBloc);
		CountLoc = NetPtrs[CombBloc.logicdepth] + CombBloc.offset;
		Count[CountPos] = *CountLoc;
		ThisNum++;
		}
	}


/*
Convert the list of retrieved counts into a probabilistic truth table using
the PatNum masks.
*/
	{
	unsigned long int
		OtherCounts,
		i,
		j;
		
	for ( i=0; i<TableSize; i++ )
		{
		OtherCounts = 0;
		for ( j=0; j<i; j++ )
			{
			if ( (PatNum[i]&PatNum[j]) == PatNum[i]) 
				{
				OtherCounts = OtherCounts + Table[PatNum[j]];
				}
			}
		Table[PatNum[i]] = Count[PatNum[i]] - OtherCounts;
		}
	}



}
/*----------------------------------------------------------------------*/









/*------------------------------------------------------------------------*/
/* routines in the reduce.c file... */
unsigned long int 		Reduce();

/* Routines in the Bit Table Algorithms file:  */
	unsigned long int 	BitValue();
	void				SetBit();
	void				ClearBit();
	unsigned long int 	TableBitValue();
	void				SetTableBit();
	void				ClearTableBit();

/* routines in the combalg.c file... */

unsigned long int 	NetSize();
void 				Offset();
void 				BitNumbers();
unsigned long int 	NextOffset();
unsigned long int 	PreviousOffset();

/*------------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

unsigned long int
Reduce	( HypeMask, HypeBits, MinCount, Mode )
unsigned long int 
	*HypeMask, 
	*HypeBits, 
	MinCount,
	Mode;

/*
NOTE:
The Reduce routine eliminates bits from a hypothesis if their hypothesized
values do not have sufficient precedent in the patterns that have been
learned. The global variable "MinCount" specifies how many times a pattern
must have occurred to be considered plausible.

Reduce is written to handle any net depth or hypothesis size; hypotheses
smaller than current NetDepth present difficulties but Reduce deals with
them.

Reduce operates in three modes: mode 1 is peremptory rejection of the
hypothesis if any conflict is found. Mode 3 searchs out the most commonly
offending bits and trashes them, potentially useful for error correction.
mode 2 is an intermediate kludge.

Reduce returns a count of the number of bits it trashed from the hypothesis.
If this count is 0, no conflicts were found.
*/

{
unsigned long int
	Depth,
	i,
	HCount,
	HLine[26],
	TheseLines[4],
	ThisLine,
	Lines[9],
	Table[8],
	NextLine,
	FillCnt,
	PatMask,
	Pattern,
	BadCombo,
	GoodCnt,
	Indexes[4],
	one=1,
	BadCount[26],
	BadMax,
	BadFlag,
	OutCount=0
	;
struct NetInfoBlock CombBloc;


/* abort if no learning yet */
if(! *NetPtrs[0] ) return OutCount;

/* count hypothesis lines and list line numbers */
HCount=0;
for(i=1; i<=InWidth; i++)
	{
		if ( BitValue(HypeMask,i)  )
			{
			HCount++ ; 
			HLine[HCount] = i;
			}
	}

/* quit early indicating no reduction if no hypothesis lines counted */
if (HCount==0) return OutCount;


/* begin loop for iteration of the line group size, "Depth" */
Depth=1;

/* no iteration in "peremptory" mode */
if (Mode == 1)
	{
	if(HCount >= NetDepth)
		Depth = NetDepth;
	else
		Depth = HCount;
	}
do /* while Depth<=NetDepth and Depth<HCount and HCount not zero */
{



/* Begin loop to eliminate the most commonly conflicting lines progressively
until no conflict of "Depth" lines remains. This loop terminates a little
earlier for Mode=1 or Mode=2 since progressive conflict removal is not a
feature of these modes. */
do /* while conflicts remain */
{

/* set up CombBloc for this depth and current hypothesis line count */
CombBloc.inputwidth = HCount; 
CombBloc.logicdepth = Depth;
CombBloc.bitnumbers = Indexes;
CombBloc.offset = 0; 
BitNumbers(&CombBloc); /* Make Indexes match offset, ie init em. */
/*
Values in the Indexes array select line numbers in the HLine array. 
CombBloc is used to iterate through combinations of hypothesis lines.
*/

/* clear conflict flag */
BadFlag=0;

/* clear conflict counts */
for(i=1; i<=InWidth; i++) BadCount[i]=0;


/*
begin loop to iterate through all combinations of "Depth" lines in the 
current version of the hypothesis
*/
do
{


/* Put the "Depth" actual line numbers into a convenient array. */
for (ThisLine=1; ThisLine<=Depth; ThisLine++) 
	{
	TheseLines[ ThisLine ]= HLine[ Indexes[ThisLine] ];
	}

/*
Set up a composite combination of NetDepth bit numbers which includes the
current combination of "Depth" line numbers and some fill lines. The first
truth table which contains info about TheseLines is unique and thus is a
convenient objective. The line numbers for this table will be those in
TheseLines and the lowest possible other numbers, beginning with 1, which
are not equal to any of the line numbers in TheseLines.
*/
ThisLine=1;
NextLine=1;
FillCnt=0;
PatMask=0;
Pattern=0;
for ( i=1;i<= NetDepth;i++)
	{
		if	(	 
				( NextLine < TheseLines[ThisLine] )
				&&
				( FillCnt < (NetDepth - Depth) )
			)
		{
			Lines[i] = NextLine;
			NextLine++;
			FillCnt++;
			PatMask=(PatMask<<1) ;
			Pattern=(Pattern<<1);
		}
		else
		{
			Lines[i] = TheseLines[ThisLine];
			NextLine = TheseLines[ThisLine] + 1;
			PatMask=(PatMask<<1) | one ;
			Pattern = (Pattern<<1)
					| 
					BitValue(HypeBits,TheseLines[ThisLine]);
			ThisLine++;
		}
	}


/* Find the probabilistic occurance-count truth table for the lines */
Reconstruct(Lines,Table);

/*
Search the truth table for patterns which have occured and in which the
"Depth" lines have carried their hypothesized value. If such patterns have
occured often enough the hypothesized pattern on the "Depth" lines is
considered plausible and the line combination's hypothesized value pattern
is good. Otherwise it is bad and the BadCombo flag is set.
NOTE: prob(lines,pattern) = GoodCnt/(Total Number of Observations)
*/
GoodCnt=0;
for(i=1; i<TableSize; i++)
	{
	if ( (i & PatMask) == Pattern ) GoodCnt = GoodCnt + Table[i];
	}
if (GoodCnt < MinCount)
	BadCombo = 1;
else
	BadCombo = 0;

/* If line combination bad, count all it's "Depth" lines bad and set BadFlag. */
if (BadCombo)
	{ 	
	BadFlag=1;
	for (ThisLine=1;ThisLine<=Depth;ThisLine++) 
		{
		BadCount[TheseLines[ThisLine]]++;
		}
	}

} while (! NextOffset(&CombBloc));
/* next combo or end iteraton thru combinations of hypothesis lines */
 

switch(Mode)	
{
case 1: /* Peremptory */
	{
	/* eliminate all lines from hypothesis if any conflict was found */
	if(BadFlag)
		{
		for(i=1;i<=InWidth;i++)
			{
			ClearBit(HypeMask,i);
			OutCount++; /*Count lines expunged */
			}
		}
	/* clear BadFlag since all conflicts are expunged */
	BadFlag=0;
	}
break;

case 2: /* Cleanup */
	{
	/* eliminate all conflicting lines if any */
	if(BadFlag)
		{
		/* remove the conflicting lines from hypothesis */
		for(i=1;i<=InWidth;i++)
			{
			if (BadCount[i]>0)
				{
				ClearBit(HypeMask,i);
				OutCount++; /*Count lines expunged */
				}
			}
		}
	/* clear BadFlag since all conflicts are expunged */
	BadFlag=0;
	}
break;

case 3: /* Resolve */
	{
	/*eliminate only the most commonly conflicting lines if any */
	if(BadFlag)
		{
		/* find max conflict count */
		BadMax=0;
		for(i=1;i<=InWidth;i++)
			{
			if (BadCount[i]>BadMax) BadMax=BadCount[i];
			}
		/* remove the most commonly conflicting lines from hypothesis */
		for(i=1;i<=InWidth;i++)
			{
			if (BadCount[i]==BadMax) 
				{
				ClearBit(HypeMask,i);
				OutCount++; /*Count lines expunged */
				}
			}
		}
	/* do not clear BadFlag since some conflicts may remain */
	}
break;
}


/* 
Re-count hypothesis lines and list their line numbers. Some may have been
deleted.
*/
HCount=0;
for(i=1 ; i<=InWidth ; i++)
	{
		if ( BitValue(HypeMask,i)  )
			{
			HCount++ ; 
			HLine[HCount] = i;
			}
	}



}
while(BadFlag);
/*...end of progressive rejection of commonly conflicting lines from 
hypothesis */



Depth++;
} while( (Depth <= NetDepth) && (Depth <= HCount) && HCount );
/* ...end of loop through all possible values of "Depth" */


return OutCount;
}

/*----------------------------------------------------------------------*/










/*------------------------------------------------------------------------*/

/* routines in the infer.c file... */
void				Infer();

/* Routines in the Bit Table Algorithms file:  */
unsigned long int 	BitValue();
void				SetBit();
void				ClearBit();
unsigned long int 	TableBitValue();
void				SetTableBit();
void				ClearTableBit();

/* routines in the combalg.c file... */

unsigned long int 	NetSize();
void 				Offset();
void 				BitNumbers();
unsigned long int 	NextOffset();
unsigned long int 	PreviousOffset();

void Reconstruct();

/*------------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

void
Infer( HypeMask, HypeBits, InfrMask, InfrBits )
unsigned long int 
	*HypeMask,
	*HypeBits,
	*InfrMask,
	*InfrBits;
{			
unsigned long int 	
	i,
	Target,
	HCount,
	HLine[26],
	nonHCnt,
	nonHLine[26],
	TheLine,
	Indexes[4],
	HLinComb[4],
	Lines[9],
	Table[8],
	FillLim,
	FillCnt,
	HLim,
	HLnIndex,
	NextLine,
	Pattern,
	PatMask,
	LineBit,
	hypedone,
	linedone,

	BigHype,
	Was1Cnt,
	Was0Cnt,
	Done,
	one=1;
struct NetInfoBlock
	CombBloc;

/*clear response arrays */
for(i=1 ;i<=InWidth; i++) 
	{
	ClearBit(InfrMask,i);
	ClearBit(InfrBits,i);
	}

/* Count and list hypothesis & non-hypothesis line numbers. */
HCount=0; nonHCnt=0;
for(i=1 ; i<=InWidth ; i++)
	{
	if ( BitValue(HypeMask,i)  )
		{ HCount++ ; HLine[HCount] = i; }
	else
		{ nonHCnt++ ; nonHLine[nonHCnt]= i; }
	}


/* try to infer each non-hypothesis bit */
for ( Target=1; Target<=nonHCnt; Target++ ) 
{
TheLine = nonHLine[Target];

/* note and adjust for hypothesis size */
if ( ( HCount < (NetDepth-1) ) || (NetDepth==1) )
	{
	BigHype=0;
	FillLim = NetDepth - 1 - HCount;
	if (NetDepth==1) FillLim = 0;
	HLim = NetDepth - FillLim - 1;
	}
else
	{
	BigHype = 1; /* big hypothesis */
	FillLim = 0;
	HLim = NetDepth - 1;
	/* prepare to iterate through combinations of hypothesis lines... */
	CombBloc.bitnumbers = Indexes;
	CombBloc.inputwidth = HCount;
	CombBloc.logicdepth = NetDepth - 1 ;
	CombBloc.offset = 0;
	BitNumbers(&CombBloc);
	}

do /* until inference achieved or hypothesis exhausted */
{

/* form a composite combination of line numbers including the target line,
up to (NetDepth-1) hypothesis lines if available, and some irrelevant fill
lines if the hypothesis is small.
PatMask indicates position of lines from the hypothesis in the combination.
Pattern indicates hypothesized values carried by those lines.
LineBit indicates the position of the target line in the combination.
*/

/* move hypothesis line numbers to HLinComb[] */
if( BigHype ) for ( i=1; i<=HLim; i++ ) HLinComb[i] = HLine[Indexes[i]];
else for ( i=1; i<=HLim; i++ ) HLinComb[i] = HLine[i];
/* init flags */ hypedone = ! HLim; linedone = 0;
/* initialize line control values */ FillCnt=0; HLnIndex=1; NextLine=1;
/* initialize masks */ Pattern = 0; PatMask=0; LineBit=0;
/* select the line numbers */
for (i = 1; i<=NetDepth;i++)
	{
	PatMask = PatMask<<1;
	Pattern = Pattern<<1;
	LineBit = LineBit<<1;
	
	if 	(	( FillCnt != FillLim ) /* need more fill lines */
			&&
			( NextLine != TheLine ) /* not time for the target line */
			&&
			( NextLine != HLinComb[HLnIndex] ) /* not time for an H line */
		)
		{
		/* insert a fill line number */
		Lines[i] = NextLine;
		FillCnt++;
		}
	else
		{ 
		if ( (!hypedone) && ( (HLinComb[HLnIndex]<TheLine) || linedone ) )
			{
			/* insert a Hypothesis line number */
			Lines[i] = HLinComb[HLnIndex];
			NextLine = HLinComb[HLnIndex];
			PatMask = PatMask | one;
			Pattern = Pattern | BitValue( HypeBits, HLinComb[HLnIndex] );
			if ( HLnIndex == HLim )
				{ hypedone = 1; }
			else
				{ HLnIndex++; }
			}
		else
			{
			/* insert the target line's number */
			Lines[i] = TheLine;
			NextLine = TheLine;
			LineBit = LineBit | one;
			linedone = 1;
			}
		}
	NextLine++;
	}

/* fetch table */
Reconstruct(Lines,Table);

/* scan table */
Was1Cnt = 0;
Was0Cnt = 0;
for( i=0; i<TableSize; i++)
	{
	if ( (i&PatMask) == Pattern )
		{
		if(i & LineBit)
			{ Was1Cnt = Was1Cnt + Table[i]; }
		else
			{ Was0Cnt = Was0Cnt + Table[i]; }
		}
	}

/* Make counts binary through comparison to MinCount */
/* note that prob(bit=1) = Was1Cnt/(Was1Cnt+Was0Cnt) */
if(Was0Cnt >= MinCount) Was0Cnt = 1; else Was0Cnt = 0;
if(Was1Cnt >= MinCount) Was1Cnt = 1; else Was1Cnt = 0;

/* mark bit as inferred if it had only one value */
if ( ( (! Was1Cnt) && ( Was0Cnt) ) ||  ( ( Was1Cnt) && (! Was0Cnt) ) )
	{
	SetBit(InfrMask,TheLine);
	if ( ( Was1Cnt) && (! Was0Cnt) )
		SetBit(InfrBits,TheLine);
	else
		ClearBit(InfrBits,TheLine);
	}

if ( BigHype )
	{
	/* next combination of hypothesis lines */
	Done = NextOffset(&CombBloc);
	}
else
	{
	Done = 1;
	}

} 
while 	(	
		(! Done) 
		&& 
		(! BitValue(InfrMask,TheLine)) 
		); /* continue if more combinations and bit not yet inferred */

}/* end of loop through target lines */



}
/*----------------------------------------------------------------------*/







/* Routines in the Search file:  */
	void				Search();

/* Routines in the probmain file:  */
	void 				RedInf();

/* Routines in the Bit Table Algorithms file:  */
	unsigned long int 	BitValue();
	void				SetBit();
	void				ClearBit();
	unsigned long int 	TableBitValue();
	void				SetTableBit();
	void				ClearTableBit();

	unsigned long int	Reduce();
	void	Infer();
	unsigned long int	CheckBit();

/*----------------------------------------------------------------------*/
void
Search()
{
unsigned long int
	HCount,
	nonHCnt,
	HLine[26],
	nonHLine[26],
	XHypMask[4],
	XHypBits[4],
	XBitVals[4],
	XBitCnt,
	Full,
	valid,
	Done = 0,
	Widen,
	i,
	one=1;

char
	answer;
	
	
/* abort if learned pattern count = 0 */
if(! *NetPtrs[0] )
	{
	printf("\nNo patterns have been learned. Go to main menu item 1!\n");
	getreturn();
	return;
	}

/* explain search */
printf("Welcome to 'SEARCH'.\n");
printf("You will be asked for a hypothesis.  If you wish to see all\n");
printf("patterns considered plausible in the context of current\n");
printf("stored learning and current MinCount and NetDepth values,\n");
printf("enter a null hypothesis (no specified bit values, ie all\n");
printf("periods). Otherwise, enter any hypothetical pattern. The\n");
printf("hypothesis you enter will be reduced if not plausible and\n");
printf("extended by inference if possible, and the composite result\n");
printf("will be shown. This result will then be used as a base in\n");
printf("a search for all plausible complete patterns which contain it.\n");
printf("Note that ALL searches begin with a reduce/infer result that\n");
printf("contains all constant bits, including those begun from the null\n");
printf("hypothesis.\n\n");
getreturn();

/* get base hypothesis, reduce it, and extend by inference */
RedInf();

/* Count and list base hypothesis & non-hypothesis line numbers. */
HCount=0; nonHCnt=0;
for(i=1 ; i<=InWidth ; i++)
	{
	if ( BitValue(HypeMask,i)  )
		{ HCount++ ; HLine[HCount] = i; }
	else
		{ nonHCnt++ ; nonHLine[nonHCnt]= i; }
	}

/* start with one extension bit, set to zero */
XBitCnt=1; ClearBit(XBitVals,XBitCnt);

do /* til search complete or abort */
{

/* clear the extended hypothesis' mask */
for(i=1;i<=InWidth;i++) ClearBit(XHypMask,i);

/* lay in base hypothesis bits */
for(i=1;i<=HCount;i++)
	{
	SetBit(XHypMask,HLine[i]);
	if(BitValue(HypeBits,HLine[i]))
		SetBit(XHypBits,HLine[i]);
	else
		ClearBit(XHypBits,HLine[i]);
	}

/* extend the hypothesis with the extension bits */
for(i=1;i<=XBitCnt;i++)
	{
	SetBit(XHypMask,nonHLine[i]);
	if( BitValue(XBitVals,i) )
		SetBit(XHypBits,nonHLine[i]);
	else
		ClearBit(XHypBits,nonHLine[i]);
	}


printf("\nPattern being checked:");
ShowGrid(XHypMask,XHypBits);
printf("Checking validity...");

/* check extended hypothesis for validity */
/* nopped out! valid = ! Reduce(XHypMask,XHypBits,MinCount,one); */
valid = ! CheckBit ( XHypMask,XHypBits, nonHLine[XBitCnt] );




Full=0;

if (valid)
	{
	printf("valid.  ");
	printf("Checking sufficiency..."); /* extend by inference */
	Infer( XHypMask, XHypBits, InfrMask, InfrBits );
	
	/* combine inferred bits with hypothesis */
	for(i=1; i<=InWidth; i++)
		{ if( BitValue(InfrMask,i) )
			{
			SetBit(XHypMask,i);
			if( BitValue(InfrBits,i) )
				SetBit(XHypBits,i);
			else
				ClearBit(XHypBits,i);
			}
		}
	
	/* check to see if a complete pattern has been found */
	Full=1;
	for(i=1;i<=InWidth;i++) if(! BitValue(XHypMask,i) ) Full=0;
	}
else
	printf("not valid.\n");


if (Full)
	{
	printf("sufficient!\n");
	/* display the pattern */
	printf("\nOne solution is:");
	ShowGrid(XHypMask,XHypBits);
	
	/* get go-ahead to search for more */
	printf("\n Search for another? (Y/N)...");
	answer=Key();
	printf("\n");
	if( (answer != 'Y') && (answer != 'y') )
		break; /* leave search loop */
	}
else
	if(valid) printf("not sufficient.\n");

/* decide whether to widen the hypothesis extension */
if ( Full || (! valid) || (XBitCnt==nonHCnt) )
	Widen = 0; /* don't widen the hypothesis extension*/
else
	Widen = 1; /* do widen */


/* widen hypothesis extension, or shrink (if necessary )and increment ) */
if ( Widen ) /* ie current hype extension has potential */
 	{
	printf("Widening hypothesis.\n");
 	/* add a new bit position and set the bit to zero */
 	XBitCnt++;
 	ClearBit(XBitVals,XBitCnt);
 	}
 else /* ie current hype (size & value) extension exhausted  */
	{
	/* delete all bits on right which are 1 if any */
	while( ( BitValue( XBitVals, XBitCnt ) ==1) && ( XBitCnt != 0 ) )
		{ XBitCnt--; }
	if(XBitCnt)	/* if any bits remain */
		/* make current rightmost bit true */
		SetBit(XBitVals,XBitCnt);
	else /* if no bits remain */
		/* quit loop, job is done */
		{
		Done=1;
		printf("\nSEARCH COMPLETE! No more patterns can be found!\n");
		getreturn();
		}
	}

}while(! Done);

}
/*----------------------------------------------------------------------*/









/*------------------------------------------------------------------------*/

/* routines in the BitCheck.c file... */
void				BitCheck();

/* Routines in the Bit Table Algorithms file:  */
unsigned long int 	BitValue();
void				SetBit();
void				ClearBit();
unsigned long int 	TableBitValue();
void				SetTableBit();
void				ClearTableBit();

/* routines in the combalg.c file... */

unsigned long int 	NetSize();
void 				Offset();
void 				BitNumbers();
unsigned long int 	NextOffset();
unsigned long int 	PreviousOffset();

void Reconstruct();

/*------------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/

unsigned long int
CheckBit ( HypeMask, HypeBits, TheLine )
unsigned long int 
	*HypeMask,
	*HypeBits,
	TheLine;
{			
unsigned long int 	
	i,
	HCount,
	HLine[26],
	Indexes[4],
	HLinComb[4],
	Lines[9],
	Table[8],
	FillLim,
	FillCnt,
	HLim,
	HLnIndex,
	NextLine,
	Pattern,
	PatMask,
	LineBit,
	hypedone,
	linedone,
	BigHype,
	BadFlag,
	Done,
	one=1,
	GoodCnt;
struct NetInfoBlock
	CombBloc;


/* Count and list hypothesis line numbers other than TheLine. */
HCount=0;
for(i=1 ; i<=InWidth ; i++)
	{
	if ( ( BitValue(HypeMask,i) ==1) && (i != TheLine ) )
		{ HCount++ ; HLine[HCount] = i; }
	}

/* note and adjust for hypothesis size */
if ( ( HCount < (NetDepth-1) ) || (NetDepth==1) )
	{
	BigHype=0;
	FillLim = NetDepth - 1 - HCount;
	if (NetDepth==1) FillLim = 0;
	HLim = NetDepth - FillLim - 1;
	}
else
	{
	BigHype = 1; /* big hypothesis */
	FillLim = 0;
	HLim = NetDepth - 1;
	/* prepare to iterate through combinations of hypothesis lines... */
	CombBloc.bitnumbers = Indexes;
	CombBloc.inputwidth = HCount;
	CombBloc.logicdepth = NetDepth - 1 ;
	CombBloc.offset = 0;
	BitNumbers(&CombBloc);
	}

do /* until conflict found or hypothesis exhausted */
{

/* form a composite combination of line numbers including the target line,
up to (NetDepth-1) hypothesis lines if available, and some irrelevant fill
lines if the hypothesis is small.
PatMask indicates position of lines from the hypothesis in the combination.
Pattern indicates hypothesized values carried by those lines.
LineBit indicates the position of the target line in the combination.
*/

/* move hypothesis line numbers to HLinComb[] */
if( BigHype ) for ( i=1; i<=HLim; i++ ) HLinComb[i] = HLine[Indexes[i]];
else for ( i=1; i<=HLim; i++ ) HLinComb[i] = HLine[i];
/* init flags */ hypedone = ! HLim; linedone = 0;
/* initialize line control values */ FillCnt=0; HLnIndex=1; NextLine=1;
/* initialize masks */ Pattern = 0; PatMask=0;
/* select the line numbers */
for (i = 1; i<=NetDepth;i++)
	{
	PatMask = PatMask<<1;
	Pattern = Pattern<<1;
	
	if 	(	( FillCnt != FillLim ) /* need more fill lines */
			&&
			( NextLine != TheLine ) /* not time for the target line */
			&&
			( NextLine != HLinComb[HLnIndex] ) /* not time for an H line */
		)
		{
		/* insert a fill line number */
		Lines[i] = NextLine;
		FillCnt++;
		}
	else
		{ 
		if ( (!hypedone) && ( (HLinComb[HLnIndex]<TheLine) || linedone ) )
			{
			/* insert a Hypothesis line number */
			Lines[i] = HLinComb[HLnIndex];
			NextLine = HLinComb[HLnIndex];
			PatMask = PatMask | one;
			Pattern = Pattern | BitValue( HypeBits, HLinComb[HLnIndex] );
			if ( HLnIndex == HLim )
				{ hypedone = 1; }
			else
				{ HLnIndex++; }
			}
		else
			{
			/* insert the target line's number */
			Lines[i] = TheLine;
			PatMask = PatMask | one;
			Pattern = Pattern | BitValue( HypeBits, TheLine );
			NextLine = TheLine;
			linedone = 1;
			}
		}
	NextLine++;
	}

/* TRACE */


/* fetch table for lines selected */
Reconstruct(Lines,Table);

/* scan table */
GoodCnt=0;
for( i=0; i<TableSize; i++)
	if 	( ( (i&PatMask) == Pattern ) ) GoodCnt=GoodCnt+Table[i];

/* interpret scan results */
if( GoodCnt >= MinCount )
	BadFlag = 0;
else
	BadFlag = 1;



if ( BigHype )
	{
	/* next combination of hypothesis lines */
	Done = NextOffset(&CombBloc);
	}
else
	{
	Done = 1;
	}

} 
while 	( (! Done) && (! BadFlag)  );

return BadFlag;
}
/*----------------------------------------------------------------------*/




/* end of program */




