/* ************************************************************** */
/* file ibp.h: contains definitions for programs that use 16-bit  */
/*             integer weights                                    */
/*                                                                */
/* Copyright (c) 1990, 1991, 1992, 1993, 1994 by Donald R. Tveter */
/*                                                                */
/* ************************************************************** */

#ifdef DOS16
#define INT32 long
#define MAXINT 32767
#else
#define INT32 int
#define MAXINT 2147483647
#endif

#define maxformat 21          /* maximum number of format breaks */
#define buffsize 257          /* maximum size of an input line */
#define WTTYPE short          /* a 16-bit integer */
#define WTSIZE 2              /* shorts are two bytes */
#define MAXSHORT 32767        /* largest short */
#define MINSHORT -32768       /* smallest short */
#define OUTSTRSIZE 257        /* max size of output string */
#define HCODE -32768          /* code number for a layer h (2) unit */
#define ICODE -32767          /* code number for a layer i (3) unit */
#define JCODE -32766          /* code number for a layer j (4) unit */
#define KCODE -32765          /* code number for a layer k (5) unit */
#define GT 0                  /* a symbol meaning > */
#define GE 1                  /* a symbol meaning >= */

#ifdef FLOAT
#define REAL float
#else
#define REAL double
#endif

typedef struct seednode
   {
     unsigned val;            /* a seed value */
     struct seednode *next;   /* pointer to next node */
   } SEEDNODE;
typedef struct patlist
   {
     WTTYPE *pats;            /* the list of patterns */
     struct patlist *next;    /* pointer to the next pattern */
   } PATLIST;
typedef struct unit
   {
     short layernumber;       /* layer number of the unit */
     short unitnumber;        /* position within layer */
     INT32 error;             /* to sum error factors */
     WTTYPE oj;               /* state of activation of node */
     WTTYPE tj;               /* output target of a node */
     struct wtnode *wtlist;   /* the list of weights */
     struct unit *next;       /* link to next unit in this layer */
   } UNIT;

typedef struct wtnode
   {
#ifdef SYMMETRIC
     WTTYPE *weight;          /* ptr to weight */
     WTTYPE *olddw;           /* ptr to delta wji */
     WTTYPE *eta;             /* ptr to eta for the DBD method */
     INT32 *total;            /* ptr to total of weight changes */
     WTTYPE *slope;           /* previous slope */
#else
     WTTYPE weight;           /* weight from here to backunit */
     WTTYPE olddw;            /* delta wji from previous iteration */
     WTTYPE eta;              /* the eta for the DBD method */
     INT32 total;             /* total weight changes for batch mode */
     WTTYPE slope;            /* previous slope */
#endif
     struct wtnode *next;     /* link to next node */
     UNIT *backunit;          /* ptr to unit the weight comes from */
   } WTNODE;

typedef struct layer
   {
     int unitcount;           /* number of units in this layer */
     struct layer *backlayer; /* pointer to previous layer */
     struct layer *next;      /* pointer to next layer */
     UNIT *units;             /* start of list of units in this layer */
     PATLIST *patstart;       /* to the list of patterns */
     PATLIST *currentpat;     /* the current pattern */
   } LAYER;
