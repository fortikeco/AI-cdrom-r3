#ifndef _RNSCONF_H
#define _RNSCONF_H


#undef  GNUC
#undef  LINUX
#undef  TURBOC
#undef  UNIX
#undef  USEPROTOS

#ifdef __linux__
#define LINUX
#define UNIX
#define _BSD_SOURCE
#endif

#ifdef __sun__
#ifdef __svr4__
#define SOLARIS
#else
#define SUNOS
#endif
#define UNIX
#endif

#ifdef  __TURBOC__
#undef  GNUC
#define TURBOC           /*  definieer TURBOC als __TURBOC__  */
#define USEPROTOS
#endif

#ifdef  __GNUC__
#define GNUC
#undef  TURBOC           /*  maak TURBOC definitie ongedaan als __GNUC__  */
#define USEPROTOS
#endif


#ifdef USEPROTOS
#define __(p)  p
#else
#define __(p)  ()
#endif


#endif
