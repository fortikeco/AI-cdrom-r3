/*  $Id: rnstime.c,v 1.7 1991/10/10 16:46:37 richard Exp richard $  */

/*  Part of RNS -- Recurrent Network Simulator
 *
 *     by R. Kooijman
 *        T.U. Delft
 *        Faculteit Elektrotechniek
 *        Vakgroep Computerarchitectuur
 *        Sectie Neurale Netwerken
 */


/*  $Log: rnstime.c,v $
 * Revision 1.7  1991/10/10  16:46:37  richard
 * Switched to UNIX RCS
 *
 * Revision 1.6  91/02/26  21:50:56  ROOT_DOS
 * Added comments
 * 
 * Revision 1.5  91/02/17  14:29:28  ROOT_DOS
 * Minor changes
 *
 * Revision 1.4  91/01/30  21:45:01  ROOT_DOS
 * Forget ANSI C and make traditional C / Turbo C dual mode
 *
 * Revision 1.3  91/01/27  21:04:32  ROOT_DOS
 * Changes to make code strict ANSI C compatible
 *
 * Revision 1.2  90/12/08  03:51:43  ROOT_DOS
 * Some minor cosmetic changes
 *
 * Revision 1.1  90/12/08  03:18:58  ROOT_DOS
 * Initial revision
 *   */



/*  functies voor tijdmetingen  */


#define EXTERN
#include "rnsdefs.h"
#include "rnsfuncs.h"


#ifdef TURBOC
#include <string.h>
#include <time.h>
#else
#include <string.h>
#include <time.h>
#endif



#ifdef USEPROTOS
void init_time(void)
#else
void init_time()
#endif
{
   time(&begin_time);           /*  meet begintijd en maak tekst versie  */
   strcpy(begin_str, ctime(&begin_time));
   time(&end_time);             /*  meet eindtijd en maak tekst versie   */
   strcpy(end_str, ctime(&end_time));
}



#ifdef USEPROTOS
void update_time(void)
#else
void update_time()
#endif
{
   time(&end_time);             /*  meet eindtijd en maak tekst versie   */
   strcpy(end_str, ctime(&end_time));
}
