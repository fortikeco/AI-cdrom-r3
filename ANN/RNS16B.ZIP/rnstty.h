/*  $Id$  */

/*  Part of RNS -- Recurrent Network Simulator
 *
 *     by R. Kooijman
 *        T.U. Delft
 *        Faculteit Elektrotechniek
 *        Vakgroep Computerarchitectuur
 *        Sectie Neurale Netwerken
 */


/*  $Log$  */



/*  functies voor het zetten van TTY instellingen  */


#ifndef _RNSTTY_H
#define _RNSTTY_H


#ifdef UNIX

int  tty_raw __((void));
int  tty_reset __((void));

#endif


#endif  /*  _RNSTTY_H  */

