/*
is: onelays.c Copyright (c) 1990 J.R.Parramore
dz: generates vectors to train neural net 
by: j.r.m-parramore
on: 20th august 90
*/

#include <stdio.h>
#include <time.h>

#define samples 10

FILE *fp1;

main()
{
	int i;
	float a, b, c;
	
	srand(clock());
	if ((fp1 = fopen("onelays.tea", "w" )) == NULL )
		printf("\nCould'nt open file");

	fprintf(fp1,"%d", samples);
	for ( i=0; i<samples; i++ )
	{
		a = 2.0 * (rand()/32768.0 - 0.5);
		b = 2.0 * (rand()/32768.0 - 0.5);
	
		if ( b > (0.9 * a - 0.1) )
			c = 0.9;
		else
			c = 0.1;

		fprintf(fp1, "\n%10.7f %10.7f   %5.2f", a, b, c);
	}
	fclose(fp1);
}
