/*
is: thrlays.c Copyright (c) 1990 J.R.Parramore
dz: generates vectors to train neural net 
by: j.r.m-parramore
on: 20th august 90
*/

#include <stdio.h>
#include <time.h>

#define samples 10

FILE *fp1;


main()
{
	int i;
	float a, b, c, d, e, f;
	
	srand(clock());
	if ((fp1 = fopen("thrlays.tea", "w" )) == NULL )
		printf("\nCould'nt open file");

	fprintf(fp1,"%d", samples);
	for ( i=0; i<samples; i++ )
	{
		a = 2.0 * (rand()/32768.0 - 0.5);
		b = 2.0 * (rand()/32768.0 - 0.5);
	
		if ( b > (0.9 * a - 0.1) )
			c = 0.9;
		else
			c = 0.1;

		if ( b > (-0.167 * a - 0.7) )
			d = 0.9;
		else
			d = 0.1;

		if ( b > (1.8 * a - 0.9) )
			e = 0.9;
		else
			e = 0.1;

		if ( (c > 0.8) && (d > 0.8) && (e > 0.8) )
			f = 0.9;
		else
			f = 0.1;

		fprintf(fp1, "\n%10.7f %10.7f  %5.2f %5.2f %5.2f  %5.2f",
				a, b, c, d, e, f);
	}
	fclose(fp1);
}
