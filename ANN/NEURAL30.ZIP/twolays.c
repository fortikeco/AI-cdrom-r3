/*
is: twolays.c Copyright (c) 1990 J.R.Parramore
dz: generates vectors to train neural net 
by: j.r.m-parramore
on: 20th august 90
*/

#include <stdio.h>
#include <time.h>

#define samples  10

FILE *fp1;


main()
{
	int i;
	float a, b, c, d, e;
	
	srand(clock());
	if ((fp1 = fopen("twolays.tea", "w" )) == NULL )
		printf("\nCould'nt open file");

	fprintf(fp1,"%d", samples);
	for ( i=0; i<samples; i++ )
	{
		a = 2.0 * (rand()/32767.0 - 0.5);
		b = 2.0 * (rand()/32767.0 - 0.5);
	
		if ( b > (0.9 * a - 0.1) )
			c = 0.9;
		else
			c = 0.1;

		if ( b < (-0.9 * a - 0.2) )
			d = 0.9;
		else
			d = 0.1;

		if ( (c > 0.8) && (d > 0.8) )
			e = 0.9;
		else
			e = 0.1;

		fprintf(fp1, "\n%10.7f %10.7f   %5.2f %5.2f  %5.2f",
				a, b, c, d, e);
	}
	fclose(fp1);
}
