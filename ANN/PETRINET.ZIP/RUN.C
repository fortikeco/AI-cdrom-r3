#include "sim.h"

/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/


/************************************************************************/
/* execute the net							*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	run_net						*/
/* 									*/
/* Description:		does one execution of the net			*/
/* 									*/
/* Date of creation:	17-12-92					*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	whether the net fired (FIRED, DEAD)		*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
Net_state run_net(b_list branch)
{
  Net_state	retval;
  t_list	transitions = (t_list)NULL;

  find_active( branch, &transitions);
  if (transitions)
  {
    execute_active(branch, transitions);
    destroy_active(&transitions);
    retval = FIRED;
  }
  else
    retval = DEAD;

  return(retval);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	find_active					*/
/* 									*/
/* Description:		generate a list of active transitions		*/
/* 									*/
/* Date of creation:	17-12-92					*/
/* 									*/
/* input arguments:	branch to check					*/
/* 									*/
/* output:		list to update					*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void find_active( b_list branch, t_list *list)
{
  p_list current;
  int alive, alive2 ;
  t_list new_life;

  if (branch)
  {
     /* ---------------------------------------------------------------	*/
     /* check the sub branches first					*/
     /* ---------------------------------------------------------------	*/
     find_active(branch->left, list);
     find_active(branch->right, list);

     /* ---------------------------------------------------------------	*/
     /* if this is a transition, check that it can fire			*/
     /* ---------------------------------------------------------------	*/
     if (branch->my_type == TRANSITION)
     {
	alive = TRUE;
	alive2 = FALSE;

	current = branch->list;

	while (current && alive)
	{
	   if (current->what_i_am == TARGET)
	   {
	     alive = (current->item->tokens >= current->strength);
	     alive2 = alive;
	   }
	   current = current->next;
	}

        /* ------------------------------------------------------------	*/
        /* if the transition was alive add it to the active list	*/
        /* ------------------------------------------------------------	*/
        if (alive2)
        {
          if (debug)
            printf("trans is alive\n");
 
          if (  new_life = (t_list) malloc(sizeof(_trans_list))  )
          {
	    new_life->item = branch;
	    new_life->next = *list;
	    *list = new_life;
          }
        }
     }
  }
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	count_active					*/
/* 									*/
/* Description:		determine how many firable transitions in a list*/
/* 									*/
/* Date of creation:	17-12-92					*/
/* 									*/
/* input arguments:	list of active transitions			*/
/* 									*/
/* output:		void						*/
/* 									*/
/* function return:	counted						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int count_active( t_list list)
{
   int retval;

   if (list)
      retval =  1 + count_active(list->next);
   else
      retval = 0;


   return(retval);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	execute_active					*/
/* 									*/
/* Description:		fire a net in an indeterministic order		*/
/* 									*/
/* Date of creation:	17-12-92					*/
/* 									*/
/* input arguments:	net to fire, list of active transitions		*/
/* 									*/
/* output:		void						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void execute_active(b_list branch, t_list list)
{
   int count, which, counter;
   t_list current;
   p_list item;

   if (branch && list)
   {
     count = count_active(list);


     /* ---------------------------------------------------------------	*/
     /* randomise the transition to fire				*/
     /* ---------------------------------------------------------------	*/
     if (count>1)
       which = random()%count;
     else
       which = count;

     which = (which==0?1:which);

     if (debug)
     {
       printf("%d active transitions\n", count);
       printf(" firing transitions %d\n", which);
     }

     /* ---------------------------------------------------------------	*/
     /* seek the transition to fire					*/
     /* ---------------------------------------------------------------	*/
     counter = 1;
     current = list;

     while (counter < which)
     {
       current = current->next;
       counter ++;
     }

     /* ---------------------------------------------------------------	*/
     /* fire the transition						*/
     /* ---------------------------------------------------------------	*/

     item = current->item->list;

     while (item)
     {
       if (item->what_i_am == TARGET)
	 item->item->tokens -= item->strength;
       else if (item->what_i_am == SOURCE)
	 item->item->tokens += item->strength;
       item = item->next;
     }

   }
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/* 									*/
/* Description:								*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void destroy_active(t_list *list)
{
   t_list current, next;

   if (*list)
   {
     current = *list;
     while(current)
     {
       next = current->next;
       free (current);
       current = next;
     }
     *list = NULL;
   }
}
