#include "sim.h"


/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/


/************************************************************************/
/* vector functions							*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	get_arrow					*/
/* 									*/
/* Description:		stolen from xfig 2.1.5, draws an arrow on a line*/
/* 									*/
/* Date of creation:	30/11/92					*/
/* 									*/
/* input arguments:	start and end points on line			*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:	all variables changed to use GP_points for	*/
/*			compatibility with SUIT				*/
/* 									*/
/* 			arrow draw 3/4 way up the path			*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void get_arrow(GP_point p1, GP_point p2,
		 GP_point *wing1, GP_point *nose , GP_point *wing2)
{
    GP_point	delta, b, c, d, mid;
    double	x, y, l, sina, cosa;

    midpoint (p1,p2,&mid);
    midpoint (mid,p2,&mid);

    delta.x = mid.x - p1.x;
    delta.y = p1.y - mid.y;


    l = line_length( p1, mid);

    if (l != 0)
    {
      sina = delta.y / l;
      cosa = delta.x / l;

      b.x = mid.x * cosa - mid.y * sina;
      b.y = mid.x * sina + mid.y * cosa;

      x = b.x - ARROW_WID;
      y = b.y - ARROW_HT / 2;
      c.x = x * cosa + y * sina;
      c.y = -x * sina + y * cosa;

      y = b.y + ARROW_HT / 2;
      d.x = x * cosa + y * sina;
      d.y = -x * sina + y * cosa;

      wing1->x = c.x;    wing1->y = c.y;
      nose->x  = mid.x;  nose->y  = mid.y;
      wing2->x = d.x;    wing2->y = d.y;
  
    }
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/* 									*/
/* Description:								*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
double line_length( GP_point p1, GP_point p2)
{
    double dx, dy;
    
    dx = p2.x - p1.x;
    dy = p2.y - p1.y;

    return ( sqrt((dx*dx) + (dy*dy)) );
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	midpoint					*/
/* 									*/
/* Description:		mid point of two points				*/
/* 									*/
/* Date of creation:	29/10/92					*/
/* 									*/
/* input arguments:	input points p1, p2				*/
/* 									*/
/* output:		modified pointer				*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void	  midpoint( GP_point p1, GP_point p2, GP_point *mid)
{
	mid->x = (p1.x + p2.x)/ 2.0;
	mid->y = (p1.y + p2.y)/ 2.0;
}

