#include "sim.h"


/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/


/************************************************************************/
/*  load and save stuff							*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	save_branch					*/
/* 									*/
/* Description:		saves the petri_net info from this branch on	*/
/* 									*/
/* Date of creation:	11-12-92					*/
/* 									*/
/* input arguments:	the file and the branch to save			*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void save_branch( FILE *fp, b_list branch)
{

   if (branch)
   {

     save_branch( fp, branch->left);

     if (branch->my_type == PLACE)
     {
        fprintf 
        (
	     fp, "PL %d %d %s\n",
	     branch->hash,
	     branch->tokens,
	     (branch->label ? branch->label: "")
	);
     }
     else if (branch->my_type == TRANSITION)
     {
        fprintf 
        (
	     fp, "TR %d %s\n",
	     branch->hash,
	     (branch->label ? branch->label: "")
	);
     }

     save_branch( fp, branch->right);
   }
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/* 									*/
/* Description:								*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void save_header( FILE *fp)
{
  fprintf( fp, "%s\n", SIG );
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/* 									*/
/* Description:								*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void save_list( FILE *fp, b_list branch, p_list list)
{
  if (branch && list)
  {
    if ((list->what_i_am == SOURCE) &&(list->item))
       fprintf (
	   fp, "PA %d %d %d\n",
	   branch->hash, list->item->hash, list->strength
       );
    save_list ( fp, branch, list->next);
  }
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/* 									*/
/* Description:								*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void save_paths( FILE *fp, b_list branch)
{
   if (branch)
   {
     if (branch->list)
       save_list( fp, branch, branch->list);
     if (branch->right)
        save_paths( fp, branch->right);
     if (branch->left)
        save_paths( fp, branch->left);
   }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	load_data					*/
/* 									*/
/* Description:		reads petri-net info from file			*/
/* 									*/
/* Date of creation:	11-12-92					*/
/* 									*/
/* input arguments:	file and branch to add net to			*/
/* 									*/
/* output:		void						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void load_data( FILE *fp, b_list *branch )
{
   int hash, source, target, tokens, strength, count;
   double tmp_x, tmp_y;
   double s_x, s_y, t_x, t_y;
   char mnemonic[3];
   char label[MYBUFSIZ];
   b_list node, s_node, t_node;

   while (!feof(fp))
   {
     *buffer = NULL;
     *mnemonic = NULL;
     *label = NULL;

     fgets(buffer, MYBUFSIZ, fp);
     sscanf( buffer, "%2s", &mnemonic);

     if (strcmp(mnemonic, "PL") == 0)
     {
	sscanf(buffer, "PL %d %d %s\n", &hash, &tokens, label);
	unhash(hash, &tmp_x, &tmp_y);
	node = add_element(&root, PLACE, tmp_x, tmp_y);
	if (node)
	{
	  if (label)
	     node->label = strdup(label);
	  node->tokens = tokens;
	}
     }
     else if (strcmp(mnemonic, "TR") == 0)
     {
	sscanf(buffer, "TR %d %s\n", &hash, label);
	unhash (hash, &tmp_x, &tmp_y);
	node = add_element(&root, TRANSITION, tmp_x, tmp_y);
	if (node)
	{
	   if (label)
	      node->label = strdup(label);
	}
     }
     else if (strcmp(mnemonic, "PA") == 0)
     {
	sscanf(buffer,"PA %d %d %d\n", &source, &target, &strength );
	unhash(source, &s_x, &s_y);
	unhash(target, &t_x, &t_y);

	s_node = get_closest(root, s_x, s_y);
	t_node = get_closest(root, t_x, t_y);

	if (s_node && t_node)
	{
	  for (count = 1; count <= strength; count ++)
	    add_path( s_node, t_node);
	}
     }
   }
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	load_header					*/
/* 									*/
/* Description:		determines if the file was saved by this prog	*/
/* 									*/
/* Date of creation:	11-12-92					*/
/* 									*/
/* input arguments:	opened file					*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int load_header( FILE *fp)
{
  fscanf( fp, "%s\n", &buffer);
  return ( strcmp(buffer, SIG) == 0);
}
