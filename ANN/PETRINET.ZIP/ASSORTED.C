#include "sim.h"

/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/


/************************************************************************/
/*  assorted functions							*/
/************************************************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	get_closest					*/
/* 									*/
/* Description:		attempts to locate the closest object to  x, y	*/
/* 									*/
/* Date of creation:	26-10-92					*/
/* 									*/
/* input arguments:	x, y						*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	pointer to a tree (node)			*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
b_list get_closest( b_list branch, double x, double y)
{
   b_list retval = NULL;

   if (retval = get_element(branch, get_hash(x,y)) )
     retval = ( (retval->my_type == DELETED) ? NULL: retval);

   return (retval);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	get_element					*/
/* 									*/
/* Description:		attempts to locate the closest object to  x, y	*/
/* 									*/
/* Date of creation:	26-10-92					*/
/* 									*/
/* input arguments:	x, y						*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	pointer to a tree (node)			*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
b_list get_element(b_list branch, int hash_val)
{
   b_list	retval = NULL;

   if (branch)
   {
     if (hash_val > branch->hash)
     {
       retval = get_element(branch->right, hash_val);
     }
     else if (hash_val < branch->hash)
     {
       retval = get_element(branch->left, hash_val);
     }
     else
     {
       retval = branch;
     }
   }

   return (retval);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	get_hash					*/
/* 									*/
/* Description:		gets the hash value for a particular x y	*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:	x,y coords					*/
/* 									*/
/* output:		NOne						*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int get_hash(double x, double y)
{
   int hashx, hashy;

   hashx = nint(x/GRID);
   hashy = nint(y/GRID);

   return (ngrids*hashy + hashx);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	is_path						*/
/* 									*/
/* Description:		checks that a path doesnt allready exist between*/
/*			the source and the target. returns the list 	*/
/*			if there is and NULL if not			*/
/* 									*/
/* Date of creation:	30-11-92					*/
/* 									*/
/* input arguments:	the source and target				*/
/* 									*/
/* output:		none						*/
/* 									*/
/* function return:	the list element with the path if any		*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
p_list is_path(b_list node1, b_list node2, whatami what)
{
   p_list retval = (p_list) NULL;

   if (node1 && node2)
      retval = is_wanted_path( node1->list, node2, what);
   return(retval);
}

p_list is_wanted_path(p_list list, b_list element, whatami what)
{
   p_list retval = (p_list) NULL;

   if(list && element)
   {
     if ( (list->item==element) && (list->what_i_am == what) )
       retval = list;
     else
       retval = is_wanted_path( list->next, element, what);
   }
   return (retval);

}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/* 									*/
/* Description:								*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
char *itoa( int num)
{
  sprintf(buffer, "%d", num);

  return (strdup(buffer));
}

void set_colour( char *colour)
{
  if (!mono)
    GP_setColor(GP_defColor(colour, FALSE));
}

void unhash ( int hash, double *x, double *y)
{
   int hash_x, hash_y;

   hash_y = hash/ngrids;
   hash_x = hash - (hash_y * ngrids);

   *x = (double) hash_x *GRID;
   *y = (double) hash_y *GRID;
}

int SUIT_getNumber(char *prompt)
{
  char buff[30];
  int retval;

  if (SUIT_getString( prompt, buff, buff, 29) == REPLY_OK)
  {
    sscanf(buff,"%d",&retval);
  }
  else
    retval = 0;

  return(retval);
}

void GNU_thing()
{
  puts( "petri version 1.0A, Copyright (C) 1993 Sunil Gupta");
  puts( "petri comes with ABSOLUTELY NO WARRANTY; ");
  puts( "This is free software, and you are welcome to redistribute it");
  puts( "under certain conditions;");
  puts( "See the file LICENSE for more details");
}
