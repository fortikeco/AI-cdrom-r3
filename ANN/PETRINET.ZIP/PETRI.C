#include "sim.h"


/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/


/************************************************************************/
/* User defined  SUIT objects						*/
/************************************************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name: 	CreatePetriWidget				*/
/* 									*/
/* Description:		create a new instance of the graphics widget	*/
/*			for displaying petri-nets			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	name of widget					*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	pointer to new SUIT object			*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

SUIT_object CreatePetriWidget(char *name)
{
    SUIT_object obj;

    obj = SUIT_createObject(name, "PetriWidget class");
    SUIT_addDisplayToObject
    (
        obj, 
        "standard", 
        HitPetriWidget, 
        PaintPetriWidget
    );
    return (obj);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	HitPetriWidget					*/
/* 									*/
/* Description:		This determines what happens when a mouse event */
/*			on the graphics window				*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	obj		the object which was hit	*/
/*			ev		the mouse event			*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void HitPetriWidget (SUIT_object obj, SUIT_event ev)
{
    static	double	down_x, down_y;
    static	b_list	source, target;
    double	x, y;
    char	*ch;
    Action	current_status;
    static double oldx = 0.0;
    static double oldy = 0.0;


    /* ----------------------------------------------------------------	*/
    /*		always update the x/y/coordinates			*/
    /* ----------------------------------------------------------------	*/
    x = ev.worldLocation.x;
    y = ev.worldLocation.y;

    SUIT_setDouble (obj, "current x", x);
    SUIT_setDouble (obj, "current y", y); 



    /* ----------------------------------------------------------------	*/
    /* find out what the current status of the program is		*/
    /* ----------------------------------------------------------------	*/
    ch = SUIT_getText(status_obj, LABEL);

    if (strcmp(ch, "Adding Path") == 0)
      current_status = ADD_PATH;
    else if (strcmp(ch, "Adding Transition") == 0)
      current_status = ADD_TRANS;
    else if (strcmp(ch, "Adding Place") == 0)
      current_status = ADD_PLACE;
    else if (strcmp(ch, "Adding Token") == 0)
      current_status = ADD_TOKEN;
    else if (strcmp(ch, "Removing Path") == 0)
      current_status = DEL_PATH;
    else if (strcmp(ch, "Removing Transition") == 0)
      current_status = DEL_TRANS;
    else if (strcmp(ch, "Removing Place") == 0)
      current_status = DEL_PLACE;
    else if (strcmp(ch, "Removing Token") == 0)
      current_status = DEL_TOKEN;


    /* ----------------------------------------------------------------	*/
    /* do something on the event					*/
    /* ----------------------------------------------------------------	*/

    switch (ev.type)
    {
      case MOUSE_MOTION:
	 switch (current_status)
	 {
	   case ADD_PATH:
	   case DEL_PATH:
	     /* the mouse is down so, follow mouse with a line */
	     GP_lineCoord(down_x, down_y, x, y);
	     break;

	   default:
	     break;
	 }
	 break;

      case MOUSE_DOWN:
	 switch(current_status)
	 {
	   case ADD_PATH:
	   case DEL_PATH:
	      down_x = x;
	      down_y = y;

	      source = get_closest(root, x, y);
	      if (!source )
	         SUIT_inform("No symbol at start of path");
	      break;

	   default:
	      break;
	 }
	 break;

      case MOUSE_UP:
	 switch(current_status)
	 {
	   case ADD_PATH:
	   case DEL_PATH:
	      target = get_closest(root, x, y);
	      if (!target)
	         SUIT_inform("No symbol at end of path");
   
	      if (source && target)
	      {
	        if (current_status == ADD_PATH)
	          add_path(source, target);
	        else
	          destroy_path(source, target);
	      }
	      refresh(petri_obj);
	   
	      break;

	   default:
	      break;
	 }
	 break;

      case CLICK:
	 switch (current_status)
	 {
	   case ADD_PLACE:
	     add_element (&root, PLACE, x, y );
	     break;

	   case ADD_TOKEN:
	     if (target = get_closest(root, x, y))
	     {
		if (target->my_type == PLACE)
		   target->tokens++;
		else
		   SUIT_inform("tokens can only be added to PLACEs");
	     }
	     else
		SUIT_inform ("couldn't find anything to add token to");
	     break;

	   case ADD_TRANS:
	     add_element (&root, TRANSITION, x, y );
	     break;

	   case DEL_TOKEN:
	     if (target = get_closest(root, x, y))
	     {
		if (target->my_type == PLACE)
		{
		  if (target->tokens > 0)
		    target->tokens--;
		}
		else
		  SUIT_inform("Tokens can only be removed from PLACES");
	     }
	     else
		SUIT_inform ("couldn't find anything to remove token from");
	     break;

	   case DEL_PLACE:
	     target = get_closest(root, x, y);
	     if (target&& (target->my_type == PLACE))
	       destroy_place (target);
	     else
		SUIT_inform ("PLACE not found here");
	     break;

	   case DEL_TRANS:
	     target = get_closest(root, x, y);
	     if (target && (target->my_type == TRANSITION) )
	       destroy_transition (target);
	     else
		SUIT_inform ("TRANSITION not found here");
	     break;

	   case DEL_PATH:
	   case ADD_PATH:
	     SUIT_inform("Mouse button must be held down for PATH operations");
	     break;

	   default:
	     SUIT_inform("Function not appropriate or not implemented");
	     break;
	 }
	 break;

      default:
	 break;
    }
    

    /* ----------------------------------------------------------------	*/
    /*		always update the x/y/coordinates on exiting		*/
    /* ----------------------------------------------------------------	*/
    oldx =  ev.worldLocation.x;
    oldy =  ev.worldLocation.y;
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name: 	PaintPetriWidget				*/
/* 									*/
/* Description:		draw the contents of tree			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	obj	object to redraw			*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void myPaintPetriWidget (SUIT_object obj)
{
}

void PaintPetriWidget (SUIT_object obj)
{
    if (show_grid)
    {
      paint_grid(obj);
    }
    paint_paths(root);
    paint_symbols(root);
}
