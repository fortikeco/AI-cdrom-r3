#include "sim.h"


/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/

char *filenam;

/************************************************************************/
/*  call back functions							*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	set_status					*/
/* 									*/
/* Description:		called when "Add" or "delete" is hit 		*/	
/*			sets a global variable				*/
/* 									*/
/* Date of creation:	29-11-92					*/
/* 									*/
/* input arguments:	SUIT_object	obj 	(not used)		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void set_status(SUIT_object obj)
{
   char *current;

   current = SUIT_getEnumString(obj, CURRENT_VALUE);

   if ( strcmp ("Add", current) == 0)
     objing = ADDING;
   else if ( strcmp ("Remove", current) == 0)
     objing = ZAPPING;
   else if ( strcmp ("Move", current) == 0)
     objing = MOVING;

   obj_things(obj_radio);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	clear_net					*/
/* 									*/
/* Description:		Destroys the current network			*/
/*			and redraw the graphics (should be blank)	*/
/*			called when "clear" button is hit		*/
/* 									*/
/* Date of creation:	21-10-92					*/
/* 									*/
/* input arguments:	SUIT_object obj		(not used)		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void clear_net(SUIT_object obj)
{
   destroy_blist (&root);
   SUIT_paintObject(petri_obj);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	obj_things					*/
/* 									*/
/* Description:		called when "del" radio buttons are hit, sets	*/
/*			the contents of the status window		*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	SUIT_object	obj 				*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void obj_things(SUIT_object obj)
{
   char action[20];

   GP_setCursor(STANDARD_CURSOR);

   switch (objing)
   {
     case ADDING:
	sprintf( action , "%s", "Adding");
	break;
     case ZAPPING:
	sprintf( action , "%s", "Removing");
	GP_setCursor(PIRATE_CURSOR);
	break;
     case MOVING:
	sprintf( action , "%s", "Moving");
	GP_setCursor(PROMPT_CURSOR);
	break;
   }

   sprintf
   (
      buffer, "%s %s",
      action,
      SUIT_getEnumString(obj, CURRENT_VALUE)
   );
   SUIT_setText(status_obj, LABEL, buffer);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	execute_net					*/
/* 									*/
/* Description:		executes the current petri-net			*/
/* 									*/
/* Date of creation:	dummy function 16-10-92				*/
/* 									*/
/* input arguments:	SUIT_object obj		(not used)		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void execute_net(SUIT_object obj)
{
   Net_state retval = FIRED;
   int howmany, nfired;

   GP_setCursor(WATCH_CURSOR);
   SUIT_setText(status_obj, LABEL, "Executing Net");
   SUIT_paintObject(status_obj);

   if (root)
   {
     howmany = SUIT_getNumber("number of times to fire?");
     if (howmany >0)
     {
       nfired = 0;

       while ((retval == FIRED)&&(nfired < howmany))
       {
          retval = run_net(root);
          refresh(petri_obj);

	  nfired++;
       }

       if (retval == DEAD)
         SUIT_inform("Net is deadlocked");
     }
     else
       SUIT_inform("Invalid number , operation cancelled");
   }
   else
     SUIT_inform("No objects in the net");

   obj_things(obj_radio);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	refresh						*/
/* 									*/
/* Description:		redraw contents of graphics window		*/
/*			called when "refresh" button is hit		*/
/* 									*/
/* Date of creation:	20-10-92					*/
/* 									*/
/* input arguments:	SUIT_object obj		(not used)		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:	used to change the status display. This was not	*/
/*			consistant, and the tme period wan not enough	*/
/*			to justify a message				*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void refresh(SUIT_object obj)
{
   GP_setCursor(WATCH_CURSOR);
   SUIT_paintObject(petri_obj);
   GP_setCursor(STANDARD_CURSOR);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name: 	toggle_grid					*/
/* 									*/
/* Description:		toggles whether the internal representation	*/
/*			of the links between the objects are shown	*/
/*			called when "show tree" button is hit		*/
/* 									*/
/* Date of creation:	20-10-92					*/
/* 									*/
/* input arguments:	SUIT_object obj		(not used)		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	None						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void toggle_grid(SUIT_object obj)
{
   GP_setCursor(WATCH_CURSOR);
   show_grid = !show_grid;
   refresh(petri_obj);
   GP_setCursor(STANDARD_CURSOR);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	Trace_net					*/
/* 									*/
/* Description:		traces the current petri-net			*/
/* 									*/
/* Date of creation:	dummy function 16-10-92				*/
/* 									*/
/* input arguments:	SUIT_object obj		(not used)		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void trace_net(SUIT_object obj)
{
   Net_state retval;

   GP_setCursor(WATCH_CURSOR);
   SUIT_setText(status_obj, LABEL, "Tracing Net");
   SUIT_paintObject(status_obj);

   if (root)
   {
     retval = run_net(root);

     if (retval == DEAD)
       SUIT_inform("Net is deadlocked");
   }
   else
     SUIT_inform("No objects in the net");

   obj_things(obj_radio);
   refresh(petri_obj);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	save_net					*/
/* 									*/
/* Description:		saves a new petri_net				*/
/* 									*/
/* Date of creation:	dummy function 4-12-92				*/
/* 									*/
/* input arguments:	SUIT_object obj		(not used)		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void save_net(SUIT_object obj)
{
   FILE *fp;
   char *newfile;

   SUIT_setText(status_obj, LABEL, "Saving Net");
   SUIT_paintObject(status_obj);

   if (!root)
   {
     SUIT_inform("Nothing to save !");
   }
   else
   {
     GP_setCursor(PROMPT_CURSOR);
     if (newfile = SUIT_askForFileName( ".", "SAVE NET TO FILE", filenam))
     {
	 /* -----------------------------------------------------------	*/
	 /* check if file allready exists				*/
	 /* -----------------------------------------------------------	*/
	 if (fp = fopen( newfile, "r") )
	 {

	   fclose(fp);
	   sprintf (buffer, "Overwrite file @b(%s) ?", newfile);
	   if ( SUIT_askYesNo(buffer) == REPLY_NO)
	   {
	      SUIT_inform("Save Aborted");
	      return;
	   }
	 }

	 /* -----------------------------------------------------------	*/
	 /* and save out stuff						*/
	 /* -----------------------------------------------------------	*/
	 if (fp = fopen( newfile, "w"))
	 {
	   save_header(fp);
	   save_branch(fp, root);
	   save_paths(fp, root);
	   fclose (fp);

	   if (filenam)
	     free (filenam);
	   filenam = strdup(newfile);
	 }
	 free(newfile);
     }
   }

   obj_things(obj_radio);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	load_net					*/
/* 									*/
/* Description:		loads a new petri_net				*/
/* 									*/
/* Date of creation:	dummy function 4-12-92				*/
/* 									*/
/* input arguments:	SUIT_object obj		(not used)		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void load_net(SUIT_object obj)
{
   char *newfile;
   FILE *fp;

   SUIT_setText(status_obj, LABEL, "Loading Net");
   SUIT_paintObject(status_obj);

   if (newfile = SUIT_askForFileName( ".", "LOAD NET FROM FILE", " "))
   {
     if  (fp = fopen(newfile, "r"))
     {
	if (load_header(fp))
	{
	  clear_net(petri_obj);
	  load_data(fp, &root);
	  refresh(petri_obj);

	  if (filenam)
	    free(filenam);
	  filenam = strdup(newfile);
	}
	else
	{
	  sprintf (buffer, "file @b(%s) isn't a petri-net file", filenam);
	  SUIT_inform(buffer);
	}
        fclose(fp);
	free(newfile);
     }
     else
     {
	sprintf (buffer, "file @b(%s) doesn't exist !", filenam);
	SUIT_inform(buffer);
     }
   }
   obj_things(obj_radio);
}

