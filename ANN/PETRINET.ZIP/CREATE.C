#include "sim.h"


/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/


/************************************************************************/
/*  create and destroy objects						*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	create_blist_node				*/
/* 									*/
/* Description:								*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

b_list create_blist_node( Object_type type, double x, double y)
{
     b_list new_sub_branch;
     int hash_v;
     double tmp_x, tmp_y;

     new_sub_branch = (b_list) malloc( sizeof(_blist));
     if (new_sub_branch != NULL)
     {
       hash_v = get_hash(x, y);
       unhash(hash_v , &tmp_x, &tmp_y);

       new_sub_branch->hash	= hash_v;
       new_sub_branch->x	= tmp_x;
       new_sub_branch->y	= tmp_y;
       new_sub_branch->my_type	= type;
       new_sub_branch->tokens	= 0;
       new_sub_branch->list	= (p_list) NULL;
       new_sub_branch->left	= (b_list) NULL;
       new_sub_branch->right	= (b_list) NULL;
       new_sub_branch->label	= (char *) NULL;
     }
     return (new_sub_branch);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	destroy_blist					*/
/* 									*/
/* Description:		destroys all nodes in a tree starting from the	*/
/*			curent branch					*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	pointer to tree to destroy			*/
/* 									*/
/* output:		modified pointer (hopefull NULL)		*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void destroy_blist(b_list *branch)
{
  if (*branch != NULL)
  {
     /* ---------------------------------------------------------------	*/
     /* destroy the sub-trees						*/
     /* ---------------------------------------------------------------	*/
        destroy_blist ( &(*branch)->left);
        destroy_blist ( &(*branch)->right);

     /* ---------------------------------------------------------------	*/
     /* destroy the list of paths					*/
     /* ---------------------------------------------------------------	*/
     destroy_plist ( *branch, &(*branch)->list);

     /* ---------------------------------------------------------------	*/
     /* wipe all trace of this tree					*/
     /* ---------------------------------------------------------------	*/
     free (*branch);
     *branch = NULL;
  }
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	create_plist_node				*/
/* 									*/
/* Description:		creates a new instance of a list-type node	*/
/* 									*/
/* Date of creation:	26-10-92					*/
/* 									*/
/* input arguments:	None						*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	the new list element				*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

p_list create_plist_node( )
{
     p_list new_element;

     new_element = (p_list) malloc( sizeof(_path_list));
     if (new_element != NULL)
     {
       new_element->what_i_am = UNKNOWN;
       new_element->strength = 1;
       new_element->item = (b_list) NULL;
       new_element->next = (p_list) NULL;
     }
     return (new_element);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	destroy_plist					*/
/* 									*/
/* Description:		destroys all elements in the list attached to 	*/
/*			a node, 					*/
/* 									*/
/* Date of creation:	27-10-92					*/
/* 									*/
/* input arguments:	branch						*/
/*			list to destroy					*/
/* 									*/
/* output:		modified pointer (hopefully NULL)		*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void destroy_plist(b_list branch, p_list *list)
{
   p_list	current = *list;

   if (*list)
   {
      destroy_plist ( branch, &(*list)->next);

      if (current->what_i_am == SOURCE)
	destroy_plist_element(  (*list)->item, branch, TARGET, ZAPALL);
      else
	destroy_plist_element(  (*list)->item, branch, SOURCE, ZAPALL);

      *list = current->next;
      free (current);
   }
}

void destroy_plist_element (
	b_list branch, b_list target, whatami thing, int zapall)
{
  p_list current, next;
  int found;

  if (branch && target)
  {
    if ( current = branch->list)
    {

      /* --------------------------------------------------------------	*/
      /* special case for the first element in the list			*/
      /* --------------------------------------------------------------	*/
      if ((current->item == target)&&(current->what_i_am == thing))
      {
         if (branch->list->strength >1)
	    branch->list->strength --;
         else
         {
           branch->list = current->next;
           free (current);
         }
      }
      /* --------------------------------------------------------------	*/
      /* check through the rest of the list for a match			*/
      /* --------------------------------------------------------------	*/
      else
      {
         found = FALSE;
  
         while (!found && current->next)
         {
	    next =  current->next;
	    found  = (next->item == target)&&(next->what_i_am == thing);
	    if (!found)
	       current = next;
         }
  
         if (found)
         {
           if (next->strength >1)
	      next->strength --;
           else
           {
	     current->next = next->next;
	     free(next);
           }
         }
      }
    }
  }
}

