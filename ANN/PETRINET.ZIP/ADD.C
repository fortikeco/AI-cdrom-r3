#include "sim.h"


/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/


/************************************************************************/
/*  add/remove objects to the tree					*/
/************************************************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	add_blist_node				*/
/* 									*/
/* Description:		given the pointer to a node, recursively add it	*/
/*			to the tree, based on the old add_element	*/
/* 									*/
/* Date of creation:	23-10-92					*/
/* 									*/
/* input arguments:	pointer to a tree				*/
/*			node to add					*/
/* 									*/
/* output:		modified pointer to the tree			*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void add_blist_node( b_list *branch, b_list node)
{

  if (*branch == NULL)
    *branch = node;
  else
  {
    int branch_hash = (*branch)->hash;
    int node_hash   =  node->hash;

    if (node_hash > branch_hash)
    {
       add_blist_node( &((*branch)->right) , node);
    }
    else if (node_hash < branch_hash)
    {
       add_blist_node( &((*branch)->left) , node);
    }
    else
    {
       if ((*branch)->my_type == DELETED)
       {
	 (*branch)->my_type = node->my_type;
	 (*branch)->tokens = 0;
	 (*branch)->list = (p_list)NULL;
	 (*branch)->label = (char *) NULL;
       }

       /* ---- square is occupied, modify its label  ---- */
       else
       {
	   char def[20];
	   char ans[20];

	   if ((*branch)->label)
	     strcpy(def, (*branch)->label);
	   else
	     strcpy(def, "undefined");

	   GP_setCursor(PROMPT_CURSOR);
	   if (SUIT_getString("place label", def, ans, 20) == REPLY_OK)
	   {
	      if ((*branch)->label)
	        free ((*branch)->label);
	      (*branch)->label = strdup(ans);
	      refresh(petri_obj);
	   }
	   GP_setCursor(STANDARD_CURSOR);
       }
       destroy_blist(&node);
    }
  }
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	add_path					*/
/* 									*/
/* Description:		if the two objects are not of the same type	*/
/*			a link is formed from the source to the target	*/
/* 									*/
/* Date of creation:	26-10-92					*/
/* 									*/
/* input arguments:	The objects contained in source, targets	*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/*	checks if a path allready exists between the source and target,	*/
/*	if it does just increase the strength of the connection		*/
/* 									*/
/* 	store duplicate entries with places, as this will make it 	*/
/*	easier to identofy any nets in the analysis stage		*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void add_path(b_list source, b_list target)
{
   p_list element, found;
   Object_type s_type, t_type;

   if (source && target)
   {
     s_type = source->my_type;
     t_type = target->my_type;

     if ((s_type != DELETED) && (t_type!= DELETED) && (s_type != t_type))
     {
       /* -------------------------------------------------------------	*/
       /* add a path between source and target				*/
       /* -------------------------------------------------------------	*/
       if (found = is_path(source, target, SOURCE))
         found->strength++;
       else
       {
          element = create_plist_node();
  
          if (element)
          {
             element->what_i_am = SOURCE;
             element->strength = 1;
	     element->item = target;
             element->next = source->list;
             source->list = element;
          }
       }
  
       /* -------------------------------------------------------------	*/
       /* add a duplicate path between target and source		*/
       /* -------------------------------------------------------------	*/
       if (found = is_path(target, source, TARGET))
         found->strength++;
       else
       {
          element = create_plist_node();
  
          if (element)
          {
             element->what_i_am = TARGET;
             element->strength = 1;
	     element->item = source;
             element->next = target->list;
             target->list = element;
          }
       }
     }
     else
     {
        SUIT_inform("source and target must be different symbol types");
     }
   }
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	add_element					*/
/* 									*/
/* Description:		generates a node and adds the node to the tree	*/
/* 									*/
/* Date of creation:	20-10-92					*/
/* 									*/
/* input arguments:	pointer to the tree				*/
/*			type of object to add				*/
/*			locating coordinate of object			*/
/* 									*/
/* output:		modified tree					*/
/* 									*/
/* function return:	None						*/
/* 									*/
/* Modifications:	The original function created the node and	*/
/*			added the information to the tree itself.	*/
/*			The add of the node to the tree is now done by	*/
/*			add_blist_node				*/
/* 									*/
/* 			name changed from add_to_tree to add_element	*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

b_list add_element( b_list *net , Object_type type, double x, double y)
{
  b_list	node;

  node = create_blist_node(type, x, y);
  add_blist_node(net, node);

  return(node);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/* 									*/
/* Description:								*/
/* 									*/
/* Date of creation:	1-12-92						*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void destroy_path(b_list source, b_list target)
{
  if ( source && target )
  {
    Object_type s_type, t_type;

    s_type = source->my_type;
    t_type = target->my_type;

    if ((s_type != DELETED) && (t_type != DELETED))
      if (s_type != t_type)
      {
        destroy_plist_element (source, target, SOURCE, ZAPONE);
        destroy_plist_element (target, source, TARGET, ZAPONE);
      }
  }
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	destroy_place					*/
/* 									*/
/* Description:		destroys a place and all its paths		*/
/* 									*/
/* Date of creation:	1-12-92						*/
/* 									*/
/* input arguments:	the place to kill				*/
/* 									*/
/* output:		modified place					*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void destroy_place( b_list node)
{
   if (node && (node->my_type == PLACE))
   {
       destroy_plist( node,  &(node->list) );
       node->my_type = DELETED;
       node->tokens =0;
       if (node->label)
       {
	  free (node->label);
          node->label = NULL;
       }
   }
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	destroy_transition				*/
/* 									*/
/* Description:		removes all the paths, removes the node from	*/
/*			branch, adds the subtrees and frees the node	*/
/* 									*/
/* Date of creation:	1-12-92						*/
/* 									*/
/* input arguments:							*/
/* 									*/
/* output:								*/
/* 									*/
/* function return:							*/
/* 									*/
/* Modifications:							*/
/*	truncating subtrees is all well and fine, but just you try to 	*/
/*	implement it. It may be better to just mark the nodes to as	*/
/*	deleted								*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void destroy_transition( b_list node)
{
   if (node && (node->my_type == TRANSITION))
     {
       destroy_plist( node,  &(node->list) );
       node->my_type = DELETED;
       node->tokens =0;
       node->label = NULL;
     }
}


