#include "sim.h"


/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/

/************************************************************************/
/* globals								*/
/************************************************************************/

SUIT_object obj_radio;
SUIT_object petri_obj;
SUIT_object status_obj;

char buffer[MYBUFSIZ];

b_list  root = (b_list) NULL;

int debug = FALSE;
int show_grid = FALSE;
int mono = FALSE;
int ngrids;

int times_fired = 15;

Happening objing = ADDING;



/************************************************************************/
/* main interface creating functions					*/
/************************************************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	main						*/
/* 									*/
/* Description:		initializes SUIT interface			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	None						*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void main (int argc, char *argv[])
{
#ifdef INSTALL
    SUIT_initFromCode(argv[0]);
#else
    SUIT_init(argv[0]);
#endif

    if (argc >1)
    {
      mono = (strcmp (argv[1],"-mono") == 0);
    }

    ngrids = nint(1.0/GRID);

    setup_interface();
    GNU_thing();
    SUIT_beginStandardApplication();
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	setup_interface					*/
/* 									*/
/* Description:		creates user interface items, sets callbacks	*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	none						*/
/* 									*/
/* output:		none						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void setup_interface()
{
  SUIT_object	obj_board, status_board, act_board, do_board;
  SUIT_object	file_board, net_board;
  SUIT_object	addel_radio;
  SUIT_object	show_button, refresh_button, done_button, go_button;
  SUIT_object	trace_button, clear_button, load_button, save_button;

  /* ------------------------------------------------------------------	*/

  SUIT_createLabel("Petri Net Simulator");

  /* ------------------------------------------------------------------	*/

  obj_board = SUIT_createBulletinBoard("obj_board");

  addel_radio = SUIT_createRadioButtons("adddel_butons", set_status);
  SUIT_addButtonToRadioButtons(addel_radio, "Add");
  SUIT_addButtonToRadioButtons(addel_radio, "Move");
  SUIT_addButtonToRadioButtons(addel_radio, "Remove");

  obj_radio = SUIT_createRadioButtons("obj_buttons", obj_things);
  SUIT_addButtonToRadioButtons(obj_radio, "Path");
  SUIT_addButtonToRadioButtons(obj_radio, "Place");
  SUIT_addButtonToRadioButtons(obj_radio, "Token");
  SUIT_addButtonToRadioButtons(obj_radio, "Transition");

  SUIT_addChildToObject(obj_board, addel_radio);
  SUIT_addChildToObject(obj_board, obj_radio);

  /* ------------------------------------------------------------------	*/
  do_board = SUIT_createBulletinBoard("do_board");
  clear_button = SUIT_createButton("Clear", clear_net);
  show_button = SUIT_createButton("toggle_grid", toggle_grid);
  refresh_button = SUIT_createButton("Refresh", refresh);

  SUIT_addChildToObject(do_board, clear_button);
  SUIT_addChildToObject(do_board, show_button);
  SUIT_addChildToObject(do_board, refresh_button);

  /* ------------------------------------------------------------------	*/
  net_board = SUIT_createBulletinBoard("net_board");
  trace_button = SUIT_createButton("trace", trace_net);
  go_button = SUIT_createButton("Go", execute_net);

  SUIT_addChildToObject(net_board, go_button);
  SUIT_addChildToObject(net_board, trace_button);

  /* ------------------------------------------------------------------	*/
  file_board = SUIT_createBulletinBoard("file_board");
  save_button = SUIT_createButton("Save...", save_net);
  load_button = SUIT_createButton("Load...", load_net);

  SUIT_addChildToObject(file_board, save_button);
  SUIT_addChildToObject(file_board, load_button);

  /* ------------------------------------------------------------------	*/
  status_board = SUIT_createBulletinBoard("status_board");
  status_obj   = SUIT_createLabel("current_status");

  SUIT_addChildToObject(status_board, status_obj);


  /* ------------------------------------------------------------------	*/

  petri_obj = CreatePetriWidget("petri");

  /* ------------------------------------------------------------------	*/

  act_board = SUIT_createBulletinBoard("actions");
  done_button = SUIT_createDoneButton(NULL);

  SUIT_addChildToObject(act_board, done_button);

}
