#include "sim.h"


/*
  sim: simple petri net simulator developed using the SUIT toolkit 

  Copyright (C) 1993  Sunil Gupta

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The author can be contacted by emailing cs89ssg@brunel.ac.uk
  before the end of August 1993, or via the newsgroup alt.bugs after
  August 1993.
*/


/************************************************************************/
/* painting operations							*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	paint_label					*/
/* 									*/
/* Description:		paint the label on an object			*/
/* 									*/
/* Date of creation:	10-12-92					*/
/* 									*/
/* input arguments:	branch, object to paint				*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void	paint_label( b_list branch )
{
   GP_point locating_pt;

   if ((branch) &&(branch->label))
   {
     locating_pt.y = branch->y;

     if (branch->my_type == PLACE)
        locating_pt.x = branch->x+SYM_HT*1.1;
     else if (branch->my_type == TRANSITION)
        locating_pt.x = branch->x+SYM_HT/2.5;
     else 
        locating_pt.x = branch->x+SYM_HT;

     set_colour("darkviolet");
     GP_text(locating_pt, branch->label);
     set_colour("black");
   }
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	paint_grid					*/
/* 									*/
/* Description:		paint the grid on top of the graphics		*/
/*			window, called from refresh()			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	obj	SUIT object (hopefully graphics)	*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void paint_grid( SUIT_object obj)
{
  double x;

  set_colour("peachpuff");
  for (x = 0.0 ; x<1.0; x+=GRID)
  {
     GP_lineCoord( x, 0.0 , x, 1.0);
     GP_lineCoord( 0.0 , x, 1.0, x);
  }
  set_colour("black");
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	paint_path_list					*/
/* 									*/
/* Description:		paint the paths which form the network		*/
/*			recursively using the list attached to objects	*/
/* 									*/
/* Date of creation:	26-10-92					*/
/* 									*/
/* input arguments:	source node for the starting x, y coords	*/
/*			list of paths for targets			*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/*   PLaces are not really deleted, so if the place doesnt exist on a	*/
/*  path, remove that element and redraw the whole path list		*/
/* 									*/
/*  only draw paths from the source this reduces work being dupicated	*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void paint_path_list( b_list node, p_list element)
{
  b_list	target, source;
  GP_point	start_pt, end_pt ;
  GP_point	wing1, nose, wing2;


  if (node && element)
  {
    /* ----------------------------------------------------------------	*/
    /* which is the source and the target				*/
    /* ----------------------------------------------------------------	*/
    if (element->what_i_am == SOURCE)
    {
       source = node;
       target = element->item;
       /* -----------------------------------------------------------	*/
       /* work out line coordinates					*/
       /* -----------------------------------------------------------	*/
       start_pt.x = source->x;	start_pt.y = source->y;
       end_pt.x= target->x;	end_pt.y = target->y;

  
       get_arrow( start_pt, end_pt, &wing1, &nose, &wing2);

       /* -----------------------------------------------------------	*/
       /* draw the damn thing						*/
       /* -----------------------------------------------------------	*/
       GP_line( start_pt, end_pt);
       paint_triangle (wing1, nose, wing2);

       if (element->strength > 1)
       {
	   char *txt;
   
	   GP_point textpos, delta;

	   delta.x = wing2.x - wing1.x;
	   delta.y = wing2.y - wing1.y;

	   textpos.x = wing1.x + 2.5*delta.x;
	   textpos.y = wing1.y + 2.5*delta.y;

           txt = itoa(element->strength);
           GP_text(textpos, txt);
           free(txt);
       }
    }
    paint_path_list(node, element->next);
  }

}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	paint_paths					*/
/* 									*/
/* Description:		recursive function to paint the petri-net paths	*/
/*			this is done before the symbols, so that the	*/
/*			symbols come out on top				*/
/* 									*/
/* Date of creation:	30-11-92					*/
/* 									*/
/* input arguments:	the branch of the tree to repaint		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:	taken out from paint symbols into a function	*/
/*			all by itself					*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void paint_paths( b_list branch)
{
  if (branch != NULL)
  {
    paint_paths (branch->left);
    paint_paths (branch->right);

    paint_path_list(branch, branch->list);
  }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	paint_symbols					*/
/* 									*/
/* Description:		recursive function to paint the petri-net tree	*/
/* 									*/
/* Date of creation:	17-10-92					*/
/* 									*/
/* input arguments:	the branch of the tree to repaint		*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void paint_symbols( b_list branch)
{
  double x, y;

  if (branch != NULL)
  {
    y = branch->y;
    x = branch->x;

    /* ----------------------------------------------------------------	*/
    /* paint the sub-trees first, 					*/
    /* ----------------------------------------------------------------	*/
    paint_symbols (branch->left);
    paint_symbols (branch->right);

    /* ----------------------------------------------------------------	*/
    /* draw the symbol at this node					*/
    /* ----------------------------------------------------------------	*/
    switch( branch->my_type )
    {
      case PLACE:

         GP_setColor(GP_defColor("grey", FALSE));
         GP_fillEllipseCoord(x-SYM_HT, y-SYM_HT, x+SYM_HT, y+SYM_HT);
         GP_setColor(GP_defColor("black", FALSE));
         GP_ellipseCoord(x-SYM_HT, y-SYM_HT, x+SYM_HT, y+SYM_HT);

         if (branch->tokens > 0)
         {
           GP_point locating_pt;
           char *txt;
   
           locating_pt.x = x;
           locating_pt.y = y;

           txt = itoa(branch->tokens);
           GP_text(locating_pt, txt);
           free(txt);
         }

	 paint_label(branch);
         break;

      case TRANSITION:
         GP_fillRectangleCoord(x-.006, y-SYM_HT, x+.006, y+SYM_HT);
	 paint_label(branch);
         break;

      case DELETED:
	 if (show_grid)
	 {
           set_colour("red");
	   GP_lineCoord(x-SYM_HT, y-SYM_HT, x+SYM_HT, y+SYM_HT);
	   GP_lineCoord(x-SYM_HT, y+SYM_HT, x+SYM_HT, y-SYM_HT);
           set_colour("black");
	 }
	 break;

      default:
	 break;
    }

  }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	paint_triangle					*/
/* 									*/
/* Description:		draws a 3 point polygon				*/
/* 									*/
/* Date of creation:							*/
/* 									*/
/* input arguments:	the three points				*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void	  paint_triangle( GP_point p1, GP_point p2, GP_point p3)
{
  GP_point vertices[3] = { p1, p2, p3};
  GP_fillPolygon(3, vertices);
}


