/*
* ADDCOL.C
* Utility to add data as the the last column of EACH line of a file
* by taking information from a specific column in EACH line of another file
* which also has the capability of:
* 1) Using the percentage difference between this line as the last line
*    (in the same column) as the value to add.
* 2) Using a multiline "window". Adding data from current line and
*    several previous lines.
*
* Usage: 
* ADDCOL <file to add column to> <file to copy column from> [<options> ...]
*
* Options:
* -Cn 		select the column 
*			if used more than once will add columns
* -%		use percentage difference (defaults to no)
* -Wn		use n-line window (defaults to 1 line)
* 
* Copyright (c) 1988-91, Adam Blum
*/

#include <stdio.h>
#include <stdlib.h>

int procline(char *mrgline);
int getncol(int n,char **p);
int scan(char **p);
int span(char **p);
int getargs(int argc,char **argv);

#define MAXLINE 2048
#define MAXWINSIZE 8

char ofn[32],ifn[32],tfn[32]="ADDCOL.TMP";
char mrgline[MAXLINE];
char win[MAXWINSIZE][MAXLINE],colwin[MAXWINSIZE][16],pctwin[MAXWINSIZE][8];
char op=0;
int pct=0,cols[2],winsize=1,lineno=0,i;
FILE *inf,*of,*tf;

main(int argc,char **argv)
{
	char *p;
	getargs(argc,argv);
	inf=fopen(ifn,"r");
	if(!inf){
		printf("Failed to open input file.\n");
		exit(1);
	}
	printf("Extracting column(s) from file %s.\n",ifn);

	of=fopen(ofn,"r");

	printf(of?"Combining to file %s.\n":"Creating file %s.\n",ofn);

	if(op&&!isspace(op))
		printf("Combining multiple columns using %c operator.\n",op);
	if(pct)
		printf("Using percentage difference between rows.\n");
	if(winsize>1)
		printf("Using multiline window to create %d new columns.\n",winsize);

	tf=fopen(tfn,"w");

	printf("Processing file ");

	
	if(of && !feof(of)){
			fgets(mrgline,MAXLINE,of);	
			strip(mrgline);
	}
	else
		mrgline[0]=0;
	
	if(mrgline[0])
		fprintf(tf,"%s",mrgline); 

	/* get base name of input file */
	p=strchr(ifn,'.');
	if(p)
		*p=0;

	if(winsize>1){
		for(i=0;i<winsize;i++)
			fprintf(tf,"\t%s%d_%d",ifn,cols[0],i+1);
	}
	else
	 	fprintf(tf,"\t%s%d",ifn,cols[0]);
	
	fprintf(tf,"\n");

	for(;;){
		if(of && !feof(of)){
			fgets(mrgline,MAXLINE,of);	
			strip(mrgline);
		}
		else
			mrgline[0]=0;

		slidewin();

		fgets(win[0],MAXLINE,inf);	
		strip(win[0]);
		if(!win[0][0])continue;

		if(feof(inf))break;		

		procline(mrgline);

		if(++lineno >= winsize)
			fprintf(tf,"%s\n",mrgline);

		printf(".");
	}

	printf("\nProcessing complete.\n");

	fclose(inf);
	if(of)
		fclose(of);
	fclose(tf);
	remove(ofn);
	rename(tfn,ofn);

}

slidewin()
{
	memmove(win[1],win[0],(MAXWINSIZE-1)*sizeof(win[0]));
	memmove(colwin[1],colwin[0],(MAXWINSIZE-1)*sizeof(colwin[0]));
	memmove(pctwin[1],pctwin[0],(MAXWINSIZE-1)*sizeof(pctwin[0]));
}

strip(s)
char *s;
{
	int i,l=strlen(s);
	for(i=l-1;isspace(s[i]);i--);s[i+1]=0;
}

procline(char *mrgline)
{
	int i;char *p;
	double curval,prevval,pctage,rand1,rand2,result;
	p=win[0];
	getncol(cols[0],&p);
	if(op&&!isspace(op)){
		rand1=atof(p);
		p=win[0];
		getncol(cols[1],&p);
		rand2=atof(p);
		switch(op){
		case '*':result=rand1*rand2;break;
		case '/':
			if(rand2)
				result=rand1/rand2;
			else
				result=0;		
			break;
		case '+':result=rand1+rand2;break;
		case '-':result=rand1-rand2;break;
		default: result=rand1;break;
		}
		sprintf(colwin[0],"\t%.2f",result);
	}
	else
		sprintf(colwin[0],"\t%s",p);

	if(pct){
		curval=atof(colwin[0]);
		prevval=atof(colwin[1]);
		if(prevval)
			pctage=((curval-prevval)/prevval)*100;
		else
			pctage=0;
		sprintf(pctwin[0],"\t%2.0f",pctage);
	}

	for(i=0;i<winsize;i++)
		strcat(mrgline,pct?pctwin[i]:colwin[i]);
}

getncol(int n,char **p)
{
	int i;char *p2;
	if(!n){	/* default says grab last piece of data on line */
		*p=*p+strlen(*p);
		while(isspace(**p))
			*p--;
		*(p+1)=0;
		while(!isspace(**p))
			*p--;
		p++;
	}
	else{
		scan(p); /* skip whitespace to first data piece */
		for(i=1;i<n;i++){
			span(p);/* skip over data piece */
			scan(p);/* skip over white space */
		}	   
		
		if(!op){		   
			memcpy(&p2,p,sizeof(char *));	
			span(&p2);
			*p2=0; /*terminate end of data */
		}
	}
}

scan(char **p)
{
	while(isspace(**p))
		(*p)++;
}

span(char **p)
{
	while(!isspace(**p))
		(*p)++;
}

getargs(int argc,char **argv)
{
	int i;
	strcpy(ofn,argv[1]);
	strcpy(ifn,argv[2]);
	for(i=3;i<argc;i++){
		if(argv[i][0]=='-'){
			switch(toupper(argv[i][1])){
			case 'P':pct=1;
				break;
			case 'W':winsize=argv[i][2]-'0';
				break;
			case 'C':
				cols[0]=argv[i][2]-'0';
				op=argv[i][3];
				if(op&&!isspace(op))
					cols[1]=argv[i][4]-'0';
				break;
			}
		}
	}
}


