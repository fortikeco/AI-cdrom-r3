Hand printed OCR Demo

This demo requires Windows 3.1 to execute!!!

This demo uses neural network technology developed at Cirrus Recognition
to perform recognition of hand printed digits 0-9.  You may either draw a 
character in the drawing window or use one of the included scanned examples.
Included examples can be selected by pushing the arrow buttons or by entering
a character number.  In either case, CirrusNet attempts to classify the
mark shown in the drawing area as one of the digits 0-9.  The classification
is shown in the top part of the application window.

Observations:

This demo was prepared as part of a proof of concept package for recognition
of hand printed scanned characters.  Recognition has been optimized for data
scanned at 300 DPI.  At this resolution, all but the thinnest characters
have stroke width.  The included examples illustrate this trait.  On the
other hand, digits drawn by hand tend to be "stick" figures and therefore do
not correspond well with the training data.  Recognition improves if "stick"
digits are thickened.

Confidence values reported by this demo are not normalized.  Therefore a 
confidence of 50 for a "1" may indicate the same level of confidence as 
a confidence of 100 for a "9". In other words, do not compare confidences 
across digits and expect to glean anything meaningful.

The demo may report recognition of a drawn mark as more than one digit.
This indicates that the mark has characteristics of multiple digits and 
cannot be uniquely classified.

Negative and very low confidences are the equivalent of a rejection.  The 
demo has no threshold setting for outright rejection.  Everything is 
classified as something.


If you have any questions about this demo, please contact Mike Blundin at
71303.1116@compuserve.com.
