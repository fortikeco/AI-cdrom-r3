/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include <stdio.h>
#include <math.h>

#include "spiral.h"
  

static double x_p[96], y_p[96];
static double x_n[96], y_n[96];

main()
{
  int i;
  double x, y, angle, radius;
  

  for (i=0; i<=96; i++) {
    angle = i * BP_PI / 16.0;
    radius = 6.5 * (104 - i) / 104.0;
    x = radius * sin(angle);
    y = radius * cos(angle);
    printf("%8.5f  %8.5f   %3.1f\n",  x,  y, 0.5);
    printf("%8.5f  %8.5f   %3.1f\n",  -x,  -y, -0.5);
  }


}

