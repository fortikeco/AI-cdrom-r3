/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "nn.h"

#include "bayes.h"

extern void define_generator(void (*f)(char *item), char *item, char *string);

/*
 *   NormalRandom()    --  Uses the Box-Jenkins technique
 */
static int NRswitch = 0;
static double NR_u1, NR_u2;
static float NormalRandom(float mean, float variance)
{
  if (NRswitch == 0) {
    while((NR_u1 = AM_RANDOM()) == 0.0);
    while((NR_u2 = AM_RANDOM()) == 0.0);
    NRswitch = 1;
    return( mean + AM_SQRT((double)(-2.0 * AM_LOG(NR_u1) * variance)) * AM_COS((double)(2.0 * AM_PI * NR_u2)) );
  } else {
    NRswitch = 0;
    return( mean + AM_SQRT((double)(-2.0 * AM_LOG(NR_u1) * variance)) * AM_SIN((double)(2.0 * AM_PI * NR_u2)) );
  }
}  /* end NormalRandom() */

static float targetv[4], inputv[2];

static void H1()
{
  inputv[0] = NormalRandom(H1_XMEAN, (H1_STD*H1_STD) );
  inputv[1] = NormalRandom(H1_YMEAN, (H1_STD*H1_STD) );
}

static void H2()
{
  inputv[0] = NormalRandom(H2_XMEAN, (H2_STD*H2_STD) );
  inputv[1] = NormalRandom(H2_YMEAN, (H2_STD*H2_STD) );
}

static void H3() 
{
  inputv[0] = NormalRandom(H3_XMEAN, (H3_STD*H3_STD) );
  inputv[1] = NormalRandom(H3_YMEAN, (H3_STD*H3_STD) );
}

static void H4() 
{
  inputv[0] = NormalRandom(H4_XMEAN, (H4_STD*H4_STD) );
  inputv[1] = NormalRandom(H4_YMEAN, (H4_STD*H4_STD) );
}

static void gauss()
{
  float dist;

  dist = AM_RANDOM();
  if ( dist < 0.25 ) {
    H1();
    targetv[0] = 1.0;
    targetv[1] = 0.0;
    targetv[2] = 0.0;
    targetv[3] = 0.0;
  }  else if ( dist < 2*0.25 ) {
    H2();
    targetv[0] = 0.0;
    targetv[1] = 1.0;
    targetv[2] = 0.0;
    targetv[3] = 0.0;
  } else if ( dist < 3*0.25 ) {
    H3();
    targetv[0] = 0.0;
    targetv[1] = 0.0;
    targetv[2] = 1.0;
    targetv[3] = 0.0;
  } else {
    H4();
    targetv[0] = 0.0;
    targetv[1] = 0.0;
    targetv[2] = 0.0;
    targetv[3] = 1.0;
  }

  inputv[0] *= 10.0;
  inputv[1] *= 10.0;
}

void user_init()
{

  nn_set_target_output(targetv);
  nn_set_input(inputv);

  nn_set_random_init_range(0.1);
  define_generator(gauss, (char *)NULL, "G");
}


