/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/


/* input bounds */
#define XSTART -0.03
#define YSTART -0.12
#define XSTOP  0.05
#define YSTOP  0.1

/* distribution parameters */
#define THRESHOLD 0.01

/* H1 */
#define H1_XOFFSET -0.0202
#define H1_YOFFSET 0.0404
#define H1_XX 3.85297e+4
#define H1_YY 1.36977e+4
#define H1_XY 2.13087e+4

/* H2 */
#define H2_XOFFSET -0.0295
#define H2_YOFFSET 0.0357
#define H2_XX 3.78316e+4
#define H2_YY 1.42733e+4
#define H2_XY 2.166338e+4

/* H3 */
#define H3_XOFFSET 0
#define H3_YOFFSET 0
#define H3_SCALE 7.27646e+4


/* plot resolution */
#define WIDTH 100
#define HEIGHT 100


/* network layer sizes */
#define N_H2_NODES 4
#define N_H1_NODES 4
