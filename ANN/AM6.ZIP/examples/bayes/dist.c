/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "nn.h"

#include "bayes.h"


static float targetv[3], inputv[2];

static void H1()
{
  double x, y;


  inputv[0] = NormalRandom(H1_XOFFSET, 
  inputv[1] = (AM_RANDOM() * (YSTOP - YSTART)) + YSTART;


  x = inputv[0] + H1_XOFFSET;
  y = inputv[1] + H1_YOFFSET;

  targetv[0] = (THRESHOLD < exp( -0.5 * (x*x*H1_XX + y*y*H1_YY +x*y*H1_XY*2) ) ) ? 1.0 : 0.0;

}

static void H2()
{
  double x, y;

  x = inputv[0] + H2_XOFFSET;
  y = inputv[1] + H2_YOFFSET;

  targetv[1] = (THRESHOLD < exp( -0.5 * (x*x*H2_XX + y*y*H2_YY +x*y*H2_XY*2) ) ) ? 1.0 : 0.0;

}
static void H3() {
  double x, y;

  x = inputv[0] + H3_XOFFSET;
  y = inputv[1] + H3_YOFFSET;

  targetv[2] = (THRESHOLD < exp( -0.5 * (x*x + y*y) * H3_SCALE ) ) ? 1.0 : 0.0;

}

static void gauss()
{
  float dist;

  dist = AM_RANDOM;
  if ( dist < 0.333333 ) {
    H1();
    targetv[0] = 1.0;
    targetv[1] = 0.0;
    targetv[2] = 0.0;
  }  else if ( dist < 2*0.333333 ) {
    H2();
    targetv[0] = 0.0;
    targetv[1] = 1.0;
    targetv[2] = 0.0;
  } else {
    H3();
    targetv[0] = 0.0;
    targetv[1] = 0.0;
    targetv[2] = 1.0;
  }

  inputv[0] *= 10.0;
  inputv[1] *= 10.0;
}

void user_init()
{

  nn_set_target_output(targetv);
  nn_set_input(inputv);

  nn_set_random_init_range(0.1);
  define_generator(gauss, (char *)NULL, "G");
}


