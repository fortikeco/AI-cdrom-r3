/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "nn.h"

#include "bayes.h"

static float h123[WIDTH*HEIGHT];

static float inputv[2];

static void print_d(a)
     float *a;
{
  int width=WIDTH, height=HEIGHT;

  while(height--) {

    width = WIDTH;
    while(width--) {
      printf("%f\n", *a++);
    }
    printf("\n\n");
  }
}

main()
{
  int width=WIDTH, height=HEIGHT;
  float *h123_ptr=h123, *output;
  float x=XSTART, y=YSTART, xinc, yinc;

  network_initialize("Network.save", 0);

  nn_set_input(inputv);
  output = nn_get_output();

  xinc = (XSTOP - XSTART) / WIDTH ;
  yinc = (YSTOP - YSTART) / HEIGHT ;
  while(height--) {

    width = WIDTH;
    x = XSTART;
    while(width--) {
      float mag_diff, max = -1000000;

      /* set input */
      inputv[0] = x*10.0;
      x += xinc;

      inputv[1] = y*10.0;

      /* run network */
      nn_propagate_forward(); 

      /* max diff */
      mag_diff = fabs( (double) (output[0]- output[1]));
      if (mag_diff > max ) max = mag_diff;
      mag_diff = fabs( (double) (output[0]- output[2]));
      if (mag_diff > max ) max = mag_diff;
      mag_diff = fabs( (double) (output[0]- output[3]));
      if (mag_diff > max ) max = mag_diff;
      mag_diff = fabs( (double) (output[1]- output[2]));
      if (mag_diff > max ) max = mag_diff;
      mag_diff = fabs( (double) (output[1]- output[3]));
      if (mag_diff > max ) max = mag_diff;
      mag_diff = fabs( (double) (output[2]- output[3]));
      if (mag_diff > max ) max = mag_diff;

      /* record output */
      *h123_ptr++ = ((1-max)*100)+150;

    }/* width */
    y += yinc;
  }

  print_d(h123);

}
