/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/

/*************** Class dist stuff ****************/

#define NORMAL_SCALAR 0.15915494

/* H1 */
#define H1_XMEAN 0.04
#define H1_YMEAN 0.02

#define H1_STD 0.19749143e-1

/* H2 */
#define H2_XMEAN -0.04
#define H2_YMEAN 0.02

#define H2_STD 0.19749143e-1


/* H3 */
#define H3_XMEAN 0
#define H3_YMEAN -0.02

#define H3_STD 0.19749143e-1

/* H4 */
#define H4_XMEAN 0
#define H4_YMEAN 0.02

#define H4_STD 0.1e-1


/*************** Plot stuff ****************/
/* plot resolution */
#define WIDTH 100
#define HEIGHT 100


/* input bounds */
#define XSTART -0.1
#define YSTART -0.1
#define XSTOP  0.1
#define YSTOP  0.1

/*************** Net arch stuff ****************/
/* network layer sizes */
#define N_H2_NODES 2
#define N_H1_NODES 4
