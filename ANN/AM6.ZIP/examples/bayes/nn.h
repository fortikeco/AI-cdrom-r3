/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/

/* backpropagation simulator header file */
/* From: nn.aspirin */

#include "aspirin_bp.h"


/* NETWORK FUNCTIONS */
extern void nn_set_learning_rate(float x);
extern void nn_set_inertia(float x);
extern float nn_get_learning_rate();
extern float nn_get_inertia();
extern int nn_init_network();
extern void nn_set_random_init_seed(long x);
extern void nn_set_random_init_range(float x);
extern int nn_load_network(char *filename);
extern int nn_dump_network();
extern int nn_ascii_dump_network(char *filename);
extern char *nn_error_string();
extern LB_PTR nn_query_network(int bbindex, int lindex);

/* BLACK BOX FUNCTIONS */

extern void nn_propagate_forward();
extern float nn_calc_error();
extern void nn_calc_grad();
extern void nn_update_weights(float scalar);
extern void nn_set_backprop_counter(int x);
extern int nn_get_backprop_counter();
extern float *nn_get_output();
extern void nn_set_target_output(float *target);
extern float *nn_get_target_output();
extern void nn_set_input(float *input);
extern float *nn_get_input();
/* GENERIC INTERFACE FUNCTIONS (begin with network_) */
extern void network_initialize(char *filename, int verbose);
extern void network_forward(int iterations, void (*generator)(void) );
extern void network_learn(int iterations, void (*generator)(void) );
extern void network_clear_delays();
extern void network_dump(char *filename);
extern void network_load(char *filename);
extern void network_ascii_dump(int formatted);
extern void network_load_ascii();
extern LB_PTR network_query(int bbindex, int lindex);
extern void network_forward_print(int iterations, void (*generator)(void) );
extern void network_forward_pdpfa(int iterations, void (*generator)(void), float threshold);

