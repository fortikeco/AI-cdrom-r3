/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/


/* You may want to run this thru 'cb' or 'indent' */

/**** Back-propagation simulation for nn.aspirin ****/


#include "aspirin_bp.h"


#include "BpSim.h"


/* GLOBAL VARIABLES */
float  BPlearning_rate = 0.2; 
float  BPinertia = 0.95;      
static float  init_range = 0.1;
static long   init_seed = 123;



/* Don't backprop if Error < BPthreshold */
float         BPthreshold = 0.000050;

char error_string[E_STRING_SIZE]; /* describes current error */

/* Connection Buffer for interconnect data */
static CB connection_buffer[6];

/* Communication Buffer */
static LB comms_buffer;

/* NETWORK DATA */
#ifndef PADDING
# define PADDING 0
#endif
static float network_data[206+PADDING];


/* data for nn */
static unsigned int b0fcounter = 0; /* # times fwd */
static unsigned int b0bcounter = 0; /* # times bkwd */

/* nn:H1 */
#define b0_l2_v (network_data + 0) /* values */
#define b0_l2_t (network_data + 20) /* thresholds */
#define b0_l2_ac (network_data + 24) /* accumulated changes */
#define b0_l2_dt (network_data + 28) /* delta thresholds */
#define b0_l2_c (network_data + 4) /* credit */

/* nn:H2 */
#define b0_l1_v (network_data + 8) /* values */
#define b0_l1_t (network_data + 32) /* thresholds */
#define b0_l1_ac (network_data + 34) /* accumulated changes */
#define b0_l1_dt (network_data + 36) /* delta thresholds */
#define b0_l1_c (network_data + 10) /* credit */

/* nn:Out */
#define b0_l0_v (network_data + 12) /* values */
#define b0_l0_t (network_data + 38) /* thresholds */
#define b0_l0_ac (network_data + 42) /* accumulated changes */
#define b0_l0_dt (network_data + 46) /* delta thresholds */
#define b0_l0_c (network_data + 16) /* credit */

static float *b0_input_vector = (float *)NULL; /* input vector */

#define b0_input_vector0 b0_input_vector /* input vector */

static float *b0_target_output = (float *)NULL; /* desired output */

/* nn:H1 input connections */
#define b0_H16 (network_data + 50) /* weights from $INPUTS */
#define b0_H16ac (network_data + 58)      /* accumulated changes */
#define b0_H16d (network_data + 66)       /* delta weights */

/* nn:H2 input connections */
#define b0_H25 (network_data + 74) /* weights from $INPUTS */
#define b0_H25ac (network_data + 78)      /* accumulated changes */
#define b0_H25d (network_data + 82)       /* delta weights */
#define b0_H24 (network_data + 86) /* weights from nn:H1 */
#define b0_H24ac (network_data + 94)      /* accumulated changes */
#define b0_H24d (network_data + 102)       /* delta weights */

/* nn:Out input connections */
#define b0_Out3 (network_data + 110) /* weights from $INPUTS */
#define b0_Out3ac (network_data + 118)      /* accumulated changes */
#define b0_Out3d (network_data + 126)       /* delta weights */
#define b0_Out2 (network_data + 134) /* weights from nn:H1 */
#define b0_Out2ac (network_data + 150)      /* accumulated changes */
#define b0_Out2d (network_data + 166)       /* delta weights */
#define b0_Out1 (network_data + 182) /* weights from nn:H2 */
#define b0_Out1ac (network_data + 190)      /* accumulated changes */
#define b0_Out1d (network_data + 198)       /* delta weights */

/* Black Box Control Functions */


/**** nn ****/

void nn_bb_clear_delays()
{
}/* end nn_bb_clear_delays */

/* nn Forward Propagation */
void nn_propagate_forward()
{

 /* ---------------- nn:H1 ---------------- */
 /* Connection to nn:H1 from $INPUTS */
 BPlvdot(b0_H16, b0_input_vector + 0, 2, b0_l2_v, 2, 4);
 /* calculate the transfer function for nn:H1 */
 BPsig1(b0_l2_v, b0_l2_t, 4);

 /* ---------------- nn:H2 ---------------- */
 /* Connection to nn:H2 from $INPUTS */
 BPlvdot(b0_H25, b0_input_vector + 0, 2, b0_l1_v, 2, 2);
 /* Connection to nn:H2 from nn:H1 */
 BPlvdot_sum(b0_H24, b0_l2_v + 0, 4, b0_l1_v, 4, 2);
 /* calculate the transfer function for nn:H2 */
 BPsig1(b0_l1_v, b0_l1_t, 2);

 /* ---------------- nn:Out ---------------- */
 /* Connection to nn:Out from $INPUTS */
 BPlvdot(b0_Out3, b0_input_vector + 0, 2, b0_l0_v, 2, 4);
 /* Connection to nn:Out from nn:H1 */
 BPlvdot_sum(b0_Out2, b0_l2_v + 0, 4, b0_l0_v, 4, 4);
 /* Connection to nn:Out from nn:H2 */
 BPlvdot_sum(b0_Out1, b0_l1_v + 0, 2, b0_l0_v, 2, 4);
 /* calculate the transfer function for nn:Out */
 BPsig1(b0_l0_v, b0_l0_t, 4);

 b0fcounter++; /* increment fwd counter */
}/* end nn_ propagate_forward */

/****************** nn Error  ******************/
float nn_calc_error()
{
 float error; 
 /*** nn:Out ***/
 /* Calc diff between output and target output */
 /* Modulate by learning rate times 1/(update_interval) */
 error = BPoutput_error(b0_target_output,b0_l0_v,b0_l0_c,BPlearning_rate*0.333333,4)/4;
 return(error);
} /* end nn_calc_error */

/****************** nn Backward Propagation (Gradient Calc) ******************/
void nn_calc_grad()
{

 b0bcounter++; /* increment bwd counter */

 /* clear errors */
 bzero((char *)b0_l1_c, 2 * sizeof(float));
 bzero((char *)b0_l2_c, 4 * sizeof(float));

 /* backprop */

 /* calc deriv of function and multiply by credit */
 BPderiv_sig1(b0_l0_v,b0_l0_c,4,BPfrandom(0.050000));

 /* Accumulate Biases */
 BPaccum_biases(b0_l0_ac,b0_l0_c,4);

 /* Do all connections into nn:Out */

 /* Connection to nn:Out from $INPUTS */

 /* Accumulate weight changes */
 BPaccum_weights_from_input(b0_l0_c, b0_input_vector+0,b0_Out3ac,  4,2,2);
 /* Connection to nn:Out from nn:H1 */

 /* Accumulate weight changes */
 BPaccum_weights_from_hidden(b0_l0_c, b0_l2_v+0,b0_l2_c+0,b0_Out2,b0_Out2ac,  4,4,4);
 /* Connection to nn:Out from nn:H2 */

 /* Accumulate weight changes */
 BPaccum_weights_from_hidden(b0_l0_c, b0_l1_v+0,b0_l1_c+0,b0_Out1,b0_Out1ac,  4,2,2);

 /* calc deriv of function and multiply by credit */
 BPderiv_sig1(b0_l1_v,b0_l1_c,2,BPfrandom(0.050000));

 /* Accumulate Biases */
 BPaccum_biases(b0_l1_ac,b0_l1_c,2);

 /* Do all connections into nn:H2 */

 /* Connection to nn:H2 from $INPUTS */

 /* Accumulate weight changes */
 BPaccum_weights_from_input(b0_l1_c, b0_input_vector+0,b0_H25ac,  2,2,2);
 /* Connection to nn:H2 from nn:H1 */

 /* Accumulate weight changes */
 BPaccum_weights_from_hidden(b0_l1_c, b0_l2_v+0,b0_l2_c+0,b0_H24,b0_H24ac,  2,4,4);

 /* calc deriv of function and multiply by credit */
 BPderiv_sig1(b0_l2_v,b0_l2_c,4,BPfrandom(0.050000));

 /* Accumulate Biases */
 BPaccum_biases(b0_l2_ac,b0_l2_c,4);

 /* Do all connections into nn:H1 */

 /* Connection to nn:H1 from $INPUTS */

 /* Accumulate weight changes */
 BPaccum_weights_from_input(b0_l2_c, b0_input_vector+0,b0_H16ac,  4,2,2);
} /* end nn_calc_grad */

/****************** nn Update Weights ******************/
void nn_update_weights(float scalar)
{

 /* update the weights */
 if ( ! (b0bcounter % 3) ) {

 /* Upate Biases */
 BPupdate_weights(scalar,b0_l0_ac,b0_l0_t,b0_l0_dt,4);
 bzero((char *)b0_l0_ac, 4 * sizeof(float));
 /* Upate Connection from $INPUTS to nn:Out*/
 BPupdate_weights(scalar,b0_Out3ac,b0_Out3,b0_Out3d,8);
 /* Clear Connection from $INPUTS to nn:Out*/
 bzero((char *)b0_Out3ac, 8 * sizeof(float));
 /* Upate Connection from nn:H1 to nn:Out*/
 BPupdate_weights(scalar,b0_Out2ac,b0_Out2,b0_Out2d,16);
 /* Clear Connection from nn:H1 to nn:Out*/
 bzero((char *)b0_Out2ac, 16 * sizeof(float));
 /* Upate Connection from nn:H2 to nn:Out*/
 BPupdate_weights(scalar,b0_Out1ac,b0_Out1,b0_Out1d,8);
 /* Clear Connection from nn:H2 to nn:Out*/
 bzero((char *)b0_Out1ac, 8 * sizeof(float));

 /* Upate Biases */
 BPupdate_weights(scalar,b0_l1_ac,b0_l1_t,b0_l1_dt,2);
 bzero((char *)b0_l1_ac, 2 * sizeof(float));
 /* Upate Connection from $INPUTS to nn:H2*/
 BPupdate_weights(scalar,b0_H25ac,b0_H25,b0_H25d,4);
 /* Clear Connection from $INPUTS to nn:H2*/
 bzero((char *)b0_H25ac, 4 * sizeof(float));
 /* Upate Connection from nn:H1 to nn:H2*/
 BPupdate_weights(scalar,b0_H24ac,b0_H24,b0_H24d,8);
 /* Clear Connection from nn:H1 to nn:H2*/
 bzero((char *)b0_H24ac, 8 * sizeof(float));

 /* Upate Biases */
 BPupdate_weights(scalar,b0_l2_ac,b0_l2_t,b0_l2_dt,4);
 bzero((char *)b0_l2_ac, 4 * sizeof(float));
 /* Upate Connection from $INPUTS to nn:H1*/
 BPupdate_weights(scalar,b0_H16ac,b0_H16,b0_H16d,8);
 /* Clear Connection from $INPUTS to nn:H1*/
 bzero((char *)b0_H16ac, 8 * sizeof(float));
 }
} /* end nn_update_weights */

/* COUNTER CONTROL */
void nn_set_backprop_counter(int x)
{
	b0bcounter = x;
}/* end nn_set_backprop_counter */
int nn_get_backprop_counter()
{
	return(b0bcounter);
}/* end nn_get_backprop_counter */

/* INPUT CONTROL */
void nn_set_input(float *vector)
{
	b0_input_vector = vector;
}/* end nn_set_input */

float *nn_get_input()
{
	return(b0_input_vector);
}/* end nn_get_input */

/* TARGET OUTPUT CONTROL */

float *nn_get_output()
{
	return(b0_l0_v);
}/* end nn_get_output */

void nn_set_target_output(float *vector)
{
	b0_target_output = vector;
}/* end nn_set_target_output */

float *nn_get_target_output()
{
	return(b0_target_output);
}/* end nn_get_target_output */

/* NETWORK FUNCTIONS */

/* nn_error_string: Return string describing error */
char *nn_error_string()
{ 
   return(error_string);
}/* end nn_error_string */

/* nn_set_learning_rate: Set learning rate */
void nn_set_learning_rate(float x)
{ 
   BPlearning_rate = x;
}/* end nn_set_learning_rate */

/* nn_set_inertia: Set inertia*/
void nn_set_inertia(float x)
{ 
   BPinertia = x;
}/* end nn_set_inertia */

/* nn_get_learning_rate: Return the  learning rate */
float nn_get_learning_rate()

{ 
   return(BPlearning_rate);
}/* end nn_get_learning_rate */

/* nn_get_inertia: Return the  inertia*/
float nn_get_inertia()

{ 
   return(BPinertia);
}/* end nn_get_inertia */

static write_header(int fd)
{
 int number;
 int n_extra_bytes = 256;
 char extra_bytes[256];

 /* write header */
 number = 100; /* compiler identifier */
 write(fd, &number, sizeof(int));
 number = 6; /* major version */
 write(fd, &number, sizeof(int));
 number = 0; /* minor version */
 write(fd, &number, sizeof(int));
 /* extra bytes for future use */
 write(fd, extra_bytes, n_extra_bytes);
}/* end write_header */


int nn_dump_network(char *filename)
{
 int number;
 int n_extra_bytes = 256;
 int extra_bytes[256];
 int fd;

 /* open the file */
 fd = creat(filename, 0644);
 if (fd == -1) {
  sprintf(error_string, "\nUnable to open %s.\n", filename);
  return(FERROR);
 }/* end if */
 /* write header */
 write_header(fd);
 number = 1; /* number of black boxes */
 write(fd, &number, sizeof(int));
 number = 357; /* data size of black box */
 write(fd, &number, sizeof(int));
 /* dump nn */
 write(fd, "nn", 3); /* name */
 number = b0bcounter; /* number of iterations */
 write(fd, &number, sizeof(int));
 number = 3; /* number of layers */
 write(fd, &number, sizeof(int));
 write(fd, "H1", 3); /* layer name */
 number = 4; /* size of threshold array */
 write(fd, &number, sizeof(int));
 write(fd, b0_l2_t, 4 * sizeof(float)); /* thresholds */
 write(fd, "H2", 3); /* layer name */
 number = 2; /* size of threshold array */
 write(fd, &number, sizeof(int));
 write(fd, b0_l1_t, 2 * sizeof(float)); /* thresholds */
 write(fd, "Out", 4); /* layer name */
 number = 4; /* size of threshold array */
 write(fd, &number, sizeof(int));
 write(fd, b0_l0_t, 4 * sizeof(float)); /* thresholds */
 number = 6; /* number of connection arrays */
 write(fd, &number, sizeof(int));
 write(fd, "H1", 3); /* to layer name */
 write(fd, "H16", 4); /* matrix name */
 number = 8; /* size of weight array */
 write(fd, &number, sizeof(int));
 write(fd, b0_H16, 8 * sizeof(float)); /* connection */
 write(fd, "H2", 3); /* to layer name */
 write(fd, "H25", 4); /* matrix name */
 number = 4; /* size of weight array */
 write(fd, &number, sizeof(int));
 write(fd, b0_H25, 4 * sizeof(float)); /* connection */
 write(fd, "H2", 3); /* to layer name */
 write(fd, "H24", 4); /* matrix name */
 number = 8; /* size of weight array */
 write(fd, &number, sizeof(int));
 write(fd, b0_H24, 8 * sizeof(float)); /* connection */
 write(fd, "Out", 4); /* to layer name */
 write(fd, "Out3", 5); /* matrix name */
 number = 8; /* size of weight array */
 write(fd, &number, sizeof(int));
 write(fd, b0_Out3, 8 * sizeof(float)); /* connection */
 write(fd, "Out", 4); /* to layer name */
 write(fd, "Out2", 5); /* matrix name */
 number = 16; /* size of weight array */
 write(fd, &number, sizeof(int));
 write(fd, b0_Out2, 16 * sizeof(float)); /* connection */
 write(fd, "Out", 4); /* to layer name */
 write(fd, "Out1", 5); /* matrix name */
 number = 8; /* size of weight array */
 write(fd, &number, sizeof(int));
 write(fd, b0_Out1, 8 * sizeof(float)); /* connection */
 close(fd);
 return(0);
}/* end nn_dump_network */

static TOC_PTR read_header(int fd)
{
 int header_size = 272;
 int number;
 char extra_bytes[256];
 int counter;
 int n_bbs; /* number of black boxes */
 TOC_PTR table_of_contents;
 off_t *address_table; /* used to index bb in a file */

 /* read header */
 read(fd, &number, sizeof(int)); /* compiler type */
 if (number != 100) {
  sprintf(error_string, "\nWarning: This dump file is from another compiler.\n");
 }/* end if */
 read(fd, &number, sizeof(int)); /* major version */
 if (number != 6) {
  sprintf(error_string, "\nWarning: Dump file created with another version (v.%d) of compiler.\n", number);
 }/* end if */
 read(fd, &number, sizeof(int)); /* minor version */
 if (number != 0) {
  sprintf(error_string, "\nWarning: Dump file created with another version of compiler.\n");
 }/* end if */
 /* extra bytes for future use */
 read(fd, extra_bytes, 256);
 read(fd, &n_bbs, sizeof(int));
 /* create a table of black boxes => location in file */
 address_table = (off_t *)am_alloc_mem(n_bbs * sizeof(int));
 header_size += n_bbs * sizeof(int); /* add the address_table size */
 for (counter = 0; counter<n_bbs; counter++) {
  address_table[counter] =  header_size;
  read(fd, &number, sizeof(int));
  header_size += number;
 }/* end for */
 table_of_contents = (TOC_PTR)am_alloc_mem(sizeof(TOC_STRUCT));
 table_of_contents->size = n_bbs;
 table_of_contents->address_table = address_table;
 return(table_of_contents);

}/* end read_header */

static load_black_box(int fd, char *name, char *key, TOC_PTR toc)
{
 int table_size = toc->size;
 off_t *address_table = toc->address_table;
 off_t *end_of_table;
 int n_layers, n_connections, size, counter, error_code, not_found;
 char name_string[100], name_string2[100]; /* for reading names */

 /* record end of address table */
 end_of_table = address_table + table_size;
  /* find key name in the file */
  do {
   if (address_table == end_of_table) {
    sprintf(error_string, "\nUnable to find %s as %s.\n", name, key);
    return(DFERROR);
   }/* end if */
   lseek(fd, *address_table++, 0);
   BPread_string(fd, name_string);
  }while (strcmp(key, name_string) != 0);

 if (strcmp("nn", name) == 0) {
  read(fd, &b0bcounter, sizeof(int)); /* iteration counter */
  read(fd, &n_layers, sizeof(int)); /* n layers of thresholds */
  if (n_layers != 3) {
   sprintf(error_string, "\nError in reading nn\n");
   return(DFERROR);
  }/* end  if */
  /* load all thresholds and feedback weights */
  for(counter = 0; counter<n_layers; counter++) {
   /* read the layer name and data size */
   BPread_string(fd, name_string);
   read(fd, &size, sizeof(int));
   not_found = 1; /* reset flag (0 if read the thresholds) */
   if (error_code = BPread_thresholds(fd,name_string,"H1",size,4,b0_l2_t,&not_found))
      return(error_code);
   if (error_code = BPread_thresholds(fd,name_string,"H2",size,2,b0_l1_t,&not_found))
      return(error_code);
   if (error_code = BPread_thresholds(fd,name_string,"Out",size,4,b0_l0_t,&not_found))
      return(error_code);
   if(not_found) {
     sprintf(error_string, "\nUnknown layer name in file: %s\n", name_string);
     return(DFERROR);
   }/* end if not found */
  }/* end for */
  read(fd, &n_connections, sizeof(int));
  for(counter = 0; counter<n_connections; counter++) {
   /* to layer */
   BPread_string(fd, name_string);
   /* from layer */
   BPread_string(fd, name_string2);
   read(fd, &size, sizeof(int));
   not_found = 1; /* reset flag (0 if read the weights) */
   if (error_code = BPread_weights(fd,name_string,"H1",name_string2,"H16",size,8,b0_H16,&not_found))
      return(error_code);
   if (error_code = BPread_weights(fd,name_string,"H2",name_string2,"H25",size,4,b0_H25,&not_found))
      return(error_code);
   if (error_code = BPread_weights(fd,name_string,"H2",name_string2,"H24",size,8,b0_H24,&not_found))
      return(error_code);
   if (error_code = BPread_weights(fd,name_string,"Out",name_string2,"Out3",size,8,b0_Out3,&not_found))
      return(error_code);
   if (error_code = BPread_weights(fd,name_string,"Out",name_string2,"Out2",size,16,b0_Out2,&not_found))
      return(error_code);
   if (error_code = BPread_weights(fd,name_string,"Out",name_string2,"Out1",size,8,b0_Out1,&not_found))
      return(error_code);
   if(not_found) {
     sprintf(error_string, "\nUnknown connection array in file\n");
     return(DFERROR);
   }/* end if */
  }/* end for */
 return(0);
 }/* end if */
}/* end load_black_box */

static int load_black_box_data(char *name, char *key, char* filename)
{
 int fd;
 TOC_PTR toc;

 /* open the file */
 fd = open(filename, 0);
 if (fd == -1) {
  sprintf(error_string, "\nUnable to open %s.\n", filename);
  return(FERROR);
 }/* end if */
 /* read header */
 toc = read_header(fd);
 if (toc == (TOC_PTR)NULL) return(DFERROR);
 return(load_black_box(fd, name, key, toc));

}/* end load_black_box_data */

int nn_load_network(char *filename)
{
 int fd, error_code;
 TOC_PTR toc; /* table of contents */


 /* open the file */
 fd = open(filename, 0);
 if (fd == -1) {
  sprintf(error_string, "\nUnable to open %s.\n", filename);
  return(FERROR);
 }/* end if */
 /* read header */
 toc = read_header(fd);
 if (toc == (TOC_PTR)NULL) return(DFERROR);
 if (error_code = load_black_box(fd, "nn", "nn", toc))
	return(error_code);
 close(fd);
 return(0);
}/* end nn_load_network */

/* network_forward: Propagate all bb's forward.*/
void nn_network_forward()
{
 /* all black boxes forward! */
  nn_propagate_forward();
}/* end nn_network_forward */

/* nn_network_learn: Propagate all bb's forward then backward */
void nn_network_learn(int iterations, void (*generator)(void) )
{
 float error=0.0;

 while(iterations--) {
  /* execute the generator */
  generator();
  /* all black boxes forward! */
  nn_network_forward();

 /* Calc error on each output black box */
   error += nn_calc_error();

 /* Only calc on significant errors (heuristic to speed learning) */
  if ( error > BPthreshold )  {

 /* Calc grad ient and update on each black box */
    nn_calc_grad();
    nn_update_weights(BPinertia);
  }/* end if error */
  error = 0.0;
 }/* end while iterations */
}/* end nn_network_learn */

void nn_clear_delays()
{
	nn_bb_clear_delays();
}/* end nn_clear_delays */

void nn_set_random_init_seed(long x) { init_seed = x; } 


void nn_set_random_init_range(float x) { init_range = x; } 


int nn_init_network()
{
 int error_code = 0;
 int counter1, counter2, counter3, counter4;
 float *weights;

 BPfrandom_init(init_seed); /* init random number generator */

 /* clear all data */
 bzero((char *)network_data, 206 * sizeof(float));
 /* init table lookup for sigmoid [-1,1] */
 BPinit_sigmoid_table();

 error_string[0] = '\0'; /* empty string */

 /* init comms_buffer with network information */
 comms_buffer.network_info.aspirin_file = "nn.aspirin";
 comms_buffer.network_info.file = "nn";
 comms_buffer.network_info.temporal = 0;
 comms_buffer.network_info.n_black_boxes = 1;
 comms_buffer.network_info.n_nodes = 10;
 comms_buffer.network_info.n_connections = 62;
 comms_buffer.network_info.set_learning_rate = nn_set_learning_rate;
 comms_buffer.network_info.set_inertia = nn_set_inertia;
 comms_buffer.network_info.get_learning_rate = nn_get_learning_rate;
 comms_buffer.network_info.get_inertia = nn_get_inertia;
 comms_buffer.network_info.set_random_init_seed = nn_set_random_init_seed;
 comms_buffer.network_info.set_random_init_range = nn_set_random_init_range;
 comms_buffer.network_info.init_network = nn_init_network;
 comms_buffer.network_info.network_forward = nn_network_forward;
 comms_buffer.network_info.network_learn = nn_network_learn;
 comms_buffer.network_info.dump_network = nn_dump_network;
 comms_buffer.network_info.load_network = nn_load_network;
 comms_buffer.network_info.error_string = nn_error_string;
 /* hook up connection buffer */
 comms_buffer.connections = connection_buffer;

 /* initializing nn */
 /* init for nn:Out */
  /* init thresholds (biases) */
 for(counter1 = 0; counter1<4; counter1++) {
  b0_l0_t[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for counter1 */
 /* init weights for nn:Out */
 /* initialize w/small random weights */
 for(counter1 = 0; counter1<8; counter1++) {
  b0_Out3[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for */
 /* initialize w/small random weights */
 for(counter1 = 0; counter1<16; counter1++) {
  b0_Out2[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for */
 /* initialize w/small random weights */
 for(counter1 = 0; counter1<8; counter1++) {
  b0_Out1[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for */
 /* init for nn:H2 */
  /* init thresholds (biases) */
 for(counter1 = 0; counter1<2; counter1++) {
  b0_l1_t[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for counter1 */
 /* init weights for nn:H2 */
 /* initialize w/small random weights */
 for(counter1 = 0; counter1<4; counter1++) {
  b0_H25[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for */
 /* initialize w/small random weights */
 for(counter1 = 0; counter1<8; counter1++) {
  b0_H24[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for */
 /* init for nn:H1 */
  /* init thresholds (biases) */
 for(counter1 = 0; counter1<4; counter1++) {
  b0_l2_t[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for counter1 */
 /* init weights for nn:H1 */
 /* initialize w/small random weights */
 for(counter1 = 0; counter1<8; counter1++) {
  b0_H16[counter1] = BPfrandom(2.0 * init_range) - init_range;
 }/* end for */
 return(error_code);
}/* end nn_init_network */

/* nn_query_network   This function returns a pointer to a    */
/*                 layer buffer specified by the integer    */
/*                 pair of arguments. The first integer     */
/*                 is the black box index and the second    */
/*                 is the layer index. If no layer has      */
/*                 these indices then (LB_PTR)NULL is       */
/*                 returned. There is only ONE LAYER BUFFER,*/
/*                 so COPY!! the data you need for display. */
/*                 To change the network state alter the    */
/*                 data in the layer buffer.                */
LB_PTR nn_query_network(int bb_index, int layer_index)
{
 /* look up the black box first, then the layer in the black
    box, if either index does not exist return (LB_PTR)NULL.
 */
 /* Black Box nn */
 if(bb_index ==  0)
  {
    comms_buffer.black_box_info.bb_index = 0;
    comms_buffer.black_box_info.bb_name = "nn";
    comms_buffer.black_box_info.dynamic = 1;
    comms_buffer.black_box_info.efferent = 1;
    comms_buffer.black_box_info.n_layers = 3;
    comms_buffer.black_box_info.n_inputs = 2;
    comms_buffer.black_box_info.n_bb_inputs = 0;
    comms_buffer.black_box_info.n_bb_outputs = 0;
    comms_buffer.black_box_info.inputs_xdim = 2;
    comms_buffer.black_box_info.inputs_ydim = 1;
    comms_buffer.black_box_info.inputs_delay = 0;
    comms_buffer.black_box_info.output_layer_index = 0;
    comms_buffer.black_box_info.forward_prop = nn_propagate_forward;
    comms_buffer.black_box_info.set_backprop_counter = nn_set_backprop_counter;
    comms_buffer.black_box_info.get_backprop_counter = nn_get_backprop_counter;
    comms_buffer.black_box_info.calc_grad = nn_calc_grad;
    comms_buffer.black_box_info.update_weights = nn_update_weights;
    comms_buffer.black_box_info.set_target_output = nn_set_target_output;
    comms_buffer.black_box_info.get_target_output = nn_get_target_output;
    comms_buffer.black_box_info.get_output = nn_get_output;
    comms_buffer.black_box_info.set_input = nn_set_input;
    comms_buffer.black_box_info.get_input = nn_get_input;
   /* Layer nn:Out */
   if (layer_index == 0)
   {
     comms_buffer.layer_index = 0;
     comms_buffer.layer_type = 0;
     comms_buffer.layer_name = "nn:Out";
     comms_buffer.n_nodes = 4;
     comms_buffer.delay = 0;
     comms_buffer.xdim = 4;
     comms_buffer.ydim = 1;
     comms_buffer.values = b0_l0_v;
     comms_buffer.thresholds = b0_l0_t;
     comms_buffer.delta_thresholds = b0_l0_dt;
     comms_buffer.credit = b0_l0_c;
     comms_buffer.order = 0;
     (comms_buffer.connections)[0].type = 0;
     (comms_buffer.connections)[0].order = 1;
     (comms_buffer.connections)[0].shared = 0;
     (comms_buffer.connections)[0].size = 8;
     (comms_buffer.connections)[0].delay = 0;
     (comms_buffer.connections)[0].from_layer_name = "$INPUTS";
     (comms_buffer.connections)[0].tess_xdim = 2;
     (comms_buffer.connections)[0].tess_ydim = 1;
     (comms_buffer.connections)[0].tess_xoverlap = 2;
     (comms_buffer.connections)[0].tess_yoverlap = 0;
     (comms_buffer.connections)[0].tess_xoffset = 0;
     (comms_buffer.connections)[0].tess_yoffset = 0;
     (comms_buffer.connections)[0].from_bb_index = 0;
     (comms_buffer.connections)[0].from_layer_index = -1; /* $INPUTS */
     (comms_buffer.connections)[0].from_size = 2;
     (comms_buffer.connections)[0].from_xdim = 2;
     (comms_buffer.connections)[0].from_ydim = 1;
     (comms_buffer.connections)[0].weights = b0_Out3;
     (comms_buffer.connections)[0].delta_weights = b0_Out3d;
     (comms_buffer.connections)[1].type = 0;
     (comms_buffer.connections)[1].order = 1;
     (comms_buffer.connections)[1].shared = 0;
     (comms_buffer.connections)[1].size = 16;
     (comms_buffer.connections)[1].delay = 0;
     (comms_buffer.connections)[1].from_layer_name = "nn:H1";
     (comms_buffer.connections)[1].tess_xdim = 4;
     (comms_buffer.connections)[1].tess_ydim = 1;
     (comms_buffer.connections)[1].tess_xoverlap = 4;
     (comms_buffer.connections)[1].tess_yoverlap = 0;
     (comms_buffer.connections)[1].tess_xoffset = 0;
     (comms_buffer.connections)[1].tess_yoffset = 0;
     (comms_buffer.connections)[1].from_bb_index = 0;
     (comms_buffer.connections)[1].from_layer_index = 2;
     (comms_buffer.connections)[1].from_size = 4;
     (comms_buffer.connections)[1].from_xdim = 4;
     (comms_buffer.connections)[1].from_ydim = 1;
     (comms_buffer.connections)[1].weights = b0_Out2;
     (comms_buffer.connections)[1].delta_weights = b0_Out2d;
     (comms_buffer.connections)[2].type = 0;
     (comms_buffer.connections)[2].order = 1;
     (comms_buffer.connections)[2].shared = 0;
     (comms_buffer.connections)[2].size = 8;
     (comms_buffer.connections)[2].delay = 0;
     (comms_buffer.connections)[2].from_layer_name = "nn:H2";
     (comms_buffer.connections)[2].tess_xdim = 2;
     (comms_buffer.connections)[2].tess_ydim = 1;
     (comms_buffer.connections)[2].tess_xoverlap = 2;
     (comms_buffer.connections)[2].tess_yoverlap = 0;
     (comms_buffer.connections)[2].tess_xoffset = 0;
     (comms_buffer.connections)[2].tess_yoffset = 0;
     (comms_buffer.connections)[2].from_bb_index = 0;
     (comms_buffer.connections)[2].from_layer_index = 1;
     (comms_buffer.connections)[2].from_size = 2;
     (comms_buffer.connections)[2].from_xdim = 2;
     (comms_buffer.connections)[2].from_ydim = 1;
     (comms_buffer.connections)[2].weights = b0_Out1;
     (comms_buffer.connections)[2].delta_weights = b0_Out1d;
     comms_buffer.n_inputs = 3;
     comms_buffer.n_outputs = 0;
     return(&comms_buffer);/* success!! */
    }/* end if for Layer nn:Out (number 0) */
   /* Layer nn:H2 */
   if (layer_index == 1)
   {
     comms_buffer.layer_index = 1;
     comms_buffer.layer_type = 0;
     comms_buffer.layer_name = "nn:H2";
     comms_buffer.n_nodes = 2;
     comms_buffer.delay = 0;
     comms_buffer.xdim = 2;
     comms_buffer.ydim = 1;
     comms_buffer.values = b0_l1_v;
     comms_buffer.thresholds = b0_l1_t;
     comms_buffer.delta_thresholds = b0_l1_dt;
     comms_buffer.credit = b0_l1_c;
     comms_buffer.order = 0;
     (comms_buffer.connections)[0].type = 0;
     (comms_buffer.connections)[0].order = 1;
     (comms_buffer.connections)[0].shared = 0;
     (comms_buffer.connections)[0].size = 4;
     (comms_buffer.connections)[0].delay = 0;
     (comms_buffer.connections)[0].from_layer_name = "$INPUTS";
     (comms_buffer.connections)[0].tess_xdim = 2;
     (comms_buffer.connections)[0].tess_ydim = 1;
     (comms_buffer.connections)[0].tess_xoverlap = 2;
     (comms_buffer.connections)[0].tess_yoverlap = 0;
     (comms_buffer.connections)[0].tess_xoffset = 0;
     (comms_buffer.connections)[0].tess_yoffset = 0;
     (comms_buffer.connections)[0].from_bb_index = 0;
     (comms_buffer.connections)[0].from_layer_index = -1; /* $INPUTS */
     (comms_buffer.connections)[0].from_size = 2;
     (comms_buffer.connections)[0].from_xdim = 2;
     (comms_buffer.connections)[0].from_ydim = 1;
     (comms_buffer.connections)[0].weights = b0_H25;
     (comms_buffer.connections)[0].delta_weights = b0_H25d;
     (comms_buffer.connections)[1].type = 0;
     (comms_buffer.connections)[1].order = 1;
     (comms_buffer.connections)[1].shared = 0;
     (comms_buffer.connections)[1].size = 8;
     (comms_buffer.connections)[1].delay = 0;
     (comms_buffer.connections)[1].from_layer_name = "nn:H1";
     (comms_buffer.connections)[1].tess_xdim = 4;
     (comms_buffer.connections)[1].tess_ydim = 1;
     (comms_buffer.connections)[1].tess_xoverlap = 4;
     (comms_buffer.connections)[1].tess_yoverlap = 0;
     (comms_buffer.connections)[1].tess_xoffset = 0;
     (comms_buffer.connections)[1].tess_yoffset = 0;
     (comms_buffer.connections)[1].from_bb_index = 0;
     (comms_buffer.connections)[1].from_layer_index = 2;
     (comms_buffer.connections)[1].from_size = 4;
     (comms_buffer.connections)[1].from_xdim = 4;
     (comms_buffer.connections)[1].from_ydim = 1;
     (comms_buffer.connections)[1].weights = b0_H24;
     (comms_buffer.connections)[1].delta_weights = b0_H24d;
     comms_buffer.n_inputs = 2;
     comms_buffer.n_outputs = 1;
     return(&comms_buffer);/* success!! */
    }/* end if for Layer nn:H2 (number 1) */
   /* Layer nn:H1 */
   if (layer_index == 2)
   {
     comms_buffer.layer_index = 2;
     comms_buffer.layer_type = 0;
     comms_buffer.layer_name = "nn:H1";
     comms_buffer.n_nodes = 4;
     comms_buffer.delay = 0;
     comms_buffer.xdim = 4;
     comms_buffer.ydim = 1;
     comms_buffer.values = b0_l2_v;
     comms_buffer.thresholds = b0_l2_t;
     comms_buffer.delta_thresholds = b0_l2_dt;
     comms_buffer.credit = b0_l2_c;
     comms_buffer.order = 0;
     (comms_buffer.connections)[0].type = 0;
     (comms_buffer.connections)[0].order = 1;
     (comms_buffer.connections)[0].shared = 0;
     (comms_buffer.connections)[0].size = 8;
     (comms_buffer.connections)[0].delay = 0;
     (comms_buffer.connections)[0].from_layer_name = "$INPUTS";
     (comms_buffer.connections)[0].tess_xdim = 2;
     (comms_buffer.connections)[0].tess_ydim = 1;
     (comms_buffer.connections)[0].tess_xoverlap = 2;
     (comms_buffer.connections)[0].tess_yoverlap = 0;
     (comms_buffer.connections)[0].tess_xoffset = 0;
     (comms_buffer.connections)[0].tess_yoffset = 0;
     (comms_buffer.connections)[0].from_bb_index = 0;
     (comms_buffer.connections)[0].from_layer_index = -1; /* $INPUTS */
     (comms_buffer.connections)[0].from_size = 2;
     (comms_buffer.connections)[0].from_xdim = 2;
     (comms_buffer.connections)[0].from_ydim = 1;
     (comms_buffer.connections)[0].weights = b0_H16;
     (comms_buffer.connections)[0].delta_weights = b0_H16d;
     comms_buffer.n_inputs = 1;
     comms_buffer.n_outputs = 2;
     return(&comms_buffer);/* success!! */
    }/* end if for Layer nn:H1 (number 2) */
  return((LB_PTR)NULL);
  }/* end if for black box nn (number: 0) */
 return((LB_PTR)NULL);
}/* end nn_query_network */


void nn_ascii_dump_network(int formatted)
{
 int counter1, counter2, counter3, counter4;
 float *weights;

  if (! formatted) printf("\n\n#");

 if (formatted) printf("\n\nBlackBox: nn");

 if (formatted) printf("\nIterations: %d", b0bcounter);

 else printf("\n%d", b0bcounter);

 if (formatted) printf("\nLayer: nn:Out");
 /* print for nn:Out */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {

    if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);

    if (formatted)
      printf("\n   Bias=%.12f", b0_l0_t[counter3+(4*counter4)]);
      else
      printf("\n%.12f", b0_l0_t[counter3+(4*counter4)]);
  }/* end for counter3 */
 }/* end for counter4 */

 if (formatted) printf("\nConnection from $INPUTS:");
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {

 if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);
   weights = b0_Out3 + (counter3 * 2) + (counter4 * 8);
   for(counter1 = 0; counter1<1; counter1++) {
    if (formatted) printf("\n");
    for(counter2 = 0; counter2<2; counter2++) {
       if (formatted)
         printf("%.12f ", *weights++);
       else
         printf("\n%.12f ", *weights++);
    }/* end for */
    weights += 6;
   }/* end for */
  }/* end for */
 }/* end for */

 if (formatted) printf("\nConnection from nn:H1:");
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {

 if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);
   weights = b0_Out2 + (counter3 * 4) + (counter4 * 16);
   for(counter1 = 0; counter1<1; counter1++) {
    if (formatted) printf("\n");
    for(counter2 = 0; counter2<4; counter2++) {
       if (formatted)
         printf("%.12f ", *weights++);
       else
         printf("\n%.12f ", *weights++);
    }/* end for */
    weights += 12;
   }/* end for */
  }/* end for */
 }/* end for */

 if (formatted) printf("\nConnection from nn:H2:");
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {

 if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);
   weights = b0_Out1 + (counter3 * 2) + (counter4 * 8);
   for(counter1 = 0; counter1<1; counter1++) {
    if (formatted) printf("\n");
    for(counter2 = 0; counter2<2; counter2++) {
       if (formatted)
         printf("%.12f ", *weights++);
       else
         printf("\n%.12f ", *weights++);
    }/* end for */
    weights += 6;
   }/* end for */
  }/* end for */
 }/* end for */

 if (formatted) printf("\nLayer: nn:H2");
 /* print for nn:H2 */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<2; counter3++) {

    if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);

    if (formatted)
      printf("\n   Bias=%.12f", b0_l1_t[counter3+(2*counter4)]);
      else
      printf("\n%.12f", b0_l1_t[counter3+(2*counter4)]);
  }/* end for counter3 */
 }/* end for counter4 */

 if (formatted) printf("\nConnection from $INPUTS:");
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<2; counter3++) {

 if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);
   weights = b0_H25 + (counter3 * 2) + (counter4 * 4);
   for(counter1 = 0; counter1<1; counter1++) {
    if (formatted) printf("\n");
    for(counter2 = 0; counter2<2; counter2++) {
       if (formatted)
         printf("%.12f ", *weights++);
       else
         printf("\n%.12f ", *weights++);
    }/* end for */
    weights += 2;
   }/* end for */
  }/* end for */
 }/* end for */

 if (formatted) printf("\nConnection from nn:H1:");
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<2; counter3++) {

 if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);
   weights = b0_H24 + (counter3 * 4) + (counter4 * 8);
   for(counter1 = 0; counter1<1; counter1++) {
    if (formatted) printf("\n");
    for(counter2 = 0; counter2<4; counter2++) {
       if (formatted)
         printf("%.12f ", *weights++);
       else
         printf("\n%.12f ", *weights++);
    }/* end for */
    weights += 4;
   }/* end for */
  }/* end for */
 }/* end for */

 if (formatted) printf("\nLayer: nn:H1");
 /* print for nn:H1 */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {

    if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);

    if (formatted)
      printf("\n   Bias=%.12f", b0_l2_t[counter3+(4*counter4)]);
      else
      printf("\n%.12f", b0_l2_t[counter3+(4*counter4)]);
  }/* end for counter3 */
 }/* end for counter4 */

 if (formatted) printf("\nConnection from $INPUTS:");
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {

 if (formatted) printf("\nNode[%d,%d]:",counter3,counter4);
   weights = b0_H16 + (counter3 * 2) + (counter4 * 8);
   for(counter1 = 0; counter1<1; counter1++) {
    if (formatted) printf("\n");
    for(counter2 = 0; counter2<2; counter2++) {
       if (formatted)
         printf("%.12f ", *weights++);
       else
         printf("\n%.12f ", *weights++);
    }/* end for */
    weights += 6;
   }/* end for */
  }/* end for */
 }/* end for */
  if (! formatted) printf("\n\n#");
  printf("\n");
}/* end nn_ascii_dump_network */

void nn_load_ascii_network()
{
 int counter1, counter2, counter3, counter4;
 float *weights;


 {
    char c;
    do {
      am_fread(&c,sizeof(char),1,stdin);
    } while( c != '#' );

 }

 scanf("\n%d", &b0bcounter);
 /* read for nn:Out */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {

    scanf("%f", &b0_l0_t[counter3+(4*counter4)]);
  }/* end for counter3 */
 }/* end for counter4 */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {
   weights = b0_Out3 + (counter3 * 2) + (counter4 * 8);
   for(counter1 = 0; counter1<1; counter1++) {
    for(counter2 = 0; counter2<2; counter2++) {
       scanf("%f", weights++);
    }/* end for */
    weights += 6;
   }/* end for */
  }/* end for */
 }/* end for */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {
   weights = b0_Out2 + (counter3 * 4) + (counter4 * 16);
   for(counter1 = 0; counter1<1; counter1++) {
    for(counter2 = 0; counter2<4; counter2++) {
       scanf("%f", weights++);
    }/* end for */
    weights += 12;
   }/* end for */
  }/* end for */
 }/* end for */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {
   weights = b0_Out1 + (counter3 * 2) + (counter4 * 8);
   for(counter1 = 0; counter1<1; counter1++) {
    for(counter2 = 0; counter2<2; counter2++) {
       scanf("%f", weights++);
    }/* end for */
    weights += 6;
   }/* end for */
  }/* end for */
 }/* end for */
 /* read for nn:H2 */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<2; counter3++) {

    scanf("%f", &b0_l1_t[counter3+(2*counter4)]);
  }/* end for counter3 */
 }/* end for counter4 */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<2; counter3++) {
   weights = b0_H25 + (counter3 * 2) + (counter4 * 4);
   for(counter1 = 0; counter1<1; counter1++) {
    for(counter2 = 0; counter2<2; counter2++) {
       scanf("%f", weights++);
    }/* end for */
    weights += 2;
   }/* end for */
  }/* end for */
 }/* end for */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<2; counter3++) {
   weights = b0_H24 + (counter3 * 4) + (counter4 * 8);
   for(counter1 = 0; counter1<1; counter1++) {
    for(counter2 = 0; counter2<4; counter2++) {
       scanf("%f", weights++);
    }/* end for */
    weights += 4;
   }/* end for */
  }/* end for */
 }/* end for */
 /* read for nn:H1 */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {

    scanf("%f", &b0_l2_t[counter3+(4*counter4)]);
  }/* end for counter3 */
 }/* end for counter4 */
 for(counter4 = 0; counter4<1; counter4++) {
  for(counter3 = 0; counter3<4; counter3++) {
   weights = b0_H16 + (counter3 * 2) + (counter4 * 8);
   for(counter1 = 0; counter1<1; counter1++) {
    for(counter2 = 0; counter2<2; counter2++) {
       scanf("%f", weights++);
    }/* end for */
    weights += 6;
   }/* end for */
  }/* end for */
 }/* end for */

 {
    int  code;
    char c;
    do {
      code = am_fread(&c,sizeof(char),1,stdin);
    } while( code );

 }
}/* end nn_load_ascii_network */

/* network_initialize: Init simulation, optionaly load dump.*/
void network_initialize(char *filename, int verbose)
{
 /* initialize the simulator */
 if (nn_init_network()) {
   fprintf(stderr, "%s", nn_error_string());
   am_exit( EXIT_FAILURE );
 }/* end if init */
 /* load dump file? */
 if (filename != (char *)NULL) {
  if (verbose) printf("\nLoading Saved Network: %s", filename);
  if (nn_load_network(filename)) {
    fprintf(stderr, "%s", nn_error_string());
    am_exit( EXIT_FAILURE );
  }/* end if load_network */
 }/* end if filename */

 if (verbose) {
  printf("\n\nBackpropagation Learning");
  printf("\n\nBlack Boxes:\n");
  printf("\nnn (Saved at Backprop Iteration %d)", nn_get_backprop_counter());
 }/* end if verbose */
}/* end network_initialize */

/* network_forward: Propagate all bb's forward.*/
void network_forward(int iterations, void (*generator)(void) )
{
  while (iterations--) {
   generator();
   nn_network_forward();
  }/* end while */
}/* end network_forward */

/* network_learn: Propagate all bb's forward then backward */
void network_learn(int iterations, void (*generator)(void) )
{
     nn_network_learn(iterations, generator);
}/* end network_learn */

void network_clear_delays()
{
  nn_clear_delays();
}/* end network_clear_delays */

void network_dump(char *filename)
{
 if (nn_dump_network(filename)) {
   fprintf(stderr, "%s", nn_error_string());
}/* end if dump*/
}/* end network_dump */

void network_load(char *filename)
{
 if (nn_load_network(filename)) {
   fprintf(stderr, "%s", nn_error_string());
}/* end if load*/
}/* end network_load */

void network_ascii_dump(int formatted)
{
 nn_ascii_dump_network(formatted);
}/* end network_ascii_dump */

void network_load_ascii()
{
 nn_load_ascii_network();
}/* end network_load_ascii */

LB_PTR network_query(int bbindex, int layerindex)
{
 return(nn_query_network(bbindex, layerindex));
}/* end network_query */

/* network_forward_print: print outputs/target for each bb */
void network_forward_print(int iterations, void (*generator)(void))
{
   int icounter,counter;
   float *ptr;

  for(icounter=0;icounter<iterations;icounter++) {
   generator();
   nn_network_forward();
   printf("\nIteration: %d", icounter);
   printf("\nblack box nn:");
   ptr = nn_get_output();
   counter = 4;
   printf("\n\tOutputs:");
   while(counter--)
     printf(" %f", *ptr++);
   ptr = nn_get_target_output();
   counter = 4;
   printf("\n\tTargets:");
   while(counter--)
     printf(" %f", *ptr++);
  }/* end while */
}/* end network_forward_print */

/* network_forward_pdpfa: calc pd, pfa, pfn */
void network_forward_pdpfa(int iterations, void (*generator)(void), float threshold)
{
   int counter;
   float *ptr1, *ptr2;
  int total = iterations;
  float nn_sum;
  int nn_detections = 0;
  double nnMin[4];
  double nnMax[4];
  float nnMean[4];
  float nnSquare[4];

  if (!iterations) return;
  threshold *= threshold;
  for(counter=0;counter<4;counter++) { /* init */
     nnMin[counter] = AM_HUGE_VAL;
     nnMax[counter] = -AM_HUGE_VAL;
     nnMean[counter] = 0.0;
     nnSquare[counter] = 0.0;
  }/* end for */
  while (iterations--) {
   generator();
   nn_network_forward();
   nn_sum = 0.0;
   ptr1 = nn_get_output();
   ptr2 = nn_get_target_output();
   for(counter=0;counter<4;counter++) { /* calc sum of squared diffs */
     float val, target, diff;

     val = *ptr1++;
     target = *ptr2++;
     nnMean[counter] += val;
     nnSquare[counter] += val * val;
     if (val < nnMin[counter]) nnMin[counter] = val;
     if (val > nnMax[counter]) nnMax[counter] = val;
     diff = val - target;
     nn_sum += diff * diff;
   }/* end for */
   /* count */
   if (nn_sum < threshold) nn_detections++;
  }/* end while */

  printf("\n\nnn:");
  printf("\nMaxima: ");
  for(counter=0;counter<4;counter++) { /* calc max */
   printf("%f ",nnMax[counter]);
  }/* end for */
  printf("\nMinima: ");
  for(counter=0;counter<4;counter++) { /* calc min */
   printf("%f ",nnMin[counter]);
  }/* end for */
  printf("\nMeans: ");
  for(counter=0;counter<4;counter++) { /* calc mean */
     nnMean[counter] /= (float)total;
     printf("%f ",nnMean[counter]);
  }/* end for */
  printf("\nVariances: ");
  for(counter=0;counter<4;counter++) { /* calc variance */
     nnSquare[counter] /= (float)total;
     printf("%f ",nnSquare[counter] - (nnMean[counter] * nnMean[counter]));
  }/* end for */
  /* print stats */
  printf("\n\nPd = %d/%d = %f",nn_detections, total, (float)nn_detections/total);
  printf("\nPfa = %d/%d = %f", total - nn_detections, total, (float)(total - nn_detections)/total);
}/* end network_forward_pdpfa */

/* end of nn.c */

