/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/

/* head */
#define ROUND_HEAD    1 0 0
#define SQUARE_HEAD   0 1 0
#define OCTAGON_HEAD  0 0 1

/* body */
#define ROUND_BODY    1 0 0
#define SQUARE_BODY   0 1 0
#define OCTAGON_BODY  0 0 1

/* smile */
#define SMILE     1 0
#define NO_SMILE  0 1

/* holding */
#define SWORD_HOLDING   1 0 0
#define BALLOON_HOLDING 0 1 0
#define FLAG_HOLDING    0 0 1

/* jacket color */
#define RED_JACKET     1 0 0 0
#define YELLOW_JACKET  0 1 0 0
#define GREEN_JACKET   0 0 1 0
#define BLUE_JACKET    0 0 0 1

/* tie */
#define TIE    1 0
#define NO_TIE 0 1


