/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
typedef union {
	int i;    /* integer                */
	float f;  /* float                  */
	char *s;  /* string                 */
	DD_PTR d; /* delay struct  ptr      */
	CD_PTR c; /* connection struct ptr  */
	LD_PTR l; /* layer struct ptr       */
} YYSTYPE;
#define	NEWLINE	258
#define	INPUT_FIELDS	259
#define	INPUT_SIZE	260
#define	COMPONENTS	261
#define	OUTPUT_LAYER	262
#define	INPUTS_FROM	263
#define	STATIC	264
#define	CLRDELAYS	265
#define	UPDATE	266
#define	INPUT_FILTER	267
#define	OUTPUT_FILTER	268
#define	ERROR_FUNCTION	269
#define	BBD	270
#define	ORDER	271
#define	PDPNODE1	272
#define	PDPNODE2	273
#define	PDPNODE3	274
#define	LINEAR_NODE	275
#define	QUAD_NODE	276
#define	USER_NODE	277
#define	CONJ	278
#define	DIMENSION	279
#define	LOAD_DATA	280
#define	INTO	281
#define	FROM	282
#define	IN	283
#define	NUMBER	284
#define	NAME	285
#define	QUOTE	286
#define	COMMA	287
#define	LCP	288
#define	RCP	289
#define	RP	290
#define	LP	291
#define	LB	292
#define	RB	293
#define	TESSELLATION	294
#define	SHARED	295
#define	WITH	296
#define	USING	297
#define	XOVERLAP	298
#define	YOVERLAP	299
#define	XOFFSET	300
#define	YOFFSET	301
#define	AT	302
#define	TIME	303
#define	INIT	304
#define	BIAS	305
#define	EQUALS	306


extern YYSTYPE yylval;
