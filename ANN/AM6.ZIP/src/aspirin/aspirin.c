/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/

/** aspirin  This is the user level code that accesses the correct
             neural network compiler.
 **/

#include <stdio.h>
#include "aspirin.h"

/*** the parser ***/
extern ND_PTR parse(char *file);

/*** the compilers ***/
extern void backprop_generator(ND_PTR network, char *aspirin_file, char *file, int flagc, char **flagv);

typedef void (*FUNC_PTR)();

main(argc, argv)
     int argc;
     char *argv[];
{
  int counter1 = 3; /* flag counter */
  FUNC_PTR function = (FUNC_PTR)NULL; /* function ptr */
  int flagc = 0; /* number of flags */
  char *(*flagv); /* pointer to flag strings */
  
  if (argc < 5)  {
    fprintf(stderr,
	    "\nUsage: aspirin <aspirin file> <C file> %s %s\n",
	    "-c <network compiler>",
	    "[<compiler flags>]");
    am_exit( EXIT_FAILURE );
  }/* end if */
  
  
  /* am_alloc_mem vector for flags */
  flagv = (char *(*))am_alloc_mem((argc - 3) * sizeof(flagv));
  /* find aspirin flags and send other flags to the compiler */
  while (counter1 < argc)   { 
    if (strcmp(argv[counter1], "-c") == 0){
      if (strcmp(argv[counter1 + 1], "backprop") == 0)  {
	/* use backprop_compiler */
	function = backprop_generator;
      }/* end if */
      /* say what? */
      else  {
	fprintf(stderr, "\naspirin currently does not support %s\n", argv[4]);
	am_exit( EXIT_FAILURE );
      }/* end else */
      /* jump passed argument */
      counter1++;
    }/* end if */
    /* load flags into flagv */
    else {
      flagv[flagc++] = argv[counter1];
    }/* end else */
    /* next */
    counter1++;
  }/* end while */
  
  
  if (function == (FUNC_PTR)NULL) {
    fprintf(stderr,
	    "You must supply a compiler name with -c.\n%s%s",
	    "Options:",
	    "\n\tbackprop");
    
    am_exit( EXIT_FAILURE );
  } else {
    /* call the compiler */
    (*function)(parse(argv[1]), /* parse aspirin file => structure */
		argv[1],        /* name of aspirin file */
		argv[2],        /* name of files to create */
		flagc,          /* number of flags passed to compiler */
		flagv);         /* vector of flag strings */
  }/* end else */
  
  am_exit( EXIT_SUCCESS );
  
}
	
