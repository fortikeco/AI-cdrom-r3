/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/

/************************ vector stuff ****************************/


/* BPvclip: Vector clip */
void BPvclip(float *v, float min, float max, int n)
{
  while(n--) {
    float val;

    val = *v;

    if (val < min ) *v = min;
    else if (val > max) *v = max;

    v++;
  }/* while n */
}

/* BPvsubsmulsum: Vector sub scalar mul sum */
void BPvsubsmulsum(float *result, float *new, float *old, float scalar, int n)
{
  while(n--) {
    *result++ += (*new++ - *old++) * scalar;
  }/* while n */
  
}/* end BPvsubsmulsum */



/* BPvmul: vector multiply  */
void BPvmul(float *to, float *v1, float *v2, int n)
{
  extern vmul();

  vmul(v1,1,v2,1,to,1,n);
}/* end BPvmul */

/* BPvmul_sum: vector multiply sum */
void BPvmul_sum(float *to, float *v1, float *v2, int n)
{
  extern void vma();

  vma(v1,1,v2,1,to,1,to,1,n);
}/* end BPvmul_sum */


/* BPvsmul: vector scalar multiply */
void BPvsmul(float *to, float *v, float s, int n)
{
  extern void vsmul();

  vsmul(v,1,&s,to,1,n);
}/* end BPvsmul */

/* BPvsmul_sum: vector scalar multiply sum */
void BPvsmul_sum(float *to, float *v, float s, int n)
{
  extern void vsma();
  
  vsma(v,1,&s,to,1,to,1,n);
}/* end BPvsmul_sum */


/* BPlvsmul: looping vector scalar multiply  */
void BPlvsmul(float *to, float *v, float *vs, int vsize, int lpcount)
{
  while(lpcount--) {
    BPvsmul(to, v, *vs, vsize);
    vs++;
    to += vsize;
    v += vsize;
  } /* end loop */
}/* end BPvsmul */

/* BPlvsmul_sum: looping vector scalar multiply increment */
void BPlvsmul_sum(float *to, float *v, float *vs, int vsize, int lpcount)
{
  while(lpcount--) {
    BPvsmul_sum(to, v, *vs, vsize);
    vs++;
    to += vsize;
    v += vsize;
  } /* end loop */
}/* end BPvsmul_sum */



/* BPvdot: Vector dot product */
float BPvdot(float *v1, float *v2, int n)
{
  float sum = 0.0;
  extern void dotpr();

  dotpr(v1, 1, v2, 1, &sum, n);
  
  return(sum);
}/* end BPvdot */


/* BPlvdot: Looping vector dot product (vector matrix mult) */
void BPlvdot(float *weights, float *from, int overlap, float *to, int n, int lc)
{
  if (overlap == n) { /* full connection */
    while(lc--) {
      extern void dotpr();
      
      dotpr(weights, 1, from, 1, to, n);
      to++;
      weights += n;
    }
  } else { 

    while(lc--) {
      extern void dotpr();
      
      dotpr(weights, 1, from, 1, to, n);
      to++;
      weights += n;
      from += n - overlap;  
    }

  }/* end else */
  
}/* end BPlvdot */

/* BPlvdot_share: Looping vector dot product (shared weights) */
void BPlvdot_share(float *weights, float *from, int overlap, float *to, int n, int lc)
{
  while(lc--) {
    extern void dotpr();
    
    dotpr(weights, 1, from, 1, to, n);
    to++;
    from += n - overlap;  
  }/* end while */
}/* end BPlvdot_share */

/* BPlvdot_sum: Looping vector dot product and sum */
void BPlvdot_sum(float *weights, float *from, int overlap, float *to, int n, int lc)
{
    while(lc--) {
      extern void dotpr();
      float sum;
      
      dotpr(weights, 1, from, 1, &sum, n);
      *to++ += sum;
      weights += n;
      from += n - overlap;  
    }/* end while */
  
}/* end BPlvdot_sum */

/* BPlvdot_share_sum: Looping vector dot product and sum (shared weights) */
 void BPlvdot_share_sum(float *weights, float *from, int overlap, float *to, int n, int lc)
{
  while(lc--) {
    extern void dotpr();
    float sum;
    
    dotpr(weights, 1, from, 1, &sum, n);
    *to++ += sum;
    from += n - overlap;  
  }/* end while */
  
}/* end BPlvdot_share_sum */

/* BPlvdot2d: For 2d connections. */
void BPlvdot2d(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *from, float *to, int xoverlap, int wstep, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
    while(counter--) {
      BPlvdot_sum(weights, from, xoverlap, to, tess_xdim, xdim);
      weights += wstep;
      from += fxstep;
    }/* end while tess_ydim */
    to += xdim;
    from -= fystep;
  }/* end while ydim */
}/* BPlvdot2d */

/* BPlvdot2d_share: For 2d connections (shared weights) */
void BPlvdot2d_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *from, float *to, int xoverlap, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
     float *kernel=weights;
    while(counter--) {
      BPlvdot_share_sum(kernel, from, xoverlap, to, tess_xdim, xdim);
      kernel += tess_xdim;
      from += fxstep;
    }/* end while tess_ydim */
    to += xdim;
    from -= fystep;
  }/* end while ydim */
}/* BPlvdot2d_share */


/************************ node stuff ************************/

  
#define TABLE_SIZE 1024
static float sigmoid_array[TABLE_SIZE];             /* table lookup sigmoid */
static float *sigmoid_ptr;                          /* pointer to center of sigmoid */

void BPinit_sigmoid_table()
{
  int counter;
  /* init table lookup for sigmoid [-1/2,1/2] */
  for(counter = 0; counter<TABLE_SIZE; counter++)
    sigmoid_array[counter] /* domain (8,8) w/511.5 at center (for 1024 table) */
      = (1.0 / (1.0 + AM_EXP(((TABLE_SIZE-1.0) - 2.0 * counter) / (TABLE_SIZE/8.0)))) - 0.5;
  sigmoid_ptr = sigmoid_array + (TABLE_SIZE/2) - 1;
}/* end BPinit_sigmoid_table */

/* Sigmoid macros */
#define sigmoid(x) ( (AM_FABS((x)) >= 8.0)?(((x)>0.0)?(0.499999):(-0.499999)):(*(sigmoid_ptr + (int)((TABLE_SIZE/16.0)*(x) + 0.5))) )
#define sigmoid1(x) (sigmoid(x) + 0.5)
#define sigmoid2(x) sigmoid(x)
#define sigmoid3(x) (2.0 * sigmoid(x))
#define sigmoid1prime(x) ( (x) * (1.0 - (x) ))
#define sigmoid2prime(x) (0.25 - ( (x) * (x) ))
#define sigmoid3prime(x) (0.5 * (1.0 - ( (x) * (x) )))


/* addbias: add the bias to the node value */
static  void addbias(float *nodes, float *biases, int n)
{
  extern void vadd();

  vadd(nodes,1,biases,1,nodes,1,n);
}/* end addbias */

/* BPsig1: sigmoid1 transfer function on layer */
void BPsig1(float *nodes, float *biases, int n)
{
  addbias(nodes,biases,n);
  while(n--) {
    float val;

    val = *nodes;
    *nodes++ = sigmoid1(val);
  }/* end while */

}/* end BPsig1 */

/* BPsig2: sigmoid2 transfer function on layer */
void BPsig2(float *nodes, float *biases, int n)
{
  addbias(nodes,biases,n);
  while(n--) {
    float val;

    val = *nodes;
    *nodes++ = sigmoid2(val);
  }/* end while */

}/* end BPsig2 */

/* BPsig3: sigmoid3 transfer function on layer */
void BPsig3(float *nodes, float *biases, int n)
{
  addbias(nodes,biases,n);
  while(n--) {
    float val;

    val = *nodes;
    *nodes++ = sigmoid3(val);
  }/* end while */

}/* end BPsig3 */

/* BPlinear: linear transfer function on layer */
void BPlinear(float *nodes, float *biases, int n)
{
    addbias(nodes,biases,n);
}/* end BPlinear */

/* BPquadratic: quadratic transfer function on layer */
void BPquadratic(float *nodes, float *netinput, float *biases, int n)
{
  /* Note: the netinput is accumulated in the node values vector,
           before being passed to this function.
   */
  addbias(nodes,biases,n);
  while(n--) {
    float sum;

    sum = *nodes;
    *netinput++ = sum;
    *nodes++ = sum * sum;
  }/* end while */
}/* end BPquadratic */

/* BPuser: user transfer function on layer */
void BPuser(float *nodes, float *netinput, float *biases, int n, float (*f)(float x))
{
  /* Note: the netinput is accumulated in the node values vector,
           before being passed to this function.
   */
  addbias(nodes,biases,n);
  while(n--) {
    *netinput = *nodes;
    *nodes++ = f(*netinput++);
  }/* end while */
}/* end BPuser */


/* BPderiv_sig1: derivative, update credit. */
void BPderiv_sig1(float *nodes, float *credit, int n, float bias)
{
  while(n--) {
    /* Scott Fahlman suggests biasing the derivative (88 Connectionist Summer School) */
    *credit++ *= (sigmoid1prime(*nodes) + bias);
    nodes++;
  }/* end while */
}/* end BPderiv_sig1 */


/* BPset_deriv_sig1: derivative */
void BPset_deriv_sig1(float *deriv, float *nodes, int n, float bias)
{
  while(n--) {
    /* Scott Fahlman suggests biasing the derivative (88 Connectionist Summer School) */
    *deriv++ = (sigmoid1prime(*nodes) + bias);
    nodes++;
  }/* end while */
}/* end BPset_deriv_sig1 */


/* BPderiv_sig2: derivative, update credit. */
void BPderiv_sig2(float *nodes, float *credit, int n, float bias)
{
  while(n--) {
    /* Scott Fahlman suggests biasing the derivative (88 Connectionist Summer School) */
    *credit++ *= (sigmoid2prime(*nodes) + bias);
    nodes++;
  }/* end while */
}/* end BPderiv_sig2 */


/* BPset_deriv_sig2: derivative */
void BPset_deriv_sig2(float *deriv, float *nodes, int n, float bias)
{
  while(n--) {
    /* Scott Fahlman suggests biasing the derivative (88 Connectionist Summer School) */
    *deriv++ = (sigmoid2prime(*nodes) + bias);
    nodes++;
  }/* end while */
}/* end BPset_deriv_sig2 */

/* BPderiv_sig3: derivative, update credit. */
void BPderiv_sig3(float *nodes, float *credit, int n, float bias)
{
  while(n--) {
    /* Scott Fahlman suggests biasing the derivative (88 Connectionist Summer School) */
    *credit++ *= (sigmoid3prime(*nodes) + bias);
    nodes++;
  }/* end while */
}/* end BPderiv_sig3 */


/* BPset_deriv_sig3: derivative */
void BPset_deriv_sig3(float *deriv, float *nodes, int n, float bias)
{
  while(n--) {
    /* Scott Fahlman suggests biasing the derivative (88 Connectionist Summer School) */
    *deriv++ = (sigmoid3prime(*nodes) + bias);
    nodes++;
  }/* end while */
}/* end BPset_deriv_sig3 */

/* BPderiv_quadratic: derivative, update credit. */
void BPderiv_quadratic(float *netinput, float *credit,int n)
{

  while(n--)  *credit++ *= (2.0 * *netinput++);

}/* end BPderiv_quadratic */

/* BPderiv_user: derivative, update credit. */
void BPderiv_user(float *netinput, float *credit, int n, float (*f_prime)(float x))
{
  while(n--) *credit++ *= f_prime(*netinput++);
}/* end BPderiv_user */


/************************ basic learning stuff ****************************/

float BPsum_squares(float *v, int n)
{
  float sum=0.0;

  while(n--) {
    float val;

    val = *v++;
    sum += val * val;
  }/* end while */

  return(sum);
}


/* BPoutput_error: Diff on the output, updates credit, returns MSE/2 */
float BPoutput_error(float *target, float *output, float *credit, float scalar, int n)
{
  float total_error;
  extern void vsub(), vsmul();

  vsub(output,1,target,1,credit,1,n);
  total_error = BPsum_squares(credit, n);
  vsmul(credit,1,&scalar,credit,1,n);

  return( total_error / 2.0 );
}/* end BPoutput_error */


/* BPaccum_biases: alter thresholds. */
void BPaccum_biases(float *changes, float *credit, int n)
{
  extern void vadd();

  vadd(changes,1,credit,1,changes,1,n);

}/* end BPaccum_biases */

/* BPaccum_weights_from_input: calc weight change. */
void BPaccum_weights_from_input(float *to_credit, float *from, float *changes, int n_to, int n_from, int overlap)
{
  while(n_to--) {
    extern void vsma();

    vsma(from,1,to_credit,changes,1,changes,1,n_from);
    to_credit++;
    from += n_from - overlap;
    changes += n_from;
  }/* end while */

}/* end BPaccum_weights_from_input */

/* BPaccum_weights_from_input_share: alter SHARED weights. */
void BPaccum_weights_from_input_share(float *to_credit, float *from, float *changes, int n_to, int n_from, int overlap)
{
  while(n_to--) {
    extern void vsma();

    vsma(from,1,to_credit,changes,1,changes,1,n_from);
    to_credit++;
    from += n_from - overlap;
  }/* end while */

}/* end BPaccum_weights_from_input_share */

/* BPaccum_weights_from_hidden: alter weights. */
void BPaccum_weights_from_hidden(float *to_credit, float *from, float *from_credit, float *weights, float *changes, int n_to, int n_from, int overlap)
{
  while(n_to--) {
    extern void vsma();

    vsma(from,1,to_credit,changes,1,changes,1,n_from);
    vsma(weights,1,to_credit,from_credit,1,from_credit,1,n_from);
    to_credit++;
    changes += n_from;
    weights += n_from;
    from += n_from - overlap;
    from_credit += n_from - overlap;
  }/* end while */

}/* end BPaccum_weights_from_hidden */

/* BPaccum_weights_from_hidden_share: alter SHARED weights. */
void BPaccum_weights_from_hidden_share(float *to_credit, float *from, float *from_credit, float *weights, float *changes, int n_to, int n_from, int overlap)
{
  while(n_to--) {
    extern void vsma();

    vsma(from,1,to_credit,changes,1,changes,1,n_from);
    vsma(weights,1,to_credit,from_credit,1,from_credit,1,n_from);
    to_credit++;
    from += n_from - overlap;
    from_credit += n_from - overlap;
  }/* end while */

}/* end BPaccum_weights_from_hidden_share */

/* BPaccum2d_weights_from_input: For 2d connections. */
void BPaccum2d_weights_from_input(int xdim, int ydim, int tess_xdim, int tess_ydim, float *changes, float *from, float *to_credit, int xoverlap, int wstep, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
    while(counter--) {
      BPaccum_weights_from_input(to_credit, from,
				      changes,
				      xdim, tess_xdim, xoverlap);
      changes += wstep;
      from += fxstep;
    }/* end while tess_ydim */
    to_credit += xdim;
    from -= fystep;
  }/* end while ydim */
}/* BPaccum2d_weights_from_input */

/* BPaccum2d_weights_from_input_share: For 2d connections (shared weights) */
void BPaccum2d_weights_from_input_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *changes, float *from, float *to_credit, int xoverlap, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
     float *kernel=changes;
    while(counter--) {
      BPaccum_weights_from_input_share(to_credit, from,
					    kernel, xdim, tess_xdim, xoverlap);
      kernel += tess_xdim;
      from += fxstep;
    }/* end while tess_ydim */
    to_credit += xdim;
    from -= fystep;
  }/* end while ydim */
}/* BPaccum2d_weights_from_input_share */

/* BPaccum2d_weights_from_hidden: For 2d connections. */
void BPaccum2d_weights_from_hidden(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *changes, float *from, float *from_credit, float *to_credit, int xoverlap, int wstep, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
    while(counter--) {
      BPaccum_weights_from_hidden(to_credit, from, from_credit,
				       weights, changes,
				       xdim, tess_xdim, xoverlap);
      weights += wstep;
      changes += wstep;
      from += fxstep;
      from_credit += fxstep;
    }/* end while tess_ydim */
    to_credit += xdim;
    from -= fystep;
    from_credit -= fystep;
  }/* end while ydim */
}/* BPaccum2d_weights_from_hidden */


/* BPaccum2d_weights_from_hidden_share: For 2d connections (shared weights). */
void BPaccum2d_weights_from_hidden_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *changes, float *from, float *from_credit, float *to_credit, int xoverlap, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
     float *kernel=weights,*ckernel=changes;
    while(counter--) {
      BPaccum_weights_from_hidden_share(to_credit, from, from_credit,
					     kernel, ckernel, xdim, tess_xdim, xoverlap);
      kernel += tess_xdim;
      ckernel += tess_xdim;
      from += fxstep;
      from_credit += fxstep;
    }/* end while tess_ydim */
    to_credit += xdim;
    from -= fystep;
    from_credit -= fystep;
  }/* end while ydim */
}/* BPaccum2d_weights_from_hidden_share */


/* BPupdate_weights: change the weights by accumulated change */
void BPupdate_weights(float inertia, float *changes, float *weights, float *delta_weights, int n)
{
   extern void vadd(), vsmul();

   vsmul(delta_weights,1,&inertia,delta_weights,1,n);
   vadd(changes,1,delta_weights,1,delta_weights,1,n);
   vadd(delta_weights,1,weights,1,weights,1,n);

}/* BPupdate_weights */


/************************ autoregressive backprop stuff ****************************/


/* Finding the roots of the characterisitic equation:
   D(z) = z^n - a1*z^(n-1) - a2*z^(n-2) - a3,
   where the a's are the feedback weights.
 */

#define BP_DBL_ZERO(x) ( (AM_FABS(x) < (10.0 * DBL_MIN) ) )

/*    D(z) = z^1 - a1 */
void BPar1_poles(double a, AM_COMPLEX *r)
{
  r->real = a;    /* it's just the weight */
  r->imag = 0.0;
}

/*   D(z) = z^2 - a1*z^1 - a2 */
void BPar2_poles(double a1, double a2, AM_COMPLEX *r)
{
  double d;

  a1 *= -1.0;
  a2 *= -1.0;

  /* use quadratic formula */
  d = (a1 * a1) - (4.0 * a2);
  if ( BP_DBL_ZERO(d) ) {  /* 2 equal real roots */
    double real;

    real = -a1 / 2.0;
    r->real = real;
    r->imag = 0.0;
    r++;
    r->real = real;
    r->imag = 0.0;

  } else if (d < 0.0) { /* complex conjugates */
    double real, imag;

    real = -a1 / 2.0;
    imag = AM_SQRT(-d) / 2.0;
    r->real = real;
    r->imag = imag;
    r++;
    r->real = real;
    r->imag = -imag;

  } else { /* 2 real */

    r->real = (-a1 + AM_SQRT(d)) / 2.0;
    r->imag = 0.0;
    r++;
    r->real = (-a1 - AM_SQRT(d)) / 2.0;
    r->imag = 0.0;

  }/* end if else */

}

/*   D(z) = z^3 - a1*z^2 - a2*z^1 - a3 */
void BPar3_poles(double a1, double a2,double a3, AM_COMPLEX *r)
{
  fprintf(stderr, "\nCube root not implemented!\n"); am_exit( EXIT_FAILURE );
}





/************* Stabilize by not allowing weights to *************/
/************* leave stable region...test with the  *************/
/************* Routh-Hurwitz criterion.             *************/


/* BPunstable_1st: true if unstable AR weight */
int BPunstable_1st(float x)
{
  return ( (float)(AM_FABS(x)) >= (float)1.0 ) ;
}/* end BPunstable_1st */


/* BPTupdate_1st : update and stabilize first order feedback weights */
void BPTupdate_1st(float inertia,float *changes, float *weights, float *delta_weights, int n)
{
  /* update, keep stable */
  while(n--) {
    float new_weight,change;
    int trys=30;
    
    change = *changes + (inertia * *delta_weights);
    new_weight = *weights + change;
    
    while ( BPunstable_1st(new_weight) ) { /* not stable if mag >= 1 */
      
      /* now contract to be within stability boundries (underflow to 0) */
      change *= 0.5; /* contract by 1/2 */
      trys--;

      /* decay if on edge of stability...what else can you do? */
      if ( ! trys ) {
	new_weight = *weights * 0.9999;
        break;
      } else
	/* new weight */
	new_weight = *weights + change;

    }/* end while */
    
    /* set */
    *weights = new_weight;
    *delta_weights = change;
    
    /* onward */
    weights++; delta_weights++; changes++;
    
  } /* end while */
  
}/* BPTupdate_1st */



/* BPunstable_2nd: true if unstable AR weights */
int BPunstable_2nd(float x1, float x2)
{
  return ( (x2 + (float)(AM_FABS(x1)) >= (float)1.0) || (x2 <= (float)-1.0) ) ;
}/* end BPunstable_2nd */


/* BPTupdate_2nd : update and stabilize second order feedback weights */
void BPTupdate_2nd(float inertia, float *changes_1, float *changes_2, float *weights_1, float *weights_2, float *delta_weights_1, float *delta_weights_2, int n)
{
  /* update, keep stable */
  while(n--) {
    float new_weight_1, new_weight_2;
    float change_1, change_2;
    int trys=30;
    
    change_1 = *changes_1 + (inertia * *delta_weights_1);
    change_2 = *changes_2 + (inertia * *delta_weights_2);
    new_weight_1 = *weights_1 + change_1;
    new_weight_2 = *weights_2 + change_2;
    
    while ( BPunstable_2nd(new_weight_1, new_weight_2) ) { /* unstable! */
      
      /* now contract to be within stability boundries (underflow to 0) */
      change_1 *= 0.5; /* contract by 1/2 */
      change_2 *= 0.5; /* contract by 1/2 */
      trys--;

      /* decay if on edge of stability...what else can you do? */
      if ( ! trys ) {
	
	new_weight_1 = *weights_1 * 0.9999;
	new_weight_2 = *weights_2 * 0.9999;
	break;
	
      } else { /* end if stuck */
	
	/* new weights */
	new_weight_1 = *weights_1 + change_1;
	new_weight_2 = *weights_2 + change_2;
	
      } /* end else not stuck */
      
    }/* end while */
    
    /* set */
    *weights_1 = new_weight_1;
    *weights_2 = new_weight_2;
    *delta_weights_1 = change_1;
    *delta_weights_2 = change_2;
    
    /* onward */
    weights_1++; weights_2++;
    delta_weights_1++; delta_weights_2++;
    changes_1++; changes_2++;
    
  } /* end while */
  
}/* BPTupdate_2nd */

/* BPTaccum_feedback_weights: Accumulate changes to feedback coef. */
void BPTaccum_feedback_weights(float *changes, float *partials, float *credit, int n)
{
  BPvmul_sum(changes, partials, credit, n);
}/* end BPTaccum_feedback_weights */


/* BPTaccum_biases: thresholds. */
void BPTaccum_biases(float *changes, float *credit, float *to_deriv, float *partials, int n)
{
  extern void vadd(), vma();

  vadd(partials,1,to_deriv,1,partials,1,n);
  vma(credit,1,partials,1,changes,1,changes,1,n);

}/* end BPTaccum_biases */


/* BPTaccum_weights_from_input: calc weight change. */
void BPTaccum_weights_from_input(float *to_credit,float *to_deriv,float *from, float *changes, float *partials, int n_to, int n_from, int overlap)
{
  extern void vsma();

  while(n_to--) {
    vsma(from,1, to_deriv, partials,1, partials,1, n_from);
    vsma(partials,1, to_credit, changes,1, changes,1, n_from);
    to_deriv++; to_credit++;    /* scalars */
    partials += n_from;
    changes += n_from;
    from += n_from - overlap;
  }/* end while */

}/* end BPTaccum_weights_from_input */

/* BPTaccum_weights_from_input_share: alter SHARED weights. */
void BPTaccum_weights_from_input_share(float *to_credit, float *to_deriv, float *from, float *changes, float *partials, int n_to, int n_from, int overlap)
{
  extern void vsma();

  while(n_to--) {
    vsma(from,1, to_deriv, partials,1, partials,1, n_from);
    vsma(partials,1, to_credit, changes,1, changes,1, n_from);
    to_deriv++; to_credit++;    /* scalars */
    from += n_from - overlap;
  }/* end while */

}/* end BPTaccum_weights_from_input_share */

/* BPTaccum_weights_from_hidden: alter weights. */
void BPTaccum_weights_from_hidden(float *to_credit, float *to_deriv, float *from, float *from_credit, float *weights, float *changes, float *opartials, float *wpartials, int n_to, int n_from, int overlap)
{
  extern void vsma();

  while(n_to--) {
    /* accumulate error */
    vsma(weights,1, to_deriv, wpartials,1, wpartials,1, n_from);
    vsma(wpartials,1, to_credit, from_credit,1, from_credit,1, n_from);

    /* accumulate weight change */
    vsma(from,1, to_deriv, opartials,1, opartials,1, n_from);
    vsma(opartials,1, to_credit, changes,1, changes,1, n_from);

    /* update ptrs */
    to_deriv++; to_credit++;    /* scalars */
    weights += n_from;
    opartials += n_from;
    wpartials += n_from;
    changes += n_from;
    from += n_from - overlap;
    from_credit += n_from - overlap;
  }/* end while */

}/* end BPTaccum_weights_from_hidden */

/* BPTaccum_weights_from_hidden_share: alter SHARED weights. */
void BPTaccum_weights_from_hidden_share(float *to_credit, float *to_deriv, float *from, float *from_credit, float *weights, float *changes, float *opartials, float *wpartials, int n_to, int n_from, int overlap)
{
  extern void vsma();

  while(n_to--) {
    /* accumulate error */
    vsma(weights,1, to_deriv, wpartials,1, wpartials,1, n_from);
    vsma(wpartials,1, to_credit, from_credit,1, from_credit,1, n_from);

    /* accumulate weight change */
    vsma(from,1, to_deriv, opartials,1, opartials,1, n_from);
    vsma(opartials,1, to_credit, changes,1, changes,1, n_from);

    /* update ptrs */
    to_deriv++; to_credit++;    /* scalars */
    from += n_from - overlap;
    from_credit += n_from - overlap;
  }/* end while */

}/* end BPTaccum_weights_from_hidden_share */

/* BPTaccum2d_weights_from_input: For 2d connections. */
void BPTaccum2d_weights_from_input(int xdim, int ydim, int tess_xdim, int tess_ydim, float *changes, float *opartials, float *from, float *to_credit, float *to_deriv, int xoverlap, int wstep, int fxstep, int fystep)
{
  while(ydim--) {
    int counter=tess_ydim;
    while(counter--) {
      BPTaccum_weights_from_input(to_credit, to_deriv, from,
				       changes, opartials,
				       xdim, tess_xdim, xoverlap);
      changes += wstep;
      opartials += wstep;
      from += fxstep;
    }/* end while tess_ydim */
    to_credit += xdim;
    to_deriv += xdim;
    from -= fystep;
  }/* end while ydim */
}/* BPTaccum2d_weights_from_input */

/* BPTaccum2d_weights_from_input_share: For 2d connections (shared weights) */
void BPTaccum2d_weights_from_input_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *changes, float *opartials, float *from, float *to_credit, float *to_deriv, int xoverlap, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
     float *kernel=changes,*pkernel=opartials;
    while(counter--) {
      BPTaccum_weights_from_input_share(to_credit,to_deriv,from,
					     kernel, pkernel,
					     xdim, tess_xdim, xoverlap);
      kernel += tess_xdim;
      pkernel += tess_xdim;
      from += fxstep;
    }/* end while tess_ydim */
    to_credit += xdim;
    to_deriv += xdim;
    from -= fystep;
  }/* end while ydim */
}/* BPTaccum2d_weights_from_input_share */

/* BPTaccum2d_weights_from_hidden: For 2d connections. */
void BPTaccum2d_weights_from_hidden(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *changes, float *opartials, float *wpartials, float *from, float *from_credit, float *to_credit, float *to_deriv, int xoverlap, int wstep, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
    while(counter--) {
      BPTaccum_weights_from_hidden(to_credit,to_deriv,  from, from_credit,
					weights, changes, opartials, wpartials,
					xdim, tess_xdim, xoverlap);
      weights += wstep;
      changes += wstep;
      opartials += wstep;
      wpartials += wstep;
      from += fxstep;
      from_credit += fxstep;
    }/* end while tess_ydim */
    to_credit += xdim;
    to_deriv += xdim;
    from -= fystep;
    from_credit -= fystep;
  }/* end while ydim */
}/* BPTaccum2d_weights_from_hidden */

/* BPTaccum2d_weights_from_hidden_share: For 2d connections (shared weights). */
void BPTaccum2d_weights_from_hidden_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *changes, float *opartials, float *wpartials, float *from, float *from_credit, float *to_credit, float *to_deriv, int xoverlap, int fxstep, int fystep)
{
  while(ydim--) {
     int counter=tess_ydim;
     float *kernel=weights,*ckernel=changes,*opkernel=opartials,*wpkernel=wpartials;
    while(counter--) {
      BPTaccum_weights_from_hidden_share(to_credit, to_deriv, from, from_credit,
					      kernel, ckernel, opkernel, wpkernel,
					      xdim, tess_xdim, xoverlap);
      kernel += tess_xdim;
      ckernel += tess_xdim;
      opkernel += tess_xdim;
      wpkernel += tess_xdim;
      from += fxstep;
      from_credit += fxstep;
    }/* end while tess_ydim */
    to_credit += xdim;
    to_deriv += xdim;
    from -= fystep;
    from_credit -= fystep;
  }/* end while ydim */
}/* BPTaccum2d_weights_from_hidden_share */

