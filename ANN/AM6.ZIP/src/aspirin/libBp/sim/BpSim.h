/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/



/* exported functions from $NNTOOLS/aspirin/sim */
extern void BPfrandom_init(long seed);
extern void BPread_string(int fd, char *string);
extern int BPread_thresholds(int fd, char *name, char *key, int size, int target_size, float *data, int *flag);
extern int BPread_feedback_weights(int fd, char *name, char *key, int size, int target_size, float *data, int *flag);
extern int BPread_weights(int fd, char *name1, char *key1, char *name2, char *key2, int size, int target_size, float *data, int *flag);
extern float BPfrandom(float val);
extern void BPvclip(float *v, float min, float max, int n);
extern void BPvsubsmulsum(float *result, float *new, float *old, float scalar, int n);
extern void BPvmul(float *to, float *v1, float *v2, int n);
extern void BPvmul_sum(float *to, float *v1, float *v2, int n);
extern void BPvsmul(float *to, float *v, float s, int n);
extern void BPvsmul_sum(float *to, float *v, float s, int n);
extern void BPlvsmul(float *to, float *v, float *vs, int vsize, int lpcount);
extern void BPlvsmul_sum(float *to, float *v, float *vs, int vsize, int lpcount);
extern void BPlvdot(float *weights, float *from, int overlap, float *to, int n, int lc);
extern void BPlvdot_share(float *weights, float *from, int overlap, float *to, int n, int lc);
extern void BPlvdot_sum(float *weights, float *from, int overlap, float *to, int n, int lc);
extern void BPlvdot2d(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *from, float *to, int xoverlap, int wstep, int fxstep, int fystep);
extern void BPlvdot2d_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *from, float *to, int xoverlap, int fxstep, int fystep);
extern void BPinit_sigmoid_table();
extern void BPsig1(float *nodes, float *biases, int n);
extern void BPsig2(float *nodes, float *biases, int n);
extern void BPsig3(float *nodes, float *biases, int n);
extern void BPlinear(float *nodes, float *biases, int n);
extern void BPquadratic(float *nodes, float *netinput, float *biases, int n);
extern void BPuser(float *nodes, float *netinput, float *biases, int n, float (*f)(float x));
extern void BPderiv_sig1(float *nodes, float *credit, int n, float bias);
extern void BPset_deriv_sig1(float *deriv, float *nodes, int n, float bias);
extern void BPderiv_sig2(float *nodes, float *credit, int n, float bias);
extern void BPset_deriv_sig2(float *deriv, float *nodes, int n, float bias);
extern void BPderiv_sig3(float *nodes, float *credit, int n, float bias);
extern void BPset_deriv_sig3(float *deriv, float *nodes, int n, float bias);
extern void BPderiv_quadratic(float *netinput, float *credit,int n);
extern void BPderiv_user(float *netinput, float *credit, int n, float (*f_prime)(float x));
extern void BPaccum_biases(float *changes, float *credit, int n);
extern void BPaccum_weights_from_input(float *to_credit, float *from, float *changes, int n_to, int n_from, int overlap);
extern void BPaccum_weights_from_input_share(float *to_credit, float *from, float *changes, int n_to, int n_from, int overlap);
extern void BPaccum_weights_from_hidden(float *to_credit, float *from, float *from_credit, float *weights, float *changes, int n_to, int n_from, int overlap);
extern void BPaccum_weights_from_hidden_share(float *to_credit, float *from, float *from_credit, float *weights, float *changes, int n_to, int n_from, int overlap);
extern void BPaccum2d_weights_from_input(int xdim, int ydim, int tess_xdim, int tess_ydim, float *changes, float *from, float *to_credit, int xoverlap, int wstep, int fxstep, int fystep);
extern void BPaccum2d_weights_from_input_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *changes, float *from, float *to_credit, int xoverlap, int fxstep, int fystep);
extern void BPaccum2d_weights_from_hidden(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *changes, float *from, float *from_credit, float *to_credit, int xoverlap, int wstep, int fxstep, int fystep);
extern void BPaccum2d_weights_from_hidden_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *changes, float *from, float *from_credit, float *to_credit, int xoverlap, int fxstep, int fystep);
extern void BPupdate_weights(float inertia, float *changes, float *weights, float *delta_weights, int n);
extern void BPar1_poles(double a, AM_COMPLEX *r);
extern void BPar2_poles(double a1, double a2, AM_COMPLEX *r);
extern void BPar3_poles(double a1, double a2,double a3, AM_COMPLEX *r);
extern void BPTupdate_1st(float inertia,float *changes, float *weights, float *delta_weights, int n);
extern void BPTupdate_2nd(float inertia, float *changes_1, float *changes_2, float *weights_1, float *weights_2, float *delta_weights_1, float *delta_weights_2, int n);
extern void BPTaccum_feedback_weights(float *changes, float *partials, float *credit, int n);
extern void BPTaccum_biases(float *changes, float *credit, float *to_deriv, float *partials, int n);
extern void BPTaccum_weights_from_input(float *to_credit,float *to_deriv,float *from, float *changes, float *partials, int n_to, int n_from, int overlap);
extern void BPTaccum_weights_from_input_share(float *to_credit, float *to_deriv, float *from, float *changes, float *partials, int n_to, int n_from, int overlap);
extern void BPTaccum_weights_from_hidden(float *to_credit, float *to_deriv, float *from, float *from_credit, float *weights, float *changes, float *opartials, float *wpartials, int n_to, int n_from, int overlap);
extern void BPTaccum_weights_from_hidden_share(float *to_credit, float *to_deriv, float *from, float *from_credit, float *weights, float *changes, float *opartials, float *wpartials, int n_to, int n_from, int overlap);
extern void BPTaccum2d_weights_from_input(int xdim, int ydim, int tess_xdim, int tess_ydim, float *changes, float *opartials, float *from, float *to_credit, float *to_deriv, int xoverlap, int wstep, int fxstep, int fystep);
extern void BPTaccum2d_weights_from_input_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *changes, float *opartials, float *from, float *to_credit, float *to_deriv, int xoverlap, int fxstep, int fystep);
extern void BPTaccum2d_weights_from_hidden(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *changes, float *opartials, float *wpartials, float *from, float *from_credit, float *to_credit, float *to_deriv, int xoverlap, int wstep, int fxstep, int fystep);
extern void BPTaccum2d_weights_from_hidden_share(int xdim, int ydim, int tess_xdim, int tess_ydim, float *weights, float *changes, float *opartials, float *wpartials, float *from, float *from_credit, float *to_credit, float *to_deriv, int xoverlap, int fxstep, int fystep);
extern int BPunstable_1st(float x);
extern int BPunstable_2nd(float x1, float x2);
extern float BPvdot(float *v1, float *v2, int n);
extern float BPsum_squares(float *v, int n);
extern float BPoutput_error(float *target, float *output, float *credit, float scalar, int n);
