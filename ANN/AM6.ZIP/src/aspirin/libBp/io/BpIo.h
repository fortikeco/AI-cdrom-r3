/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/



/* exported functions from $NNTOOLS/aspirin/gfx */
extern void BPbb_input_dim(int bbindex, int *xdim, int *ydim);
extern void BPbb_layer_dim(int bbindex, int lindex, int *xdim, int *ydim);
extern void BPbb_layer_type(int bbindex, int lindex, int *type);
extern void BPbb_connection_dim(int bbindex, int lindex, int cindex, int *type, int *xdim, int *ydim, int *xoffset, int *yoffset);
extern void BPis_bb_connected(int to_bb_index, int from_bb_index,  void (*connect_ftn)() );
extern void BPis_input_connected(int to_bb_index, void (*connect_ftn)() );
extern void BPis_layer_intra_connected(int to_bb_index, int lindex, void (*connect_ftn)() );
extern void BPis_layer_inter_connected(int to_bb_index, int lindex, void (*connect_ftn)() );
extern void BPrw_input_values(int bbindex, float *d, int n, int rw);
extern void BPrw_target_values(int bbindex, float *d, int n, int rw);
extern void BPr_mag_diff_target_values(int bbindex, float *d, int n);
extern void BPrw_layer_values(int bbindex, int lindex, float *d, int n, int rw);
extern void BPrw_bias_values(int bbindex, int lindex, float *d, int n, int rw);
extern void BPrw_ar_values(int bbindex, int lindex, int delay, float *d, int n, int rw);
extern void BPrw_connection_values(int bbindex, int lindex, int cindex, int x, int y, float *d, int n, int rw);
extern int BPn_bbs();
extern int BPbb_dynamic(int bbindex);
extern int BPbb_efferent(int bbindex);
extern int BPn_bb_layers(int bbindex);
extern int BPbb_input_size(int bbindex);
extern int BPbb_input_delays(int bbindex);
extern int BPbb_output_layer_index(int bbindex);
extern int BPn_bb_inputs(int bbindex);
extern int BPn_bb_outputs(int bbindex);
extern int BPbb_connection_delay(int bbindex, int lindex, int cindex);
extern int BPn_layer_inputs(int bbindex, int lindex);
extern int BPn_layer_outputs(int bbindex, int lindex);
extern int BPbb_layer_order(int bbindex, int lindex);
extern char *BPbb_name(int bbindex);
extern char *BPbb_layer_name(int bbindex, int lindex);
extern char *BPbb_connection_from_name(int bbindex, int lindex, int cindex);
