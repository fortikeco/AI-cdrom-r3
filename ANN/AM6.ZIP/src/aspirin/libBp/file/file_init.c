/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include <stdio.h>
#include "BpDatafile.h"

/* noise functions */
extern float *_no_noise(float *from_ptr, float *to_ptr, float mean, float variance, int n);
extern float *_add_normal_noise(float *from_ptr, float *to_ptr, float mean, float variance, int n);
extern float *_add_uniform_noise(float *from_ptr, float *to_ptr, float mean, float variance, int n);

DFPTR _make_df_root()
{
  DFPTR df; /* root */

  /* create root data structure */
  df = (DFPTR)am_alloc_mem(sizeof(DF));

  /* set */
  df->inputs_xdim = 0;
  df->inputs_ydim = 0;
  df->inputs_size = 0;
  df->targets_xdim = 0;
  df->targets_ydim = 0;
  df->targets_size = 0;
  df->setfunctions = (FUNCTIONSPTR)NULL;
  df->datafiles = (DATAFILEPTR)NULL;
  df->n_datafiles = 0;
  df->datafile_table = (DATAFILEPTR *)NULL;
  df->noise = NULL;
  df->input_buffer = (float *)NULL;

  return(df);
}

/* file_init: Init structures, get sizes from network. */
DFPTR _file_init(
		 LB_PTR (*query_function)(),
		 int noise_type,
		 float mean,
		 float variance
		 )
{
  BBB_PTR bbinfo;
  LB_PTR layer;
  DFPTR df; /* root */
  int bbindex = 0;

  /* create root data structure */
  df = _make_df_root();

  /* now update the dimensions, create list of setfunctions */
  while((layer = query_function(bbindex,0)) != (LB_PTR)NULL) {

    /* ask the network for black box information */
    bbinfo = &((query_function(bbindex,0))->black_box_info);

    /* get the output layer for target dimensions */
    layer = query_function(bbindex, bbinfo->output_layer_index);

    /* test to see if ALL black boxes have same input/target
       dimensions. */
    if (df->setfunctions != (FUNCTIONSPTR)NULL) { /* been set at least once */
      
      /* can i set the targets? */
      if (bbinfo->set_target_output != NULL) { /* does this bb have targets? */
	if (df->targets_xdim != 0) {/* have the global target sizes been set ? */
	  /* cannot have different sized targets to use this */
	  if (df->targets_xdim != layer->xdim ||	  
	      df->targets_ydim != layer->ydim) {
	    fprintf(stderr,"\nError: Two black boxes have different target sizes.");
	    fprintf(stderr,
		    "\nYou should use your own generator in this case.\n");
	    am_exit( EXIT_FAILURE );
	  }/* end if */
	}/* end if */
	else {
	  df->targets_xdim = layer->xdim;
	  df->targets_ydim = layer->ydim;
	}/* end else */
      }/* end if */
      
      /* can i set the inputs? */
      if (bbinfo->n_inputs != 0) { /* does this bb have inputs? */
	if (df->inputs_xdim != 0) { /* have the global input size been set? */
	  if (df->inputs_xdim != bbinfo->inputs_xdim ||
	      df->inputs_ydim != bbinfo->inputs_ydim) {
	    fprintf(stderr,"\nError: Two black boxes have different input sizes.");
	    fprintf(stderr,"\nYou should use your own generator in this case.\n");
	    am_exit( EXIT_FAILURE );
	  }/* end if */
	}/* end if */
	else {
	  df->inputs_xdim = bbinfo->inputs_xdim;
	  df->inputs_ydim = bbinfo->inputs_ydim;
	}/* end else */
      }/* end if */
      
      /* update functions? */
      if (bbinfo->set_target_output != NULL ||
	  bbinfo->n_inputs != 0) {
	FUNCTIONSPTR temp = df->setfunctions;
	
	/* add new function structure */
	df->setfunctions = (FUNCTIONSPTR)am_alloc_mem(sizeof(FUNCTIONS));
	df->setfunctions->set_target_output = bbinfo->set_target_output;
	df->setfunctions->set_input = bbinfo->set_input;
	
	df->setfunctions->next = temp;
      }/* end if */
      
      
    } else { /* never been set */

      /* can i set the targets? */
      if (bbinfo->set_target_output != NULL) { 
	df->targets_xdim = layer->xdim;
	df->targets_ydim = layer->ydim;
      }/* end if */

      /* can i set the inputs? */
      if (bbinfo->n_inputs != 0) { 
        df->inputs_xdim = bbinfo->inputs_xdim;
	df->inputs_ydim = bbinfo->inputs_ydim;
      }/* end if */

      /* did i change anything? */
      if (df->inputs_xdim != 0 || df->targets_xdim != 0) {
	/* add new function structure */
	df->setfunctions = (FUNCTIONSPTR)am_alloc_mem(sizeof(FUNCTIONS));
	df->setfunctions->set_target_output = bbinfo->set_target_output;
	df->setfunctions->set_input = bbinfo->set_input;
	df->setfunctions->next = NULL;
      }/* end if */
      
    }/* end if else */

    bbindex++;
  }/* end while */


  /* noise info */
  df->inputs_size = df->inputs_xdim * df->inputs_ydim;
  df->targets_size = df->targets_xdim * df->targets_ydim;
  df->mean = mean;
  df->variance = variance;
  switch (noise_type) {
  case NO_NOISE :
    df->noise = _no_noise;
    df->input_buffer = (float *)NULL;
    break;
  case NORMAL_NOISE :
    df->noise = _add_normal_noise;
    df->input_buffer = (float *)am_alloc_mem(df->inputs_size * sizeof(float)); 
    break;
  case UNIFORM_NOISE :
    df->noise = _add_uniform_noise;
    df->input_buffer = (float *)am_alloc_mem(df->inputs_size * sizeof(float)); 
    break;
  }/* end switch */


  return(df);
}/* end _file_init */
