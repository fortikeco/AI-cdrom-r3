/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "BpDatafile.h"
#include "globals.h"  

/*****************************************************/
/* lowclip_data                                      */
/*****************************************************/
static void lowclip_data(float *vector , float lowclip, int n)
{
  
  /* for each value */
  while(n--) {

    /* clip low */
    if (*vector < lowclip) *vector = lowclip;

    vector++;
    
  }/* end while */
  
}/* end lowclip_data */

/*****************************************************/
/* highclip_data                                     */
/*****************************************************/
static void highclip_data(float *vector , float highclip, int n)
{
  
  /* for each value */
  while(n--) {

    /* clip low */
    if (*vector > highclip) *vector = highclip;

    vector++;
    
  }/* end while */
  
}/* end highclip_data */
  
/*****************************************************/
/* rescale_data                                      */
/*****************************************************/
static void rescale_data(float *data, float threshold, float range, float scalar, float bias, int n)
{
  /* range */
  if (range > 0.0) {
    double max_val = -AM_HUGE_VAL, min_val = AM_HUGE_VAL;
    int s = n;
    float *ptr=data;
    
    /* max, min */
    while(s--) {
      if (*ptr > max_val) max_val = *ptr;
      if (*ptr < min_val) min_val = *ptr;
      ptr++;
    }

    if (max_val < threshold) max_val = threshold;

    max_val -= min_val;
    
    if (max_val != 0.0) {

      s = n;
      ptr = data;
      bias += range * -0.5;
      while(s--) {
	float val=*ptr;

	*ptr++ = (range * ((val - min_val)/max_val));
      }/* end while */

    } else  bzero(data, n * sizeof(float));
    
  } 
  
  /* scale */
  if (scalar != 1.0) {
    int s=n;
    float *ptr=data;
    
    while(s--) *ptr++ *= scalar;
  }
  
  
  /* bias */
  if (bias != 0.0) {
    int s=n;
    float *ptr=data;
    
    while(s--) *ptr++ += bias;
  }
  
  
}/* end rescale_data */

/*****************************************************/
/* swapbytes_data                                    */
/*****************************************************/
static void swapbytes_data(float *vector, int n)
{
  
  /* for each value */
  while(n--) {
    union {
      float f;
      char c[sizeof(float)];
    } newval,oldval;
    int sz = sizeof(float);
    
    /* swap */
    oldval.f = *vector;
    while(sz--) newval.c[sz] = oldval.c[ sizeof(float) - 1 - sz ];
    *vector++ = newval.f;
    
  }/* end while */
  
}/* end swapbytes_data */


/*****************************************************/
/* math_data                                         */
/*****************************************************/
static void math_data(int function, float *vector, int n)
{
  switch (function) {
    
  case DF_MATH_FABS :
    while (n--) {
      float x;
      
      x = *vector;
      *vector++ = AM_FABS(x);
    }
    break;
    
  case DF_MATH_SQUARE :
    while (n--) {
      float x;
      
      x = *vector;
      *vector++ = x *x;
    }
    break;
    
  case DF_MATH_LOG10 :
    while (n--) {
      float x;
      
      x = *vector;
      *vector++ = AM_LOG10(x);
    }
    break;
    
  case DF_MATH_PSEUDO_LOG10 :
    while (n--) {
      float x;
      
      x = *vector + 1.0;
      *vector++ = AM_LOG10(x);
    }
    break;
    
  }/* end switch */
  
}/* end math_data */

/*****************************************************/
/* submean_data                                      */
/*****************************************************/
static void submean_data(float *vector, int n)
{
  int counter=n;
  float mean=0.0, *ptr=vector;
  
  /* calc mean */
  while(counter--) mean += *ptr++;
  mean /= n;
  
  /* submean */
  counter = n;
  while(counter--)  *vector++ -= mean;
  
}/* end submean_data */



/*****************************************************/
/* normalize_data                                    */
/*****************************************************/
static void normalize_data(float *vector, int n)
{
  int counter=n;
  float power2=0.0, *ptr=vector;
  
  
  /* submean */
  submean_data(vector,n);
  
  /* calc power */
  counter = n;
  ptr = vector;
  while(counter--) {
    power2 += *ptr * *ptr;
    ptr++;
  }
  
  /* normalize power2 */
  if (power2 == 0.0) return;
  power2 = 1.0 / AM_SQRT( power2 );
  while(n--) *vector++ *= power2;
}/* end normalize_data */


/* _preprocess_df: Do all user specified preprocessing (from .df file) */
void _preprocess_df( DATAFILEPTR datafile )
{
  int npatterns;

  if ( datafile->usefile ) return ;

  if ( datafile->cache_size )
    npatterns = datafile->cache_size;
  else
    npatterns = datafile->npatterns;

  /******************************************/  
  /* swapbytes                              */
  /******************************************/  
  if (datafile->swapbytes) {
    int n = npatterns;
    int size = datafile->size; /* size of a data pattern */
    
    while (n--) {
      swapbytes_data(*(datafile->inputs + n), size);
    }/* end swap inputs */
    
    /* swap targets */
    switch (datafile->type) {
    case TYPE2_FILE :
      /* size of a target pattern */
      size = df->targets_xdim * df->targets_ydim;
      swapbytes_data(*(datafile->targets), size);
      break;
      
    case TYPE3_FILE :
    case TYPE4_FILE : 
    case TYPE5_FILE : 
      n = npatterns;
      /* size of a target pattern */
      size = df->targets_xdim * df->targets_ydim;
      
      while (n--) {
	swapbytes_data(*(datafile->targets + n), size);
      }/* end swap inputs */
      break;
      
    }/* end switch */
    
  }/* end if swapbytes */
  /******************************************/  
  
  /******************************************/  
  /* math                                   */
  /******************************************/  
  if (datafile->math != DF_MATH_NONE) {
    int n = npatterns;
    int size = datafile->size; /* size of a data pattern */
    
    while (n--) math_data(datafile->math, *(datafile->inputs + n), size);
  }/* end if math */
  /******************************************/ 
  
  /******************************************/  
  /* lowclip                                */
  /******************************************/  
  if (datafile->lowclip != -AM_HUGE_VAL) {
    int n = npatterns;
    int size = datafile->size; /* size of a data pattern */
    
    while (n--) lowclip_data(*(datafile->inputs + n), datafile->lowclip, size);
  }/* end if lowclip  */
  /******************************************/  

  /******************************************/  
  /* highclip                                */
  /******************************************/  
  if (datafile->highclip != AM_HUGE_VAL) {
    int n = npatterns;
    int size = datafile->size; /* size of a data pattern */
    
    while (n--) highclip_data(*(datafile->inputs + n), datafile->highclip, size);
  }/* end if highclip  */
  /******************************************/  
  
  /******************************************/  
  /* submean                                */
  /******************************************/  
  if (datafile->submean) {
    int n = npatterns;
    int size = datafile->size; /* size of a data pattern */
    
    while (n--) submean_data(*(datafile->inputs + n), size);
  }/* end if submean */
  /******************************************/  
  
  
  /******************************************/  
  /* normalize                              */
  /******************************************/  
  if (datafile->normalize) {
    int n = npatterns;
    int size = datafile->size; /* size of a data pattern */
    
    while (n--) normalize_data(*(datafile->inputs + n), size);
  }/* end if normalize */
  /******************************************/  
  
  
  /******************************************/  
  /* rescale                                */
  /******************************************/  
  {
    int n = npatterns;
    int size = datafile->size; /* size of a data pattern */
    float range_threshold = datafile->range_threshold;
    float range = datafile->range;
    float scalar = datafile->scalar;
    float bias = datafile->bias;
    
    
    if (range > 0.0 || bias != 0.0 || scalar != 1.0) /* leave alone? */
      while (n--) rescale_data(*(datafile->inputs + n),
			       range_threshold, range, scalar, bias, size);
    
  }/* end block */
  /******************************************/  
  
} /* end _preprocess_df */
