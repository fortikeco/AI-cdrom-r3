/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
/* data structures etc. for Aspirin/MIGRAINES data files */

#include "aspirin_bp.h"

typedef struct functions {
  void (*set_input)(float *inputs);            /* bb function to set inputs */
  void (*set_target_output)(float *targets);    /* bb function to set targets */
  struct functions *next;     /* list */
}FUNCTIONS, *FUNCTIONSPTR;


typedef struct datafile {

  char *filename;             /* pathname */

  int type;                   /* format */

  int usefile;                /* not zero if this is from UseFile-> */

  int xdim;                   /* xdim size */
  int ydim;                   /* ydim size */
  int size;                   /* xdim * ydim */

  int cache_size;             /* number of input/target patterns in cache (zero if no cache) */
  int input_fd;               /* open file (if caching) */
  int target_fd;              /* open file (if caching) */


  void (*next_pattern)(struct datafile *x);         /* function to get the next pattern */

                              /* preprocessing... */
  float range;                /* max - min */
  float range_threshold;      /* if (max < range_threshold) max = range_threshold (optional) */
  float bias;                 /* (max - min)/2 */
  float scalar;               /* scalar * data when read */
  int normalize;              /* 1 if to normalize data */
  int submean;                /* 1 if to submean data */
  float lowclip,highclip;     /* used to clip data */
  int math;                   /* set to function to do on data points */
  int swapbytes;              /* 1 if swapbytes on read */

  int clear_delays;           /* TRUE if clear delay buffers before using */

  int current_pattern;        /* index of pattern now */

  int switch_cycle;           /* how often to switch files */
  int switch_counter;         /* index of current pattern in cycle */
  
  int npatterns;              /* number of patterns */
  
  union {
    char *target_file;          /* name of the target file */
    float *user_target;         /* ptr to user supplied target vector */
    int self;                   /* 1 if using input as target vector */
  } target;
  
  char *user_label;           /* label for this data from user */

  float **inputs;             /* ptr to array of ptrs to patterns */
  float **targets;            /* ptr to array of ptrs to patterns */

  struct datafile *next;      /* list */

}DATAFILE, *DATAFILEPTR;

typedef struct df {

  int inputs_xdim;             /* x dimension */
  int inputs_ydim;             /* y dimension */
  int inputs_size;             /* x * y dimension */
  int targets_xdim;            /* x dimension */
  int targets_ydim;            /* y dimension */
  int targets_size;            /* x * y dimension */

  int n_datafiles;             /* the number of datafiles */

  DATAFILEPTR current_datafile;/* current datafile */

  FUNCTIONSPTR setfunctions;   /* list of pointers to bb functions */
  DATAFILEPTR  datafiles;      /* data of data from files */
  DATAFILEPTR *datafile_table; /* table of data files */
  void (*next_datafile)(void);   /* function to get the next data file */
  
  /* function that corrupts input with noise */
  float *(*noise)(float *from_ptr, float *to_ptr, float mean, float variance, int n);
  float mean, variance;        /* for noise */
  float *input_buffer;         /* holds corrupted/scrolled input */

}DF, *DFPTR;


/* datafile types */
#define ASCII_FILE 0 
#define TYPE1_FILE 1
#define TYPE2_FILE 2
#define TYPE3_FILE 3
#define TYPE4_FILE 4
#define TYPE5_FILE 5
#define MATLAB_FILE 6

#define MAX_USER_GENERATORS 20

typedef struct user_generator {
  void (*generator)(char *item);
  char *item;
  char *string;
}USER_GENERATOR;

/* types of noise to add to signal */
#define NO_NOISE 0
#define NORMAL_NOISE 1
#define UNIFORM_NOISE 2

/* math functions */
#define DF_MATH_NONE 0
#define DF_MATH_FABS 1
#define DF_MATH_LOG10 3
#define DF_MATH_PSEUDO_LOG10 4
#define DF_MATH_SQUARE 5



