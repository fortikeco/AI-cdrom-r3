/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
/* this is a hack but it works..oh well */

#include "BpDatafile.h"

static FILE *stream;
static int floats_read;

/* ascii file reader : Ascii format files are files of patterns of ascii floating point
                       numbers. The format is:
		         <input pattern-1: list of ascii floats, length equal to input size>
		         <target pattern-1: list of ascii floats, length equal to target size>
		         <input pattern-2: list of ascii floats, length equal to input size>
		         <target pattern-2: list of ascii floats, length equal to target size>
			                         .
						 .
						 .
		      	 <input pattern-N: list of ascii floats, length equal to input size>
		         <target pattern-N: list of ascii floats, length equal to target size>

			C style comments are allowed as well as cpp macros.
*/

static void next_pattern(DATAFILEPTR datafile) 
{
  datafile->current_pattern = (datafile->current_pattern + 1) % datafile->npatterns;
  datafile->switch_counter = datafile->current_pattern + 1;
}

static float read_float()
{
  float result;
  
  if (floats_read > 0) { /* d'nat doo nufin' if eof */
    
    floats_read = fscanf(stream, "%f", &result);
    return(result);
    
  } else 
    return(0.0);

}/* end read_float */



static void read_pattern(int n, float *data_ptr)
{
  int i;
  
  if (data_ptr == (float *) NULL) {/* scanning file */

    read_float();
    if ( feof(stream) ) return; /* eof */
    for (i=1; i<n; i++) {
      read_float();
      if (floats_read != 1) {
	fprintf(stderr,"\nError: ascii_reader - non ascii number in file!\n");
	am_exit( EXIT_FAILURE );
      }/* end if */
    }/* end for */

  } else { /* reading file */

    for (i=0; i<n; i++) *(data_ptr++) = read_float();

  }/* end if else */

}/* end read_pattern */

void _ascii_reader(
		   int file_descriptor,                /* open file (not used) */
		   DATAFILEPTR datafile,               /* this file */
		   DFPTR df                            /* root structure */
		   )
{
  int input_size = (df->inputs_xdim * df->inputs_ydim);
  int target_size = (df->targets_xdim * df->targets_ydim);
  char *cpp_file;
  int N_Patterns, i;

  /* no cache */
  if ( datafile->cache_size ) {
    fprintf(stderr,"\nSorry, you cannot use Cache-> with Ascii file type!\n");
    return;
  }

  /* run cpp on file to remove comments and macros */
  cpp_file = am_cpp(datafile->filename,1);

  /* open the preprocesessed file */
  stream = fopen(cpp_file, "r");
  if (stream == (FILE *)NULL) {
    fprintf(stderr,"\nUnable to open %s.\n", cpp_file);
    am_perror("ascii_reader.c");
    am_exit( EXIT_FAILURE );
  }/* end if */

  /* count input/output pairs */
  floats_read = 1;
  N_Patterns = -1; /* last pattern read is eof */
  while (floats_read > 0) {
    read_pattern(input_size + target_size, (float *)NULL);
    N_Patterns++;
  }/* end while */

  if (! N_Patterns ){ /* error check */
    fprintf(stderr,"\n%s has 0 patterns!\n",
	    datafile->filename);
    return;
  }/* end if */


  /* update the structure */
  datafile->next_pattern = *next_pattern;
  datafile->npatterns = N_Patterns;
  datafile->inputs = (float **)am_alloc_mem((unsigned)(N_Patterns * sizeof(float *)));
  datafile->targets = (float **)am_alloc_mem((unsigned)(N_Patterns * sizeof(float *)));
  datafile->size = input_size;
  datafile->xdim = df->inputs_xdim;
  datafile->ydim = df->inputs_ydim;
  if (datafile->switch_cycle < 0) datafile->switch_cycle = N_Patterns; /* (switch: all) */

  for (i=0; i<N_Patterns; i++) {
    datafile->inputs[i] = (float *)am_alloc_mem((unsigned)(input_size * sizeof(float)));
    datafile->targets[i] = (float *)am_alloc_mem((unsigned)(target_size * sizeof(float)));
  }/* end for */

  /* back to the beginning...to read the data */
  (void)fclose(stream);
  floats_read = 1;

  /* open the preprocesessed file */
  stream = fopen(cpp_file, "r");
  if (stream == (FILE *)NULL) {
    am_perror("ascii_reader.c: ");
    am_exit( EXIT_FAILURE );
  }/* end if */

  for(i=0;i<N_Patterns;i++) {
    read_pattern(input_size, datafile->inputs[i]);
    read_pattern(target_size, datafile->targets[i]);
  }/* end while */

  /* done */
  (void)fclose(stream);

  /* remove the cpp file */
  am_remove_cpp_file(cpp_file);

}  /* end _ascii_reader */

