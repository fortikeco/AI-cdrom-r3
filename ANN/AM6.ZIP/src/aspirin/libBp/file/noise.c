/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "BpDatafile.h"
  
/*
 *   NormalRandom()    --  Uses the Box-Jenkins technique
 */
static int NRswitch = 0;
static double NR_u1, NR_u2;
static float NormalRandom(float mean, float variance)
{
  if (NRswitch == 0) {
    while((NR_u1 = AM_RANDOM()) == 0.0);
    while((NR_u2 = AM_RANDOM()) == 0.0);
    NRswitch = 1;
    return( mean + AM_SQRT( (-2.0 * AM_LOG(NR_u1) * variance) ) * AM_COS( (2.0 * AM_PI * NR_u2) ) );
  } else {
    NRswitch = 0;
    return( mean + AM_SQRT( (-2.0 * AM_LOG(NR_u1) * variance) ) * AM_SIN( (2.0 * AM_PI * NR_u2) ) );
  }
}  /* end NormalRandom() */

static float UniformRandom(float mean, float variance)
{
  return(mean + (variance * 2.0  * (AM_RANDOM() - 0.5)));
}  /* UniformRandom() */


float *_add_uniform_noise(float *from_ptr, float *to_ptr, float mean, float variance, int n)
{
  float *ptr = to_ptr;
  
  bcopy((char *)(from_ptr), (char *)to_ptr, n * sizeof(float));
  while(n--) *ptr++ += UniformRandom(mean,variance);
  
  return(to_ptr);
}/* end _add_uniform_noise */

float *_add_normal_noise(float *from_ptr, float *to_ptr, float mean, float variance, int n)
{
  float *ptr = to_ptr;
  
  bcopy((char *)(from_ptr), (char *)to_ptr, n * sizeof(float));
  while(n--) *ptr++ +=  NormalRandom(mean,variance);
  
  return(to_ptr);
}/* end _add_normal_noise */


float *_no_noise(float *from_ptr, float *to_ptr, float mean, float variance, int n)
{
  return(from_ptr);   /* noop */
}/* end _no_noise */
