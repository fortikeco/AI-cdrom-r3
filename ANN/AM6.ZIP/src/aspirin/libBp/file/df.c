
/*  A Bison parser, made from df.y  */

#define YYBISON 1  /* Identify Bison output.  */

#define	NEWLINE	258
#define	NUMBER	259
#define	NAME	260
#define	LCP	261
#define	RCP	262
#define	RP	263
#define	LP	264
#define	READFILE	265
#define	USEFILE	266
#define	RANDOM_SWITCH	267
#define	ASCII	268
#define	MATLAB	269
#define	TYPE1	270
#define	TYPE2	271
#define	TYPE3	272
#define	TYPE4	273
#define	TYPE5	274
#define	CACHE	275
#define	LABEL	276
#define	TARGET	277
#define	SELF	278
#define	SWITCH	279
#define	RANGE	280
#define	NORMALIZE	281
#define	LOWCLIP	282
#define	HIGHCLIP	283
#define	SUBMEAN	284
#define	SCALE	285
#define	BIAS	286
#define	CLEAR_DELAYS	287
#define	SWAPBYTES	288
#define	MATH	289
#define	MATH_FUNCTION	290


#line 40 "df.y"
typedef union {
	int i;    /* integer */
	float f;  /* float */
	char *s;  /* string */
} YYSTYPE;
#line 47 "df.y"

#include "BpDatafile.h"
#include "globals.h"

 /* initialize files */
extern DFPTR _file_init(LB_PTR (*query_function)(), int noise_type, float mean, float variance);

/* read in a datafile */
extern void  _readfile(DATAFILEPTR datafile, DFPTR df) ;

#define TRUE 1
#define FALSE 0

/* input stream */
static FILE *df_stream;

/* input buffer */
static char yytext[256];
static int yyleng;

DFPTR df = NULL; /* root */

static int error_code = 0;

#define TARGET_LENGTH 50


/* globals */
static int cache_size = 0;      /* number of patterns to cache */
static char *user_label = NULL; /* user supplied label */  
static int target_length = 0;   /* length of user's target vector */
static float target_vector[TARGET_LENGTH];
static int self = FALSE; /* if target is same as data */
static char *target_file = NULL; /* name of target file (type5) */
static int switch_cycle = 1; /* when to switch between files (after how many patterns) */
static float range_threshold, range = -1.0, bias = 0.0, scalar=1.0; /* for rescaling data */
static int normalize = 0; /* for normalizing data */
static int submean = 0; /* for normalizing data */
static float lowclip, highclip; /* for preprocessing data */
static int clear_delays = FALSE; /* TRUE if clear delay buffers before using */
static int random_switch = FALSE;
static int swapbytes= FALSE; /* in case the data is from a machine w/opposite byte order */
static int math=DF_MATH_NONE;       /* for doing math on data points */

/* used for error messages */
int lineno = 1; 
static char *datafile_name;



int yywrap() { return(1); } /* noop */

/*****************************************************/
/* warning                                           */
/*        Print warning message.                     */
/*****************************************************/
static void warning(char *s, char *t)
{
  fprintf(stderr, "\n%s: %s", datafile_name, s);
  if (t != (char *)NULL) fprintf(stderr, "  %s", t);
}

/*****************************************************/
/* yyerror                                           */
/*        Called by yacc for syntax errors.          */
/*****************************************************/
int yyerror (char *s)
{
  char where[256];

  *where = '\0'; /* empty */
  if (yytext != NULL)
    {  char *token = am_alloc_mem(yyleng + 1);

       bcopy(yytext, token, yyleng);
       token[yyleng] = '\0'; /* end of string */
       sprintf(where, "(near \"%s\" somewhere around line %d)\n", yytext, lineno);
       am_free_mem(token);
    }/* end if */

  warning(s, where);
  error_code = 1;

  return(error_code);
}/* end yyerror */  

/*****************************************************/
/*****************************************************/
/*****************************************************/
/*******************    lex    ***********************/



char *newstr (char *name, int length)
{
 char *temp;

 temp = am_alloc_mem(length + 1);
 *(temp + length) = 0;
 bcopy(name, temp, length+1);
 return(temp);
}

static void read_token()
{
  unsigned int c;


  yyleng=0;
  /* skip spaces, tabs , quotes, and newlines  */
  while((c=getc(df_stream)) != ' '
	&& !(iscntrl(c))
	&& c != '"'
	&& c != '{'
	&& c != '}'
	&& c != '('
	&& c != ')'
	&& c != '#'
	&& c != ','
	&& c != EOF) {
    yytext[yyleng++] = c;
  }
  ungetc((unsigned char)c,df_stream);
  yytext[yyleng] = '\0';
}

static void read_quoted_token()
{
  unsigned int c;


  yyleng=0;
  /* end at quote */
  while((c=getc(df_stream)) != '"' && c != EOF) {
    yytext[yyleng++] = c;
  }
  yytext[yyleng] = '\0';
}

static int input_equals(char *str)
{
  register int counter;
  register char *tptr = yytext;

  counter = yyleng;
  if (strlen(str) > counter) counter = strlen(str);
  while(counter--) if (*str++ != *tptr++) return FALSE;;
  return TRUE;

}

#define CONTEXT_STACK_DEPTH 16
#define NO_CONTEXT 0
#define READFILE_CONTEXT 1
#define USEFILE_CONTEXT 2
#define KEYWORD_CONTEXT 3
#define MATH_CONTEXT 4
static int context_stack[CONTEXT_STACK_DEPTH], *cstackptr = context_stack;

#define switch_lex_context(ctx) *cstackptr = ctx;

static void push_lex_context(int new_context)
{
  if (cstackptr == context_stack + CONTEXT_STACK_DEPTH)
    yyerror("\nLex context stack full! (push_lex_context)\n");
  cstackptr++; *cstackptr = new_context;
}

static void pop_lex_context()
{
  if (cstackptr == context_stack)
    yyerror("\nLex context stack would be empty! (pop_lex_context)\n");
  /* pop */
  cstackptr--;
}

static int this_context(int context)
{
  return( *cstackptr == context );
}




/*****************************************************/
/*****************************************************/
/*****************************************************/


/*****************************************************/
/* update_target_vector: Add numbers to target vector. */
/*****************************************************/
static void update_target_vector(float x)
{
  if (target_length == TARGET_LENGTH) yyerror("\nTarget vector too long!");
  target_vector[target_length++] = x;
}/* end update_target_vector */


/*****************************************************/
/* create_datafile: create datafile structure.       */
/*****************************************************/
static void create_datafile(char *filename, int type)
{
  DATAFILEPTR new_datafile;

  /* make new structure */
  new_datafile = (DATAFILEPTR)am_alloc_mem(sizeof(DATAFILE));
  new_datafile->filename = filename;

  new_datafile->type = type;

  new_datafile->usefile = FALSE;

  new_datafile->next = (DATAFILEPTR)NULL;

  new_datafile->size = df->inputs_size;
  new_datafile->xdim = df->inputs_xdim;
  new_datafile->ydim = df->inputs_ydim;

  new_datafile->current_pattern = -1;

  new_datafile->switch_counter = 1;

  new_datafile->switch_cycle = switch_cycle;
  switch_cycle = 1; /* reset */


  new_datafile->range = range;
  range = -1.0; /* reset */
  new_datafile->range_threshold = range_threshold;
  range_threshold = -AM_HUGE_VAL; /* reset */
  new_datafile->bias = bias;
  bias = 0.0; /* reset */
  new_datafile->scalar = scalar;
  scalar = 1.0; /* reset */
  new_datafile->normalize = normalize;
  normalize = 0; /* reset */
  new_datafile->lowclip = lowclip;
  lowclip = -AM_HUGE_VAL; /* reset */
  new_datafile->highclip = highclip;
  highclip = AM_HUGE_VAL; /* reset */
  new_datafile->submean = submean;
  submean = 0; /* reset */
  new_datafile->math= math;
  math = 0; /* reset */
  new_datafile->swapbytes= swapbytes;
  swapbytes = 0; /* reset */

  new_datafile->clear_delays = clear_delays;
  clear_delays = FALSE; /* reset */

  new_datafile->cache_size = cache_size;
  cache_size = 0; /* reset */

  new_datafile->user_label = user_label;
  user_label = (char *)NULL; /* reset */
  
  /* Target-> in .df */
  if (target_length) {

    new_datafile->target.user_target = (float *)am_alloc_mem(target_length * sizeof(float));
    /* copy */
    bcopy((char *)target_vector,
	  (char *)new_datafile->target.user_target,
	  (target_length * sizeof(float)));
    /* reset */
    target_length = 0;

  } else if ( self ) { /* use inputs as targets? */
    
    new_datafile->target.self = 1; self = FALSE;   
    
  } else if (target_file != NULL) {  /* set the target file (type5) */

    new_datafile->target.target_file = target_file; target_file = NULL;

  }/* end else if */

  new_datafile->inputs = (float **)NULL;
  new_datafile->targets = (float **)NULL;

  /* push into list */
  df->n_datafiles += 1;
  if (df->datafiles == (DATAFILEPTR)NULL) {
    df->datafiles = new_datafile;    
    new_datafile->next = (DATAFILEPTR)NULL;
  } else {
    DATAFILEPTR temp;
    temp = df->datafiles;
    df->datafiles = new_datafile;
    new_datafile->next = temp;
  }/* end else */

}/* end create_datafile */

/*****************************************************/
/* find_datafile: Search and return named file     */
/*****************************************************/
DATAFILEPTR find_datafile(char *name)
{
  DATAFILEPTR ptr;

  ptr = df->datafiles;
  while(ptr != (DATAFILEPTR)NULL) {
    if (! ptr->usefile && ! strcmp(ptr->filename, name))
      return ptr;
    else
      ptr = ptr->next;
  }

  yyerror("Undefined file name for UseFile!");

  return ( NULL );

}/* end find_datafile */

/*****************************************************/
/* use_datafile:   Just reference a file             */
/*****************************************************/
static void use_datafile(char *name)
{
  DATAFILEPTR referenced_datafile, new_datafile;

  /* find name in list */
  referenced_datafile = find_datafile(name);

  /* make new structure */
  new_datafile = (DATAFILEPTR)am_alloc_mem(sizeof(DATAFILE));

  new_datafile->filename = name;

  /* mark so it won't be read */
  new_datafile->usefile = TRUE;

  /* push into list */
  df->n_datafiles += 1;
  {
    DATAFILEPTR temp;
    temp = df->datafiles;
    df->datafiles = new_datafile;
    new_datafile->next = temp;
  }/* end block */

}/* end use_datafile */

/*****************************************************/
/* next_datafile: Goto next datafile. */
/*****************************************************/
static void next_datafile()
{
    df->current_datafile = df->current_datafile->next;
}/* end next_datafile */

/*****************************************************/
/* random_datafile: random next datafile. */
/*****************************************************/
static void random_datafile()
{
    df->current_datafile = *(df->datafile_table +
			       ( (int) (AM_RANDOM() * df->n_datafiles) ));
}/* end next_datafile */



#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __STDC__
#define const
#endif



#define	YYFINAL		87
#define	YYFLAG		-32768
#define	YYNTBASE	36

#define YYTRANSLATE(x) ((unsigned)(x) <= 290 ? yytranslate[x] : 48)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     5,     7,     9,    16,    21,    23,    25,    27,
    29,    31,    33,    35,    37,    39,    42,    47,    52,    57,
    62,    67,    72,    78,    83,    88,    93,    97,   102,   107,
   111,   116,   120,   124,   125,   127,   130,   132,   135,   139,
   144,   149,   153,   156,   158,   160,   161
};

#endif

static const short yyrhs[] = {    37,
     0,    36,    37,     0,    38,     0,    43,     0,    10,     9,
     5,    39,    40,     8,     0,    11,     9,     5,     8,     0,
    12,     0,    13,     0,    14,     0,    15,     0,    16,     0,
    17,     0,    18,     0,    19,     0,    41,     0,    40,    41,
     0,     9,    21,     5,     8,     0,     9,    22,    42,     8,
     0,     9,    22,    23,     8,     0,     9,    22,     5,     8,
     0,     9,    20,    47,     8,     0,     9,    24,    46,     8,
     0,     9,    25,    45,    45,     8,     0,     9,    25,    45,
     8,     0,     9,    31,    45,     8,     0,     9,    30,    45,
     8,     0,     9,    26,     8,     0,     9,    27,    45,     8,
     0,     9,    28,    45,     8,     0,     9,    33,     8,     0,
     9,    34,    35,     8,     0,     9,    29,     8,     0,     9,
    32,     8,     0,     0,    45,     0,    42,    45,     0,    44,
     0,    43,    44,     0,     3,    47,     5,     0,     3,    47,
     5,    47,     0,     3,     5,    47,     5,     0,     3,     5,
     5,     0,     3,    47,     0,     4,     0,    47,     0,     0,
     4,     0
};

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   473,   474,   478,   479,   483,   484,   485,   490,   491,   492,
   493,   494,   495,   496,   500,   501,   504,   505,   506,   507,
   508,   509,   510,   512,   513,   514,   515,   516,   517,   518,
   519,   520,   521,   522,   526,   527,   534,   535,   538,   541,
   545,   548,   550,   555,   558,   559,   562
};

static const char * const yytname[] = {   "$","error","$illegal.","NEWLINE",
"NUMBER","NAME","LCP","RCP","RP","LP","READFILE","USEFILE","RANDOM_SWITCH","ASCII",
"MATLAB","TYPE1","TYPE2","TYPE3","TYPE4","TYPE5","CACHE","LABEL","TARGET","SELF",
"SWITCH","RANGE","NORMALIZE","LOWCLIP","HIGHCLIP","SUBMEAN","SCALE","BIAS","CLEAR_DELAYS",
"SWAPBYTES","MATH","MATH_FUNCTION","datafile","datafile_exp","files","type",
"keys","key","vector","newlines","newline","real","optional_integer","integer",
""
};
#endif

static const short yyr1[] = {     0,
    36,    36,    37,    37,    38,    38,    38,    39,    39,    39,
    39,    39,    39,    39,    40,    40,    41,    41,    41,    41,
    41,    41,    41,    41,    41,    41,    41,    41,    41,    41,
    41,    41,    41,    41,    42,    42,    43,    43,    44,    44,
    44,    44,    44,    45,    46,    46,    47
};

static const short yyr2[] = {     0,
     1,     2,     1,     1,     6,     4,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     2,     4,     4,     4,     4,
     4,     4,     5,     4,     4,     4,     3,     4,     4,     3,
     4,     3,     3,     0,     1,     2,     1,     2,     3,     4,
     4,     3,     2,     1,     1,     0,     1
};

static const short yydefact[] = {     0,
     0,     0,     0,     7,     0,     1,     3,     4,    37,    47,
     0,    43,     0,     0,     2,    38,    42,     0,    39,     0,
     0,    41,    40,     8,     9,    10,    11,    12,    13,    14,
    34,     6,     0,     0,    15,     0,     0,     0,    46,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     5,
    16,     0,     0,    44,     0,     0,     0,    35,     0,    45,
     0,    27,     0,     0,    32,     0,     0,    33,    30,     0,
    21,    17,    20,    19,    18,    36,    22,    24,     0,    28,
    29,    26,    25,    31,    23,     0,     0
};

static const short yydefgoto[] = {     5,
     6,     7,    31,    34,    35,    57,     8,     9,    58,    59,
    12
};

static const short yypact[] = {    42,
    19,     0,     8,-32768,     2,-32768,-32768,    18,-32768,-32768,
    22,    28,    44,    45,-32768,-32768,-32768,    46,    51,    43,
    40,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
    54,-32768,    10,    38,-32768,    51,    59,     6,    51,    61,
    58,    61,    61,    60,    61,    61,    62,    63,    32,-32768,
-32768,    64,    65,-32768,    66,    67,    11,-32768,    68,-32768,
    12,-32768,    69,    70,-32768,    71,    72,-32768,-32768,    73,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    74,-32768,
-32768,-32768,-32768,-32768,-32768,    83,-32768
};

static const short yypgoto[] = {-32768,
    79,-32768,-32768,-32768,    35,-32768,-32768,    77,   -39,-32768,
   -11
};


#define	YYLAST		85


static const short yytable[] = {    18,
    61,    86,    63,    64,     1,    66,    67,    23,    13,    54,
    55,     2,     3,     4,    54,    54,    14,    76,    75,    78,
     1,    79,    10,    11,    52,    10,    17,    60,    56,    36,
    37,    38,    19,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,     1,    50,    33,    32,    20,    21,
    22,     2,     3,     4,    10,    24,    25,    26,    27,    28,
    29,    30,    33,    53,    54,    62,    70,    65,    51,    68,
    69,    71,    72,    73,    74,    77,    80,    81,    82,    83,
    84,    85,    87,    15,    16
};

static const short yycheck[] = {    11,
    40,     0,    42,    43,     3,    45,    46,    19,     9,     4,
     5,    10,    11,    12,     4,     4,     9,    57,     8,     8,
     3,    61,     4,     5,    36,     4,     5,    39,    23,    20,
    21,    22,     5,    24,    25,    26,    27,    28,    29,    30,
    31,    32,    33,    34,     3,     8,     9,     8,     5,     5,
     5,    10,    11,    12,     4,    13,    14,    15,    16,    17,
    18,    19,     9,     5,     4,     8,    35,     8,    34,     8,
     8,     8,     8,     8,     8,     8,     8,     8,     8,     8,
     8,     8,     0,     5,     8
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/local/gnu/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 169 "/usr/local/gnu/lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
#ifdef YYLSP_NEEDED
		 &yyls1, size * sizeof (*yylsp),
#endif
		 &yystacksize);

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symboles being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 5:
#line 483 "df.y"
{ create_datafile(yyvsp[-3].s, yyvsp[-2].i); ;
    break;}
case 6:
#line 484 "df.y"
{ use_datafile(yyvsp[-1].s); ;
    break;}
case 7:
#line 485 "df.y"
{ random_switch = TRUE; ;
    break;}
case 8:
#line 490 "df.y"
{ yyval.i = ASCII_FILE; ;
    break;}
case 9:
#line 491 "df.y"
{ yyval.i = MATLAB_FILE; ;
    break;}
case 10:
#line 492 "df.y"
{ yyval.i = TYPE1_FILE; ;
    break;}
case 11:
#line 493 "df.y"
{ yyval.i = TYPE2_FILE; ;
    break;}
case 12:
#line 494 "df.y"
{ yyval.i = TYPE3_FILE; ;
    break;}
case 13:
#line 495 "df.y"
{ yyval.i = TYPE4_FILE; ;
    break;}
case 14:
#line 496 "df.y"
{ yyval.i = TYPE5_FILE; ;
    break;}
case 17:
#line 504 "df.y"
{ user_label = yyvsp[-1].s; ;
    break;}
case 19:
#line 506 "df.y"
{ self = TRUE ; ;
    break;}
case 20:
#line 507 "df.y"
{ target_file = yyvsp[-1].s; ;
    break;}
case 21:
#line 508 "df.y"
{ if (yyvsp[-1].i < 1) yyerror("Cache size must be postive!"); cache_size = yyvsp[-1].i; ;
    break;}
case 22:
#line 509 "df.y"
{ switch_cycle = yyvsp[-1].i; ;
    break;}
case 23:
#line 510 "df.y"
{ if (yyvsp[-2].f <= 0.0) yyerror("Range must be postive!");
                                range = yyvsp[-2].f; range_threshold = yyvsp[-1].f; ;
    break;}
case 24:
#line 512 "df.y"
{ if (yyvsp[-1].f <= 0.0) yyerror("Range must be postive!"); range = yyvsp[-1].f; ;
    break;}
case 25:
#line 513 "df.y"
{ bias = yyvsp[-1].f; ;
    break;}
case 26:
#line 514 "df.y"
{ scalar = yyvsp[-1].f; ;
    break;}
case 27:
#line 515 "df.y"
{ normalize = 1; ;
    break;}
case 28:
#line 516 "df.y"
{ lowclip = yyvsp[-1].f; ;
    break;}
case 29:
#line 517 "df.y"
{ highclip = yyvsp[-1].f; ;
    break;}
case 30:
#line 518 "df.y"
{ swapbytes = 1; ;
    break;}
case 31:
#line 519 "df.y"
{ math = yyvsp[-1].i; ;
    break;}
case 32:
#line 520 "df.y"
{ submean = 1; ;
    break;}
case 33:
#line 521 "df.y"
{clear_delays = TRUE; ;
    break;}
case 35:
#line 526 "df.y"
{ update_target_vector(yyvsp[0].f); ;
    break;}
case 36:
#line 527 "df.y"
{ update_target_vector(yyvsp[0].f); ;
    break;}
case 39:
#line 538 "df.y"
{ lineno = yyvsp[-1].i;
 				datafile_name = yyvsp[0].s;
			      ;
    break;}
case 40:
#line 541 "df.y"
{ 
	                                   lineno = yyvsp[-2].i;
 				           datafile_name = yyvsp[-1].s;
			                 ;
    break;}
case 41:
#line 545 "df.y"
{ lineno = yyvsp[-1].i;
                                       datafile_name = yyvsp[0].s;
                                     ;
    break;}
case 42:
#line 548 "df.y"
{;
    break;}
case 43:
#line 550 "df.y"
{ lineno = yyvsp[0].i; ;
    break;}
case 44:
#line 555 "df.y"
{ yyval.f = yyvsp[0].f; ;
    break;}
case 45:
#line 558 "df.y"
{ yyval.i = yyvsp[0].i; ;
    break;}
case 46:
#line 559 "df.y"
{ yyval.i = 1; /* default */;
    break;}
case 47:
#line 562 "df.y"
{yyval.i = (int)yyvsp[0].f; ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 440 "/usr/local/gnu/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 564 "df.y"

  

int yylex()
{
  unsigned int c;

  more :


  /* skip spaces and tabs */
  while((c=getc(df_stream)) == ' ' || c == '\t') ;

  if (c == '\n') {  ++lineno; goto more ; }

  if (iscntrl(c)) goto more ;
  
  if (c == EOF) return 0;

  if (c == '#') return(NEWLINE);

  if (c == '"') { /* quoted string */
    read_quoted_token();
    yylval.s = newstr(yytext, yyleng);
    return(NAME);
  }

  if (c == '(') {
    if (this_context(KEYWORD_CONTEXT))
      push_lex_context(KEYWORD_CONTEXT);
    return(LP);
  }/* end if */

  if (c == ')') {
    pop_lex_context();
    return(RP);
  }/* end if */


  /* ok, done with the single character stuff */
  ungetc((unsigned char)c, df_stream);
  read_token();

  if (isdigit((unsigned int)yytext[0]) ||
      (yyleng > 1 &&
       (yytext[0] == '-' || yytext[0] == '+' || yytext[0] == '.') &&
       isdigit((unsigned int)yytext[1])) ||
      (yyleng > 2 &&
       (yytext[0] == '-' || yytext[0] == '+') &&
       yytext[1] == '.' &&
       isdigit((unsigned int)yytext[2]))) { /* number */
    sscanf((char *)yytext, "%f", &(yylval.f)); 
    return(NUMBER);
  }/* end if number */ 

  if (this_context(NO_CONTEXT)) { /* global context */
    if (input_equals("RandomSwitch")) return(RANDOM_SWITCH);
  }

  if (this_context(NO_CONTEXT)) { /* global context */
    if (input_equals("UseFile")) {
      push_lex_context(USEFILE_CONTEXT);
      return(USEFILE);
    }
  }

  if (this_context(NO_CONTEXT)) { /* global context */
    if (input_equals("ReadFile")) {
      push_lex_context(READFILE_CONTEXT);
      return(READFILE);
    }
  }

  if (this_context(READFILE_CONTEXT)) {

    /* types */
    
    if (input_equals("Ascii")) {
      switch_lex_context(KEYWORD_CONTEXT);
      return(ASCII);
    }
    
    if (input_equals("Matlab")) {
      switch_lex_context(KEYWORD_CONTEXT);
      return(MATLAB);
    }
    
    if (input_equals("Type1")) {
      switch_lex_context(KEYWORD_CONTEXT);
      return(TYPE1);
    }

    if (input_equals("Type2")) {
      switch_lex_context(KEYWORD_CONTEXT);
      return(TYPE2);
    }

    if (input_equals("Type3")) {
      switch_lex_context(KEYWORD_CONTEXT);
      return(TYPE3);
    }

    if (input_equals("Type4")) {
      switch_lex_context(KEYWORD_CONTEXT);
      return(TYPE4);
    }

    if (input_equals("Type5")) {
      switch_lex_context(KEYWORD_CONTEXT);
      return(TYPE5);
    }
    
  }

  if (this_context(KEYWORD_CONTEXT)) {

    if (input_equals("Math->")) {
      push_lex_context(MATH_CONTEXT);
      return(MATH);
    }

    if (input_equals("ClearDelays->")) return(CLEAR_DELAYS);

    if (input_equals("SubMean->")) return(SUBMEAN);

    if (input_equals("Normalize->")) return(NORMALIZE);

    if (input_equals("LowClip->")) return(LOWCLIP);

    if (input_equals("HighClip->")) return(HIGHCLIP);

    if (input_equals("Scale->")) return(SCALE);

    if (input_equals("Bias->")) return(BIAS);

    if (input_equals("Range->")) return(RANGE);

    if (input_equals("SwapBytes->")) return(SWAPBYTES);

    if (input_equals("Switch->")) return(SWITCH);

    if (input_equals("Target->")) return(TARGET);

    if (input_equals("Label->")) return(LABEL);

    if (input_equals("Cache->")) return(CACHE);

    if (input_equals("All")) { yylval.f = -1.0 ; return(NUMBER); }

    if (input_equals("Self")) return(SELF);

  }

  if (this_context(MATH_CONTEXT)) {

    if (input_equals("abs[x]"))  yylval.i = DF_MATH_FABS;
    
    else if (input_equals("square[x]"))  yylval.i = DF_MATH_SQUARE;

    else if (input_equals("log10[x]"))  yylval.i = DF_MATH_LOG10;

    else if (input_equals("log10[x+1]"))  yylval.i = DF_MATH_PSEUDO_LOG10;

    else fprintf(stderr, "\nMath->: Unknown function!\n");

    pop_lex_context();

    return(MATH_FUNCTION);
  }


  /* names */
  {
    yylval.s = newstr(yytext, yyleng);
    return(NAME);
  }  

}/* end yylex */


int _read_df (char *file)
{
  char *cpp_file;

  /******************************************/
  /* some basic init */
  lowclip = -AM_HUGE_VAL;
  highclip = AM_HUGE_VAL;
  range_threshold = -AM_HUGE_VAL;
  datafile_name = file;
  
  /******************************************/
  /* run cpp on datafile */
  cpp_file = am_cpp(file,0);

  /******************************************/
  /* open  input from cpp */
  df_stream = am_fopen(cpp_file, "r");
  /* return on error */
  if (df_stream == NULL)  {
    fprintf(stderr, "\nUnable to open %s", cpp_file);
    am_perror("Reading .df file");
    return(1);
  }

  /******************************************/
  
  /******************************************/
  /* parse storing info in global variables */
  yyparse();
  if (error_code) return(error_code);
  /******************************************/

  /******************************************/
  /* close the stream */
  am_fclose(df_stream);
  /******************************************/

  /******************************************/
  /* read in the data                       */
  /******************************************/
  {
    DATAFILEPTR files = df->datafiles;

    if (files == (DATAFILEPTR)NULL) {
      fprintf(stderr, "\nNo data files!\n");
      return(1);
    }
    
    /* loop through each structure...read */
    while(files != (DATAFILEPTR)NULL) {
      if (!files->usefile) _readfile(files, df);
      files = files->next;
    }/* end while */

    
    /* set the first one */
    df->current_datafile = df->datafiles;

  }/* end block */
  
  /******************************************/
  /* Reference files w/UseFile              */
  /******************************************/
  {
    DATAFILEPTR files = df->datafiles;

    /* loop through each structure...reference (from UseFile) */
    while(files != (DATAFILEPTR)NULL) {

      if (files->usefile) { /* just a reference, don't read */
	DATAFILEPTR tmp_next = files->next; /* hold on */

	/* copy contents */
	*files = *(find_datafile(files->filename));

	/* fix list */
	files->next = tmp_next;
	files->usefile = TRUE;

      }/* end if */

      files = files->next;
    }/* end while */

  }/* end block */

  /******************************************/  
  /* preprocess                             */
  /******************************************/  
  {
    extern void _preprocess_df(DATAFILEPTR datafile); /* from preprocess.c */
    DATAFILEPTR files = df->datafiles;
    /* loop through each structure... */
    while(files != (DATAFILEPTR)NULL) {

      _preprocess_df(files);
      files = files->next;
    }/* end while */
  }/* end block */
  /******************************************/  

  /******************************************/
  /* setup for the next_file function       */
  /******************************************/
  {
    /* set the next file function */
    if (random_switch) { /* random */
      DATAFILEPTR files = df->datafiles, *file_ptr;
      
      df->datafile_table = (DATAFILEPTR *)am_alloc_mem(df->n_datafiles * sizeof(DATAFILEPTR));
      file_ptr = df->datafile_table;
      
      /* loop through each structure...set into table */
      while(files != (DATAFILEPTR)NULL) {
	*file_ptr++ = files;
	files = files->next;
      }/* end while */
      
      df->next_datafile = random_datafile;
      
    } else { /* cyclic */
      
      /* set function */
      df->next_datafile = next_datafile;
      
    }/* end else */
    
  }/* end block */



  /******************************************/
  /* make circular list                     */
  /******************************************/
  {
    DATAFILEPTR files = df->datafiles, last_file=df->datafiles;

    /* loop through each structure...find the end */
    while(files != (DATAFILEPTR)NULL) {
      last_file = files;
      files = files->next;
    }/* end while */
    
    /* make circular list */
    if (df->datafiles != (DATAFILEPTR)NULL) 
      last_file->next = df->datafiles;
    
  }/* end block */
  
  /******************************************/
  /* remove cpp file */
  am_remove_cpp_file(cpp_file);
  /******************************************/

  return(error_code);
}




/*****************************************************/
/* loaddata:       file = datafile specification from
                   which datafiles are read.
		   query_function = function
		   to interogate the network.
		   noise_type = type of noise to
		   corrupt input (if any)
		   mean = mean of noise distribution.
		   variance = variance of noise distribution.
 */
/*****************************************************/
int loaddata(char *file, LB_PTR (*query_function)(), int noise_type, float mean, float variance)
{
  
  /******************************************/
  /* make the root */
  df = _file_init(query_function, noise_type, mean, variance);

  /******************************************/
  /* read the .df */
  return( _read_df(file) );
  /******************************************/
}
