/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
/* type2 file reader: Type2 files are floating point files of data patterns.
                      The first piece of data is the target vector for
		      the file. The rest of the data are patterns
                      one after another. It is assumed that the size and
		      dimensions of these patterns correspond to the size
		      and dimensions of the input to ALL black boxes.
 */

#include "BpDatafile.h"
#include "globals.h"

static void next_pattern(DATAFILEPTR datafile) 
{
  datafile->current_pattern = (datafile->current_pattern + 1) % datafile->npatterns;
  datafile->switch_counter = datafile->current_pattern + 1;
}

static void next_pattern_cache(DATAFILEPTR datafile) 
{
  datafile->current_pattern = (datafile->current_pattern + 1) % datafile->cache_size;
  datafile->switch_counter = (datafile->switch_counter + 1) % datafile->npatterns;

  if (! datafile->current_pattern ) { /* reset, end of cache buffer */
    extern void _preprocess_df(); /* from preprocess.c */

    
    /* read in more data */
    {
      int cache_size = datafile->size * datafile->cache_size * sizeof(float); /* in bytes */
      int nbytes;

      /* try to fill buffer */
      nbytes = am_read(datafile->input_fd,
		       (char *)(*datafile->inputs),
		       cache_size);

      /* eof condition */
      if ( nbytes != cache_size ) {
	int the_rest = cache_size - nbytes;

	/* move file pointer back to start of file, skip target vector */
	lseek(datafile->input_fd, df->targets_size * sizeof(float), 0);

	/* read the rest */
	am_read(datafile->input_fd,
		((char *)(*datafile->inputs)) + nbytes,
		the_rest);

      }/* end if eof */

    }


    /* preprocess the data */
    _preprocess_df(datafile);

  }/* end if */
}

void _type2_reader(
		   int file_descriptor,                 /* open file */
		   DATAFILEPTR datafile,                /* this file */
		   DFPTR df                             /* root structure */
		   )
{
  int counter, file_nfloats, file_nbytes, npatterns;
  int input_size = df->inputs_size;
  int target_size = df->targets_size;
  float *data_block, *target;

  /* get size of the file */
  file_nbytes = am_file_size(datafile->filename);
  file_nfloats = ((int)file_nbytes)/sizeof(float);  /* # floats in file */

  /* derive the number of patterns */
  file_nfloats -= target_size; /* minus the target vector */
  if (file_nfloats % input_size != 0) { /* error check */
    fprintf(stderr,"\n%s has NON integral number of patterns!\n",
	    datafile->filename);
      am_exit( EXIT_FAILURE );
  }/* end if */
  npatterns = file_nfloats/ input_size;
  if (! npatterns ){ /* error check */
    fprintf(stderr,"\n%s has 0 patterns!\n",
	    datafile->filename);
      am_exit( EXIT_FAILURE );
  }/* end if */
  if (datafile->switch_cycle < 0) datafile->switch_cycle = npatterns; /* (Switch-> All) */
  datafile->size = input_size;
  
  datafile->npatterns = npatterns;

  if ( datafile->cache_size > 0 ) { /* if user asks for a data cache */

    if ( npatterns <= datafile->cache_size ) { /* don't need cache */

      fprintf(stderr, "\n%s: No cache used (cache size larger than total number of patterns)\n",
	      datafile->filename);
      datafile->cache_size = 0;
      datafile->next_pattern = *next_pattern;
    } else {

      npatterns = datafile->cache_size;
      datafile->next_pattern = *next_pattern_cache;

      /* open datafile */
      datafile->input_fd = am_open(datafile->filename);
      if (datafile->input_fd < 0) {
	fprintf(stderr,"\nUnable to open %s.\n",datafile->filename);
	am_perror("ReadFile");
      }/* end if */

      file_descriptor = datafile->input_fd;

    }/* end else */
    
  } else { /* no cache */
    datafile->next_pattern = *next_pattern;
  }

  datafile->xdim = df->inputs_xdim;
  datafile->ydim = df->inputs_ydim;


  /* read in the target pattern */
  target = (float *)am_alloc_mem(target_size * sizeof(float));
  am_read(file_descriptor, (char *)target, target_size * sizeof(float));

  /* check to see if user specified a target vector */
  if (datafile->target.user_target != (float *)NULL) {
    target = datafile->target.user_target;
    fprintf(stderr, "\nWarning: Using user's targets instead of file's targets.\n");
  }/* end if */
  

  /* make pointer vectors */
  datafile->inputs = (float **)am_alloc_mem(npatterns * sizeof(float *));
  datafile->targets = (float **)am_alloc_mem(npatterns * sizeof(float *));

  /* read the file into an array of the same size */
  data_block = (float *)am_alloc_mem( npatterns * input_size * sizeof(float) );

  /* only read if not cached */
  if ( ! datafile->cache_size )
    am_read(file_descriptor, (char *)data_block, npatterns * input_size * sizeof(float) );

  /* update pointers into the inputs array */
  for (counter=0; counter<npatterns; counter++) {
    datafile->inputs[counter] = data_block + (counter * input_size);
    datafile->targets[counter] = target;
  }/* end for */
}/* end _type2_reader */
