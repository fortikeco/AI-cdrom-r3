/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "BpDatafile.h"
#include "globals.h"

/* these globals keep track of user generators */
static int n_user_generators = 0;
static USER_GENERATOR user_generators[MAX_USER_GENERATORS];        /* from BpDatafile.h */
static int file_counter = 0 , user_counter = 0, toggle = 0;

/* update_black_boxes: Sets the input and targets for each black box. */
static void update_black_boxes(DATAFILEPTR datafile)
{
  int index = datafile->current_pattern;
  FUNCTIONSPTR bbfncts = df->setfunctions;
  float *current_inputs, *current_targets;

  /* get the data (possibly add noise) */
  current_inputs = (*df->noise)(*(datafile->inputs + index),
				df->input_buffer,
				df->mean,
				df->variance,
				df->inputs_size);
  
  current_targets = (datafile->targets)[index];

  /* for every black box ... */
  while(bbfncts != (FUNCTIONSPTR)NULL) {

    /* set the targets? */
    if (bbfncts->set_target_output != NULL) {
      (*bbfncts->set_target_output)(current_targets);
    }/* end if */

    /* set the inputs? */
    if (bbfncts->set_input != NULL) {
      (*bbfncts->set_input)(current_inputs);
    }/* end if */

    bbfncts = bbfncts->next;
  }/* end while */

}/* end update_black_boxes */



/* datafile_generator: Sets the input and target outputs of all
                       the black boxes. 
 */
void datafile_generator(DATAFILEPTR datafile)
{
  extern void network_clear_delays();   /* from generated simulation */

  /* get the next file? */
  if (!(datafile->switch_counter % datafile->switch_cycle)) (*df->next_datafile)();
  
  /* clear delays? ("network_clear_delays" is in the generated file) */
  if (datafile->clear_delays)  network_clear_delays();

  /* next input/target pattern */
  (*datafile->next_pattern)(datafile);
  
  /* update black boxes by setting input and target output */
  update_black_boxes(datafile);
  
}/* end datafile_generator */


/*=================================================*
  define_generator  This adds a user's generator
  to the list.
  *=================================================*/
void define_generator( void (*generator)(char *item), char *item, char *string)
{
  if (n_user_generators > MAX_USER_GENERATORS) {
    fprintf(stderr,"\nToo many generators declared!\n");
    am_exit( EXIT_FAILURE );
  }/* end if */
  user_generators[n_user_generators].generator = generator;
  user_generators[n_user_generators].item = item;
  if (string == NULL)
    user_generators[n_user_generators++].string = "User Generator";
  else
    user_generators[n_user_generators++].string = string;
}/* end define_generator */

/*=================================================*
  generator1:         Calls the generators in a cycle.
                      from only files.
  *=================================================*/
void generator1()
{
  datafile_generator( df->current_datafile );
  file_counter = (file_counter + 1) % df->n_datafiles;
}/* end generator1 */

/*=================================================*
  generator2:         Calls the generators in a cycle.
                      from only user.
  *=================================================*/
void generator2()
{
  user_generators[user_counter].generator(user_generators[user_counter].item);
  user_counter = (user_counter + 1) % n_user_generators;
}/* end generator2 */

/*=================================================*
  print_user_generators:   Print user generator names
  *=================================================*/
void print_user_generators()
{
  int n=n_user_generators;
  
  if (n) {
    printf("\n\nUser generators:");
    while(n--)
      if ( user_generators[n].string != NULL)
	printf("\n\t%s", user_generators[n].string);
  }
}

/*=================================================*
  generator3:         Calls the generators in a cycle.
                      from both files and user.
  *=================================================*/
void generator3()
{
  if (toggle) {
    generator1();
    if (file_counter == 0) toggle = 1 - toggle;
  } else {
    generator2();
    if (user_counter == 0) toggle = 1 - toggle;
  }/* end else */
}/* end generator3 */


/*=================================================*
  set_generator:    Select a generator.
  *=================================================*/
void (*(set_generator)(int verbose))
{
  
  /* if we don't have a generator by now...barf! */
  if (n_user_generators == 0 && df == NULL) {
    if (verbose) {
      fprintf(stderr, "\nNo generators defined!");
      fprintf(stderr, "\nMaybe you need a .df file?");
    }/* end if */
    return(NULL);
  } else if (n_user_generators && df != NULL) { /* both */
    return(generator3);
  } else if (df != NULL) { /* only files */
    return(generator1);
  } else  { /* only user */
    return(generator2);
  }/* end else */
  
}/* end set_generator */
