/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "aspirin_bp.h"	       
  
  typedef struct test_struct {
    float *(*out_function)(void);
    float *(*target_function)(void);
    int      n_outputs;
    struct test_struct *next;
  } TS, *TS_PTR;

static TS_PTR Test_List = NULL;
     
void Create_Test_List(LB_PTR (*query_function)() )
{
  int i;
  LB_PTR layer_buffer;
  TS_PTR new_tester, results = (TS_PTR)NULL;
  
  if (Test_List == NULL) {
    for (i=0; (layer_buffer=query_function(i,0)) != NULL; i++)
      if ((layer_buffer->black_box_info.get_output != NULL) &&
	  (layer_buffer->black_box_info.get_target_output != NULL)) {
	
	new_tester = (TS_PTR)am_alloc_mem(sizeof(TS));
	
	new_tester->out_function =
	  layer_buffer->black_box_info.get_output;
	new_tester->target_function =
	  layer_buffer->black_box_info.get_target_output;
	layer_buffer =
	  query_function(i, layer_buffer->black_box_info.output_layer_index);
	new_tester->n_outputs = layer_buffer->n_nodes;
	new_tester->next = results;
	results = new_tester;
      }  /* if get_output != NULL */
    
    Test_List = results;
  }  /* if Test_List == NULL */
}  /* create_test_list() */

float RMS_Error()
{
  int i, count=0;
  float *output, *target, value;
  double sum = 0.0;
  TS_PTR tester;
  
  for (tester = Test_List; tester != NULL; tester = tester->next)
    if (((output = (tester->out_function)()) != NULL)  &&
	((target = (tester->target_function)()) != NULL))
      for (i=0; i<tester->n_outputs; i++, count++) {
	value = *output++ - *target++;
	sum += value * value;
      }
  
  if (count == 0) return( 0.0 );
  else {
    float result;
    result = AM_SQRT( (sum / count) );
    return( result );
  }
}  /* RMS_Error() */

float Max_Absolute_Error()
{
  int i;
  float *output, *target, value;
  TS_PTR tester;
  float max_error = 0.0;
  
  for (tester = Test_List; tester != NULL; tester = tester->next)
    if (((output = (tester->out_function)()) != NULL)  &&
	((target = (tester->target_function)()) != NULL))
      for (i=0; i<tester->n_outputs; i++)
	if ((value = AM_FABS(*output++ - *target++)) > max_error)
	  max_error = value;
  
  return( max_error );
}  /* Max_Absolute_Error() */

float Min_Absolute_Error()
{
  int i, count=0;
  float *output, *target, value;
  TS_PTR tester;
  double min_error;
  
  min_error = AM_HUGE_VAL;
  for (tester = Test_List; tester != NULL; tester = tester->next)
    if (((output = (tester->out_function)()) != NULL)  &&
	((target = (tester->target_function)()) != NULL))
      for (i=0; i<tester->n_outputs; i++, count++)
	if ((value = AM_FABS(*output++ - *target++)) < min_error)
	  min_error = value;
  
  if (count == 0) return(0.0);
  else return( min_error );
}  /* Min_Absolute_Error() */

float Mean_Absolute_Error()
{
  int i, count=0;
  float *output, *target;
  double sum = 0.0;
  TS_PTR tester;
  
  for (tester = Test_List; tester != NULL; tester = tester->next)
    if (((output = (tester->out_function)()) != NULL)  &&
	((target = (tester->target_function)()) != NULL))
      for (i=0; i<tester->n_outputs; i++, count++)
	sum += AM_FABS(*output++ - *target++);
  
  if (count == 0) return(0.0);
  else return( sum / count );
}  /* Mean_Absolute_Error() */
