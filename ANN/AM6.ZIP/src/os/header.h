/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/

/* This defines MACHTYPE/OS specific headers, constants, math stuff, etc. */

#ifndef AM_OS_HEADER

#define AM_OS_HEADER

#define AM_VERSION 6.0

#ifndef AM_OS_INCLUDES
/* ANSI C Headers */
#include <sys/types.h>
#include <sys/stat.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <float.h>
#include <errno.h>
#include <math.h>
#endif

/* machine specific defines (override) */
#ifdef AM_MACHTYPE_HEADER
# include AM_MACHTYPE_HEADER
#endif

#ifndef EXIT_SUCCESS
# define EXIT_SUCCESS 0
#endif

#ifndef EXIT_FAILURE
# define EXIT_FAILURE 1
#endif

/* I dunna wan' alloca */
#ifndef alloca
# define alloca malloc
#endif


/* ############################## MATH #################################### */

/* Note: If your system doesn't have these (or you want different functions)
         use the file $NNTOOLS/config/$MACHTYPE.h to override these macros.
	 For example, in the sun_sparc.h file the random functions are replaced.
*/

typedef struct {
  double real, imag;
} AM_COMPLEX;

#ifndef  AM_TINY_VAL
#define  AM_TINY_VAL FLT_MIN
#endif

#ifndef AM_HUGE_VAL
# define AM_HUGE_VAL FLT_MAX
#endif

#define AM_PI 3.14159265358979323846

#ifndef AM_CEIL
# define AM_CEIL(x) (ceil((double)(x)))
#endif 

#ifndef AM_LOG10
# define AM_LOG10(x) (log10((double)(x)))
#endif

#ifndef AM_LOG
# define AM_LOG(x) (log((double)(x)))
#endif

#ifndef AM_COS
# define AM_COS(x) (cos((double)(x)))
#endif

#ifndef AM_SIN
# define AM_SIN(x) (sin((double)(x)))
#endif 

#ifndef AM_COS
# define AM_ACOS(x) (acos((double)(x)))
#endif

#ifndef AM_POW
# define AM_POW(x,y) (pow((x),(y)))
#endif

#ifndef AM_SQRT
# define AM_SQRT(x) (sqrt((double)(x)))
#endif

#ifndef AM_EXP
# define AM_EXP(x) (exp((double)(x)))
#endif

#ifndef AM_FABS
# define AM_FABS(x) (fabs((double)(x)))
#endif

#ifndef AM_FMOD
# define AM_FMOD(x,y) ( fmod(((double)(x)),(double)(y)) )
#endif


#ifndef AM_RANDOM_RANGE
# ifdef RAND_MAX
#  define AM_RANDOM_RANGE RAND_MAX
# else
#  define AM_RANDOM_RANGE 2147483647.0 /* a guess, (2^31)-1 */
# endif
#endif


#ifndef AM_RANDOM
# define AM_RANDOM() ( ((float)rand()) / (AM_RANDOM_RANGE + 1.0) )
#endif

#ifndef AM_SEED_RANDOM
# define AM_SEED_RANDOM(x) ((void)srand((unsigned int)(x)))
#endif

/* ############################ bcopy ############################ */

#ifndef bcopy
# define bcopy(s1,s2,n) memcpy(s2,s1,n)
#endif

#ifndef bzero
# define bzero(s,n) memset(s,0,n)
#endif

/* ############################ cpp ############################ */

#ifndef CPP_CMD
# define CPP_CMD "/lib/cpp"
#endif

/* ############################ copyright ############################ */

#define BASIC_COPYRIGHT "Copyright (C) 1988-1992 The MITRE Corporation."

/* rules of the road... */
#define MITRE_COPYRIGHT "\n\n\n    ****************   NO WARRANTY  *****************\n\
Since the Aspirin/MIGRAINES system is licensed free of charge,\n\
Russell Leighton and the MITRE Corporation provides absolutley \n\
no warranty. Should the Aspirin/MIGRAINES system prove defective,\n\
you must assume the cost of all necessary servicing, repair or correction.\n\
In no way will Russell Leighton or the MITRE Corporation be liable\n\
to you for damages, including any lost profits, lost monies, or other\n\
special, incidental or consequential damages arising out of\n\
the use or in ability to use the Aspirin/MIGRAINES system.\n\
\n\
    *****************   COPYRIGHT  *******************\n\
This software is the copyright of Russell Leighton and the MITRE Corporation.\n\
It may be freely used and modified for research and development\n\
purposes. We require a brief acknowledgement in any research paper\n\
or other publication where this software has made a significant\n\
contribution. If you wish to use it for commercial gain, you must\n\
contact The MITRE Corporation for conditions of use. Russell Leighton and the MITRE\n\
Corporation provide absolutely NO WARRANTY for this software.\n\
"

#define EMAIL "taylor@world.std.com"

#endif  /* end AM_OS_HEADER */




/* exported functions from $NNTOOLS/os */

