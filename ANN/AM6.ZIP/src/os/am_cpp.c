/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "header.h"

extern int am_system(char *s);
extern char *am_mktemp();

char *am_cpp(char *file, int p)
{
#ifdef NO_SYSTEM
  fprintf(stderr, "\n      Warning: cpp not supported! (%s)\n", file);
  fprintf(stderr, "\n(Inotherwords, no C comments, #define's, #include's, etc.");
  fprintf(stderr, "\n If you use such things you must run /lib/cpp manually.)\n\n");
  return(file);
#else 
  char system_string[512];
  char *cpp_file;
  char *flags;
  
  cpp_file = am_mktemp();
  flags = " -D$MACHTYPE ";
  
  if (p)
    sprintf(system_string, "%s -P %s %s %s", CPP_CMD, flags, file, cpp_file);
  else
    sprintf(system_string, "%s %s %s %s", CPP_CMD, flags, file, cpp_file);
  
  am_system(system_string);
  
  return(cpp_file);
#endif
}

void am_remove_cpp_file(char *file)
{
#ifdef NO_SYSTEM

#else
  unlink(file);
#endif
}
