/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/

/*                      ---------------- analyze --------------                */

/* This program reads .df files and allows
   different analysis methods to be applied
   to the data.
*/

/* Required arguments:
         -d <df file>
         -InputsXdim <xdim>
         -InputsYdim <ydim>
         -TargetsXdim <xdim>
         -TargetsYdim <ydim>
*/

/* Analysis methods:

         **************************************************************************
         -pca
	 options:
	      -P <prefix> "Use "<prefix> for prefix of generated files (default: analyze)"
	      -range <n>  "Save 1-n components"
	      -group      "Divide data into sets, run pca seperatley"
	      options:
	          -edit "Ask user to confirm the use of every group"
	          -max, -unique "-unique => all data with unique targets are grouped
	                         -max    => all data with the same index of max are grouped"
         **************************************************************************

         **************************************************************************
         -cda
	 options:
	      -P <prefix> "Use "<prefix> for prefix of generated files (default: analyze)"
	      -range <n>  "Save 1-n components"
	      options:
	          -edit "Ask user to confirm the use of every group"
	          -max, -unique "-unique => all data with unique targets are grouped
	                         -max    => all data with the same index of max are grouped"
         **************************************************************************

         **************************************************************************
	 -project                "Project the data thru 1-range eigen vectors 
	                        (looks for files from <prefix>.<component>.<suffix>)"
	 options:
            -P <prefix> "Use "<prefix> for prefix of generated files (default: analyze)"
            -S <suffix> "Use "<suffix> for suffix of generated files (default: pcs)"
	    -range <n>  "Read 1-n components"
	    -autohistogram <n> "Compute an n bin histogram autoscale to max/min"
	    -histogram <n> <min> <max> "Compute an n bin histogram in the interval [<max>,<min>]"
         **************************************************************************

         **************************************************************************
         -div
	 options:
	      -P <prefix> "Use "<prefix> for prefix of generated files (default: analyze)"
	      options:
	          -edit "Ask user to confirm the use of every group"
	          -max, -unique "-unique => all data with unique targets are grouped
	                         -max    => all data with the same index of max are grouped"
         **************************************************************************
*/


#include "analyze.h"

/* from analyze_veq.c */
extern int veq(float *v1, float *v2, int n, int mode);

/* from analyze_pca.c */
extern void pca(DATA_GROUP *group_list, char *file_prefix, int mode, int pc_range);      
/* from analyze_cda.c */
extern void cda(DATA_GROUP *group_list, int n_groups, char *file_prefix, int mode, int pc_range);
/* from analyze_pjct.c */
extern void project(char *file_prefix, char *file_suffix,
		    int mode, int pc_range,
		    int n_histbins, float histmax, float histmin);
/* from analyze_div.c */
extern void div_data(DATA_GROUP *g, char *file_prefix, int mode);      

/* list of UNIQUE target patterns */
static DATA_GROUP *group_list=NULL;

static void usage()
{
  fprintf(stderr, "\nUnable to parse arguments! (see user's manual)\n");
  am_exit( EXIT_FAILURE );
}

static int parse_args_analysis(int argc, char **argv, char *flag)
{
  int is_there=0;

  while ( argc-- ) {
    if (! strcmp(flag, *argv) ) {
      is_there = 1;
      break;
    }/* end if */
    argv++;
  }/* end while */

  return( is_there );
}

static int parse_args_int(int argc, char **argv, char *flag)
{
  int dim=0;

  while ( argc-- ) {
    if (! strcmp(flag, *argv) ) {
      if (! argc ) break;
      argv++;
      if ( sscanf(*argv, "%d", &dim) != 1 ) {
	fprintf(stderr, "\nBad %s value\n", flag);
	usage();
      }
      break;
    }/* end if */
    argv++;
  }/* end while */

  return( dim );
}


static void parse_args_int_float_float(int argc, char **argv, char *flag,
				      int *dim,  float *max, float *min)
{

  while ( argc-- ) {
    if (! strcmp(flag, *argv) ) {
      if (! argc ) break;
      argv++;
      if ( sscanf(*argv, "%d", dim) != 1 ) {
	fprintf(stderr, "\nBad %s dimension\n", flag);
	usage();
      }
      argv++;
      if ( sscanf(*argv, "%f", max) != 1 ) {
	fprintf(stderr, "\nBad %s max\n", flag);
	usage();
      }
      argv++;
      if ( sscanf(*argv, "%f", min) != 1 ) {
	fprintf(stderr, "\nBad %s min\n", flag);
	usage();
      }
      break;
    }/* end if */
    argv++;
  }/* end while */

}

static char *parse_args_filename(int argc, char **argv, char *flag)
{
  char *filename=NULL;

  while ( argc-- ) {
    if (! strcmp(flag, *argv) ) {
      if (! argc ) break;
      argv++;
      filename = *argv;
      break;
    }/* end if */
    argv++;
  }/* end while */

  return(filename);
}

static void insert_target_groups(float *target_vector, int n, int mode)
{
  DATA_GROUP *g=group_list;

  /* is it in the list? */
  while(g != NULL) {

    /* same? */
    if ( veq(g->target_vector, target_vector, n , mode) ) {
      g->n_elements++;
      return;
    }/* end if */

    g = g->next;
  }

  /* it is not in the list...push */
  g = (DATA_GROUP *)am_alloc_mem(sizeof(DATA_GROUP));
  g->target_vector = target_vector; 
  g->n_elements = 1;
  g->next = group_list;
  group_list = g;
  
}


/* create a list of UNIQUE target vectors */
static int make_group_list(int mode)
{
  extern DFPTR df; /* from BpDatafile */

  /* loop thru all target vectors, insert
     unique ones into the list */
  {
    DATAFILEPTR files = df->datafiles;
    int targets_size = df->targets_size;

    /* make 1st target */
    group_list = (DATA_GROUP *)am_alloc_mem(sizeof(DATA_GROUP));
    group_list->target_vector = *(files->targets); /* 1st one */
    group_list->n_elements = 0;
    group_list->next = NULL;

    do {
      int n = files->npatterns;
      
      while (n--) {
	files->next_pattern(files); /* ask file for next pattern */
	insert_target_groups( *(files->targets + files->current_pattern), targets_size , mode);
      }/* end while */

      files = files->next;

    } while(files != df->datafiles) ; /* it's a circular list */

  }/* end block */

  /* how many groups? */
  { 
    int n_groups=0;
    DATA_GROUP *g=group_list;

    while(g != NULL) {
      n_groups++;
      g = g->next;
    }/* end while */

    fprintf(stderr, "\n%d different target groups found.\n", n_groups);

    return(n_groups);

  }/* end block */

}

static void edit_group_list()
{
  int group_number=1;
  DATA_GROUP *g=group_list;

  /* un-buffer the input */
  setbuf(stdin,(char *)NULL);
  
  while(g != NULL) {
    int i;

    printf("\n%d :", group_number);

    for(i=0;i<df->targets_size;i++)
      printf(" %g", *(g->target_vector + i) );

    printf("\nKeep %d? ", group_number);

    if ( getchar() == 'n' ) { /* remove */
      printf("\nremoving %d", group_number);

      {
	DATA_GROUP *l=group_list;

	if (l == g) group_list = group_list->next;
	else {
	  while(l->next != g) l = l->next;
	  l->next = g->next;
	}
      }/* end block */

    }/* end if */

    (void)getchar(); /* suck up the \n */

    g = g->next;
    group_number++;
  }/* end while */

  printf("\n");
}

main(argc, argv)
	int             argc;
	char           *argv[];
{
  char *file_prefix;
  char *df_file=NULL;


  if (argc == 1) {
    usage();
  }

  /* initialize */
  {
    /* disable underflow */
    am_disable_exceptions();

    /* make root of list */
    df = _make_df_root();

    /* fill root with dimension info (NULL out the rest) */
    df->inputs_xdim = parse_args_int(argc,argv,"-InputsXdim");
    df->inputs_ydim = parse_args_int(argc,argv,"-InputsYdim");
    df->inputs_size = df->inputs_xdim * df->inputs_ydim;
    df->targets_xdim = parse_args_int(argc,argv,"-TargetsXdim");
    df->targets_ydim = parse_args_int(argc,argv,"-TargetsYdim");
    df->targets_size = df->targets_xdim * df->targets_ydim;

    /* check inputs and targets */
    if ( ! df->inputs_xdim ) {
      fprintf(stderr, "\n-InputsXdim unspecified!\n");
      usage();
    }
    if ( ! df->inputs_ydim ) {
      fprintf(stderr, "\n-InputsYdim unspecified!\n");
      usage();
    }
    if ( ! df->targets_xdim ) {
      fprintf(stderr, "\n-TargetsXdim unspecified!\n");
      usage();
    }
    if ( ! df->targets_ydim ) {
      fprintf(stderr, "\n-TargetsYdim unspecified!\n");
      usage();
    }

  }

  /* read the data */
  {
    df_file = parse_args_filename(argc, argv, "-d");

    if (df_file == NULL) { /* error check */
      fprintf(stderr, "\nNo .df file supplied!\n");
      usage();
    } 

    fprintf(stderr, "\n\nLoading Data Files from %s...", df_file);
    
    if ( _read_df(df_file) ) {
      fprintf(stderr, "\n\nProblem reading data file.\n");
      am_exit( EXIT_FAILURE );
    } 
    
    fprintf(stderr, "Done\n");
  }

  /* analyze */

  /*  -------------------------  pca -------------------------  */
  if ( parse_args_analysis(argc, argv, "-pca") ) {
    int mode=UNIQUE_VECTOR;
    int pc_range;
    int n_groups;

    /* prefix */
    file_prefix = parse_args_filename(argc, argv, "-P");
    if (file_prefix == NULL) { /* error check */
      file_prefix = "analyze";
    }

    /* how many eigen vectors? (0 means all components ) */
    pc_range = parse_args_int(argc, argv, "-range");

    /* divide data into groups? */
    if ( parse_args_analysis(argc, argv, "-group") ) {
            
      if ( parse_args_analysis(argc, argv, "-max") )
	mode = MAX_VECTOR;
      else if ( parse_args_analysis(argc, argv, "-unique") )
	mode = UNIQUE_VECTOR;
	

      n_groups = make_group_list(mode);

      if ( parse_args_analysis(argc, argv, "-edit") ) {
	edit_group_list();
      }/* end if */

    }/* end if */

    fprintf(stderr, "\nDoing principal components analysis...");
    pca(group_list, file_prefix, mode, pc_range);
    fprintf(stderr, "\nDone");

    am_exit( EXIT_SUCCESS );

  }
  /*  -------------------------  pca -------------------------  */


  /*  -------------------------  cda -------------------------  */
  if ( parse_args_analysis(argc, argv, "-cda") ) {
    int mode=UNIQUE_VECTOR;
    int pc_range;
    int n_groups;

    /* prefix */
    file_prefix = parse_args_filename(argc, argv, "-P");
    if (file_prefix == NULL) { /* error check */
      file_prefix = "analyze";
    }

    /* how many eigen vectors? (0 means all components ) */
    pc_range = parse_args_int(argc, argv, "-range");

    /* divide data into groups */
    if ( parse_args_analysis(argc, argv, "-max") )
      mode = MAX_VECTOR;
    else if ( parse_args_analysis(argc, argv, "-unique") )
      mode = UNIQUE_VECTOR;
    
    
    n_groups = make_group_list(mode);
    
    if ( parse_args_analysis(argc, argv, "-edit") ) {
      edit_group_list();
    }/* end if */
    

    fprintf(stderr, "\nDoing canonical discriminate analysis...");
    cda(group_list, n_groups, file_prefix, mode, pc_range); 
    fprintf(stderr, "\nDone");

    am_exit( EXIT_SUCCESS );

  }
  /*  -------------------------  cda -------------------------  */

  /*  -------------------------  project -------------------------  */
  if ( parse_args_analysis(argc, argv, "-project") ) {
    int mode=UNIQUE_VECTOR;
    int n_histbins;
    float histmax=-AM_HUGE_VAL, histmin=AM_HUGE_VAL;
    int pc_range;
    char *file_suffix;

    /* prefix */
    file_prefix = parse_args_filename(argc, argv, "-P");
    if (file_prefix == NULL) { /* error check */
      file_prefix = "analyze";
    }

    /* suffix */
    file_suffix = parse_args_filename(argc, argv, "-S");
    if (file_suffix == NULL) { /* error check */
      file_suffix = "pc";
    }

    /* how many eigen vectors? (0 means all components ) */
    pc_range = parse_args_int(argc, argv, "-range");

    /* nbins for histogram (0 means no hist ) */
    n_histbins = parse_args_int(argc, argv, "-autohistogram");

    if (! n_histbins) { /* histogram? */
      parse_args_int_float_float(argc, argv, "-histogram",
				 &n_histbins, &histmin, &histmax);
      if (n_histbins && histmin > histmax) {
	fprintf(stderr, "\nhistmax < histmin!\n");
	usage();
      }/* end if */
    }/* end if */

    fprintf(stderr, "\nDoing projection of data thru eigen vectors...");
    project(file_prefix, file_suffix, mode, pc_range, n_histbins, histmin, histmax);
    fprintf(stderr, "\nDone");

    am_exit( EXIT_SUCCESS ); 

  }
  /*  -------------------------  project -------------------------  */

  /*  -------------------------  div -------------------------  */
  if ( parse_args_analysis(argc, argv, "-div") ) {
    int mode=UNIQUE_VECTOR;
    int n_groups;

    /* prefix */
    file_prefix = parse_args_filename(argc, argv, "-P");
    if (file_prefix == NULL) { /* error check */
      file_prefix = "analyze";
    }

            
      if ( parse_args_analysis(argc, argv, "-max") )
	mode = MAX_VECTOR;
      else if ( parse_args_analysis(argc, argv, "-unique") )
	mode = UNIQUE_VECTOR;
	

      n_groups = make_group_list(mode);

      if ( parse_args_analysis(argc, argv, "-edit") ) {
	edit_group_list();
      }/* end if */

    fprintf(stderr, "\nSpitting data by group...");
    div_data(group_list, file_prefix, mode);
    fprintf(stderr, "\nDone");

    am_exit( EXIT_SUCCESS ); 

  }
  /*  -------------------------  div -------------------------  */


}
