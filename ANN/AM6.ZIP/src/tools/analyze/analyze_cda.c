/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "analyze.h"

/*     ---------------  canonical discriminate analysis ---------------       */

/* from analyze_eigen.c */
extern void calculate_eigen_vectors_symmetric(double *eigen_vector_matrix, double *eigen_value_vector,
				    int n_columns);
extern void save_eigen_vectors(char *file_prefix, char *file_suffix,
			       int groups, int n_columns, double *matrix,
			       int xdim, int ydim, int pc_range);
extern void save_eigen_values(char *file_prefix, char *file_suffix,
			      int groups, int n_columns, double *vector);

/* from analyze_veq.c */
extern int veq(float *v1, float *v2, int n, int mode);

static double *wss_matrix, *wss_matrix_inv, *bss_matrix, *eigen_value_vector;
static double *column_totals, *group_column_totals;
static int *index_vector;

static void update_covariance_matrix(double *covariance_matrix, float *v,
				     double *column_totals_ptr, int n_columns)
{
  int col;
  

  for (col=0;col<n_columns;col++) {
    int i;

    /* sigma Xi */
    *column_totals_ptr++ += *(v + col);

    /* calculate XiXj terms */
    for (i=0; i<= col; i++){
      *(covariance_matrix + (col * n_columns)  + i) += *(v + i) * *(v + col);
      if (col != i) 
	*(covariance_matrix + (i * n_columns)  + col)
	  += *(v + i) * *(v + col);
    }/* end of XiXj */

  }/* end for col */
}


/* modified from numerical recipes */
static int ludcmp(double *a,int n,int *indx, double *d, double *vv)
{
	int i,imax,j,k;
	double big,dum,sum,temp;

	*d=1.0;
	for (i=0;i<n;i++) {
		big=0.0;
		for (j=0;j<n;j++) if ((temp=fabs( *(a + (i * n) + j)) ) > big) big=temp;
		if (big == 0.0) {
		  fprintf(stderr, "\n\n\t\tSingular matrix in cda calculation!\n");
		  return(1);
		}
		vv[i]=1.0/big;
	}

	for (j=0;j<n;j++) {
		for (i=0;i<=j;i++) {
			sum = *(a + (i * n) + j);
			for (k=0;k<i;k++) sum -= *(a + (i * n) + k) * *(a + (k * n) + j);
			*(a + (i * n) + j) = sum;
		}
		big=0.0;
		for (i=j;i<n;i++) {
			sum= *(a + (i * n) + j);
			for (k=0;k<j;k++)
				sum -= *(a + (i * n) + k) * *(a + (k * n) + j);
			*(a + (i * n) + j) = sum;
			if ( ( dum=vv[i] * fabs(sum) ) >= big) {
				big=dum;
				imax=i;
			}
		}
		if (j != imax) {
			for (k=0;k<n;k++) {
				dum = *(a + (imax * n) + k);
				*(a + (imax * n) + k) = *(a + (j * n) + k);
				*(a + (j * n) + k) = dum;
			}
			*d = -(*d);
			vv[imax]=vv[j];
		}
		indx[j]=imax;
		if (*(a + (j * n) + j) == 0.0) *(a + (j * n) + j) = DBL_MIN; /* smallest double */
		if (j != n-1) {
			dum = 1.0/(*(a + (j * n) + j));
			for (i=j+1;i<n;i++) *(a + (i * n) + j) *= dum;
		}
	}

	return(0);
}


/* modified from numerical recipes */
static void lubksb(double *a, int n, int *indx, double *b)
{
  int i,ii=0,ip,j;
  double sum;
  
  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii) for (j=ii;j<=i-1;j++) sum -= *(a + (i * n) + j) * b[j];
    else if (sum) ii=i;

    b[i]=sum;
  }

  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= *(a + (i * n) + j) * b[j];
    b[i]=sum / *(a + (i * n) + i);
  }

}



static void cda_groups(DATA_GROUP *groups, int n_groups, char *file_prefix,
		       int mode, int pc_range)
{
  float fuzz=0;
  int n_columns = df->inputs_size;
  int n_rows = 0;

 fuzz_data:

  if ( fuzz ) { /* had a singular matrix...fuzzing */
    DATAFILEPTR files = df->datafiles;

    /* reset */
    n_rows = 0;
    
    do {
      int n = files->npatterns;
      
      while (n--) {
	
	(*files->next_pattern)(files); /* ask file for next pattern */

	/* fuzz */
	{
	  int n_elements=n_columns;
	  float *pattern_ptr, half_fuzz;

	  half_fuzz = 0.5 * fuzz;

	  pattern_ptr = *(files->inputs + files->current_pattern);

	  while(n_elements--) *pattern_ptr++ += (AM_RANDOM() * fuzz) - half_fuzz ;

	}

      }/* end while */
      
      files = files->next;
    } while(files != df->datafiles) ; /* it's a circular list */
  }/* end if fuzz */

  /*   -----------------------   zero everything   ----------------------- */
  bzero((char *)wss_matrix, n_columns*n_columns*sizeof(double));
  bzero((char *)bss_matrix, n_columns*n_columns*sizeof(double));
  bzero((char *)column_totals, n_columns*sizeof(double));
  bzero((char *)group_column_totals, n_groups*n_columns*sizeof(double));

  /* for each group... */
  if (fuzz) fprintf(stderr, "\n\t\tNote: This may run slowly due to under/overflow traps.");
  fprintf(stderr, "\n\t\tCalculating covariance matrices ... ");
  {
    double *gptr= group_column_totals;
    DATA_GROUP *g=groups;

    while (g != NULL) {
      
      /*   -----------------------   wss (covariance)   ----------------------- */
      {
	DATAFILEPTR files = df->datafiles;
	
	do {
	  int n = files->npatterns;
	  
	  while (n--) {

	    (*files->next_pattern)(files); /* ask file for next pattern */

	    /* if the targets are the same then... */
	    if ( veq(g->target_vector, *(files->targets + files->current_pattern), n_columns, mode) ) {
	      
	      /* wss (covariance) */
	      update_covariance_matrix( wss_matrix, *(files->inputs + files->current_pattern) , gptr, n_columns);
	      
	    }/* end if */
	  }/* end while */
	  
	  files = files->next;
	} while(files != df->datafiles) ; /* it's a circular list */
	
      }/* end block */
      
      
      /* total number of patterns */
      n_rows += g->n_elements;
      
      /* next group */
      g = g->next;
      gptr += n_columns; 
      
    }/* end while g*/
  }
  
  /* calculate column totals */
  {
    int n = n_groups;
    double *gptr= group_column_totals;

    while(n--) {
      int i = n_columns;
      double *cptr = column_totals;

      while(i--) *cptr++ += *gptr++;

    }/* end while */
  }

  /* calc sqr(sigma X) */
  {
    int i,j;
    double scalar;

    scalar = -1.0/(double)n_rows;

    for (i=0; i < n_columns; i++)
      for (j=0; j < n_columns; j++)
	*(bss_matrix + (i * n_columns) + j) =
	    *(column_totals + j) *  *(column_totals + i) * scalar;

  }/* end block */

  /* subtract Sigma Xi Sigma Xj  */
  { /* for each group... */
    DATA_GROUP *g=groups;
    double *gptr= group_column_totals;
    int i,j;
    
    while(g != NULL) {
      double val, scalar;

      scalar = 1.0 / g->n_elements;
      
      for (i=0; i< n_columns; i++) {
	for (j=0; j < n_columns; j++) {
	  
	  val = ( *(gptr + i) * *(gptr + j) ) * scalar;
	  
	  *(bss_matrix + (i * n_columns) + j) += val;
	  *(wss_matrix + (i * n_columns) + j) -= val;
	  
	}/* end for j */
      }/* end for i */
      
      /* next group */
      gptr += n_columns;
      g = g->next;
    }/* end while */
    
  }/* end groups */

  fprintf(stderr, "Done");
    
  /*   -----------------------   invert, multi, eigen vector/values   ----------------------- */
  {
    int i,j,k;
    double d;

    fprintf(stderr, "\n\t\tCalculating [inverse(wss_matrix) * bss_matrix] ... ");
    

    /* invert (lu decomp from numerical recipes) */
    if (                        /* if returns, non-zero then singular matrix */
	ludcmp(wss_matrix,
	       n_columns, 
	       index_vector, 
	       &d,
	       eigen_value_vector) /* just used 'cause its free now */
	) {

      if ( fuzz )
	fprintf(stderr, "\n\t\tOh well, let's do it again\n");
      else
	fuzz = 1.1 * FLT_MIN;  /* add a little noise, and try again */

      fprintf(stderr, "\n\t\tAdding uniform noise with variance %g to data...trying again\n",
	      fuzz);
      goto fuzz_data ;

    }/* end if singular */

    bzero((char *)wss_matrix_inv, n_columns*n_columns*sizeof(double)); 
    bzero((char *)eigen_value_vector, n_columns*sizeof(double)); 
    for(i=0;i<n_columns; i++) {
      eigen_value_vector[i] = 1.0; /* just used 'cause its free now */
      lubksb(wss_matrix,
	     n_columns, 
	     index_vector, 
	     eigen_value_vector); 
      /* copy into wss_matrix_inv */
      for(j=0; j<n_columns; j++) *(wss_matrix_inv + (j * n_columns) + i) = eigen_value_vector[j];
      bzero((char *)eigen_value_vector, n_columns*sizeof(double)); 
    }
    
    /* wss_matrix = wss_matrix_inv * bss_matrix */
    for (j=0;j<n_columns;j++) 
      for (i=0;i<n_columns;i++) /* each row in wss_matrix_inv... */
	for (k=0;k<n_columns;k++)
	  *(wss_matrix + (k * n_columns) + j) = 
 	    *(wss_matrix_inv + (i * n_columns) + k) * *(bss_matrix + (k * n_columns) + j); 
    fprintf(stderr, "Done");

    fprintf(stderr, "\n\t\tForcing [inverse(wss_matrix) * bss_matrix] into symmetric form ...");
    for (j=0;j<n_columns-1;j++) {
      for (i=j+1;i<n_columns;i++) {
	double val;

	/* mean */
	val = ( *(wss_matrix + (i * n_columns) + j) + *(wss_matrix + (j * n_columns) + i) )*0.5 ; 

	*(wss_matrix + (i * n_columns) + j) = val;
	*(wss_matrix + (j * n_columns) + i) = val;
      }/* for i */
    }/* for j */
    fprintf(stderr, "Done");

    /* eig */
    fprintf(stderr, "\n\t\tSolving eigensystem ... ");
    calculate_eigen_vectors_symmetric(wss_matrix, eigen_value_vector, n_columns);
    fprintf(stderr, "Done");
  }
  
  /*   -----------------  output eigen vector/values   ----------------- */
  save_eigen_vectors(file_prefix, "cv", 0,
		     n_columns,
		     wss_matrix,
		     df->inputs_xdim, df->inputs_ydim,
		     pc_range);
  save_eigen_values(file_prefix, "cvs", 0,
		    n_columns, eigen_value_vector);
}

void cda(DATA_GROUP *group_list, int n_groups, char *file_prefix, int mode, int pc_range)
{
  
  /* create the mss and bss matrix, etc. */
  group_column_totals = (double *)am_alloc_mem(n_groups*df->inputs_size*sizeof(double));
  column_totals = (double *)am_alloc_mem(df->inputs_size*sizeof(double));
  wss_matrix = (double *)am_alloc_mem(df->inputs_size*df->inputs_size*sizeof(double));
  bss_matrix = (double *)am_alloc_mem(df->inputs_size*df->inputs_size*sizeof(double));
  eigen_value_vector = (double *)am_alloc_mem(df->inputs_size*sizeof(double));
  wss_matrix_inv = (double *)am_alloc_mem(df->inputs_size*df->inputs_size*sizeof(double)); 
  index_vector = (int *)am_alloc_mem(df->inputs_size*sizeof(int)); 
    
  
  
  if ( pc_range ) fprintf(stderr, "\n\tOnly saving canonical variates 1-%d", pc_range);
  else pc_range = df->inputs_size;
  
  fprintf(stderr, "\n\tWriting canonical variates to %s.<component>.cv", file_prefix);
  fprintf(stderr, "\n\tWhere <component> is replaced the component number");
  fprintf(stderr, "\n\tWriting canonical values to %s.cvs", file_prefix);
  fprintf(stderr, "\n\n\tAll data written in Aspirin data output format (see manual)\n");
  cda_groups(group_list, n_groups, file_prefix, mode, pc_range);
  
  fprintf(stderr, "\n");
}
