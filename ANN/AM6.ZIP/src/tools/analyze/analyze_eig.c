/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "analyze.h"

/* eigen system stuff, from numerical recipes */

static char eigen_filename[256];

void save_eigen_vectors(char *file_prefix, char *file_suffix,
			int groups, int n_columns, double *matrix,
			int xdim, int ydim, int pc_range)
{
  FILE *fp;
  int	i, j;
  
  /* for each component ... */
  for (i=0; i< pc_range; i++){
    
    if (groups)
      sprintf(eigen_filename, "%s.%d.%d.%s", file_prefix, groups, i+1, file_suffix);
    else
      sprintf(eigen_filename, "%s.%d.%s", file_prefix,i+1, file_suffix);
    
    fp = am_fopen(eigen_filename, "w");
    if (fp == NULL) {
      fprintf(stderr, "\nUnable to open %s!\n", eigen_filename);
      am_perror("analyze");
    }


    /* write header */
    fprintf(fp, "binary float %d %d\n", xdim, ydim);

    /* write data (binary) */
    for (j=0; j< n_columns; j++) {
      float val;
      
      val = *(matrix + (j * n_columns) + i);
      fwrite( &val, sizeof(float), 1, fp );
    }

    /* done */
    fclose(fp);
    
  }/* end for */
}

void save_eigen_values(char *file_prefix, char *file_suffix,
		       int groups, int n_columns, double *vector)
{
  FILE *fp;
  int	i;
  
  if (groups)
    sprintf(eigen_filename, "%s.%d.%s", file_prefix, groups, file_suffix);
  else
    sprintf(eigen_filename, "%s.%s", file_prefix, file_suffix);
  
  fp = am_fopen(eigen_filename, "w");
  if (fp == NULL) {
    fprintf(stderr, "\nUnable to open %s!\n", eigen_filename);
    am_perror("analyze");
  }

  /* write header */
  fprintf(fp, "binary float %d 1\n", n_columns);
  
  /* write data (binary) */
  for (i=0; i< n_columns; i++) {
    float val;

    val = *vector++;
    fwrite( &val, sizeof(float), 1, fp );
  }


}

void save_target_values(char *file_prefix, int groups, int n_columns, float *vector, int xdim, int ydim)
{
  FILE *fp;
  
  sprintf(eigen_filename, "%s.%d.target", file_prefix, groups);
  
  fp = am_fopen(eigen_filename, "w");
  if (fp == NULL) {
    fprintf(stderr, "\nUnable to open %s!\n", eigen_filename);
    am_perror("analyze");
  }

  /* write header */
  fprintf(fp, "binary float %d %d\n", xdim, ydim);

  /* write data (binary) */
  fwrite(vector, sizeof(float), n_columns,  fp);

  fclose(fp);
}

/* modified from numerical recipes */
static void tred2(double *a, int n, double *d, double *e)
{
  int l,k,j,i;
  double hh,h,g,f;  

  for(i=n-1; i>0; i--) {
    l=i-1;
    h=0.0;
    if (l > 0) {
      double scale;

      scale=0.0;

      for (k=0;k<i;k++)	scale += fabs( *(a + (i * n) + k) );

      if ( scale == 0.0) 
	e[i]=*(a + (i * n) + l);
      else {

	for (k=0;k<i;k++) {
	  double val;
	  val = *(a + (i * n) + k) / scale;
	  *(a + (i * n) + k) = val;
	  h += val*val;
	} /* for k */ 

	f=*(a + (i * n) + l);
	g = (f>0.0) ? -sqrt(h) : sqrt(h); 
	e[i]=scale*g;
	h -= f*g;
	*(a + (i * n) + l)=f-g;
	f=0.0;

	for (j=0;j<i;j++) {
	  /* Next statement can be omitted if eigenvectors not wanted */
	  *(a + (j * n) + i)=*(a + (i * n) + j)/h;
	  g=0.0;
	  for (k=0;k<=j;k++) g += *(a + (j * n) + k) * *(a + (i * n) + k);
	  for (k=j+1;k<i;k++) g += *(a + (k * n) + j) * *(a + (i * n) + k);
	  e[j]=g/h;
	  f += e[j] * *(a + (i * n) + j);
	} /* for j */

	hh=f/(h+h);
	for (j=0;j<i;j++) {
	  f= *(a + (i * n) + j);
	  e[j]=g=e[j] - hh * f;
	  for (k=0;k<=j;k++) *(a + (j * n) + k) -= (f * e[k] + g * *(a + (i * n) + k) );
	} /* for j */
      }
    } else
      e[i]=*(a + (i * n) + l);
    
    d[i]=h;

  } /* for i */
  
  /* Next statement can be omitted if eigenvectors not wanted */
  d[0]=0.0;
  e[0]=0.0;
  
  /* Contents of this loop can be omitted if eigenvectors not
     wanted except for statement d[i]=a[i][i]; */
  for (i=0;i<n;i++) {

    if (d[i]) {
      for (j=0;j<i;j++) {
	g=0.0;
	for (k=0;k<i;k++)  g += *(a + (i * n) + k) * *(a + (k * n) + j);
	for (k=0;k<i;k++)  *(a + (k * n) + j) -= g * *(a + (k * n) + i);
      } /* for j */
    }

    d[i]=*(a + (i * n) + i);
    *(a + (i * n) + i)=1.0;
    for (j=0;j<i;j++) *(a + (j * n) + i) = *(a + (i * n) + j) = 0.0;
  } /* for i */
}

/* modified from numerical recipes */
static void tqli(double *d, double *e, int n, double *z)
{
  int m,l,iter,i,k;
  double s,r,p,g,f,dd,c,b;

#define SIGN(a,b) ((b)<0 ? -fabs(a) : fabs(a))
  
  for (i=1;i<n;i++) e[i-1]=e[i];
  e[n-1]=0.0;
  
  for (l=0;l<n;l++) {
    iter=0;
    do {
      for (m=l;m<n-1;m++) {
	dd=fabs(d[m])+fabs(d[m+1]);
	if (fabs(e[m])+dd == dd) break;
      }
      if (m != l) {
	if (iter++ > 30) {
	  fprintf(stderr, "\nEigenvector calculation does not seem to be converging...\n");
	}
	g=(d[l+1]-d[l])/(2.0*e[l]);
	r=sqrt((g*g)+1.0);
	g=d[m]-d[l]+e[l]/(g+SIGN(r,g));
	s=c=1.0;
	p=0.0;
	for (i=m-1;i>=l;i--) {
	  f=s*e[i];
	  b=c*e[i];
	  if (fabs(f) >= fabs(g)) {
	    c=g/f;
	    r=sqrt((c*c)+1.0);
	    e[i+1]=f*r;
	    c *= (s=1.0/r);
	  } else {
	    s=f/g;
	    r=sqrt((s*s)+1.0);
	    e[i+1]=g*r;
	    s *= (c=1.0/r);
	  }
	  g=d[i+1]-p;
	  r=(d[i]-g)*s+2.0*c*b;
	  p=s*r;
	  d[i+1]=g+p;
	  g=c*r-b;
	  /* Next loop can be omitted if eigenvectors not wanted */
	  for (k=0;k<n;k++) {
	    f = *(z + (k * n) + i + 1);
	    *(z + (k * n) + i + 1) = s * *(z + (k * n) + i) + c * f;
	    *(z + (k * n) + i) = c * *(z + (k * n) + i) - s * f;
	  }
	}
	d[l]=d[l]-p;
	e[l]=g;
	e[m]=0.0;
      }
    } while (m != l);
  }
}


/* modified from numerical recipes */
static void eigsrt(double *d, double *v, int n)
{
  int k,j,i;
  double  p;
  
  for (i=0;i<n-1;i++) {
    p = d[k=i];
    for (j=i+1;j<n;j++)
      if (d[j] >= p) p = d[k=j];
    if (k != i) {
      d[k] = d[i];
      d[i] = p;
      for (j=0;j<n;j++) {
	p = *(v + (j * n) + i);
	*(v + (j * n) + i) = *(v + (j * n) + k);
	*(v + (j * n) + k) = p;
      }
    }
  }
}

void calculate_eigen_vectors_symmetric(double *eigen_vector_matrix, double *eigen_value_vector, int n)
{
  double *offdiag;

  offdiag = (double *)am_alloc_mem(n * sizeof(double));

  /* Call two functions to tridiagonalize the eigen_vector_matrix matrix and then
     return the eigenvalues (in eigen_value_vector) and the eigenvectors (in eigen_vector_matrix).
     The k-th column of eigen_vector_matrix will be the normalized eigenvector corresponding
     to eigen_value_vector[k] */
  tred2( eigen_vector_matrix, n, eigen_value_vector, offdiag );
  tqli( eigen_value_vector, offdiag, n, eigen_vector_matrix );
  
  /* Sort the eigenvalues into descending order and rearrange the columns of 
     eigen_vector_matrix accordingly. */
  eigsrt( eigen_value_vector, eigen_vector_matrix, n );

  am_free_mem( (char *)offdiag);
  
}
