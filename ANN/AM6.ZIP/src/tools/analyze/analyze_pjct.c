/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "analyze.h"

/* from BpDatafile */
extern int epoch_length(); 

/* from analyze_am.c */
extern int read_am_file(char *file, int xdim, int ydim, float *buffer);

/* from analyze_veq.c */
extern int veq(float *v1, float *v2, int n, int mode);

static float *eigen_vector_matrix;

static void histogram_vector(float *v, int npoints, float *histogram,
			     int nbins, float min, float max)
{
  float interval;

  /* find max,min -autohistogram  */
  if (max == -AM_HUGE_VAL && min == AM_HUGE_VAL) {
    int i=npoints;
    float *ptr=v;

    while(i--) {
      if (*ptr < min) min = *ptr;
      if (*ptr > max) max = *ptr;
      ptr++;
    }/* end while */

    fprintf(stderr, "\n\t\t-autohistogram range: [%f,%f]\n", min, max);

  }

  /* count */
  interval = (max - min) / nbins;
  bzero((char *)histogram, nbins * sizeof(float));
  while (npoints--) {
    int index;

    index = (int)((*v - min)/interval);
    /* clip , set */
    if (index > -1 && index <nbins) *(histogram + index) += 1.0;
    v++;
  }/* end while */

}

static void project_eigen_vector(float *projections, float *eigen_vector, int n_columns)
{
  DATAFILEPTR files = df->datafiles;
  
  do {
    int n = files->npatterns;
    
    while (n--) {

      (*files->next_pattern)(files); /* ask file for next pattern */

      *projections++ = BPvdot(eigen_vector, *(files->inputs + files->current_pattern) , n_columns);
    }
    
    files = files->next;
  } while(files != df->datafiles) ; /* it's a circular list */
}

static void project_data(char *file_prefix, char *file_suffix, int pc_range,
			 int n_histbins, float histmin, float histmax)
{
  char project_filename[256];
  int n_columns = df->inputs_size;
  int n_points;
  
  n_points = epoch_length(); /* from BpDatafile */

  /*   -----------------------   read eigen vectors   ----------------------- */
  {
    float *ptr=eigen_vector_matrix;
    int i;

    for(i=0; i<pc_range; i++) {
      sprintf(project_filename, "%s.%d.%s", file_prefix,i+1,file_suffix);
      fprintf(stderr, "\n\t\tReading: %s", project_filename);
      read_am_file(project_filename, df->inputs_xdim, df->inputs_ydim, ptr);
      ptr += n_columns;
    }

  } 

  /*   -----------------------   normalize eigen vectors   ----------------------- */
  {
    float *ptr=eigen_vector_matrix;
    int n=pc_range;

    while(n--) {
      /* divide thru (actually, times inverse) */
      BPvsmul(ptr, ptr,
	      1.0 / AM_SQRT( BPsum_squares(ptr, n_columns) ),
	      n_columns); 

      ptr += n_columns; 

    }/* end while */

  }

  /*   -----------------------  project   ----------------------- */
  {
    float *projections, *histogram;
    int i;
    
    
    projections = (float *)am_alloc_mem( n_points * pc_range * sizeof(float) );
    
    
    if (n_histbins) 
      histogram = (float *)am_alloc_mem( n_histbins * pc_range * sizeof(float) );
    
    
    for(i=0;i<pc_range; i++) {
      
      /* project thru */
      project_eigen_vector(projections + (i * n_points),
			   eigen_vector_matrix + (i * n_columns),
			   n_columns);
      
      /*   -----------------------  histogram it?  ----------------------- */      
      if (n_histbins) 
	histogram_vector(projections + (i * n_points),
			 n_points, histogram + (i * n_histbins),
			 n_histbins, histmin, histmax);
    }/* end for */
    
    /*   -----------------------  save it? ----------------------- */
    {
      FILE *fp;
      
      /* save it */
      sprintf(project_filename, "%s.%s.prj", file_prefix,file_suffix);
      
      fprintf(stderr, "\n\t\tSaving projections: %s", project_filename);
      
      fp = am_fopen(project_filename, "w");
      if (fp == NULL) {
	fprintf(stderr, "\nUnable to open %s!\n", project_filename);
	am_perror("analyze");
      }
      
      /* write header */
      fprintf(fp, "binary float %d %d\n", pc_range, n_points);
      
      /* write data (binary) */
      {
	int x,y;

	/* output transpose (more useful form) */
	for(y=0;y<n_points;y++)
	  for(x=0;x<pc_range;x++)
	    fwrite((char *)(projections + y + (x * n_points)),
		   sizeof(float), 1, fp );
      }

      /* done */
      fclose(fp);	
      
    }/* end save projections */
    
    
    if (n_histbins) {
      FILE *fp;
      
      /* ------ Unnormalized ------- */
      
      /* save it */
      sprintf(project_filename, "%s.%s.hst", file_prefix,file_suffix);
      
      fprintf(stderr, "\n\t\tSaving histogram: %s", project_filename);
      
      fp = am_fopen(project_filename, "w");
      if (fp == NULL) {
	fprintf(stderr, "\nUnable to open %s!\n", project_filename);
	am_perror("analyze");
      }
      
      /* write header */
      fprintf(fp, "binary float %d %d\n", pc_range, n_histbins);
      
      /* write data (binary) */
      {
	int x,y;

	/* output transpose (more useful form) */
	for(y=0;y<n_histbins;y++)
	  for(x=0;x<pc_range;x++)
	    fwrite((char *)(histogram + y + (x * n_histbins)),
		   sizeof(float), 1, fp );
      }
      
      /* done */
      fclose(fp);
      
      /* ------ Normalized ------- */
      
      {
	int n=n_histbins;
	float *h_ptr=histogram;
	
	n *= pc_range; /* times how many histograms */
	while(n--) *h_ptr++ /= (float)n_points;
      }
      
      /* save it */
      sprintf(project_filename, "%s.%s.norm.hst", file_prefix,file_suffix);
      
      fprintf(stderr, "\n\t\tSaving normalized histogram: %s", project_filename);
      
      fp = am_fopen(project_filename, "w");
      if (fp == NULL) {
	fprintf(stderr, "\nUnable to open %s!\n", project_filename);
	am_perror("analyze");
      }
      
      /* write header */
      fprintf(fp, "binary float %d %d\n", pc_range, n_histbins);
      
      /* write data (binary) */
      {
	int x,y;

	/* output transpose (more useful form) */
	for(y=0;y<n_histbins;y++)
	  for(x=0;x<pc_range;x++)
	    fwrite((char *)(histogram + y + (x * n_histbins)),
		   sizeof(float), 1, fp );
      }
      
      /* done */
      fclose(fp);
      
    }/* end if n_histbins */
    
  }/* end project */

}

void project(char *file_prefix, char *file_suffix, int mode, int pc_range,
	     int n_histbins, float histmin, float histmax)
{


  if ( pc_range ) {
    fprintf(stderr, "\n\tOnly reading prinicpal components 1-%d", pc_range);
  } else {
    pc_range = df->inputs_size;
  }/* end if else */

  /* create space */
  eigen_vector_matrix = (float *)am_alloc_mem(df->inputs_size*pc_range*sizeof(float));

  fprintf(stderr, "\n\tReading principal components from %s.<component>.%s",
	  file_prefix, file_suffix);
  fprintf(stderr, "\n\tWriting projections to %s.<component>.%s.prj",
	  file_prefix, file_suffix);
  if (n_histbins) {
    if (histmax != -AM_HUGE_VAL || histmin != AM_HUGE_VAL)
      fprintf(stderr, "\n\tScaling histogram [%f,%f]", histmin, histmax);
    else
      fprintf(stderr, "\n\tAutoscaling histogram [min,max]");
    fprintf(stderr, "\n\tWriting %d bin histograms to %s.<component>.%s.hst",
	    n_histbins, file_prefix, file_suffix);
  }/* end if */
  fprintf(stderr, "\n\tWhere <component> is replaced the component number.");
  fprintf(stderr, "\n\n\tAll data read/written in Aspirin data output format (see manual).\n");
  project_data(file_prefix, file_suffix, pc_range, n_histbins, histmin, histmax); 
  fprintf(stderr, "\n");
}
