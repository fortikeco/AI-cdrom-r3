/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/

#include "analyze.h"

/* vector equal */
int veq(float *v1, float *v2, int n, int mode)
{
  /* same address */
  if (v1 == v2) return (1);
  
  /* same values */
  switch (mode) {
  case UNIQUE_VECTOR :
    while(n--) if (*v1++ != *v2++) return(0);
    break;
  case MAX_VECTOR : {
    int v1_max_index;
    int v2_max_index;
    float v1_max, v2_max;

    n--;
    v1_max_index = n;
    v2_max_index = n;
    v1_max = *v1++;
    v2_max = *v2++;

    while(n--) {
      if (*v1 > v1_max) {
	v1_max = *v1;
	v1_max_index = n;
      }
      if (*v2 > v2_max) {
	v2_max = *v1;
	v2_max_index = n;
      }
      v1++;
      v2++;
    }/* end while */

    if (v1_max_index != v2_max_index) return(0);

    break;
  }
    default : {
      fprintf(stderr, "\nBad mode!");
    }
  }/* end switch */
  
  /* if you made it thru the whole vector, same */
  return(1);
}
