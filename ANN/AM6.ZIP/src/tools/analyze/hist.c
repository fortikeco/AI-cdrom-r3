/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "analyze.h"

static int parse_args_int(int argc, char **argv, char *flag)
{
  int dim=0;

  while ( argc-- ) {
    if (! strcmp(flag, *argv) ) {
      if (! argc ) break;
      argv++;
      if ( sscanf(*argv, "%d", &dim) != 1 ) {
	fprintf(stderr, "\nBad %s flag\n", flag);
	exit(1);
      }
      break;
    }/* end if */
    argv++;
  }/* end while */

  return( dim );
}

static float parse_args_float(int argc, char **argv, char *flag)
{
  float dim=0;

  while ( argc-- ) {
    if (! strcmp(flag, *argv) ) {
      if (! argc ) break;
      argv++;
      if ( sscanf(*argv, "%f", &dim) != 1 ) {
	fprintf(stderr, "\nBad %s flag\n", flag);
	exit(1);
      }
      break;
    }/* end if */
    argv++;
  }/* end while */

  return( dim );
}


main(argc,argv)
     int argc;
     char **argv;
{
  int nbins;
  float *histogram, max, min, val, interval, total=0.0;

  nbins = parse_args_int(argc, argv, "-nbins");
  max = parse_args_float(argc, argv, "-max");
  min = parse_args_float(argc, argv, "-min");


  if (min > max) {
    fprintf(stderr, "\nmin > max!\n");
    exit(1);
  }

  fprintf(stderr, "\nhist: nbins %d min %f max %f\n",
	  nbins, min, max);

  histogram = (float *)malloc( nbins * sizeof(float) );
  if (histogram == NULL) {
    fprintf(stderr, "\nUnable to malloc %d floats!\n", nbins);
    exit(1);
  }

  /* count */
  interval = (max - min) / nbins;
  bzero((char *)histogram, nbins * sizeof(float));
  while ( fread(&val, sizeof(float), 1, stdin) == 1 ) {
    int index;

    index = (int)((val - min)/interval);
    if (index >= nbins) index = nbins - 1; /* clip at top */
    if (index < 0) index = 0;              /* clip at bottom */
    *(histogram + index) += 1.0;
    total += 1.0;
  }/* end while */

  while(nbins--) printf("\n%f", (*histogram++)/total );

  exit(0);

}
