/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "analyze.h"

/*     ---------------  principal compents analysis ---------------       */

/* from analyze_eigen.c */
extern void calculate_eigen_vectors_symmetric(double *input_matrix, double *eigen_value_vector, 
				    int n_columns);
extern void save_eigen_vectors(char *file_prefix, char *file_suffix,
			       int groups, int n_columns, double *matrix,
			       int xdim, int ydim, int pc_range);
extern void save_eigen_values(char *file_prefix, char *file_suffix,
			      int groups, int n_columns, double *eigen_value_vector);
extern void save_target_values(char *file_prefix, int groups, int n_columns, float *vector, int xdim, int ydim);

/* from analyze_veq.c */
extern int veq(float *v1, float *v2, int n, int mode);

static double *covariance_matrix, *column_totals, *eigen_value_vector;

static void update_covariance_matrix(float *v, int n_columns)
{
  int col;
  double *column_totals_ptr=column_totals;

  for (col=0;col<n_columns;col++) {
    int i;

    /* sigma Xi */
    *column_totals_ptr++ += *(v + col);

    /* calculate XiXj terms */
    for (i=0; i<= col; i++){
      double val;

      val = *(v + i) * *(v + col);

      *(covariance_matrix + (col * n_columns)  + i) += val;
      if (col != i) *(covariance_matrix + (i * n_columns)  + col) += val;
    }/* end of XiXj */

  }/* end for col */
}


static void pca_all(char *file_prefix, int pc_range)
{
  int n_columns = df->inputs_size;
  int n_rows=0;

  /*   -----------------------   zero covariance   ----------------------- */
  bzero((char *)covariance_matrix, n_columns*n_columns*sizeof(double));
    
  /*   ---------------------   zero eigen vectors  ----------------------- */
  bzero((char *)eigen_value_vector, n_columns*sizeof(double));

  /*   ---------------------   zero column_totals  ----------------------- */
  bzero((char *)column_totals, n_columns*sizeof(double));
  
  /*   -----------------------   calc covariance   ----------------------- */
  fprintf(stderr, "\n\t\tCalculating covariance matrix ... ");
  {
    DATAFILEPTR files = df->datafiles;

    do {
      int n = files->npatterns;

      while (n--) {
	
	(*files->next_pattern)(files); /* ask file for next pattern */

	update_covariance_matrix( *(files->inputs + files->current_pattern) , n_columns);
	n_rows++;
      }
      
      files = files->next;
    } while(files != df->datafiles) ; /* it's a circular list */
    
  }/* end block */
  
  
  /* subtract Sigma Xi Sigma Xj / N  */
  {
    int i,j;

    for (i=0; i< n_columns; i++) {
      for (j=0; j < n_columns; j++) {
	*(covariance_matrix + (i * n_columns) + j) =
	  (
	   *(covariance_matrix + (i * n_columns) + j)
	   - *(column_totals + i) * *(column_totals + j)/ (double) n_rows
	   ) / (double) n_rows;
      }/* for j */
    }/* for i */
  }/* end block */
 
  fprintf(stderr, "Done");

  /*   -----------------------   eigen vector/values   ----------------------- */
  fprintf(stderr, "\n\t\tSolving eigensystem ... ");
  calculate_eigen_vectors_symmetric(covariance_matrix, eigen_value_vector, n_columns);
  fprintf(stderr, "Done");

  /*   -----------------  output eigen vector/values   ----------------- */
  save_eigen_vectors(file_prefix, "pc", 0,
		     n_columns,
		     covariance_matrix,
		     df->inputs_xdim, df->inputs_ydim,
		     pc_range);
  save_eigen_values(file_prefix, "pvs", 0,
		    n_columns, eigen_value_vector);
}

static void pca_groups(DATA_GROUP *g, char *file_prefix, int mode, int pc_range)
{
  int n_columns = df->inputs_size;
  int group_number = 1;
  
  /* for each group... */
  while (g != NULL) {
    
    /*   -----------------------   zero covariance   ----------------------- */
    bzero((char *)covariance_matrix, n_columns*n_columns*sizeof(double));
    
    /*   ---------------------   zero eigen vectors  ----------------------- */
    bzero((char *)eigen_value_vector, n_columns*sizeof(double));
    
    /*   ---------------------   zero column_totals  ----------------------- */
    bzero((char *)column_totals, n_columns*sizeof(double));

    /*   -----------------------   calc covariance   ----------------------- */
    fprintf(stderr, "\n\t\tCalculating covariance matrix ... ");
    {
      DATAFILEPTR files = df->datafiles;
      
      do {
	int n = files->npatterns;
	
	while (n--) {

	  (*files->next_pattern)(files); /* ask file for next pattern */

	  /* if the targets are the same then... */
	  if ( veq(g->target_vector, *(files->targets + files->current_pattern), n_columns, mode) ) {
	    update_covariance_matrix( *(files->inputs + files->current_pattern) , n_columns);
	  }/* end if */

	}/* end while */
	
	files = files->next;
      } while(files != df->datafiles) ; /* it's a circular list */
      
      /* subtract Sigma Xi Sigma Xj / N  */
      {
	int n_rows=g->n_elements;
	int i,j;
	for (i=0; i< n_columns; i++)
	  for (j=0; j < n_columns; j++)
	    *(covariance_matrix + (i * n_columns) + j) =
	      (
	       *(covariance_matrix + (i * n_columns) + j)
	       - *(column_totals + i) * *(column_totals + j)/ (double) n_rows
	       ) / (double) n_rows;
      }/* end block */

      fprintf(stderr, "Done\n\t\tgroup %d: %d elements", group_number, g->n_elements);
     
    }/* end block */
    
    /*   -----------------------   eigen vector/values   ----------------------- */
    fprintf(stderr, "\n\t\tSolving eigensystem ... ");
    calculate_eigen_vectors_symmetric(covariance_matrix, eigen_value_vector, n_columns);
    fprintf(stderr, "Done");
    
    /*   -----------------  output eigen vector/values   ----------------- */
    save_eigen_vectors(file_prefix, "pc", group_number,
		       n_columns,
		       covariance_matrix,
		       df->inputs_xdim, df->inputs_ydim,
		       pc_range);
    save_eigen_values(file_prefix, "pvs", group_number,
		      n_columns, eigen_value_vector);
    save_target_values(file_prefix, group_number,
		       df->targets_size, g->target_vector,
		       df->targets_xdim, df->targets_ydim);
    
    g = g->next;
    group_number++;
    
  }/* end while */
  
}

void pca(DATA_GROUP *group_list, char *file_prefix, int mode, int pc_range)
{

  /* create the covariance matrix, etc. */
  covariance_matrix = (double *)am_alloc_mem(df->inputs_size*df->inputs_size*sizeof(double));
  eigen_value_vector = (double *)am_alloc_mem(df->inputs_size*sizeof(double));
  column_totals = (double *)am_alloc_mem(df->inputs_size*sizeof(double));

  if ( pc_range ) fprintf(stderr, "\n\tOnly saving prinicpal components 1-%d", pc_range);
  else pc_range = df->inputs_size;

  /* w'happin' */
  if (group_list == NULL) {
    fprintf(stderr, "\n\tTreating all data as a single group");
    fprintf(stderr, "\n\tWriting principal components to %s.<component>.pc", file_prefix);
    fprintf(stderr, "\n\tWhere <component> is replaced the component number");
    fprintf(stderr, "\n\tWriting principal values to %s.pvs", file_prefix);
    fprintf(stderr, "\n\n\tAll data written in Aspirin data output format (see manual)\n");
    pca_all(file_prefix, pc_range);
  } else {
    fprintf(stderr, "\n\tGroup based analysis");
    fprintf(stderr, "\n\tWriting principal components to %s.<group>.<component>.pc", file_prefix);
    fprintf(stderr, "\n\tWhere <group> is replaced the group number and");
    fprintf(stderr, "\n\t<component> is replaced the component number");
    fprintf(stderr, "\n\tWriting principal values to %s.<group>.pvs", file_prefix);
    fprintf(stderr, "\n\tWriting target values to %s.<group>.target", file_prefix);
    fprintf(stderr, "\n\n\tAll data written in Aspirin data output format (see manual)\n");
    pca_groups(group_list, file_prefix, mode, pc_range);
  }
  fprintf(stderr, "\n");
}
