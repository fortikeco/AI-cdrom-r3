/* 

  ****************   NO WARRANTY  *****************

Since the Aspirin/MIGRAINES system is licensed free of charge,
Russell Leighton and the MITRE Corporation provide absolutley 
no warranty. Should the Aspirin/MIGRAINES system prove defective, 
you must assume the cost of all necessary servicing, repair or correction.
In no way will Russell Leighton or the MITRE Corporation be liable to you for
damages, including any lost profits, lost monies, or other
special, incidental or consequential damages arising out of
the use or inability to use the Aspirin/MIGRAINES system.

  *****************   COPYRIGHT  *******************

This software is the copyright of Russell Leighton and the MITRE Corporation. 
It may be freely used and modified for research and development
purposes. We require a brief acknowledgement in any research
paper or other publication where this software has made a significant
contribution. If you wish to use it for commercial gain you must contact 
The MITRE Corporation for conditions of use. Russell Leighton and 
the MITRE Corporation provide absolutely NO WARRANTY for this software.

   August, 1992 
   Russell Leighton
   The MITRE Corporation
   7525 Colshire Dr.
   McLean, Va. 22102-3481

*/
#include "analyze.h"

int read_am_file(char *file, int xdim, int ydim, float *buffer)
{
  FILE *fp;
  int ascii;
  char format_string[64];
  char data_type_string[64];

  fp = fopen(file, "r");
  if (fp == NULL) {
    fprintf(stderr, "\nUnable to open %s\n", file);
    am_perror(file);
    am_exit( EXIT_FAILURE );
  }

  /* read header */
  {
    int read_xdim, read_ydim;

    { 
      int header_length;
      
      header_length = fscanf(fp,"%s %s %d %d\n",
			     format_string,
			     data_type_string,
			     &read_xdim, &read_ydim);
      
      if ( header_length != 4) {
	fprintf(stderr, "\nUnable to read header in: %s\n", file);
	am_exit( EXIT_FAILURE );
      }/* end if */
      
    }
    
    /* error check */
    if (xdim != read_xdim) {
      fprintf(stderr, "\nBad xdim, read %d, wanted %d!\n", read_xdim, xdim);
      am_exit( EXIT_FAILURE );
    }
    if (ydim != read_ydim) {
      fprintf(stderr, "\nBad ydim, read %d, wanted %d!\n", read_ydim, ydim);
      am_exit( EXIT_FAILURE );
    }
  }/* end read header */
  
  /* how to read */
  if ( !strcmp(format_string, "ascii") )
    ascii = 1;
  else if ( !strcmp(format_string, "binary") )
    ascii = 0;
  else {
    fprintf(stderr, "\n%s: Illegal data format - %s!\n", file, format_string);
    am_exit( EXIT_FAILURE );
  }
  
  /* only float supported */
  if ( strcmp(data_type_string, "float") ) {
    fprintf(stderr, "\n%s: Error - only type float supported!\n", file);
    am_exit( EXIT_FAILURE );
  }
  
  /* fill... */
  if (ascii) {
    int n;
    
    n=xdim*ydim;
    while(n--)
      if ( fscanf(fp, "%f", buffer++) != 1 ) {
	fprintf(stderr, "\n%s: Error reading ascii input!\n", file);
	am_exit( EXIT_FAILURE );
      }
  } else {
    int n;
    
    n=xdim*ydim;
    if ( fread(buffer, sizeof(float), n, fp) != n ) {
      fprintf(stderr, "\n%s: Error reading binary input!\n", file);
      am_exit( EXIT_FAILURE );
    }

  }

  fclose(fp);
  
}
