/****************************************************************************/
/*                             MBP.H                                        */
/****************************************************************************/
/* Written by: Davide Anguita                                               */
/*             University of Genova                                         */
/*             DIBE - Department of Biophysical and Electronic Engineering  */
/*             Via all'Opera Pia 11a                                        */
/*             16145 Genova, ITALY                                          */
/*             e-mail: anguita@dibe.unige.it                                */
/*             Tel:    +39-10-3532192                                       */
/*             Fax:    +39-10-3532175                                       */
/****************************************************************************/
/*                                                                          */
/* Matrix Back Propagation with Vogl acceleration.                          */
/*                                                                          */ 
/* USAGE:  MBP <configuration file>                                         */
/*                                                                          */ 
/* REVISION 1.1 - August 1993                                               */
/*                                                                          */
/****************************************************************************/

#ifndef _H_MBP
#define _H_MBP

/****************************************************************************/
/*                            DEFINES                                       */
/****************************************************************************/
/*                                                                          */
/* Some useful defines..                                                    */
/*                                                                          */
/****************************************************************************/

typedef int   BOOL;

#define OR      ||
#define AND     &&
#define NOT     !

#define EQ      ==
#define GE      >=
#define GT      >
#define LE      <=
#define LT      <
#define NE      !=

#define ERROR   -1
#define NO_ERROR 0

#define TEXT_LINE 81

#ifndef TRUE
#define TRUE    -1
#endif

#ifndef FALSE
#define FALSE    0
#endif

#ifndef MAXFLOAT
#define MAXFLOAT 1.0e38
#endif

#define ERROR_MSG(x)    {\
			 printf("ERROR: %s\n",x);\
			 exit(-1);\
			}

#define DEBUG(x) printf("***DEBUG*** %s\n",x);\
		 getch();

#define WRITE_MAT(Mat,Rows,Cols,Name) {\
					printf("*** MATRIX %s ***\n",Name);\
					for (ii=0; ii LT (Rows); ii++)\
					 {\
					  for (jj=0; jj LT (Cols); jj++)\
					   printf(" %4.2f ",Mat[ii*(Cols)+jj]);\
					  printf("\n");\
					 }\
				      }

#define CHECK_PTR(x) if (x EQ NULL)\
		      {\
		       printf("Insufficient memory\n");\
		      }

#define IGNORE(x) if(x);


/***************************************************************************/
/*                            Init()                                       */
/***************************************************************************/
/*                                                                         */
/* Matrix allocation and initialization (from files).                      */
/*                                                                         */
/***************************************************************************/

void Init (REAL ***Status,         REAL ***StatusTest,   REAL ***Weight,
	   REAL ***Bias,           REAL ***OldWeight,    REAL ***OldBias,
	   REAL ***Delta,          REAL ***DeltaWeight,  REAL ***DeltaBias,
	   REAL ***OldDeltaWeight, REAL ***OldDeltaBias, REAL  **Target,
	   REAL  **TargetTest,     REAL ***StepWeight,   REAL ***StepBias,
	   int    *nLayer,         int   **nUnit,        int    *nIPattern,
	   int    *nTPattern,      REAL   *GradTh,       REAL   *AnaTh,
	   REAL   *MaxTh,          REAL   *DigTh,        long   *IterTh,
	   int    *RunTh,          FILE  **fInput,       FILE  **fTarget,
	   FILE  **fInputTest,     FILE  **fTargetTest,  FILE  **fWeight,
	   BOOL   *Test,           int    *nPrints,      long   *aSeed,
	   REAL    Sat,            BOOL   *YProp,        int     argc,         
	   char   *argv[]);

/****************************************************************************/
/*                         GetInt()                                         */
/*                         GetReal()                                        */
/*                         GetName()                                        */
/****************************************************************************/
/*                                                                          */
/* Read respectively int, long, real and char* values from the network      */
/* configuration file                                                       */
/*                                                                          */
/****************************************************************************/

void GetInt  (FILE *File, char *Name, int  *x);
void GetLong (FILE *File, char *Name, long *x);
void GetReal (FILE *File, char *Name, REAL *x);
void GetName (FILE *File, char *Name, char *x);


/****************************************************************************/
/*                         RandomWeights()                                  */
/****************************************************************************/
/*                                                                          */
/* Fill a matrix (nRows x nCols) with random values in the interval         */
/* [-Range,+Range].                                                         */
/*                                                                          */
/****************************************************************************/

void RandomWeights (REAL *Matrix, int nRows, int nCols, REAL Range);

/****************************************************************************/
/*                         FeedForward()                                    */
/****************************************************************************/
/*                                                                          */
/* Feed-forward phase of BP. Computes:                                      */
/*                                                        t                 */
/*   [Status](n) = f([Weight](n)*[Status](n-1)+Bias(n-1)*1)                 */
/*                                                                          */
/* for each layer.                                                          */
/*                                                                          */
/****************************************************************************/

void FeedForward (REAL *NewStatus, int nRowsNS, int nColsNS,
		  REAL *Weight,    int nRowsW,  int nColsW,
		  REAL *OldStatus, int nRowsOS, int nColsOS,
		  REAL *Bias,      int nElem);

/****************************************************************************/
/*                         EBPLastLayer()                                   */
/*                         EBP()                                            */
/****************************************************************************/
/*                                                                          */
/* Error back-propagation phase. Compute for the last layer:                */
/*                                                                          */
/*   [Delta](N) = df([Status](N))x([Target]-[Status](N))                    */
/*                                                                          */
/* For the hidden layers:                                                   */
/*                                         t                                */
/*   [Delta](n) = df([Status](n))x([Weight](n+1)*[Delta](n+1))              */
/*                                                                          */
/****************************************************************************/

void EBPLastLayer (REAL *Delta,  int nRowsD, int nColsD,
		   REAL *Target, int nRowsT, int nColsT,
		   REAL *Status, int nRowsS, int nColsS);

void EBP          (REAL *NewDelta, int nRowsND, int nColsND,
		   REAL *Status,   int nRowsS,  int nColsS,
		   REAL *Weight,   int nRowsW,  int nColsW,
		   REAL *OldDelta, int nRowsOD, int nColsOD);

/****************************************************************************/
/*                           Step()                                         */
/****************************************************************************/
/*                                                                          */
/* Compute the lerning step.                                                */
/*                                                                          */
/* For each layer:                                                          */
/*                                         t                                */
/*   [DeltaWeight](n) = [Delta](n)*[Status](n-1)                            */
/*   DeltaBias(n)     = [Delta](n)*1                                        */
/*                                                                          */
/****************************************************************************/

void Step (REAL *DeltaWeight, int nRowsDW, int nColsDW,
	   REAL *Delta,       int nRowsD,  int nColsD,
	   REAL *Status,      int nRowsS,  int nColsS,
	   REAL *DeltaBias,   int nElemsDB);

/****************************************************************************/
/*                         ComputeDigitalCost()                             */
/*                         ComputeAnalogCost()                              */
/*                         ComputeMaximumCost()                             */
/****************************************************************************/
/*                                                                          */
/* Compute different errors of the net.                                     */
/*                                                                          */
/* - Digital                                                                */
/*   % of wrong outputs of the network                                      */
/*                                                                          */
/* - Analog                                                                 */
/*   quadratic error                                                        */
/*                                                                          */
/* - Maximum                                                                */
/*   maximum absolute error                                                 */
/*                                                                          */
/****************************************************************************/


REAL ComputeDigitalCost  (REAL *Target, int nRowsT, int nColsT,
			  REAL *Status, int nRowsS, int nColsS);

REAL ComputeAnalogCost   (REAL *Target, int nRowsT, int nColsT,
			  REAL *Status, int nRowsS, int nColsS);

REAL ComputeMaximumCost  (REAL *Target, int nRowsT, int nColsT,
			  REAL *Status, int nRowsS, int nColsS);

/****************************************************************************/
/*                         ComputeGradientNorm()                            */
/****************************************************************************/
/*                                                                          */
/* Compute the gradient norm.                                               */
/*                                                                          */
/****************************************************************************/

REAL ComputeGradientNorm (REAL **DeltaWeight, REAL **DeltaBias,
			  int   *nUnit,       int    nLayer);


/****************************************************************************/
/*                         PrintStep()                                      */
/*                         OutResults()                                     */
/*                         SaveWeights()                                    */
/*                         OutTime()                                        */
/*                         OutStart()                                       */
/****************************************************************************/
/*                                                                          */
/* Routines to output results.                                              */
/* PrintStep prints the costs of the actual learning step.                  */
/* OutResults prints the final results.                                     */
/* SaveWeights saves the weights of the network at the end of each run.     */
/* OutStart prints the current run number and the seed of the random gen.   */
/* OutTime prints the learning speed.                                       */
/*                                                                          */
/****************************************************************************/

void OutStart   (int nRun);

void OutTime (long nIter, int nLayer, int nPattern, int *nUnit, double Time);

void PrintStep  (char *s,          long nIter,       REAL DigCost,
		 REAL AnaCost,     REAL MaxCost,     REAL GradientNorm,
		 REAL DigTestCost, REAL AnaTestCost, REAL MaxTestCost,
		 BOOL Test);

void OutResults (FILE *fWeight,    REAL BestDigCost, int  nBestDig,
		 REAL BestAnaCost, int  nBestAna,    REAL BestMaxCost,
		 int  nBestMax,    long nSuccIter,   int  nRun,
		 int  nSuccRun,    long nTotIter);

void SaveWeights (FILE  *fWeight, int  nLayer, REAL **Weight, REAL **Bias,
		  int *nUnit);

/****************************************************************************/
/*                         BackStep()                                       */
/*                         UpdateWeights()                                  */
/****************************************************************************/
/*                                                                          */
/* BackStep recalls the weights of the previous learning step.              */
/* UpdateWeights() updates the weights according to the new learning step.  */
/*                                                                          */
/****************************************************************************/

void BackStep      (REAL *DeltaWeight,    int nRowsDW,   int nColsDW,
		    REAL *DeltaBias,      int nElemsDB,
		    REAL *OldDeltaWeight, int nRowsODW,  int nColsODW,
		    REAL *OldDeltaBias,   int nElemsODB,
		    REAL *Weight,         int nRowsW,    int nColsW,
		    REAL *Bias,           int nElemsB,
		    REAL *StepWeight,     int nRowsSW,   int nColsSW,
		    REAL *StepBias,       int nElemsSB);

void UpdateWeights (REAL *StepWeight,     int nRowsSW,   int nColsSW,
		    REAL *StepBias,       int nElemsSB,
		    REAL Eta, REAL Alfa,
		    REAL *DeltaWeight,    int nRowsDW,   int nColsDW,
		    REAL *DeltaBias,      int nRowsDB, 
		    REAL *OldDeltaWeight, int nRowsODW,  int nColsODW,
		    REAL *OldDeltaBias,   int nElemsODB,
		    REAL *Weight,         int nRowsW,    int nColsW,
		    REAL *Bias,           int nElemsB );

/****************************************************************************/
/*                             f()                                          */
/*                             df()                                         */
/****************************************************************************/
/*                                                                          */
/* Activation function of the neurons and its derivative.                   */
/*                                                                          */
/****************************************************************************/

REAL f  (REAL x);

REAL df (REAL x);

#endif

/****************************************************************************/
/*                            END OF FILE                                   */
/****************************************************************************/
