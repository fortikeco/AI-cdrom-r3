/****************************************************************************/
/*                           inout.c                                        */
/****************************************************************************/
/* Written by: Davide Anguita                                               */
/*             University of Genova                                         */
/*             DIBE - Department of Biophysical and Electronic Engineering  */
/*             Via all'Opera Pia 11a                                        */
/*             16145 Genova, ITALY                                          */
/*             e-mail: anguita@dibe.unige.it                                */
/*             Tel:    +39-10-3532192                                       */
/*             Fax:    +39-10-3532175                                       */
/****************************************************************************/
/*                                                                          */
/* Routines for Input/Ouput and Initialization                              */
/*                                                                          */ 
/* REVISION 1.1 - August 1993                                               */
/*                                                                          */
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "mm.h"
#include "random.h"
#include "mbp.h"

/****************************************************************************/
/*                              Init()                                      */
/****************************************************************************/

void Init (REAL ***Status,         REAL ***StatusTest,   REAL ***Weight,
	   REAL ***Bias,           REAL ***OldWeight,    REAL ***OldBias,
	   REAL ***Delta,          REAL ***DeltaWeight,  REAL ***DeltaBias,
	   REAL ***OldDeltaWeight, REAL ***OldDeltaBias, REAL  **Target,
	   REAL  **TargetTest,     REAL ***StepWeight,   REAL ***StepBias,
	   int    *nLayer,         int   **nUnit,        int    *nIPattern,
	   int    *nTPattern,      REAL   *GradTh,       REAL   *AnaTh,
	   REAL   *MaxTh,          REAL   *DigTh,        long   *IterTh,
	   int    *RunTh,          FILE  **fInput,       FILE  **fTarget,
	   FILE  **fInputTest,     FILE  **fTargetTest,  FILE  **fWeight,
	   BOOL   *Test,           int    *nPrints,      long   *aSeed,
	   REAL    Sat,            BOOL   *YProp,        int     argc,         
	   char   *argv[])
 {
  FILE  *fConf;         
  int    i,j;
  double Tmp;
  char   Name[TEXT_LINE];

  if (argc NE 2)
   {
    ERROR_MSG("USAGE: MBP <conf. file>");
   }

  if ((fConf = fopen(argv[1],"rt")) EQ NULL)
   {
    ERROR_MSG("Configuration file not found");
   }

  /* Read # of input patterns */

  *nIPattern = 0;
  GetInt(fConf,"nIPATTERN",nIPattern);
  if (*nIPattern LE 0)
   {
    ERROR_MSG("Insufficient number of patterns");
   }

  /* Read # of test patterns */

  *nTPattern = 0;
  GetInt(fConf,"nTPATTERN",nTPattern);
  if (*nTPattern LE 0)
   {
    *Test = FALSE;
   }
  else
   {
    *Test = TRUE;
   }

  /* Read # of layers */

  *nLayer = 0;
  GetInt(fConf,"nLAYER",nLayer);
  if (*nLayer LT 1)
   {
    ERROR_MSG("Insufficient number of layers");
   }

  /* Read # of units per layer */

  *nUnit = (int*) calloc(*nLayer+1,sizeof(int));
  CHECK_PTR(*nUnit);
  for (i=0; i LE *nLayer; i++)
   {
    (*nUnit)[i] = 0;
    sprintf(Name,"nUNIT[%1d]",i);
    GetInt(fConf,Name ,&((*nUnit)[i]));
    if ((*nUnit)[i] LE 0)
     {
      ERROR_MSG("Layer without units");
     }
   }

  /* Read thresholds */

  *GradTh = 0.0;
  *AnaTh  = 0.0;
  *MaxTh  = 0.0;
  *DigTh  = 0.0;
  *IterTh = 0;
  *RunTh  = 0;
  GetReal(fConf,"GRADTH",GradTh);
  GetReal(fConf,"ANATH",AnaTh);
  GetReal(fConf,"MAXTH",MaxTh);
  GetReal(fConf,"DIGTH",DigTh);
  GetLong(fConf,"ITERTH",IterTh);
  GetInt(fConf,"RUNTH",RunTh);

  /* Read print step */

  *nPrints = 0;
  GetInt(fConf,"nPRINTS",nPrints);

  /* Read algorithm */

  *YProp = 0;
  GetInt(fConf,"YPROP",YProp);

  /* Read the seed of the random generator */

  *aSeed = 0L;
  GetLong(fConf,"SEED",aSeed);

  /* Print the welcome message */

  printf("***********************************************\n");
  printf("***********  Matrix Back Propagation **********\n");
  printf("***********************************************\n");
  printf("N. of layers        : %d\n",*nLayer);
  for (i=0; i LE *nLayer; i++)
   {
    printf("Layer %2d            : %d\n",i,(*nUnit)[i]);
   }
  printf("N. of patterns      : %d\n",*nIPattern);
  if (*Test)
   {
    printf("N. of test patterns : %d\n",*nTPattern);
   }
  printf("***********************************************\n");
  printf("***********************************************\n");

  /* Matrix allocation */

  *Status = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*Status);

  (*Status)[0] = (REAL*) calloc((*nUnit)[0]*(*nIPattern),sizeof(REAL));
  CHECK_PTR((*Status)[0]);

  if (*Test)
   {
    *StatusTest = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
    CHECK_PTR(*StatusTest);
    (*StatusTest)[0] = (REAL*) calloc((*nUnit)[0]*(*nTPattern),sizeof(REAL));
    CHECK_PTR((*StatusTest)[0]);
   }


  *Weight         = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*Weight);

  *Bias           = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*Bias);

  *OldWeight      = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*OldWeight);

  *OldBias        = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*OldBias);

  *Delta          = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*Delta);

  *DeltaWeight    = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*DeltaWeight);

  *DeltaBias      = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*DeltaBias);

  *OldDeltaWeight = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*OldDeltaWeight);

  *OldDeltaBias   = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*OldDeltaBias);

  *Target         = (REAL*)  calloc((*nUnit)[*nLayer]*(*nIPattern),sizeof(REAL));
  CHECK_PTR(*Target);

  if (*Test)
   {
    *TargetTest   = (REAL*) calloc((*nUnit)[*nLayer]*(*nTPattern),sizeof(REAL));
   }

  *StepWeight     = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*StepWeight);

  *StepBias       = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*StepBias);

  for (i=1; i LE *nLayer; i++)
   {
    (*Status)[i]         = (REAL*) calloc((*nUnit)[i]*(*nIPattern),sizeof(REAL));
    CHECK_PTR((*Status)[i]);

    if (*Test)
     {
      (*StatusTest)[i]   = (REAL*) calloc((*nUnit)[i]*(*nTPattern),sizeof(REAL));
      CHECK_PTR((*Status)[i]);
     }

    (*Weight)[i]         = (REAL*) calloc((*nUnit)[i]*(*nUnit)[i-1],sizeof(REAL));
    CHECK_PTR((*Weight)[i]);

    (*Bias)[i]           = (REAL*) calloc((*nUnit)[i],sizeof(REAL));
    CHECK_PTR((*Bias)[i]);

    (*OldWeight)[i]      = (REAL*) calloc((*nUnit)[i]*(*nUnit)[i-1],sizeof(REAL));
    CHECK_PTR((*Weight)[i]);

    (*OldBias)[i]        = (REAL*) calloc((*nUnit)[i],sizeof(REAL));
    CHECK_PTR((*Bias)[i]);

    (*Delta)[i]          = (REAL*) calloc((*nUnit)[i]*(*nIPattern),sizeof(REAL));
    CHECK_PTR((*Delta)[i]);

    (*DeltaWeight)[i]    = (REAL*) calloc((*nUnit)[i]*(*nUnit)[i-1],sizeof(REAL));
    CHECK_PTR((*DeltaWeight)[i]);

    (*DeltaBias)[i]      = (REAL*) calloc((*nUnit)[i],sizeof(REAL));
    CHECK_PTR((*DeltaBias)[i]);

    (*OldDeltaWeight)[i] = (REAL*) calloc((*nUnit)[i]*(*nUnit)[i-1],sizeof(REAL));
    CHECK_PTR((*OldDeltaWeight)[i]);

    (*OldDeltaBias)[i]   = (REAL*) calloc((*nUnit)[i],sizeof(REAL));
    CHECK_PTR((*OldDeltaBias)[i]);

    (*StepWeight)[i]     = (REAL*) calloc((*nUnit)[i]*(*nUnit)[i-1],sizeof(REAL));
    CHECK_PTR((*StepWeight)[i]);

    (*StepBias)[i]       = (REAL*) calloc((*nUnit)[i],sizeof(REAL));
    CHECK_PTR((*StepBias)[i]);
   }

  /* Read file of learning patterns: input */

  *Name = 0;
  GetName(fConf,"fINPUT",Name);
  if ((*fInput = fopen(Name,"rt")) EQ NULL)
   {
    ERROR_MSG("Input file not found");
   }
  for (i=0; i LT *nIPattern; i++)
   {
    for (j=0; j LT (*nUnit)[0]; j++)
     {
      fscanf(*fInput,"%lf",&Tmp);
      (*Status)[0][j+i*((*nUnit)[0])] = Tmp*Sat;
     }
   }
  fclose(*fInput);

  /* Read file of learning patterns: target */

  *Name = 0;
  GetName(fConf,"fTARGET",Name);
  if ((*fTarget = fopen(Name,"rt")) EQ NULL)
   {
    ERROR_MSG("Target file not found");
   }
  for (i=0; i LT *nIPattern; i++)
   {
    for (j=0; j LT (*nUnit)[*nLayer]; j++)
     {
      fscanf(*fTarget,"%lf",&Tmp);
      (*Target)[j+i*((*nUnit)[*nLayer])] = Tmp*Sat;
     }
   }
  fclose(*fTarget);

  /* Open weight file for output */

  *Name = 0;
  GetName(fConf,"fWEIGHTS",Name);
  if ((*fWeight = fopen(Name,"wt")) EQ NULL)
   {
    ERROR_MSG("Cannot open weight file");
   }

  /* Same for test patterns */

  if (*Test)
   {
    *Name = 0;
    GetName(fConf,"fINPUTTEST",Name);
    if ((*fInputTest = fopen(Name,"rt")) EQ NULL)
     {
      ERROR_MSG("Test input file not found");
     }

    for (i=0; i LT *nTPattern; i++)
     {
      for (j=0; j LT (*nUnit)[0]; j++)
       {
	fscanf(*fInputTest,"%lf",&Tmp);
	(*StatusTest)[0][j+i*((*nUnit)[0])] = Tmp*Sat;
       }
     }
    fclose(*fInputTest);
    *Name = 0;
    GetName(fConf,"fTARGETTEST",Name);
    if ((*fTargetTest = fopen(Name,"rt")) EQ NULL)
     {
      ERROR_MSG("Test target file not found");
     }
    for (i=0; i LT *nTPattern; i++)
     {
      for (j=0; j LT (*nUnit)[*nLayer]; j++)
       {
	fscanf(*fTargetTest,"%lf",&Tmp);
	(*TargetTest)[j+i*((*nUnit)[*nLayer])] = Tmp*Sat;
       }
     }
    fclose(*fTargetTest);
   }
 }

/*****************************************************************************/
/*                         GetLong()                                         */
/*****************************************************************************/

void GetLong(FILE *File, char *Name, long *x)
{
 char TextLine[TEXT_LINE];
 char *Word;

 while (fscanf(File,"%s\n",TextLine) NE EOF)
  {
   if ((Word = strstr(TextLine, Name)) NE NULL)
    {
     Word += strlen(Name);
     if (*Word EQ '=' AND ++Word NE 0)
      {
       *x = atol(Word);
      }
    }
  }
 rewind(File);
}


/****************************************************************************/
/*                         GetInt()                                         */
/****************************************************************************/

void GetInt(FILE *File, char *Name, int *x)
{
 char TextLine[TEXT_LINE];
 char *Word;

 while (fscanf(File,"%s\n",TextLine) NE EOF)
  {
   if ((Word = strstr(TextLine, Name)) NE NULL)
    {
     Word += strlen(Name);
     if (*Word EQ '=' AND ++Word NE 0)
      {
       *x = atoi(Word);
      }
    }
  }
 rewind(File);
}


/****************************************************************************/
/*                         GetReal()                                        */
/****************************************************************************/

void GetReal(FILE *File, char *Name, REAL *x)
{
 char TextLine[TEXT_LINE];
 char *Word;

 while (fscanf(File,"%s",TextLine) NE EOF)
  {
   if ((Word = strstr(TextLine, Name)) NE NULL)
    {
     Word += strlen(Name);
     if (*Word EQ '=' AND ++Word NE 0)
      {
       *x = (REAL) atof(Word);
      }
    }
  }
 rewind(File);
}

/****************************************************************************/
/*                         GetName()                                        */
/****************************************************************************/

void GetName (FILE *File, char *Name, char *x)
{
 char TextLine[TEXT_LINE];
 char *Word;

 while (fscanf(File,"%s",TextLine) NE EOF)
  {
   if ((Word = strstr(TextLine, Name)) NE NULL)
    {
     Word += strlen(Name);
     if (*Word EQ '=' AND ++Word NE 0)
      {
       strcpy(x,Word);
      }
    }
  }
 rewind(File);
}

/****************************************************************************/
/*                             PrintStep()                                  */
/****************************************************************************/

void PrintStep (char *s,          long nIter,       REAL DigCost, 
		REAL AnaCost,     REAL MaxCost,     REAL GradientNorm, 
		REAL DigTestCost, REAL AnaTestCost, REAL MaxTestCost, 
		BOOL Test)
{
 if (Test)
  {
   printf ("%s %6ld  %.4E  %.6lf %.6lf %6.2lf   %.6lf %.6lf %6.2lf\n", 
	   s, nIter,
	   (double) GradientNorm,
	   (double) AnaCost,
	   (double) MaxCost,
	   (double) DigCost,
	   (double) AnaTestCost,
	   (double) MaxTestCost,
	   (double) DigTestCost);
  }
 else
  {
   printf ("%s %5ld  %.4E  %.6lf %.6lf %6.2lf\n", 
	   s, nIter,
	   (double) GradientNorm,
	   (double) AnaCost,
	   (double) MaxCost,
	   (double) DigCost);
  }
}

/****************************************************************************/
/*                             OutTime()                                    */
/****************************************************************************/

void OutTime (long nIter, int nLayer, int nPattern, int *nUnit, double Time)
 {
  double    nC=0;
  int    i;

  for (i=1; i<= nLayer; i++)
   {
    nC += (double) (nUnit[i-1]+1) * nUnit[i];
   }

  nC *= (double) nIter*nPattern;

  if (Time GT 0.0)
   {
    printf ("\n\n* MCUPS = %6.4lf\n",nC/(1.0e6*Time));
   }
  else
   {
    printf ("\n\n* MCUPS = <not measurable>\n");
   }
 }

/****************************************************************************/
/*                             OutStart()                                   */
/****************************************************************************/

void OutStart (int nRun)
 {
  printf ("\n\n* nRun =%4d  Seed = %ld\n",nRun,GetSeed());
 }

/****************************************************************************/
/*                             OutResults()                                 */
/****************************************************************************/

void OutResults (FILE *fWeight,    REAL BestDigCost, int  nBestDig,
		 REAL BestAnaCost, int  nBestAna,    REAL BestMaxCost,
		 int  nBestMax,    long nSuccIter,   int  nRun,
		 int  nSuccRun,    long nTotIter)

{
 printf("\n###%6d %.2lf %.2lf %.2lf",
	nRun, 
	(double)nSuccIter/(double)nSuccRun,
	(double)nTotIter/(double)nSuccRun,
	100.0*(double)nSuccRun/(double)nRun);

 printf("  %d: %.6lf   %d: %.6lf   %d: %.3lf\n", 
	nBestAna, (double)BestAnaCost,
	nBestMax, (double)BestMaxCost,
	nBestDig, (double)BestDigCost);

 fclose(fWeight);

}


/****************************************************************************/
/*                             SaveWeights()                                */
/****************************************************************************/

void SaveWeights(FILE *fWeight, int nLayer, REAL **Weight, REAL **Bias,
		 int  *nUnit)
{
 int i,j;

 for (i=1; i LE nLayer; i++)
  {
   for (j=0; j LT nUnit[i]*nUnit[i-1]; j++)
    {
     fprintf(fWeight,"%lf ",(double)Weight[i][j]);
    }
   for (j=0; j LT nUnit[i]; j++)
    {
     fprintf(fWeight,"%lf ",(double)Bias[i][j]);
    }
  } 
}

/****************************************************************************/
/*                         END OF FILE                                      */
/****************************************************************************/
