/****************************************************************************/
/*                           inoutval.c                                     */
/****************************************************************************/
/* Written by: Davide Anguita                                               */
/*             University of Genova                                         */
/*             DIBE - Department of Biophysical and Electronic Engineering  */
/*             Via all'Opera Pia 11a                                        */
/*             16145 Genova, ITALY                                          */
/*             e-mail: anguita@dibe.unige.it                                */
/*             Tel:    +39-10-3532192                                       */
/*             Fax:    +39-10-3532175                                       */
/****************************************************************************/
/*                                                                          */
/* Routines for Input/Ouput and Initialization                              */
/*                                                                          */ 
/* REVISION 1.1 - August 1993                                               */
/*                                                                          */
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "mm.h"
#include "mbpval.h"

/****************************************************************************/
/*                              Init()                                      */
/****************************************************************************/

void Init (REAL ***Status,    REAL ***Weight,    REAL ***Bias,
	   REAL  **TargetVal, int    *nLayer,    int   **nUnit,
	   int    *nVPattern, FILE  **fInputVal, FILE  **fTargetVal,
	   FILE  **fWeight,   int    *RunTh,     REAL    Sat,
	   int     argc,      char   *argv[])
 {
  FILE  *fConf;
  int    i,j;
  double Tmp;
  int    TmpI;
  char   Name[TEXT_LINE];

  if (argc NE 2)
   {
    ERROR_MSG("USAGE: MBPVAL <conf. file>");
   }

  if ((fConf = fopen(argv[1],"rt")) EQ NULL)
   {
    ERROR_MSG("Configuration file not found");
   }

  /* Read # of validation patterns */

  *nVPattern = 0;
  GetInt(fConf,"nVPATTERN",nVPattern);
  if (*nVPattern LE 0)
   {
    ERROR_MSG("Insufficient number of patterns");
   }

  /* Read # of layers */

  *nLayer = 0;
  GetInt(fConf,"nLAYER",nLayer);
  if (*nLayer LT 1)
   {
    ERROR_MSG("Insufficient number of layers");
   }

  /* Read # of units per layer */

  *nUnit = (int*) calloc(*nLayer+1,sizeof(int));
  CHECK_PTR(*nUnit);
  for (i=0; i LE *nLayer; i++)
   {
    (*nUnit)[i] = 0;
    sprintf(Name,"nUNIT[%1d]",i);
    GetInt(fConf,Name ,&((*nUnit)[i]));
    if ((*nUnit)[i] LE 0)
     {
      ERROR_MSG("Layer without units");
     }
   }

  /* Read # of runs */

  *RunTh  = 0;
  GetInt(fConf,"RUNTH",RunTh);

  /* Print the welcome message */

  printf("***********************************************\n");
  printf("***********  MBP Validation  ******************\n");
  printf("***********************************************\n");
  printf("N. of layers        : %d\n",*nLayer);
  for (i=0; i LE *nLayer; i++)
   {
    printf("Layer %2d            : %d\n",i,(*nUnit)[i]);
   }
  printf("N. of patterns      : %d\n",*nVPattern);
  printf("***********************************************\n");
  printf("***********************************************\n");

  /* Matrix allocation */

  *Status = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*Status);

  (*Status)[0] = (REAL*) calloc((*nUnit)[0]*(*nVPattern),sizeof(REAL));
  CHECK_PTR((*Status)[0]);

  *Weight         = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*Weight);

  *Bias           = (REAL**) calloc(*nLayer+1,sizeof(REAL*));
  CHECK_PTR(*Bias);

  *TargetVal      = (REAL*)  calloc((*nUnit)[*nLayer]*(*nVPattern),
				    sizeof(REAL));
  CHECK_PTR(*TargetVal);

  for (i=1; i LE *nLayer; i++)
   {
    (*Status)[i]         = (REAL*) calloc((*nUnit)[i]*(*nVPattern),
					  sizeof(REAL));
    CHECK_PTR((*Status)[i]);

    (*Weight)[i]         = (REAL*) calloc((*nUnit)[i]*(*nUnit)[i-1],
					  sizeof(REAL));
    CHECK_PTR((*Weight)[i]);

    (*Bias)[i]           = (REAL*) calloc((*nUnit)[i],sizeof(REAL));
    CHECK_PTR((*Bias)[i]);

   }


  /* Read file of validation patterns: input */

  *Name = 0;
  GetName(fConf,"fINPUTVAL",Name);
  if ((*fInputVal = fopen(Name,"rt")) EQ NULL)
   {
    ERROR_MSG("Input file not found");
   }
  for (i=0; i LT *nVPattern; i++)
   {
    for (j=0; j LT (*nUnit)[0]; j++)
     {
      fscanf(*fInputVal,"%lf",&Tmp);
      (*Status)[0][j+i*((*nUnit)[0])] = Tmp*Sat;
     }
   }
  fclose(*fInputVal);

  /* Read file of validation patterns: target */

  *Name = 0;
  GetName(fConf,"fTARGETVAL",Name);
  if ((*fTargetVal = fopen(Name,"rt")) EQ NULL)
   {
    ERROR_MSG("Target file not found");
   }
  for (i=0; i LT *nVPattern; i++)
   {
    for (j=0; j LT (*nUnit)[*nLayer]; j++)
     {
      fscanf(*fTargetVal,"%lf",&Tmp);
      (*TargetVal)[j+i*((*nUnit)[*nLayer])] = Tmp*Sat;
     }
   }
  fclose(*fTargetVal);

  /* Open weight file for input */
  
  *Name = 0;
  GetName(fConf,"fWEIGHTS",Name);
  if ((*fWeight = fopen(Name,"rt")) EQ NULL)
   {
    ERROR_MSG("Cannot open weight file");
   }
}


/****************************************************************************/
/*                         GetInt()                                         */
/****************************************************************************/

void GetInt(FILE *File, char *Name, int *x)
{
 char TextLine[TEXT_LINE];
 char *Word;

 while (fscanf(File,"%s\n",TextLine) NE EOF)
  {
   if ((Word = strstr(TextLine, Name)) NE NULL)
    {
     Word += strlen(Name);
     if (*Word EQ '=' AND ++Word NE 0)
      {
       *x = atoi(Word);
      }
    }
  }
 rewind(File);
}

/****************************************************************************/
/*                         GetReal()                                        */
/****************************************************************************/

void GetReal(FILE *File, char *Name, REAL *x)
{
 char TextLine[TEXT_LINE];
 char *Word;

 while (fscanf(File,"%s",TextLine) NE EOF)
  {
   if ((Word = strstr(TextLine, Name)) NE NULL)
    {
     Word += strlen(Name);
     if (*Word EQ '=' AND ++Word NE 0)
      {
       *x = (REAL) atof(Word);
      }
    }
  }
 rewind(File);
}

/****************************************************************************/
/*                         GetName()                                        */
/****************************************************************************/

void GetName (FILE *File, char *Name, char *x)
{
 char TextLine[TEXT_LINE];
 char *Word;

 while (fscanf(File,"%s",TextLine) NE EOF)
  {
   if ((Word = strstr(TextLine, Name)) NE NULL)
    {
     Word += strlen(Name);
     if (*Word EQ '=' AND ++Word NE 0)
      {
       strcpy(x,Word);
      }
    }
  }
 rewind(File);
}


/****************************************************************************/
/*                           ReadNet()                                      */
/****************************************************************************/

void ReadNet (FILE *fWeight, REAL **Weight, REAL **Bias, int nLayer,
	      int  *nUnit)
 {
  int    i,j;
  double TmpD;

  for (i=1; i LE nLayer; i++)
   {
    for (j=0; j LT nUnit[i]*nUnit[i-1]; j++)
     {
      fscanf(fWeight,"%lf", &TmpD);
      Weight[i][j] = (REAL) TmpD;
     }
    for (j=0; j LT nUnit[i]; j++)
     {
      fscanf(fWeight,"%lf", &TmpD);
      Bias[i][j] = (REAL) TmpD;
     }
   } 
 }

/****************************************************************************/
/*                             OutPattern()                                 */
/****************************************************************************/

void OutPattern (REAL *Target, REAL *Status, int nRows, int nCols, REAL Sat)
 {
  int i,j;

  for (i=0; i LT nRows; i++)
   {
    printf ("#%6d  Net:",i+1); 
    for (j=0; j LT nCols; j++)
     {
      printf("%9.6lf ",(double)Status[j+i*nCols]/Sat);
     }
    printf("  Target:");
    for (j=0; j LT nCols; j++)
     {
      printf("%9.6lf",(double)Target[j+i*nCols]/Sat);
     }
    printf("\n");
   }
}

/****************************************************************************/
/*                             OutResults()                                 */
/****************************************************************************/

void OutTot (int nRun, REAL TotAnaCost, REAL TotMaxCost, REAL TotDigCost)
 {
  printf ("\n##%6d  %.6lf  %.6lf  %.3f\n\n", nRun, (double) TotAnaCost,
						   (double) TotMaxCost,
						   (double) TotDigCost);  

 }


/****************************************************************************/
/*                         END OF FILE                                      */
/****************************************************************************/
