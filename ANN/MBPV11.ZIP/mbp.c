/****************************************************************************/
/*                           MBP.c                                          */
/****************************************************************************/
/* Written by: Davide Anguita                                               */
/*             University of Genova                                         */
/*             DIBE - Department of Biophysical and Electronic Engineering  */
/*             Via all'Opera Pia 11a                                        */
/*             16145 Genova, ITALY                                          */
/*             e-mail: anguita@dibe.unige.it                                */
/*             Tel:    +39-10-3532192                                       */
/*             Fax:    +39-10-3532175                                       */
/****************************************************************************/
/*                                                                          */
/* Matrix Back Propagation with Vogl acceleration.                          */
/*                                                                          */ 
/* USAGE:  MBP <configuration file>                                         */
/*                                                                          */ 
/* REVISION 1.1 - August 1993                                               */
/*                                                                          */
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include "random.h"
#include "mm.h"
#include "mbp.h"

/****************************************************************************/
/*                           main()                                         */
/****************************************************************************/

main(int argc, char* argv[])
 {
  BOOL   endMBP;          /* End MBP?                                       */
  BOOL   endRun;          /* End single run ?                               */
  BOOL   Test;            /* Test while learning ? (Cross-validation)       */
  BOOL   YProp;           /* YProp or Vogl algorithm ?                      */
	
  REAL   Sat   = 0.9;     /* [-1,+1] -> [-Sat,+Sat]                         */
  REAL   ASat  = 1.47;    /* Tanh(ASat) == Sat                              */
  REAL   R     = 2.0;     /* Range of initial weights                       */
  REAL   E0    = 0.75;    /* Initial learning step                          */
  REAL   A0    = 0.9;     /* Initial momentum                               */
  REAL   Psi   = 1.05;    /* Vogl's parameter psi                           */
  REAL   Beta  = 0.7;     /* Vogl's parameter beta                          */
  REAL   G     = 1.05;    /* Acceptance of error increase (Vogl)            */
  REAL   Ka    = 0.7;     /* Acceleration factor (YPROP)                    */
  REAL   Kd    = 0.07;    /* Deceleration factor (YPROP)                    */
  REAL   Eta;             /* Learning step                                  */
  REAL   Alpha;           /* Momentum                                       */

  REAL   GradTh;          /* Threshold on gradient norm                     */
  REAL   AnaTh;           /* Threshold on analog error   (t-o)^2            */
  REAL   MaxTh;           /* Threshold on maximum error  max|t-o|           */
  REAL   DigTh;           /* Threshold on digital error  sign(t*o) %        */
  long   IterTh;          /* Threshold on # of iterations per run           */
  int    RunTh;           /* Threshold on # of runs                         */

  int    nPrints;         /* # of iterations/prints  0=no output            */
  long   aSeed;           /* Initial seed of the random number generator    */

  REAL   GradientNorm;    /* Gradient norm                                  */
  REAL   AnaCost;         /* Analog cost                    (t-o)^2         */
  REAL   OldAnaCost;      /* Analog cost at step n-1                        */
  REAL   MaxCost;         /* Maximum absolute cost          max|t-o|        */
  REAL   DigCost;         /* Digital cost                   sign(t*o) %     */
  REAL   AnaTestCost=0.0; /* Analog cost for test patterns                  */
  REAL   MaxTestCost=0.0; /* Maximum absolute cost for test patterns        */
  REAL   DigTestCost=0.0; /* Digital cost for test patterns                 */
  long   nIter;           /* Iteration #                                    */
  int    nRun;            /* Run #                                          */

  REAL   BestAnaCost;    /* Best analog cost                                */
  REAL   BestMaxCost;    /* Best maximum absolute cost                      */
  REAL   BestDigCost;    /* Best digital cost                               */
  int    nBestAna;       /* Run # with best analog cost                     */
  int    nBestMax;       /* Run # with best max abs cost                    */
  int    nBestDig;       /* Run # with best digital cost                    */
  int    nSuccRun;       /* # of successfull runs                           */
  long   nSuccIter;      /* # of iterations of successfull runs             */        
  long   nTotIter;       /* # of total iterations                           */
 
  REAL** Status;         /* Neurons status for learning patterns            */
  REAL** StatusTest;     /* Neurons status for test patterns                */
  REAL** Weight;         /* Weights                                         */
  REAL** Bias;           /* Biases                                          */
  REAL** OldWeight;      /* Weights at step n-1                             */
  REAL** OldBias;        /* Biases at step n-1                              */
  REAL** Delta;          /* Error back-propagated                           */
  REAL** DeltaWeight;    /* Weight delta (gradient)                         */
  REAL** DeltaBias;      /* Bias delta (gradient)                           */
  REAL** OldDeltaWeight; /* Weight delta at step n-1                        */
  REAL** OldDeltaBias;   /* Bias delta at step n-1                          */
  REAL*  Target;         /* Target of learning patterns                     */
  REAL*  TargetTest;     /* Target of test patterns                         */
  REAL** StepWeight;     /* Weight updating step                            */
  REAL** StepBias;       /* Bias updating step                              */

  int    nLayer;         /* # of layers                                     */
  int*   nUnit;          /* # of neurons per layer                          */
  int    nIPattern;      /* # of input patterns                             */
  int    nTPattern;      /* # of test patterns                              */

  clock_t Start,End;     /* Speed measurements                              */

  FILE*  fInput;         /* File of learning patterns                       */
  FILE*  fTarget;        /* File of targets for learning patterns           */
  FILE*  fWeight;        /* File of weights and biases                      */
  FILE*  fInputTest;     /* File of test patterns                           */
  FILE*  fTargetTest;    /* File of targets for test patterns               */

  int    i;              

  /* Initialize and allocate everything (almost) */

  Init (&Status,       &StatusTest, &Weight,      &Bias,        &OldWeight,
	&OldBias,      &Delta,      &DeltaWeight, &DeltaBias,   &OldDeltaWeight,
	&OldDeltaBias, &Target,     &TargetTest,  &StepWeight,  &StepBias,
	&nLayer,       &nUnit,      &nIPattern,   &nTPattern,   &GradTh,
	&AnaTh,        &MaxTh,      &DigTh,       &IterTh,      &RunTh,
	&fInput,       &fTarget,    &fInputTest,  &fTargetTest, &fWeight,
	&Test,         &nPrints,    &aSeed,       Sat,          &YProp,
	argc,          argv);


  endMBP      = FALSE;
  nRun        = 0;
  BestAnaCost = MAXFLOAT;
  BestMaxCost = MAXFLOAT;
  BestDigCost = MAXFLOAT;
  nSuccRun    = 0;
  nSuccIter   = 0;
  nTotIter    = 0;

  /* Initialize the seed of the random number generator */

  InitRandom(aSeed);

  /* repeat for all the runs */

  while (NOT endMBP)
   {

    nIter      = 0;
    OldAnaCost = MAXFLOAT;
    Eta        = E0;
    endRun     = FALSE;

    /* Print initial information */

    OutStart (nRun+1);

    /* Compute a new starting point */

    for ( i=1; i LE nLayer; i++ )
     {
      RandomWeights (Weight[i], nUnit[i-1], nUnit[i], ASat*R/(nUnit[i-1]+1.0));
      RandomWeights (Bias[i],   nUnit[i], 1,          ASat*R/(nUnit[i-1]+1.0));
     }

    /* Start the timer */

    Start = clock();

    /* Start the learning */

    while (NOT endRun)
     {

      /* for each layer */

      for (i=1; i LE nLayer; i++)
       {

	/* compute the forward phase for the learning patterns */

	FeedForward (Status[i],   nIPattern,  nUnit[i],
		     Status[i-1], nIPattern,  nUnit[i-1],
		     Weight[i],   nUnit[i-1], nUnit[i],
		     Bias[i],     nUnit[i]);
	
	/* and the test patterns too */

	if (Test)
	 { 
	  FeedForward (StatusTest[i],   nTPattern,  nUnit[i],
		       StatusTest[i-1], nTPattern,  nUnit[i-1],
		       Weight[i],       nUnit[i-1], nUnit[i],
		       Bias[i],         nUnit[i]);
	 }
       }

      /* Back-propagate the error of the output layer */

      EBPLastLayer (Delta[nLayer],  nIPattern, nUnit[nLayer],
		    Target,         nIPattern, nUnit[nLayer],
		    Status[nLayer], nIPattern, nUnit[nLayer]);
       
      /* and the hidden layers */
			
      for (i=nLayer-1; i GE 1; i--)
       {
	EBP (Delta[i],    nIPattern, nUnit[i],
	     Delta[i+1],  nIPattern, nUnit[i+1],
	     Weight[i+1], nUnit[i],  nUnit[i+1],
	     Status[i],   nIPattern, nUnit[i]);
			 
       }

      /* Compute the gradient */

      for (i=1; i LE nLayer; i++)
       {
	Step (DeltaWeight[i], nUnit[i-1], nUnit[i],
	      Status[i-1],    nIPattern,  nUnit[i-1],
	      Delta[i],       nIPattern,  nUnit[i],
	      DeltaBias[i],   nUnit[i]);
       }

      /* Compute the costs and the gradient norm */

      DigCost  = ComputeDigitalCost (Target,         nIPattern, nUnit[nLayer],
				     Status[nLayer], nIPattern, nUnit[nLayer]);
      AnaCost  = ComputeAnalogCost  (Target,         nIPattern, nUnit[nLayer],
				     Status[nLayer], nIPattern, nUnit[nLayer]);
      MaxCost  = ComputeMaximumCost (Target,         nIPattern, nUnit[nLayer],
				     Status[nLayer], nIPattern, nUnit[nLayer]);
      GradientNorm = ComputeGradientNorm (DeltaWeight, DeltaBias, nUnit,
					  nLayer);

      /* for the test patterns too */

      if (Test)
       {
	AnaTestCost = ComputeAnalogCost (TargetTest, nTPattern, nUnit[nLayer],
					 StatusTest[nLayer], nTPattern, 
					 nUnit[nLayer]);
	MaxTestCost = ComputeMaximumCost (TargetTest, nTPattern, nUnit[nLayer],
					  StatusTest[nLayer], nTPattern,
					  nUnit[nLayer]);
	DigTestCost = ComputeDigitalCost (TargetTest, nTPattern, nUnit[nLayer],
					  StatusTest[nLayer], nTPattern,
					  nUnit[nLayer]);
       }

      /* Test if the actual cost is the best */

      if (AnaCost LT BestAnaCost)
       {
	BestAnaCost = AnaCost;
	nBestAna    = nRun+1;
       }
      if (MaxCost LT BestMaxCost)
       {
	BestMaxCost = MaxCost;
	nBestMax    = nRun+1;
       }
      if (DigCost LT BestDigCost)
       {
	BestDigCost = DigCost;
	nBestDig    = nRun+1;
       }
			
      /* Print the starting step */

      if (nIter EQ 0)
       {
	PrintStep ("\n#", nIter,        DigCost,     AnaCost,     MaxCost,
			  GradientNorm, DigTestCost, AnaTestCost, MaxTestCost,
			  Test);
       }
			
      /* and every nPrints steps */

      if (nPrints NE 0 AND nIter GT 0 AND (nIter % nPrints EQ 0))
       {
	PrintStep ("#", nIter,        DigCost,     AnaCost,     MaxCost,
			GradientNorm, DigTestCost, AnaTestCost, MaxTestCost,
			Test);
       }
      
      /* Test if a threshold has been reached */

      if (GradientNorm LE GradTh OR
	  DigCost      LE DigTh  OR
	  AnaCost      LE AnaTh  OR
	  MaxCost      LE MaxTh  OR
	  nIter        GE IterTh )
       {

	/* Stop the timer */

	End = clock();

	/* and the current run */        
	
	endRun = TRUE;

	/* Was this run successful ? */

	if (DigCost LE DigTh OR
	    AnaCost LE AnaTh OR
	    MaxCost LE MaxTh)
	 {
	  nSuccRun++;
	  nSuccIter += nIter;
	 }

	nRun++;
	nTotIter += nIter;

	/* End MBP ? */

	if (nRun GE RunTh)
	 {
	  endMBP = TRUE;
	 }

	/* Print the last step */

	PrintStep("\n##", nIter,        DigCost,     AnaCost,     MaxCost,
			  GradientNorm, DigTestCost, AnaTestCost, MaxTestCost,
			  Test);                                                      

	/* Print the speed of the lerning */
	
	OutTime (nIter+1, nLayer, nIPattern, nUnit,
		 (double)(End-Start)/CLOCKS_PER_SEC);

	/* Save the weights of this run */

	SaveWeights(fWeight, nLayer, Weight, Bias, nUnit);

       }
			
      /* else makes a step following the Vogl's or YPROP algorithm */
			
      else
       {
	
	/* If cost is better increase Eta */

	if (AnaCost LT OldAnaCost)
	 {
	  if (YProp)
	   {
	    Eta *= 1+Ka/(Ka+Eta);
	   }
	  else
	   {
	    Eta *= Psi;            
	   }
	  Alpha      = A0;
	  OldAnaCost = AnaCost;
	 }

	/* If cost is worse than a few percent decrease Eta
	   and zeroes momentum */

	else if (AnaCost LE G*OldAnaCost)
	 {
	  if (YProp)
	   {
	    Eta *= Kd/(Kd+Eta);
	   }
	  else
	   {
	    Eta *= Beta;
	   }
	  Alpha       = 0.0;
	  OldAnaCost = AnaCost;
	 }
 
	/* If cost is really worse, backstep */

	else
	 {
	  if (YProp)
	   {
	    Eta *= Kd/(Kd+Eta);
	   }
	  else
	   {
	    Eta *= Beta;
	   }
	  Alpha       = 0.0;
	  for (i=1; i LE nLayer; i++)
	   {
	    BackStep (DeltaWeight[i],    nUnit[i-1], nUnit[i],
		      DeltaBias[i],      nUnit[i],
		      OldDeltaWeight[i], nUnit[i-1], nUnit[i],
		      OldDeltaBias[i],   nUnit[i],
		      Weight[i],         nUnit[i-1], nUnit[i],
		      Bias[i],           nUnit[i],
		      StepWeight[i],     nUnit[i-1], nUnit[i],
		      StepBias[i],       nUnit[i]);
	   }
	 }

	/* Makes the learning step */

	for (i=1; i LE nLayer; i++)
	 {
	  UpdateWeights (StepWeight[i],     nUnit[i-1], nUnit[i],
			 StepBias[i],       nUnit[i],
			 Eta, Alpha,
			 DeltaWeight[i],    nUnit[i-1], nUnit[i],
			 DeltaBias[i],      nUnit[i],
			 OldDeltaWeight[i], nUnit[i-1], nUnit[i],
			 OldDeltaBias[i],   nUnit[i],
			 Weight[i],         nUnit[i-1], nUnit[i],
			 Bias[i],           nUnit[i]);
	 }
       }

      nIter++;
		
     }
   }
 
  /* Print final results */

  OutResults (fWeight,     BestDigCost, nBestDig,  BestAnaCost, nBestAna,
	      BestMaxCost, nBestMax,    nSuccIter, nRun,        nSuccRun,
	      nTotIter);

  return (0);
}



/****************************************************************************/
/*                         RandomWeights()                                  */
/****************************************************************************/

void RandomWeights (REAL *Matrix, int nRows, int nCols, REAL Range)
{
 int  i,j;
 
 for (i=0; i LT nCols; i++)
  {
   for (j=0; j LT nRows; j++)
    {
     Matrix[i+j*nCols] = Range*(REAL)(1.0-2.0*RandomNumber());
    }
  }
}

/****************************************************************************/
/*                           FeedForward()                                  */
/****************************************************************************/

void FeedForward (REAL *NewStatus, int nRowsNS, int nColsNS,
		  REAL *OldStatus, int nRowsOS, int nColsOS,
		  REAL *Weight,    int nRowsW,  int nColsW,
		  REAL *Bias,      int nElem)

{
 int i,j;

 /* Keep the compiler happy */

 IGNORE(nRowsW);
 IGNORE(nRowsOS);
 IGNORE(nElem);

 /* Fast matrix multiplication routine to compute neurons' net input */

 MM2x2PB (NewStatus, OldStatus, Weight, nRowsNS, nColsNS, nColsOS,
	  nColsOS,   nColsW, BLOCK_DIMENSION);

 /* Compute neurons' output */
	
 for (i=0; i<nRowsNS; i++)
  {
   for (j=0; j<nColsNS; j++)
    {
     NewStatus[i*nColsNS+j] = f(NewStatus[i*nColsNS+j]+Bias[j]);
    }
  }
}

/****************************************************************************/
/*                              f()                                         */
/****************************************************************************/

REAL f (REAL x)
{
 return (REAL)tanh((double)x);     /* Tanh */
 
 /* IF YOU WANT TO USE THE APPROXIMATION USE THE FOLLOWING CODE INSTEAD */
 /*
 REAL Lambda = 0.26037;
 REAL Xs     = 1.92033;
 REAL Ys     = 0.96016;

 if ( x GT Xs )
	return Ys;
 else if ( x LT -Xs )
	return -Ys;
 else if ( x GE 0.0 )
	return Ys-Lambda*(x-Xs)*(x-Xs);
 else
	return Lambda*(x+Xs)*(x+Xs)-Ys;
 */

}

/****************************************************************************/
/*                              df()                                        */
/****************************************************************************/

REAL df (REAL x)
{
 return (REAL)(1.0-x*x);      /* Tanh' */
}

/****************************************************************************/
/*                           EBPLastLayer()                                 */
/****************************************************************************/

void EBPLastLayer (REAL *Delta,      int nRowsD, int nColsD,
		   REAL *Target,     int nRowsT, int nColsT,
		   REAL *Status,     int nRowsS, int nColsS)
{
 int  i;

 /* Keep the compiler happy */

 IGNORE(nRowsT);
 IGNORE(nColsT);
 IGNORE(nRowsS);
 IGNORE(nColsS);

 /* Compute deltas */
	
 for (i=0; i LT nRowsD*nColsD; i++)
  {
   Delta[i] = 2.0/((REAL)(nRowsD*nColsD))*df(Status[i])*(Target[i]-Status[i]);
  }
}

/****************************************************************************/
/*                           EBP()                                          */
/****************************************************************************/

void EBP (REAL *NewDelta,   int nRowsND, int nColsND,
	  REAL *OldDelta,   int nRowsOD, int nColsOD,
	  REAL *Weight,     int nRowsW,  int nColsW,
	  REAL *Status,     int nRowsS,  int nColsS)
{
 int  i;

 /* Keep the compiler happy */

 IGNORE(nRowsS);
 IGNORE(nColsS);
 IGNORE(nRowsW);
 IGNORE(nRowsOD);

 /* Compute deltas of hidden neurons */

 MMT2x2P ( NewDelta, OldDelta, Weight, nRowsND, nColsND, nColsOD, nColsOD,
	   nColsW);

 for (i=0; i LT nRowsND*nColsND; i++)
  {
   NewDelta[i] *= df(Status[i]);
  }
}

/****************************************************************************/
/*                           Step()                                         */
/****************************************************************************/

void Step (REAL *DeltaWeight, int nRowsDW, int nColsDW,
	   REAL *Status,      int nRowsS,  int nColsS,
	   REAL *Delta,       int nRowsD,  int nColsD,
	   REAL *DeltaBias,   int nElemsDB)
{
 int i,j;

 /* Keep the compiler happy */

 IGNORE(nElemsDB);

 /* Compute the gradient */

 MTM2x2PB(DeltaWeight, Status, Delta, nRowsDW, nColsDW, nRowsS, nColsS, 
					nColsD, BLOCK_DIMENSION);

 for (i=0; i<nColsD; i++)
  {
   DeltaBias[i] = 0.0;
   for (j=0; j<nRowsD; j++)
    {
     DeltaBias[i] += Delta[j*nColsD+i];
    }
  }
}

/****************************************************************************/
/*                           ComputeDigitalCost()                           */
/****************************************************************************/

REAL ComputeDigitalCost (REAL *Target, int nRowsT, int nColsT,
			 REAL *Status, int nRowsS, int nColsS)
{
 int  i;
 REAL result = 0.0;

 /* Keep the compiler happy */
	
 IGNORE(nRowsS);
 IGNORE(nColsS);

 /* Compute the % of wrong answers of the net */

 for ( i=0; i LT nRowsT*nColsT; i++ )
  {
   if (Target[i]*Status[i] LE 0.0)
    {
     result += 100.0/(REAL)(nRowsT*nColsT);
    }
  }

 return result;
 
}

/****************************************************************************/
/*                           ComputeAnalogCost()                            */
/****************************************************************************/

REAL ComputeAnalogCost  (REAL *Target, int nRowsT, int nColsT,
			 REAL *Status, int nRowsS, int nColsS)
{
 int  i;
 REAL result = 0.0;

 /* Keep the compiler happy */

 IGNORE(nRowsS);
 IGNORE(nColsS);

 /* Compute the quadratic error of the net */

 for ( i=0; i LT nRowsT*nColsT; i++)
  {
   result += (Target[i]-Status[i])*(Target[i]-Status[i]);
  }
 result /= (REAL) (nRowsT*nColsT);

 return result;
}

/****************************************************************************/
/*                           ComputeMaximumCost()                           */
/****************************************************************************/

REAL ComputeMaximumCost (REAL *Target, int nRowsT, int nColsT,
			 REAL *Status, int nRowsS, int nColsS)
 {
  int  i;
  REAL result = 0.0;
  REAL diff;

  /* Keep the compiler happy */

  IGNORE(nRowsS);
  IGNORE(nColsS);

  /* Compute the maximum abs error of the net */

  for ( i=0; i LT nRowsT*nColsT; i++)
   {
    diff = Target[i] - Status[i];
    if (diff LT 0.0)
     {
      diff = -diff;
     }
    result = (result GT diff) ? result : diff;
   }
  return result;
 }

/****************************************************************************/
/*                           ComputeGradientNorm()                          */
/****************************************************************************/

REAL ComputeGradientNorm (REAL **DeltaWeight, REAL **DeltaBias,
													int   *nUnit,       int    nLayer)
 {
  int  i,j;
  REAL result = 0.0;
  REAL *pDeltaWeight;   /* Some pointers to speed things up */
  REAL *pDeltaBias;

  for ( i=1; i LE nLayer; i++ )
   {
    pDeltaWeight = DeltaWeight[i];
    pDeltaBias   = DeltaBias[i];
  
    for ( j=0; j LT nUnit[i]*nUnit[i-1]; j++)
     {
      result += (pDeltaWeight[j])*(pDeltaWeight[j]);
     }
    for ( j=0; j LT nUnit[i]; j++)
     {
      result += (pDeltaBias[j])*(pDeltaBias[j]);
     }
   }
	
  result = (REAL) sqrt((double)result);

  return result;

 }


/****************************************************************************/
/*                           BackStep()                                     */
/****************************************************************************/

void BackStep (REAL *DeltaWeight,    int nRowsDW,  int nColsDW,
	       REAL *DeltaBias,      int nElemsDB,
	       REAL *OldDeltaWeight, int nRowsODW, int nColsODW,
	       REAL *OldDeltaBias,   int nElemsODB,
	       REAL *Weight,         int nRowsW,   int nColsW,
	       REAL *Bias,           int nElemsB,
	       REAL *StepWeight,     int nRowsSW,  int nColsSW,
	       REAL *StepBias,       int nElemsSB)
{

 int i;

 /* Keep the compiler happy */

 IGNORE(nRowsODW);
 IGNORE(nColsODW);
 IGNORE(nElemsODB);
 IGNORE(nRowsW);
 IGNORE(nColsW);
 IGNORE(nElemsB);
 IGNORE(nRowsSW);
 IGNORE(nColsSW);
 IGNORE(nElemsSB);

 /* Makes a learning step back */

 for ( i=0; i LT nRowsDW*nColsDW; i++)
  {
   DeltaWeight[i] =  OldDeltaWeight[i];
   Weight[i]      -= StepWeight[i];
  }

 for ( i=0; i LT nElemsDB; i++)
  {
   DeltaBias[i] =  OldDeltaBias[i];
   Bias[i]      -= StepBias[i];
  }

}

/****************************************************************************/
/*                           UpdateWeights()                                */
/****************************************************************************/

void UpdateWeights (REAL *StepWeight,     int nRowsSW,  int nColsSW,
		    REAL *StepBias,       int nElemsSB,
		    REAL Eta, REAL Alpha,
		    REAL *DeltaWeight,    int nRowsDW,  int nColsDW,
		    REAL *DeltaBias,      int nRowsDB,
		    REAL *OldDeltaWeight, int nRowsODW, int nColsODW,
		    REAL *OldDeltaBias,   int nElemsODB,
		    REAL *Weight,         int nRowsW,   int nColsW,
		    REAL *Bias,           int nElemsW )
{

 int i;

 /* Keep the compiler happy */

 IGNORE(nRowsDW);
 IGNORE(nColsDW);
 IGNORE(nRowsDB);
 IGNORE(nRowsODW);
 IGNORE(nColsODW);
 IGNORE(nElemsODB);
 IGNORE(nRowsW);
 IGNORE(nColsW);
 IGNORE(nElemsW);

 /* A step in the right direction (hopefully) */
 
 for ( i=0; i LT nRowsSW*nColsSW; i++ )
  {
   OldDeltaWeight[i] = DeltaWeight[i];
   StepWeight[i]     = Eta*DeltaWeight[i] + Alpha*StepWeight[i];
   Weight[i]        += StepWeight[i];
  }
 
 for ( i=0; i LT nElemsSB; i++ )
  {
   OldDeltaBias[i] = DeltaBias[i];
   StepBias[i]     = Eta*DeltaBias[i] + Alpha*StepBias[i];
   Bias[i]        += StepBias[i];
  }
}


/****************************************************************************/
/*                         END OF FILE                                      */
/****************************************************************************/
