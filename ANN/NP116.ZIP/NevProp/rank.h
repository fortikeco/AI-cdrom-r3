#ifndef _RANK_H
#define _RANK_H


#include "const.h" /* define const if necessary */
#include "protoTyp.h"

/* write rank[i] as rank (1-based) of array[i].  Ties give average rank
   among tied elements. 
   E.g. array = {3, 3, 9, 2.8} gives rank = {2.5, 2.5, 4, 1}*/ 
extern void rankF proto(( /* `F' for float */
		  long n
		  , const float *array  /*  array[n]  */
		  , float *rank  /* rank[n] (elements written) */
		  ));

#endif /* _RANK_H */
