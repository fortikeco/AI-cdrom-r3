/* lets you declare functions as for example
       void myfunc proto((float **, int));
   and have this work in both ansi and traditional C

   Renamed from proto.h to protoArgs.h to avoid conflict with another
   proto.h distributed with gcc.
   Then renamed to protoTyp.h to be short enough for MS-DOS.

*/
   
#ifndef proto
#ifdef __STDC__
#define proto(a) a
#else
#define proto(a) ()
#endif /* __STDC__ */
#endif /* proto */
