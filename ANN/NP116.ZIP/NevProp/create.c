/* Copyright (C) 1991,1993 by David B. Rosen.  All rights reserved. */

#include "stdio.h"
#include "stdlib.h"

#include "create.h"

void _ncreate(ptrptr,size)
     void **ptrptr;
     unsigned long size; /* avoid size_t for pre-ansi  -DBR 5/93 */
{
    if (!(*ptrptr = (void *)malloc(size))) 
      {
	  fprintf(stderr,
	  "Memory allocation failure for %d bytes in _ncreate().  Exiting.\n",
		  (int)size);
	  exit(1);
      }
}

void _destroy(ptrptr)
     void **ptrptr;
{
  if (*ptrptr) free(*ptrptr);
  *ptrptr = (void *)0;
}
