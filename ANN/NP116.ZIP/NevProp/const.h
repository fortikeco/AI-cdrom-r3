/* define const as a null token for non-ansi C */
#ifndef __STDC__

#ifndef const
#define const
#endif

#endif
