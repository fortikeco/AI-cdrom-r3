// test.cpp : implementation file
//					Performs functionality of test dialog box. A forward pass
//					is performed with the input neurons set to the user's test input
//					In order to allow access to the document methods
//					to perform a forward pass through net, a pointer to
//					the document is passed to this dialog
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"
#include "test.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTest dialog

// pointer to document allows test to access the data and methods of
// CSimDoc through m_mydoc
CTest::CTest(CSimDoc& myDoc)
	: CDialog(CTest::IDD,NULL),m_myDoc(myDoc)
{
	//{{AFX_DATA_INIT(CTest)
	m_pTestOutput = NULL;
	m_pTestGrid = NULL;
    m_bSelChange = FALSE ;
	//}}AFX_DATA_INIT
}

void CTest::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTest)
	DDX_VBControl(pDX, IDC_TESTGRIDINPT, m_pTestOutput);
	DDX_VBControl(pDX, IDC_TEST, m_pTestGrid);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTest, CDialog)
	//{{AFX_MSG_MAP(CTest)
	ON_VBXEVENT(VBN_CLICK, IDC_TEST, OnClickTest)
	ON_VBXEVENT(VBN_ROWCOLCHANGE, IDC_TEST, OnRowcolchangeTest)
	ON_VBXEVENT(VBN_GOTFOCUS, IDC_TEST, OnGotfocusTest)
	ON_VBXEVENT(VBN_SELCHANGE, IDC_TEST, OnSelchangeTest)
	ON_EN_CHANGE(IDC_TESTEDIT, OnChangeTestedit)
	ON_BN_CLICKED(IDC_TESTBUTTON, OnClickedTestbutton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest message handlers

BOOL CTest::OnInitDialog()
{
    m_TestEdit.SubclassDlgItem(IDC_TESTEDIT,this) ;
	
	CDialog::OnInitDialog();
    
    int nRows = (int)m_pTestGrid->GetNumProperty("Rows") ;
    int nCols = (int)m_pTestGrid->GetNumProperty("Cols") ;
    
    // Initialise column heading
	m_pTestGrid->SetNumProperty("Row",0) ;
	m_pTestGrid->SetNumProperty("Col",0) ;
	m_pTestGrid->SetStrProperty("Text","Input") ;

	m_pTestOutput->SetNumProperty("Row",0) ;
	m_pTestOutput->SetNumProperty("Col",0) ;
	m_pTestOutput->SetStrProperty("Text","Output") ;

	m_pTestGrid->SetNumProperty("Row",1) ; // set focus to first cell in input grid
	m_pTestGrid->SetNumProperty("Col",1) ;          

	m_pTestOutput->SetNumProperty("Row",1) ; // set focus to first cell in input grid
	m_pTestOutput->SetNumProperty("Col",1) ;          
	
	return FALSE ;  // return TRUE  unless you set the focus to a control
}
 

#define TWIPS_PER_INCH 1440


// Returns the position of the top-left corner of a cell. Asking for
// nRow == maxRow and nCol == maxCol will give the extent of the grid
CPoint CTest::FindCellPosition(int nRow, int nCol, CVBControl* Grid)
{
	ASSERT (nRow >= 0 && nRow <= Grid->GetNumProperty("Rows")) ;
	ASSERT (nCol >= 0 && nCol <= Grid->GetNumProperty("Cols")) ;
	
	CPoint ptPos(0,0) ;
	
	// Get left edge of requested cell by summing widths of previous cells
	int nLeftCol = (int)Grid->GetNumProperty("LeftCol") ;
	int nLeftFix = (int)Grid->GetNumProperty("FixedCols") ;
	
	for (int i = 0 ; i < nCol ; i++)
		{
				if (i < nLeftFix || i >= nLeftCol) // only count displayed cells
				   {
				   		ptPos.x += (int)Grid->GetNumProperty("ColWidth",i) ;
				   }
		}
		
	// Get top edge of requested cell by summing Heights of previous cells
	int nTopRow = (int)Grid->GetNumProperty("TopRow") ;
	int nTopFix = (int)Grid->GetNumProperty("FixedRows") ;
	for (i = 0 ; i < nRow ; i++)
	    {
	    		if (i < nTopFix || i >= nTopRow) // only count displayed cells
	    		   {
	    		   		ptPos.y += (int)Grid->GetNumProperty("RowHeight",i) ;
	    		   }
	    }
	    
	// ptPos is now in LOGICAL TWIPs
	// convert to pixels
	
	CClientDC dc(this) ;
	
	ptPos.x = MulDiv(ptPos.x,dc.GetDeviceCaps(LOGPIXELSX),TWIPS_PER_INCH) ;
	ptPos.y = MulDiv(ptPos.y,dc.GetDeviceCaps(LOGPIXELSY),TWIPS_PER_INCH) ;
	
	ptPos.x += (nCol - (nLeftCol- 1)) ; // add one pixel per column for gap
	ptPos.y += (nRow - (nTopRow - 1)) ; // mod nTopRow to allow for scrolling
	
	return ptPos ;
}


void CTest::PositionEdit(CVBControl* Grid)
{
	int nRow = (int)Grid->GetNumProperty("Row") ;
	int nCol = (int)Grid->GetNumProperty("Col") ;
	int nTopRow = (int)Grid->GetNumProperty("TopRow") ;
	int nLeftCol = (int)Grid->GetNumProperty("LeftCol") ;
	
	CPoint ptPos = FindCellPosition(nRow,nCol,Grid) ;
	
	CClientDC dc(this) ;
	
	int nWidth = MulDiv((int)Grid->GetNumProperty("ColWidth",nCol),
					(int)dc.GetDeviceCaps(LOGPIXELSX),TWIPS_PER_INCH) + 2 ;
	
	int nHeight = MulDiv((int)Grid->GetNumProperty("RowHeight",nRow),
					(int)dc.GetDeviceCaps(LOGPIXELSY),TWIPS_PER_INCH) + 2 ;				
	
	// Adjust for Grid position and scroll position
	
	ptPos.x += (int)Grid->GetNumProperty("Left") ;
	ptPos.y += (int)Grid->GetNumProperty("Top") ;
	
	m_TestEdit.MoveWindow(ptPos.x,ptPos.y,nWidth,nHeight,TRUE) ;
	
	CString s = Grid->GetStrProperty("Text") ;
	m_TestEdit.SetWindowText(s) ; // set to reflect cell's data
	

 	if ((nRow - nTopRow) <= 5)
	   {
			m_TestEdit.ShowWindow(SW_SHOW) ;
	   }
	else
	   {
	   		m_TestEdit.ShowWindow(SW_HIDE) ;
	   }
	
 	Grid->SetNumProperty("SelStartRow",nRow) ;	
	Grid->SetNumProperty("SelStartCol",nCol) ;
	Grid->SetNumProperty("SelEndRow", nRow) ;
	Grid->SetNumProperty("SelEndCol", nCol) ;
	
	m_TestEdit.SetSel(0,-1) ;
	m_TestEdit.Invalidate() ;
	m_TestEdit.SetFocus() ;
}
           
 
void CTest::OnClickTest(UINT, int, CWnd*, LPVOID)
{
	PositionEdit(m_pTestGrid) ;
}
 
 
void CTest::OnRowcolchangeTest(UINT, int, CWnd*, LPVOID)
{
	PositionEdit(m_pTestGrid) ;
}
                               
                               
void CTest::OnGotfocusTest(UINT, int, CWnd*, LPVOID)
{
	m_TestEdit.SetFocus() ;  // Give focus to edit control
	m_TestEdit.SetSel(0,-1) ;
}
                                                          
                                                          
void CTest::OnSelchangeTest(UINT, int, CWnd*, LPVOID)
{
	m_bSelChange = TRUE ;
}                        


void CTest::OnChangeTestedit()
{
	CString m_str ;
	
	m_TestEdit.GetWindowText(m_str) ;
	m_pTestGrid->SetStrProperty("Text",m_str) ;
	   
	int nRow = (int)m_pTestGrid->GetNumProperty("Row") ;
                                          
	// Remember to change range from 1->40 to 0->39 for array 	
	m_TestData[nRow-1] = atoi(m_str) ;
}


void CTest::OnClickedTestbutton()
{   
	int row, col ;
    
    row = 0 ; col = 0 ;
	// put the input pattern directly into the input neuron's output queues
	for (int atNeuron = 0 ; atNeuron < m_myDoc.nInLayer[0] ; atNeuron++)
		{                                                       
			m_myDoc.neuron[0][atNeuron]->output = m_TestData[atNeuron] ;
		}

	// feed forward for each layer
	int cnxnNumber = 0 ;
	int offset = 0 ;
	for (int atLayer = 1 ; atLayer <= m_myDoc.nLayers - 1 ; atLayer++)
		{
			int nCons = m_myDoc.nInLayer[atLayer] * m_myDoc.nInLayer[atLayer - 1] ;
	   		   				
			for (cnxnNumber = offset ; cnxnNumber < nCons + offset ; cnxnNumber++)
				{
					m_myDoc.cnxn[cnxnNumber].feedForward() ;
				}
	   		   				
			offset += nCons ;
	   		   				
			for (atNeuron = 0 ; atNeuron < m_myDoc.nInLayer[atLayer] ; atNeuron++)
				{
					m_myDoc.neuron[atLayer][atNeuron]->transfer() ;
				}
		}
    
    int lastLayer = m_myDoc.nLayers - 1 ;
	char buf[10] ;
	int nRow = 1 ;
	m_pTestOutput->SetNumProperty("Col",1) ;
	
	// display output in output grid in dialog box
	for (int outNeuron = 0 ; outNeuron < m_myDoc.nInLayer[lastLayer] ; outNeuron++)
		{   
			m_pTestOutput->SetNumProperty("Row",nRow++) ;
			
			sprintf(buf,"%f",m_myDoc.neuron[lastLayer][outNeuron]->output) ;
			m_pTestOutput->SetStrProperty("Text",buf) ;
		}
}
