// traindat.cpp : implementation file
// 					This was originally a dialog box which has been incorporated into
//					the view (see viewnetv.cpp). All aspects of the grid view are dealt
//					with by this class.
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"
#include "traindat.h"
#include "simdoc.h"
#include "simview.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTrainData

// implements the functionality of the grid in the main view

IMPLEMENT_DYNCREATE(CTrainData, CFormView)

CTrainData::CTrainData()
	: CFormView(CTrainData::IDD)
{   
	m_bInitialised = FALSE ;
	m_bEventLockout = FALSE ;
	m_bSelChange = FALSE ;
	m_bSubclassed = FALSE ;
	
	//{{AFX_DATA_INIT(CTrainData)
	m_pGrid = NULL;
	//}}AFX_DATA_INIT
}

CTrainData::~CTrainData()
{
}

void CTrainData::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTrainData)
	DDX_VBControl(pDX, IDC_TRAINDATA, m_pGrid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTrainData, CFormView)
	//{{AFX_MSG_MAP(CTrainData)
	ON_VBXEVENT(VBN_ROWCOLCHANGE, IDC_TRAINDATA, OnRowcolchange)
	ON_VBXEVENT(VBN_SELCHANGE, IDC_TRAINDATA, OnSelchange)
	ON_VBXEVENT(VBN_GOTFOCUS, IDC_TRAINDATA, OnGotfocus)
	ON_VBXEVENT(VBN_CLICK, IDC_TRAINDATA, OnClick)
	ON_EN_CHANGE(IDC_GRIDEDIT, OnChangeGridedit)
	ON_EN_UPDATE(IDC_GRIDEDIT, OnUpdateGridedit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrainData message handlers

void CTrainData::OnInitialUpdate() // first time after construct
{
	// subclass the edit control (once)
	if (!m_bSubclassed)
	   {
	   		m_edit.SubclassDlgItem(IDC_GRIDEDIT, this) ;
	   		m_bSubclassed = TRUE ;
	   }
    
    CFormView::OnInitialUpdate() ; // tie into document
	
	CSimDoc* sDoc = (CSimDoc*) GetDocument();
	
	if (!m_bInitialised)
	   {
	   		int nRows = (int)m_pGrid->GetNumProperty("Rows") ;
	   		int nCols = (int)m_pGrid->GetNumProperty("Cols") ;
	   		char buf[80] ;
	   		
	   		// initialise row headings
	   		m_pGrid->SetNumProperty("Col",0) ;
	   		for (int nRow = 1 ; nRow < nRows ; nRow++)
	   		    {
	   		    	wsprintf(buf,"%d",nRow) ;
	   		    	m_pGrid->SetNumProperty("Row",nRow) ;
	   		    	m_pGrid->SetStrProperty("Text",buf) ;
	   		    }
	   		    
	   		// initialise column headings
	   		m_pGrid->SetNumProperty("Row",0) ;
	   		for (int nCol = 1 ; nCol < nCols ; nCol++)
	   			{
	   				if (nCol % 2 == 1)
	   					wsprintf(buf,"I") ;
	   				else
	   					wsprintf(buf,"O") ;
	   				m_pGrid->SetNumProperty("Col",nCol) ;
	   				m_pGrid->SetStrProperty("Text",buf) ;
	   			}
	   			
	   		m_pGrid->SetNumProperty("Row",1) ;
	   		m_pGrid->SetNumProperty("Col",1) ;
	   }
	
	char buf[10] ;                                 
	
	if (sDoc->GetDataPresent())
	   {
	   	   // if data is present then populate the grid data structure
	   	   int i ;
	   	   div_t  num ;
	   	   for (int atPattern = 0 ; atPattern < sDoc->nPatterns ; atPattern++) 
	   	       {         
	   	       		for (i = 0 ; i < sDoc->nInLayer[0] ; i++)
	   	       			{                 
	   	       				num = div(i,sDoc->nInLayer[0]) ;
	   						m_pGrid->SetNumProperty("Row",i + 1) ;
	   						m_pGrid->SetNumProperty("Col",(atPattern * 2) + 1) ;
	   						sprintf(buf,"%lf",sDoc->pat[atPattern].in[i]) ;
	   						m_pGrid->SetStrProperty("Text",buf) ;
	   	       			} 
			   	       			
	   	       		for (i = 0 ; i < sDoc->nInLayer[sDoc->nLayers-1] ; i++)
	   	       			{ 
	   	       				num = div(i,sDoc->nInLayer[sDoc->nLayers-1]) ;
	   						m_pGrid->SetNumProperty("Row",i + 1) ;
	   						m_pGrid->SetNumProperty("Col",(atPattern * 2) + 2) ;
	   						sprintf(buf,"%lf",sDoc->pat[atPattern].out[i]) ;
	   						m_pGrid->SetStrProperty("Text",buf) ;
	   	       			}
	   	       		
			   }

	   }
	
	SetDlgItemInt(IDC_TRAINPATTERNS,sDoc->nPatterns,TRUE) ;
	m_bInitialised = TRUE ;	   

	PositionEdit() ;
}

#define TWIPS_PER_INCH 1440
       
CPoint CTrainData::FindCellPosition(int nRow,int nCol)
{
	ASSERT (nRow >= 0 && nRow <= m_pGrid->GetNumProperty("Rows")) ;
	ASSERT (nCol >= 0 && nCol <= m_pGrid->GetNumProperty("Cols")) ;
	
	CPoint ptPos(0,0) ;
	
	// Get left edge of requested cell by summing widths of previous cells
	int nLeftCol = (int)m_pGrid->GetNumProperty("LeftCol") ;
	int nLeftFix = (int)m_pGrid->GetNumProperty("FixedCols") ;
	
	for (int i = 0 ; i < nCol ; i++)
		{
			if (i < nLeftFix || i >= nLeftCol) // only count displayed cells
			   ptPos.x += (int)m_pGrid->GetNumProperty("ColWidth",i) ;
		}
		
	// Get top edge of requested cell by summing heights of previous cells
	int nTopRow = (int)m_pGrid->GetNumProperty("TopRow") ;
	int nTopFix = (int)m_pGrid->GetNumProperty("FixedRows") ;
	for (i = 0 ; i < nRow ; i++)
		{
			if (i < nTopFix || i >= nTopRow) // only count displayed cells
			   ptPos.y += (int)m_pGrid->GetNumProperty("RowHeight",i) ;
		}
		
	// ptPos is now in logical TWIPS
	// convert to pixels
	
	CClientDC dc(this) ;
	
	ptPos.x = MulDiv(ptPos.x, dc.GetDeviceCaps(LOGPIXELSX),TWIPS_PER_INCH) ;
	ptPos.y = MulDiv(ptPos.y, dc.GetDeviceCaps(LOGPIXELSY),TWIPS_PER_INCH) ;
	
	ptPos.x += nCol ; // add one pixel per column for gap
	ptPos.y += nRow ; // add one pixel per row for gap
	
	return ptPos ;
}


void CTrainData::PositionEdit()
{
	int nRow = (int)m_pGrid->GetNumProperty("Row") ;
	int nCol = (int)m_pGrid->GetNumProperty("Col") ;
	
	CPoint ptPos = FindCellPosition(nRow,nCol) ;
	
	CClientDC dc(this) ;
	
	int nWidth = MulDiv((int)m_pGrid->GetNumProperty("ColWidth",nCol),
						(int)dc.GetDeviceCaps(LOGPIXELSX),TWIPS_PER_INCH) + 2 ;
	int nHeight = MulDiv((int)m_pGrid->GetNumProperty("RowHeight",nRow),
						(int)dc.GetDeviceCaps(LOGPIXELSY),TWIPS_PER_INCH) + 2 ;
						
	// adjust for grid position and scroll position
	
	ptPos.x += (int)m_pGrid->GetNumProperty("Left") ;
	ptPos.y += (int)m_pGrid->GetNumProperty("Top") ;
	
	m_edit.MoveWindow(ptPos.x,ptPos.y,nWidth,nHeight,TRUE) ;
	
	m_bEventLockout = TRUE ;
	
	CString s = m_pGrid->GetStrProperty("Text") ;
	m_edit.SetWindowText(s) ;

	m_bEventLockout = FALSE ;
	
	m_edit.ShowWindow(SW_SHOW) ;
	m_edit.SetSel(0,-1) ;
	m_edit.Invalidate() ;
}
	
                                                                
void CTrainData::OnRowcolchange(UINT, int, CWnd*, LPVOID)
{
	if (m_bEventLockout)
		return ;
		
	PositionEdit() ;
}

void CTrainData::OnSelchange(UINT, int, CWnd*, LPVOID)
{
	if (m_bEventLockout)
		return ;

	m_bSelChange = TRUE ;
}

void CTrainData::OnGotfocus(UINT, int, CWnd*, LPVOID)
{
	if (m_bEventLockout)
		return ;
		
	m_edit.SetFocus() ;
	m_edit.SetSel(0,-1) ;	
}

void CTrainData::OnClick(UINT, int, CWnd*, LPVOID)
{
	if (m_bEventLockout)
		return ;
		
	PositionEdit() ;
}

////////////////////////////////////////////////////////////////////// 
// CMyEdit

CMyEdit::CMyEdit()
{
}

CMyEdit::~CMyEdit()
{
}

BEGIN_MESSAGE_MAP(CMyEdit,CWnd)
	//{{AFX_MSG_MAP(CMyEdit)
	ON_WM_GETDLGCODE()
	ON_WM_KEYDOWN()
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////////////////

UINT CMyEdit::OnGetDlgCode()
{
	return CEdit::OnGetDlgCode() | DLGC_WANTALLKEYS ;
}

void CMyEdit::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == VK_UP || nChar == VK_DOWN)
		ProcessKeys(nChar) ;
	else
		CEdit::OnKeyDown(nChar, nRepCnt, nFlags) ;
}

void CMyEdit::OnChar(UINT nChar,UINT nRepCnt,UINT nFlags)
{
	if (!ProcessKeys(nChar))
		CEdit::OnChar(nChar,nRepCnt,nFlags) ;
}

BOOL CMyEdit::ProcessKeys(UINT nChar)
{
	CTrainData* pParent = (CTrainData*)GetParent() ;
	CVBControl* pGrid = pParent->m_pGrid ;
    
	int nRow = (int)pGrid->GetNumProperty("Row") ;
	int nCol = (int)pGrid->GetNumProperty("Col") ;
	int nRows = (int)pGrid->GetNumProperty("Rows") ;
	int nCols = (int)pGrid->GetNumProperty("Cols") ;
	int nFirstRow = (int)pGrid->GetNumProperty("FixedRows") ;
	int nFirstCol = (int)pGrid->GetNumProperty("FixedCols") ;
	
	int nOldCol = nCol ;
	
	switch (nChar)
	{
		case VK_TAB:
				if (GetKeyState(VK_SHIFT) & 0x8000) // is it a back-tab?
					nCol-- ;
				else
					nCol++ ;
				break ;
		case VK_RETURN:
				nCol++ ;
				break ;
		case VK_UP:
				nRow-- ;
				break ;
		case VK_DOWN:
				nRow++ ;
				break ;
		default:
				return FALSE ;
	}
	
	if (nCol >= nCols) // moved off right edge
	   {
	   		nCol = nFirstCol ;
	   		nRow++ ;
	   }
	   
	if (nCol < nFirstCol) // moved off left edge
	   {
	   		nCol = nCols - 1 ;
	   		nRow-- ;
	   }
	   
	if (nRow < nFirstRow)
	   nRow = nRows - 1 ;
	   
	if (nRow >= nRows)
	   nRow = nFirstRow ;
	   
	pGrid->SetNumProperty("Row",nRow) ;
	pGrid->SetNumProperty("Col",nCol) ;
	pGrid->SetNumProperty("SelStartCol",nCol) ;
	pGrid->SetNumProperty("SelEndCol",nCol) ;
	pGrid->SetNumProperty("SelStartRow",nRow) ;
	pGrid->SetNumProperty("SelEndRow",nRow) ;
	return TRUE ;
}


void CTrainData::OnChangeGridedit()
{                                        
	char buf[20] ;
	
	if (m_bEventLockout)
		return ;
		
	BOOL bValid ;
	int nValue = GetDlgItemText(IDC_GRIDEDIT,buf,20) ;
	
	if (!bValid)
		return ;
	
	m_pGrid->SetStrProperty("Text",buf) ;
}


void CTrainData::OnUpdateGridedit()
{
    CSimDoc* sDoc = (CSimDoc*) GetDocument() ;
	sDoc->SetGridModified(TRUE) ;
}

void CTrainData::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint)
{
    CSimDoc* sDoc = (CSimDoc*) GetDocument() ;

    if (sDoc->GetNewDocument())
       {    
			m_pGrid->SetNumProperty("SelStartRow",1) ;
			m_pGrid->SetNumProperty("SelEndRow",40);
			m_pGrid->SetNumProperty("SelStartCol",1);
			m_pGrid->SetNumProperty("SelEndCol",40) ;
			m_pGrid->SetStrProperty("Clip","\t");
			m_pGrid->SetNumProperty("SelStartRow",1) ;
			m_pGrid->SetNumProperty("SelEndRow",1);
			m_pGrid->SetNumProperty("SelStartCol",1);
			m_pGrid->SetNumProperty("SelEndCol",1) ;

			SetDlgItemInt(IDC_TRAINPATTERNS,0,TRUE) ;
	
			m_pGrid->SetNumProperty("Row",1) ;
			m_pGrid->SetNumProperty("Col",1) ;
			PositionEdit() ;
					
 			sDoc->SetNewDocument(FALSE) ;
 			sDoc->SetTDPresent(FALSE) ;
 	   }
}
