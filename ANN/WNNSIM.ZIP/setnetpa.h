// setnetpa.h : header file
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#ifndef __SIMDOC_H__
#define __SIMDOC_H__
#include "simdoc.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetNetParams dialog

class CSetNetParams : public CDialog
{
// Construction
public:
	CSetNetParams(CWnd* pParent = NULL);	// standard constructor
    
    BOOL  ParamsPresent ; // indicates whether to initialise values to 0 or use defined value
    float m_nSamadCoeff ;
    float m_nMomentum ;
    float m_nAccError ;
    float m_nLearnConst ;
    
// Dialog Data
	//{{AFX_DATA(CSetNetParams)
	enum { IDD = IDD_NETPARAMS };
	//}}AFX_DATA
                               
// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CSetNetParams)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
