// simdoc.h : interface of the CSimDoc class
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

const int M_FACTOR = 5 ; // this scales the input to the neuron
const int MAX_LAYERS = 20 ;
const int MAX_NEURONS = 60 ;
const int ALLOC_ERR = 5 ;

struct Pattern
{
	int getMem(int inSize,int outSize) 
		{ in = new float[inSize] ; out = new float[outSize] ; return TRUE ; }
	float* in  ;
	float* out ;
} ;

//////////////////////////////////////////////////////////////////////////////////////

class Neuron
{           
public:
	Neuron(void) ;
	void setZero(void) ;
	void transfer() ;
	float derivTransfer(float) ;
	void sumOfErrors(float) ;
	float input ;
	float output;
	float error ;
} ;


struct Connection
{
	void set(Neuron*, Neuron*) ;
	void setRandom(float, float, float) ;
	void displaySelf(void) ;
	void feedForward(void) ;
	float weight ;
	float delta ;
	Neuron* n1 ;
	Neuron* n2 ;
	void adjust(void) ;
	inline int firstNeuronIs(Neuron* n) ;
	inline int secondNeuronIs(Neuron* n) ;
   	float learningConstant ;
	float samadCoefficient ;
	float momentum ;
} ;

/////////////////////////////////////////////////////////////////////////////

class CSimDoc : public CDocument
{
protected: // create from serialization only
	CSimDoc() ;
	DECLARE_DYNCREATE(CSimDoc)

// Attributes
public:
	Neuron* neuron[MAX_LAYERS][MAX_NEURONS] ;
	int nLayers ;	
	int nCnxns, nNeurons ;
	int* nInLayer ;
	int nPatterns, tmpnPatterns ;
	int atPattern ;
	int inWidth, inDepth, outWidth, outDepth ;
	long iteration ;
	Pattern* pat ;
	float acceptableError ;
	float thisPatternError ;
	float totalError ;
    Connection* cnxn ;
    
    float DocAcceptableError, DocMomentum ;
    float DocSamadCoefficient, DocLearningConstant ;
    
    int m_WatchBoxContents[20] ; // hold list box contents
	int m_nCnxnsToWatch ;
    float Scale ;
    BOOL m_bDirtyGraph ;
    
    CSize m_sizeDoc ;
    
	void adjustWeights(void) ;
	void calcOutputError(void) ;
	void calcMiddleError(void) ;
	
	int DeallocateMem(BOOL m_bnInLayers,BOOL m_bCnxns,BOOL m_bNeurons,BOOL m_bPatterns) ;
	void ReadFile(char*, CArchive&) ;
	
	CSize	GetDocSize()			{ return m_sizeDoc 			  ; }
	
	BOOL	GetLayersAlloc()		{ return m_bLayersAlloc       ; } // indicates dynamic allocation of layers
	BOOL	GetCnxnAlloc()			{ return m_bCnxnAlloc         ; } // dynamic allocation of connections
	BOOL	GetNeuronAlloc()		{ return m_bNeuronAlloc       ; } // dynamic allocation of neurons
	BOOL	GetPatternAlloc()		{ return m_bPatternAlloc      ; } // dynamic allocation of patterns
	BOOL	GetRunStatus()			{ return m_bRunning           ; } // training in progress?
	BOOL	GetCDPresent()			{ return m_bConfigDataPresent ; } // layer configuration data present?
	BOOL	GetNetParams()			{ return m_bNetParamsDefined  ; } // samad coeff etc defined?
	BOOL	GetTDPresent()			{ return m_bTrainDataPresent  ; } // training data present? 
	BOOL	GetNewDocument()		{ return m_bNewDocument       ; } // New network being configured?
	BOOL	GetDataPresent()		{ return m_bDataPresent		  ; } // data present?
	BOOL	GetWatchData()			{ return m_bWatchDataPresent  ; } // watch connection data present?
	BOOL	GetGridModified()		{ return m_bGridModified      ; } // has the grid been modified?
	BOOL	GetSuspended()		    { return m_bSuspended         ; } // has training been suspended?
	BOOL	GetTraining()			{ return m_bTraining          ; } // is training in pogress?
	
	void	SetLayersAlloc(BOOL yorn)  { m_bLayersAlloc       = yorn ; }
	void 	SetCnxnAlloc(BOOL yorn)    { m_bCnxnAlloc         = yorn ; }
	void 	SetNeuronAlloc(BOOL yorn)  { m_bNeuronAlloc       = yorn ; }
	void 	SetPatternAlloc(BOOL yorn) { m_bPatternAlloc      = yorn ; }
	void    SetWDPresent(BOOL yorn)    { m_bWatchDataPresent  = yorn ; }                                                               
	void	SetRunStatus(BOOL yorn)    { m_bRunning           = yorn ; }
	void	SetCDPresent(BOOL yorn)	   { m_bConfigDataPresent = yorn ; }
	void	SetNetParams(BOOL yorn)	   { m_bNetParamsDefined  = yorn ; }
	void	SetTDPresent(BOOL yorn)	   { m_bTrainDataPresent  = yorn ; }
	void	SetNewDocument(BOOL yorn)  { m_bNewDocument       = yorn ; }
	void	SetDataPresent(BOOL yorn)  { m_bDataPresent 	  = yorn ; }
	void	SetGridModified(BOOL yorn) { m_bGridModified      = yorn ; }
	void	SetSuspended(BOOL yorn)    { m_bSuspended         = yorn ; }
	void	SetTraining(BOOL yorn)     { m_bTraining          = yorn ; }
	
	void 	forwardPass(void)  ;
	void	backwardProp(void) ;
	void	allForward(void)   ;
	BOOL	atEpochEnd(void)   ;
	BOOL	trained(void)      ;
		
// Implementation
public: 
	int		InitLayers() ;
	int		InitCnxns() ;
	int		InitPatterns() ;
	int		InitNeurons() ;
	virtual ~CSimDoc();
	virtual void Serialize(CArchive& ar);	// overridden for document i/o
#ifdef _DEBUG
	virtual	void AssertValid() const;
	virtual	void Dump(CDumpContext& dc) const;
#endif

private:                                                                
	BOOL	m_bLayersAlloc      ; // Has nInLayers been allocated memory?
	BOOL	m_bCnxnAlloc        ; // Has connection memory been dynamically allocated
	BOOL	m_bNeuronAlloc      ; // Has neuron memory been allocated
	BOOL	m_bPatternAlloc		; // Has pattern memory been allocated
	BOOL	m_bRunning          ; // Simulation is running 
	BOOL	m_bConfigDataPresent; // Training data has been input
	BOOL	m_bNetParamsDefined ; // Have the network parameters been input?
	BOOL	m_bTrainDataPresent ; // Is there any training data?
    BOOL	m_bNewDocument      ; // New document ?
    BOOL	m_bDataPresent      ; // To decide how to populate dialog boxes
    BOOL    m_bWatchDataPresent ; // data in watch box?
    BOOL	m_bGridModified     ; // has anything been entered in the grid?
    BOOL	m_bSuspended        ; // Has simulation been stopped before trained?
    BOOL	m_bTraining         ; // Has network training been started?
              
protected:
	void			InitDocument()  ;
	virtual	BOOL	OnNewDocument() ;
	virtual BOOL 	OnOpenDocument(const char* pszPathName) ;

// Generated message map functions
protected:
	//{{AFX_MSG(CSimDoc)
	afx_msg void OnFileNew();
	afx_msg void OnSetnetparams();
	afx_msg void OnTest();
	afx_msg void OnWatch();
	afx_msg void OnImageZoomin();
	afx_msg void OnImageZoomout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
                                
	
	
	