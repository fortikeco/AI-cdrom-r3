// traindat.h : header file
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

/////////////////////////////////////////////////////////////////////////////
// CTrainData form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif


/////////////////////////////////////////////////////////////////////////////
// CMyEdit window

class CMyEdit : public CEdit
{
// Construction
public:
	CMyEdit();

// Attributes
public:

// Operations
public:

// Implementation
public:
	virtual ~CMyEdit();
	BOOL ProcessKeys(UINT nChar) ;
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CMyEdit)
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

class CTrainData : public CFormView
{
	DECLARE_DYNCREATE(CTrainData)
protected:
	CTrainData();	// protected constructor used by dynamic creation

	BOOL	m_bSubclassed ;    
    BOOL 	m_bInitialised ;
    BOOL 	m_bEventLockout ;
    BOOL	m_bSelChange ;
    CMyEdit m_edit ;

// Form Data
public:
	//{{AFX_DATA(CTrainData)
	enum { IDD = IDD_TRAINDATA };
	CVBControl*	m_pGrid;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Implementation
protected:
	void PositionEdit() ;
	CPoint FindCellPosition(int nRow, int nCol) ;
	
	virtual ~CTrainData();
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual void OnInitialUpdate() ; // first time after construct
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	
	// Generated message map functions
	//{{AFX_MSG(CTrainData)
	afx_msg void OnRowcolchange(UINT, int, CWnd*, LPVOID);
	afx_msg void OnSelchange(UINT, int, CWnd*, LPVOID);
	afx_msg void OnGotfocus(UINT, int, CWnd*, LPVOID);
	afx_msg void OnClick(UINT, int, CWnd*, LPVOID);
	afx_msg void OnChangeGridedit();
	afx_msg void OnUpdateGridedit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
 
