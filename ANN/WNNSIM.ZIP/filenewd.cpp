// filenewd.cpp : implementation file
// 					Functionality of the network configuration dialog box
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"
#include "newdlg.h"       

#define MAXSTRINGLEN 20 

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileNewDlg dialog

CFileNewDlg::CFileNewDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFileNewDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFileNewDlg)
	m_nLayers = 0;
	m_Config = 0;
	m_ConfList = "";  
	
	m_ConfigDataPresent = FALSE ;
	m_Change = FALSE ;
	//}}AFX_DATA_INIT
}
                                                    
// Never call this function directly, instead call UpdateData
void CFileNewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFileNewDlg) 
	DDX_Text(pDX, IDC_NLAYERS, m_nLayers);
	DDV_MinMaxUInt(pDX, m_nLayers, 2, 100);
	DDX_Text(pDX, IDC_CONFIG, m_Config);
	DDV_MinMaxUInt(pDX, m_Config, 1, 255);
	DDX_LBString(pDX, IDC_CONFLISTBOX, m_ConfList); 
	//}}AFX_DATA_MAP        
	
	// Initial conditions
	GetDlgItem(IDC_BUTTONADD)->SetWindowText("Add") ;
	GetDlgItem(IDC_BUTTONREMOVE)->EnableWindow(FALSE) ;
}

BEGIN_MESSAGE_MAP(CFileNewDlg, CDialog)
	//{{AFX_MSG_MAP(CFileNewDlg)
	ON_BN_CLICKED(IDC_BUTTONADD, OnNewDlgAdd)
	ON_LBN_SELCHANGE(IDC_CONFLISTBOX, OnConflistboxSelChange)
	ON_BN_CLICKED(IDC_BUTTONREMOVE, OnButtonremove)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileNewDlg message handlers

// called when the ADD button is pressed in the File New dialog box
void CFileNewDlg::OnNewDlgAdd()
{                     
	char szValue[20] ;
	CWnd* Text ;
	int nLength ;
	UINT value ;
	
	// get contents of configuration edit box
	Text = GetDlgItem(IDC_CONFIG) ;
	nLength = Text->GetWindowTextLength() ;
	Text->GetWindowText(szValue,nLength+1) ;
	szValue[nLength] = '\0' ;
	
	value = atoi(szValue) ;
	                       
	// Check range of Config value is acceptable
	if ( (value >= 1) && (value <= 255) )
	   {
	   		GetDlgItem(IDC_CONFIG)->SetWindowText(szValue) ;
	   }
	else
	   {
	   		AfxMessageBox("An invalid value has been entered",
	   			MB_ICONEXCLAMATION|MB_OK,0) ;
	   		return ;
	   }
	                
	// Check for integer input
	if ((char*)memchr(szValue,'.',nLength) != NULL)
	   {
	   		AfxMessageBox("Please input an integer",
	   			MB_ICONEXCLAMATION|MB_OK,0) ;
	   		return ;
	   }

	// create a pointer to the list box	   		
	CListBox* ConfListBox = (CListBox*) GetDlgItem(IDC_CONFLISTBOX) ;
                                       
    // if the change option has not been selected then insert
    // the value at the end of the list, otherwise change the
    // selected value.
	if ( !m_Change )
	   {            
	   		m_Index = ConfListBox->GetCount() ;
	   		ConfListBox->SetCurSel(m_Index) ;
	   		ConfListBox->InsertString(m_Index,szValue) ;
	   }
	else
	   {
	   		ConfListBox->DeleteString(m_Index) ; // m_nIndex points to selected string
	   		ConfListBox->InsertString(m_Index,szValue) ;
	   		
	   		m_Change = FALSE ;
	   		GetDlgItem(IDC_BUTTONADD)->SetWindowText("Add") ;
	   		GetDlgItem(IDC_BUTTONREMOVE)->EnableWindow(FALSE) ;
	   		
	   		// Now no item is selected
	   		m_Index = -1 ;
	   		ConfListBox->SetCurSel(m_Index) ;
	   	}
}                 


// when a selection in the list box has changed, update the selection
// as well as the button states
void CFileNewDlg::OnConflistboxSelChange()
{
	// create a pointer to the list box
	CListBox* ConfListBox = (CListBox*)GetDlgItem(IDC_CONFLISTBOX) ;
	                                   
	// get the index of the selected list box item
	// used for change purposes 
	m_Index = ConfListBox->GetCurSel() ;
	
	if (m_Index == LB_ERR)
	   {
	   		m_Index = -1 ;
	   		return ;
	   }
	   
	m_Change = TRUE ;

	// Change text on ADD button to CHANGE
	// and enable REMOVE button
	GetDlgItem(IDC_BUTTONADD)->SetWindowText("Change") ;
	GetDlgItem(IDC_BUTTONREMOVE)->EnableWindow() ;
}
                               

// if REMOVE button is pressed while it is acting as CHANGE,
// replace selected list box element with new value
void CFileNewDlg::OnButtonremove()
{
	if ( m_Change )
	   {
	   		CListBox* ConfListBox = (CListBox*)GetDlgItem(IDC_CONFLISTBOX) ;
	   		
	   		ConfListBox->DeleteString(m_Index) ;
	   		
	        // Now no item is selected
	        m_Index = -1 ;
	        ConfListBox->SetCurSel(m_Index) ;
	        
	        m_Change = FALSE ;
	        GetDlgItem(IDC_BUTTONADD)->SetWindowText("Add") ;
	        GetDlgItem(IDC_BUTTONREMOVE)->EnableWindow(FALSE) ;
	   }
}
                                                    

// When OK pressed, validate numbers input
void CFileNewDlg::OnOK()
{   
	BOOL bValid ;
	m_nLayers = GetDlgItemInt(IDC_NLAYERS,&bValid,FALSE) ;
	
	if (m_nLayers > 20)
	   {
	   		AfxMessageBox("Error!, too many layers",
	   					MB_ICONEXCLAMATION | MB_OK,0) ;
	   		return ;
	   }
	                                      
	// create pointer to list box
	CListBox* ConfListBox = (CListBox*)GetDlgItem(IDC_CONFLISTBOX) ;
	
	if (ConfListBox->GetCount() != (int)m_nLayers)
	   {
	   		AfxMessageBox("Error!, Configuration is not consistent with number of layers.",
	   						MB_ICONEXCLAMATION | MB_OK,0) ;
	   		return ;
	   }
    
    // store list box elements in array m_LBoxContents
    char szLabel[MAXSTRINGLEN] ;    
    int nLength ;
	for (int i = 0 ; i < ConfListBox->GetCount() ; i++)
		{
			nLength = ConfListBox->GetText(i,szLabel) ;
			szLabel[nLength] = '\0' ;
			m_LBoxContents[i] = atoi(szLabel) ;
		}
			     
    m_ConfigDataPresent = TRUE ;
    
	CDialog::OnOK();
}
