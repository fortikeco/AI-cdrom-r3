//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by SIM.RC
//
#define IDR_MAINFRAME                   2
#define IDD_ABOUTBOX                    100
#define IDC_NLAYERS                     101
#define IDD_FILENEW                     102
#define IDD_DIALOG1                     103
#define IDD_TRAINDATA                   103
#define IDC_CONFLISTBOX                 104
#define IDC_CONFIG                      105
#define IDD_NETPARAMS                   105
#define IDC_BUTTONADD                   106
#define IDC_BUTTONREMOVE                107
#define IDB_SYNAPTEK                    107
#define IDC_TRAINDATA                   108
#define IDI_ICON1                       108
#define IDC_GRIDEDIT                    109
#define IDC_TRAINDATA2                  110
#define IDC_SAMAD                       111
#define IDB_BITMAP1                     111
#define IDC_ACCERR                      112
#define IDD_TESTNET                     112
#define IDC_LEARNCONST                  113
#define IDC_MOMENTUM                    114
#define IDD_INOUTDEPTH                  114
#define IDC_TEST                        115
#define IDD_WATCH                       115
#define IDC_EDIT1                       116
#define IDC_TESTDEPTH                   116
#define IDC_INWIDTH                     116
#define IDC_CONNECTION                  116
#define IDC_TRAINPATTERNS               116
#define IDC_TESTBUTTON                  118
#define IDC_INDEPTH                     119
#define IDC_INDEPTH2                    120
#define IDC_OUTDEPTH                    120
#define IDC_EDIT2                       122
#define IDC_TESTEDIT                    122
#define IDC_OUTWIDTH                    122
#define IDC_TESTGRIDINPT                123
#define IDC_CONNECTIONLIST              125
#define IDC_WREMOVE                     126
#define IDC_WADD                        127
#define ID_VIEW_ZOOMIN                  32768
#define ID_VIEW_ZOOMOUT                 32769
#define ID_VIEW_DISPWEIGHTS             32773
#define ID_VIEW_DISPNET                 32774
#define ID_SIMULATION_STARTSIMULATION   32775
#define ID_SIMULATION_TRAINSIMULATOR    32776
#define ID_SIMULATION_SETNETPARAMS      32777
#define ID_STARTSIMULATION              32779
#define ID_SIMULATION_STOPSIMULATION    32780
#define ID_STOPSIMULATION               32781
#define ID_CONTINUESIMULATION           32782
#define ID_SIMULATION_SHOWNETPARAMS     32783
#define ID_SHOWNETPARAMS                32784
#define ID_SIMULATION_CONTINUESIMULATION 32785
#define ID_TEST                         32786
#define ID_WEIGHTS_SAVEWEIGHTS          32787
#define ID_WEIGHTS_LOADWEIGHTS          32788
#define ID_WATCH                        32789
#define ID_IMAGE_ZOOMIN                 32790
#define ID_IMAGE_ZOOMOUT                32791

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         128
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
