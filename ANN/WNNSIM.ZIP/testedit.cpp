// testedit.cpp : implementation file
//					Handles the key codes associated with moving the edit box
//					around the grid in the test dialog box
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"
#include "test.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestEdit

// this is the edit control used in the test grid

CTestEdit::CTestEdit()
{
}

CTestEdit::~CTestEdit()
{
}


BEGIN_MESSAGE_MAP(CTestEdit, CWnd)
	//{{AFX_MSG_MAP(CTestEdit)
	ON_WM_GETDLGCODE()
	ON_WM_KEYDOWN()
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestEdit message handlers

BOOL CTestEdit::ProcessKeys(UINT nChar)
{
	CTest* pParent = (CTest*)GetParent() ;
	CVBControl* pGrid = pParent->m_pTestGrid ;
	
	int nRow = (int)pGrid->GetNumProperty("Row") ;
	int nCol = (int)pGrid->GetNumProperty("Col") ;
	int nRows = (int)pGrid->GetNumProperty("Rows") ;
	int nCols = (int)pGrid->GetNumProperty("Cols") ;
	int nFirstRow = (int)pGrid->GetNumProperty("FixedRows") ;
	int nFirstCol = (int)pGrid->GetNumProperty("FixedCols") ;
	int nTopRow = (int)pGrid->GetNumProperty("TopRow") ;
	int nLeftCol = (int)pGrid->GetNumProperty("LeftCol") ;
	
	int nOldCol = nCol ;
	
	switch (nChar)
		{
			case VK_UP:
						if ( (nTopRow > 1) && (nRow == nTopRow) )
						   pGrid->SetNumProperty("TopRow",--nTopRow) ;
						nRow-- ;
						break ;
			case VK_DOWN:
						if ( (nRow - nTopRow) > 4)
						   pGrid->SetNumProperty("TopRow",++nTopRow) ;
						nRow++ ;
						break ;
			default:
						return FALSE ;
		}
	
	if (nCol < nFirstCol) // moved off left edge
	   {
	   		nCol = 1 ;
	   }
	   
	if (nRow < nFirstRow)
	   {
	   		nRow = 1 ;
	   }
	
	if (nRow >= nRows)
	   {
	   		nRow = nRows ;
	   }
	   
	pGrid->SetNumProperty("Row",nRow) ;
	pGrid->SetNumProperty("Col",nCol) ; // Generate Row/Col change event
	
	return TRUE ;
}

						  
////////////////////////////////////////////////////////////////////
// CtestEdit message handlers

UINT CTestEdit::OnGetDlgCode()
{
	return CEdit::OnGetDlgCode() | DLGC_WANTALLKEYS ;
}


void CTestEdit::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == VK_UP || nChar == VK_DOWN || nChar == VK_TAB)
	   {
	   		ProcessKeys(nChar) ;
	   }
	else
	   {    
			CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
	   }
}


void CTestEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{   
	BOOL valid ;
	
	// VK_BACK == Backspace
	// VK_DELETE == Delete
	// VK_RETURN == Return
	// "0" == ascii 48
	// "9" == ascii 57
	// "-" == ascii
	// "." == ascii
	                                                                     
	// check for bacskpace, delete and return
	valid = (nChar == VK_BACK || nChar == VK_DELETE);
	
	// check for numeric value
	valid |= ( (nChar >= 48) && (nChar <= 57) ) ;
		                      
    // check for "-" and "."
    valid |= ( (nChar == 45) || (nChar == 46) ) ;
    
	if ( valid && (!ProcessKeys(nChar)) )
	   {
	   		CEdit::OnChar(nChar, nRepCnt, nFlags);
	   }
}