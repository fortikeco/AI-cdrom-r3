// viewnetv.h : header file
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

/////////////////////////////////////////////////////////////////////////////
// ViewNetVars frame with splitter

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class ViewNetVars : public CFrameWnd
{
	DECLARE_DYNCREATE(ViewNetVars)
protected:
	ViewNetVars();			// protected constructor used by dynamic creation

// Attributes
protected:
	CToolBar		m_wndToolBar ;
	CStatusBar		m_wndStatusBar ;

public:
	CSplitterWnd	m_wndSplitter;   // two row splitter window
	CSplitterWnd	m_wndSplitter2;  // two column splitter window in bottom 
									 // row of previous splitter window
	
// Operations
public:

// Implementation
public:
	virtual ~ViewNetVars();
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);

	// Generated message map functions
	//{{AFX_MSG(ViewNetVars)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
