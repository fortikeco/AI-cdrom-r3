// newdlg.h : header file
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

/////////////////////////////////////////////////////////////////////////////
// CFileNewDlg dialog

class CFileNewDlg : public CDialog
{
// Construction
public:
	CFileNewDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFileNewDlg)
	enum { IDD = IDD_FILENEW };
	UINT	m_nLayers; // number of layers in layers edit box
	UINT	m_Config;  // number in edit box representing number of neurons in layer
	CString	m_ConfList;
    
    UINT    m_Index ;  // point to selected string in list box
	BOOL 	m_Change ; // data to be changed
	BOOL	m_ConfigDataPresent ; // data has been accepted from this dialog box
	
	int		m_LBoxContents[20] ; // holds contents of list box (maximum of 20 layers)
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
     
	// Generated message map functions
	//{{AFX_MSG(CFileNewDlg)
	afx_msg void OnNewDlgAdd();
	afx_msg void OnConflistboxSelChange();
	afx_msg void OnButtonremove();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
