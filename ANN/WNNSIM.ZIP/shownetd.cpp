// shownetd.cpp : implementation file
// 					The data associated with a neural net, such as connection weights,
//					acceptable error, etc are displayed in the top splitter window.
//					The display is updated on a WM_PAINT message.
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h" 
#include "stdlib.h"
#include "simdoc.h"
#include "simview.h" 
#include "viewnetv.h"
#include "sim.h"
#include "traindat.h"
#include "shownetd.h" 

#include <stdlib.h>

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShowNetData

IMPLEMENT_DYNCREATE(CShowNetData, CScrollView)

CShowNetData::CShowNetData()
{
}

CShowNetData::~CShowNetData()
{
}


BEGIN_MESSAGE_MAP(CShowNetData, CScrollView)
	//{{AFX_MSG_MAP(CShowNetData)
	ON_COMMAND(ID_STARTSIMULATION, OnStartsimulation)
	ON_COMMAND(ID_CONTINUESIMULATION, OnContinuesimulation)
	ON_COMMAND(ID_STOPSIMULATION, OnStopsimulation)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShowNetData drawing

// Called when OnPaint message encountered, such as generated
// by UpdateAllViews(NULL,0,NULL)
void CShowNetData::OnDraw(CDC* pDC)
{                                
	// Get pointer to CSimDoc to allow access to document variables
	CSimDoc* sDoc = (CSimDoc*) GetDocument() ;
    
	int x, y, WatchLayer, LoopCount ; 
	TEXTMETRIC tm ;
	
	pDC->GetTextMetrics(&tm) ;
	                                                               
	// Display the Acceptable Error, Total Error and Iterations
	y = 0 ;
	for (int i = 0 ; i < 3 ; i++)
		{
	    	pDC->TextOut(0,y,ScreenText[0][i],ScreenText[0][i].GetLength()) ;
	    	y += tm.tmHeight ;
		}	     
                                                               
    // display the weights of the connections being watched
	int MaxnInLayer = 0 ;    
    for (i = 0 ; i < sDoc->m_nCnxnsToWatch ; i++)
        {
        	if (sDoc->nInLayer[sDoc->m_WatchBoxContents[i]] > MaxnInLayer)
        	   {
        	   		MaxnInLayer = sDoc->nInLayer[sDoc->m_WatchBoxContents[i]] ;
        	   }
        } 
                         
    x = 4 ; char num[5] ;
    y = 4*tm.tmHeight ;
    
    // display neuron number 0..Maximum neuron number
    for (i = 0 ; i < MaxnInLayer ; i++) 
    	{   
    		if (i == 0) pDC->TextOut(x,y,"Neuron",6) ;
    		y += tm.tmHeight ;
    		sprintf(num,"%d",i) ;
    		pDC->TextOut(x,y,num,strlen(num)) ;
    	}
                                                     
    // display connection weights                                                 
	int width ; x = 60 ;
	for (int j = 0 ; j < sDoc->m_nCnxnsToWatch ; j++)
		{
			y = 4*tm.tmHeight ;
		    pDC->TextOut(x,y,"Connections",11) ;
			WatchLayer = sDoc->m_WatchBoxContents[j] ;
			LoopCount = sDoc->nInLayer[WatchLayer] ;
			width = sDoc->nInLayer[WatchLayer+1] ;
			for (int i = 3 ; i < LoopCount + 4 ; i++)  // +4 because of first 4 screen lines
   				{
   					pDC->TextOut(x,y,ScreenText[j][i],ScreenText[j][i].GetLength()) ;
   					y += tm.tmHeight ;
   				}
   				
   			x += 65 * width ;
   	    }
}


void CShowNetData::ShowWeights()
{
	CSimDoc* sDoc = (CSimDoc*) GetDocument() ;
    
    char value[20] ;
    ltoa(GetIterationNum(),value,10) ; // sDoc->iteration
    ScreenText[0][2] = " Iterations: " ;
    ScreenText[0][2] += value ; 
    ScreenText[0][2] += "          " ;
    	
    int cnxnNumber, y, nNeurons1, nNeurons2 ;
    
    
    // Iterate through ScreenText array, displaying the text held within
    cnxnNumber = 0 ; 
    for (int atLayer = 0 ; atLayer < sDoc->m_nCnxnsToWatch ; atLayer++)
		{
			y = 3 ;
			nNeurons1 = sDoc->nInLayer[sDoc->m_WatchBoxContents[atLayer]] ;
			nNeurons2 = sDoc->nInLayer[sDoc->m_WatchBoxContents[atLayer]+1] ;
			
			for (int atNeuron1 = 0 ; atNeuron1 < nNeurons1 ; atNeuron1++)
				{   
					ScreenText[atLayer][++y] = "" ;
					for (int atNeuron2 = 0 ; atNeuron2 < nNeurons2 ; atNeuron2++)
						{   
							sprintf(value,"%-10.5f",sDoc->cnxn[cnxnNumber].weight) ;
				            
							ScreenText[atLayer][y] += value ;
							
							cnxnNumber++ ;
	   					}
	   			}
		}
}

                                                                  
// This is the heart of the training process, this is called to iterate
// through the training. ResetIterCnt indicates whether the iteration counter is
// to be reset or not.                                                                  
void CShowNetData::TrainingLoop(BOOL ResetIterCnt)
{
	CSimDoc* sDoc = (CSimDoc*) GetDocument() ;
 	CClientDC pDC(this) ;
	
	char value[10] ;
	sDoc->totalError = 0.0 ;

	// display acceptable error
	sprintf(value,"%-10.5f",sDoc->acceptableError) ;
    ScreenText[0][0] = " Acceptable Error: " ;
    ScreenText[0][0] += value ;
	
	sDoc->SetRunStatus(TRUE) ;
	sDoc->SetTraining(TRUE) ;
		
    if (ResetIterCnt) ResetIterations() ; // m_nIterations = 0                                 
    
    srand((int)time(NULL)) ; // random number generator seed
    MSG msg ;
    for (;;)
    {
    	// watch any other messages being sent around the system
    	// and pass them on to allow tasking to take place
        while (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
			{                                       
				// if quit message posted (as done when STOP button pressed)
				// then stop training, and indicate as done so in document variable
				if (msg.message == WM_QUIT)
			   		{
			   			sDoc->SetRunStatus(FALSE) ;
			   			return ;
			   		}
			
				TranslateMessage(&msg) ;
				DispatchMessage(&msg) ;
		 	}
	
		ShowWeights()     ; // display the required data on screen
		Invalidate(FALSE) ; // stops flickering by not clearing display
		UpdateWindow()    ; // area before new weights displayed
		
		IncIteration() ; // Iteration++
        
		sDoc->forwardPass() ;   // perform forward pass and backward prop which are
		sDoc->backwardProp() ;  // document methods
        
        // if all patterns have been passed through once then    
        if (sDoc->atEpochEnd())
           {
             // display total error
		 	 sprintf(value,"%-10.5f",sDoc->totalError) ;
			 ScreenText[0][1] = " Total Error: " ;
			 ScreenText[0][1] += value ;
                                		   
             if (sDoc->trained())
                {
               		ShowWeights() ;
					Invalidate(FALSE) ; // stop flickering

 					sDoc->SetRunStatus(FALSE) ;
	   				sDoc->SetSuspended(FALSE) ;
            		break ;
                }
                   	   
             sDoc->totalError = 0.0 ; // zeroTotalError() ;
           }
	}
}

/////////////////////////////////////////////////////////////////////////////
// CShowNetData message handlers

// called when train button pressed                                       
void CShowNetData::OnStartsimulation()
{
	CSimDoc* sDoc = (CSimDoc*) GetDocument() ;
	                               
	// only start if there is no training in progress
	if (sDoc->GetRunStatus())
	   {
	   		return ;
	   }
	   
	if ( (sDoc->GetCDPresent() == FALSE) || (sDoc->GetNetParams() == FALSE) )
	   {
	   		AfxMessageBox("Check Network Configuration!",MB_ICONEXCLAMATION | MB_OK,0) ;
	   		return ;
	   }
                                            
    // Deallocate(layers,cnxns,neurons,patterns). Deallocate Pattern memory
	sDoc->DeallocateMem(FALSE,FALSE,FALSE,TRUE) ; 
    
    // read the number of training patterns from the box in view 3 (grid view)   
	CSplitterWnd* pParent = (CSplitterWnd*) GetParent() ;
	CSplitterWnd* pChild  = (CSplitterWnd*) pParent->GetPane(1,0) ;
	int np = ((CSimView*)pChild->GetPane(0,1))->GetDlgItemInt(IDC_TRAINPATTERNS,NULL,TRUE) ;
	
	// create pointer to grid
    CTrainData* pGridView = (CTrainData*)pChild->GetPane(0,1) ;
	CVBControl* pGrid = pGridView->m_pGrid ;

    sDoc->nPatterns = np ;
	sDoc->InitPatterns() ; // initiate pattern structure for pattern data
                                                                         
    // read patterns from the grid by selecting them then performing a
    // clip. Data is then converted and passed to the pat structure
    pGrid->SetNumProperty("SelStartRow",1) ;
    int index = -1 ; int size ;
    for (int col = 1 ; col <= np*2 ; col++)
       	{
	   		if (col % 2 == 1)
	   		   {
	   		    	index++ ;
	   				size = sDoc->nInLayer[0] ;
	   		   }
	   		else
	   		   {	
	   				size = sDoc->nInLayer[sDoc->nLayers-1] ;
	   		   }
		    			
	   		pGrid->SetNumProperty("SelStartCol",col) ;
	   		pGrid->SetNumProperty("SelEndRow",size) ;
	   		pGrid->SetNumProperty("SelEndCol",col) ;
	        CString data = pGrid->GetStrProperty("Clip") ;
    	    char *pData = data.GetBuffer(1) ;
            for (int element = 0 ; element < size ; element++)
    			{
					char *pToken = strtok(pData, " \t\r\n") ;
					pData = NULL ;                                           
					
      				if (pToken != NULL)
      				   {
      		   			  if (col % 2 == 1)
      		   	  		  	 sDoc->pat[index].in[element] = strtod(pToken,NULL) ;
       		   			  else    				    
       		      			 sDoc->pat[index].out[element] = strtod(pToken,NULL) ;
       		      	   }
       		      	else
       		      	   {
       		      	   	  AfxMessageBox("Could not read training data from grid!",MB_ICONEXCLAMATION | MB_OK,0) ;
       		      	   	  sDoc->SetTDPresent(FALSE) ;
       		      	   	  return ;
       		      	   }
       			}
       	}
	pGrid->SetNumProperty("SelStartRow",0) ; // get rid of blue highlight
	pGrid->SetNumProperty("SelStartCol",0) ;
	pGrid->SetNumProperty("SelEndRow",0) ;
	pGrid->SetNumProperty("SelEndCol",0) ;

	sDoc->SetTDPresent(TRUE) ; // indicate that training data is present
    
    // randomise weights before simulation starts
    sDoc->cnxn->momentum = sDoc->DocMomentum ;
    sDoc->cnxn->samadCoefficient = sDoc->DocSamadCoefficient ;
    sDoc->cnxn->learningConstant = sDoc->DocLearningConstant ;
    sDoc->acceptableError = sDoc->DocAcceptableError ;   		
    int atCnxn = 0, atLayer, atLowNeuron, atHighNeuron ;
    for (atLayer = 0 ; atLayer < sDoc->nLayers - 1 ; atLayer++)
    	{
    		for (atLowNeuron = 0 ; atLowNeuron < sDoc->nInLayer[atLayer] ; atLowNeuron++)
    			{
    				for (atHighNeuron = 0 ; atHighNeuron < sDoc->nInLayer[atLayer+1] ; atHighNeuron++)
    					{
    						sDoc->cnxn[atCnxn].set(sDoc->neuron[atLayer][atLowNeuron],
    										sDoc->neuron[atLayer+1][atHighNeuron]) ;
    						sDoc->cnxn[atCnxn].setRandom(sDoc->cnxn->learningConstant,
											sDoc->cnxn->momentum,sDoc->cnxn->samadCoefficient) ;
							atCnxn++ ;
						}
				}
		}

	sDoc->atPattern = 0 ; 
	sDoc->totalError = 0 ;
	sDoc->SetDataPresent(TRUE) ;
	
	TrainingLoop(TRUE) ;
}


void CShowNetData::OnContinuesimulation()
{                                                
	// Same as start simulation but no training data is read and
	// neuron weights are already present
	CSimDoc* sDoc = (CSimDoc*) GetDocument() ;
	
	if (!sDoc->GetSuspended())
	   {
	   		AfxMessageBox("Can not CONTINUE training!",MB_ICONEXCLAMATION | MB_OK,0) ;
	   		return ;
	   }
	
	sDoc->SetSuspended(FALSE) ;
	TrainingLoop(FALSE) ;
}
 

// set size of scroll view  
void CShowNetData::OnInitialUpdate()
{	
	CSimDoc* sDoc = (CSimDoc*) GetDocument() ;
  
    sDoc->UpdateAllViews(NULL,0,NULL) ;
    
	SetScrollSizes(MM_TEXT,sDoc->GetDocSize()) ;
}


// post a WM_QUIT message only if simulation is under way
void CShowNetData::OnStopsimulation()
{
	CSimDoc* sDoc = (CSimDoc*) GetDocument() ;

	// only post a WM_QUIT message if training is in progress
	if (sDoc->GetRunStatus())
	   {
			PostMessage(WM_QUIT,0,0) ;
			sDoc->SetSuspended(TRUE) ;
	   }
}
