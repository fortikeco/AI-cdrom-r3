// shownetd.h : header file
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

/////////////////////////////////////////////////////////////////////////////
// CShowNetData view

class CShowNetData : public CScrollView
{
	DECLARE_DYNCREATE(CShowNetData)
protected:
	CShowNetData();			// protected constructor used by dynamic creation
    void OnInitialUpdate() ;
    
private:
	long int m_nIterations ;
	
// Attributes
public:
    CString ScreenText[5][200] ; // contents of screen

// Operations
public:
    void ResetIterations() { m_nIterations = 0 ; }
    void IncIteration()    { m_nIterations++   ; }
    
    long int GetIterationNum() { return m_nIterations ; }
    
// Implementation
protected:
	virtual ~CShowNetData();
	virtual	void OnDraw(CDC* pDC);		// overridden to draw this view
    void ShowWeights() ;                     
    void TrainingLoop(BOOL IncIterCount) ;
    int FloatToStr(float num,char value[]) ;
    
	// Generated message map functions
protected:
	//{{AFX_MSG(CShowNetData)
	afx_msg void OnStartsimulation();
	afx_msg void OnContinuesimulation();
	afx_msg void OnStopsimulation();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
                        

/////////////////////////////////////////////////////////////////////////////
