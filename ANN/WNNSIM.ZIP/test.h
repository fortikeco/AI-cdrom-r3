// test.h : header file
//  
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#ifndef __SIMDOC_H__
#define __SIMDOC_H__
#include "simdoc.h"
#endif

#include "testedit.h"

/////////////////////////////////////////////////////////////////////////////
// CTest dialog
class CTest : public CDialog
{
// Construction
public:	
    CTest(CSimDoc& myDoc) ; // pass pointer to document data on construction
    
    CTestEdit m_TestEdit         ;
    BOOL	  m_bSelChange       ;
    int		  m_TestData[40]	 ; // allow for 40 input neurons
    
// Dialog Data
	//{{AFX_DATA(CTest)
	enum { IDD = IDD_TESTNET };
	CVBControl*	m_pTestOutput;
	CVBControl*	m_pTestGrid;
	//}}AFX_DATA

private:
	CSimDoc& m_myDoc ; // all document data may be accessed through m_myDoc

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
    void PositionEdit(CVBControl* Grid) ;
    CPoint FindCellPosition(int nRow, int nCol, CVBControl* Grid) ;

	// Generated message map functions
	//{{AFX_MSG(CTest)
	virtual BOOL OnInitDialog();
	afx_msg void OnClickTest(UINT, int, CWnd*, LPVOID);
	afx_msg void OnRowcolchangeTest(UINT, int, CWnd*, LPVOID);
	afx_msg void OnGotfocusTest(UINT, int, CWnd*, LPVOID);
	afx_msg void OnSelchangeTest(UINT, int, CWnd*, LPVOID);
	afx_msg void OnChangeTestedit();
	afx_msg void OnClickedTestbutton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

