// watch.h : header file
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#ifndef __SIMDOC_H__
#define __SIMDOC_H__
#include "simdoc.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// Watch dialog

class Watch : public CDialog
{
// Construction
public:
	Watch(CSimDoc& myDoc);	// pass pointer to document
    
    UINT	m_nConnections ;
    UINT	m_Connection   ;
    CString	m_ConnList     ;
    
    UINT 	m_Index ; // point to selected string in list box
    BOOL	m_bChange ; // data to be changed ? 
    BOOL 	m_bDataPresent ;
    
// Dialog Data
	//{{AFX_DATA(Watch)
	enum { IDD = IDD_WATCH };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
              
private:
	CSimDoc& m_myDoc ;
	
// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(Watch)
	afx_msg void OnClickedWadd();
	afx_msg void OnSelchangeConnectionlist();
	afx_msg void OnClickedWremove();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
