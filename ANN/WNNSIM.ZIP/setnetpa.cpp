// setnetpa.cpp : implementation file
// 					Dialog box for setting the network parameters
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"   
#include "setnetpa.h"
#include "simview.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetNetParams dialog

CSetNetParams::CSetNetParams(CWnd* pParent /*=NULL*/)
	: CDialog(CSetNetParams::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetNetParams)
	ParamsPresent = FALSE ;
    m_nSamadCoeff = 0.0 ;
    m_nMomentum   = 0.0 ;
    m_nAccError   = 0.0 ;
    m_nLearnConst = 0.0 ;
	//}}AFX_DATA_INIT
}

void CSetNetParams::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetNetParams)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSetNetParams, CDialog)
	//{{AFX_MSG_MAP(CSetNetParams)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetNetParams message handlers

// On initiation of dialog box, populate the edit boxes with either
// 0 or a pre-defined value
BOOL CSetNetParams::OnInitDialog()
{
	CDialog::OnInitDialog();
    
    if (ParamsPresent)
       {
       		char buf[10] ;
   			sprintf(buf,"%.5f",m_nSamadCoeff) ;
			GetDlgItem(IDC_SAMAD)->SetWindowText(buf) ;
			sprintf(buf,"%.5f",m_nAccError) ;
			GetDlgItem(IDC_ACCERR)->SetWindowText(buf) ;
			sprintf(buf,"%.5f",m_nLearnConst) ;
			GetDlgItem(IDC_LEARNCONST)->SetWindowText(buf) ;
			sprintf(buf,"%.5f",m_nMomentum) ;
			GetDlgItem(IDC_MOMENTUM)->SetWindowText(buf) ;
	   }
	else
       {
			GetDlgItem(IDC_SAMAD)->SetWindowText("0.0") ;
			GetDlgItem(IDC_ACCERR)->SetWindowText("0.0") ;
			GetDlgItem(IDC_LEARNCONST)->SetWindowText("0.0") ;
			GetDlgItem(IDC_MOMENTUM)->SetWindowText("0.0") ;
	   }

	// set the focus to the samad coefficient box          		
	CEdit* SetNetParamsEdit = (CEdit*) GetDlgItem(IDC_SAMAD) ;
	SetNetParamsEdit->SetFocus() ;
	
	return FALSE;  // return TRUE  unless you set the focus to a control
}
    

// store values when OK pressed    
void CSetNetParams::OnOK()
{                                          
	char buf[10] ;
	
	GetDlgItemText(IDC_SAMAD,buf,10) ;	
	m_nSamadCoeff = strtod(buf,NULL) ;
	GetDlgItemText(IDC_ACCERR,buf,10) ;	
	m_nAccError = strtod(buf,NULL) ;
	GetDlgItemText(IDC_LEARNCONST,buf,10) ;	
	m_nLearnConst = strtod(buf,NULL) ;
	GetDlgItemText(IDC_MOMENTUM,buf,10) ;	
	m_nMomentum = strtod(buf,NULL) ;
	
	CDialog::OnOK();
}
