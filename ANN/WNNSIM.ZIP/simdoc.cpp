// simdoc.cpp : implementation of the CSimDoc class
//              This class represents the main document interface. Tasks performed
//					Load / Save Network configuration
//					Network Configuration dialog box initiated here
//					Net Parameters dialog box initiation
//					Network functionality
//					Test network dialog initiation
//					Watch dialog initiation
//					Zoom In/Out scale factor variable changed in document method
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"
#include "newdlg.h"
#include "setnetpa.h"
#include "test.h"
#include "watch.h"
#include "simview.h"
#include "viewnetv.h" 
#include "shownetd.h"
#include <math.h>

#ifndef __TRAIN__
#define __TRAIN__
#include "traindat.h"
#endif
 
#define MAXSTRINGLEN 20 
         
#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimDoc

IMPLEMENT_DYNCREATE(CSimDoc, CDocument)

BEGIN_MESSAGE_MAP(CSimDoc, CDocument)
	//{{AFX_MSG_MAP(CSimDoc)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_SIMULATION_SETNETPARAMS, OnSetnetparams)
	ON_COMMAND(ID_TEST, OnTest)
	ON_COMMAND(ID_WATCH, OnWatch)
	ON_COMMAND(ID_IMAGE_ZOOMIN, OnImageZoomin)
	ON_COMMAND(ID_IMAGE_ZOOMOUT, OnImageZoomout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CSimDoc construction/destruction

CSimDoc::CSimDoc()
{	
	m_sizeDoc = CSize(800,1000) ;  // document size (x,y)
    
    Scale = 1 ; // scale for graphical representation of net
	nLayers = 0 ;
	nPatterns = 0 ;
	tmpnPatterns = 0 ;
	atPattern = 0 ;
	iteration = 0 ;
	totalError = 0.0 ;
	inWidth = 0 ; inDepth = 0 ;  // not used now
	outWidth = 0 ; outDepth = 0 ; // not used now
	acceptableError = 0.0 ;
	m_nCnxnsToWatch = 0 ;
	DocAcceptableError = 0.0 ;
	DocMomentum	= 0.0 ;
	DocLearningConstant = 0.0 ;
	DocSamadCoefficient = 0.0 ;
	
	SetNewDocument(FALSE)  ;
	SetNetParams(FALSE)    ;
	SetTDPresent(FALSE)    ;
	SetDataPresent(FALSE)  ;
	SetRunStatus(FALSE)    ;
	SetGridModified(FALSE) ;
	SetTraining(FALSE)     ;
	SetCnxnAlloc(FALSE)    ; // Connection memory allocated?
	SetNeuronAlloc(FALSE)  ; // Neuron memory allocated?
	SetPatternAlloc(FALSE) ; // Pattern memory allocated?
	SetLayersAlloc(FALSE)  ; // nInLayers memory allocated?
}


CSimDoc::~CSimDoc()
{   
	// tidy up before we go!
	DeallocateMem(TRUE,TRUE,TRUE,TRUE) ;
}

  
void CSimDoc::InitDocument()
{
}  

  
BOOL CSimDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
		
	SetCDPresent(FALSE)   ;
	SetNetParams(FALSE)   ;
	SetTDPresent(FALSE)   ;
	SetRunStatus(FALSE)   ;
	SetDataPresent(FALSE) ;
	SetSuspended(FALSE)   ;
	SetTraining(FALSE)    ;
	
	return TRUE;
}
     
     
BOOL CSimDoc::OnOpenDocument( const char* pszPathName )
{
	if ( !CDocument::OnOpenDocument( pszPathName ) )
	{
		return FALSE ;
	}    
	
	InitDocument() ;
	return TRUE ;
}                       
    
    
/////////////////////////////////////////////////////////////////////////////
// CSimDoc serialization

// clear up any memory that has been dynamically allocated
int CSimDoc::DeallocateMem(BOOL m_bnInLayers,BOOL m_bCnxns,BOOL m_bNeurons,BOOL m_bPatterns)
{   
	if (m_bNeurons && GetNeuronAlloc())
	   {         
			for (int atLayer = 0 ; atLayer < nLayers ; atLayer++)
				{
					for (int atNeuron = 0 ; atNeuron < nInLayer[atLayer] ; atNeuron++)
						{
							delete(neuron[atLayer][atNeuron]) ;
						}
				}
			SetNeuronAlloc(FALSE) ;
	   }

	if (m_bnInLayers && GetLayersAlloc())
	   {
	    	delete(nInLayer) ;
	    	SetLayersAlloc(FALSE) ;
	   }
	
	if (m_bCnxns && GetCnxnAlloc())
	   { 
			delete(cnxn) ;
	        SetCnxnAlloc(FALSE) ;        
	   }
	
	if (m_bPatterns && GetPatternAlloc())
	   {
			for (int i = 0 ; i < nPatterns ; i++)
				{
					delete(pat[i].in) ;
					delete(pat[i].out) ;
				}
			delete(pat) ;        
			SetPatternAlloc(FALSE) ;
	   }                
	   
	return 0 ;
}
 

// reads all characters until white space encountered
void CSimDoc::ReadFile(char* buffer, CArchive& ar)
{
	int i = 0 ;     
	char c ;
	
	do {
		ar.Read(&c,1) ;
		if ( (c != ' ') && (c != '\n') )
		   {
		   		buffer[i++] = c ;
		   }
	} while ( (c != ' ') && (c != '\n') );
	buffer[i] = '\0' ;
}


int CSimDoc::InitCnxns()
{
	// Initialise connections
	nCnxns = 0 ;
	for (int atLayer = 0 ; atLayer < nLayers ; atLayer++)
		{
			if (atLayer > 0)
			   {
			   		nCnxns += nInLayer[atLayer] * nInLayer[atLayer-1] ;
			   }
		}
		
	if (!(cnxn = new Connection[nCnxns]))
		{
			AfxMessageBox("Could not create connections",MB_ICONEXCLAMATION | MB_OK,0) ;
			return -1 ;
		}
	
	SetCnxnAlloc(TRUE) ;
	return 0 ;
}


int CSimDoc::InitNeurons()
{
    for (int atLayer = 0 ; atLayer < nLayers ; atLayer++)
    	{
    		for (int atNeuron = 0 ; atNeuron < nInLayer[atLayer] ; atNeuron++)
    			{
    				if (!(neuron[atLayer][atNeuron] = new Neuron))
    		   		   {
    		   				AfxMessageBox("Error during neuron memory allocation",
   			   				   MB_ICONEXCLAMATION | MB_OK,0) ;
   			   				return -1 ;
   			   		   }
   				}
   		}          

	SetNeuronAlloc(TRUE) ;
	return 0 ;
}


int CSimDoc::InitPatterns()
{
	if (!(pat = new Pattern[nPatterns]))
   		{
    		AfxMessageBox("Could not allocate pattern memory!",MB_ICONEXCLAMATION | MB_OK,0) ;
    		return -1 ;
    	}
           
	for (int i = 0 ; i < nPatterns ; i++)
       	{
        	if (!pat[i].getMem(nInLayer[0], nInLayer[nLayers-1]))
        	   {
        	   		AfxMessageBox("Could not allocate pattern memory!",MB_ICONEXCLAMATION | MB_OK,0) ;
        	   		return -1 ;
        	   }
        }
	
	SetPatternAlloc(TRUE) ;
	return 0 ;
}


int CSimDoc::InitLayers()
{
	if (!(nInLayer = new int[nLayers]))
       {
      		AfxMessageBox("Could not allocate layer memory",MB_ICONEXCLAMATION | MB_OK,0) ;
			return -1 ; 
	   }

	return 0 ;
}


// load / save network data 
void CSimDoc::Serialize(CArchive& ar)
{       
	char buffer[256] ;
	
	if (ar.IsStoring())
	{                       
		if (!GetNetParams() || !GetCDPresent())
		   {
		   		AfxMessageBox("Network data incomplete",MB_ICONEXCLAMATION | MB_OK,0) ;
		   		return ;
		   }
		   
		// Save network data
		sprintf(buffer,"%d\n%d\n%d\n",GetCDPresent(),GetNetParams(),GetTDPresent()) ;
		ar.Write(buffer,strlen(buffer)) ;
		                                                                        
		inWidth = nInLayer[0] ;
		inDepth = 1 ;
		outWidth = nInLayer[nLayers - 1] ;
		outDepth = 1 ;                                                                        
		sprintf(buffer,"%d\n%d\n%d\n%d\n%d\n%d\n",nLayers,nPatterns,inWidth,inDepth,outWidth,outDepth) ;
		ar.Write(buffer,strlen(buffer)) ;
		
		sprintf(buffer,"%.5f\n%.5f\n%.5f\n%.5f\n",DocAcceptableError,DocLearningConstant,DocSamadCoefficient,DocMomentum) ;
		ar.Write(buffer,strlen(buffer)) ;
		
		int i ;
		for (i = 0 ; i < nLayers ; i++)
			{   
				sprintf(buffer,"%d ",nInLayer[i]) ;
				ar.Write(buffer,strlen(buffer)) ; 
			}

		
		// Find the Grid View
		POSITION pos = GetFirstViewPosition();
		CShowNetData* ShowView = (CShowNetData*) GetNextView(pos) ;
        CSimView*     SimView  = (CSimView*)     GetNextView(pos) ;
        CTrainData*   TrainView= (CTrainData*)   GetNextView(pos) ;
        
		ASSERT(TrainView != NULL);
		ASSERT(TrainView->IsKindOf(RUNTIME_CLASS(CTrainData)));
        
        // Construct a pointer to the grid
		CVBControl* pGrid = (CVBControl*)TrainView->GetDlgItem(IDC_TRAINDATA);
		ASSERT(pGrid != NULL);
		ASSERT(pGrid->IsKindOf(RUNTIME_CLASS(CVBControl)));

	    nPatterns = TrainView->GetDlgItemInt(IDC_TRAINPATTERNS,NULL,TRUE) ;
        
        // Read grid data. Exit if data is incomplete
		pGrid->SetNumProperty("SelStartRow",1) ;
    	int index = -1 ; int size ;
    	for (int col = 1 ; col <= nPatterns*2 ; col++)
       		{
	   			if (col % 2 == 1)
	   		   	   {
	   		    		index++ ;
	   					size = nInLayer[0] ;
	   		       }
	   			else
	   		   	   {	
	   					size = nInLayer[nLayers-1] ;
	   		   	   }
		    			
	   			pGrid->SetNumProperty("SelStartCol",col) ;
	   			pGrid->SetNumProperty("SelEndRow",size) ;
	   			pGrid->SetNumProperty("SelEndCol",col) ;
	        	CString data = pGrid->GetStrProperty("Clip") ;
    	    	char *pData = data.GetBuffer(1) ;
            	for (int element = 0 ; element < size ; element++)
    				{
						char *pToken = strtok(pData, " \t\r\n") ;
						pData = NULL ;                                           
					
    					if (pToken != NULL)
    				   	   {    
    				   	   		sprintf(buffer,"%.5f ",strtod(pToken,NULL)) ;
    		   			  		ar.Write(buffer,strlen(buffer)) ;
    		      	   	   }
    		      		else
       			   	   	   {
       			   	   	  		AfxMessageBox("Save abandoned, inconsistent pattern data",MB_ICONEXCLAMATION | MB_OK,0) ;
       			   	   	  		return ;
       			   	       }
       				}
			}       
    	pGrid->SetNumProperty("SelStartRow",0) ; // get rid of blue highlight
    	pGrid->SetNumProperty("SelStartCol",0) ;
    	pGrid->SetNumProperty("SelEndRow",0) ;
    	pGrid->SetNumProperty("SelEndCol",0) ;
        
        // write weights to file
		sprintf(buffer,"%d ",nCnxns) ;
		ar.Write(buffer,strlen(buffer)) ;
		for (i = 0 ; i < nCnxns ; i++)
			{   
				sprintf(buffer,"%.5f ",cnxn[i].weight) ;
				ar.Write(buffer,strlen(buffer)) ;
			}
	}
	else
	{
		// Load network data
		BOOL b ;
		
		DeallocateMem(TRUE,TRUE,TRUE,TRUE) ;
		 
        ReadFile(buffer,ar) ; sscanf(buffer,"%d",&b) ; SetCDPresent(b) ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%d",&b) ; SetNetParams(b) ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%d",&b) ; SetTDPresent(b) ;
		
		ReadFile(buffer,ar) ; sscanf(buffer,"%d",&nLayers)   ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%d",&nPatterns) ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%d",&inWidth)   ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%d",&inDepth)   ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%d",&outWidth)  ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%d",&outDepth)  ;
		
		ReadFile(buffer,ar) ; sscanf(buffer,"%f",&DocAcceptableError) ;
		
		ReadFile(buffer,ar) ; sscanf(buffer,"%f",&DocLearningConstant) ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%f",&DocSamadCoefficient) ;
		ReadFile(buffer,ar) ; sscanf(buffer,"%f",&DocMomentum)         ;
        
		InitLayers() ;
		        
        for (int atLayer = 0 ; atLayer < nLayers ; atLayer++)
        	{
        		ReadFile(buffer,ar) ; 
        		sscanf(buffer,"%d",&nInLayer[atLayer]) ;
			}

		InitCnxns() ;
        InitNeurons() ;
		InitPatterns() ;
		        
        for (int atPattern = 0 ; atPattern < nPatterns ; atPattern++)
        	{
				for (int i = 0 ; i < nInLayer[0] ; i++)
        			{
        				ReadFile(buffer,ar) ; sscanf(buffer,"%f",&pat[atPattern].in[i]) ;
        			}
				
				for (i = 0 ; i < nInLayer[nLayers-1] ; i++)
					{
						ReadFile(buffer,ar) ; sscanf(buffer,"%f",&pat[atPattern].out[i]) ;
					}
			}
			
		atPattern  = 0 ; 
		totalError = 0 ;
		SetDataPresent(TRUE) ;
		SetNetParams(TRUE)   ;
        SetNewDocument(TRUE) ;
        SetGridModified(TRUE);
        SetTDPresent(TRUE)   ;
        SetSuspended(FALSE)  ;
        SetTraining(FALSE)   ;
        
       	// Send OnPaint message to clear grid
	   	UpdateAllViews(NULL,0,NULL) ;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CSimDoc diagnostics

#ifdef _DEBUG
void CSimDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSimDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSimDoc commands

void CSimDoc::OnFileNew()
{
	CFileNewDlg dlg ;
	
	// Initialise dialog data
	dlg.m_nLayers = 2 ;
	dlg.m_Config  = 1 ;

	CListBox* ConfListBox = (CListBox*) dlg.GetDlgItem(IDC_CONFLISTBOX) ;

	// Invoke the dialog box
	if (dlg.DoModal() == IDOK)
	   {
	   		// retrieve the dialog data
	   		nLayers = dlg.m_nLayers ;            

            DeallocateMem(TRUE,TRUE,TRUE,TRUE) ; // clean up previous memory allocations
            
            // allocate memory for configuration details
            InitLayers() ;
	   		
	   		for (int i = 0 ; i < (int)(dlg.m_nLayers) ; i++)
	   			{
	   				// Get list box data
	   				nInLayer[i] = dlg.m_LBoxContents[i] ; 
                }
            
	   		InitNeurons() ;
	   		InitCnxns() ;
	   			
	   		SetCDPresent(dlg.m_ConfigDataPresent) ;
			SetNewDocument(TRUE);
            SetNetParams(FALSE) ;
			SetTDPresent(FALSE) ;
			SetTraining(FALSE)  ;            
			
       		// Send OnPaint message to display net
	   		UpdateAllViews(NULL,0,NULL) ;
	   }
}
                              

void CSimDoc::OnSetnetparams()
{
	if (!GetCDPresent())
	   {
	   		AfxMessageBox("Configure network first",MB_ICONEXCLAMATION | MB_OK,0) ;
			return ;
	   }
	
    CSetNetParams dlg ;
    
    dlg.ParamsPresent = GetNetParams() ;
	dlg.m_nAccError = DocAcceptableError ;
	dlg.m_nMomentum = DocMomentum	       ;
	dlg.m_nLearnConst = DocLearningConstant ;
	dlg.m_nSamadCoeff = DocSamadCoefficient ;
	
	// Invoke the dialog box and get network parameters
	if (dlg.DoModal() == IDOK)
	   {          
	   		DocAcceptableError = dlg.m_nAccError   ;
	   		DocMomentum        = dlg.m_nMomentum   ;
	   		DocLearningConstant= dlg.m_nLearnConst ;
	   		DocSamadCoefficient= dlg.m_nSamadCoeff ;
			SetNetParams(TRUE) ;
	   }
}


//////////////////////////////////////////////////////////////////////////
// Class Neuron methods

Neuron::Neuron(void)
{
    input = 0;
    output = 0;
    error = 0;
}


void Neuron::transfer(void)
{
    //This is the "classic" transfer function.
    output = 1.0 / (1.0 + exp(-1.0 * M_FACTOR * input)) ;
}


float Neuron::derivTransfer(float weightedSumOfErrors)
{
    error = output * (1 - output) * weightedSumOfErrors;
    return error;
}

///////////////////////////////////////////////////////////////////////////
// Class Connection methods

void Connection::adjust(void)
{
    //If samad Coefficient == 0 this is "classic" backprop
    //If samad Coefficient == 1 this is original "fast backprop"
    //If samad Coefficient is something else, you will usually get significant 
    //changes in learning rate.  The range 0.5 - 2.0 seems to work well 
    delta = learningConstant * n2->error * (n1->output + samadCoefficient * n1->error) + delta * momentum;
    weight += delta;
}

void Connection::displaySelf(void)
{
    // cout<<"Connection delta: "<<delta<<" weight: "<<weight<<"\n";
}


void Connection::feedForward(void)
{
    n2->input += n1->output * weight;
}


void Connection::set(Neuron* nLow, Neuron* nHigh)
{
    n1 = nLow;
    n2 = nHigh;
}
 
 
void Connection::setRandom(float lC, float m, float sC)
{
    weight = (((float)rand()/RAND_MAX) - 0.5) / 5;
    delta = 0;
    learningConstant = lC;
    momentum = m;
    samadCoefficient = sC;
}


int Connection::firstNeuronIs(Neuron* n)
{

    if(n == n1)
        return 1;
    else
        return 0;
}

int Connection::secondNeuronIs(Neuron* n)
{
    if(n == n2)
        return 1;
    else
        return 0;
}

///////////////////////////////////////////////////////////////////////////
// Class Network methods

#define sqr(x) ( x * x)
#define differ(diff) (diff  < 0 ? (diff * (log(diff * -1.0) * -1.0)) : (diff * (diff > 1.0 ? log(diff) : log(diff) * -1.0)))
       
       
void CSimDoc::adjustWeights(void)
{   
    for (int atCnxn = 0; atCnxn < nCnxns ; atCnxn++)
    	{   
        	cnxn[atCnxn].adjust();
        }
}
         
         
void CSimDoc::allForward(void)
{        
	for (int atPattern = 0; atPattern < nPatterns ; atPattern++)
    	{
        	forwardPass();
        	// displayDiff();
    	}
}
        
        
void CSimDoc::backwardProp(void)
{
    calcOutputError();
    calcMiddleError();
    adjustWeights();
}
        
        
void CSimDoc::calcMiddleError(void)
{
    //This would need to be reworked for a multi-middle layer network
    for (int atMidNeurode = 0; atMidNeurode < nInLayer[1]; atMidNeurode++)
    	{
        	float weightedSumOfErrors = 0;
        	int offset = nInLayer[0]*nInLayer[1] + nInLayer[2] * atMidNeurode;
        	
        	for (int atHighNeurode = 0; atHighNeurode < nInLayer[nLayers - 1]; atHighNeurode++)
        		{      
            		weightedSumOfErrors += cnxn[offset + atHighNeurode].n2->error * cnxn[offset + atHighNeurode].weight;
            	}
        	neuron[1][atMidNeurode]->derivTransfer(weightedSumOfErrors);
    	}
}
  

void CSimDoc::calcOutputError(void)
{
    thisPatternError = 0 ;
    for (int atNeurode = 0; atNeurode < nInLayer[nLayers - 1]; atNeurode++)
    	{
        	float diff = pat[atPattern].out[atNeurode] - neuron[nLayers - 1][atNeurode]->output;
            
			//You may just pass diff to calcLocalError for "classic" backprop
    		//Or you can square it for "Quadratic" error func
    		//Or you can cube it for "Cubic" error func.
    		neuron[nLayers - 1][atNeurode]->derivTransfer(diff);
    		    		
    		if (diff < 0)
       		   {
        			if (diff < -acceptableError)
        	   		   {
            				thisPatternError -= diff;
               		   }
       		   }
    		else
       		   {
        			if (diff > acceptableError)
        	   		   {
        					thisPatternError += diff;
        	   		   }
       		   }
    	}
    
    if (thisPatternError > acceptableError)
       {
        	totalError += thisPatternError;
       }
}


BOOL CSimDoc::atEpochEnd(void)
{
    if (atPattern == nPatterns - 1)
       {
			atPattern = 0 ;
         	++iteration   ;
        	return TRUE   ;
       }
    else
       {
       		atPattern++  ;
        	return FALSE ;
       }
}
  

void CSimDoc::forwardPass(void)
{
	// Zero all inputs
	for (int atLayer = 0; atLayer < nLayers ; atLayer++)
	{
		for (int atNeuron = 0; atNeuron < nInLayer[atLayer]; atNeuron++)
			{      
				neuron[atLayer][atNeuron]->input = 0.0;
			}
    }        

    //First, put the input pattern directly into the input neuron's output
    //queues.
	for (int atNeuron = 0; atNeuron < nInLayer[0]; atNeuron++)
		{              
        	neuron[0][atNeuron]->output = pat[atPattern].in[atNeuron];
        }
    
    //Then, for each layer, feedforward
    int cnxnNumber = 0;
    int offset = 0;
    for (atLayer = 1; atLayer <= nLayers - 1 ; atLayer++)
    	{
			int nCons = nInLayer[atLayer] * nInLayer[atLayer - 1] ;
			
			for (cnxnNumber = offset; cnxnNumber < nCons + offset; cnxnNumber++)
				{
            		cnxn[cnxnNumber].feedForward() ;
            	}
            	
        	offset += nCons;
        	
        	for (atNeuron = 0; atNeuron < nInLayer[atLayer] ; atNeuron++)
        		{
            		neuron[atLayer][atNeuron]->transfer() ;
            	}
		}
}
        
     
BOOL CSimDoc::trained(void)
{
    if (totalError < acceptableError)
       {
			return TRUE ;
	   }
    else
       {
        	return FALSE ;
       }
}


void CSimDoc::OnTest()
{                        
	if (!GetTraining())
	   {
	   		AfxMessageBox("Must create and train network",MB_ICONEXCLAMATION | MB_OK,0) ;
	   		return ;
	   }

	if (CTest(*this).DoModal() == IDOK)
	   {    
	   }	
}

void CSimDoc::OnWatch()
{
	if (!GetCDPresent())
	   {
	   		AfxMessageBox("Configure neural network!",MB_ICONEXCLAMATION | MB_OK,0) ;
	   		return ;
	   }
	
	if (Watch(*this).DoModal() == IDOK)
	   {
	   }
	
	// Update screen to clear unwanted text
	UpdateAllViews(NULL,0,NULL) ;
}

void CSimDoc::OnImageZoomin()
{      
	if (!GetCDPresent())
	   {
	   		AfxMessageBox("Configure net first!",MB_ICONEXCLAMATION | MB_OK,0) ;
	   		return ;
	   }
	   
	Scale += 0.2 ;

	// send WM_PAINT message to invoke drawing of the scaled net	
    UpdateAllViews(NULL,0,NULL) ;
}

void CSimDoc::OnImageZoomout()
{   
	if (!GetCDPresent())
	   {
	   		AfxMessageBox("Configure net first!",MB_ICONEXCLAMATION | MB_OK,0) ;
	   		return ;
	   }
	   
	if (Scale > 1.2)
	   {
	   		Scale -= 0.2 ;	
	   }
	
	UpdateAllViews(NULL,0,NULL) ;
}


	