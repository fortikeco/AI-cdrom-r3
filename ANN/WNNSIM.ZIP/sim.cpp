// sim.cpp : Defines the class behaviors for the application.
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"
#include "traindat.h"

#ifndef __SIMDOC_H__
#define __SIMDOC_H__
#include "simdoc.h"
#endif            

#include "viewnetv.h"
#include "simview.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimApp

BEGIN_MESSAGE_MAP(CSimApp, CWinApp)
	//{{AFX_MSG_MAP(CSimApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimApp construction

CSimApp::CSimApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSimApp object

CSimApp NEAR theApp;

/////////////////////////////////////////////////////////////////////////////
// CSimApp initialization

BOOL CSimApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	SetDialogBkColor();        // set dialog background color to gray
	LoadStdProfileSettings();  // Load standard INI file options (including MRU)
    EnableVBX() ;
    
	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	AddDocTemplate(new CSingleDocTemplate(IDR_MAINFRAME,
			RUNTIME_CLASS(CSimDoc),
			RUNTIME_CLASS(ViewNetVars),
			RUNTIME_CLASS(CTrainData)));



	// simple command line parsing
	if (m_lpCmdLine[0] == '\0')
	{
		// create a new (empty) document
		OnFileNew();
	}
	else
	{
		// open an existing document
		OpenDocumentFile(m_lpCmdLine);
	}

	// Simulator is not running
	m_SimRunning = FALSE ;
	
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CSimApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CSimApp commands


//{{AFX_VBX_REGISTER_MAP()
	UINT NEAR VBN_CLICK = AfxRegisterVBEvent("CLICK");
	UINT NEAR VBN_GOTFOCUS = AfxRegisterVBEvent("GOTFOCUS");
	UINT NEAR VBN_ROWCOLCHANGE = AfxRegisterVBEvent("ROWCOLCHANGE");
	UINT NEAR VBN_SELCHANGE = AfxRegisterVBEvent("SELCHANGE");
	UINT NEAR VBN_MOUSEDOWN = AfxRegisterVBEvent("MOUSEDOWN");
	UINT NEAR VBN_KEYPRESS = AfxRegisterVBEvent("KEYPRESS");
	UINT NEAR VBN_KEYUP = AfxRegisterVBEvent("KEYUP");
	UINT NEAR VBN_KEYDOWN = AfxRegisterVBEvent("KEYDOWN");
//}}AFX_VBX_REGISTER_MAP                                 
