// watch.cpp : implementation file
// 					Handles the watch dialog box for the user to specify
//					watch ing connections between layers
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"
#include "watch.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#define MAXSTRINGLEN 20

/////////////////////////////////////////////////////////////////////////////
// Watch dialog

// pointer to document is included so all document data and methods
// may be referenced through m_myDoc

Watch::Watch(CSimDoc& myDoc)
	: CDialog(Watch::IDD, NULL), m_myDoc(myDoc)
{
	//{{AFX_DATA_INIT(Watch)
		m_nConnections = 0 ;
		m_Connection = 0 ;
		m_ConnList = "" ;
		m_bDataPresent = FALSE ;
		m_bChange = FALSE ;
	//}}AFX_DATA_INIT
}

void Watch::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Watch)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(Watch, CDialog)
	//{{AFX_MSG_MAP(Watch)
	ON_BN_CLICKED(IDC_WADD, OnClickedWadd)
	ON_LBN_SELCHANGE(IDC_CONNECTIONLIST, OnSelchangeConnectionlist)
	ON_BN_CLICKED(IDC_WREMOVE, OnClickedWremove)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Watch message handlers

void Watch::OnClickedWadd()
{
	char szValue[20] ;
	CWnd* Text ;
	int nLength ;
	int value ;
	
	Text = GetDlgItem(IDC_CONNECTION) ;
	nLength = Text->GetWindowTextLength() ;
	Text->GetWindowText(szValue,nLength+1) ;
	szValue[nLength] = '\0' ;
	
	value = atoi(szValue) ;
	                          
	// Check range of Config value is acceptable
	if ( (value >= 0) && (value <= m_myDoc.nLayers-2) )
	   {
	   		GetDlgItem(IDC_CONNECTION)->SetWindowText(szValue) ;
	   }
	else
	   {
	   		MessageBox("An invalid value has been entered",
	   			"Neural Network Simulator",MB_ICONEXCLAMATION|MB_OK) ;
	   		return ;
	   }
	                
	// Check for integer input
	if ((char*)memchr(szValue,'.',nLength) != NULL)
	   {
	   		MessageBox("Please input an integer",
	   			"Neural Network Simulator",MB_ICONEXCLAMATION|MB_OK) ;
	   		return ;
	   }
	   		
	CListBox* ConnectionListBox = (CListBox*) GetDlgItem(IDC_CONNECTIONLIST) ;
	
	if ( !m_bChange )
	   {            
	   		m_Index = ConnectionListBox->GetCount() ;
	   		ConnectionListBox->SetCurSel(m_Index) ;
	   		ConnectionListBox->InsertString(m_Index,szValue) ;
	   }
	else
	   {
	   		ConnectionListBox->DeleteString(m_Index) ; // m_nIndex points to selected string
	   		ConnectionListBox->InsertString(m_Index,szValue) ;
	   		
	   		m_bChange = FALSE ;
	   		GetDlgItem(IDC_WADD)->SetWindowText("Add") ;
	   		GetDlgItem(IDC_WREMOVE)->EnableWindow(FALSE) ;
	   		
	   		// Now no item is selected
	   		m_Index = -1 ;
	   		ConnectionListBox->SetCurSel(m_Index) ;
	   	}
}

void Watch::OnSelchangeConnectionlist()
{
	// create a pointer to the list box
	CListBox* ConnectionListBox = (CListBox*)GetDlgItem(IDC_CONNECTIONLIST) ;

	// get the index of the selected list box item
	// used for change purposes 
	m_Index = ConnectionListBox->GetCurSel() ;
	
	if (m_Index == LB_ERR)
	   {
	   		m_Index = -1 ;
	   		return ;
	   }
	   
	m_bChange = TRUE ;

	// Change text on ADD button to CHANGE
	// and enable REMOVE button
	GetDlgItem(IDC_WADD)->SetWindowText("Change") ;
	GetDlgItem(IDC_WREMOVE)->EnableWindow() ;
}

void Watch::OnClickedWremove()
{
	if ( m_bChange )
	   {
	   		CListBox* ConnectionListBox = (CListBox*)GetDlgItem(IDC_CONNECTIONLIST) ;
	   		
	   		ConnectionListBox->DeleteString(m_Index) ;
	   		
	        // Now no item is selected
	        m_Index = -1 ;
	        ConnectionListBox->SetCurSel(m_Index) ;
	        
	        m_bChange = FALSE ;
	        GetDlgItem(IDC_WADD)->SetWindowText("Add") ;
	        GetDlgItem(IDC_WREMOVE)->EnableWindow(FALSE) ;
	   }
}

void Watch::OnOK()
{
	CListBox* ConnectionListBox = (CListBox*)GetDlgItem(IDC_CONNECTIONLIST) ;

	if (m_myDoc.m_nCnxnsToWatch > 19) // 20 - 1
	   {
	   		MessageBox("Error!, too many connections","Neural Net Simulator",
	   					MB_ICONEXCLAMATION | MB_OK) ;
	   		return ;
	   }
	else
	   {
			m_myDoc.m_nCnxnsToWatch = ConnectionListBox->GetCount() ;
	   }
	   
    char szLabel[MAXSTRINGLEN] ;    
    int nLength ;
	for (int i = 0 ; i < ConnectionListBox->GetCount() ; i++)
		{
			nLength = ConnectionListBox->GetText(i,szLabel) ;
			szLabel[nLength] = '\0' ;
			m_myDoc.m_WatchBoxContents[i] = atoi(szLabel) ;
		}
			     
    m_bDataPresent = TRUE ;
	m_myDoc.SetWDPresent(TRUE) ;
	
	CDialog::OnOK();
}


BOOL Watch::OnInitDialog()
{   
	char szValue[20] ;
	
	CDialog::OnInitDialog();
	
	m_bDataPresent = m_myDoc.GetWatchData() ;

	CListBox* ConnectionListBox = (CListBox*)GetDlgItem(IDC_CONNECTIONLIST) ;

	if ( m_bDataPresent )
	   {    
	   		for (int i = 0 ; i < m_myDoc.m_nCnxnsToWatch ; i++)
	   			{
	   				sprintf(szValue,"%d",m_myDoc.m_WatchBoxContents[i]) ;
	   				ConnectionListBox->InsertString(i,szValue) ;
	   			}
	   }
	   
	return TRUE;  // return TRUE  unless you set the focus to a control
}
