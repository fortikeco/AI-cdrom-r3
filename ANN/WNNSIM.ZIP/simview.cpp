// simview.cpp : implementation of the CSimView class
// 					Handles the visual representation of the neural net
//					which is displayed in the bottom left-hand splitter window
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"

#include "simdoc.h"
#include "simview.h" 

#include "viewnetv.h"
#include "shownetd.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimView

IMPLEMENT_DYNCREATE(CSimView,CScrollView)

BEGIN_MESSAGE_MAP(CSimView,CScrollView)
	//{{AFX_MSG_MAP(CSimView)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimView construction/destruction

CSimView::CSimView()
{                
}

CSimView::~CSimView()
{
}

/////////////////////////////////////////////////////////////////////////////
// CSimView drawing

void CSimView::OnDraw(CDC* pDC)
{
	CSimDoc* sDoc = GetDocument();

	CBrush newbrush ;
	CPen newpen ;
	CPen* oldpen ;
	CRect screenPos ;
	
	GetClientRect(screenPos) ;
	
	if (sDoc->GetCDPresent())
	   {
			short Diameter = 20 * sDoc->Scale ;
			short MaxnInLayer = 0 ;
            
            // find the maximum number of neurons out of all the layers
			for (int i = 0 ; i < sDoc->nLayers ; i++)
				{
					if (sDoc->nInLayer[i] > MaxnInLayer)
					   {
					   		MaxnInLayer = sDoc->nInLayer[i] ;
					   } 
				}
					
			newpen.CreatePen(PS_SOLID,3,RGB(0,0,0)) ;
			oldpen = pDC->SelectObject(&newpen) ;   
			int x, y, xStep, yStep, height ; 
			
			height = (MaxnInLayer*Diameter*1.5)*sDoc->Scale ;
			xStep = 100 * sDoc->Scale ;			
			for (i = 0 ; i < sDoc->nLayers ; i++)
				{
					yStep = (height / (sDoc->nInLayer[i] + 1))*sDoc->Scale ;
					for (int j = 0 ; j < sDoc->nInLayer[i] ; j++)
						{
							x = i*xStep ;                     
							y = ((j+1)*yStep) - Diameter ;
					   		
							pDC->Ellipse(x,y,x+Diameter,y+Diameter) ;
						}
				}
			
			// delete pen object
			pDC->SelectObject(oldpen) ;
			newpen.DeleteObject() ;
				
			// Interconnect neurons
			newpen.CreatePen(PS_SOLID,1,RGB(255,0,0)) ;
			oldpen = pDC->SelectObject(&newpen) ;
			int xInterval, yInterval1, yInterval2, xS, yS, xF, yF ;
			
			xInterval = 100 * sDoc->Scale ;
			for (i = 0 ; i < (sDoc->nLayers - 1) ; i++)
				{
					yInterval1 = (height/((sDoc->nInLayer[i])+1))*sDoc->Scale ;
					yInterval2 = (height/((sDoc->nInLayer[i+1])+1))*sDoc->Scale ;
					xS = (Diameter/2) + (xInterval*i) ;
					
					for (int j = 0 ; j < sDoc->nInLayer[i] ; j++)
						{
							yS = yInterval1*(j+1) ;
							
							for (int k = 0 ; k < sDoc->nInLayer[i+1] ; k++)
								{
									pDC->MoveTo(xS+(Diameter/2),yS-(Diameter/2)) ;
									
									xF = xS + xInterval ;
									yF = yInterval2*(k+1) ;
									
									pDC->LineTo(xF-(Diameter/2),yF-(Diameter/2)) ;
								}
						}			
				}
				
			// delete pen object
			pDC->SelectObject(oldpen) ;
			newpen.DeleteObject() ;
		}                           
}

/////////////////////////////////////////////////////////////////////////////
// CSimView printing

BOOL CSimView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSimView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSimView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSimView diagnostics

#ifdef _DEBUG
void CSimView::AssertValid() const
{
	CView::AssertValid();
}

void CSimView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSimDoc* CSimView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSimDoc)));
	return (CSimDoc*) m_pDocument;
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////
// Message handling functions

void CSimView::OnInitialUpdate()
{
	SetScrollSizes(MM_TEXT,GetDocument()->GetDocSize()) ;
	
	GetDocument()->UpdateAllViews(NULL,0,NULL) ;
}