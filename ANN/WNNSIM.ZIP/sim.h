// sim.h : main header file for the SIM application
//
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSimApp:
// See sim.cpp for the implementation of this class
//

class CSimApp : public CWinApp
{
public:
	CSimApp();
    BOOL m_SimRunning ;
    
// Overrides
	virtual BOOL InitInstance();

// Implementation

	//{{AFX_MSG(CSimApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////


//{{AFX_VBX_REGISTER()
	extern UINT NEAR VBN_CLICK;
	extern UINT NEAR VBN_GOTFOCUS;
	extern UINT NEAR VBN_ROWCOLCHANGE;
	extern UINT NEAR VBN_SELCHANGE;
	extern UINT NEAR VBN_MOUSEDOWN;
	extern UINT NEAR VBN_KEYPRESS;
	extern UINT NEAR VBN_KEYUP;
	extern UINT NEAR VBN_KEYDOWN;
//}}AFX_VBX_REGISTER
