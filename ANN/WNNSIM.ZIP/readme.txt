Copy grid.vbx into the windows\system directory before running simulator.

nns.doc - WordPerfect user manual
nns.txt - ascii text user manual
