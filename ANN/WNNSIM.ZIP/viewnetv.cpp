// viewnetv.cpp : implementation file
//					Sets up the three views, the view for displaying network
//					data, the main document view for the graphical representation and
//					the grid view.
//					The three splitter windows are achieved by using a single splitter
//					window then another splitter window in one of its panes. 
// Company	  : Synaptek Ltd.
// Address    :	TEDCO
//				Eldon Street
//				South Shields
//				Tyne & Wear
//				NE33 5JE
// Authors    : Dominic Wright
//				Gordon Stutchbury
// Thanks to  : Larry O'Brien (Editor AI Expert) for neural network code
// Version	  : 1.0
// Date    	  : September 1993
// Comments   : This software is freely distributable. Feel free to use any parts of the
//			 	code for your own applications and make any extensions you wish.
//			 	This program saves connection weights but does not restore them
//			 	allowing a user to stop a simulation to continue at a later time.
//				This is an obvious extension.

#include "stdafx.h"
#include "sim.h"
#include "viewnetv.h"
#include "shownetd.h"

#ifndef __SIMDOC_H__
#define __SIMDOC_H__
#include "simdoc.h"
#endif

#include "simview.h"

#ifndef __TRAIN__
#define __TRAIN__
#include "traindat.h"
#endif

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ViewNetVars

IMPLEMENT_DYNCREATE(ViewNetVars, CFrameWnd)

ViewNetVars::ViewNetVars()
{
}

ViewNetVars::~ViewNetVars()
{
}                             

BEGIN_MESSAGE_MAP(ViewNetVars, CFrameWnd)
	//{{AFX_MSG_MAP(ViewNetVars)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// arrays of IDs used to initialize control bars

// toolbar buttons - IDs are command buttons
static UINT BASED_CODE buttons[] =
{
	// same order as in the bitmap 'toolbar.bmp'
	ID_FILE_NEW,
	ID_FILE_OPEN,
	ID_FILE_SAVE,
		ID_SEPARATOR,
	ID_SIMULATION_SETNETPARAMS,
		ID_SEPARATOR,
	ID_FILE_PRINT,
		ID_SEPARATOR,
	ID_STARTSIMULATION,
	ID_STOPSIMULATION,
	ID_CONTINUESIMULATION,
		ID_SEPARATOR,
	ID_TEST,
	ID_WATCH,
		ID_SEPARATOR,
	ID_IMAGE_ZOOMIN,
	ID_IMAGE_ZOOMOUT,
		ID_SEPARATOR,
	ID_APP_ABOUT,
};

static UINT BASED_CODE indicators[] =
{
	ID_SEPARATOR,			// status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// ViewNetVars message handlers

BOOL ViewNetVars::OnCreateClient(LPCREATESTRUCT /*lpcs*/, CCreateContext* pContext)
{               
	CRect rect ;
	GetClientRect(&rect) ;
	
	CSize size = rect.Size() ;
	size.cy /= 2 ;
	
	if (!m_wndSplitter.CreateStatic(this,2,1,WS_CHILD | WS_VISIBLE,AFX_IDW_PANE_FIRST))
	   {
			TRACE("Failed to create Static Splitter\n") ;
			return FALSE ;
	   }
	   
	if (!m_wndSplitter2.CreateStatic(
			&m_wndSplitter,
			1,2,
			WS_CHILD | WS_VISIBLE | WS_BORDER,
			m_wndSplitter.IdFromRowCol(1,0)))
	{
		TRACE("Failed to create nested splitter\n") ;
		return FALSE ;
	}
	
	if (!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(CShowNetData),size,pContext))
	   {
	   		TRACE("Failed to create first pane\n") ;
	   		return FALSE ;
	   }
	
	size.cx /= 2 ;
	if (!m_wndSplitter2.CreateView(0,0,RUNTIME_CLASS(CSimView),size,pContext))
	   {
	   		TRACE("Failed to create second pane\n") ;
	   		return FALSE ;
	   }
	
    if (!m_wndSplitter2.CreateView(0,1,RUNTIME_CLASS(CTrainData),size,pContext))
       {
       		TRACE("Failed to create third pane\n") ;
       		return FALSE ;
       }
    
	SetActiveView((CScrollView*)m_wndSplitter.GetPane(0,0)) ;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadBitmap(IDR_MAINFRAME) ||
		!m_wndToolBar.SetButtons(buttons,
		  sizeof(buttons)/sizeof(UINT)))
	{
		TRACE("Failed to create toolbar\n");
		return -1;		// fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE("Failed to create status bar\n");
		return -1;		// fail to create
	}

	return TRUE ;         
}
