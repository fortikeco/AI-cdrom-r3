

/* sptmp.c */

#include  "sptmp.h"


struct nets   *STN_sys;




void normalize_vector(float *vector,  int vector_length )
{
	float		magnitude;
	int		i;

	for (i =0;i < vector_length; i++)
	{
		magnitude += vector[i] * vector[i];
	}

	magnitude = sqrt( (double)magnitude);

	for (i =0;i < vector_length; i++)
	{
   	vector[i] = vector[i] / magnitude; 
	}

}


float dot_product(float  *a, float  *b, int length)
{
 	int 	i;
	float 	prod = 0.0;

	for (i = 0; i < length; i++)
		{
		   prod += a[i] * b[i];
		}
	return(prod);
}



void calc_x(struct st_network  *net, float  *Q)
{
	float		unit_input1;
	float		unit_input2;
	int		i, j;
	float		activation;
	float		u_plus, delta_x;
	

	for (i = 0; i < STN_sys->num_units; i++)
		{
			unit_input2 = 0.0;

			unit_input1 = dot_product(net->z[i], Q,
			                          STN_sys->num_inputs);
/*printf("unit %d  input1 = %f\n", i, unit_input1);
*/
			for (j = 0; j < i; j++)
			   unit_input2 += net->x[j];
/*printf("unit %d  input2 = %f\n", i, unit_input2);
*/
			activation = unit_input1 + (net->d * unit_input2);
/*printf("unit %d  activation = %f\n", i, activation);
*/

		 	u_plus = activation - net->Gamma;
			if (u_plus > 0)
			   u_plus *= net->b;
			else
			   u_plus = 0.0;
/*printf("unit %d  u+ = %f\n", i, u_plus);
*/
			delta_x = (net->x[i] * -net->a) + u_plus;
			if (delta_x <= 0.0)
			   delta_x *= net->c;
/*printf("unit %d  delta x = %f\n", i, delta_x);
*/
			net->x[i] += delta_x;
          if (net->x[i] > 1.0)
			   net->x[i] = 1.0;
		}

	for (i = 0; i < STN_sys->num_units; i++)
		{
printf(" x%d = %f\n", i, net->x[i]);
      }
}




void  examine_output()
{

}




void process_pattern(float  *pattern)
{
	int	i;


	for (i = 0; i < STN_sys->num_networks; i++)
		{
		 	calc_x(STN_sys->st_net[i], pattern);
			STN_sys->y[i] = STN_sys->st_net[i]->x[STN_sys->num_units - 1];
		}

	for (i = 0; i < STN_sys->num_networks; i++)
printf(" y%d = %f\n", i, STN_sys->y[i]);		                                   
}



int  read_input_file(int inputs)
{
	int 	i, j;
	float  temp;
	FILE   *fp;
	char   patterns[5];
   int	num_patterns;
   char	filename[15];


	/* get input file name */
	printf("\n\nEnter name of input file: ");
	scanf("%s", filename);

	fp = fopen(filename, "r");
	if (fp == NULL)
		{
			printf("\n\nUnable to open file");
			pause();
		}

	printf("\n\nNumber of patterns to process: ");
	scanf("%s", patterns);
	num_patterns = atoi(patterns);

 	STN_sys->Qs = (float **)calloc(num_patterns*STN_sys->num_units,
		                            sizeof(float *) );
	for (i = 0; i < num_patterns*STN_sys->num_units; i++)
		{
			STN_sys->Qs[i] = (float *)calloc(inputs, sizeof(float) );
			for (j = 0; j < inputs; j++)
			   {
			   		fscanf(fp, "%f", &temp);
					STN_sys->Qs[i][j] = temp; 
			   }
			normalize_vector(STN_sys->Qs[i], inputs);
		}

	return(num_patterns*STN_sys->num_units);
}


void set_parameters(struct st_network  *net)
{
	char		as_a[5];
	char		as_b[5];
	char		as_c[5];
	char		as_d[5];
	char		as_gamma[5];


	printf("\nEnter value for a: ");
	scanf("%s", as_a);
	net->a = atof(as_a);

	printf("\nEnter value for b: ");
	scanf("%s", as_b);
	net->b = atof(as_b);

	printf("\nEnter value for c: ");
	scanf("%s", as_c);
	net->c = atof(as_c);

	printf("\nEnter value for d: ");
	scanf("%s", as_d);
	net->d = atof(as_d);

	printf("\nEnter value for Gamma: ");
	scanf("%s", as_gamma);
	net->Gamma = atof(as_gamma);


}


void set_weights(struct st_network  *net, int  units, int inputs)
{
	FILE	 *fp;
	int	 net_size;
	int	 vec_size;
	int	 i, j;
	char	 filename[15];
	float   temp;


	printf("\n\nEnter name of weight file :");
	scanf("%s", filename);

	fp = fopen(filename, "r");
	if (fp == NULL)
		{
			printf("Unable to open file");
			pause();
		}

	fscanf(fp, "%d", &net_size);
	fscanf(fp, "%d", &vec_size);
	if ( (net_size != units) ||
		  (vec_size != inputs) )
	   {
			printf("\nweight file incompatible with network size");
			pause();
			return;
		}

	for (i = 0; i < units; i++)
	   {
			for (j = 0; j < inputs; j++)
			   {
		   			fscanf(fp, "%f", &temp);
					net->z[i][j] = temp;
			   }
			normalize_vector(net->z[i], vec_size);
	   }


}






struct st_network  *make_network(int  units, int inputs)
{
	struct st_network	*net;
	int				i;


	net = (struct st_network *)calloc(1, sizeof(struct st_network) );

	net->x = (float  *)calloc(units, sizeof(float) );

	net->z = (float **)calloc(units, sizeof(float *) );
	for (i = 0; i < units; i++)
		{
			net->z[i] = (float *)calloc(inputs, sizeof(float) );
		}

	set_parameters(net);

	set_weights(net, units, inputs);

 return(net);
}


struct nets  *make_system(int  num_networks, int num_units, int num_inputs)
{
	char		    number[4];
	struct nets	*system;
	int			i;


	system = (struct nets *)calloc(1, sizeof(struct nets) );

	system->num_networks = num_networks;
	system->num_units = num_units;
	system->num_inputs = num_inputs;
	system->y = (float *)calloc(num_networks, sizeof(float) );
	system->st_net = (struct st_network  **)calloc(num_networks,
		                                       sizeof(struct st_network *) );

	for (i = 0; i < num_networks; i++)
		{

	    	system->st_net[i] = make_network(num_units, num_inputs);

		}

	return(system);
}


void  clear_outputs(int  nets, int  units)
{
 	int	i, j;

	for (i = 0; i < nets; i ++)
		for (j = 0; j < units; j++)
		   STN_sys->st_net[i]->x[j] = 0.0;
}



void main()
{
	char       	choice[5];
	char			number[5];
	char			filename[15];
	int            quit, i;
	int	    	sys_size, net_size, input_size, file_size;
	float      	temp;

	quit = 0;

while (quit != 1)
{
	printf("1 - Initialize system\n");
	printf("2 - Run\n");
	printf("q - Quit\n");
	printf("\n");
	printf("   Your selection: ");

	scanf("%s", choice);

	if (is_it(choice, "1")==1)
		{
			printf("\n\nEnter number of networks in system: ");
			scanf("%s", number);
			sys_size = atoi(number);

			printf("\n\nEnter number of units in each network: ");
			scanf("%s", number);
			net_size = atoi(number);

			printf("\n\nEnter number of inputs to each unit: ");
			scanf("%s", number);
			input_size = atoi(number);

			STN_sys = make_system(sys_size, net_size, input_size);
		}
	else
	if (is_it(choice, "2")==1)
		{
			file_size = read_input_file(input_size);

			clear_outputs(sys_size, net_size);

			for (i = 0; i < file_size; i++)
	       	{
printf(" time %d \n", i);
					process_pattern(STN_sys->Qs[i]);
pause();
					examine_output();
				}

		}
	else
	if(is_it(choice, "q")==1)
		{
			free(STN_sys);
			quit = 1;
		}

} /* end while quit != 1 */



}



int is_it(char  *str1, char  *str2)
{
	if (strcmp(str1, str2)==0)
		return(1);
	else
		return(0);
}


void  pause(void)
{
	int	ch;

	fflush(stdin);
	while(!kbhit());
	ch = getch();
	ch = ch;
}





 /*

calc_Gamma()
{
	S = calc_S();
	Gamma = (alpha * (S - T) )  + (beta * ??)
}


float  calc_S()
{
	for (i = 0; i < num_units; i++)
		{
			S += x[i];
		}
	return(S);
}

*/



