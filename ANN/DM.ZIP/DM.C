/*                               DM V2.0
                                 =======

                        (c) Said Baloui, FEB 1990
                        -------------------------
*/
/*--------------------------------------------------------------------------

	INCLUDES
	--------
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <process.h>
#include <math.h>
#include <io.h>
#ifdef __TURBOC__
  #include <alloc.h>
#else
  #include <malloc.h>
#endif
/*--------------------------------------------------------------------------

	DEFINES
	-------
*/
#define DAT_TYPE   float  /* verwendeter Zahlentyp f�r die Rohdaten */
#define L_SIZE     5000   /* maximale L�nge der zu lesenden Eingabezeilen */
#define MAX_BREITE 20     /* max.Breite der auszugebenden Zahlen, gleich- */
			  /* zeitig max.Breite einer Spalten�berschrift */
#define DISTANCE   1.2	  /* �berh�hungsfaktor f�r Minima-/Maxima-Werte */
/*--------------------------------------------------------------------------

	FUNKTIONEN
	----------
*/
int   main(int argc, char *argv[]);
void  dm_outofmem_err(void);
void  dm_read_err(char *file);
void  dm_write_err(char *file);
void  dm_col_err(char *col);
void  dm_errline(void);
void  dm_read_file(char *file_in);
void  dm_del_zeros(void);
int   dm_read_line(FILE *fp_in);
void  dm_write_file(char *file_out);
void  dm_write_datfile(char *file_out, int *stellen);
void  dm_write_brainfile(char *file_out, int *stellen);
void  dm_extract(char *fct, char *run, int first, int last, int *stellen);
int  *dm_calc_width(void);
void  dm_write_head(FILE *fp_out, char *head, int breite);
void  dm_write_number(FILE *fp_out, DAT_TYPE number, int breite);
void  dm_create_col(char *col_neu);
void  dm_delete_col(char *col_del);
int   dm_search_col(char *col);
void  dm_init_calc(char *col1, char *col2, char *col_neu, int *nr1, int *nr2);
void  dm_init_calc1(char *col, char *col_neu, int *nr_alt, int *nr_neu);
void  dm_add_const(char *col, float number, char *col_neu);
void  dm_sub_const(char *col, float number, char *col_neu);
void  dm_mul_const(char *col, float number, char *col_neu);
void  dm_div_const(char *col, float number, char *col_neu);
void  dm_add_col(char *col1, char *col2, char *col_neu);
void  dm_sub_col(char *col1, char *col2, char *col_neu);
void  dm_mul_col(char *col1, char *col2, char *col_neu);
void  dm_div_col(char *col1, char *col2, char *col_neu);
void  dm_shift_down_col(char *col, int shift, char *col_neu);
void  dm_shift_up_col(char *col, int shift, char *col_neu);
void  dm_diff_col(char *col, int shift, char *col_neu);
void  dm_class_col(char *col, char *typ);
void  dm_ctrfile(char *file_ctr);
void  dm_statistics(void);
void  dm_total(void);
/*--------------------------------------------------------------------------

	GLOBALE VARIABLEN
	-----------------
*/

/* Allgemein */
char  copyright[] = "(c) Said Baloui, FEB 1990";
char  **header;              /* Array mit Pointern auf d.Spalten�berschriften */
DAT_TYPE **array;            /* Array mit Pointern auf die Arrays */
int   cols;                  /* Spaltenanzahl (ab 1) */
int   rows;                  /* Zeilenanzahl (ab 1) */
char *class;	             /* String mit Spalten-Klassifikation f�r BrainM. */
int   basis, result;         /* Anzahl der als Basis/Result verwendeten Spalten*/
int   hidden_neurons;        /* Anzahl Neuronen im "Hidden Layer" */
int   hidden_1;
int   hidden_2;
int   ctr_line;              /* Momentan bearbeitete Zeile der Steuerdatei */
char  buffer[L_SIZE];        /* Puffer zum Einlesen der Textzeilen */
int   run_brain;             /* <> 0 => BrainMaker als ChildProcess aufrufen */
int   display_on;            /* Flag (1 = Anzeige (Thermometer etc.) ein */
int   digitalize_on;	     /* Flag (1 = Zahlen in 1, 0, -1 umcodieren) */
int   max_lines = 25 - 5;    /* Anzahl freier Zeilen im BrainMaker-Screen */

/* F�r <test>-Befehl */
char *test_name;             /* Name der zu erstellenden TEST-Datei */
char *testrun_name;          /* Name der zu erstellenden TESTRUN-Datei */
int   test_percent;          /* Prozentzahl der Testdaten */

/* F�r <extract_first>-Befehl */
char *extract_first_name;    /* Name der Datei, in die der erste zu extrahierende Block kommt */
int   extract_first;         /* Gr��e des Blocks in Zeilen */
char *extract_firstrun_name; /* Name der zugeh�rigen RUN-Datei */
int   extract_firstrun;      /* Anzahl der letzten daraus zu l�schenden Zeilen */

/* F�r <extract_last>-Befehl */
char *extract_last_name;     /* Name der Datei, in die der zweite zu extrahierende Block kommt */
int   extract_last;          /* Gr��e des Blocks in Zeilen */
char *extract_lastrun_name;  /* Name der zugeh�rigen RUN-Datei */
int   extract_lastrun;       /* Anzahl der letzten daraus zu l�schenden Zeilen */

/* F�r <statistics>-Befehl */
char *cmp_test_name;         /* Name der zu vergleichenden Testdatei */
char *cmp_out_name;          /* Name der damit zu vergleichenden Ausgabedatei */
char *stat_name;             /* Name der Ausgabedatei mit der Statistik (NULL = Screen) */
int   test_tolerance;        /* Toleranz beim Vergleich der beiden Dateien */

/* F�r <total>-Befehl */
char *diff_name;             /* Name der RUN-Datei mit den Differenzen */
char *total_name;            /* Name der Ausgabedatei mit den Resultaten */
int   total_startline;       /* Nummer (VON UNTEN !!!) der ersten Zeile in */
			     /* Rohdatendatei, die f�r Prognosen verwendet wird */
/*--------------------------------------------------------------------------

*/
int main(int argc, char *argv[])
{
  /* Aufruf pr�fen, Rohdatendatei einlesen, Steuerbefehle abarbeiten */
  if (argc < 3)
  {
    printf("\nSYNTAX:    BRAIN INFILE OUTFILE [CTRLFILE]");
    exit(1);
  }
  dm_read_file(argv[1]);
  dm_del_zeros();
  dm_ctrfile(argv[3]);

  /* Wenn OUTFILE != NULL, Ausgabedatei erzeugen, eventuell BrainMaker aufrufen */
  if (strcmp(argv[2], "NULL"))
  {
    dm_write_file(argv[2]);
    if (run_brain)
      spawnl(P_WAIT, "brainmak.exe", "brainmak", argv[2], NULL);
  }

  /* Bei entspr.Befehlen Resultat- und Statistikdatei erzeugen */
  if (total_name != NULL)
    dm_total();
  if (cmp_test_name != NULL)
    dm_statistics();
  return(0);
}
/*--------------------------------------------------------------------------

	Fehlermeldungen
	---------------
*/
void dm_outofmem_err()
{
  printf("\nSpeicherkapazit�t unzureichend");
  dm_errline();
}

void dm_read_err(char *file)
{
  printf("\nFehler beim Lesen der Datei %s", file);
  dm_errline();
}

void dm_write_err(char *file)
{
  printf("\nFehler beim Schreiben der Datei %s", file);
  dm_errline();
}

void dm_col_err(char *col)
{
  printf("\nDie Spalte <%s> existiert nicht", col);
  dm_errline();
}

void dm_errline(void)
{
  if (ctr_line)
    printf(" (%d)", ctr_line);
  exit(1);
}
/*--------------------------------------------------------------------------

	DM_READ_FILE()
	--------------
	Funktion: Liest Rohdatendatei ein und baut die Datenstrukturen auf
	Hin	: file_in : Name der Eingabedatei
	Zur�ck	: cols, rows, header, array : erzeugte Datenstrukturen
*/
void dm_read_file(char *file_in)
{
  FILE *fp_in;
  char *s;
  int i;

  if ((fp_in = fopen(file_in, "r")) == NULL)   /* Datendatei �ffnen */
    dm_read_err(file_in);

  /* �berschrift analysieren */
  if (! dm_read_line(fp_in))                   /* �berschriften lesen */
    dm_read_err(file_in);

  cols = 0;                                    /* Spaltenanzahl initial. */
  s = strtok(buffer, " \t\n");                 /* 1.�berschrift suchen */
  while (s)
  {
    if ((array = realloc(array, (cols + 1) * sizeof(DAT_TYPE *))) == NULL)
      dm_outofmem_err();                       /* neuen Spaltenptr. anlegen */
    array[cols] = NULL;                        /* u.mit NULL initialisieren */

    if ((header = realloc(header, (cols + 1) * sizeof(char *))) == NULL)
      dm_outofmem_err();                       /* �berschriftenptr.anlegen */
    if ((header[cols] = malloc(strlen(s) + 1)) == NULL)
      dm_outofmem_err();                       /* Platz f.�berschrift allok.*/
    strcpy(header[cols], s);                   /* �berschrift kopieren */
    s = strtok(NULL, " \t\n");                 /* und n�chste suchen */
    cols++;                                    /* Spaltenanzahl inkrem. */
  }

  /* Datenzeilen analysieren */
  rows = 0;                                    /* Zeilenanzahl initial. */
  while(dm_read_line(fp_in))                   /* Datenzeile lesen */
  {
    i = 0;
    s = strtok(buffer, " \t\n");               /* 1.Datum suchen */
    while (s)
    {
      if ((array[i] = realloc(array[i], (rows + 1) * sizeof(DAT_TYPE))) == NULL)
	dm_outofmem_err();                     /* Spaltenarray erweitern */
      array[i][rows] = atof(s);                /* Wert eintragen */
      s = strtok(NULL, " \t\n");               /* n�chsten Wert suchen */
      i++;                                     /* Spaltenz�hler inkrem. */
    }
    rows++;                                    /* Zeilenz�hler inkrem. */
  }
  if (ferror(fp_in) || fclose(fp_in) == EOF)
    dm_read_err(file_in);
}
/*--------------------------------------------------------------------------

	DM_DEL_ZEROS()
	--------------
	Funktion: Entfernt Nullen durch Mittelwerte
*/
void dm_del_zeros()
{
  int i, j, nr1, nr2;

  for (i = 0; i < cols; i++)
    for (j = 0; j < rows; j++)
      if (array[i][j] == 0)
      {
	nr1 = j;
	while (array[i][nr1] == 0  &&  nr1 > 0)
	  nr1--;

	nr2 = j;
	while (array[i][nr2] == 0  &&  nr2 < rows - 1)
	  nr2++;

	array[i][j] = (array[i][nr1] + array[i][nr2]) / 2;
      }
}
/*--------------------------------------------------------------------------

	DM_READ_LINE()
	---------------
	Funktion: Liest n�chste "echte" Zeile aus Eingabedatei; Leerzeilen
		  und Zeilen, die mit "'" beginnen, werden �berlesen
	Hin	: fp_in : Eingabedatei
	RETURN  : 1 = Alles okay, Zeile ist in <buffer>
		  0 = Dateiende erreicht
*/
int dm_read_line(FILE *fp_in)
{
  while(fgets(buffer, L_SIZE, fp_in))
  {
    ctr_line++;
    if (*buffer != '\n'  &&  *buffer != '\'')
      return(1);
  }
  return(0);
}
/*--------------------------------------------------------------------------

	DM_WRITE_FILE()
	---------------
	Funktion: Erzeugt Ausgabedatei (Rohdatendatei, wenn Klassifizierung
		  erfolgt (wenn <class> != NULL) sonst BrainMaker-Datei
	Hin	: file_out : Name der Ausgabedatei
*/
void dm_write_file(char *file_out)
{
  int *stellen;

  stellen = dm_calc_width();                   /* Ausgabebreiten ermitteln */

  if (class != NULL)                           /* Klassifikation erfolgt? */
    dm_write_brainfile(file_out, stellen);     /* Ja => BrainMaker-Datei */
  else                                         /* erzeugen, sonst normale */
    dm_write_datfile(file_out, stellen);       /* Rohdaten-Datei */
}
/*--------------------------------------------------------------------------

	DM_WRITE_DATFILE()
	------------------
	Funktion: Erzeugt neue Rohdatendatei mit den manipulierten Daten
	Hin	: file_out : Name der Ausgabedatei
		  stellen  : Pointerarray mit den Sollbreiten
*/
void dm_write_datfile(char *file_out, int *stellen)
{
  FILE *fp_out;
  int i, j;

  if ((fp_out = fopen(file_out, "w")) == NULL) /* Datendatei �ffnen */
    dm_write_err(file_out);

  for (i = 0; i < cols; i++)                   /* Alle Spalten ablaufen */
    dm_write_head(fp_out, header[i], stellen[i]);
  fprintf(fp_out, "\n");                       /* Zeilenende: Vorschub */

  /* Zahlenreihen ausgeben */
  for (i = 0; i < rows; i++)
  {                                            /* Alle Spalten jeder */
    for (j = 0; j < cols; j++)                 /* Zeile ablaufen */
      dm_write_number(fp_out, array[j][i], stellen[j]);
    fprintf(fp_out, "\n");                     /* Zeilenende: Vorschub */
  }
}
/*--------------------------------------------------------------------------

	DM_WRITE_BRAINFILE()
	--------------------
	Funktion: Erzeugt BrainMaker-Definitionsfile (inkl.Daten)
	Hin	: file_out : Name der Ausgabedatei
		  stellen  : Pointerarray mit den Sollbreiten
*/
void dm_write_brainfile(char *file_out, int *stellen)
{
  FILE *fp_out, *fp_tst, *fp_tstrun, *fp_tmp;
  int i, j, lines, bas, res, b = 1, r = 1, width = 70;
  DAT_TYPE min, max;
  char *screen;

  /* Definitionsdatei �ffnen */
  if ((fp_out = fopen(file_out, "w")) == NULL) /* Datendatei �ffnen */
    dm_write_err(file_out);

  /* Layer definieren */
  fprintf(fp_out, "input number 1 %d\n", basis);   /* input number */
  fprintf(fp_out, "output number 1 %d\n", result); /* output number */
  if (! hidden_neurons)                            /* Wenn hidden undef.: */
    if ((hidden_neurons = (basis + result) / 2) < 10) /* (Input+Output)/2 */
      hidden_neurons = 10;                         /* nehmen, aber */
                                                   /* mindestens 10 */
  fprintf(fp_out, "hidden %d", hidden_neurons);
  if (hidden_1)
    fprintf(fp_out, " %d", hidden_1);
  if (hidden_2)
    fprintf(fp_out, " %d", hidden_2);
  fprintf(fp_out, "\n");

  /*** Bildschirmanzeige ***/
  if (display_on)
  {
    /* maximal <ScreenLines - 5> Zeilen */
    bas = basis;
    res = result;
    if ((lines = basis) < result)
      lines = result;
    if (lines > max_lines)
    {
      lines = max_lines;
      if (bas > max_lines)
	bas = max_lines;
      if (res > max_lines)
	res = max_lines;
    }

    /* Thermometeranzeige */
    fprintf(fp_out, "\ndisplay input thermo 5 12 %d 10\n", bas);
    fprintf(fp_out, "display output thermo 5 51 %d 10\n", res);
    fprintf(fp_out, "display pattern thermo 5 61 %d 10\n", res);

    /* Bildschirmhintergrund */
    fprintf(fp_out, "\ndisplay screen 4 %d\n", 4 + lines);

    if ((screen = malloc((lines + 1) * width * sizeof(char))) == NULL)
      dm_outofmem_err();
    memset(screen, ' ', (lines + 1) * width);
    sprintf(screen + 51, "Output:   Pattern:");
    for (i = 0; i < cols; i++)
      if (toupper(class[i]) == 'B')
      {
	if (b < lines + 1)
	{
	  sprintf(screen + b * width, "%.10s", header[i]);
	  *(screen + b * width + strlen(screen + b * width)) = ' ';
	  b++;
	}
      }
      else if (toupper(class[i]) == 'R')
      {
	if (r < lines + 1)
	{
	  sprintf(screen + r * width + 40, "%.10s", header[i]);
	  *(screen + r * width + strlen(screen + r * width)) = ' ';
	  r++;
	}
      }
    for (i = 0; i < lines + 1; i++)
    {
      *(screen + i * width + 69) = '\0';
      fprintf(fp_out, "%s\n", screen + i * width);
    }
  }

  /* Header ausgeben */
  fprintf(fp_out, "\n");
  for (i = 0; i < cols; i++)
    if (class[i] == 'B')
      dm_write_head(fp_out, header[i], stellen[i]);
  fprintf(fp_out, "\n");
  for (i = 0; i < cols; i++)
    if (class[i] == 'R')
      dm_write_head(fp_out, header[i], stellen[i]);
  fprintf(fp_out, "\n");

  /* Minima */
  fprintf(fp_out, "\nminimum\n");
  for (i = 0; i < cols; i++)
    if (class[i] == 'B')
    {
      for (j = 0, min = array[i][0]; j < rows; j++)
	if (array[i][j] < min)
	  min = array[i][j];
      dm_write_number(fp_out, min * DISTANCE, stellen[i]);
    }
  fprintf(fp_out, "\n");
  for (i = 0; i < cols; i++)
    if (class[i] == 'R')
    {
      for (j = 0, min = array[i][0]; j < rows; j++)
	if (array[i][j] < min)
	  min = array[i][j];
      dm_write_number(fp_out, min * DISTANCE, stellen[i]);
    }

  /* Maxima */
  fprintf(fp_out, "\n\nmaximum\n");
  for (i = 0; i < cols; i++)
    if (class[i] == 'B')
    {
      for (j = 0, max = array[i][0]; j < rows; j++)
	if (array[i][j] > max)
	  max = array[i][j];
      dm_write_number(fp_out, max * DISTANCE, stellen[i]);
    }
  fprintf(fp_out, "\n");
  for (i = 0; i < cols; i++)
    if (class[i] == 'R')
    {
      for (j = 0, max = array[i][0]; j < rows; j++)
	if (array[i][j] > max)
	  max = array[i][j];
      dm_write_number(fp_out, max * DISTANCE, stellen[i]);
    }

  /*** Zahlenreihen ausgeben ***/

  /* Ersten zu extrahierenden Block in separate Datei schreiben */
  dm_extract(extract_first_name, extract_firstrun_name, extract_firstrun, extract_first, stellen);

  /* Fakten in Definitionsfile (und Testfile) schreiben */
  fprintf(fp_out, "\n\nfacts\n");
  if (test_name != NULL)
  {
    if ((fp_tst = fopen(test_name, "w")) == NULL)
      dm_write_err(test_name);
    fprintf(fp_tst, "facts\n");
  }
  if (testrun_name != NULL)
  {
    if ((fp_tstrun = fopen(testrun_name, "w")) == NULL)
      dm_write_err(testrun_name);
    fprintf(fp_tstrun, "facts\n");
  }

  for (i = extract_first; i < rows - extract_last; i++)
  {
    if (test_percent  &&  ((int) (i + 1) / (100 / test_percent) == (float) (i + 1) / (100 / test_percent)))
      fp_tmp = fp_tst;
    else
      fp_tmp = fp_out;

    for (j = 0; j < cols; j++)                 /* Zeilen spaltenweise abl.*/
      if (class[j] == 'B')                     /* Basis? Ja => ausgeben */
      {
	dm_write_number(fp_tmp, array[j][i], stellen[j]);
	if (fp_tmp == fp_tst)
	  dm_write_number(fp_tstrun, array[j][i], stellen[j]);
      }
    fprintf(fp_tmp, "\n");                     /* Zeilenende: Vorschub */
    if (fp_tmp == fp_tst)
      fprintf(fp_tstrun, "\n");

    for (j = 0; j < cols; j++)
      if (class[j] == 'R')
	dm_write_number(fp_tmp, array[j][i], stellen[j]);
    fprintf(fp_tmp, "\n");
  }

  if (test_name != NULL)
    if (fclose(fp_tst) == EOF)
      dm_write_err(test_name);
  if (testrun_name != NULL)
    if (fclose(fp_tstrun) == EOF)
      dm_write_err(testrun_name);

  /* Zweiten zu extrahierenden Block in separate Datei schreiben */
  dm_extract(extract_last_name, extract_lastrun_name, rows - extract_last, rows - extract_lastrun, stellen);

  /* Definitionsdatei schlie�en */
  if (fclose(fp_out) == EOF)
    dm_write_err(file_out);
}
/*--------------------------------------------------------------------------

	DM_EXTRACT
	----------
	Funktion: Extrahiert ersten/letzten Block aus Definitionsdatei,
		  schreibt ihn in eine separate Datei und - wenn
		  angegeben - den gleichen Block ohne die RESULT-Spalten
		  in eine weitere Datei.
	Hin     : fct     : Name der ersten zu erzeugenden Datei
		  run     : Name der zweiten zu erzeugenden Datei
		  first   : Erste Zeile des zu extrahierenden Blocks
		  last    : Letzte Zeile des zu extrahierenden Blocks
		  stellen : Array mit Ausgabebreiten der Spalten
*/
void dm_extract(char *fct, char *run, int first, int last, int *stellen)
{
  FILE *fp_fct, *fp_run;
  int i, j;

  /* Fakten- (Basis- u.Result-Spalten) und RUN- (nur Results) Datei �ffnen */
  if (fct != NULL)
  {
    if ((fp_fct = fopen(fct, "w")) == NULL)
      dm_write_err(fct);
    fprintf(fp_fct, "facts\n");
  }

  if (run != NULL)
  {
    if ((fp_run = fopen(run, "w")) == NULL)
      dm_write_err(run);
    fprintf(fp_run, "facts\n");
  }

  /* Dateien erzeugen */
  for (i = first; i < last; i++)
  {
    for (j = 0; j < cols; j++)
      if (class[j] == 'B')
      {
	dm_write_number(fp_fct, array[j][i], stellen[j]);
	if (run != NULL)
	  dm_write_number(fp_run, array[j][i], stellen[j]);
      }
    fprintf(fp_fct, "\n");
    if (run != NULL)
      fprintf(fp_run, "\n");

    for (j = 0; j < cols; j++)
      if (class[j] == 'R')
	dm_write_number(fp_fct, array[j][i], stellen[j]);
    fprintf(fp_fct, "\n");
  }

  /* Dateien schliessen */
  if (fct != NULL)
    if (fclose(fp_fct) == EOF)
      dm_write_err(fct);
  if (run != NULL)
    if (fclose(fp_run) == EOF)
      dm_write_err(run);
}
/*--------------------------------------------------------------------------

	DM_CALC_WIDTH
	-------------
	Funktion: Ermittelt Sollbreite jeder Spalte (=Breite der breitesten
		  Zahl in der betreffenden Spalte)
	RETURN  : Zeiger auf angelegtes Array mit den Sollbreiten
*/
int *dm_calc_width(void)
{
  int i, j, max, *width;
  char s[MAX_BREITE];

  if ((width = malloc(cols * sizeof(int))) == NULL)
    dm_outofmem_err();                         /* int-Array f�r die zu er- */
					       /* mittelnden Maximalbreiten */
  for (i = 0; i < cols; i++)
    for (j = 0, width[i] = 0; j < rows; j++)   /* Spaltenelemente ablaufen */
    {                                          /* jedes Element "printen" */
      sprintf(s, "%.2f", array[i][j]);         /* Resultat breiter als */
      if ((max = strlen(s)) > width[i])        /* bisher gr��te Breite der */
        width[i] = max;                        /* betreffenden Spalte? */
    }                                          /* Ja => als neue Maximal- */
  return(width);                               /* breite merken */
}
/*--------------------------------------------------------------------------

	DM_WRITE_HEAD
	-------------
	Funktion: Schreibt formatierte Spalten�berschrift in Ausgabedatei
	Hin	: fp_out  : Ausgabedatei
		  head    : �berschrift
		  breite  : Sollbreite
*/
void dm_write_head(FILE *fp_out, char *head, int breite)
{
  int i, diff;

  if ((diff = breite - strlen(head)) < 0)      /* Differenz zwischen */
  {                                            /* Soll- und Istbreite */
    head[breite] = '\0';                       /* Zu breit? */
    fprintf(fp_out, "%s ", head);              /* Ja => String abschneiden */
  }                                            /* und ausgeben */
  else
  {
    fprintf(fp_out, "%s ", head);              /* Nein => String ausgeben */
    for (i = 0; i < diff; i++)                 /* und fehlende Anzahl */
      fprintf(fp_out, " ");                    /* Leerzeichen ausgeben */
  }
}
/*--------------------------------------------------------------------------

	DM_WRITE_NUMBER
	---------------
	Funktion: Schreibt formatierten Wert in Ausgabedatei
	Hin	: fp_out : Ausgabedatei
		  number : Wert
		  breite : Sollbreite
*/
void dm_write_number(FILE *fp_out, DAT_TYPE number, int breite)
{
  int i, diff;
  char s[MAX_BREITE];

  if (digitalize_on == 1)
  {
    if (number > 0) number =  1;
    if (number < 0) number = -1;
  }

  sprintf(s, "%.2f", number);                  /* Zahl in Buffer "printen" */
  if (diff = breite - strlen(s))               /* Schmaler als Sollbreite? */
    for (i = 0; i < diff; i++)                 /* Ja => entsprechend viele */
      fprintf(fp_out, " ");                    /* Leerzeichen ausgeben */
  fprintf(fp_out, "%.2f ", number);            /* Zahl ausgeben */
}
/*--------------------------------------------------------------------------

	DM_CREATE_COL()
	---------------
	Funktion: Erzeugt neue Spalte und Spalten�berschrift
	Hin	: *col_neu : Name der neuen Spalte
*/
void dm_create_col(char *col_neu)
{                                              /* Neuen Ptr. auf die */
  if ((header = realloc(header, (cols + 1) * sizeof(char *))) == NULL)
    dm_outofmem_err();                         /* Spaltennamen anlegen */
  if ((header[cols] = malloc(strlen(col_neu) + 1)) == NULL)
    dm_outofmem_err();                         /* Platz f�r Name allok. */
  strcpy(header[cols], col_neu);               /* Name dorthin kopieren */

  if ((array = realloc(array, (cols + 1) * sizeof(DAT_TYPE *))) == NULL)
    dm_outofmem_err();
  if ((array[cols] = malloc(rows * sizeof(DAT_TYPE))) == NULL)
    dm_outofmem_err();

  cols++;                                      /* Nun eine Spalte mehr */
}
/*--------------------------------------------------------------------------

	DM_DELETE_COL()
	---------------
	Funktion: L�scht bestehende Spalte und Spalten�berschrift
	Hin	: *col_del : Name der zu l�schenden Spalte
*/
void dm_delete_col(char *col_del)
{
  int nr, i;

  if ((nr = dm_search_col(col_del)) == -1)     /* Index der Spalte */
    dm_col_err(col_del);                       /* ermitteln */

  free(header[nr]);                            /* Platz f�r zu l�schende */
  free(array[nr]);                             /* �berschrift und Spalte */
					       /* freigeben. */
  for (i = nr; i < cols - 1; i++)              /* Pointer auf Spalten- */
  {                                            /* namen und Spalten */
    header[i] = header[i + 1];                 /* umsetzen */
    array[i] = array[i + 1];
  }

  if ((header = realloc(header, (cols - 1) * sizeof(char *))) == NULL)
    dm_outofmem_err();                         /* Header- und Spaltenarray */
  if ((array = realloc(array, (cols - 1) * sizeof(DAT_TYPE *))) == NULL)
    dm_outofmem_err();                         /* um je 1 Ptr.verkleinern */

  cols--;                                      /* Nun eine Spalte weniger */
}
/*--------------------------------------------------------------------------

	DM_SEARCH_COL()
	---------------
	Funktion: Ermittelt die Nummer einer bestimmten Spalte (ab 0)
	Hin	: *col : Name der Spalte
	RETURN	: Spaltennummer, -1 = Spaltenname existiert nicht
*/
int dm_search_col(char *col)
{
  int i;

  for (i = 0; i < cols; i++)
    if (! strcmp(header[i], col))
      return(i);
  return(-1);
}
/*--------------------------------------------------------------------------

	DM_INIT_CALC()
	--------------
	Funktion: Ermittelt die Indizes zweier Spalten und legt eine neue an
	Hin	: col1    : Name der 1.Spalte
		  col2    : Name der 2.Spalte
		  col_neu : Name der neuen Spalte
	Zur�ck  : nr1     : Index der 1.Spalte
		  nr2     : Index der 2.Spalte
*/
void dm_init_calc(char *col1, char *col2, char *col_neu, int *nr1, int *nr2)
{
  if ((*nr1 = dm_search_col(col1)) == -1)      /* Index der 1.Spalte */
    dm_col_err(col1);                          /* ermitteln */
  if ((*nr2 = dm_search_col(col2)) == -1)      /* Index der 2.Spalte */
    dm_col_err(col2);                          /* ermitteln */
  dm_create_col(col_neu);                      /* neue Spalte anlegen */
}
/*--------------------------------------------------------------------------

	DM_INIT_CALC1()
	---------------
	Funktion: Ermittelt den Index einer Spalte und legt eine neue an,
		  wenn der Name der neuen Spalte nicht mit dem der alten
		  Spalte identisch ist. Gibt Index der neuen Spalte zur�ck,
		  bzw. - falls keine angelegt wurde - Index der alten Spalte.
	Hin	: col     : Name der Spalte
		  col_neu : Name der neuen Spalte
	Zur�ck  : nr_alt  : Index der Spalte
		  nr_neu  : Index der neuen Spalte (ist bei identischen
			    Namen gleich dem Index der alten Spalte)
*/
void dm_init_calc1(char *col, char *col_neu, int *nr_alt, int *nr_neu)
{
  if ((*nr_alt = dm_search_col(col)) == - 1)   /* Index der Spalte */
    dm_col_err(col);                           /* ermitteln */
  if (strcmp(col, col_neu))                    /* Namen identisch? */
  {
    dm_create_col(col_neu);                    /* Nein => neue Spalte */
    *nr_neu = cols - 1;                        /* anlegen */
  }
  else
    *nr_neu = *nr_alt;
}
/*--------------------------------------------------------------------------

	DM_ADD_CONST()
	--------------
	Funktion: Addiert Konstante zu allen Werten einer Spalte und erzeugt
		  eine neue Spalte, wenn der Name der neuen Spalte nicht
		  mit dem der alten Spalte identisch ist.
	Hin	: col     : Name der Spalte
		  number  : Konstante
		  col_neu : Name der zus�tzlichen Summenspalte
*/
void dm_add_const(char *col, float number, char *col_neu)
{
  int i, nr_alt, nr_neu;

  dm_init_calc1(col, col_neu, &nr_alt, &nr_neu);
  for (i = 0; i < rows; i++)
    array[nr_neu][i] = array[nr_alt][i] + number;
}
/*--------------------------------------------------------------------------

	DM_SUB_CONST()
	--------------
	Funktion: Subtrahiert Konstante von allen Werten einer Spalte und
		  erzeugt eine neue Spalte, wenn der Name der neuen Spalte
		  nicht mit dem der alten Spalte identisch ist.
	Hin	: col     : Name der Spalte
		  number  : Konstante
		  col_neu : Name der zus�tzlichen Summenspalte
*/
void dm_sub_const(char *col, float number, char *col_neu)
{
  int i, nr_alt, nr_neu;

  dm_init_calc1(col, col_neu, &nr_alt, &nr_neu);
  for (i = 0; i < rows; i++)
    array[nr_neu][i] = array[nr_alt][i] - number;
}
/*--------------------------------------------------------------------------

	DM_MUL_CONST()
	--------------
	Funktion: Multipliziert alle Werte einer Spalte mit einer Konstanten
		  und erzeugt eine neue Spalte, wenn der Name der neuen
		  Spalte nicht mit dem der alten Spalte identisch ist.
	Hin	: col     : Name der Spalte
		  number  : Konstante
		  col_neu : Name der zus�tzlichen Summenspalte
*/
void dm_mul_const(char *col, float number, char *col_neu)
{
  int i, nr_alt, nr_neu;

  dm_init_calc1(col, col_neu, &nr_alt, &nr_neu);
  for (i = 0; i < rows; i++)
    array[nr_neu][i] = array[nr_alt][i] * number;
}
/*--------------------------------------------------------------------------

	DM_DIV_CONST()
	--------------
	Funktion: Dividiert alle Werte einer Spalte durch eine Konstante
		  und erzeugt eine neue Spalte, wenn der Name der neuen
		  Spalte nicht mit dem der alten Spalte identisch ist.
	Hin	: col     : Name der Spalte
		  number  : Konstante
		  col_neu : Name der zus�tzlichen Summenspalte
*/
void dm_div_const(char *col, float number, char *col_neu)
{
  int i, nr_alt, nr_neu;

  dm_init_calc1(col, col_neu, &nr_alt, &nr_neu);
  for (i = 0; i < rows; i++)
    array[nr_neu][i] = array[nr_alt][i] / number;
}
/*--------------------------------------------------------------------------

	DM_ADD_COL()
	------------
	Funktion: Addiert zwei Spalten und erzeugt eine neue Summenspalte
	Hin	: col1    : Name der 1.Spalte
		  col2    : Name der 2.Spalte
		  col_neu : Name der zus�tzlichen Summenspalte
*/
void dm_add_col(char *col1, char *col2, char *col_neu)
{
  int i, nr1, nr2;

  dm_init_calc(col1, col2, col_neu, &nr1, &nr2);
  for (i = 0; i < rows; i++)
    array[cols - 1][i] = array[nr1][i] + array[nr2][i];
}
/*--------------------------------------------------------------------------

	DM_SUB_COL()
	------------
	Funktion: Subtrahiert zwei Spalten und erzeugt neue Differenzspalte
	Hin	: col1    : Name der 1.Spalte
		  col2    : Name der 2.Spalte
		  col_neu : Name der zus�tzlichen Differenzspalte
*/
void dm_sub_col(char *col1, char *col2, char *col_neu)
{
  int i, nr1, nr2;

  dm_init_calc(col1, col2, col_neu, &nr1, &nr2);
  for (i = 0; i < rows; i++)
    array[cols - 1][i] = array[nr1][i] - array[nr2][i];
}
/*--------------------------------------------------------------------------

	DM_MUL_COL()
	------------
	Funktion: Multipliziert zwei Spalten und erzeugt neue Resultatspalte
	Hin	: col1    : Name der 1.Spalte
		  col2    : Name der 2.Spalte
		  col_neu : Name der zus�tzlichen Resultatspalte
*/
void dm_mul_col(char *col1, char *col2, char *col_neu)
{
  int i, nr1, nr2;

  dm_init_calc(col1, col2, col_neu, &nr1, &nr2);
  for (i = 0; i < rows; i++)
    array[cols - 1][i] = array[nr1][i] * array[nr2][i];
}
/*--------------------------------------------------------------------------

	DM_DIV_COL()
	------------
	Funktion: Dividiert zwei Spalten und erzeugt eine neue Resultatspalte
	Hin	: col1    : Name der 1.Spalte
		  col2    : Name der 2.Spalte
		  col_neu : Name der zus�tzlichen Resultatspalte
*/
void dm_div_col(char *col1, char *col2, char *col_neu)
{
  int i, nr1, nr2;

  dm_init_calc(col1, col2, col_neu, &nr1, &nr2);
  for (i = 0; i < rows; i++)
    array[cols - 1][i] = array[nr1][i] / array[nr2][i];
}
/*--------------------------------------------------------------------------

	DM_SHIFT_DOWN_COL()
	-------------------
	Funktion: Kopiert alle Werte einer Spalte um beliebig viele Zeilen
		  nach unten verschoben in eine neue Spalte. In die obersten
		  Zeilen der neuen Spalte kommt der erste Wert der alten
		  Spalte, so da� dieser anschlie�end mehrfach vorhanden ist.
	Hin	: col     : Name der Spalte
		  shift   : Verschiebungsfaktor in Zeilen (1 bis cols - 1)
		  col_neu : Name der neuen Spalte
*/
void dm_shift_down_col(char *col, int shift, char *col_neu)
{
  int i, nr_alt, nr_neu;

  dm_init_calc1(col, col_neu, &nr_alt, &nr_neu);
  for (i = shift - 1; i >= 0; i--)
    array[nr_neu][i] = array[nr_alt][0];
  for (i = rows - 1; i >= shift; i--)
    array[nr_neu][i] = array[nr_alt][i - shift];
}
/*--------------------------------------------------------------------------

	DM_SHIFT_UP_COL()
	-----------------
	Funktion: Kopiert alle Werte einer Spalte um beliebig viele Zeilen
		  nach oben verschoben in eine neue Spalte. In die untersten
		  Zeilen der neuen Spalte kommt der letzte Wert der alten
		  Spalte, so da� dieser anschlie�end mehrfach vorhanden ist.
	Hin	: col     : Name der Spalte
		  shift   : Verschiebungsfaktor in Zeilen (1 bis cols - 1)
		  col_neu : Name der neuen Spalte
*/
void dm_shift_up_col(char *col, int shift, char *col_neu)
{
  int i, nr_alt, nr_neu;

  dm_init_calc1(col, col_neu, &nr_alt, &nr_neu);
  for (i = 0; i < rows - shift; i++)
    array[nr_neu][i] = array[nr_alt][i + shift];
  for (i = rows - shift; i < rows; i++)
    array[nr_neu][i] = array[nr_alt][rows - 1];
}
/*--------------------------------------------------------------------------

	DM_DIFF_COL()
	-------------
	Funktion: Erzeugt Differenzspalte, indem die angegebene Spalte um
		  die angegebene Zeilenzahl nach unten (Zahl positiv) bzw.
		  nach oben (Zahl negativ) verschoben wird, in eine neue
		  Spalte mit dem Namen <DIFF_COL>. Anschlie�end wird die alte
		  Spalte von <DIFF_COL> subtrahiert (wenn nach unten ver-
		  schoben wurde) bzw. umgekehrt die <DIFF_COL> von der alten
		  Spalte subtrahiert, wenn nach oben verschoben wurde.
		  Zuletzt wird die nur tempor�r ben�tigte Spalte <DIFF_COL>
		  wieder gel�scht.
	Hin	: col     : Name der Spalte
		  shift   : Verschiebungsfaktor (positiv = nach unten
						 negativ = nach oben)
		  col_neu : Name der neuen Spalte
*/
void dm_diff_col(char *col, int shift, char *col_neu)
{
  if (shift >= 0)
  {
    dm_shift_down_col(col, shift, "DIFF_COL");
    dm_sub_col(col, "DIFF_COL", col_neu);
  }
  else
  {
    dm_shift_up_col(col, abs(shift), "DIFF_COL");
    dm_sub_col("DIFF_COL", col, col_neu);
  }
  dm_delete_col("DIFF_COL");
}
/*--------------------------------------------------------------------------

	DM_CLASS_COL()
	--------------
	Funktion: �bernimmt �bergebenen String mit der Klassifizierung der
		  Spalten zur Erstellung einer BrainMaker-Datei. Nicht
		  klassifizierte Spalten sind standardm��ig BASIS-Spalten.
	Hin	: col : Name der Spalte
		  typ : Klassifizierungszeichen; 'R' = Resultspalte,
			'N' = zu ignorierende Spalte, die nicht in die
			Definitionsdatei geschrieben wird, 'O' = Original-
			Spalte, die der <total>-Befehl weiterverwendet.
*/
void dm_class_col(char *col, char *typ)
{
  int nr;

  if (class == NULL)
  {
    if ((class = calloc(cols + 1, sizeof(char))) == NULL)
      dm_outofmem_err();
    memset(class, 'B', cols);                  /* String <class> anlegen, */
    basis = cols;                              /* wenn nicht vorhanden, */
  }                                            /* und mit 'B' initialis. */

  if ((nr = dm_search_col(col)) == - 1)        /* Kennzeichen an entspre- */
    dm_col_err(col);                           /* chender Posit.speichern */
  class[nr] = *typ;                            /* Anzahl Basisspalten de- */
  basis--;                                     /* krementieren und - wenn */
  if (*typ == 'R')                             /* 'R' - Anzahl Resultspalten */
    result++;                                  /* inkrementieren */
}
/*--------------------------------------------------------------------------

	DM_CTRFILE()
	------------
	Funktion: Liest Steuerungsdatei ein und setzt die darin enthaltenen
		  Befehle in Funktionsaufrufe um.
	Hin	: file_in : Name der Steuerungsdatei
*/
void dm_ctrfile(char *file_ctr)
{
  FILE *fp_in;
  char *par[6];
  int i;

  if ((fp_in = fopen(file_ctr, "r")) == NULL)  /* Steuerdatei �ffnen */
    dm_read_err(file_ctr);

  ctr_line = 0;
  while (dm_read_line(fp_in))                  /* Alle Zeilen behandeln */
  {
    par[0] = strtok(buffer, " \"\t\n(),");     /* Befehlsname  holen */
    if (par[0]  &&  *par[0] != '\'')           /* Leerzeile oder Kommentar? */
    {
      i = 1;
      while (par[i] = strtok(NULL, " \"\t\n(),")) /* Nein => restliche */
	i++;                                   /* Parameter holen */

      if (! strcmp(par[0], "add_const"))
	dm_add_const(par[1], atof(par[2]), par[3]);
      if (! strcmp(par[0], "sub_const"))
	dm_sub_const(par[1], atof(par[2]), par[3]);
      if (! strcmp(par[0], "mul_const"))
	dm_mul_const(par[1], atof(par[2]), par[3]);
      if (! strcmp(par[0], "div_const"))
	dm_div_const(par[1], atof(par[2]), par[3]);
      if (! strcmp(par[0], "add_col"))
	dm_add_col(par[1], par[2], par[3]);
      if (! strcmp(par[0], "sub_col"))
	dm_sub_col(par[1], par[2], par[3]);
      if (! strcmp(par[0], "mul_col"))
	dm_mul_col(par[1], par[2], par[3]);
      if (! strcmp(par[0], "div_col"))
	dm_div_col(par[1], par[2], par[3]);
      if (! strcmp(par[0], "shift_down"))
	dm_shift_down_col(par[1], atoi(par[2]), par[3]);
      if (! strcmp(par[0], "shift_up"))
	dm_shift_up_col(par[1], atoi(par[2]), par[3]);
      if (! strcmp(par[0], "diff_col"))
	dm_diff_col(par[1], atoi(par[2]), par[3]);
      if (! strcmp(par[0], "del"))
	dm_delete_col(par[1]);
      if (! strcmp(par[0], "class"))
	dm_class_col(par[1], par[2]);
      if (! strcmp(par[0], "display"))
	display_on = 1;
      if (! strcmp(par[0], "digitalize"))
	digitalize_on = 1;
      if (! strcmp(par[0], "hidden"))
      {
	hidden_neurons = atoi(par[1]);
	if (strcmp (par[2], "NULL"))
	  hidden_1 = atoi(par[2]);
	if (strcmp (par[3], "NULL"))
	  hidden_2 = atoi(par[3]);
      }
      if (! strcmp(par[0], "run_brain"))
	run_brain = 1;
      if (! strcmp(par[0], "lines"))
	max_lines = atoi(par[1]) - 5;
      if (! strcmp(par[0], "test"))
      {
	if ((test_name = malloc(strlen(par[1]) +  1)) == NULL)
	  dm_outofmem_err();
	strcpy(test_name, par[1]);
	test_percent = atoi(par[2]);
	if (strcmp(par[3], "NULL"))
	{
	  if ((testrun_name = malloc(strlen(par[3]) +  1)) == NULL)
	    dm_outofmem_err();
	  strcpy(testrun_name, par[3]);
	}
      }
      if (! strcmp(par[0], "extract_first"))
      {
	if ((extract_first_name = malloc(strlen(par[1]) +  1)) == NULL)
	  dm_outofmem_err();
	strcpy(extract_first_name, par[1]);
	extract_first = atoi(par[2]);
	if (strcmp(par[3], "NULL"))
	{
	  if ((extract_firstrun_name = malloc(strlen(par[3]) +  1)) == NULL)
	    dm_outofmem_err();
	  strcpy(extract_firstrun_name, par[3]);
	  extract_firstrun = atoi(par[4]);
	}
      }
      if (! strcmp(par[0], "extract_last"))
      {
	if ((extract_last_name = malloc(strlen(par[1]) +  1)) == NULL)
	  dm_outofmem_err();
	strcpy(extract_last_name, par[1]);
	extract_last = atoi(par[2]);
	if (strcmp(par[3], "NULL"))
	{
	  if ((extract_lastrun_name = malloc(strlen(par[3]) +  1)) == NULL)
	    dm_outofmem_err();
	  strcpy(extract_lastrun_name, par[3]);
	  extract_lastrun = atoi(par[4]);
	}
      }
      if (! strcmp(par[0], "statistics"))
      {
	if ((cmp_test_name = malloc(strlen(par[1]) +  1)) == NULL)
	  dm_outofmem_err();
	strcpy(cmp_test_name, par[1]);
	if ((cmp_out_name = malloc(strlen(par[2]) +  1)) == NULL)
	  dm_outofmem_err();
	strcpy(cmp_out_name, par[2]);
	test_tolerance = atof(par[3]);
	if (strcmp(par[4], "NULL"))
	{
	  if ((stat_name = malloc(strlen(par[4]) +  1)) == NULL)
	    dm_outofmem_err();
	  strcpy(stat_name, par[4]);
	}
      }
      if (! strcmp(par[0], "total"))
      {
	if ((diff_name = malloc(strlen(par[1]) +  1)) == NULL)
	  dm_outofmem_err();
	strcpy(diff_name, par[1]);
	if ((total_name = malloc(strlen(par[2]) +  1)) == NULL)
	  dm_outofmem_err();
	strcpy(total_name, par[2]);
	total_startline = atoi(par[3]);
      }
    }
  }
  if (ferror(fp_in) || fclose(fp_in) == EOF)
    dm_read_err(file_ctr);
}
/*--------------------------------------------------------------------------

	DM_STATISTICS()
	---------------
	Funktion: Statistische Auswertung; Vergleich der Prognosen in einer
		  BrainMaker-Ausgabedatei mit einer Datei, die die tats�ch-
		  lichen Werte enth�lt.
*/
void dm_statistics()
{
  FILE *fp_tst, *fp_out, *fp_outnew, *fp_stat;
  float **tst = NULL, **out = NULL;
  char *s, ch, chlast;
  int i, j, rescol, resrow, okay, prozsumokay = 0, richsumokay = 0, extremes = 0, local_extremes;
  DAT_TYPE percent, sum_percent, sum_percent_extremes = 0, global_sum_percent = 0, average_percent = 0;

  /* Von BrainMaker "ab und zu" eingef�gte Linefeeds in Ausgabedatei entfernen */
  fp_out    = fopen(cmp_out_name, "rb");
  fp_outnew = fopen("temp", "wb");

  while (! feof(fp_out))
  {
    ch = fgetc(fp_out);
    if (ch != 10  ||  chlast == 13)
      fputc(ch, fp_outnew);
    chlast = ch;
  }
  fseek(fp_outnew, -1L, SEEK_CUR);
  fputc(26, fp_outnew);

  fclose(fp_out);
  fclose(fp_outnew);
  remove(cmp_out_name);
  rename("temp", cmp_out_name);

  /* Test, Ausgabe- und Statistikdatei �ffnen */
  if ((fp_tst = fopen(cmp_test_name, "r")) == NULL) /* Testdatei �ffnen */
    dm_read_err(cmp_test_name);
  if ((fp_out = fopen(cmp_out_name, "r")) == NULL)  /* Ausgabedatei �ffnen */
    dm_read_err(cmp_out_name);
  if (stat_name != NULL)
  {	                                       /* Statistik-Datei �ffnen, */
    if ((fp_stat = fopen(stat_name, "w")) == NULL)  /* wenn Name != NULL  */
      dm_write_err(stat_name);
  }
  else                                         /* sonst Ausgabe auf Screen*/
    fp_stat = stdout;

  /*** RESULT-Werte beider Dateien in Arrays einlesen ***/
  if (! dm_read_line(fp_tst))                  /* Zeile "facts" �berlesen */
    dm_read_err(cmp_test_name);

  resrow = 0;
  while(dm_read_line(fp_tst))                  /* BASIS-Zeile �berlesen */
  {
    /* RESULT-Zeile aus Testdatei lesen */
    if (! dm_read_line(fp_tst)  &&  ferror(fp_tst))
      dm_read_err(cmp_out_name);               /* RESULT-Zeile lesen */

    rescol = 0;
    s = strtok(buffer, " \t\n");               /* 1.Datum suchen */
    while (s)
    {
      if (! resrow)
      {
	if ((tst = realloc(tst, (rescol + 1) * sizeof(DAT_TYPE *))) == NULL)
	  dm_outofmem_err();                   /* neuen Spaltenptr. anlegen */
	tst[rescol] = NULL;                    /* u.mit NULL initialisieren */
      }
      if ((tst[rescol] = realloc(tst[rescol], (resrow + 1) * sizeof(DAT_TYPE))) == NULL)
	dm_outofmem_err();                     /* Spaltenarray erweitern */
      tst[rescol][resrow] = atof(s);           /* Wert eintragen */
      s = strtok(NULL, " \t\n");               /* n�chsten Wert suchen */
      rescol++;                                /* Spaltenz�hler inkrem. */
    }

    /* RESULT-Zeile aus RUN-Datei lesen */
    if (! dm_read_line(fp_out)  &&  ferror(fp_out))
      dm_read_err(cmp_out_name);               /* BASIS-Zeile �berlesen */
    if (! dm_read_line(fp_out)  &&  ferror(fp_out))
      dm_read_err(cmp_out_name);               /* RESULT-Zeile lesen */

    rescol = 0;
    s = strtok(buffer, " \t\n");
    while (s)
    {
      if (! resrow)
      {
	if ((out = realloc(out, (rescol + 1) * sizeof(DAT_TYPE *))) == NULL)
	  dm_outofmem_err();                   /* neuen Spaltenptr. anlegen */
	out[rescol] = NULL;                    /* u.mit NULL initialisieren */
      }
      if ((out[rescol] = realloc(out[rescol], (resrow + 1) * sizeof(DAT_TYPE))) == NULL)
	dm_outofmem_err();
      out[rescol][resrow] = atof(s);
      s = strtok(NULL, " \t\n");
      rescol++;
    }
    if (! dm_read_line(fp_out)  &&  ferror(fp_out))
      dm_read_err(cmp_out_name);               /* Trennzeile �berlesen */

    resrow++;                                  /* Zeilenz�hler inkrem. */
  }

  /* Statistik der RESULT-Werte erstellen */
  fprintf(fp_stat, "\nProzentuale Abweichungen in den einzelnen Spalten\n");
  for (i = 0; i < rescol; i++)
  {
    for (j = 0, sum_percent = 0, local_extremes = 0; j < resrow; j++)
    {
      if (! tst[i][j])
        tst[i][j] = 0.000001;
      percent =  100 * fabs(tst[i][j] - out[i][j]) / fabs(tst[i][j]);
      fprintf(fp_stat, "%.2f\t", percent);
      if (percent < 1000)
      {
	sum_percent += percent;
        sum_percent_extremes += percent;
	global_sum_percent += percent;
      }
      else
      {
	extremes++;
	local_extremes++;
      }
    }
    fprintf(fp_stat, "\nDurchschnittliche (ohne Extremwerte > 1000) prozentuale Abweichung in Spalte %d: %.2f\n", i + 1, sum_percent / (resrow - local_extremes));     /*sum_percent / resrow);*/
    average_percent += sum_percent_extremes / resrow;
  }

  fprintf(fp_stat, "\nGem�� Testtoleranz korrekte Resultatwerte in den einzelnen Zeilen\n");
  for (i = 0; i < resrow; i++)
  {
    for (j = 0, okay = 0; j < rescol; j++)
    {
      if (fabs(tst[j][i] - out[j][i]) <= fabs(tst[j][i] * test_tolerance / 100))
	okay++;
    }
    fprintf(fp_stat, "Z%.2d:%.2d   ", i + 1, okay);
  }
  fprintf(fp_stat, "\nGem�� Testtoleranz korrekte Resultatwerte in den einzelnen Spalten\n");
  for (i = 0; i < rescol; i++)
  {
    for (j = 0, okay = 0; j < resrow; j++)
      if (fabs(tst[i][j] - out[i][j]) <= fabs(tst[i][j] * test_tolerance / 100))
      {
	okay++;
	prozsumokay++;
      }
    fprintf(fp_stat, "S%.2d:%.2d   ", i + 1, okay);
  }

  fprintf(fp_stat, "\n\nVon Richtung her korrekte Resultatwerte in den einzelnen Zeilen\n");
  for (i = 0; i < resrow; i++)
  {
    for (j = 0, okay = 0; j < rescol; j++)
    {
      if ((tst[j][i] >= 0  &&  out[j][i] >= 0)  ||  (tst[j][i] < 0  &&  out[j][i] < 0))
	okay++;
    }
    fprintf(fp_stat, "Z%.2d:%.2d   ", i + 1, okay);
  }
  fprintf(fp_stat, "\nVon Richtung her korrekte Resultatwerte in den einzelnen Spalten\n");
  for (i = 0; i < rescol; i++)
  {
    for (j = 0, okay = 0; j < resrow; j++)
      if ((tst[i][j] >= 0  &&  out[i][j] >= 0)  ||  (tst[i][j] < 0  &&  out[i][j] < 0))
      {
	okay++;
	richsumokay++;
      }
    fprintf(fp_stat, "S%.2d:%.2d   ", i + 1, okay);
  }

  fprintf(fp_stat, "\n\nGesamtzahl aller Resultatwerte                        : %d", rescol * resrow);
  fprintf(fp_stat, "\nDurchschn.prozent.Abweichung ohne Extremwerte >1000   : %.2f", global_sum_percent / (rescol * resrow - extremes));     /*average_percent / (rescol - extremes));*/
  fprintf(fp_stat, "\nAnzahl gem�� Testtoleranz korrekter Aussagen          : %d", prozsumokay);
  fprintf(fp_stat, "\nProzentsatz gem�� Testtoleranz korrekter Aussagen     : %.2f", 100.0 / (rescol * resrow) * prozsumokay);
  fprintf(fp_stat, "\nAnzahl von Richtung her korrekter Aussagen            : %d", richsumokay);
  fprintf(fp_stat, "\nProzentsatz von Richtung her korrekter Aussagen       : %.2f", 100.0 / (rescol * resrow) * richsumokay);

  /* Test-, Ausgabe- und Statistikdatei schliessen */
  if (ferror(fp_tst)  ||  fclose(fp_tst) == EOF)
    dm_read_err(cmp_test_name);
  if (ferror(fp_out)  ||  fclose(fp_out) == EOF)
    dm_read_err(cmp_out_name);
  if (stat_name != NULL)
    if (ferror(fp_stat)  ||  fclose(fp_stat) == EOF)
      dm_write_err(stat_name);
}
/*--------------------------------------------------------------------------

	DM_TOTAL()
	----------
	Funktion: Addiert prognostizierte Differenzen in BrainMaker-Ausgabe-
		  datei und zugeh�rige Werte in der Rohdatendatei; schreibt
		  Resultate in neue Datei.
*/
void dm_total()
{
  FILE *fp_res, *fp_out, *fp_outnew;
  int i, j, k, rescol, resrow, resnr;
  char *s, ch, chlast = '\0';
  float **out = NULL;
  int *stellen;

  stellen = dm_calc_width();

  /* Von BrainMaker "ab und zu" eingef�gte Linefeeds in Ausgabedatei entfernen */
  fp_out    = fopen(diff_name, "rb");
  fp_outnew = fopen("temp", "wb");

  while (! feof(fp_out))
  {
    ch = fgetc(fp_out);
    if (ch != 10  ||  chlast == 13)
      fputc(ch, fp_outnew);
    chlast = ch;
  }
  fseek(fp_outnew, -1L, SEEK_CUR);
  fputc(26, fp_outnew);

  fclose(fp_out);
  fclose(fp_outnew);
  remove(diff_name);
  rename("temp", diff_name);

  /* Ausgabe- und Resultatdatei �ffnen */
  if ((fp_out = fopen(diff_name, "r")) == NULL)/* Ausgabedatei �ffnen */
    dm_read_err(diff_name);
  if ((fp_res = fopen(total_name, "w")) == NULL)/* Resultatdatei �ffnen */
    dm_write_err(total_name);

  /* RESULT-Werte in Array einlesen */
  resrow = 0;
  while(dm_read_line(fp_out))                  /* BASIS-Zeile �berlesen */
  {
    if (! dm_read_line(fp_out)  &&  ferror(fp_out))
      dm_read_err(diff_name);                  /* RESULT-Zeile lesen */

    rescol = 0;
    s = strtok(buffer, " \t\n");
    while (s)
    {
      if (! resrow)
      {
	if ((out = realloc(out, (rescol + 1) * sizeof(DAT_TYPE *))) == NULL)
	  dm_outofmem_err();                   /* neuen Spaltenptr. anlegen */
	out[rescol] = NULL;                    /* u.mit NULL initialisieren */
      }
      if ((out[rescol] = realloc(out[rescol], (resrow + 1) * sizeof(DAT_TYPE))) == NULL)
	dm_outofmem_err();
      out[rescol][resrow] = atof(s);
      s = strtok(NULL, " \t\n");
      rescol++;
    }
    if (! dm_read_line(fp_out)  &&  ferror(fp_out))
      dm_read_err(diff_name);                  /* Trennzeile �berlesen */

    resrow++;                                  /* Zeilenz�hler inkrem. */
  }

  /* Zugeh�rige Werte aus Rohdatendatei zu den Differenzen addieren */
  for (i = 0; i < rescol; i++)                 /* Resultspalten der Reihe */
  {                                            /* nach behandeln */
    for (j = 0, resnr = -1; resnr != i  &&  j < strlen(class); j++)
      if (class[j] == 'O')                     /* Index <j> der aktuellen */
	resnr++;                               /* Spalte im Rohdatenarray erm.*/

    for (k = 0; k < resrow; k++)               /* Wert zu Differenz addieren */
      out[i][k] = out[i][k] + array[j - 1][rows - total_startline + k];

    dm_write_head(fp_res, header[j - 1], 2 * stellen[j - 1] + 7); /* Spalten�berschrift */
  }                                            /* in Resultatdatei schreiben */
  fprintf(fp_res, "\n");

  /* Resultate in Datei schreiben */
  for (i = 0; i < resrow; i++)
  {
    for (j = 0; j < rescol; j++)
    {
      for (k = 0, resnr = -1; resnr != j  && k < strlen(class); k++)
	if (class[k] == 'O')                     /* Index <j> der aktuellen */
	  resnr++;                               /* Spalte im Rohdatenarray erm.*/

      dm_write_number(fp_res, array[k - 1][rows - total_startline + i], stellen[k]);
      fprintf(fp_res, "-> ");
      dm_write_number(fp_res, out[j][i], stellen[k]);
      fprintf(fp_res, "   ");
    }
    fprintf(fp_res, "\n");
  }

  /* Ausgabe- und Resultatdatei schliessen */
  if (ferror(fp_out)  ||  fclose(fp_out) == EOF)
    dm_read_err(diff_name);
  if (ferror(fp_res)  ||  fclose(fp_res) == EOF)
    dm_write_err(total_name);
}
