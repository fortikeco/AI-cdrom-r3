/*
** Free the storage allocated to a machine 
*/
# include "Tools.h"

void Free_weight_matrix(weight)
Tools_type **weight;
{
  free((char*) *weight);
  free((char*)  weight);
}

void Free_machine(p)
Machine_type *p;
{
  /* deallocate space to the machine values */
  free((char*) p->node_ip);
  free((char*) p->node_op);
  free((char*) p->delta);
  Free_weight_matrix(p->weight);
  Free_weight_matrix(p->change);
  Free_weight_matrix(p->smooth);
}
