# include "Tools.h"

void Print_machine(p)
Machine_type *p;
{
  printf("p->ext_ip %d\n", p->ext_ip);
  printf("p->sta_ip %d\n", p->sta_ip);
  printf("p->hidden %d\n", p->hidden);
  printf("p->sta_op %d\n", p->sta_op);
  printf("p->ext_op %d\n", p->ext_op);
  printf("p->length %d\n", p->length);
}
