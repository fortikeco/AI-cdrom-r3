/*
** perform the operation write[i] += read[i] for all i
*/
# include "Tools.h"

void Add(read, write, size)
register Tools_type *read, *write;
int size;
{
#ifndef convexvc
  register Tools_type *end = read + size;
  while(read < end) *write++ += *read++;
#else
  int i;
  /*$dir no_recurrence */
  for(i = 0; i < size; i++) write[i] += read[i];
#endif
}
