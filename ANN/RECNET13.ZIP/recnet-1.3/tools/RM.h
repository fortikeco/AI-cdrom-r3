# define RM_NWORD			992
# define RM_NOTAWORD			(-1)
# define RM_LABEL_SIZE       		16
# define RM_MAXHOMOPHONES		3
# define RM_WORD_LABEL_SIZE		15
# define RM_MAX_NALLOPHONE_PER_WORD	32
# define RM_NPHONE			68	/* was 49 */
# define RM1_NPHONE			42
# define RM1_DEFAULT_NINP		23	/* same as TIMIT */
# define RM_PHONE_LABEL_SIZE		4	/* same as TIMIT */
# define RM1_HEADER_SIZE		1024
# define RM1_CDROM_PATH		"/home/dsl1/ajr/rm1/"
# define RM1_LOCAL_PATH		"/home/dsl1/ajr/DATA/rm1/"
# define RM1_LOCAL_TRUDIR_PATH	"/home/dsl1/ajr/DATA/rm1/truedir/"
# define RM1_DEFAULT_PHNTAB	"/home/dsl1/ajr/lib/sriphone.tab"
# define RM1_DEFAULT_DUR	"/home/dsl1/ajr/lib/rm1_0_32.dur"
# define RM1_DEFAULT_DUR_OFF	"/home/dsl1/ajr/lib/rm1_3_32.dur"
# define RM1_DEFAULT_RMDICT	"/home/dsl1/ajr/lib/pcdsril.dct"
# define RM1_DEFAULT_RMDICT_WPG	"/home/dsl1/ajr/lib/pcdsril.dct"
# define RM1_DEFAULT_WPLIST	"/home/dsl1/ajr/lib/rm1_wplist.wpg"
