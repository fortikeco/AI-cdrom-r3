# define RAY_NWORD 	18
# define RAY_WORD_SIZE	8

static char ray_word[RAY_NWORD][RAY_WORD_SIZE] = {
  "pickup", "the", "green", "apple", "a", "red", "grasp", "ball", "release",
  "blue", "and", "move", "cup", "an", "orange", "yellow", "bowl", "black"};

