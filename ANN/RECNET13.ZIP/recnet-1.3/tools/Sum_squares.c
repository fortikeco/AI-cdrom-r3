/* compute the sum of the squared values */
# include "Tools.h"

Tools_type Sum_squares(read, size)
Tools_type *read;
int         size;
{
  register Tools_type sum = 0.0;
  register Tools_type *end;
  read--;
  end = read + size;
  while(read++ < end) sum += *read * *read;
  return(sum);
}

int Sum_squares_int(read, size)
int *read;
int size;
{
  register int sum = 0.0;
  register int *end;
  read--;
  end = read + size;
  while(read++ < end) sum += *read * *read;
  return(sum);
}
