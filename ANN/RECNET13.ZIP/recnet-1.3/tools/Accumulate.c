/*
** Multiply the outputs by the delltas and accumulate in `store'
*/
# include "Tools.h"

void Accumulate(p, store)
Machine_type *p;
Tools_type  **store;
{
  int i;

  /* for all the hidden units */
  for(i = p->hidden; i < p->sta_op; i++)
    Multiply_add2(p->node_op, store[i], i, p->delta[i]);

  /* for all the output units */
  for(i = p->sta_op; i < p->length; i++)
    Multiply_add2(p->node_op, store[i], p->sta_op, p->delta[i]);
}
