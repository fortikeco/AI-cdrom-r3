/* monstrous hack: TADPOLE SPECIFIC!! */
# include "Tools.h"

void Set_heapend() {
#ifdef TC
  _heapend = (void*) (0x801fffff - 0x1f);	/*tee hee*/
#endif
}
