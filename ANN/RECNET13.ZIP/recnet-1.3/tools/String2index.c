# include "Tools.h"

int String2index(char *string, char **slist, int nstring) {
  int i;

  for(i = 0; i < nstring && strcmp(string, slist[i]) != 0; i++);
  if(i == nstring) 
    Panic("String2index: Can't find entry for %s\n", string);
  return(i);
}
