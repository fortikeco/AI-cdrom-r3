/* assumes this process is called at low priority */

# include "Tools.h"

#ifdef TC
sleep(unsigned int seconds) {
  ProcWait(seconds * TickRate_Low);
}

usleep(unsigned int useconds) {
  ProcWait((int) (((float) useconds * (float) TickRate_Low) / 1000000.0));
}
#else
int getnodeid() {
  return(B011_NODEID);
}
#endif
