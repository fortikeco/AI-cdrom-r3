/*****************************************************************************
  FILE           : d3_anageo.h
  SHORTNAME      : anageo.h
  SNNS VERSION   : 3.2

  PURPOSE        : private header for d3_anageo.c
  NOTES          : all functions will be exported

  AUTHOR   	 : Ralf Huebner
  DATE     	 : 1.12.1991

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_anageo.h	1.10 3/2/94
  SCCS VERSION   : 1.10
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _D3_ANAGEO_DEFINED_
#define _D3_ANAGEO_DEFINED_

extern void d3_transMatrix (matrix, vector);
extern void d3_scaleMatrix (matrix, vector);
extern void d3_multMatrix (matrix, matrix, matrix);
extern void d3_multMatrixVector (vector, matrix, vector);
extern void d3_normalVector (vector, vector, vector, vector);
extern void d3_rotateCube (cube, vector, cube);
extern void d3_shiftCube (cube, cube, float, float);
extern void d3_shiftVector (vector, vector, float, float);
extern void d3_projection (cube, vector, cube);
extern void d3_rotateMatrix (matrix, vector);

#endif
/* end of file */

