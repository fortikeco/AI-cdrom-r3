/*****************************************************************************
  FILE           : d3_disp.h
  SHORTNAME      : disp.ph
  SNNS VERSION   : 3.2

  PURPOSE        : header for d3_disp.c
  NOTES          :

  AUTHOR         : Ralf Huebner
  DATE           : 1.12.1991


  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_disp.h	1.9 3/2/94
  SCCS VERSION   : 1.9
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _D3_DISP_DEFINED_
#define  _D3_DISP_DEFINED_


extern void d3_createDisplayWindow (void);
extern Widget d3_displayMainWidget;
extern void d3_eventProc (Widget w, Display *display, XEvent *event);

#endif 
             
/* end of file */
/* lines: */
