/*****************************************************************************
  FILE           : d3_dither.h
  SHORTNAME      : dither.h
  SNNS VERSION   : 3.2

  PURPOSE        : header
  NOTES          :

  AUTHOR         : Ralf Huebner
  DATE           : 1.12.1991

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_dither.h	1.8 3/2/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _D3_DITHER_DEFINED_
#define  _D3_DITHER _DEFINED_

extern int dither (int x, int y, float level);

#endif

/* end of file */
/* lines: */
