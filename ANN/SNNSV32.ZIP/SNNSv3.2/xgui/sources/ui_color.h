/*****************************************************************************
  FILE           : ui_color.h
  SHORTNAME      : color.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer, Universitaet Stuttgart
  DATE           : 18.2.1990

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_color.h	1.12 3/2/94
  SCCS VERSION   : 1.12
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/


#ifndef _UI_COLOR_DEFINED_
#define _UI_COLOR_DEFINED_




#define RGBMAX 65535
#define SNNS_COLORS 96


extern void ui_convertColorString (char *, int *, int *, int *);
extern void ui_colVar_init (void);
extern void ui_col_init (void);
extern void ui_col_getGrayPalette (int *, unsigned long []);
extern void ui_col_freeGrayPalette (int *, unsigned long []);
extern void ui_init_colorPalette (void);

extern unsigned long   ui_col_rangePixels[];

	/* array to hold all colors for selection, text and background */
extern unsigned long ui_editColor[];
extern float ui_editColorRGB[][3];


	/* default values */
extern int ui_initalBackgroundColorIndex;  /* index to ui_editColor */
extern int ui_initalSelectionColorIndex;  /* index to ui_editColor */
extern int ui_initalTextColorIndex;   /* index to ui_editColor */

extern Bool ui_monoOnColorScreen;
extern Bool ui_col_monochromeMode;
extern Bool ui_col_colorDisplay;

extern int  ui_col_steps;


#endif /* _UI_COLOR_DEFINED_ */


/* end of file */
/* lines: 59 */

