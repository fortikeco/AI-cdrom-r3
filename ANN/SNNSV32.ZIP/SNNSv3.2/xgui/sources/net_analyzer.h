/*****************************************************************************
  FILE           : net_analyzer.h
  SHORTNAME      : net_analyzer.c
  SNNS VERSION   : 3.2

  PURPOSE        : header file for corresponding '.c' file
  NOTES          :

  AUTHOR         : Tobias Soyez
  DATE           : 09.11.1993

  CHANGED BY     : 
  IDENTIFICATION : @(#)net_analyzer.h	1.2 3/2/94
  SCCS VERSION   : 1.2 
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/


#ifndef _NET_ANALYZER_DEFINED_
#define _NET_ANALYZER_DEFINED_


extern void NA_OpenNetworkAnalyzer   (Widget w, XtPointer client_data,
                                                XtPointer call_data) ;
extern Bool NA_NetworkAnalyzerIsOpen (void) ;
extern void NA_DrawNextPoint         (void) ;
extern Bool NA_ContinueTest          (void) ;
extern void NA_StopTest              (void) ;


#endif


/*****************************************************************************
                           E N D   O F   F I L E
******************************************************************************/


