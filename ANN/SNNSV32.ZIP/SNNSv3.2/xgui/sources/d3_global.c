/*****************************************************************************
  FILE           : d3_global.c
  SHORTNAME      : global.c
  SNNS VERSION   : 3.2

  PURPOSE        : global variables declaration  
  NOTES          :

  AUTHOR         : Ralf Huebner
  DATE           : 1.12.1991

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_global.c	1.9 3/2/94
  SCCS VERSION   : 1.9
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/X.h>
#include <X11/Xutil.h>


#include "ui.h"
#include "d3_global.ph"


/* end of file */
/* lines: */






