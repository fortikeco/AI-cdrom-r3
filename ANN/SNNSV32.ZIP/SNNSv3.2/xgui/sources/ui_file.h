/*****************************************************************************
  FILE           : ui_file.h
  SHORTNAME      : file.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 22.5.1990

  CHANGED BY     :
  IDENTIFICATION : @(#)ui_file.h	1.10 3/2/94
  SCCS VERSION   : 1.10
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_FILE_DEFINED_
#define _UI_FILE_DEFINED_

extern void ui_xCreateFilePanel (Widget);

extern Widget    ui_filePanel;

	/* strings storing the data of all input fields */
extern Bool      ui_fileIsCreated; /* file panel created yes or no */


#endif /* _UI_FILE_DEFINED_ */

/* end of file */
/* lines: 35 */

