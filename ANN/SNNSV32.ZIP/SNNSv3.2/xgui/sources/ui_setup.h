/*****************************************************************************
  FILE           : ui_setup.h
  SHORTNAME      : setup.h
  SNNS VERSION   : 3.2

  PURPOSE        :
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 18.5.1990

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_setup.h	1.11 3/2/94
  SCCS VERSION   : 1.11
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/

#ifndef _UI_SETUP_DEFINED_
#define _UI_SETUP_DEFINED_

extern void ui_set_initData (struct Ui_DisplayType *);
extern void ui_xCreateSetupPanel (Widget, struct Ui_DisplayType *);

extern FlintType  ui_maxWeight;
extern FlintType  ui_minWeight;
extern Widget ui_showBottomLabel;
extern Widget ui_showTopLabel;
extern FlintType  ui_maxAct;

#endif /* _UI_SETUP_DEFINED_ */


/* end of file */
/* lines: 35 */
