/*****************************************************************************
  FILE           : bn_bighop.h
  SHORTNAME      : bn_bighop
  SNNS VERSION   : 3.2

  PURPOSE        : 
  NOTES          :

  AUTHOR         : Christine Bagdi 
  DATE           : 27.5.1993

  CHANGED BY     : 
  IDENTIFICATION : @(#)bn_bighop.h	1.8 3/24/93
  SCCS VERSION   : 
  LAST CHANGE    : 5/27/93

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/

#ifndef _BN_BIGHOP_DEFINED_
#define  _BN_BIGHOP_DEFINED_

extern void bn_createBigHop (void);


#endif 
/* end of file */
/* lines:  */
