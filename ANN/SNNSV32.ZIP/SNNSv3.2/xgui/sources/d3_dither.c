/*****************************************************************************
  FILE           : d3_dither.c
  SHORTNAME      : dither.c
  SNNS VERSION   : 3.2

  PURPOSE        : dithering of graylevels on a monochrome display
  NOTES          :

  AUTHOR         : Ralf Huebner
  DATE           : 1.12.1991

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_dither.c	1.8 3/2/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/

#include "d3_dither.ph"

/*****************************************************************************
  FUNCTION : dither

  PURPOSE  : calculate the dither value
  RETURNS  : 0 if black or 1 if white
  NOTES    :

******************************************************************************/


int dither (int x, int y, float level)
{
    return (level * size*size > dither_matrix[(x % size) + size * (y % size)]);
}


/* end of file */
/* lines: 71 */

