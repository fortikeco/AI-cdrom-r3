/*****************************************************************************
  FILE           : ui_colEdit.h
  SHORTNAME      : colEdit.h
  SNNS VERSION   : 3.2

  PURPOSE        : header for ui_colEdit.c
  NOTES          : all functions will be exported

  AUTHOR         : Ralf Huebner
  DATE           : 27.5.1992

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_colEdit.h	1.10 3/2/94
  SCCS VERSION   : 1.10
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_COLEDIT_DEFINED_
#define _UI_COLEDIT_DEFINED_




#ifndef ZERO
#define ZERO 0
#endif

#define noOfColToggles     3

extern void ui_createColorEditPannel (Widget, Widget, caddr_t);

#endif /* _UI_COLEDIT_DEFINED_ */


/* end of file */
/* lines: 38 */
