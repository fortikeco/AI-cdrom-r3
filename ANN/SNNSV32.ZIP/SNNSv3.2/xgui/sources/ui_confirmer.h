/*****************************************************************************
  FILE           : ui_confirmer.h
  SHORTNAME      : confirm.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 6.7.1990

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_confirmer.h	1.10 3/2/94
  SCCS VERSION   : 1.10
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_CONFIRMER_DEFINED_
#define _UI_CONFIRMER_DEFINED_

extern void  ui_confirmOk (char *);
extern int   ui_confirmYes (char *);

#endif /* _UI_CONFIRMER_DEFINED_ */


/* end of file */
/* lines: 30 */

