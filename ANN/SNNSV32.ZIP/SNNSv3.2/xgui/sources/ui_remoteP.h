/*****************************************************************************
  FILE           : ui_remoteP.h
  SHORTNAME      : remoteP.h
  SNNS VERSION   : 3.2
  
  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 18.7.1990

  CHANGED BY     : Michael Vogt, Guenter Mamier
  IDENTIFICATION : @(#)ui_remoteP.h	1.12 3/2/94
  SCCS VERSION   : 1.12 
  LAST CHANGE    : 3/2/94  

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_REMOTEP_DEFINED_
#define _UI_REMOTEP_DEFINED_




extern void ui_rem_displayPatternNumber (void);
extern void ui_rem_resetCounter (void);
extern void ui_rem_resetNet (Widget w, XtPointer button, caddr_t call_data);
extern void ui_rem_doInitialization (Widget w, caddr_t client_data, caddr_t call_data);
extern void ui_rem_deleteNet (Widget w, caddr_t client_data, caddr_t call_data);
extern void  ui_rem_stepsProc (Widget widget, Bool multiStepPressed, caddr_t call_data);
extern void ui_rem_moveInPatternsProc (Widget w, int moveType, caddr_t call_data);
extern void ui_rem_testProc (Widget w, XtPointer button, caddr_t call_data);
extern void ui_rem_deleteAllPatternsProc (Widget w, XtPointer button, 
					caddr_t call_data);
extern void ui_rem_modifyPatternProc (Widget w, XtPointer button, caddr_t call_data);
extern void ui_rem_deletePatternProc (Widget w, XtPointer button, caddr_t call_data);
extern void ui_rem_newPatternProc (Widget w, XtPointer button, caddr_t call_data);
extern void ui_rem_learnProc (Widget w, int learnType, caddr_t call_data);
extern void  ui_rem_stopProc (Widget widget, caddr_t client_data, caddr_t call_data);
extern void ui_rem_shuffleProc (Widget w, caddr_t client, caddr_t call);
extern void ui_rem_showModeProc (Widget w, int value, caddr_t call_data);
extern void ui_rem_setRandomWeights (Widget w, int randomType, caddr_t call_data);
extern void ui_rem_getKernelInfo (Widget w, XtPointer button, caddr_t call_data);
extern void ui_rem_defSubPat (Widget button, int randomType, caddr_t call_data);
extern void ui_rem_usePattSet (Widget button, int setNo, caddr_t call_data);
extern void ui_rem_delPattSet (Widget button, int setNo, caddr_t call_data);
extern void ui_rem_updatePattList (void);
extern void ui_rem_getSubPatPanel (void);


extern Widget ui_popPattern;



#endif /* _UI_REMOTEP_DEFINED_ */


/* end of file */
/* lines: 62 */
