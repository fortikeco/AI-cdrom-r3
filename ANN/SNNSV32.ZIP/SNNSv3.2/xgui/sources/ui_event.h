/*****************************************************************************
  FILE           : ui_event.h
  SHORTNAME      : event.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 5.6.1990

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_event.h	1.11 3/2/94
  SCCS VERSION   : 1.11
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_EVENT_DEFINED_
#define _UI_EVENT_DEFINED_

extern void ui_mw_eventProc (Widget, struct Ui_DisplayType *, XEvent *);
extern void ui_can_MapEventProc (Widget,  struct Ui_DisplayType *, XEvent *);

extern unsigned long   *ui_col_mainCells[];
extern struct PosType  ui_pixPosMouse, ui_gridPosMouse; /* current mouse 
			  				   position */


#endif /* _UI_EVENT_DEFINED_ */

/* end of file */
/* lines: 38 */
