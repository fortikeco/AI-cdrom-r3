/*****************************************************************************
  FILE           : cc_main.h
  SHORTNAME      : cc_main.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Michael Schmalzl
  DATE           : 23.2.1993

  CHANGED BY     :
  IDENTIFICATION : @(#)cc_main.h	1.6 3/2/94
  SCCS VERSION   : 1.6
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/
#ifndef _CC_MAIN_DEFINED_
#define  _CC_MAIN_DEFINED_


/* begin global definition section */
extern void cc_readElements(void);
extern void cc_createWindow (void);
/* end global definition section */

/* begin privat  definition section */
/* end privat definition section */

#endif /* _CC_MAIN_DEFINED_ */
