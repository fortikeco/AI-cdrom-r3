/*****************************************************************************
  FILE           : bn_JordElm.h
  SHORTNAME      : bn_JordElm.h
  SNNS VERSION   : 3.2

  PURPOSE        : header file for corresponding '.c' file
  NOTES          :

  AUTHOR         : Tobias Soyez
  DATE           : 09.11.1993

  CHANGED BY     : 
  IDENTIFICATION : @(#)bn_JordElm.h	1.2 3/2/94
  SCCS VERSION   : 1.2 
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/


#ifndef _BN_JORDANELMAN_DEFINED_
#define _BN_JORDANELMAN_DEFINED_


extern void bn_create_jordan (void) ;
extern void bn_create_elman  (void) ;


#endif 


/*****************************************************************************
                        E N D     O F     F I L E
******************************************************************************/










