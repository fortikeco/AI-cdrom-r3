/*****************************************************************************
  FILE           : bn_menu.h
  SHORTNAME      : bn_menu
  SNNS VERSION   : 3.2

  PURPOSE        : 
  NOTES          :

  AUTHOR         : Kai-Uwe Herrmann
  DATE           : 15.1.1993

  CHANGED BY     : 
  IDENTIFICATION : @(#)bn_menu.h	1.8 3/2/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _BN_MENU_DEFINED_
#define  _BN_MENU_DEFINED_


extern void bn_BignetMenu (Widget w, XtPointer client_data, XtPointer call_data);


#endif 
/* end of file */
/* lines:  */
