/*****************************************************************************
  FILE           : bn_artmap.h
  SHORTNAME      : bn_artmap
  SNNS VERSION   : 3.2

  PURPOSE        : 
  NOTES          :

  AUTHOR         : Kai-Uwe Herrmann
  DATE           : 15.1.1993

  CHANGED BY     : 
  IDENTIFICATION : @(#)bn_artmap.h	1.7 3/2/94
  SCCS VERSION   : 1.7
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _BN_ARTMAP_DEFINED_
#define  _BN_ARTMAP_DEFINED_

extern void bn_createARTMAP (void);

#endif 
/* end of file */
/* lines:  */
