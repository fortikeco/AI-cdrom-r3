/*****************************************************************************
  FILE           : ui_kohonen.h
  SHORTNAME      : ui_kohonen.h
  SNNS VERSION   : 3.2

  PURPOSE        : Kohonen Function Prototypes
  NOTES          :

  AUTHOR         : Marcus Ritt
  DATE           : July 13 1993

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_kohonen.h	1.4 3/2/94
  SCCS VERSION   : 1.4
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/
#ifndef _KO_MAIN_DEFINED_
#define  _KO_MAIN_DEFINED_

/* begin global definition section */

extern void kohonen_createWindow (void);
extern Widget ui_ExtraToggle;
extern Widget ui_LayerWidget;
extern int ui_noOfCurrentLayer;
extern int kohonen_open;

/* end global definition section */

#endif /* _KO_MAIN_DEFINED_ */

