/*****************************************************************************
  FILE           : d3_lists.h
  SHORTNAME      : lists.h
  SNNS VERSION   : 3.2

  PURPOSE        : header for d3_lists.c
  NOTES          :

  AUTHOR         : Ralf Huebner
  DATE           : 1.12.199

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_lists.h	1.9 3/2/94
  SCCS VERSION   : 1.9
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _D3_LISTS_DEFINED_
#define _D3_LISTS_DEFINED_

extern void d3_insertUnit (d3_unitPtrType **, int);
extern void d3_displayUnitList (d3_unitPtrType *);

#endif 

/* end of file */
/* lines: */
