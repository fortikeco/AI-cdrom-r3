/*****************************************************************************
  FILE           : ui_config.h
  SHORTNAME      : config.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer, Universitaet Stuttgart
  DATE           : 1.9.1990

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_config.h	1.11 3/2/94
  SCCS VERSION   : 1.11
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/


#ifndef _UI_CONFIG_DEFINED_
#define _UI_CONFIG_DEFINED_

extern int  ui_cfg_save (FILE *);
extern int  ui_cfg_load (FILE *);


#endif /* _UI_CONFIG_DEFINED_ */

/* end of file */
/* lines: 32 */

