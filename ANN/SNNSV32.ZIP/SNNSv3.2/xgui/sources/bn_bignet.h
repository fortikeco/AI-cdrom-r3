/*****************************************************************************
  FILE           : bn_bignet.h
  SHORTNAME      : bn_bignet
  SNNS VERSION   : 3.2

  PURPOSE        : 
  NOTES          :

  AUTHOR         : Michael Schmalzl  
  DATE           : 1.4.1990

  CHANGED BY     : Sven Doering, Kai-Uwe Herrmann
  IDENTIFICATION : @(#)bn_bignet.h	1.11 3/2/94
  SCCS VERSION   : 1.11
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _BN_BIGNET_DEFINED_
#define  _BN_BIGNET_DEFINED_

extern void bn_createBignet (void);


#endif 
/* end of file */
/* lines:  */
