/*****************************************************************************
  FILE           : ui_layer.h
  SHORTNAME      : layer.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 31.8.1990

  CHANGED BY     :
  IDENTIFICATION : @(#)ui_layer.h	1.9 3/2/94
  SCCS VERSION   : 1.9
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_LAYER_DEFINED_
#define _UI_LAYER_DEFINED_




extern void   ui_xCreateLayerPanel(Widget parent);


/* widgets of input fields and buttons */
extern Widget    ui_layerNameWidgets[];
extern Widget    ui_layerButtonWidgets[];
/* the value indicating the initial state of the buttons */
extern unsigned short ui_layerStartValue;


#endif /* _UI_LAYER_DEFINED_ */


/* end of file */
/* lines: 40 */

