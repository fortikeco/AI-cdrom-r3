/*****************************************************************************
  FILE           : bn_TD_bignet.h
  SHORTNAME      : bn_TD_bignet
  SNNS VERSION   : 3.2

  PURPOSE        : 
  NOTES          :

  AUTHOR         : Guenter Mamier
  DATE           : 09.02.93

  CHANGED BY     : 
  IDENTIFICATION : @(#)bn_TD_bignet.h	1.6 3/2/94
  SCCS VERSION   : 1.6
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _BN_TD_BIGNET_DEFINED_
#define  _BN_TD_BIGNET_DEFINED_

void bn_create_TD_Bignet (void);

#endif 
/* end of file */
/* lines: 27 */

