/*****************************************************************************
  FILE           : bn_kohonen.h
  SHORTNAME      : bn_kohonen
  SNNS VERSION   : 3.2

  PURPOSE        : Bignet Kohonen Function Prototypes
  NOTES          :

  AUTHOR         : Marc Seemann, Marcus Ritt
  DATE           : July 13 1993

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)bn_kohonen.h	1.3 3/2/94
  SCCS VERSION   : 1.3
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _BN_KOHONEN_DEFINED_
#define  _BN_KOHONEN_DEFINED_

/* begin global definition section */

extern void bn_createKOHONEN (void);

/* end global definition section */

#endif



