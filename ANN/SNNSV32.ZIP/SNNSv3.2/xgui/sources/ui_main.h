/*****************************************************************************
  FILE           : ui_main.h
  SHORTNAME      : main.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 1.4.1990

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_main.h	1.12 3/2/94
  SCCS VERSION   : 1.12
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_MAIN_DEFINED_
#define _UI_MAIN_DEFINED_


extern void main (int, char **);

#ifndef MAXPATHLEN
#define MAXPATHLEN  512
#endif

	/* path name (see file panel). Initial value by getwd() */
extern char         ui_pathname[];

extern XtAppContext ui_appContext;

	/* label widgets of status info */
extern Widget       ui_stat_posWidget;
extern Widget       ui_stat_selNoWidget;
extern Widget       ui_stat_flagsWidget;

#endif /* _UI_MAIN_DEFINED_ */


/* end of file */
/* lines: 44 */
