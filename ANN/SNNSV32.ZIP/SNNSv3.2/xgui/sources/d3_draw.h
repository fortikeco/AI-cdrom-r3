/*****************************************************************************
  FILE           : d3_draw.h
  SHORTNAME      : draw.c
  SNNS VERSION   : 3.2

  PURPOSE        : header for draw.c
  NOTES          :

  AUTHOR         : Ralf Huebner
  DATE           : 1.12.1991

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_draw.h	1.9 3/2/94
  SCCS VERSION   : 1.9
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _D3_DRAW_DEFINED_
#define _D3_DRAW_DEFINED_

extern void d3_draw_wireframeCube (cube c);
extern void d3_draw_wireframeLine (vector v1, vector v2);

extern void d3_draw_solidLine (float *v1, float *v2);
extern void d3_draw_solidCube (float (*c)[4], float *vp, float *lp, int unit_no);

extern int **d3_cube_lines;

/* indices for the surface */

extern int **d3_vertex_index;


#endif 

/* end of file */
/* lines: */
