/*****************************************************************************
  FILE           : ui_mainP.h
  SHORTNAME      : mainP.h
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 1.4.1990

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_mainP.h	1.11 3/2/94
  SCCS VERSION   : 1.11
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_MAINP_DEFINED_
#define _UI_MAINP_DEFINED_



extern void ui_xCreateGC (Window);
extern void ui_printMessage (char *);
extern void ui_displayDone (Widget, struct Ui_DisplayType *, caddr_t);
extern void ui_popupDone (Widget, int, caddr_t);
extern void ui_rem_initNet (Widget, int, caddr_t);
extern void ui_popupWeights (Widget, int, caddr_t);
extern void ui_editPopup (Widget, struct SimpleListType *, caddr_t);
extern void ui_editSitePopup (Widget, struct SimpleListType *, caddr_t);
extern void ui_listPopup (struct SimpleListType *, Position, Position);
extern void ui_displayFilePanel (Widget, Widget, caddr_t);
extern void ui_displayLayerPanel (Position, Position);
extern void ui_displayGraphic (Widget, struct Ui_DisplayType *, caddr_t);
extern void ui_displayRemote (Widget, caddr_t, caddr_t);
extern void ui_displayText (Widget, caddr_t, caddr_t);
extern void ui_displayHelp (char *);
extern void ui_guiQuit (Widget, XtPointer, XtPointer);
extern void ui_loadFileFromCommandLine (void);
extern void ui_parseCmdLine (XtAppContext, int, char *[]);


	/* Handles of popup shells. Used by ui_popupDone() */
extern Widget ui_popRemote, ui_popResult;

	/* message widget in the remote panel */
extern Widget ui_remoteMessageWidget;

	/* widgets of init net */
extern Widget  ui_initParameterWidgets[];

	/* widgets of jog/random weights panel */
extern Widget  ui_highLimitWidget, ui_lowLimitWidget;

	/* widget of message displayed when the 
	bubble of a slider in the setup panel was moved */
extern Widget  ui_setupSliderMessage;

extern GC             ui_gc;         /* xgui graphic context */
extern XFontStruct   *ui_fontStruct; 
extern int            ui_screen;     /* X screen */

	/* display for with the setup panel was displayed */
extern struct Ui_DisplayType  *ui_set_displayPtr; /* for xgui */

extern Display       *ui_display;    /* for X */

extern Widget  ui_toplevel;
extern Widget  ui_message;  /* message in the manager panel */

	/* shell widgets of info, remote, setup and file panel */
extern Widget  ui_infoPanel, ui_setupPanel;

	/* widgets in the setup panel */
extern Widget  ui_set_gridWidthWidget, ui_set_originXWidget;
extern Widget  ui_set_originYWidget;
extern Widget  ui_set_subnetWidget;
extern Widget  ui_set_zWidget;

	/* panel created yes or no */
extern Bool    ui_setupIsCreated;

	/* data displayed in the file panel */
extern char    ui_edit_actFuncName[];
extern char    ui_edit_outFuncName[];
extern char    ui_edit_FTypeName[];


extern XGCValues      ui_gcValues;   /* initial gc values */



#endif /* _UI_MAINP_DEFINED_ */


/* end of file */
/* lines: 100 */
