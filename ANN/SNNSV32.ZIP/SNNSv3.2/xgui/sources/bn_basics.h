/*****************************************************************************
  FILE           : bn_basics.h
  SHORTNAME      : bn_basics
  SNNS VERSION   : 3.2

  PURPOSE        : 
  NOTES          :

  AUTHOR         : Kai-Uwe Herrmann
  DATE           : 15.1.1993

  CHANGED BY     : 
  IDENTIFICATION : @(#)bn_basics.h	1.8 3/2/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _BN_BASICS_DEFINED_
#define  _BN_BASICS_DEFINED_



#define ART1_MODEL    1
#define ART2_MODEL    2
#define ARTMAP_MODEL  3



extern Widget bn_basics_xCreateButtonItem (char *name,Widget parent,Widget left,Widget top);
extern void bn_basics_createART(int model, Widget *baseWidget,int *already_open,
                                Widget unitWidget[], Widget rowWidget[],
                                XtCallbackProc   CreateCallbackProc,
                                XtCallbackProc   DoneCallbackProc
                               );
extern void bn_basics_refresh (void);
extern int bn_basics_check_existingNetwork (void);
extern void bn_basics_getValues (int NoOfLayers, int units[], int rows[],
                                 Widget unitWidget[], Widget rowWidget[]);
extern int bn_basics_checkValues (int NoOfLayers, int units[], int rows[]);

#endif 
/* end of file */
/* lines:  */
