/*****************************************************************************
  FILE           : d3_light.h
  SHORTNAME      : light.h
  SNNS VERSION   : 3.2

  PURPOSE        : header for d3_light.c
  NOTES          :

  AUTHOR         : Ralf Huebner
  DATE           : 1.12.1991

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_light.h	1.8 3/2/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _D3_LIGHT_DEFINED_
#define _D3_LIGHT_DEFINED_

extern void d3_createLightPannel (Widget w, Widget button, caddr_t call_data);

#endif

/* end of file */
/* lines:  */
