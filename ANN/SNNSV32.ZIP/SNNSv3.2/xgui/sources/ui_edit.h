/*****************************************************************************
  FILE           : ui_edit.h
  SHORTNAME      : edit.h
  SNNS VERSION   : 3.2

  PURPOSE        : callbacks for editing sites and f-types
  NOTES          :

  AUTHOR         : Tilman Sommer
  DATE           : 25.9.1990

  CHANGED BY     : Guenter Mamier
  IDENTIFICATION : @(#)ui_edit.h	1.11 3/2/94
  SCCS VERSION   : 1.11
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG
             
******************************************************************************/


#ifndef _UI_EDIT_DEFINED_
#define _UI_EDIT_DEFINED_




extern void  ui_edit_selectFunction (Widget, int, caddr_t);
extern void  ui_edit_setSite (Widget, struct SimpleListType *, caddr_t);
extern void  ui_edit_listSetSite (Widget, int, XawListReturnStruct *);
extern void  ui_edit_setCurrentSite (char *);
extern void  ui_edit_newSite (Widget, struct SimpleListType *, caddr_t);
extern void  ui_edit_deleteSite (Widget, struct SimpleListType *, caddr_t);
extern void  ui_edit_displayFirstFType (struct SimpleListType *);
extern void  ui_edit_ftypeAddSite (Widget, struct SimpleListType *, caddr_t);
extern void  ui_edit_ftypeDeleteSite(Widget, struct SimpleListType *, caddr_t);
extern void  ui_edit_chooseFType (Widget, struct SimpleListType *, caddr_t);
extern void  ui_edit_setFType (Widget, struct SimpleListType *, caddr_t);
extern void  ui_edit_newFType (Widget, struct SimpleListType *, caddr_t);
extern void  ui_edit_deleteFType (Widget, struct SimpleListType *, caddr_t);


	/* widgets in the edit panels */
extern Widget ui_edit_siteFuncNameWidget;
extern Widget ui_edit_siteNameWidget;
extern Widget ui_edit_actFuncNameWidget;
extern Widget ui_edit_outFuncNameWidget;
extern Widget ui_edit_ftypeNameWidget;


	/* the following values are available after */
	/* the call of ui_list_buildList */
extern int   ui_list_noOfFtypes;     /* no of ftypes reported by the kernel */

	/* names */
extern char    ui_edit_siteName[];
extern char    ui_edit_siteFuncName[];



#endif /* _UI_EDIT_DEFINED_ */


/* end of file */
/* lines: 63 */
