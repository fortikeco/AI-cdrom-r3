/*****************************************************************************
  FILE           : d3_fonts.h
  SHORTNAME      : fonts.ph
  SNNS VERSION   : 3.2

  PURPOSE        : private header
  NOTES          :

  AUTHOR         : Ralf Huebner
  DATE           : 

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)d3_fonts.h	1.8 3/2/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _D3FONTS_DEFINED_
#define _D3FONTS_DEFINED_

extern void d3_select_font (int selected_font);
extern void d3_get_font_size (int *x, int *y);
extern void d3_draw_string (int xpos, int ypos, float zpos, char *s);

#endif 
/* end of file */
/* lines: 27 */
