/*****************************************************************************
  FILE           : bn_assoz.h
  SHORTNAME      : bn_assoz
  SNNS VERSION   : 3.2

  PURPOSE        : Bignet Auto Assoziative Function Prototypes
  NOTES          :

  AUTHOR         : Guenter Mamier
  DATE           : February 11 1994

  CHANGED BY     : 
  IDENTIFICATION : @(#)bn_assoz.h	1.3 3/2/94
  SCCS VERSION   : 1.3
  LAST CHANGE    : 3/2/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _BN_ASSOZ_DEFINED_
#define  _BN_ASSOZ_DEFINED_

/* begin global definition section */

extern void bn_create_assoz (void);

/* end global definition section */

#endif



