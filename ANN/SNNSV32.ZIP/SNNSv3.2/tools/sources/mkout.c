/*****************************************************************************
  FILE           : mkout.c
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : create snns output patten
  NOTES          :

  AUTHOR         : Ralf Huebner 
  DATE           : 2.4.93

  CHANGED BY     : 
  IDENTIFICATION : @(#)mkout.c	1.3 2/28/94
  SCCS VERSION   : 1.3
  LAST CHANGE    : 2/28/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/


#include <stdio.h>

#define RAWNUM 8

main(int argc, char *argv[])

{
   int i, units, active;

   if ((argc==1) || (int) strcmp(*++argv, "-h")==0 ) {
      fprintf (stderr, "create snns output patten\n\n");
      fprintf (stderr, "  usage: mkout <#units> <active_unit>\n\n");
      exit(0);
   }
   units = atoi(*argv);
   active = atoi(*++argv);
   for (i=0; i<units; i++) {
      if ( (i % RAWNUM == 0) && (i != 0) )
          printf("\n");
      if (i+1==active)
          printf ("1.000 ");
      else
          printf ("0.000 ");
   }
   printf ("\n");
}
   
