/*****************************************************************************
  FILE           : tbl_func.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : SNNS-Kernel: Transfer functions using table lookup and
	           linear approximation method
  NOTES          :

  AUTHOR         : Sven Doering
  DATE           : 25.02.93

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)tbl_func.h	1.8 3/15/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _TBL_FUNC_DEFINED_
#define  _TBL_FUNC_DEFINED_

extern FlintType   ACT_LogisticTbl(struct Unit *unit_ptr);


#endif 
