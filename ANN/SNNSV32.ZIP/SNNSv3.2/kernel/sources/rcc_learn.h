/*****************************************************************************
  FILE           : rcc_learn.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Michael Schmalzl
  DATE           : 5.2.92

  CHANGED BY     : Michael Schmalzl
  IDENTIFICATION : @(#)rcc_learn.h	1.8 3/15/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _RCC_LEARN_DEFINED_
#define  _RCC_LEARN_DEFINED_

/* begin global definition section */
extern krui_err LEARN_RecCasCor(int StartPattern, int EndPattern,
                      float *ParameterInArray, int NoOfInParams,
                      float **ParameterOutArray, int *NoOfOutParams);
extern krui_err rcc_searchRecurrentLinks(void);
/* end   global definition section */

/* begin privat definition section */
/* end privat definition section */

#endif /* _RCC_LEARN_DEFINED_ */



