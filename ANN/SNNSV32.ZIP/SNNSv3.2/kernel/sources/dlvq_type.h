/*****************************************************************************
  FILE           : dlvq_type.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Michael Schmalzl 
  DATE           : 5.2.93

  CHANGED BY     : 
  IDENTIFICATION : @(#)dlvq_type.h	1.6 3/15/94
  SCCS VERSION   : 1.6
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/

typedef struct MIX_UP {
           int counter;
           double *link;
   } MIX_UP_TYPE;

typedef int UNIT_NO;

