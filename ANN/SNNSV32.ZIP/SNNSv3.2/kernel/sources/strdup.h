/*****************************************************************************
  FILE           : strdup.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : System V Library Function strdup.
  NOTES          : The strdup function is missing in the ULTRIX-32 operating system
                    environment.

  AUTHOR         : Niels Mache
  DATE           : 30.07.90

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)strdup.h	1.8 3/15/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/

#ifdef ultrix
#ifndef _STRDUP_DEFINED_
#define _STRDUP_DEFINED_
extern char *strdup(const char *str );
#endif
#endif
