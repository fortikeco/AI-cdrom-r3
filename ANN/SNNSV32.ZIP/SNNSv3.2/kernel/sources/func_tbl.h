/*****************************************************************************
  FILE           : func_tbl.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : SNNS-Kernel Function table
  NOTES          :

  AUTHOR         : Sven Doering
  DATE           : 02.02.93

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)func_tbl.h	1.12 3/15/94
  SCCS VERSION   : 1.12
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _FUNC_TBL_DEFINED_
#define  _FUNC_TBL_DEFINED_

extern struct FuncTable  kernel_func_table[];
extern const int  NoOfKernelFuncs;
#endif 
