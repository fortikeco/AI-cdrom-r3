/*****************************************************************************
  FILE           : kr_pat_scan.h
  SHORTNAME      : pattern scanner
  SNNS VERSION   : 3.2

  PURPOSE        : scanner for pattern files
  NOTES          : preliminary

  AUTHOR         : Michael Vogt
  DATE           : 10.9.93

  CHANGED BY     : 
  IDENTIFICATION : @(#)kr_pat_scan.h	1.2 3/15/94
  SCCS VERSION   : 1.2
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/

#ifndef _KR_PAT_SCAN_DEFINED_
#define _KR_PAT_SCAN_DEFINED_

/* begin global definition section */

extern int pplex(void);
extern void scanner_await_pattern_end(void);
extern void scanner_init_scanner(FILE *in_file);

/* end global definition section */


#endif

