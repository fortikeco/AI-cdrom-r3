/*****************************************************************************
  FILE           : kr_rand.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : SNNS Kernel randomize functions for MS-DOS
  NOTES          :

  AUTHOR         : Niels Mache
  DATE           : 30.06.92

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)kr_rand.h	1.6 3/15/94
  SCCS VERSION   : 1.6
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifdef  __MSDOS__

#ifndef  MSDOS_RAND_FUNCS
#define  MSDOS_RAND_FUNCS

extern void srand48(long seedval);
extern long lrand48(void);
extern double drand48(void);

#endif
#endif
