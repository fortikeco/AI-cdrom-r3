
/*  A Bison parser, made from kr_pat_parse.y with Bison version GNU Bison version 1.22
  */

#define YYBISON 1  /* Identify Bison output.  */

#define yyparse ppparse
#define yylex pplex
#define yyerror pperror
#define yylval pplval
#define yychar ppchar
#define yydebug ppdebug
#define yynerrs ppnerrs
#define	L_BRACKET	258
#define	R_BRACKET	259
#define	VERSION_HEADER	260
#define	GENERATED_AT	261
#define	NO_OF_PATTERN	262
#define	NO_OF_INPUT	263
#define	NO_OF_OUTPUT	264
#define	NO_OF_VAR_IDIM	265
#define	NO_OF_VAR_ODIM	266
#define	MAXIMUM_IDIM	267
#define	MAXIMUM_ODIM	268
#define	ERROR	269
#define	PATTERNEND	270
#define	NUMBER	271
#define	V_NUMBER	272

#line 20 "kr_pat_parse.y"

#include <stdio.h>

/* since the generated parser needs alloca we need to do some special things */
/* for some architectures: */

#ifndef alloca
#ifndef __GNUC__

#ifdef __hpux
#include <malloc.h>
#include <stdio.h>
#endif /* __hpux */

#ifdef sparc
#include <alloca.h>
#endif /* sparc */

#endif /* GNU C. not defined  */
#endif /* alloca not defined.  */

#include "kr_typ.h"
#include "glob_typ.h"
#include "kernel.h"
#include "kr_pat_scan.h"
#include "kr_newpattern.h"
#include "kr_pat_parse.ph"

#line 49 "kr_pat_parse.y"
typedef union
{
	float	value;		/* allgemeine Zahl */	
	struct
	{
		int	v;
		int	r;
	}	version;	/* Versionsnummer #.# */
} YYSTYPE;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		49
#define	YYFLAG		-32768
#define	YYNTBASE	18

#define YYTRANSLATE(x) ((unsigned)(x) <= 272 ? yytranslate[x] : 39)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     1,     5,     6,     7,    19,    22,    25,    26,    31,
    32,    37,    38,    39,    44,    47,    49,    52,    54,    56,
    59,    60,    61,    62,    69,    71,    72,    74,    77
};

static const short yyrhs[] = {    -1,
    20,    19,    31,     0,     0,     0,     5,    17,    21,     6,
     7,    16,    22,    23,    24,    25,    26,     0,     8,    16,
     0,     9,    16,     0,     0,    10,    16,    12,    27,     0,
     0,    11,    16,    13,    27,     0,     0,     0,     3,    28,
    29,     4,     0,     3,     4,     0,    30,     0,    29,    30,
     0,    16,     0,    32,     0,    31,    32,     0,     0,     0,
     0,    33,    36,    34,    37,    35,    15,     0,    27,     0,
     0,    38,     0,    37,    38,     0,    16,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
    72,    85,    95,   104,   113,   116,   127,   136,   140,   157,
   161,   179,   183,   187,   188,   194,   195,   198,   215,   216,
   219,   228,   293,   307,   309,   310,   317,   318,   321
};

static const char * const yytname[] = {   "$","error","$illegal.","L_BRACKET",
"R_BRACKET","VERSION_HEADER","GENERATED_AT","NO_OF_PATTERN","NO_OF_INPUT","NO_OF_OUTPUT",
"NO_OF_VAR_IDIM","NO_OF_VAR_ODIM","MAXIMUM_IDIM","MAXIMUM_ODIM","ERROR","PATTERNEND",
"NUMBER","V_NUMBER","pattern_file","@1","header","@2","@3","i_head","o_head",
"vi_head","vo_head","actual_dim","@4","actual_dim_rest","dim_entry","pattern_list",
"pattern","@5","@6","@7","pattern_start","pattern_body","pattern_entry",""
};
#endif

static const short yyr1[] = {     0,
    19,    18,    21,    22,    20,    23,    24,    24,    25,    25,
    26,    26,    28,    27,    27,    29,    29,    30,    31,    31,
    33,    34,    35,    32,    36,    36,    37,    37,    38
};

static const short yyr2[] = {     0,
     0,     3,     0,     0,    11,     2,     2,     0,     4,     0,
     4,     0,     0,     4,     2,     1,     2,     1,     1,     2,
     0,     0,     0,     6,     1,     0,     1,     2,     1
};

static const short yydefact[] = {     0,
     0,     1,     3,    21,     0,    21,    19,    26,     0,    20,
    13,    25,    22,     0,    15,     0,     0,     4,    18,     0,
    16,    29,    23,    27,     0,    14,    17,     0,    28,     0,
     8,    24,     6,     0,    10,     7,     0,    12,     0,     0,
     5,     0,     0,     9,     0,    11,     0,     0,     0
};

static const short yydefgoto[] = {    47,
     4,     2,     5,    25,    31,    35,    38,    41,    12,    16,
    20,    21,     6,     7,     8,    17,    28,    13,    23,    24
};

static const short yypact[] = {    -3,
   -14,-32768,-32768,-32768,    -1,     6,-32768,     4,     1,-32768,
     5,-32768,-32768,    -6,-32768,    -5,    -2,-32768,-32768,    -4,
-32768,-32768,    -2,-32768,     7,-32768,-32768,     2,-32768,     0,
     9,-32768,-32768,     3,    10,-32768,     8,    11,    13,    12,
-32768,     4,    14,-32768,     4,-32768,    21,    23,-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   -41,-32768,
-32768,    -7,-32768,    20,-32768,-32768,-32768,-32768,-32768,    15
};


#define	YYLAST		38


static const short yytable[] = {    26,
    44,     1,     3,    46,     9,    -2,    11,    14,    15,    18,
    19,    19,    27,    22,    30,    33,    32,    34,    36,    37,
    48,    40,    49,    39,    42,    10,    45,    43,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    29
};

static const short yycheck[] = {     4,
    42,     5,    17,    45,     6,     0,     3,     7,     4,    16,
    16,    16,    20,    16,     8,    16,    15,     9,    16,    10,
     0,    11,     0,    16,    12,     6,    13,    16,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    23
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/local/gnu/lib/bison-1.22/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 184 "/usr/local/gnu/lib/bison-1.22/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 73 "kr_pat_parse.y"
{	
		    current_pattern = 0;
		    next_pattern_is_input = 1;

		    if (kr_np_AllocatePatternSet(&pattern_set, no_of_pattern)
			!= KRERR_NO_ERROR)
		    { 
			yyerror("can't allocate memory"); 
			YYABORT; 
		    }
		;
    break;}
case 2:
#line 85 "kr_pat_parse.y"
{
		    if (current_pattern < no_of_pattern ||
			!next_pattern_is_input)
		    { 
			yyerror("unexpected end of file"); 
			YYABORT; 
		    }
		;
    break;}
case 3:
#line 96 "kr_pat_parse.y"
{
		if ((yyvsp[0].version.v == CURRENT_VERSION_V && yyvsp[0].version.r > CURRENT_VERSION_R) ||
		    yyvsp[0].version.v > CURRENT_VERSION_V)
		{ 
		    yyerror("version of pattern file not supported"); 
		    YYABORT; 
		}
	;
    break;}
case 4:
#line 105 "kr_pat_parse.y"
{
		no_of_pattern = (int) yyvsp[0].value;
		if (no_of_pattern <= 0)
		{ 
		    yyerror("illegal number of pattern"); 
		    YYABORT; 
		}
	;
    break;}
case 6:
#line 117 "kr_pat_parse.y"
{ 
		no_of_input = (int) yyvsp[0].value;
		if (no_of_input < 0)
		{ 
		    yyerror("illegal number of input units"); 
		    YYABORT; 
		} 
	;
    break;}
case 7:
#line 128 "kr_pat_parse.y"
{ 
		no_of_output = (int) yyvsp[0].value;
		if (no_of_output < 0)
		{ 
		    yyerror("illegal number of output units"); 
		    YYABORT; 
		} 
	;
    break;}
case 8:
#line 137 "kr_pat_parse.y"
{ no_of_output = 0; ;
    break;}
case 9:
#line 141 "kr_pat_parse.y"
{
		variable_input_dim = yyvsp[-2].value; 
		if (variable_input_dim < 0 || 
		    variable_input_dim > MAX_NO_OF_VAR_I_DIM)
		{ 
		    yyerror("illegal variable input dimensions"); 
		    YYABORT; 
		}
		if (actual_dim_count != variable_input_dim)
		{ 
		    yyerror("illegal number of entries in dimension list"); 
		    YYABORT; 
		}
		for (i=0; i<variable_input_dim; i++)
			max_i_dims[i] = dims[i];
	;
    break;}
case 10:
#line 158 "kr_pat_parse.y"
{ variable_input_dim = 0; ;
    break;}
case 11:
#line 162 "kr_pat_parse.y"
{
		variable_output_dim = yyvsp[-2].value; 
		if (variable_output_dim < 0 || 
		    variable_output_dim > MAX_NO_OF_VAR_O_DIM ||
		    no_of_output == 0)
		{ 
		    yyerror("illegal variable output dimensions"); 
		    YYABORT; 
		}
		if (actual_dim_count != variable_output_dim)
		{ 
		    yyerror("illegal number of entries in dimension list"); 
		    YYABORT; 
		}
		for (i=0; i<variable_output_dim; i++)
			max_o_dims[i] = dims[i];	
	;
    break;}
case 12:
#line 180 "kr_pat_parse.y"
{ variable_output_dim = 0; ;
    break;}
case 13:
#line 184 "kr_pat_parse.y"
{
			actual_dim_count = 0;
		;
    break;}
case 15:
#line 189 "kr_pat_parse.y"
{
		        actual_dim_count = 0;
		;
    break;}
case 18:
#line 199 "kr_pat_parse.y"
{
		if (actual_dim_count >= MAX_NO_OF_VAR_DIM)
		{ 
		    yyerror("to many entries in dimension list"); 
		    YYABORT; 
		}
		dims[actual_dim_count] = (int) yyvsp[0].value;
		if (dims[actual_dim_count] <= 0)
		{ 
		    yyerror("illegal size of dimension"); 
		    YYABORT; 
		}
		actual_dim_count++;
	;
    break;}
case 21:
#line 220 "kr_pat_parse.y"
{
    if (current_pattern >= no_of_pattern)
    { 
	yyerror("to many patterns"); 
	YYABORT; 
    }
;
    break;}
case 22:
#line 228 "kr_pat_parse.y"
{
    if (kr_np_GetDescriptor(pattern_set, current_pattern, &pattern)
	!= KRERR_NO_ERROR)
    {
	yyerror("pattern parser internal error");
	YYABORT;
    }
    if (next_pattern_is_input)
    {
	pattern -> input_fixsize = no_of_input;
	pattern -> input_dim = variable_input_dim;
	pattern -> output_fixsize = no_of_output;
	pattern -> output_dim = variable_output_dim;
	if (actual_dim_count != variable_input_dim)
	{ 
	    yyerror("illegal number of entries in dimension list"); 
	    YYABORT; 
	}
	act_size = no_of_input;
	for (i=0; i<variable_input_dim; i++)
	{
	    if (dims[i] > max_i_dims[i])
	    { 
		yyerror("variable dimension overflow"); 
		YYABORT; 
	    }
	    act_size *= dims[i];
	    (pattern -> input_dim_sizes)[i] = dims[i];
	}
	if (kr_np_AllocatePattern(pattern, next_pattern_is_input)
	    != KRERR_NO_ERROR)
	{ 
	    yyerror("can't allocate memory"); 
	    YYABORT; 
	}
	pat_mem = pattern -> input_pattern;
    }
    else
    {
	if (actual_dim_count != variable_output_dim)
	{ 
	    yyerror("illegal number of entries in dimension list"); 
	    YYABORT; 
	}
	act_size = no_of_output;
	for (i=0; i<variable_output_dim; i++)
	{
	    if (dims[i] > max_o_dims[i])
	    { 
		yyerror("variable dimension overflow"); 
		YYABORT; 
	    }
	    act_size *= dims[i];
	    (pattern -> output_dim_sizes)[i] = dims[i];
	}
	if (kr_np_AllocatePattern(pattern, next_pattern_is_input)
	    != KRERR_NO_ERROR)
	{ 
	    yyerror("can't allocate memory"); 
	    YYABORT; 
	}
	pat_mem = pattern -> output_pattern;
    }
;
    break;}
case 23:
#line 293 "kr_pat_parse.y"
{
    if (act_size > 0)
    { 
	yyerror("to little values in pattern"); 
	YYABORT; 
    }
    
    if (no_of_output > 0)
	next_pattern_is_input = !next_pattern_is_input;
    
    if (next_pattern_is_input)
	current_pattern++;
;
    break;}
case 26:
#line 311 "kr_pat_parse.y"
{
    actual_dim_count = 0;
;
    break;}
case 29:
#line 322 "kr_pat_parse.y"
{
		if (act_size == 0)
		{ 
		    yyerror("to many values in pattern"); 
		    YYABORT; 
		}
		*pat_mem++ = yyvsp[0].value;
		if (--act_size == 0)
		    scanner_await_pattern_end(); 
	;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 465 "/usr/local/gnu/lib/bison-1.22/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 335 "kr_pat_parse.y"


#ifndef alloca
#ifndef __GNUC__
#ifdef __hpux
/*****************************************************************************
  FUNCTION : alloca

  PURPOSE  : must be provided for the parser.
             Uses malloc to allocate memory. This memory is not automatically
             freed as in the original alloca definition 
  RETURNS  : pointer to memory
  NOTES    : This is necessary for HP_UX only since there comes no alloca() 
             with the HP cc C-compiler.
	     It is not necessary with Gnu C

  UPDATE   : 
******************************************************************************/
void *alloca(int size)
{
    void *p;

    p = malloc(size);
    fprintf(stderr, "warning: malloc called instead of alloca\n");
    return p;
}
#endif /* __hpux */
#endif /* GNU C. not defined  */
#endif /* alloca not defined.  */

/*****************************************************************************
  FUNCTION : yyerror

  PURPOSE  : must be provided for the parser.
             reports errors in pattern file to stderr
  RETURNS  : nothing
  NOTES    :

  UPDATE   : 
******************************************************************************/
static void yyerror(char *error)
{
    fprintf(stderr, "Parse error in pattern file at line %d:\n%s\n",
	    lineno, error);
}

/*****************************************************************************
  FUNCTION : parse_pattern_file

  PURPOSE  : calls the real parser

  RETURNS  : parser error code and the handle to the loaded pattern set
  NOTES    :

  UPDATE   : 
******************************************************************************/
int parse_pattern_file(int *set)
{
    int err;

    lineno = 1;
    err = yyparse();
    *set = pattern_set;

    if (err == 0)
	lineno = 0;

    return err;
}

/*****************************************************************************
END OF FILE
******************************************************************************/
