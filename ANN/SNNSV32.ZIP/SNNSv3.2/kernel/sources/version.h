/*****************************************************************************
  FILE           : version.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : SNNS-Kernel: Current Version and Patchlevel
  NOTES          :

  AUTHOR         : Niels Mache 
  DATE           : 15.08.9

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)version.h	1.16 3/15/94
  SCCS VERSION   : 1.16
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef VERSION_INCLUDE
#define VERSION_INCLUDE

/*  define the current patchlevel
*/
#define KERNEL_DATE    "09-08-1993"
#define KERNEL_PATCH   "0"

#ifdef KERNEL3D
#ifdef MASPAR_KERNEL
#define  SNNS_VERSION   "SNNS MasPar 3D-Kernel V3.2 (Spontanous Warp Speed)"
#else
#define  SNNS_VERSION   "SNNS 3D-Kernel V3.2"
#endif
#else
#ifdef MASPAR_KERNEL
#define  SNNS_VERSION   "SNNS MasPar Kernel V3.2 (Spontanous Warp Speed)"
#else
#define  SNNS_VERSION   "SNNS Kernel V3.2"
#endif
#endif

/*  Version of I/O Manager  */
#define NETFILE_VERSION  "V1.4"
#define NETFILE_VERSION2  "V2.1"

/*  3D-Kernel Netfile Version  */
#define KERNEL3D_NETFILE_VERSION  "-3D"

#endif
