/*****************************************************************************
  FILE           : dlvq_learn.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Michael Schmalzl 
  DATE           : 5.2.93

  CHANGED BY     : 
  IDENTIFICATION : @(#)dlvq_learn.h	1.8 3/15/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/

/* begin global definition section */

extern krui_err getNoOfClasses(int startPattern, int endPattern);
extern krui_err LEARN_DLVQ(int startPattern, int endPattern, float *ParameterInArray,
                   int NoOfInParams, float **ParameterOutArray, int *NoOfOutParams);
extern void normPatterns(int startPattern, int endPattern);
extern void allocInitialUnitArray(void);
extern void initInitialUnitArray(int startPattern, int endPattern);
extern void allocArrays(void);
extern krui_err dlvq_setPointers(void);
extern void generateMissingClassHiddenUnits(int *generatedNewUnit);

extern int newPatternsLoaded;
extern int dlvq_numberOfLearnCycles;
/* end global definition section */

/* begin privat definition section */
/* end privat definition section */
