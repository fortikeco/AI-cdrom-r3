/*****************************************************************************
  FILE           : kr_rand.c
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : SNNS Kernel randomize functions for MS-DOS
  NOTES          :

  AUTHOR         : Niels Mache
  DATE           : 30.06.92

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)kr_rand.c	1.8 3/15/94
  SCCS VERSION   : 1.8
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifdef  __MSDOS__

#ifndef  MSDOS_RAND_FUNCS
#define  MSDOS_RAND_FUNCS

#include <stdlib.h>

void srand48(long seedval)
{
        srand((int) seedval);
}

long lrand48(void )
{
        return ((long) rand());
}

double drand48(void)
{
        return ((double) rand() / (double) RAND_MAX);
}

#endif
#endif
