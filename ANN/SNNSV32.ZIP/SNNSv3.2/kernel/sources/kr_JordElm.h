/*****************************************************************************
  FILE           : kr_JordElm.h
  SHORTNAME      : kr_JordElm.h
  SNNS VERSION   : 3.2

  PURPOSE        : header file for corresponding '.c' file
  NOTES          :

  AUTHOR         : Tobias Soyez
  DATE           : 09.11.1993

  CHANGED BY     : 
  IDENTIFICATION : @(#)kr_JordElm.h	1.2 3/15/94
  SCCS VERSION   : 1.2
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/


#ifndef _KR_JORDANELMAN_DEFINED_
#define _KR_JORDANELMAN_DEFINED_


extern krui_err kr_topoCheckJE (void) ;
extern krui_err kr_topoSortJE  (void) ;
 

#endif


/*****************************************************************************
                        E N D     O F     F I L E
******************************************************************************/









