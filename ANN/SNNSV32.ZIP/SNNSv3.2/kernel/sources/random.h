/*****************************************************************************
  FILE           : random.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : System V Library Functions
  NOTES          :

  AUTHOR         : Niels Mache
  DATE           : 01.10.90

  CHANGED BY     : Sven Doering
  IDENTIFICATION : @(#)random.h	1.10 3/15/94
  SCCS VERSION   : 1.10
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef SYS_FUNCS
#define SYS_FUNCS

double	drand48( void );
int	rand( void );
long    lrand48(void );
void    srand48( long );

#endif
