/*****************************************************************************
  FILE           : kr_pat_parse.h
  SHORTNAME      : pat_parse
  SNNS VERSION   : 3.2

  PURPOSE        : parser for new pattern format; bison format 
  NOTES          : impossible to use with yacc

  AUTHOR         : Michael Vogt
  DATE           : 10.9.93

  CHANGED BY     : 
  IDENTIFICATION : @(#)kr_pat_parse.h	1.3 3/15/94
  SCCS VERSION   : 1.3
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/

#ifndef _KR_PAT_PARSE_DEFINED_
#define _KR_PAT_PARSE_DEFINED_

/* begin global definition section */

#define CURRENT_VERSION_V       3  /* current version of pattern file        */
#define CURRENT_VERSION_R       2  /* format                                 */

extern int parse_pattern_file(int *set);


/* end global definition section */


#endif

