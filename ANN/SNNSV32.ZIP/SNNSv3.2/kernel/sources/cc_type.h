/*****************************************************************************
  FILE           : cc_type.h
  SHORTNAME      : type.h
  SNNS VERSION   : 3.2

  PURPOSE        : type definitions for cascade correlation
  NOTES          :

  AUTHOR         : Michael Schmalzl
  DATE           : 24.2.93

  CHANGED BY     : 
  IDENTIFICATION : @(#)cc_type.h	1.7 3/15/94
  SCCS VERSION   : 1.7
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/

#ifndef _CC_TYPE_DEFINED_
#define _CC_TYPE_DEFINED_

typedef struct CC_DATA {
  struct {
    float pixelError;
    int learningFunc;
    int onOff;
  } GLOBAL;
  struct {
    double covarianceChange;
    int    candidatePatience;
    int    maxNoOfUpdateCycles;
    int    maxNoOfCandUnits;
    int    actFunc;
  } CAND;
  struct {
    double errorChange;
    int    outputPatience;
    int    maxNoOfUpdateCycles;
  } OUT;
} CASCADE_TYPE;

#endif
