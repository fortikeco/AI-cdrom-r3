typedef union
{
	float	value;		/* allgemeine Zahl */	
	struct
	{
		int	v;
		int	r;
	}	version;	/* Versionsnummer #.# */
} YYSTYPE;
#define	L_BRACKET	258
#define	R_BRACKET	259
#define	VERSION_HEADER	260
#define	GENERATED_AT	261
#define	NO_OF_PATTERN	262
#define	NO_OF_INPUT	263
#define	NO_OF_OUTPUT	264
#define	NO_OF_VAR_IDIM	265
#define	NO_OF_VAR_ODIM	266
#define	MAXIMUM_IDIM	267
#define	MAXIMUM_ODIM	268
#define	ERROR	269
#define	PATTERNEND	270
#define	NUMBER	271
#define	V_NUMBER	272


extern YYSTYPE pplval;
