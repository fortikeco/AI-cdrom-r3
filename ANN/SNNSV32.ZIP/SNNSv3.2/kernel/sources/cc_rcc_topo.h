/*****************************************************************************
  FILE           : cc_rcc_topo.h
  SHORTNAME      : 
  SNNS VERSION   : 3.2

  PURPOSE        : Header file of correspondent '.c' file
  NOTES          :

  AUTHOR         : Michael Schmalzl
  DATE           : 5.2.93

  CHANGED BY     : Michael Schmalzl
  IDENTIFICATION : @(#)cc_rcc_topo.h	1.7 3/15/94
  SCCS VERSION   : 1.7
  LAST CHANGE    : 3/15/94

             Copyright (c) 1990-1994  SNNS Group, IPVR, Univ. Stuttgart, FRG

******************************************************************************/
#ifndef _CC_RCC_TOPO_DEFINED_
#define  _CC_RCC_TOPO_DEFINED_

/* begin global definition section */
extern krui_err cc_topoSort(int topoSortId);
/* end global definition section */

/* begin privat definition section */
/* end privat definition section */

#endif /* _CC_RCC_TOPO_DEFINED_ */
