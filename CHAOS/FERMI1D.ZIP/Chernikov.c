/*
 *    Chernikov.c
 *
 * Copyright (C) 1992 1993
 *
 *	Ataollah Etemadi,
 *	Space and Atmospheric Physics Group,
 *	Blackett Laboratory,
 *	Imperial College of Science, Technology and Medicine
 *	Prince Consort Road,
 *	London SW7 2BZ.
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 1, or
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *    Note: This program has been exempted from the requirement of
 *	  paragraph 2c of the General Public License.
 *
 *
 * Name          : /usr/users/mho/atae/mssl/chaos/Chernikov.c
 * Author        : Ata Etemadi
 * Institution   : Imperial College of Science, Technology, and Medicine
 * Written on    : Fri Apr 30 17:16:13 1993
 * Modified on   : 
 * Synopsis      : 
 * Description   : 
 * Iterates through the Chernikov equations (Nature Vol. 326, April 1987)
 * and produces an image based on occupancy of cells.
 */

#include <stdio.h>     /* Standard C I/O library */
#include <math.h>      /* Standard C mathematics library */

#define HEIGHT  256
#define WIDTH   256
#define MAXGRAY 255

main(argc,argv)

 int  argc;
 char **argv;

{

/*
 * Indecies
 */

	register int i,j;
	register int row,col;

	FILE *DataFile;
	FILE *ImageFile;
	FILE *DistFile;
	FILE *ThetaFile;

/* 
 * Create buffer for image
 */
	float DistImage [HEIGHT][WIDTH];
	float ThetaImage[HEIGHT][WIDTH];
	int   IntImage  [HEIGHT][WIDTH];

       float Dist;
       float Theta;

       float RowNorm;
       float ColNorm;
       float DistNorm;
       float ThetaNorm;
/* 
 * Chernikov parameters
 */
	int NIter;

	float Jump;
	float Alpha;
	float K;
	float U0,U1;
	float V0,V1;

/*
 * Constants
 */
	float KoverAlpha;
	float cosAlpha;
	float sinAlpha;
	float Beta;

	float pi;
	float pi2;
/*
 *  Set defaults, and process command line options
 */
       pi     = 2.0*acos(0.0);
       pi2    = 2.0*pi;
	Alpha 	= 2.0*pi/5.0; 
	K 	= 2.0;
	U0 	= 0.0;
	V0 	= 15.0;
	NIter 	= 100000;

  for (i=1;i<argc;i++) {
    if (argv[i][0] == '-') {
      switch (argv[i][1]) {
	    case 'a': Alpha 	= atof(argv[++i]); continue;	
	    case 'k': K 	= atof(argv[++i]); continue;	
	    case 'u': U0 	= atof(argv[++i]); continue;	
	    case 'v': V0 	= atof(argv[++i]); continue;	
	    case 'n': NIter  = atoi(argv[++i]); continue;	
           default : fprintf(stderr,"unrecognized option: %s",argv[i]); return(-1);
	    case 'h':
 		fprintf(stderr,"\nUSAGE :\n");
		fprintf(stderr," Chernikov -[akuvnh]\n\n");
		fprintf(stderr,"OPTION:                    DEFAULT:\n");
		fprintf(stderr,"-----------------------------------\n");
		fprintf(stderr," -a Alpha                   2pi/15\n");
		fprintf(stderr," -k Kappa                   0.9\n");
		fprintf(stderr," -u Initial Phase           0.0\n");
		fprintf(stderr," -v Initial Velocity        15.0\n");
		fprintf(stderr," -n Interations             10000\n");
		return(-1);
      }
    }
  }

       DataFile  = fopen("chernikov.dat"  ,"w");
       ImageFile = fopen("chernikov.pgm"  ,"w");
       DistFile  = fopen("chernikov.d.pgm","w");
       ThetaFile = fopen("chernikov.t.pgm","w");
/*
 * Initialise OutImage pixels and starting parameters
 */
      for (i = 0; i < HEIGHT; i++) {
         for (j = 0; j < WIDTH; j++) {
           DistImage [i][j] = 0.0;
           ThetaImage[i][j] = 0.0;
           IntImage  [i][j] = 0;
         }
      }

        cosAlpha = cos(Alpha);
        sinAlpha = sin(Alpha);
        KoverAlpha = K/Alpha;

      RowNorm  = ((float) HEIGHT) /100.0;
      ColNorm  = ((float) WIDTH)  /100.0;
      ThetaNorm= ((float) MAXGRAY)/pi2;
/*
 * Now iterate through the Chernikov equation
 */

  for (i = 0; i < NIter; i++) {

	     Beta = U0 + KoverAlpha*sin(V0);
	     U1 =  Beta*cosAlpha + V0*sinAlpha;
	     V1 = -Beta*sinAlpha + V0*cosAlpha;

	     Dist = sqrt ( (U1-U0)*(U1-U0) + (V1-V0)*(V1-V0) );
	     Theta= atan2( fabs(U1-U0), fabs(V1-V0) );

	     fprintf(DataFile,"%f %f %f %f\n",U1,V1,Dist,Theta);

	     row = (int) (U1*RowNorm) + HEIGHT/2; 
     	     col = (int) (V1*ColNorm) + WIDTH /2;

		if (row <= HEIGHT && col <= WIDTH && row >= 0 && col >= 0) {
                IntImage  [row][col] = IntImage  [row][col] + 1;
                DistImage [row][col] = DistImage [row][col] + Dist;
                ThetaImage[row][col] = ThetaImage[row][col] + Theta;
              }

	     U0 = U1; 
            V0 = V1;
  }

/*
 * Find the max min values of Dist to use in normalisation
 */

  DistNorm = 0.0;
  for (i = 0; i < HEIGHT; i++) {
      for (j = 0; j < WIDTH; j++) {
         if (DistImage[i][j] > DistNorm) DistNorm = DistImage[i][j];
       }
  }
  DistNorm = ((float) MAXGRAY)/DistNorm;

/*
 * Write resultant images with PGM header
 */

  fprintf(ImageFile,"P5\n%d %d\n255\n",HEIGHT,WIDTH);
  fprintf(DistFile ,"P5\n%d %d\n255\n",HEIGHT,WIDTH);
  fprintf(ThetaFile,"P5\n%d %d\n255\n",HEIGHT,WIDTH);

  for (i = 0; i < HEIGHT; i++) {
      for (j = 0; j < WIDTH; j++) {
                 putc(  (char) ( ((int) DistImage[i][j]*DistNorm  )/
                                         IntImage [i][j] )  ,DistFile);
                 putc(  (char) ( ((int) ThetaImage[i][j]*ThetaNorm)/
                                         IntImage  [i][j])  ,ThetaFile);
                 if (IntImage  [i][j] <= MAXGRAY) {
                     putc(  (char) (IntImage  [i][j])       ,ImageFile);
                 } else {
                     putc(  (char) MAXGRAY                  ,ImageFile);
                 }
       }
  }

/*
 * Close files
 */
         fclose(ImageFile);
         fclose(DataFile);
         fclose(DistFile);
         fclose(ThetaFile);

	  return(0);
}
