/*
 *    Fermi1D
 *
 * Copyright (C) 1992 1993
 *
 *	Ataollah Etemadi,
 *	Space and Atmospheric Physics Group,
 *	Blackett Laboratory,
 *	Imperial College of Science, Technology and Medicine
 *	Prince Consort Road,
 *	London SW7 2BZ.
 *
 *    This program is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU General Public License as
 *    published by the Free Software Foundation; either version 1, or
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *    Note: This program has been exempted from the requirement of
 *	  paragraph 2c of the General Public License.
 *
 *
 * Name          : Fermi-1D.c
 * Author        : Ata Etemadi
 * Institution   : Imperial College of Science, Technology, and Medicine
 * Written on    : Thu Apr 29 14:44:32 1993
 * Modified on   : 
 * Description   : 
 *
 * This program initially computes the phase space for 1D Fermi accelaration
 * after Lichtenberg Page 51,52. The distance and angle of trajectory between 
 * successive states within the phase space is computed. The results are
 * dumped to a file as well as being converted to a gray-scale image.
 */

#include <stdio.h>     /* Standard C I/O library */
#include <math.h>      /* Standard C mathematics library */

#define HEIGHT  256
#define WIDTH   256
#define MAXGRAY 255

main(argc,argv)

 int  argc;
 char **argv;

{
      int i,j;
      int row,col;
      int N;	       /* Number of iterations                       */

      float pi;      /* Constants used in the calculation          */
      float pi2;
      float pi2D;

      float D;       /* Normalised distance between walls          */
      float u  [2];  /* Initial and incremented values of u        */
      float Psi[2];  /* Initial and incremented values of Psi      */
      float Dist;    /* How far the point moved in phase space     */
      float Theta;   /* Direction in phase space in which it moved */

      float RowNorm;
      float ColNorm;
      float DistNorm;
      float ThetaNorm;
      float fact;


      float DistImage [HEIGHT][WIDTH];
      float ThetaImage[HEIGHT][WIDTH];
      int   IntImage  [HEIGHT][WIDTH];

      FILE  *DistFile;
      FILE  *ThetaFile;
      FILE  *DataFile;

/*
 * Defaults
 */
      u  [0] = 1.0;
      Psi[0] = 1.0;
      D      = 10.0;
      N      = 100000;
      fact   = 10.0;
/*
 * Process command-line options
 */

 for (i=1;i<argc;i++) {
    if (argv[i][0] == '-') {
      switch (argv[i][1]) {
            case 'u': u  [0]    = atof(argv[++i]); continue;    
            case 'p': Psi[0]    = atof(argv[++i]); continue;    
            case 'd': D         = atof(argv[++i]); continue;    
            case 'n': N         = atoi(argv[++i]); continue;       
            case 'f': fact      = atof(argv[++i]); continue;       
            default : fprintf(stderr,"unrecognized option: %s",argv[i]); return(-1);
            case 'h':
                fprintf(stderr,"\nUSAGE :\n");
                fprintf(stderr," %s -[updnh] > Image\n",argv[0]);
                fprintf(stderr,"OPTION:                    DEFAULT:\n");
                fprintf(stderr,"-----------------------------------\n");
                fprintf(stderr," -u Initial velocity        1.0\n");
                fprintf(stderr," -p Initial Phase           1.0\n");
                fprintf(stderr," -d Distance between walls  10.0\n");
                fprintf(stderr," -n Number of Interations   10000\n");
                fprintf(stderr," -f Normalisation factor    10.0\n");
                return(-1);
      }
    }
  }

/*
 * Initialize
 */
      pi      = 2.0*acos(0.0);
      pi2     = 2.0*pi;
      pi2D    = pi2*D;

      RowNorm  = ((float) HEIGHT) /fact;   /* Normalisation value for u     */
      ColNorm  = ((float) WIDTH)  /pi2;    /* Normalisation value for Psi   */
      ThetaNorm= ((float) MAXGRAY)/pi2;    /* Normalisation value for Theta */

      for (i = 0; i < HEIGHT; i++) {
         for (j = 0; j < WIDTH; j++) {
           DistImage [i][j] = 0.0;
           ThetaImage[i][j] = 0.0;
           IntImage  [i][j] = 0;
         }
      }

	DistFile = fopen("Fermi1D.d.pgm","w");
	ThetaFile= fopen("Fermi1D.t.pgm","w");
	DataFile = fopen("Fermi1D.dat"  ,"w");

/*
 * The 1-D Fermi particle mover
 */

  for (i=0; i<=N; i++) {
 
       u  [1] =     fabs(u[0] + sin(Psi[0]));
       Psi[1] =     Psi[0] + pi2D/u[1];

            if (Psi[1] > pi )
                while (Psi[1] >=  pi) Psi[1] -= pi2;

            if (Psi[1] < -pi)
                while (Psi[1] >= -pi) Psi[1] += pi2;

		  Dist = sqrt( (Psi[1]-Psi[0])*(Psi[1]-Psi[0]) +
                             (u[1]-u[0])*(u[1]-u[0]) );

		  Theta = atan2(fabs(u[1]-u[0]),fabs(Psi[1]-Psi[0]));
                if (Theta < 0.0) Theta += pi2;


		  fprintf(DataFile,"%f %f %f %f\n",Psi[1],fabs(u[1]),Dist,Theta);

                col = (int) ((Psi[1]+pi)*ColNorm);
                row = (int) (   u[1]    *RowNorm);

		  if (col <= HEIGHT && col >=0 && row <= WIDTH && row >= 0) {  
                   IntImage  [row][col] = IntImage  [row][col] + 1;
                   DistImage [row][col] = DistImage [row][col] + Dist; 
                   ThetaImage[row][col] = ThetaImage[row][col] + Theta; 
		  }
              u  [0] = u  [1];
              Psi[0] = Psi[1];

          } /* endfor */

/*
 * Find the max min values of Dist to use in normalisation
 */

  DistNorm = 0.0;
  for (i = 0; i < HEIGHT; i++) {
      for (j = 0; j < WIDTH; j++) {
         if (DistImage[i][j] > DistNorm) DistNorm = DistImage[i][j];
       }
  }
  DistNorm = ((float) MAXGRAY)/DistNorm;

/*
 * Write resultant images with PGM header
 */

  fprintf(DistFile ,"P5\n%d %d\n255\n",HEIGHT,WIDTH);
  fprintf(ThetaFile,"P5\n%d %d\n255\n",HEIGHT,WIDTH);
  for (i = 0; i < HEIGHT; i++) {
      for (j = 0; j < WIDTH; j++) {
                 putc( ( (char)   DistImage[i][j]*DistNorm/
                         ((float) IntImage[i][j]) )  ,DistFile);
                 putc( ( (char)   ThetaImage[i][j]*ThetaNorm/
                         ((float) IntImage[i][j]) )  ,ThetaFile);
       }
  }

/*
 * Close files
 */
         fclose(DataFile);
         fclose(DistFile);
         fclose(ThetaFile);

         return(0);

}
