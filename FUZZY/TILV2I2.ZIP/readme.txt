This is the compressed PostScript file for the latest issue of our company
newsletter.  It is referred to as Volume 2, issue 2, or just the Fall 1992
issue.  It contains articles on:

* A cooperative agreement between Hitachi America, Ltd. and Togai InfraLogic
  to develop and expand the use of fuzzy logic technology in North America.

* VLSI's adoption of TIL's FCA(tm) technology for fuzzy ASICs.

* A MicroFPL Development System for the Intel 8051.

* Hitachi EuroDESC's support of TIL's MicroFPL Development Systems for the
  Hitachi H8/300 and H8/500 families in Europe.

* An In-Circuit emulator for the FC110 DFP(tm) developed by ZAX.

* An FC110-based fuzzy accelerator board for the NEC PC.

* The introduction of TILShell+.

* An FC110-based signal classifier product developed by GTS Trautzl GmbH in
  Germany.

* A prototype ocean drilling system that uses fuzzy logic to compensate for
  ocean swell-induced motion of the drilling platform.

* A new video on fuzzy logic available from the IEEE.

PS: This message is about 170KB, and the compressed PostScript file itself is
about 123KB.
--
Erik Horstkotte, Togai InfraLogic, Inc.
The World's Source for Fuzzy Logic Solutions (The company, not me!)
erik@til.til.com, uunet!til!erik - (714) 975-8522
Standard disclaimer: the preceding are my opinions, not TIL's.
