This is a compressed PostScript file containing the second issue of our
company newsletter, The Fuzzy Source.  It is referred to as Volume 1,
issue 2, or the Fall 1991 issue.  It contains articles on:

* Our new (then) division office in Houston, Texas, known as Togai InfraLogic
  Technology Systems Division.

* The introduction of our SBus fuzzy accelerator board.

* Our alliance with Siemens.

* An SBIR contract award for work in thermal control systems.

* Our world-wide distributors.

* The Fuzzy Technology Design and Applications Seminar we held at Duke on
  January 23, 1992.

* A project that compared PID and Fuzzy control of a servo motor, showing that
  fuzzy control performed better in a difficult environment.

* Our "Fuzzy-Pong" demo, which controls the position of a ping-pong ball in
  a vertical tube by controlling the speed of a fan which blows air into the
  tube.

PS: This message is about 430KB, and the compressed file itself is about 311
KB after uudecoding.
--
Erik Horstkotte, Togai InfraLogic, Inc.
The World's Source for Fuzzy Logic Solutions (The company, not me!)
erik@til.til.com, uunet!til!erik - (714) 975-8522
Standard disclaimer: the preceding are my opinions, not TIL's.
