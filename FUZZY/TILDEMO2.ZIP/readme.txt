Togai InfraLogic Fuzzy Logic Expert System Shell Release 2.0.0

USA Corporate Headquarters:

    Togai InfraLogic, Inc.
    5 Vanderbilt
    Irvine, CA 92718
    PHONE: (714) 975-8522
    FAX:   (714) 975-8524

Release Notes

    This is a demonstration version of TILShell+.  In this version you cannot
save or compile files.	However, all other TILShell+ commands work in the same
way as the complete version of TILShell+.  To execute this demonstation version
of the TILShell run the program "TILDEMO.EXE" in Windows.
