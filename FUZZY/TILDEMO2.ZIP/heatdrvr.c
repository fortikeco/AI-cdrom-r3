/*************************************************************************/
/*									 */
/*	Fuzzy-C Compiler Driver Program: HEATDRVR.C			 */
/*									 */
/*	PURPOSE: This file contains the driver program for the		 */
/*		 heatpump.til file used to control a heat pump. 	 */
/*									 */
/*	Created 4/3/89, Gregory C. Hill, Togai InfraLogic		 */
/*									 */
/*	LANGUAGE: Microsoft C Version 5.1				 */
/*									 */
/*	Copyright (c) Togai InfraLogic, Inc. 1989			 */
/*	All rights reserved.						 */
/*									 */
/*************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <process.h>

void main (int, char * []);
extern Heatpump_Control (char, char, char *);

void main(argc, argv)
int argc;
char *argv[];
{
    char Temperature;
    char Old_Temperature;
    char Pump_Control;
    int current;

    if (argc == 1) {
	puts("USAGE: heatpump temperature1 temperature2 ...\n");
	exit(0);
    }

    current = 1;
    Old_Temperature = (char) atoi(argv[current]);

/* Loop through all of the inputs on the command line and call the rule base */
/* for each value.							     */

    for (current = 1; current < argc;  current++) {

	Temperature = (char) atoi(argv[current]);
	printf("Temperature is %d\n",Temperature);
	printf("Old_Temperature is %d\n",Old_Temperature);

	Heatpump_Control(Old_Temperature,Temperature,&Pump_Control);

	printf("Pump Control is %d\n",Pump_Control);
	Old_Temperature = Temperature;
    }

}
