This is the compressed PostScript file for the Spring/Summer 1992 issue
of our company newsletter.  It is referred to as Volume 2, issue 1, or
just the Spring/Summer 1992 issue.  It contains articles on:

* TILShell+'s simulation facility.

* TIL's second-generation hardware approach, known as FCA(tm).

* The use of the FC110 in industrial control in Japan.

* An FC110-based board from our distributor in Germany (GTA Trautzl GmbH).

* The FC110 wins the 1991 Product of the Year award from the Swedish
  technical magazine, Elteknik.

* FC110DS, Version 2.1.

* A MicroFPL Development System for Hitachi's 4-bit HMCS400 family.

* A derivative of NASA's CLIPS, called Fuzzy-CLIPS.

PS: This message is about 270KB, and the compressed PostScript file is about
192KB after uudecoding.
--
Erik Horstkotte, Togai InfraLogic, Inc.
The World's Source for Fuzzy Logic Solutions (The company, not me!)
erik@til.til.com, uunet!til!erik - (714) 975-8522
Standard disclaimer: the preceding are my opinions, not TIL's.
