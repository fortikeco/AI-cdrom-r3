
This is a compressed PostScript file containing the first issue
of "The Fuzzy Source," our company newsletter.  It is referred to
as Volume 1, issue 1, or the Summer 1991 issue.  It contains articles on:

* Togai InfraLogic's new (at that time) TILGen product for constructing
  rule sets from sampled data.

* Discussion of problem reports in the Macintosh version of TILShell, the
  FCA10AT FC110 board, and problems fixed in FC110DS V2.0.4.

* List of the latest software and hardware versions (at that time).

* An announcement of our first international sales meeting.

* A list of shows in the near future (at that time) at which TIL was to
  have exhibits.

* New features of version 2.3.0 of the Fuzzy-C Development System (FCDS).

* The introduction of our Classifier/Sorter chip.

and a picture of our new office.  Note that the address contained in the
PostScript file is out of date.

PS: This email message is about 311KB, and the compressed PostScript file
itself is about 226KB.
--
Erik Horstkotte, Togai InfraLogic, Inc.
The World's Source for Fuzzy Logic Solutions (The company, not me!)
erik@til.til.com, uunet!til!erik - (714) 975-8522
Standard disclaimer: the preceding are my opinions, not TIL's.
