/* -*-C-*-

Copyright (c) 1987, 1988 Massachusetts Institute of Technology

This material was developed by the Scheme project at the Massachusetts
Institute of Technology, Department of Electrical Engineering and
Computer Science.  Permission to copy this software, to redistribute
it, and to use it for any purpose is granted, subject to the following
restrictions and understandings.

1. Any copy made of this software must include this copyright notice
in full.

2. Users of this software agree to make their best efforts (a) to
return to the MIT Scheme project any improvements or extensions that
they make, so that these may be included in future releases; and (b)
to inform MIT of noteworthy uses of this software.

3. All materials developed as a consequence of the use of this
software shall duly acknowledge such use, in accordance with the usual
standards of acknowledging credit in academic research.

4. MIT has made no warrantee or representation that the operation of
this software will be error-free, and MIT is under no obligation to
provide any services, by way of maintenance, update, or otherwise.

5. In conjunction with products arising from the use of this material,
there shall be no use of the name of the Massachusetts Institute of
Technology nor of any adaptation thereof in any advertising,
promotional, or sales literature without prior written consent from
MIT in each case. */

/* $Header: fileio.c,v 9.31 88/11/12 06:46:53 GMT cph Rel $ */

/* Primitives to perform I/O to and from files. */

#include "scheme.h"
#include "prims.h"
#include "char.h"
#include "string.h"

extern FILE *  OS_file_open ();
extern Boolean OS_file_close ();
extern Boolean OS_file_eof_p ();
extern long    OS_file_length ();
extern long    OS_file_read_chars ();
extern Boolean OS_file_write_chars ();
extern void    OS_file_flush_output ();
extern Boolean OS_file_copy ();
extern Boolean OS_file_rename ();
extern Boolean OS_file_remove ();
extern Boolean OS_file_link_physical ();
extern Boolean OS_file_link_symbolic ();
extern Pointer OS_working_dir_pathname ();
extern Boolean OS_set_working_dir_pathname ();
extern Boolean OS_directory_make ();
extern Pointer OS_directory_open ();
extern Pointer OS_directory_read ();

#define CHANNEL_NUMBER_TO_LONG(location, argument, argument_number)	\
{									\
  if (! (FIXNUM_P (argument)))						\
    error_wrong_type_arg (argument_number);				\
  (location) = (UNSIGNED_FIXNUM_VALUE (argument));			\
  if (((location) < 0) || ((location) > FILE_CHANNELS))			\
    error_bad_range_arg (argument_number);				\
  if ((Channels [(location)]) == NULL)					\
    error_bad_range_arg (argument_number);				\
}

static long
channel_to_long (argument_number)
     int argument_number;
{
  fast Pointer argument;
  fast Pointer channel;
  fast long channel_number;

  argument = (ARG_REF (argument_number));
  if ((OBJECT_TYPE (argument)) != TC_HUNK3)
    error_wrong_type_arg (argument_number);
  channel = (Vector_Ref (argument, 0));
  Touch_In_Primitive (channel, channel);
  CHANNEL_NUMBER_TO_LONG (channel_number, channel, argument_number);
  return (channel_number);
}

FILE *
arg_channel (argument_number)
     int argument_number;
{
  return (Channels [(channel_to_long (argument_number))]);
}

/* (FILE-OPEN-CHANNEL filename output?)
   Open a file called FILENAME, returning a channel number.
   The argument OUTPUT?, if false, means open an input file.
   Otherwise, open an output file. */

DEFINE_PRIMITIVE ("FILE-OPEN-CHANNEL", Prim_file_open_channel, 2, 2, 0)
{
  long i;
  PRIMITIVE_HEADER (2);

  CHECK_ARG (1, STRING_P);
  for (i = 1; (i <= FILE_CHANNELS); i++)
    if ((Channels [i]) == NULL)
      {
	(Channels [i]) =
	  OS_file_open
	    ((Scheme_String_To_C_String (ARG_REF (1))),
	     ((ARG_REF (2)) != SHARP_F));
	if ((Channels [i]) == NULL)
	  error_bad_range_arg (1);
	Open_File_Hook (i);
	PRIMITIVE_RETURN (MAKE_UNSIGNED_FIXNUM (i));
      }
  Primitive_Error (ERR_OUT_OF_FILE_HANDLES);
}

/* (FILE-CLOSE-CHANNEL channel_number)
   Closes the file represented by channel_number. */

DEFINE_PRIMITIVE ("FILE-CLOSE-CHANNEL", Prim_file_close_channel, 1, 1, 0)
{
  long channel;
  Boolean result;
  PRIMITIVE_HEADER (1);

  CHANNEL_NUMBER_TO_LONG (channel, (ARG_REF (1)), 1);
  result = (OS_file_close (Channels [channel]));
  (Channels [channel]) = NULL;
  Close_File_Hook ();
  if (! result)
    error_external_return ();
  PRIMITIVE_RETURN (SHARP_T);
}

DEFINE_PRIMITIVE ("FILE-EOF?", Prim_file_eof_p, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  PRIMITIVE_RETURN ((OS_file_eof_p (arg_channel (1))) ? SHARP_T : SHARP_F);
}

DEFINE_PRIMITIVE ("FILE-LENGTH", Prim_file_length, 1, 1, 0)
{
  long result;
  PRIMITIVE_HEADER (1);

  result = (OS_file_length (arg_channel (1)));
  if (result < 0)
    error_external_return ();
  PRIMITIVE_RETURN (MAKE_UNSIGNED_FIXNUM (result));
}

DEFINE_PRIMITIVE ("FILE-READ-CHAR", Prim_file_read_char, 1, 1, 0)
{
  unsigned char ascii;
  PRIMITIVE_HEADER (1);

  if ((OS_file_read_chars ((arg_channel (1)), &ascii, 1)) != 1)
    error_external_return ();
  PRIMITIVE_RETURN (c_char_to_scheme_char (ascii));
}

DEFINE_PRIMITIVE ("FILE-FILL-INPUT-BUFFER", Prim_file_fill_input_buffer, 2, 2, 0)
{
  fast Pointer buffer;
  PRIMITIVE_HEADER (2);

  CHECK_ARG (2, STRING_P);
  buffer = (ARG_REF (2));
  PRIMITIVE_RETURN
    (MAKE_UNSIGNED_FIXNUM
     (OS_file_read_chars ((arg_channel (1)),
			  (Scheme_String_To_C_String (buffer)),
			  (string_length (buffer)))));
}

DEFINE_PRIMITIVE ("FILE-WRITE-CHAR", Prim_file_write_char, 2, 2, 0)
{
  char ascii;
  PRIMITIVE_HEADER (2);

  ascii = (arg_ascii_char (1));
  if (! (OS_file_write_chars ((arg_channel (2)), &ascii, 1)))
    error_external_return ();
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("FILE-WRITE-STRING", Prim_file_write_string, 2, 2, 0)
{
  fast Pointer buffer;
  PRIMITIVE_HEADER (2);

  CHECK_ARG (1, STRING_P);
  buffer = (ARG_REF (1));
  if (! (OS_file_write_chars ((arg_channel (2)),
			      (Scheme_String_To_C_String (buffer)),
			      (string_length (buffer)))))
    error_external_return ();
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("FILE-FLUSH-OUTPUT", Prim_file_flush_output, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  OS_file_flush_output (arg_channel (1));
  PRIMITIVE_RETURN (SHARP_F);
}

/* File System Operations */

DEFINE_PRIMITIVE ("FILE-EXISTS?", Prim_file_exists, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  CHECK_ARG (1, STRING_P);
  PRIMITIVE_RETURN
    (((OS_file_existence_test (Scheme_String_To_C_String (ARG_REF (1)))) > 0)
     ? SHARP_T
     : SHARP_F);
}

/* (COPY-FILE old-name new-name)
   Make a new copy of the file OLD-NAME, called NEW-NAME. */

DEFINE_PRIMITIVE ("COPY-FILE", Prim_copy_file, 2, 2, 0)
{
  PRIMITIVE_HEADER (2);

  CHECK_ARG (1, STRING_P);
  CHECK_ARG (2, STRING_P);
  if (! (OS_file_copy ((Scheme_String_To_C_String (ARG_REF (1))),
		       (Scheme_String_To_C_String (ARG_REF (2))))))
    error_external_return ();
  PRIMITIVE_RETURN (SHARP_F);
}

/* (RENAME-FILE old-name new-name)
   Moves the file from OLD-NAME to NEW-NAME. */

DEFINE_PRIMITIVE ("RENAME-FILE", Prim_rename_file, 2, 2, 0)
{
  PRIMITIVE_HEADER (2);

  CHECK_ARG (1, STRING_P);
  CHECK_ARG (2, STRING_P);
  if (! (OS_file_rename ((Scheme_String_To_C_String (ARG_REF (1))),
			 (Scheme_String_To_C_String (ARG_REF (2))))))
    error_external_return ();
  PRIMITIVE_RETURN (SHARP_F);
}

/* (REMOVE-FILE filename)
   Delete the given file from the file system.  Signals an error if
   unable to delete the file. */

DEFINE_PRIMITIVE ("REMOVE-FILE", Prim_remove_file, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  CHECK_ARG (1, STRING_P);
  if (! (OS_file_remove (Scheme_String_To_C_String (ARG_REF (1)))))
    error_external_return ();
  PRIMITIVE_RETURN (SHARP_F);
}

/* (LINK-FILE old-file new-file physical?)
   Make NEW-FILE be a link pointing at OLD-FILE.  If PHYSICAL? is
   true, a physical link is created, otherwise a symbolic link is
   created. */

DEFINE_PRIMITIVE ("LINK-FILE", Prim_link_file, 3, 3, 0)
{
  fast char *old_file, *new_file;
  PRIMITIVE_HEADER (3);

  CHECK_ARG (1, STRING_P);
  old_file = (Scheme_String_To_C_String (ARG_REF (1)));
  new_file = (Scheme_String_To_C_String (ARG_REF (2)));
  if (! (((ARG_REF (3)) != SHARP_F)
	 ? (OS_file_link_physical (old_file, new_file))
	 : (OS_file_link_symbolic (old_file, new_file))))
    error_external_return ();
  PRIMITIVE_RETURN (SHARP_F);
}

/* (WORKING-DIRECTORY-PATHNAME)
   Returns the current working directory as a string.*/

DEFINE_PRIMITIVE ("WORKING-DIRECTORY-PATHNAME", Prim_working_dir_pathname, 0, 0, 0)
{
  fast Pointer result;
  PRIMITIVE_HEADER (0);

  result = (OS_working_dir_pathname ());
  if (result == SHARP_F)
    error_external_return ();
  PRIMITIVE_RETURN (result);
}

/* (SET-WORKING-DIRECTORY-PATHNAME! string)
   Changes the current working directory to the given string.
   Returns the old working directory as its value. */

DEFINE_PRIMITIVE ("SET-WORKING-DIRECTORY-PATHNAME!", Prim_set_working_dir_pathname, 1, 1, 0)
{
  fast Pointer result;
  PRIMITIVE_HEADER (1);

  CHECK_ARG (1, STRING_P);
  result = (OS_working_dir_pathname ());
  if (result == SHARP_F)
    error_external_return ();
  if (! (OS_set_working_dir_pathname
	 (Scheme_String_To_C_String (ARG_REF (1)))))
    error_bad_range_arg (1);
  PRIMITIVE_RETURN (result);
}

/* (MAKE-DIRECTORY pathname)
   Create a new directory of the given name. */

DEFINE_PRIMITIVE ("MAKE-DIRECTORY", Prim_make_directory, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  CHECK_ARG (1, STRING_P);
  if (! (OS_directory_make (Scheme_String_To_C_String (ARG_REF (1)))))
    error_bad_range_arg (1);
  PRIMITIVE_RETURN (SHARP_F);
}

/* (OPEN-DIRECTORY pathname)
   Attempts to open the directory specified by the string `pathname'.
   If successful, it returns the first file in the directory, as a string.
   If there is no such file, or the directory cannot be opened, returns #F. */

DEFINE_PRIMITIVE ("OPEN-DIRECTORY", Prim_open_directory, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  CHECK_ARG (1, STRING_P);
  PRIMITIVE_RETURN
    (OS_directory_open (Scheme_String_To_C_String (ARG_REF (1))));
}

/* (DIRECTORY-READ)
   Returns the next file in the directory opened by `open-directory',
   or #F if there are no more files in the directory. */

DEFINE_PRIMITIVE ("DIRECTORY-READ", Prim_directory_read, 0, 0, 0)
{
  PRIMITIVE_HEADER (0);

  PRIMITIVE_RETURN (OS_directory_read ());
}
