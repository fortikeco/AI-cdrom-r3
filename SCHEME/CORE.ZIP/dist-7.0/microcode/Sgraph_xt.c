/* -*-C-*-

Copyright (c) 1987, 1988 Massachusetts Institute of Technology

This material was developed by the Scheme project at the Massachusetts
Institute of Technology, Department of Electrical Engineering and
Computer Science.  Permission to copy this software, to redistribute
it, and to use it for any purpose is granted, subject to the following
restrictions and understandings.

1. Any copy made of this software must include this copyright notice
in full.

2. Users of this software agree to make their best efforts (a) to
return to the MIT Scheme project any improvements or extensions that
they make, so that these may be included in future releases; and (b)
to inform MIT of noteworthy uses of this software.

3. All materials developed as a consequence of the use of this
software shall duly acknowledge such use, in accordance with the usual
standards of acknowledging credit in academic research.

4. MIT has made no warrantee or representation that the operation of
this software will be error-free, and MIT is under no obligation to
provide any services, by way of maintenance, update, or otherwise.

5. In conjunction with products arising from the use of this material,
there shall be no use of the name of the Massachusetts Institute of
Technology nor of any adaptation thereof in any advertising,
promotional, or sales literature without prior written consent from
MIT in each case. */

/* $Header: Sgraph_xt.c,v 1.5 88/08/15 20:34:01 GMT cph Rel $ */

/* Extra starbase primitives. */

#include "scheme.h"
#include "prims.h"
#include "flonum.h"
#include "Sgraph.h"

/* (GRAPHICS-SET-LINE-COLOR COLOR)
      Used to change the style of the line to dashes or dots and 
      dashes or whatever.  Uses Starbase LINE_COLOR_INDEX procedure.
*/
DEFINE_PRIMITIVE ("GRAPHICS-SET-LINE-COLOR", Prim_graphics_set_color, 1, 1, 0)
{
  long color_index;
  Primitive_1_Arg();

  Arg_1_Type(TC_FIXNUM);
  color_index = (long) Get_Integer(Arg1);
  line_color_index(screen_handle, color_index);
  text_color_index(screen_handle, color_index);
  perimeter_color_index(screen_handle, color_index); /*pas*/
  fill_color_index(screen_handle, color_index);	/*pas*/
  PRIMITIVE_RETURN(SHARP_F);
}

DEFINE_PRIMITIVE ("GRAPHICS-INTERIOR-STYLE", Prim_graphics_interior_style, 2, 2, 0)
{
  long style, edged;
  Primitive_2_Args();

  Arg_1_Type(TC_FIXNUM);
  Arg_2_Type(TC_FIXNUM);
  style = (long) Get_Integer(Arg1);
  edged = (long) Get_Integer(Arg1);
  if (style == 0)
    {style = INT_HOLLOW;}
  else 
    {style = INT_SOLID;}
  interior_style(screen_handle, style, edged);
  PRIMITIVE_RETURN(SHARP_F);
}

/* Allowing color definition from scheme - Lyn */
/* Should really make sure that each of the 3  
   colors is between 0 and 1 and that the color_index
   is between 0 and 15 */

DEFINE_PRIMITIVE ("GRAPHICS-DEFINE-COLOR", Prim_graphics_define_color, 4, 4, 0)
{
  long color_index, fixnum;
  float colors[1][3]; /* holds rgb value */
  Primitive_4_Args();

  Arg_1_Type(TC_FIXNUM);
  color_index = (long) Get_Integer(Arg1);
  Make_Flonum(Arg2, colors[0][0], fixnum, ERR_ARG_2_WRONG_TYPE);
  Make_Flonum(Arg3, colors[0][1], fixnum, ERR_ARG_3_WRONG_TYPE);
  Make_Flonum(Arg4, colors[0][2], fixnum, ERR_ARG_3_WRONG_TYPE); /* There is no error 4! */
  define_color_table(screen_handle, color_index, 1, colors); /* Defining 1 color */
  PRIMITIVE_RETURN(SHARP_F);
}

/* A simple BITBLT that copies bits from one portion of the screen to another */

DEFINE_PRIMITIVE ("GRAPHICS-BITBLT", Prim_graphics_bitblt, 6, 6, 0)
{
  long fixnum, x_length, y_length;
  fast float x_source, y_source, x_dest, y_dest;
  Primitive_6_Args();

  Make_Flonum(Arg1, x_source, fixnum, ERR_ARG_2_WRONG_TYPE);
  Make_Flonum(Arg2, y_source, fixnum, ERR_ARG_3_WRONG_TYPE);
  Arg_3_Type(TC_FIXNUM);
  x_length = (long) Get_Integer(Arg3);
  Arg_4_Type(TC_FIXNUM);
  y_length = (long) Get_Integer(Arg4);
  Make_Flonum(Arg5, x_dest,   fixnum, ERR_ARG_3_WRONG_TYPE); /* There is no error 4-6 */
  Make_Flonum(Arg6, y_dest,   fixnum, ERR_ARG_3_WRONG_TYPE); /* There is no error 4-6 */
  block_move(screen_handle, x_source, y_source, x_length, y_length, x_dest, y_dest);
  make_picture_current( screen_handle);
  PRIMITIVE_RETURN(SHARP_F);
}

/* (GRAPHICS-CIRCLE ARG1 ARG2 ARG3)
   Draws circle centered at (ARG1 ARG2) with radius ARG3.
   Uses a clever but obscure algorithm to avoid SIN/COS.
*/

#define plot_pixel(x,y)							\
{									\
  move2d( screen_handle, x, y);						\
  draw2d( screen_handle, x, y);						\
}

DEFINE_PRIMITIVE ("GRAPHICS-CIRCLE", Prim_graphics_circle, 3, 3, 0)
{
  fast float center_x, center_y;
  fast float x, y, temp1, temp2, temp3, temp4; 
  fast float phi, nphi, phiy;
  long fixnum;
  Primitive_3_Args();

  Make_Flonum(Arg1,center_x,fixnum,ERR_ARG_1_WRONG_TYPE);
  Make_Flonum(Arg2,center_y,fixnum,ERR_ARG_2_WRONG_TYPE);
  Make_Flonum(Arg3,x,fixnum,ERR_ARG_3_WRONG_TYPE);

  y   = 0.0;
  phi = 0.0;

  do {
    temp1 = center_x + x;
    temp2 = center_x - x;
    temp3 = center_y + y;
    temp4 = center_y - y;

    plot_pixel(temp1, temp3);
    plot_pixel(temp1, temp4);
    plot_pixel(temp2, temp3);
    plot_pixel(temp2, temp4);

    temp1 = center_x + y;
    temp2 = center_x - y;
    temp3 = center_y + x;
    temp4 = center_y - x;

    plot_pixel(temp1, temp3);
    plot_pixel(temp1, temp4);
    plot_pixel(temp2, temp3);
    plot_pixel(temp2, temp4);

    nphi = phi + y + y + 1.0;
    phiy = ((nphi - x) - x) + 1.0;

    if ((x < y) || (x == y))
      break;

    if (fabs(phiy) < fabs(nphi))
    {
      phi = phiy;
      x = x - 1.0;
      y = y + 1.0;
    }
    else
    {
      phi = nphi;
      y = y + 1.0;
    }
  } while (TRUE);

  xposition = x;
  yposition = y;

  make_picture_current(screen_handle);
  PRIMITIVE_RETURN(SHARP_T);
}

/* (GRAPHICS-DRAW-POLYGON LIST) 
   Polygon corners given in the LIST (x1 y1 x2 y2 ... etc).
*/

DEFINE_PRIMITIVE ("GRAPHICS-DRAW-POLYGON", Prim_graphics_draw_polygon, 1, 1, 0)
{
 float clist[TWICE_MAX_NUMBER_OF_CORNERS];
 fast Pointer List;
 int cnum, Count;
 long fixnum;
 Primitive_1_Arg();

 Arg_1_Type(TC_LIST);
 Touch_In_Primitive(Arg1, List);
 Count = 0;
 while(Type_Code(List) == TC_LIST)
 {
   Make_Flonum(Vector_Ref(List, CONS_CAR), clist[Count], fixnum,
	       ERR_ARG_1_WRONG_TYPE);
   Count += 1;
   if (Count == (TWICE_MAX_NUMBER_OF_CORNERS - 2)) Primitive_Error(ERR_ARG_1_BAD_RANGE);
   Touch_In_Primitive(Vector_Ref(List, CONS_CDR), List);
 }
 if (List != EMPTY_LIST)
   Primitive_Error(ERR_ARG_1_WRONG_TYPE);
 clist[Count] = clist[0];
 clist[Count+1] = clist[1];
 cnum = (Count + 2) / 2;
 polygon2d(screen_handle, clist, cnum, 0);
 make_picture_current(screen_handle);
 PRIMITIVE_RETURN(SHARP_F);
}

/* Mouse hackery. */

int locator_handle;

#define LOCATOR_DEVICE          "/dev/locator"
#define LOCATOR_DEVICE_TYPE     INDEV
#define LOCATOR_DRIVER          "hp-hil"
#define LOCATOR_INIT_TYPE       0
#define LOCATOR_NUMBER          1

#define MOUSE_X_POSITION(x)	(1024.0 * (x) - 512.0)
#define MOUSE_Y_POSITION(x)	(768.0 * (y) - 384.0)
#define MOUSE_Z_POSITION(z)	(z)

void
C_Init_Mouse()
{
  locator_handle = gopen( LOCATOR_DEVICE, LOCATOR_DEVICE_TYPE,
			 LOCATOR_DRIVER, LOCATOR_INIT_TYPE);
  if (locator_handle == -1)
  {
    Primitive_Error(ERR_EXTERNAL_RETURN);
  } 
}

void
starbase_mouse_point(boundary, desired_key, x_ptr, y_ptr)
     int boundary, desired_key;
     double *x_ptr, *y_ptr;
{
  int valid, key;
  float x, y, z;

  while(TRUE)
  {
    sample_locator(locator_handle, LOCATOR_NUMBER, &valid, &x, &y, &z);
    if (valid)
    {
      echo_update(screen_handle, SINGLE_ECHO,
		  MOUSE_X_POSITION(x), MOUSE_Y_POSITION(y),
		  MOUSE_Z_POSITION(z));
    }
    sample_choice(locator_handle, LOCATOR_NUMBER, &valid, &key);
    if (valid && (key == desired_key))
    {
      *x_ptr = ((double) MOUSE_X_POSITION(x));
      *y_ptr = ((double) MOUSE_Y_POSITION(y));
      echo_type(screen_handle, SINGLE_ECHO, boundary,
		*x_ptr, *y_ptr, MOUSE_Z_POSITION(z));
      return;
    }
  }
}

Pointer
starbase_mouse_region(boundary)
     int boundary;
{
  double real_x1, real_y1, real_x2, real_y2;
  Pointer Result, *Orig_Free;

  /* This is done here, so that it will back out before asking the user. */
  Primitive_GC_If_Needed(8);

  echo_type(screen_handle, SINGLE_ECHO, SMALL_TRACKING_CROSS, 0.0, 0.0, 0.0); 
  starbase_mouse_point(boundary, 1, &real_x1, &real_y1);
  starbase_mouse_point(NO_ECHO, 2, &real_x2, &real_y2);
   
  Result = Make_Pointer(TC_LIST, Free);
  Orig_Free = Free;
  Free = Free + 8;
  Store_Flonum_Result(real_x1, *Orig_Free);
  Orig_Free++;
  *Orig_Free++ = Make_Pointer(TC_LIST, Orig_Free + 1);
  Store_Flonum_Result(real_y1, *Orig_Free);         
  Orig_Free++;                                      
  *Orig_Free++ = Make_Pointer(TC_LIST, Orig_Free + 1);
  Store_Flonum_Result(real_x2, *Orig_Free);
  Orig_Free++;
  *Orig_Free++ = Make_Pointer(TC_LIST, Orig_Free + 1);
  Store_Flonum_Result(real_y2, *Orig_Free);
  Orig_Free++;
  *Orig_Free++ = EMPTY_LIST;
  return Result;
}

DEFINE_PRIMITIVE ("MOUSE-INITIALIZE", Prim_mouse_initialize, 0, 0, 0)
{
  Primitive_0_Args();

  C_Init_Mouse();
  PRIMITIVE_RETURN(SHARP_T);
}

/* (MOUSE-WITH-TRACKING-CROSS)
   Turns the mouse on with a small tracking cross, and returns its
   x, y coordinates when the left-hand button is pressed.
*/

DEFINE_PRIMITIVE ("MOUSE-WITH-TRACKING-CROSS", Prim_mouse_with_tracking_cross, 0, 0, 0)
{
  double real_x, real_y;
  Pointer Result, *Orig_Free;
  Primitive_0_Args();

  Primitive_GC_If_Needed(4);

  echo_type(screen_handle, SINGLE_ECHO, SMALL_TRACKING_CROSS, 0.0, 0.0, 0.0); 
  starbase_mouse_point(NO_ECHO, 1, &real_x, &real_y);

  Result = Make_Pointer(TC_LIST, Free);
  Orig_Free = Free;
  Free = Free + 4;
  Store_Flonum_Result(real_x, *Orig_Free);         
  Orig_Free++;                                     
  *Orig_Free++ = Make_Pointer(TC_LIST, Orig_Free + 1);
  Store_Flonum_Result(real_y, *Orig_Free);
  Orig_Free++;
  *Orig_Free++ = EMPTY_LIST;
  PRIMITIVE_RETURN(Result);
}

/* (MOUSE-WITH-RUBBER-BAND-RECTANGLE) 
   Turns the mouse on with a small tracking cross, and tracks its 
   position.  When the left hand key is pressed, the current location of
   cross is remembered and a rubber band rectangle is drawn from that location
   to the new location of the mouse. When the right hand key is pressed
   the previous and the current locations of the mouse are  returned in a list.
*/

DEFINE_PRIMITIVE ("MOUSE-WITH-RUBBER-BAND-RECTANGLE", Prim_mouse_with_rubber_band_rectangle, 0, 0, 0)
{
  Primitive_0_Args();

  PRIMITIVE_RETURN(starbase_mouse_region(RUBBER_BAND_RECTANGLE));
}

/* (MOUSE-WITH-RUBBER-BAND-LINE) 
   Turns the mouse on with a small tracking cross, and tracks its 
   position.  When the left hand key is pressed, the current location of
   cross is remembered and a rubber band line is drawn from that location
   to the new location of the mouse. When the right hand key is pressed
   the previous and the current locations of the mouse are  returned in a list.
*/

DEFINE_PRIMITIVE ("MOUSE-WITH-RUBBER-BAND-LINE", Prim_mouse_with_rubber_band_line, 0, 0, 0)
{
  Primitive_0_Args();

  PRIMITIVE_RETURN(starbase_mouse_region(RUBBER_BAND_LINE));
}
