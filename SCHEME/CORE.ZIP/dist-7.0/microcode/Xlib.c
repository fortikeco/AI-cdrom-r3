/* -*-C-*-

$Header: Xlib.c,v 1.4 88/08/15 20:34:51 GMT cph Rel $

Copyright (c) 1987, 1988 Massachusetts Institute of Technology

This material was developed by the Scheme project at the Massachusetts
Institute of Technology, Department of Electrical Engineering and
Computer Science.  Permission to copy this software, to redistribute
it, and to use it for any purpose is granted, subject to the following
restrictions and understandings.

1. Any copy made of this software must include this copyright notice
in full.

2. Users of this software agree to make their best efforts (a) to
return to the MIT Scheme project any improvements or extensions that
they make, so that these may be included in future releases; and (b)
to inform MIT of noteworthy uses of this software.

3. All materials developed as a consequence of the use of this
software shall duly acknowledge such use, in accordance with the usual
standards of acknowledging credit in academic research.

4. MIT has made no warrantee or representation that the operation of
this software will be error-free, and MIT is under no obligation to
provide any services, by way of maintenance, update, or otherwise.

5. In conjunction with products arising from the use of this material,
there shall be no use of the name of the Massachusetts Institute of
Technology nor of any adaptation thereof in any advertising,
promotional, or sales literature without prior written consent from
MIT in each case. */

/* Xlib Interface */

/* NOTE: Interfaces to a number of the procedures in Xlib have yet to
   be written.  Of the interfaces that have been written, only a small
   number have been tested, in particular, those required to implement
   "Xterm.scm" in the runtime system.  */

#include "scheme.h"
#include "prims.h"
#include "string.h"
#include "Xlib.h"

static int
x_io_error_handler (display)
     Display *display;
{
  fprintf (stderr, "\nX IO Error\n");
  error_external_return ();
}

static int
x_error_handler (display, error_event)
     Display *display;
     XErrorEvent *error_event;
{
  fprintf (stderr, "\nX Error: %s\n",
	   (XErrDescrip (error_event -> error_code)));
  fprintf (stderr, "         Request code: %d\n",
	   (error_event -> request_code));
  fprintf (stderr, "         Request function: %d\n",
	   (error_event -> func));
  fprintf (stderr, "         Request window: %x\n",
	   (error_event -> window));
  fprintf (stderr, "         Error serial: %x\n",
	   (error_event -> serial));
  error_external_return ();
}

DEFINE_PRIMITIVE ("X-INITIALIZE", Prim_x_initialize, 0, 0, 0)
{
  PRIMITIVE_HEADER (0);

  XErrorHandler (x_error_handler);
  XIOErrorHandler (x_io_error_handler);
  PRIMITIVE_RETURN (SHARP_F);
}

/* Section 2.5: Opening and Closing the Display */

DEFINE_PRIMITIVE ("X-OPEN-DISPLAY", Prim_x_open_display, 1, 1, 0)
{ OPERATION_1 (XOpenDisplay, XDISPLAY_VALUE, STRING_ARG); }

DEFINE_PRIMITIVE ("X-SET-DISPLAY", Prim_x_set_display, 1, 1, 0)
{ OPERATION_1 (XSetDisplay, VOID_VALUE, XDISPLAY_ARG); }

DEFINE_PRIMITIVE ("X-CLOSE-DISPLAY", Prim_x_close_display, 1, 1, 0)
{ OPERATION_1 (XCloseDisplay, VOID_VALUE, XDISPLAY_ARG); }

#define DISPLAY_MACRO(macro_name, value)				\
  PRIMITIVE_HEADER (0);							\
									\
  RESOURCE_GC_CHECK ();							\
  PRIMITIVE_RETURN (value (macro_name ()))

DEFINE_PRIMITIVE ("X-DISPLAY-TYPE", Prim_x_display_type, 0, 0, 0)
{ DISPLAY_MACRO (DisplayType, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY-PLANES", Prim_x_display_planes, 0, 0, 0)
{ DISPLAY_MACRO (DisplayPlanes, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY-CELLS", Prim_x_display_cells, 0, 0, 0)
{ DISPLAY_MACRO (DisplayCells, long_to_object); }

DEFINE_PRIMITIVE ("X-PROTOCOL-VERSION", Prim_x_protocol_version, 0, 0, 0)
{ DISPLAY_MACRO (ProtocolVersion, long_to_object); }

DEFINE_PRIMITIVE ("X-QUEUE-LENGTH", Prim_x_queue_length, 0, 0, 0)
{ DISPLAY_MACRO (QLength, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY-WIDTH", Prim_x_display_width, 0, 0, 0)
{ DISPLAY_MACRO (DisplayWidth, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY-HEIGHT", Prim_x_display_height, 0, 0, 0)
{ DISPLAY_MACRO (DisplayHeight, long_to_object); }

#undef DISPLAY_MACRO

#define DISPLAY_VARIABLE(macro_name, value)				\
  PRIMITIVE_HEADER (0);							\
									\
  RESOURCE_GC_CHECK ();							\
  PRIMITIVE_RETURN (value (macro_name))

DEFINE_PRIMITIVE ("X-ROOT-WINDOW", Prim_x_root_window, 0, 0, 0)
{ DISPLAY_VARIABLE (RootWindow, XWINDOW_VALUE); }

DEFINE_PRIMITIVE ("X-BLACK-PIXMAP", Prim_x_black_pixmap, 0, 0, 0)
{ DISPLAY_VARIABLE (BlackPixmap, XPIXMAP_VALUE); }

DEFINE_PRIMITIVE ("X-WHITE-PIXMAP", Prim_x_white_pixmap, 0, 0, 0)
{ DISPLAY_VARIABLE (WhitePixmap, XPIXMAP_VALUE); }

#undef DISPLAY_VARIABLE

/* This is not an advertised feature of Xlib.  Use it at your own risk. */

DEFINE_PRIMITIVE ("X-SELECTED-DISPLAY", Prim_x_selected_display, 0, 0, 0)
{
  PRIMITIVE_HEADER (0);

  RESOURCE_GC_CHECK ();
  PRIMITIVE_RETURN (XDISPLAY_VALUE (_XlibCurrentDisplay));
}

/* Section 2.6: Creating and Destroying Windows */

DEFINE_PRIMITIVE ("X-CREATE-WINDOW", Prim_x_create_window, 8, 8, 0)
{ OPERATION_8 (XCreateWindow, XWINDOW_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       FIXNUM_ARG, XPIXMAP_ARG, XPIXMAP_ARG); }

DEFINE_PRIMITIVE ("X-CREATE-TRANSPARENCY", Prim_x_create_transparency, 5, 5, 0)
{ OPERATION_5 (XCreateTransparency, XWINDOW_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-DESTROY-WINDOW", Prim_x_destroy_window, 1, 1, 0)
{ OPERATION_1 (XDestroyWindow, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-DESTROY-SUBWINDOWS", Prim_x_destroy_subwindows, 1, 1, 0)
{ OPERATION_1 (XDestroySubwindows, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-CREATE", Prim_x_create, 7, 7, 0)
{ OPERATION_7 (XCreate, XWINDOW_VALUE,
	       STRING_ARG, STRING_ARG, STRING_ARG, STRING_ARG,
	       X_OPAQUE_FRAME_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-CREATE-TERM", Prim_x_create_term, 12, 12, 0)
{
  Pointer result, *scan;
  int cwidth, cheight;
  PRIMITIVE_HEADER (12);

  result = (allocate_marked_vector (TC_VECTOR, 3, true));
  scan = (Nth_Vector_Loc (result, 1));
  (*scan++) =
    (XWINDOW_VALUE (XCreateTerm ((STRING_ARG (1)), (STRING_ARG (2)),
				 (STRING_ARG (3)), (STRING_ARG (4)),
				 (X_OPAQUE_FRAME_ARG (5)),
				 (FIXNUM_ARG (6)), (FIXNUM_ARG (7)),
				 (FIXNUM_ARG (8)), (FIXNUM_ARG (9)),
				 (& cwidth), (& cheight),
				 (X_FONT_INFO_ARG (10)),
				 (FIXNUM_ARG (11)), (FIXNUM_ARG (12)))));
  (*scan++) = (MAKE_UNSIGNED_FIXNUM (cwidth));
  (*scan) = (MAKE_UNSIGNED_FIXNUM (cheight));
  PRIMITIVE_RETURN (result);
}

#define CREATION_DEFS_ARG(Xtype, arg)					\
{									\
  Pointer def_vector;							\
  fast Pointer *scan_arg;						\
  fast Xtype *scan_defs;						\
  fast int i;								\
									\
  CHECK_ARG (arg, VECTOR_P);						\
  def_vector = (ARG_REF (arg));						\
  ndefs = (Vector_Length (def_vector));					\
  if (ndefs == 0)							\
    PRIMITIVE_RETURN (FIXNUM_ZERO);					\
									\
  Primitive_GC_If_Needed (BYTES_TO_POINTERS ((sizeof (Xtype)) * ndefs)); \
  defs = ((Xtype *) Free);						\
									\
  scan_arg = (Nth_Vector_Loc (def_vector, 1));				\
  scan_defs = defs;							\
  i = ndefs;								\
  while ((i--) > 0)							\
    {									\
      if (! (XSTRUCT_P (Xtype, (*scan_arg))))				\
	error_bad_range_arg (arg);					\
      (*scan_defs++) = (* (XSTRUCT_DESCRIPTOR (Xtype, (*scan_arg++))));	\
    }									\
}

#define WINDOW_CREATOR(Xtype, Xproc)					\
  Xtype *defs;								\
  int ndefs;								\
  PRIMITIVE_HEADER (2);							\
									\
  CREATION_DEFS_ARG (Xtype, 2);						\
  PRIMITIVE_RETURN (long_to_object (Xproc ((XWINDOW_ARG (1)), defs, ndefs)))

DEFINE_PRIMITIVE ("X-CREATE-WINDOWS", Prim_x_create_windows, 2, 2, 0)
{ WINDOW_CREATOR (OpaqueFrame, XCreateWindows); }

DEFINE_PRIMITIVE ("X-CREATE-TRANSPARENCIES", Prim_x_create_transparencies, 2, 2, 0)
{ WINDOW_CREATOR (TransparentFrame, XCreateTransparencies); }

DEFINE_PRIMITIVE ("X-CREATE-WINDOW-BATCH", Prim_x_create_window_batch, 1, 1, 0)
{
  BatchFrame *defs;
  int ndefs;
  PRIMITIVE_HEADER (1);

  CREATION_DEFS_ARG (BatchFrame, 1);
  PRIMITIVE_RETURN (long_to_object (XCreateWindowBatch (defs, ndefs)));
}

/* Section 2.7: Manipulating Windows */

DEFINE_PRIMITIVE ("X-MAP-WINDOW", Prim_x_map_window, 1, 1, 0)
{ OPERATION_1 (XMapWindow, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-MAP-SUBWINDOWS", Prim_x_map_subwindows, 1, 1, 0)
{ OPERATION_1 (XMapSubwindows, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-UNMAP-WINDOW", Prim_x_unmap_window, 1, 1, 0)
{ OPERATION_1 (XUnmapWindow, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-UNMAP-TRANSPARENT", Prim_x_unmap_transparent, 1, 1, 0)
{ OPERATION_1 (XUnmapTransparent, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-UNMAP-SUBWINDOWS", Prim_x_unmap_subwindows, 1, 1, 0)
{ OPERATION_1 (XUnmapSubwindows, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-MOVE-WINDOW", Prim_x_move_window, 3, 3, 0)
{ OPERATION_3 (XMoveWindow, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-CHANGE-WINDOW", Prim_x_change_window, 3, 3, 0)
{ OPERATION_3 (XChangeWindow, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-CONFIGURE-WINDOW", Prim_x_configure_window, 5, 5, 0)
{ OPERATION_5 (XConfigureWindow, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-RAISE-WINDOW", Prim_x_raise_window, 1, 1, 0)
{ OPERATION_1 (XRaiseWindow, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-LOWER-WINDOW", Prim_x_lower_window, 1, 1, 0)
{ OPERATION_1 (XLowerWindow, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-CIRCLE-WINDOW-UP", Prim_x_circle_window_up, 1, 1, 0)
{ OPERATION_1 (XCircWindowUp, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-CIRCLE-WINDOW-DOWN", Prim_x_circle_window_down, 1, 1, 0)
{ OPERATION_1 (XCircWindowDown, VOID_VALUE, XWINDOW_ARG); }

/* Section 2.8: Status and Mode Window Operations */

DEFINE_PRIMITIVE ("X-QUERY-WINDOW", Prim_x_query_window, 1, 1, 0)
{
  fast Pointer result;
  PRIMITIVE_HEADER (1);

  result = (X_WINDOW_INFO_ALLOCATE (true));
  XSTATUS (XQueryWindow ((XWINDOW_ARG (1)),
			 (X_WINDOW_INFO_DESCRIPTOR (result))));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-QUERY-TREE", Prim_x_query_tree, 1, 1, 0)
{
  Window parent, *children;
  int nchildren;
  Pointer result;
  fast Window *scan_children;
  fast Pointer *scan_vector;
  PRIMITIVE_HEADER (1);

  XSTATUS (XQueryTree ((XWINDOW_ARG (1)),
		       (& parent),
		       (& nchildren),
		       (& children)));
  result = (allocate_marked_vector (TC_VECTOR, (nchildren + 1), true));
  scan_vector = (Nth_Vector_Loc (result, 1));
  (*scan_vector++) = (FAST_XWINDOW_VALUE (parent));
  if (nchildren > 0)
    {
      scan_children = children;
      while ((nchildren--) > 0)
	(*scan_vector++)= (FAST_XWINDOW_VALUE (*scan_children++));
      /* if (nchildren == 0), don't need to do this? */
      free (children);
    }
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-CHANGE-BACKGROUND", Prim_x_change_background, 2, 2, 0)
{ OPERATION_2 (XChangeBackground, VOID_VALUE, XWINDOW_ARG, XPIXMAP_ARG); }

DEFINE_PRIMITIVE ("X-CHANGE-BORDER", Prim_x_change_border, 2, 2, 0)
{ OPERATION_2 (XChangeBorder, VOID_VALUE, XWINDOW_ARG, XPIXMAP_ARG); }

DEFINE_PRIMITIVE ("X-TILE-ABSOLUTE", Prim_x_tile_absolute, 1, 1, 0)
{ OPERATION_1 (XTileAbsolute, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-TILE-RELATIVE", Prim_x_tile_relative, 1, 1, 0)
{ OPERATION_1 (XTileRelative, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-CLIP-DRAW-THROUGH", Prim_x_clip_draw_through, 1, 1, 0)
{ OPERATION_1 (XClipDrawThrough, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-CLIP-CLIPPED", Prim_x_clip_clipped, 1, 1, 0)
{ OPERATION_1 (XClipClipped, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-STORE-NAME", Prim_x_store_name, 2, 2, 0)
{ OPERATION_2 (XStoreName, VOID_VALUE, XWINDOW_ARG, STRING_ARG); }

DEFINE_PRIMITIVE ("X-FETCH-NAME", Prim_x_fetch_name, 1, 1, 0)
{
  char *name;
  Pointer result;
  PRIMITIVE_HEADER (1);

  XSTATUS (XFetchName ((XWINDOW_ARG (1)), (& name)));
  if (name == NULL)
    PRIMITIVE_RETURN (SHARP_F);
  UNWIND_PROTECT (result = (STRING_VALUE (name)), free (name));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-SET-RESIZE-HINT", Prim_x_set_resize_hint, 5, 5, 0)
{ OPERATION_5 (XSetResizeHint, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-GET-RESIZE-HINT", Prim_x_get_resize_hint, 1, 1, 0)
{
  int width0, height0, widthinc, heightinc;
  Pointer result, *scan;
  PRIMITIVE_HEADER (1);

  XGetResizeHint ((XWINDOW_ARG (1)),
		  (& width0),
		  (& height0),
		  (& widthinc),
		  (& heightinc));
  result = (allocate_marked_vector (TC_VECTOR, 4, true));
  scan = (Nth_Vector_Loc (result, 1));
  (*scan++) = (long_to_object (width0));
  (*scan++) = (long_to_object (height0));
  (*scan++) = (long_to_object (widthinc));
  (*scan) = (long_to_object (heightinc));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-SET-ICON-WINDOW", Prim_x_set_icon_window, 2, 2, 0)
{ OPERATION_2 (XSetIconWindow, VOID_VALUE, XWINDOW_ARG, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-CLEAR-ICON-WINDOW", Prim_x_clear_icon_window, 1, 1, 0)
{ OPERATION_1 (XClearIconWindow, VOID_VALUE, XWINDOW_ARG); }

#define MOUSE_QUERY(arity, expression)					\
  int x, y;								\
  Window subw;								\
  Pointer result, *scan;						\
  PRIMITIVE_HEADER (arity);						\
									\
  XSTATUS (expression);							\
  result = (allocate_marked_vector (TC_VECTOR, 3, true));		\
  scan = (Nth_Vector_Loc (result, 1));					\
  (*scan++) = (long_to_object (x));					\
  (*scan++) = (long_to_object (y));					\
  (*scan) = (XWINDOW_VALUE (subw));					\
  PRIMITIVE_RETURN (result)

DEFINE_PRIMITIVE ("X-QUERY-MOUSE", Prim_x_query_mouse, 1, 1, 0)
{ MOUSE_QUERY (1, (XQueryMouse ((XWINDOW_ARG (1)), (& x), (& y), (& subw)))); }

DEFINE_PRIMITIVE ("X-QUERY-MOUSE-BUTTONS", Prim_x_query_mouse_buttons, 1, 1, 0)
{
  int x, y;
  Window subw;
  short state;
  Pointer result, *scan;
  PRIMITIVE_HEADER (1);

  XSTATUS (XQueryMouseButtons ((XWINDOW_ARG (1)),
			       (& x), (& y), (& subw), (& state)));
  result = (allocate_marked_vector (TC_VECTOR, 4, true));
  scan = (Nth_Vector_Loc (result, 1));
  (*scan++) = (long_to_object (x));
  (*scan++) = (long_to_object (y));
  (*scan++) = (XWINDOW_VALUE (subw));
  (*scan) = (MAKE_UNSIGNED_FIXNUM (state));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-UPDATE-MOUSE", Prim_x_update_mouse, 1, 1, 0)
{ MOUSE_QUERY (1, (XUpdateMouse ((XWINDOW_ARG (1)), (& x), (& y), (& subw)))); }

DEFINE_PRIMITIVE ("X-WARP-MOUSE", Prim_x_warp_mouse, 3, 3, 0)
{ OPERATION_3 (XWarpMouse, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-COND-WARP-MOUSE", Prim_x_cond_warp_mouse, 8, 8, 0)
{ OPERATION_8 (XCondWarpMouse, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG, XWINDOW_ARG, FIXNUM_ARG,
	       FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-INTERPRET-LOCATOR", Prim_x_interpret_locator, 2, 2, 0)
{ MOUSE_QUERY (2, (XInterpretLocator ((XWINDOW_ARG (1)), (& x), (& y),
				      (& subw), (XLOCATOR_ARG (2))))); }

/* Section 2.9.3 */

DEFINE_PRIMITIVE ("X-CLEAR", Prim_x_clear, 1, 1, 0)
{ OPERATION_1 (XClear, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-PIX-SET", Prim_x_pix_set, 6, 6, 0)
{ OPERATION_6 (XPixSet, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-PIX-FILL", Prim_x_pix_fill, 9, 9, 0)
{ OPERATION_9 (XPixFill, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG,
	       XBITMAP_ARG, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-PIXMAP-PUT", Prim_x_pixmap_put, 10, 10, 0)
{ OPERATION_10 (XPixmapPut, VOID_VALUE,
		XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG,
		UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG,
		XPIXMAP_VALUE, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-QUERY-TILE-SHAPE", Prim_x_query_tile_shape, 2, 2, 0)
{
  int rwidth, rheight;
  PRIMITIVE_HEADER (2);

  XQueryTileShape ((UNSIGNED_FIXNUM_ARG (1)), (UNSIGNED_FIXNUM_ARG (2)),
		   (& rwidth), (& rheight));
  PRIMITIVE_RETURN (pair_cons ((MAKE_UNSIGNED_FIXNUM (rwidth)),
			       (MAKE_UNSIGNED_FIXNUM (rheight)),
			       true));
}

DEFINE_PRIMITIVE ("X-TILE-SET", Prim_x_tile_set, 6, 6, 0)
{ OPERATION_6 (XTileSet, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG, XPIXMAP_ARG); }

DEFINE_PRIMITIVE ("X-TILE-FILL", Prim_x_tile_fill, 9, 9, 0)
{ OPERATION_9 (XTileFill, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG, XPIXMAP_ARG,
	       XBITMAP_ARG, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-STIPPLE-FILL", Prim_x_stipple_fill, 9, 9, 0)
{ OPERATION_9 (XStippleFill, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG,
	       XBITMAP_ARG, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-MOVE-AREA", Prim_x_move_area, 7, 7, 0)
{ OPERATION_7 (XMoveArea, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-COPY-AREA", Prim_x_copy_area, 9, 9, 0)
{ OPERATION_9 (XCopyArea, VOID_VALUE,
	       XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

/* Section 2.9.4 */

#define MAP_PUT(size_macro, c_name)					\
  fast int width, height;						\
  PRIMITIVE_HEADER (9);							\
									\
  width = (UNSIGNED_FIXNUM_ARG (4));					\
  height = (UNSIGNED_FIXNUM_ARG (5));					\
  c_name ((XWINDOW_ARG (1)),						\
	  (FIXNUM_ARG (2)),						\
	  (FIXNUM_ARG (3)),						\
	  width,							\
	  height,							\
	  (XMAP_DATA_ARG ((size_macro (width, height)), 6)),		\
	  (XBITMAP_ARG (7)),						\
	  (UNSIGNED_FIXNUM_ARG (8)),					\
	  (UNSIGNED_FIXNUM_ARG (9)));					\
  PRIMITIVE_RETURN (SHARP_F)

DEFINE_PRIMITIVE ("X-PIXMAP-BITS-PUT-XY", Prim_x_pixmap_bits_put_xy, 9, 9, 0)
{ MAP_PUT (XY_PixmapSize, XPixmapBitsPutXY); }

DEFINE_PRIMITIVE ("X-PIXMAP-BITS-PUT-Z", Prim_x_pixmap_bits_put_z, 9, 9, 0)
{ MAP_PUT (Z_PixmapSize, XPixmapBitsPutZ); }

#undef MAP_PUT

DEFINE_PRIMITIVE ("X-BITMAP-BITS-PUT", Prim_x_bitmap_bits_put, 11, 11, 0)
{
  fast int width, height;
  PRIMITIVE_HEADER (9);

  width = (UNSIGNED_FIXNUM_ARG (4));
  height = (UNSIGNED_FIXNUM_ARG (5));
  XBitmapBitsPut ((XWINDOW_ARG (1)),
		  (FIXNUM_ARG (2)),
		  (FIXNUM_ARG (3)),
		  width,
		  height,
		  (UNSIGNED_FIXNUM_ARG (6)),
		  (UNSIGNED_FIXNUM_ARG (7)),
		  (XMAP_DATA_ARG ((BitmapSize (width, height)), 8)),
		  (XBITMAP_ARG (9)),
		  (UNSIGNED_FIXNUM_ARG (10)),
		  (UNSIGNED_FIXNUM_ARG (11)));
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("X-PIXMAP-SAVE", Prim_x_pixmap_save, 5, 5, 0)
{ OPERATION_5 (XPixmapSave, XPIXMAP_VALUE, XWINDOW_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

#define MAP_GET(size_macro, c_name)					\
  fast int width, height;						\
  fast Pointer result;							\
  PRIMITIVE_HEADER (5);							\
									\
  width = (UNSIGNED_FIXNUM_ARG (4));					\
  height = (UNSIGNED_FIXNUM_ARG (5));					\
  result = (XMAP_DATA_ALLOCATE ((size_macro (width, height)), true));	\
  c_name ((XWINDOW_ARG (1)),						\
	  (FIXNUM_ARG (2)),						\
	  (FIXNUM_ARG (3)),						\
	  width,							\
	  height,							\
	  (XMAP_DATA_DESCRIPTOR (result)));				\
  PRIMITIVE_RETURN (result)

DEFINE_PRIMITIVE ("X-PIXMAP-GET-XY", Prim_x_pixmap_get_xy, 5, 5, 0)
{ MAP_GET (XY_PixmapSize, XPixmapGetXY); }

DEFINE_PRIMITIVE ("X-PIXMAP-GET-Z", Prim_x_pixmap_get_z, 5, 5, 0)
{ MAP_GET (Z_PixmapSize, XPixmapGetZ); }

#undef MAP_GET

/* Section 2.9.5 */

#define MAP_STORE(size_macro, c_name, value)				\
  fast int width, height;						\
  PRIMITIVE_HEADER (3);							\
									\
  RESOURCE_GC_CHECK ();							\
  width = (UNSIGNED_FIXNUM_ARG (1));					\
  height = (UNSIGNED_FIXNUM_ARG (2));					\
  PRIMITIVE_RETURN							\
  (value (c_name (width,						\
		  height,						\
		  (XMAP_DATA_ARG ((size_macro (width, height)), 3)))))

DEFINE_PRIMITIVE ("X-STORE-PIXMAP-XY", Prim_x_store_pixmap_xy, 3, 3, 0)
{ MAP_STORE (XY_PixmapSize, XStorePixmapXY, XPIXMAP_VALUE); }

DEFINE_PRIMITIVE ("X-STORE-PIXMAP-Z", Prim_x_store_pixmap_z, 3, 3, 0)
{ MAP_STORE (Z_PixmapSize, XStorePixmapZ, XPIXMAP_VALUE); }

DEFINE_PRIMITIVE ("X-STORE-BITMAP", Prim_x_store_bitmap, 3, 3, 0)
{ MAP_STORE (BitmapSize, XStoreBitmap, XBITMAP_VALUE); }

#undef MAP_STORE

DEFINE_PRIMITIVE ("X-MAKE-PIXMAP", Prim_x_make_pixmap, 3, 3, 0)
{ OPERATION_3 (XMakePixmap, XPIXMAP_VALUE,
	       XBITMAP_ARG, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-MAKE-TILE", Prim_x_make_tile, 1, 1, 0)
{ OPERATION_1 (XMakeTile, XPIXMAP_VALUE, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-FREE-PIXMAP", Prim_x_free_pixmap, 1, 1, 0)
{ OPERATION_1 (XFreePixmap, VOID_VALUE, XPIXMAP_ARG); }

DEFINE_PRIMITIVE ("X-FREE-BITMAP", Prim_x_free_bitmap, 1, 1, 0)
{ OPERATION_1 (XFreeBitmap, VOID_VALUE, XBITMAP_ARG); }

DEFINE_PRIMITIVE ("X-CHAR-BITMAP", Prim_x_char_bitmap, 2, 2, 0)
{ OPERATION_2 (XCharBitmap, XBITMAP_VALUE, XFONT_ARG, UNSIGNED_FIXNUM_ARG); }

/* Section 2.10 */

DEFINE_PRIMITIVE ("X-STORE-CURSOR", Prim_x_store_cursor, 7, 7, 0)
{ OPERATION_7 (XStoreCursor, XCURSOR_VALUE,
	       XBITMAP_ARG, XBITMAP_ARG, FIXNUM_ARG, FIXNUM_ARG,
	       UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-QUERY-CURSOR-SHAPE", Prim_x_query_cursor_shape, 2, 2, 0)
{
  int rwidth, rheight;
  PRIMITIVE_HEADER (2);

  XQueryCursorShape ((UNSIGNED_FIXNUM_ARG (1)), (UNSIGNED_FIXNUM_ARG (2)),
		     (& rwidth), (& rheight));
  PRIMITIVE_RETURN (pair_cons ((MAKE_UNSIGNED_FIXNUM (rwidth)),
			       (MAKE_UNSIGNED_FIXNUM (rheight)),
			       true));
}

DEFINE_PRIMITIVE ("X-FREE-CURSOR", Prim_x_free_cursor, 1, 1, 0)
{ OPERATION_1 (XFreeCursor, VOID_VALUE, XCURSOR_ARG); }

DEFINE_PRIMITIVE ("X-CREATE-CURSOR", Prim_x_create_cursor, 9, 9, 0)
{
  fast int width, height, length;
  PRIMITIVE_HEADER (9);

  RESOURCE_GC_CHECK ();
  width = (UNSIGNED_FIXNUM_ARG (1));
  height = (UNSIGNED_FIXNUM_ARG (2));
  length = (BitmapSize (width, height));
  PRIMITIVE_RETURN (XCURSOR_VALUE (XCreateCursor (width, height,
						  (XMAP_DATA_ARG (length, 3)),
						  (XMAP_DATA_ARG (length, 4)),
						  (FIXNUM_ARG (5)),
						  (FIXNUM_ARG (6)),
						  (UNSIGNED_FIXNUM_ARG (7)),
						  (UNSIGNED_FIXNUM_ARG (8)),
						  (UNSIGNED_FIXNUM_ARG (9)))));
}

DEFINE_PRIMITIVE ("X-DEFINE-CURSOR", Prim_x_define_cursor, 2, 2, 0)
{ OPERATION_2 (XDefineCursor, VOID_VALUE, XWINDOW_ARG, XCURSOR_ARG); }

DEFINE_PRIMITIVE ("X-UNDEFINE-CURSOR", Prim_x_undefine_cursor, 1, 1, 0)
{ OPERATION_1 (XUndefineCursor, VOID_VALUE, XWINDOW_ARG); }

/* Section 2.11: Color Map Manipulation */

DEFINE_PRIMITIVE ("X-GET-HARDWARE-COLOR", Prim_x_get_hardware_color, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);
  
  XSTATUS (XGetHardwareColor ((X_COLOR_ARG (1))));
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("X-PARSE-COLOR", Prim_x_parse_color, 1, 1, 0)
{
  Pointer result;
  PRIMITIVE_HEADER (1);

  result = (X_COLOR_ALLOCATE (true));
  XSTATUS (XParseColor ((STRING_ARG (1)), (X_COLOR_DESCRIPTOR (result))));
  PRIMITIVE_RETURN (result);
}
 


/* Section 2.12: Fonts and Information About Fonts */

/* DEFINE_PRIMITIVE ("X-OPEN-FONT", Prim_X_open_font, 1) */
/* DEFINE_PRIMITIVE ("X-CLOSE-FONT", Prim_X_close_font, 1) */

DEFINE_PRIMITIVE ("X-GET-FONT", Prim_x_get_font, 1, 1, 0)
{ OPERATION_1 (XGetFont, XFONT_VALUE, STRING_ARG); }

DEFINE_PRIMITIVE ("X-QUERY-FONT", Prim_x_query_font, 1, 1, 0)
{
  Pointer result;
  PRIMITIVE_HEADER (1);

  result = (X_FONT_INFO_ALLOCATE (true));
  XSTATUS (XQueryFont ((XFONT_ARG (1)), (X_FONT_INFO_DESCRIPTOR (result))));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-FREE-FONT", Prim_x_free_font, 1, 1, 0)
{ OPERATION_1 (XFreeFont, VOID_VALUE, XFONT_ARG); }

/* Section 2.13 */

DEFINE_PRIMITIVE ("X-TEXT", Prim_x_text, 7, 7, 0)
{
  fast Pointer string;
  PRIMITIVE_HEADER (7);

  string = (ARG_REF (4));
  XText ((XWINDOW_ARG (1)),
	 (UNSIGNED_FIXNUM_ARG (2)),
	 (UNSIGNED_FIXNUM_ARG (3)),
	 (string_pointer (string, 0)),
	 (string_length (string)),
	 (XFONT_ARG (5)),
	 (UNSIGNED_FIXNUM_ARG (6)),
	 (UNSIGNED_FIXNUM_ARG (7)));
  PRIMITIVE_RETURN (SHARP_F);
}

/* DEFINE_PRIMITIVE ("X-TEXT-PAD", Prim_X_text_pad, 12) */
/* DEFINE_PRIMITIVE ("X-TEXT-MASK", Prim_X_text_mask, 7) */
/* DEFINE_PRIMITIVE ("X-TEXT-MASK-PAD", Prim_X_text_mask_pad, 11) */

/* Section 2.14.2 */

DEFINE_PRIMITIVE ("X-MOUSE-CONTROL", Prim_x_mouse_control, 2, 2, 0)
{ OPERATION_2 (XMouseControl, VOID_VALUE, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-FEEP-CONTROL", Prim_x_feep_control, 1, 1, 0)
{ OPERATION_1 (XFeepControl, VOID_VALUE, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-FEEP", Prim_x_feep, 1, 1, 0)
{ OPERATION_1 (XFeep, VOID_VALUE, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-KEY-CLICK-CONTROL", Prim_x_key_click_control, 1, 1, 0)
{ OPERATION_1 (XKeyClickControl, VOID_VALUE, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-AUTO-REPEAT-ON", Prim_x_auto_repeat_on, 0, 0, 0)
{ OPERATION_0 (XAutoRepeatOn, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-AUTO-REPEAT-OFF", Prim_x_auto_repeat_off, 0, 0, 0)
{ OPERATION_0 (XAutoRepeatOff, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-LOCK-UP/DOWN", Prim_x_lock_up_down, 0, 0, 0)
{ OPERATION_0 (XLockUpDown, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-LOCK-TOGGLE", Prim_x_lock_toggle, 0, 0, 0)
{ OPERATION_0 (XLockToggle, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-SCREEN-SAVER", Prim_x_screen_saver, 3, 3, 0)
{ OPERATION_3 (XScreenSaver, VOID_VALUE, FIXNUM_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-GET-DEFAULT", Prim_x_get_default, 2, 2, 0)
{ OPERATION_2 (XGetDefault, STRING_VALUE, STRING_ARG, STRING_ARG); }

#define GEOMETRY_CALL(n_args, expression)				\
  int x, y, width, height;						\
  fast int mask;							\
  fast Pointer result, *scan_result;					\
  PRIMITIVE_HEADER (n_args);						\
									\
  mask = (expression);							\
  result = (allocate_marked_vector (TC_VECTOR, 6, true));		\
  scan_result = (Nth_Vector_Loc (result, 1));				\
  (*scan_result++) =							\
    (((XValue & mask) == 0) ? SHARP_F : (MAKE_FIXNUM (x)));		\
  (*scan_result++) =							\
    (BOOLEAN_TO_OBJECT ((XNegative & mask) != 0));			\
  (*scan_result++) =							\
    (((YValue & mask) == 0) ? SHARP_F : (MAKE_FIXNUM (y)));		\
  (*scan_result++) =							\
    (BOOLEAN_TO_OBJECT ((YNegative & mask) != 0));			\
  (*scan_result++) =							\
    (((WidthValue & mask) == 0)						\
     ? SHARP_F								\
     : (MAKE_UNSIGNED_FIXNUM (width)));					\
  (*scan_result) =							\
    (((HeightValue & mask) == 0)					\
     ? SHARP_F								\
     : (MAKE_FIXNUM (height)));						\
  PRIMITIVE_RETURN (result)

DEFINE_PRIMITIVE ("X-PARSE-GEOMETRY", Prim_x_parse_geometry, 1, 1, 0)
{ GEOMETRY_CALL (1,
		 (XParseGeometry ((STRING_ARG (1)),
				  (& x), (& y), (& width), (& height)))); }

DEFINE_PRIMITIVE ("X-GEOMETRY", Prim_x_geometry, 7, 7, 0)
{ GEOMETRY_CALL (7,
		 (XGeometry ((STRING_ARG (1)),
			     (STRING_ARG (2)),
			     (UNSIGNED_FIXNUM_ARG (3)),
			     (UNSIGNED_FIXNUM_ARG (4)),
			     (UNSIGNED_FIXNUM_ARG (5)),
			     (UNSIGNED_FIXNUM_ARG (6)),
			     (UNSIGNED_FIXNUM_ARG (7)),
			     (& x), (& y), (& width), (& height)))); }

#undef GEOMETRY_CALL

DEFINE_PRIMITIVE ("X-READ-BITMAP-FILE", Prim_x_read_bitmap_file, 1, 1, 0)
{
  int width, height, x_hot, y_hot;
  short *data;
  Pointer map_data, result;
  PRIMITIVE_HEADER (1);

  XSTATUS (XReadBitmapFile ((STRING_ARG (1)),
			    (& width),
			    (& height),
			    (& data),
			    (& x_hot),
			    (& y_hot)));
  {
    fast int length;
    fast char *scan_data, *scan_map_data;

    length = (BitmapSize (width, height));
    map_data = (XMAP_DATA_ALLOCATE (length, true));
    scan_data = ((char *) data);
    scan_map_data = ((char *) (XMAP_DATA_DESCRIPTOR (map_data)));
    while ((length--) > 0)
      (*scan_map_data++) = (*scan_data++);
  }
  result = (allocate_marked_vector (TC_VECTOR, 5, true));
  {
    fast Pointer *scan_result;

    scan_result = (Nth_Vector_Loc (result, 1));
    (*scan_result++) = (MAKE_UNSIGNED_FIXNUM (width));
    (*scan_result++) = (MAKE_UNSIGNED_FIXNUM (height));
    (*scan_result++) = map_data;
    (*scan_result++) = (MAKE_FIXNUM (x_hot));
    (*scan_result) = (MAKE_FIXNUM (y_hot));
  }
  PRIMITIVE_RETURN (result);
}

/* Section 2.14.3 */

/* DEFINE_PRIMITIVE ("X-STORE-BYTES", Prim_X_store_bytes, 1) */
/* DEFINE_PRIMITIVE ("X-FETCH-BYTES", Prim_X_fetch_bytes, 0) */
/* DEFINE_PRIMITIVE ("X-ROTATE-BUFFERS", Prim_X_rotate_buffers, 1) */
/* DEFINE_PRIMITIVE ("X-STORE-BUFFER", Prim_X_store_buffer, 2) */
/* DEFINE_PRIMITIVE ("X-APPEND-BUFFER", Prim_X_append_buffer, 2) */
/* DEFINE_PRIMITIVE ("X-FETCH-BUFFER", Prim_X_fetch_buffer, 1) */

/* Section 2.15: Input Event Handling */

DEFINE_PRIMITIVE ("X-COMPRESS-EVENTS", Prim_x_compress_events, 0, 0, 0)
{ OPERATION_0 (XCompressEvents, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-EXPAND-EVENTS", Prim_x_expand_events, 0, 0, 0)
{ OPERATION_0 (XExpandEvents, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-SELECT-INPUT", Prim_x_select_input, 2, 2, 0)
{ OPERATION_2 (XSelectInput, VOID_VALUE, XWINDOW_ARG, UNSIGNED_FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-QUERY-INPUT", Prim_x_query_input, 1, 1, 0)
{
  int mask;
  PRIMITIVE_HEADER (1);

  RESOURCE_GC_CHECK ();
  XQueryInput ((XWINDOW_ARG (1)), (& mask));
  PRIMITIVE_RETURN (long_to_object (mask));
}

DEFINE_PRIMITIVE ("X-FLUSH", Prim_x_flush, 0, 0, 0)
{ OPERATION_0 (XFlush, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-SYNC", Prim_x_sync, 1, 1, 0)
{ OPERATION_1 (XSync, VOID_VALUE, BOOLEAN_ARG); }

DEFINE_PRIMITIVE ("X-PENDING", Prim_x_pending, 0, 0, 0)
{ OPERATION_0 (XPending, long_to_object); }

DEFINE_PRIMITIVE ("X-NEXT-EVENT", Prim_x_next_event, 0, 0, 0)
{
  Pointer result;
  PRIMITIVE_HEADER (0);

  result = (XEVENT_ALLOCATE (true));
  XNextEvent (XEVENT_DESCRIPTOR (result));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-PUT-BACK-EVENT", Prim_x_put_back_event, 1, 1, 0)
{ OPERATION_1 (XPutBackEvent, VOID_VALUE, XEVENT_ARG); }

DEFINE_PRIMITIVE ("X-PEEK-EVENT", Prim_x_peek_event, 0, 0, 0)
{
  Pointer result;
  PRIMITIVE_HEADER (0);

  result = (XEVENT_ALLOCATE (true));
  XPeekEvent (XEVENT_DESCRIPTOR (result));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-WINDOW-EVENT", Prim_x_window_event, 2, 2, 0)
{
  Pointer result;
  PRIMITIVE_HEADER (2);

  result = (XEVENT_ALLOCATE (true));
  XWindowEvent ((XWINDOW_ARG (1)),
		(FIXNUM_ARG (2)),
		(XEVENT_DESCRIPTOR (result)));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-MASK-EVENT", Prim_x_mask_event, 1, 1, 0)
{
  Pointer result;
  PRIMITIVE_HEADER (1);

  result = (XEVENT_ALLOCATE (true));
  XMaskEvent ((FIXNUM_ARG (1)), (XEVENT_DESCRIPTOR (result)));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-CHECK-WINDOW-EVENT", Prim_x_check_window_event, 2, 2, 0)
{
  XEvent rep;
  Pointer result;
  PRIMITIVE_HEADER (2);

  if ((XCheckWindowEvent ((XWINDOW_ARG (1)), (FIXNUM_ARG (2)), (& rep))) == 0)
    PRIMITIVE_RETURN (SHARP_F);
  result = (XEVENT_ALLOCATE (true));
  (* (XEVENT_DESCRIPTOR (result))) = rep;
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-CHECK-MASK-EVENT", Prim_x_check_mask_event, 1, 1, 0)
{
  XEvent rep;
  Pointer result;
  PRIMITIVE_HEADER (1);

  if ((XCheckMaskEvent ((XWINDOW_ARG (1)), (& rep))) == 0)
    PRIMITIVE_RETURN (SHARP_F);
  result = (XEVENT_ALLOCATE (true));
  (* (XEVENT_DESCRIPTOR (result))) = rep;
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-GRAB-MOUSE", Prim_x_grab_mouse, 3, 3, 0)
{ OPERATION_3 (XGrabMouse, BOOLEAN_VALUE,
	       XWINDOW_ARG, XCURSOR_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-UNGRAB-MOUSE", Prim_x_ungrab_mouse, 0, 0, 0)
{ OPERATION_0 (XUngrabMouse, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-GRAB-BUTTON", Prim_x_grab_button, 4, 4, 0)
{ OPERATION_4 (XGrabButton, BOOLEAN_VALUE,
	       XWINDOW_ARG, XCURSOR_ARG, FIXNUM_ARG, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-UNGRAB-BUTTON", Prim_x_ungrab_button, 1, 1, 0)
{ OPERATION_1 (XUngrabButton, VOID_VALUE, FIXNUM_ARG); }

DEFINE_PRIMITIVE ("X-GRAB-SERVER", Prim_x_grab_server, 0, 0, 0)
{ OPERATION_0 (XGrabServer, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-UNGRAB-SERVER", Prim_x_ungrab_server, 0, 0, 0)
{ OPERATION_0 (XUngrabServer, VOID_VALUE); }

DEFINE_PRIMITIVE ("X-FOCUS-KEYBOARD", Prim_x_focus_keyboard, 1, 1, 0)
{ OPERATION_1 (XFocusKeyboard, VOID_VALUE, XWINDOW_ARG); }

DEFINE_PRIMITIVE ("X-LOOKUP-MAPPING", Prim_x_lookup_mapping, 1, 1, 0)
{
  char *XLookupMapping ();
  char *mapping;
  int nbytes;
  PRIMITIVE_HEADER (1);

  mapping = (XLookupMapping ((XEVENT_ARG (1)), (& nbytes)));
  PRIMITIVE_RETURN (memory_to_string (nbytes, mapping));
}

DEFINE_PRIMITIVE ("X-REBIND-CODE", Prim_x_rebind_code, 3, 3, 0)
{
  Pointer string;
  PRIMITIVE_HEADER (3);

  CHECK_ARG (3, STRING_P);
  string = (ARG_REF (3));
  XRebindCode ((UNSIGNED_FIXNUM_ARG (1)),
	       (UNSIGNED_FIXNUM_ARG (2)),
	       (Scheme_String_To_C_String (string)),
	       (string_length (string)));
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("X-USE-KEYMAP", Prim_x_use_keymap, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  XSTATUS (XUseKeymap (STRING_ARG (1)));
  PRIMITIVE_RETURN (SHARP_F);
}
