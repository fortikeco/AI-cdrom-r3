/* -*-C-*-

$Header: unix.c,v 9.88 89/07/25 08:51:35 GMT cph Rel $

Copyright (c) 1988, 1989 Massachusetts Institute of Technology

This material was developed by the Scheme project at the Massachusetts
Institute of Technology, Department of Electrical Engineering and
Computer Science.  Permission to copy this software, to redistribute
it, and to use it for any purpose is granted, subject to the following
restrictions and understandings.

1. Any copy made of this software must include this copyright notice
in full.

2. Users of this software agree to make their best efforts (a) to
return to the MIT Scheme project any improvements or extensions that
they make, so that these may be included in future releases; and (b)
to inform MIT of noteworthy uses of this software.

3. All materials developed as a consequence of the use of this
software shall duly acknowledge such use, in accordance with the usual
standards of acknowledging credit in academic research.

4. MIT has made no warrantee or representation that the operation of
this software will be error-free, and MIT is under no obligation to
provide any services, by way of maintenance, update, or otherwise.

5. In conjunction with products arising from the use of this material,
there shall be no use of the name of the Massachusetts Institute of
Technology nor of any adaptation thereof in any advertising,
promotional, or sales literature without prior written consent from
MIT in each case. */

/* Contains operating system (Unix) dependent procedures. */

#include <sys/types.h>
#include <sys/times.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>

#define SYSTEM_NAME "unix"

#if defined(bsd)
#define SYSTEM_VARIANT			"bsd"

#define HAS_DIR
#include <sys/dir.h>
#define HAS_SIGSETMASK
#define HAS_SIGVECTOR
#define SIGVECTOR			sigvec
#define HAS_TIMES
#include <sys/timeb.h>
#define HAS_GETTIMEOFDAY
#define HAS_LOCALTIME
#include <sys/time.h>
#include <sgtty.h>
#define getcwd				getwd
#define HAS_GETCWD
#define HAS_MKDIR
#define HAS_SETPGRP_2
#define setpgrp2			setpgrp
#define HAS_SIGCONTEXT

#ifdef ULTRIX
#define NEW_SIGNALS
#endif

#ifdef sun

#define HAS_VADVISE
#include <sys/vadvise.h>

#endif /* sun */

#ifdef sun3

#define HAS_FULL_SIGCONTEXT
#define PROCESSOR_NREGS			16
#define FULL_SIGCONTEXT_NREGS		15		/* missing sp */

struct full_sigcontext
{
  struct sigcontext * fs_original;
  int fs_regs[FULL_SIGCONTEXT_NREGS];
};

#define RFREE				(8 + 5)		/* A5 */
#define FULL_SIGCONTEXT			full_sigcontext
#define FULL_SIGCONTEXT_SP(scp)		(scp->fs_original->sc_sp)
#define FULL_SIGCONTEXT_PC(scp)		(scp->fs_original->sc_pc)
#define FULL_SIGCONTEXT_RFREE(scp)	(scp->fs_regs[RFREE])
#define FULL_SIGCONTEXT_FIRST_REG(scp)	(&((scp)->fs_regs[0]))

#define DECLARE_FULL_SIGCONTEXT(name)					\
  struct FULL_SIGCONTEXT name[1]

#define INITIALIZE_FULL_SIGCONTEXT(partial, full)			\
{									\
  static void sun3_save_regs();						\
									\
  sun3_save_regs (& (full[0].fs_regs[0]));				\
  full[0].fs_original = (partial);					\
}

#endif /* sun3 */

#ifdef vax

#define HAS_FULL_SIGCONTEXT
#define PROCESSOR_NREGS			16
#define FULL_SIGCONTEXT_NREGS		16

struct full_sigcontext
{
  struct sigcontext * fs_original;
  int fs_regs[FULL_SIGCONTEXT_NREGS];
};

#define RFREE				12		/* fp */
#define FULL_SIGCONTEXT			full_sigcontext
#define FULL_SIGCONTEXT_SP(scp)		(scp->fs_original->sc_sp)
#define FULL_SIGCONTEXT_PC(scp)		(scp->fs_original->sc_pc)
#define FULL_SIGCONTEXT_RFREE(scp)	(scp->fs_regs[RFREE])
#define FULL_SIGCONTEXT_FIRST_REG(scp)	(&((scp)->fs_regs[0]))

#define DECLARE_FULL_SIGCONTEXT(name)					\
  struct FULL_SIGCONTEXT name[1]

/* r0 has to be kludged. */

#define INITIALIZE_FULL_SIGCONTEXT(partial, full)			\
{									\
  static int vax_get_r0 ();						\
  static int * vax_save_start ();					\
  static void vax_save_finish ();					\
									\
  vax_save_finish ((vax_save_start ((& (full[0].fs_regs[0])),		\
				    (vax_get_r0 ()))),			\
		   (partial),						\
		   &(full)[0]);						\
}

#endif /* vax */

#ifdef mips

/* For now, no compiler */
/* If the compiler is ever ported, look at <signal.h> */

#define sc_sp	sc_regs[29]

#endif /* mips */

#else
#if defined(nu)

#define HAS_TIMES
#include <sys/timeb.h>
#define HAS_GETTIMEOFDAY
#define HAS_LOCALTIME
#include <time.h>
#include <sgtty.h>
#define SYSTEM_VARIANT			"nu unix"

#else /* hpux, ATT */

#define HAS_TIMES
#define HAS_LOCALTIME
#include <time.h>
#include <termio.h>
#include <fcntl.h>
#define HAS_SETPGRP_0
#define HAS_GETCWD

#ifdef hpux

#if defined(SIGTSTP)
#include <bsdtty.h>
#endif

/* As of hp-ux 6.5 */
#if defined(SV_BSDSIG)
#define NEW_SIGNALS
#endif

#if !defined(hp9000s800)
#include <sys/mknod.h>
#else /* hp9000s800 */

#include <sys/sysmacros.h>
#define HAS_SETPGRP_2

/* See <machine/save_state.h> included by <signal.h> */

#ifndef sc_pc
/* Is this right? -- It doesn't matter right now. */
#define sc_pc				sc_pcsq_head
#endif

#define ss_gr0				ss_flags	/* not really true */
#define ss_rfree			ss_gr25		/* or some such */
#define HAS_FULL_SIGCONTEXT
#define FULL_SIGCONTEXT_RFREE(scp)	((scp)->sc_sl.sl_ss.ss_rfree)
#define FULL_SIGCONTEXT_FIRST_REG(scp)	(&((scp)->sc_sl.sl_ss.ss_gr0))
#define FULL_SIGCONTEXT_NREGS		32
#define PROCESSOR_NREGS			32

#endif /* hp9000s800 */

#if defined(hp9000s200)

/* It's there, but it does not work! */
#undef FIONREAD

/* WOPR defined nowhere, but seems necessary. */
#define WOPR
#include <sys/types.h>
#include <machine/sendsig.h>
#include <machine/reg.h>

#define HAS_FULL_SIGCONTEXT
#define PROCESSOR_NREGS			16
#define FULL_SIGCONTEXT_NREGS		GPR_REGS		/* Missing sp */

#define RFREE				AR5
#define SIGCONTEXT			full_sigcontext
#define SIGCONTEXT_SP(scp)		((scp)->fs_context.sc_sp)
#define SIGCONTEXT_PC(scp)		((scp)->fs_context.sc_pc)
#define FULL_SIGCONTEXT_RFREE(scp)	((scp)->fs_regs[RFREE])
#define FULL_SIGCONTEXT_FIRST_REG(scp)	(&((scp)->fs_regs[GPR_START]))

#endif /* hp9000s200 */

/* As of HP-UX version 6.0 we must include <sys/param.h> before <ndir.h>.
   This is because some joker decided to conditionally define DEV_BSIZE
   in <ndir.h>. 
 */
#define HAS_GETTIMEOFDAY
#define HAS_DIR
#include <ndir.h>
#define HAS_SIGCONTEXT
#define HAS_SIGSETMASK
#define HAS_SIGVECTOR
#define SIGVECTOR			sigvector
#define SYSTEM_VARIANT			"hpux"

#else /* not hpux */

#define SYSTEM_VARIANT			"ATT (V)"

#endif /* hpux */

#if !defined(VINTR)
#define VINTR	  			0
#define VQUIT	  			1
#define VEOF				4
#define VMIN				4
#define VTIME				5
#endif

#endif /* nu */
#endif /* bsd */

/* Compatibility */

#if defined(NEW_SIGNALS)
#define SIGTYPE				void
#define SIGRETURN()			return
#else
#define SIGTYPE				int
#define SIGRETURN()			return (0)
#endif

#if !defined(HAS_SIGSETMASK)
#define sigsetmask(ignore)		0
#endif

#if !defined(HAS_SIGCONTEXT)
struct sigcontext { long sc_sp, sc_pc; };
#else
#if defined(USE_STACKLETS)
#undef HAS_SIGCONTEXT
#endif
#endif

#if !defined(SIGCONTEXT)
#define SIGCONTEXT			sigcontext
#define SIGCONTEXT_SP(scp)		(scp->sc_sp)
#define SIGCONTEXT_PC(scp)		(scp->sc_pc)
#endif /* SIGCONTEXT */

#if !defined(FULL_SIGCONTEXT)

#define FULL_SIGCONTEXT			SIGCONTEXT
#define FULL_SIGCONTEXT_SP(scp)		SIGCONTEXT_SP(scp)
#define FULL_SIGCONTEXT_PC(scp)		SIGCONTEXT_PC(scp)

#define DECLARE_FULL_SIGCONTEXT(name)					\
  struct FULL_SIGCONTEXT *name

#define INITIALIZE_FULL_SIGCONTEXT(partial, full)			\
{									\
  full = ((struct FULL_SIGCONTEXT *) (partial));			\
}

#endif /* FULL_SIGCONTEXT */

#if !defined(FULL_SIGCONTEXT_NREGS)
#define FULL_SIGCONTEXT_NREGS		0
#define FULL_SIGCONTEXT_FIRST_REG(scp)	((int *) NULL)
#endif

#if !defined(PROCESSOR_NREGS)
#define PROCESSOR_NREGS			0
#endif

extern char *getenv ();
extern char *malloc ();
extern char *tgetstr ();
extern char *tgoto ();
extern long lseek ();
extern int errno;
extern void OS_tty_write_char ();
extern FILE * OS_file_open ();

DECLARE_CRITICAL_SECTION ();

/* OpSys dependent I/O operations. */

#if defined(TCFLSH)			/* hpux, ATT */

#define flush_input_buffer()						\
{									\
  /* Flush buffered input */						\
  (stdin)->_cnt = 0;							\
  /* Flush pending input */						\
  ioctl ((fileno (stdin)), TCFLSH, 0);					\
}

#else /* not TCFLSH */
#if defined(TIOCFLUSH)			/* BSD */

#define flush_input_buffer()						\
{									\
  /* Flush buffered input */						\
  (stdin)->_cnt = 0;							\
  /* Flush pending input */						\
  {									\
    int zero = 0;							\
    ioctl ((fileno (stdin)), TIOCFLUSH, (& zero));			\
  }									\
}

#else /* not TIOCFLUSH */

#include "error: can't define flush_input_buffer()"

#endif /* TIOCFLUSH */
#endif /* TCFLSH */

/* This assumes ASCII */

#define CONTROL_BIT	0100

static void
print_character_name(the_char, long_p)
     unsigned char the_char;
     Boolean long_p;
{
  if (the_char < 040)
  {
    printf("`^%c'", (the_char + CONTROL_BIT));
    if (long_p)
    {
      printf(" (control-%c)", (the_char + CONTROL_BIT));
    }
  }
  else
  {
    printf("`%c'", the_char);
  }
  return;
}

/* Wrappers for system calls */

static int
my_stat (path, buf)
     char * path;
     struct stat * buf;
{
  fast int result;

  while (1)
    {
      result = (stat (path, buf));
      if (result == 0)
	break;
      if (errno != EINTR)
	break;
    }
  return (result);
}

static int
my_read (fd, buffer, nchars)
     int fd;
     char * buffer;
     int nchars;
{
  fast int n_left;
  fast int n_read;
  extern int read ();

  n_left = nchars;
  while (n_left > 0)
    {
      n_read = (read (fd, buffer, nchars));
      if (n_read > 0)
	{
	  n_left -= n_read;
	  buffer += n_read;
	}
      else if (n_read == 0)
	return (nchars - n_left);
      else if (errno != EINTR)
	return (n_read);
    }
  return (nchars);
}

static int
my_write (fd, buffer, nchars)
     int fd;
     char * buffer;
     int nchars;
{
  fast int n_left;
  fast int n_written;
  extern int write ();

  n_left = nchars;
  while (n_left > 0)
    {
      n_written = (write (fd, buffer, n_left));
      if (n_written >= 0)
	{
	  n_left -= n_written;
	  buffer += n_written;
	}
      else if (errno != EINTR)
	return (n_written);
    }
  return (nchars);
}

/* Wrappers for stdio calls */

static FILE *
my_fopen (file_name, type)
     char * file_name;
     char * type;
{
  fast FILE * result;
  extern FILE * fopen ();

  while (1)
    {
      errno = 0;
      result = (fopen (file_name, type));
      if (result != NULL)
	break;
      if (errno != EINTR)
	break;
    }
  return (result);
}

static int
my_fread (ptr, size, nitems, stream)
     char * ptr;
     int size;
     int nitems;
     fast FILE * stream;
{
  fast int n_left;
  fast int n_read;
  extern int fread ();

  n_left = nitems;
  while (n_left > 0)
    {
      n_read = (fread (ptr, size, n_left, stream));
      if (n_read > 0)
	{
	  n_left -= n_read;
	  ptr += (n_read * size);
	}
      if (feof (stream))
	break;
      if (ferror (stream))
	{
	  if (errno != EINTR)
	    break;
	  clearerr (stream);
	}
    }
  return (nitems - n_left);
}

static int
my_fwrite (ptr, size, nitems, stream)
     char * ptr;
     int size;
     int nitems;
     fast FILE * stream;
{
  fast int n_left;
  fast int n_written;
  extern int fwrite ();

  n_left = nitems;
  while (n_left > 0)
    {
      n_written = (fwrite (ptr, size, n_left, stream));
      if (n_written > 0)
	{
	  n_left -= n_written;
	  ptr += (n_written * size);
	}
      if (ferror (stream))
	{
	  if (errno != EINTR)
	    break;
	  clearerr (stream);
	}
    }
  return (nitems - n_left);
}

static int
my_fflush (stream)
     fast FILE * stream;
{
  fast int result;
  extern int fflush ();

  while (1)
    {
      clearerr (stream);
      result = (fflush (stream));
      if (result == 0)
	break;
      if ((ferror (stream)) && (errno != EINTR))
	break;
    }
  return (result);
}

static int
my_fclose (stream)
     fast FILE * stream;
{
  extern int fclose ();

  /* Ignore the result from fflush because on ultrix it returns an
     error when there is no reasonable error condition.  */
  (void) my_fflush (stream);
  return (fclose (stream));
}

/* Binary file I/O Operations */

static FILE * dump_stream;

Boolean
Open_Dump_File (name, output_p)
     Pointer name;
     Boolean output_p;
{
  dump_stream = (OS_file_open ((Scheme_String_To_C_String (name)), output_p));
  return (dump_stream != ((FILE *) 0));
}

Boolean
Close_Dump_File ()
{
  return ((my_fclose (dump_stream)) == 0);
}

long
Load_Data (n_words, buffer)
     long n_words;
     Pointer * buffer;
{
  return (my_fread (buffer, (sizeof (Pointer)), n_words, dump_stream));
}

long
Write_Data (n_words, buffer)
     long n_words;
     Pointer * buffer;
{
  return (my_fwrite (buffer, (sizeof (Pointer)), n_words, dump_stream));
}

/* File I/O Operations */

FILE *
OS_file_open_input (filename)
     char * filename;
{
  struct stat file_status;
  int stat_result;
  int file_type;

  stat_result = (stat (filename, (& file_status)));
  if (stat_result != 0)
    goto cannot_open;
  file_type = ((file_status . st_mode) & S_IFMT);
  if (! ((file_type == S_IFREG)
#if defined(S_IFCHR)
	 || (file_type == S_IFCHR)
#endif
	 ))
    goto cannot_open;
  return (my_fopen (filename, "r"));

 cannot_open:
  return ((FILE *) 0);
}

FILE *
OS_file_open_output (filename)
     char * filename;
{
  struct stat file_status;
  int stat_result;
  int file_type;

#if defined(S_IFLNK)
  stat_result = (lstat (filename, (& file_status)));
#else
  stat_result = (stat (filename, (& file_status)));
#endif
  if (stat_result == 0)
    {
      file_type = ((file_status . st_mode) & S_IFMT);

      /* Delete existing regular file before opening new one.  This
	 prevents writing through hard links.  Do not signal error if
	 the unlink fails, because the fopen might still work. */
      if (file_type == S_IFREG)
	(void) unlink (filename);
#if defined(S_IFCHR)
      /* Character special files are just opened. */
      else if (file_type == S_IFCHR)
	{}
#endif
#if defined(S_IFLNK)
      /* Don't write through soft links. */
      else if (file_type == S_IFLNK)
	{
	  if ((unlink (filename)) != 0)
	    goto cannot_open;
	}
#endif
      else
	goto cannot_open;
    }
  /* If we can't tell if the file exists, just lose. */
  else if ((errno == EACCES) || (errno == EIO))
    goto cannot_open;
  return (my_fopen (filename, "w"));

 cannot_open:
  return ((FILE *) 0);
}

FILE *
OS_file_open (filename, output_p)
     char * filename;
     Boolean output_p;
{
  return (output_p
	  ? (OS_file_open_output (filename))
	  : (OS_file_open_input (filename)));
}

Boolean
OS_file_close (stream)
     FILE * stream;
{
  return ((my_fclose (stream)) == 0);
}

Boolean
OS_file_eof_p (stream)
     FILE * stream;
{
  return (feof (stream));
}

long
OS_file_length (stream)
     fast FILE * stream;
{
  fast long current_position;
  fast long eof_position;
  fast int result;

  current_position = (ftell (stream));
  if (current_position < 0)
    return (current_position);

  result = (fseek (stream, 0L, 2));
  if (result != 0)
    return (-1L);

  eof_position = (ftell (stream));
  if (eof_position < 0)
    {
      (void) fseek (stream, current_position, 0);
      return (eof_position);
    }

  result = (fseek (stream, current_position, 0));
  if (result != 0)
    return (-1L);

  return (eof_position);
}

/* Three-valued; Lisp may need this smartness someday:
     -1   Does not exist.
      0   Don't know.
      1   Exists. */

int
OS_file_existence_test (name)
     char *name;
{
  struct stat file_stat;
  int status;

  if ((my_stat (name, (& file_stat))) == 0)
    return (1);
  status = errno;
  if ((status == EACCES) || (status == EIO))
    return (0);
  return (-1);
}

long
OS_file_read_chars (stream, buffer, nchars)
     FILE * stream;
     char * buffer;
     long nchars;
{
  return (my_fread (buffer, 1, nchars, stream));
}

Boolean
OS_file_write_chars (stream, buffer, nchars)
     FILE * stream;
     char * buffer;
     long nchars;
{
  return ((my_fwrite (buffer, 1, nchars, stream)) == nchars);
}

void
OS_file_flush_output (stream)
     FILE * stream;
{
  (void) my_fflush (stream);
  return;
}

/* file_type_letter

   file_type_letter accepts a file status block and returns a
   character code describing the type of the file.  'd' is returned
   for directories, 'b' for block special files, 'c' for character
   special files, 'm' for multiplexor files, 'l' for symbolic link,
   's' for socket, 'p' for fifo, '-' for any other file type.

   Taken from the GNU Emacs source code. */

extern char file_type_letter ();

char
file_type_letter (s)
   struct stat * s;
{
  switch ((s -> st_mode) & S_IFMT)
    {
    case S_IFDIR:
      return ('d');
#if defined(S_IFLNK)
    case S_IFLNK:
      return ('l');
#endif
#if defined(S_IFCHR)
    case S_IFCHR:
      return ('c');
#endif
#if defined(S_IFBLK)
    case S_IFBLK:
      return ('b');
#endif
#if defined(S_IFMPC)
/* These do not seem to exist */
    case S_IFMPC:
    case S_IFMPB:
      return ('m');
#endif
#if defined(S_IFSOCK)
    case S_IFSOCK:
      return ('s');
#endif
#if defined(S_IFIFO)
    case S_IFIFO:
      return ('p');
#endif
#if defined(S_IFNWK) /* hp-ux hack */
    case S_IFNWK:
      return ('n');
#endif
    default:
      return ('-');
    }
}

/* Working Directory */

#if defined(HAS_GETCWD)

extern char *getcwd ();

#else

static char *
getcwd (buffer, length)
     char *buffer;
     int length;
{
  FILE *the_pipe;
  char *finder;

  /* Allocate the buffer if needed. */
  if (buffer == NULL)
    {
      buffer = (malloc (length));
      if (buffer == NULL)
	return (NULL);
    }

  /* Invoke `pwd' and fill the buffer with its output. */
  the_pipe = (popen ("pwd", "r"));
  if (the_pipe == NULL)
    return (NULL);
  fgets (buffer, length, the_pipe);
  pclose (the_pipe);

  /* Remove extraneous newline. */
  finder = buffer;
  while (true)
    {
      if ((*finder) == '\n')
	{
	  (*finder) = '\0';
	  break;
	}
      else if ((*finder++) == '\0')
	break;
    }
  return (buffer);
}

#endif

static Pointer
home_directory_pathname ()
{
  char *path;

  path = (getenv ("HOME"));
  return ((path == NULL) ? SHARP_F : (C_String_To_Scheme_String (path)));
}

Pointer
OS_working_dir_pathname ()
{
  char path[(FILE_NAME_LENGTH + 2)];

  return
    (((getcwd (path, (FILE_NAME_LENGTH + 2))) == NULL)
     ? (home_directory_pathname ())
     : (C_String_To_Scheme_String (path)));
}

Boolean
OS_set_working_dir_pathname (name)
     char *name;
{
  return ((chdir (name)) == 0);
}

/* File System Operations */

Boolean
OS_file_remove (name)
     char *name;
{
  return ((unlink (name)) == 0);
}

Boolean
OS_file_link_physical (old_name, new_name)
     char *old_name, *new_name;
{
  return ((link (old_name, new_name)) == 0);
}

Boolean
OS_file_link_symbolic (old_name, new_name)
     char *old_name, *new_name;
{
#if defined(S_IFLNK)
  return ((symlink (old_name, new_name)) == 0);
#else
  return (false);
#endif
}

/* Moves the file from OLD-NAME to NEW-NAME.  Simply reduces to a
   hard-link then a delete file; should be fixed for cross-structure
   rename. */

Boolean
OS_file_rename (old_name, new_name)
     char *old_name, *new_name;
{
  return
    (((link (old_name, new_name)) != 0)
     ? false
     : ((unlink (old_name)) == 0));
}

#define file_copy_finish(result)					\
{									\
  if (! (OS_file_close (source_file)))					\
    error_external_return ();						\
  if (! (OS_file_close (destination_file)))				\
    error_external_return ();						\
  return (result);							\
}

#define file_copy_1(nchars)						\
{									\
  if ((OS_file_read_chars (source_file, buffer, (nchars))) < (nchars))	\
    {									\
      file_copy_finish (false);						\
    }									\
  if (! (OS_file_write_chars (destination_file, buffer, (nchars))))	\
    {									\
      file_copy_finish (false);						\
    }									\
}

/* An arbitrary length -- could use `malloc' and compute

   file_copy_buffer_length = (((ulimit (3, 0)) - (sbrk (0))) / 2);

   but that is hairy and might not be easy to port to various unices.
   This should be adequate and hopefully will perform better than
   single-character buffering. */

#define file_copy_buffer_length 8192

Boolean
OS_file_copy (source_name, destination_name)
     char *source_name, *destination_name;
{
  FILE *source_file, *destination_file;
  long source_length, buffer_length;
  char buffer[file_copy_buffer_length];

  source_file = (OS_file_open_input (source_name));
  if (source_file == NULL)
    return (false);
  destination_file = (OS_file_open_output (destination_name));
  if (destination_file == NULL)
    {
      if (! (OS_file_close (source_file)))
	error_external_return ();
      return (false);
    }
  source_length = (OS_file_length (source_file));
  buffer_length =
    ((source_length < file_copy_buffer_length)
     ? source_length
     : file_copy_buffer_length);
  while (source_length > buffer_length)
    {
      file_copy_1 (buffer_length);
      source_length -= buffer_length;
    }
  file_copy_1 (source_length);
  file_copy_finish (true);
}

Boolean
OS_directory_make (name)
     char *name;
{
  int old_umask;
  Boolean result;

  old_umask = (umask (0));
#if defined(HAS_MKDIR)
  result = ((mkdir (name, 511)) == 0);
#else
  result = ((mknod (name, 0040666, ((dev_t) 0))) == 0);
#endif
  umask (old_umask);
  return (result);
}

#if defined(HAS_DIR)

static DIR *directory_pointer = NULL;
static struct direct *directory_entry = NULL;

#define read_directory_entry()						\
{									\
  directory_entry = (readdir (directory_pointer));			\
  if (directory_entry == NULL)						\
    {									\
      closedir (directory_pointer);					\
      directory_pointer = NULL;						\
      return (NIL);							\
    }									\
  return (C_String_To_Scheme_String (directory_entry -> d_name));	\
}

Pointer
OS_directory_open (name)
     char *name;
{
  if (directory_pointer != NULL)
    error_external_return ();
  directory_pointer = (opendir (name));
  if (directory_pointer == NULL)
    return (NIL);
  read_directory_entry ();
}

Pointer
OS_directory_read ()
{
  if (directory_pointer == NULL)
    error_external_return ();
  read_directory_entry ();
}

#else /* not HAS_DIR */

Pointer
OS_directory_open (name)
     char *name;
{
  return (NIL);
}

Pointer
OS_directory_read ()
{
  error_external_return ();
}

#endif /* HAS_DIR */

/* Console input. */

static char
  stdin_file_type;

static Boolean
  stdin_is_a_kbd,
  stdout_is_a_crt,
  Under_Emacs,
  interactive_p;

#define STDIN_IS_A_FILE() (stdin_file_type == '-')

static int TYI_Immediate ();
static int TYI_Buffered ();
extern void OS_Re_Init ();
extern void OS_Quit ();

int
OS_tty_tyi (Immediate, Interrupted)
     Boolean Immediate, *Interrupted;
{
  fast int C;

  if (stdin_is_a_kbd)
  {
    C =
      (Immediate
       ? (TYI_Immediate (Interrupted, true))
       : (TYI_Buffered (Interrupted, true)));
  }
  else if (! Under_Emacs)
  {
    (*Interrupted) = false;
    if ((C = (getchar ())) == EOF)
    {
      Microcode_Termination (TERM_EOF);
    }
    if (STDIN_IS_A_FILE ())
    {
      OS_tty_write_char (C);
    }
  }
  else
  {
    C = (TYI_Buffered (Interrupted, true));
  }
  return (C);
}

#define TTY_READ_CHAR_BODY(immediate)					\
{									\
  int chr;								\
									\
  while (true)								\
    {									\
      Boolean Interrupted;						\
									\
      chr = (OS_tty_tyi ((immediate), (& Interrupted)));		\
      if (Interrupted)							\
	{								\
	  if (INTERRUPT_PENDING_P (INT_Mask))				\
	    {								\
	      Primitive_Interrupt ();					\
	    }								\
	}								\
      else								\
	{								\
	  return ((char) chr);						\
	}								\
    }									\
}

char
OS_tty_read_char ()
{
  TTY_READ_CHAR_BODY (false);
}

char
OS_tty_read_char_immediate ()
{
  TTY_READ_CHAR_BODY (true);
}

void
OS_tty_write_char (chr)
     char chr;
{
  char buffer [1];

  (buffer [0]) = chr;
  (void) my_fwrite (buffer, 1, 1, stdout);
  return;
}

Boolean
OS_tty_write_chars (string, string_length)
     char *string;
     long string_length;
{
  return ((my_fwrite (string, 1, string_length, stdout)) == string_length);
}

void
OS_Flush_Output_Buffer()
{
  my_fflush (stdout);
}

char *CM, *BC, *UP, *CL, *CE, *term;
int LI, CO;

static Boolean Can_Do_Cursor;	/* Initialized below. */

Boolean
OS_Clear_Screen()
{
  if (Can_Do_Cursor)
    tputs (CL, LI, OS_tty_write_char);
  else
    OS_tty_write_char ('\f');
}

Boolean
OS_tty_move_cursor( x, y)
     long x, y;
{
  if (Can_Do_Cursor)
    tputs (tgoto (CM, x, y), 1, OS_tty_write_char);
  return (Can_Do_Cursor);
}

/* Maybe sometime this should be upgraded to use termcap too. */

void
OS_tty_beep()
{
  OS_tty_write_char (BELL);
  return;
}

void
OS_tty_newline()
{
  OS_tty_write_char ('\n');
  return;
}

/* Not currently implemented. */

Boolean
OS_tty_get_cursor (x, y)
     long *x, *y;
{
  *x = 0;
  *y = 0;
  return (false);
}

#define DEFAULT_NCOLUMNS 80
#define DEFAULT_NLINES   24

long
NColumns ()
{
  return (Can_Do_Cursor ? CO : DEFAULT_NCOLUMNS);
}

long
NLines ()
{
  return (Can_Do_Cursor ? LI : DEFAULT_NLINES);
}

Boolean
OS_Clear_To_End_Of_Line ()
{
  if (Can_Do_Cursor)
    tputs (CE, 1, OS_tty_write_char);
  return (Can_Do_Cursor);
}

#define TERMCAP_BUFFER_SIZE 1024

static void
initialize_terminal_description()
{
  char termcaps [TERMCAP_BUFFER_SIZE];
  static char tcb [TERMCAP_BUFFER_SIZE];
  char * tcp;

  tcp = (& (tcb [0]));

  /* The ultimate in C style -- by Jinx */

  if (Under_Emacs					||
      (!stdout_is_a_crt)				||
      ((term = getenv("TERM")) == NULL) 		||
      (tgetent(termcaps, term) <= 0)			||
      ((CM = tgetstr("cm", &tcp)) == NULL))
  {
    Can_Do_Cursor = false;
  }
  else /* Find terminal information */
  {
    char *temp;

    LI = tgetnum("li");
    if ((temp = getenv("LINES")) != NULL)
      sscanf(temp, "%ld", &LI);

    CO = tgetnum("co");
    if ((temp = getenv("COLUMNS")) != NULL)
      sscanf(temp, "%ld", &CO);

    UP = tgetstr("up", &tcp);
    CL = tgetstr("cl", &tcp);
    CE = tgetstr("ce", &tcp);
    BC = tgetflag("bs") ? "\b" : tgetstr("bc", &tcp);
    Can_Do_Cursor = true;
  }
  return;
}

/* GNU Emacs interface hackery */

#define emacs_message(mess)						\
{									\
  printf (mess);							\
  my_fflush (stdout);							\
}

#define SCHEME_ENTER_INPUT_WAIT		"\033s"
#define SCHEME_EXIT_INPUT_WAIT		"\033f"

Boolean
OS_Under_Emacs ()
{
  return (Under_Emacs);
}

/* Process Clock */

extern long OS_process_clock();

#if defined(HAS_TIMES)

#if !defined(HZ)
#define HZ 60
#endif

static long initial_process_time;

static void
initialize_process_clock ()
{
  struct tms time_buffer;

  times (& time_buffer);
  initial_process_time = (((time_buffer . tms_utime) * 1000) / HZ);
  return;
}

long
OS_process_clock ()
{
  struct tms time_buffer;

  times (& time_buffer);
  return ((((time_buffer . tms_utime) * 1000) / HZ) - initial_process_time);
}

#else /* not HAS_TIMES */

/*
  Note: These cannot cause errors because the garbage collector wrapper
  and other system utilities use them.
 */

static void
initialize_process_clock ()
{
  return;
}

long
OS_process_clock ()
{
  return (0);
}

#endif /* HAS_TIMES */

/* Real Time Clock */

#if defined(HAS_GETTIMEOFDAY)

static struct timeval initial_real_time;

static void
initialize_real_time_clock ()
{
  struct timezone time_zone;

  gettimeofday ((& initial_real_time), (& time_zone));
  return;
}

long
OS_real_time_clock ()
{
  struct timeval current_real_time;
  struct timezone time_zone;

  gettimeofday ((& current_real_time), (& time_zone));
  return
    ((((current_real_time . tv_sec) - (initial_real_time . tv_sec)) * 1000) +
     (((current_real_time . tv_usec) - (initial_real_time . tv_usec)) / 1000));
}

#else /* not HAS_GETTIMEOFDAY */
#if defined(HAS_TIMES)

static long initial_real_time;

static void
initialize_real_time_clock ()
{
  struct tms time_buffer;

  initial_real_time = (times (& time_buffer));
  return;
}

long
OS_real_time_clock ()
{
  struct tms time_buffer;

  return ((times (& time_buffer)) - initial_real_time);
}

#else /* not HAS_TIMES */

static void
initialize_real_time_clock ()
{
  return;
}

long
OS_real_time_clock ()
{
  return (0);
}

#endif /* HAS_TIMES */
#endif /* HAS_GETTIMEOFDAY */

#define OS_time_mark(delta) ((OS_real_time_clock ()) + (delta))

/* Time and dates. */

#if defined(HAS_LOCALTIME)

extern struct tm *(localtime());

#define Date_Part(C_Name, Which)	\
int					\
C_Name()				\
{					\
  struct tm *Time;			\
  long The_Time;			\
					\
  time(&The_Time);			\
  Time = localtime(&The_Time);		\
  return (Time->Which);			\
}

#else /* not HAS_LOCALTIME */

#define Date_Part(C_Name, ignore)	\
int					\
C_Name()				\
{					\
  return -1;				\
}

#endif /* HAS_LOCALTIME */

Date_Part(OS_Current_Year, tm_year);
Date_Part(OS_Current_Month, tm_mon + 1);
Date_Part(OS_Current_Day, tm_mday);
Date_Part(OS_Current_Hour, tm_hour);
Date_Part(OS_Current_Minute, tm_min);
Date_Part(OS_Current_Second, tm_sec);

/* Timers (for timer interrupts) */

#if defined(ITIMER_VIRTUAL)

void
Clear_Int_Timer ()
{
  struct itimerval New_Value, Old_Value;

  New_Value.it_value.tv_sec = 0;
  New_Value.it_value.tv_usec = 0;

  /* The following two are not necessary according to the
     documentation, but there seems to be a bug in BSD, at least on
     Suns.
   */

  New_Value.it_interval.tv_sec = 0;
  New_Value.it_interval.tv_usec = 0;
  setitimer(ITIMER_REAL, &New_Value, &Old_Value);
  setitimer(ITIMER_VIRTUAL, &New_Value, &Old_Value);
  return;
}

void
Set_Int_Timer (Days, Centi_Seconds)
     long Days, Centi_Seconds;
{
  struct itimerval New_Value, Old_Value;
  long Which_Timer = ITIMER_VIRTUAL;

  Clear_Int_Timer ();
  if (Centi_Seconds < 0)
  {
    Centi_Seconds = (- (Centi_Seconds));
    Which_Timer = ITIMER_REAL;
  }
  New_Value.it_value.tv_sec =
    ((Days * 24 * 60 * 60 * 60) + (Centi_Seconds / 100));
  New_Value.it_value.tv_usec = ((Centi_Seconds % 100) * 10000);
  New_Value.it_interval.tv_sec = 0;	/* Turn off after it rings */
  New_Value.it_interval.tv_usec = 0;
  setitimer(Which_Timer, &New_Value, &Old_Value);
  return;
}

#else

void
Clear_Int_Timer ()
{
  Primitive_Error( ERR_UNIMPLEMENTED_PRIMITIVE);
}

void
Set_Int_Timer (days, centi_seconds)
     long days, centi_seconds;
{
  Primitive_Error( ERR_UNIMPLEMENTED_PRIMITIVE);
}
#endif

/*
  Installing interrupt handlers.
  Sigvector is used, because signal gives rise to an interrupt window.
 */

typedef SIGTYPE (*signal_handler)();

#if defined(HAS_SIGVECTOR)

static signal_handler
install_signal_handler (signal_name, routine)
     int signal_name;
     signal_handler routine;
{
  struct sigvec new_vector;
  struct sigvec old_vector;

  new_vector.sv_handler = routine;
  new_vector.sv_mask    = ((long) 0x0);
  new_vector.sv_onstack = 0;

  SIGVECTOR (signal_name, &new_vector, &old_vector);

  return (old_vector.sv_handler);
}

#else

#define install_signal_handler(sig, act)	(signal (sig, act))

#endif

#define DISABLE_INTERRUPT(signal)					\
{									\
  install_signal_handler (signal, SIG_IGN);				\
}

#define ENABLE_INTERRUPT(signal, handler)				\
{									\
  install_signal_handler (signal, handler);				\
}

/* Keyboard I/O and interrupts */

#if defined(CBREAK)			/* BSD */

#define INITIALIZE_READER_STATE()					\
do {} while (0)

#define READER_STATE_DECLARATIONS()					\
struct sgttyb saved_ttyb;						\
struct sgttyb new_ttyb

#define READER_STATE_IMMEDIATE(only_polling)				\
{									\
  ioctl ((fileno (stdin)), TIOCGETP,					\
	 (& (current_reader_state -> saved_ttyb)));			\
  (current_reader_state -> state_saved_p) = true;			\
  (current_reader_state -> new_ttyb) =					\
    (current_reader_state -> saved_ttyb);				\
  ((current_reader_state -> new_ttyb) . sg_flags) |= CBREAK;		\
  ioctl ((fileno (stdin)), TIOCSETN,					\
	 (& (current_reader_state -> new_ttyb)));			\
}

#define READER_STATE_BUFFERED()						\
{									\
  ioctl ((fileno (stdin)), TIOCGETP,					\
	 (& (current_reader_state -> saved_ttyb)));			\
  (current_reader_state -> state_saved_p) = true;			\
  (current_reader_state -> new_ttyb) =					\
    (current_reader_state -> saved_ttyb);				\
  ((current_reader_state -> new_ttyb) . sg_flags) &= (~CBREAK);		\
  ioctl ((fileno (stdin)), TIOCSETN,					\
	 (& (current_reader_state -> new_ttyb)));			\
}

#define READER_STATE_REVERT()						\
{									\
  ioctl ((fileno (stdin)), TIOCSETN,					\
	 (& (current_reader_state -> saved_ttyb)));			\
}

#else
#if defined(TCSETA)			/* ATT, hpux */

static Boolean initial_echo_p = true;

#define INITIALIZE_READER_STATE()					\
do {									\
  struct termio initial;						\
									\
  ioctl ((fileno (stdin)), TCGETA, &initial);				\
  initial_echo_p = (initial.c_lflag & ECHO);				\
} while (0)

#define READER_STATE_DECLARATIONS()					\
struct termio saved_termio;						\
struct termio new_termio

#define READER_STATE_IMMEDIATE(only_polling)				\
{									\
  ioctl ((fileno (stdin)), TCGETA,					\
	 (& (current_reader_state -> saved_termio)));			\
  (current_reader_state -> state_saved_p) = true;			\
  (current_reader_state -> new_termio) =				\
    (current_reader_state -> saved_termio);				\
  ((current_reader_state -> new_termio) . c_lflag) &=			\
    (~ (ICANON | ECHO));						\
  if (only_polling)							\
    {									\
      (((current_reader_state -> new_termio) . c_cc) [VMIN]) =		\
	((char) 0);							\
      (((current_reader_state -> new_termio) . c_cc) [VTIME]) =		\
	((char) 0);							\
    }									\
  else									\
    {									\
      (((current_reader_state -> new_termio) . c_cc) [VMIN]) =		\
	((char) 1);		/* Minimum number of characters. */	\
      (((current_reader_state -> new_termio) . c_cc) [VTIME]) =		\
	((char) 1);		/* Timeout in tenths of a second. */	\
    }									\
  ioctl ((fileno (stdin)), TCSETA,					\
	 (& (current_reader_state -> new_termio)));			\
}

#define READER_STATE_BUFFERED(only_polling)				\
{									\
  ioctl ((fileno (stdin)), TCGETA,					\
	 (& (current_reader_state -> saved_termio)));			\
  (current_reader_state -> state_saved_p) = true;			\
  (current_reader_state -> new_termio) =				\
    (current_reader_state -> saved_termio);				\
  ((current_reader_state -> new_termio) . c_lflag) |=			\
    (ICANON | (initial_echo_p ? ECHO : 0));				\
  ioctl ((fileno (stdin)), TCSETA,					\
	 (& (current_reader_state -> new_termio)));			\
}

#define READER_STATE_REVERT()						\
{									\
  ioctl ((fileno (stdin)), TCSETA,					\
	 (& (current_reader_state -> saved_termio)));			\
}

#else /* not TCSETA */

/* No immediate IO */

#define INITIALIZE_READER_STATE()					\
do { } while (0)

#define READER_STATE_DECLARATIONS()	int foo
#define READER_STATE_IMMEDIATE(only_polling)
#define READER_STATE_BUFFERED()
#define READER_STATE_REVERT()

#endif					/* TCSETA */
#endif					/* CBREAK */

/* Keyboard Interrupts and I/O synchronization */

#define FIRST_TIME	0
#define DISMISS		1
#define INTERRUPT	2
#define HARD_RESET	3

struct reader_state
  {
    Boolean pad;
    Boolean in_input_wait;
    Boolean interrupted_p;
    Boolean state_saved_p;
    jmp_buf control_point;
    READER_STATE_DECLARATIONS ();
    struct reader_state * previous_state;
  };

static struct reader_state * current_reader_state;

static void
initialize_reader_state ()
{
  if (stdin_is_a_kbd)
  {
    INITIALIZE_READER_STATE ();
  }
  current_reader_state = ((struct reader_state *) NULL);
  return;
}

#define DECLARE_READER_STATE()						\
  struct reader_state new_state

#define BEGIN_READER_STATE()						\
{									\
  new_state.in_input_wait = false;					\
  new_state.interrupted_p = false;					\
  new_state.state_saved_p = false;					\
  new_state.previous_state = current_reader_state;			\
  current_reader_state = &new_state;					\
}

#define FINISH_READER_STATE()						\
{									\
  current_reader_state = (current_reader_state -> previous_state);	\
}

#define KEYBOARD_INPUT_BODY(SET_READER_STATE)				\
{									\
  int which_way, c;							\
  DECLARE_READER_STATE();						\
									\
  BEGIN_READER_STATE();							\
  which_way = (setjmp (current_reader_state -> control_point));		\
									\
  while (true)								\
    {									\
      switch (which_way)						\
	{								\
	case FIRST_TIME:						\
	  SET_READER_STATE;						\
	  /* fall through */						\
									\
	case DISMISS:							\
	  (current_reader_state -> in_input_wait) = true;		\
	  if (! ((current_reader_state -> interrupted_p) ||		\
		 (from_prim && (INTERRUPT_PENDING_P(INT_Mask)))))	\
	  {								\
	    c = (getchar ());						\
	    (current_reader_state -> in_input_wait) = false;		\
	    READER_STATE_REVERT ();					\
	    if (c == EOF)						\
	    {								\
	      FINISH_READER_STATE ();					\
	      Microcode_Termination (TERM_EOF);				\
	    }								\
	    (* interrupted) = false;					\
	    break;							\
	  }								\
	  /* fall through */						\
									\
	case INTERRUPT:							\
	  (current_reader_state -> in_input_wait) = false;		\
	  READER_STATE_REVERT ();					\
	  (* interrupted) = true;					\
	  c = EOF;							\
	  break;							\
									\
	default:							\
	  continue;							\
	}								\
      break;								\
    }									\
  FINISH_READER_STATE ();						\
  return (c);								\
}

static int
TYI_Immediate (interrupted, from_prim)
     Boolean * interrupted, from_prim;
{
  KEYBOARD_INPUT_BODY(READER_STATE_IMMEDIATE(false));
}

static int
TYI_Buffered (interrupted, from_prim)
     Boolean * interrupted, from_prim;
{
  KEYBOARD_INPUT_BODY(READER_STATE_BUFFERED());
}

static void
normal_scheme_interrupt (sig, handler, action)
     int sig, action;
     signal_handler handler;
{
  if (current_reader_state != ((struct reader_state *) NULL))
  {
    (current_reader_state -> interrupted_p) = (action == INTERRUPT);
    if (current_reader_state -> in_input_wait)
    {
      ENABLE_INTERRUPT(sig, handler);
      longjmp ((current_reader_state -> control_point), action);
      /*NOTREACHED*/
    }
  }
  ENABLE_INTERRUPT (sig, handler);
  return;
}

static void
aborting_scheme_interrupt (sig, handler)
{
  while (current_reader_state != ((struct reader_state *) NULL))
  {
    if (current_reader_state -> state_saved_p)
    {
      READER_STATE_REVERT ();
    }
    FINISH_READER_STATE ();
  }
  ENABLE_INTERRUPT (sig, handler);
  return;
}

/*
  Keyboard test will need to be considerably haired up to make it portable.
  See the file `src/keyboard.c' in GNU Emacs for the details.
  Who knows what magic VMS will require to perform this.
 */

#if defined(FIONREAD)

static Boolean
are_there_characters_ready()
{
  long temp;

  if (((stdin)->_cnt) > 0)
    return true;
  if ((ioctl ((fileno (stdin)), FIONREAD, &temp)) < 0)
    return false;
  return (temp > 0);
}

#else
#if defined(TCFLSH)

static Boolean
are_there_characters_ready()
{
  int result;

  result = (getchar ());
  if (result < 0)
    return (false);
  ungetc (result, stdin);
  return (true);
}

#else

/* Unknown... no characters ready. */

#define are_there_characters_ready() false
#endif
#endif

Boolean
OS_read_char_ready_p (delay)
     long delay;
{
  long limit;
  Boolean result;
  DECLARE_READER_STATE();

  BEGIN_READER_STATE ();
  READER_STATE_IMMEDIATE (true);

  limit = (OS_time_mark (delay));
  while (true)
  {
    if (stdin_is_a_kbd && (are_there_characters_ready ()))
    {
      result = true;
      break;
    }
    if ((OS_time_mark (0)) >= limit)
    {
      result = false;
      break;
    }
  }
  READER_STATE_REVERT ();
  FINISH_READER_STATE ();

  return (result);
}

/* Scheme Keyboard Interrupts */

/* Scheme interrupt specifiers */

#define CONTROL_B			'B'
#define CONTROL_G			'G'
#define CONTROL_U			'U'
#define CONTROL_X			'X'

/* Unix interrupt key codes */

#define DISABLED_CHAR			((unsigned char) '\377')
#define DEFAULT_SIGINT_CHAR		('G' - CONTROL_BIT)
#define DEFAULT_SIGQUIT_CHAR		('C' - CONTROL_BIT)
#define DEFAULT_SIGTSTP_CHAR		('Z' - CONTROL_BIT)

/* Codes specifying special handlers */

#define NULL_KEYBOARD_HANDLER		((unsigned char) '\377')
#define INTERACTIVE_HANDLER	        ((unsigned char) '\376')
#define SUSPEND_HANDLER			((unsigned char) '\375')

#define DEFAULT_SIGINT_HANDLER		CONTROL_G

/*
  Int_Char is the scheme interrupt key code to be processed next.
  There should really be a queue.
 */

static char Int_Char;

#define SET_INT_CHAR(character)						\
{									\
  if (Int_Char == '\0')							\
  {									\
    Int_Char = ((char) character);					\
    REQUEST_INTERRUPT(INT_Character);					\
  }									\
}

int
OS_Get_Next_Interrupt_Character()
{
  int result;

  if (Int_Char == '\0')
  {
    return (-1);
  }
  result = ((int) Int_Char);
  Int_Char = '\0';
  return (result);
}

/*
   OS_Clean_Interrupt_Channel is used to clear the input buffer when a
   character interrupt is received.  On most systems this is not
   currently used, but the Emacs interface under hp-ux needs some
   assistance.  Normally this is used in conjunction with some kind of
   distinguished marker in the input stream which indicates where each
   interrupt occurred.

   The `mode' argument allows the following values: 

   UNTIL_MOST_RECENT_INTERRUPT_CHARACTER indicates that the input buffer
   should be flushed up to and including the most recent interrupt marker.

   MULTIPLE_COPIES_ONLY indicates that all interrupts which match
   `interrupt_char' should be removed from the input buffer.  Any
   other interrupts should be left alone. 

 */

#define UNTIL_MOST_RECENT_INTERRUPT_CHARACTER	0
#define MULTIPLE_COPIES_ONLY			1

Boolean
OS_Clean_Interrupt_Channel (mode, interrupt_char)
     int mode, interrupt_char;
{
  if (Under_Emacs && (mode == UNTIL_MOST_RECENT_INTERRUPT_CHARACTER))
    while ((OS_tty_read_char_immediate ()) != '\0')
      ;
  return (true);
}

/* Keyboard interrupt state */

struct keyboard_characters {
  unsigned char eof;
  unsigned char quit;
  unsigned char intrpt;
  unsigned char tstp;
};

static struct keyboard_characters
  current_keyboard, current_handlers,
  disabled_keyboard =
{
  DISABLED_CHAR,
  DISABLED_CHAR,
  DISABLED_CHAR,
  DISABLED_CHAR
},
  scheme_default_keyboard =
{
  DISABLED_CHAR,
  DEFAULT_SIGQUIT_CHAR,
  DEFAULT_SIGINT_CHAR,
  DEFAULT_SIGTSTP_CHAR
},
  scheme_default_handlers =
{
  NULL_KEYBOARD_HANDLER,
  INTERACTIVE_HANDLER,
  DEFAULT_SIGINT_HANDLER,
  SUSPEND_HANDLER
};

void
copy_keyboard(source, dest)
     struct keyboard_characters *source, *dest;
{
  dest->eof = source->eof;
  dest->tstp = source->tstp;
  dest->quit = source->quit;
  dest->intrpt = source->intrpt;
  return;
}

/* Temporary suspension. */

int Scheme_Process_Id;

#if defined(SIGTSTP)

#define NO_SIGNALS_ALLOWED	(-1)
#define TSTP_MASK		(~(1 << (SIGTSTP - 1)))

static Boolean
Suspend_Me (from_intrpt)
     Boolean from_intrpt;
{
  long saved_mask;
  signal_handler old_handler;

  saved_mask = sigsetmask (NO_SIGNALS_ALLOWED);
  OS_Quit (TERM_HALT, false);
  old_handler = install_signal_handler (SIGTSTP, SIG_DFL);
  sigsetmask (saved_mask & TSTP_MASK);
  kill (Scheme_Process_Id, SIGTSTP);
  sigsetmask (NO_SIGNALS_ALLOWED);
  OS_Re_Init ();
  install_signal_handler (SIGTSTP, old_handler);
  sigsetmask (saved_mask);
  return (true);
}

#else

static Boolean
Suspend_Me (from_intrpt)
     Boolean from_intrpt;
{
#if false
  fprintf (stderr, "\nSuspend_Me: unimplemented.");
#endif
  return (false);
}

#endif

Boolean
Restartable_Exit ()
{
  return (Suspend_Me (false));
}

/* Random utilities. */

#define C_STRING_LENGTH		256

static void
examine_memory ()
{
  long free, input;
  char input_string[C_STRING_LENGTH];
  Boolean interrupted;

  interrupted = false;
  printf ("Enter location to examine (0x prefix for hex) : ");
  OS_Flush_Output_Buffer ();

  /* Considerably haired up to go through standard (safe) interface.
     Taken from debug.c
   */

  for (free = 0; free < C_STRING_LENGTH; free++)
  {
    input_string[free] = ((char) TYI_Buffered (&interrupted, false));
    if (interrupted)
    {
      return;
    }
    if (input_string[free] == '\n')
    {
      input_string[free] = '\0';
      break;
    }
  }

  /* Check to see if address is in hexadecimal (0x prefix). */

  if ((input_string[0] == '0') && (input_string[1] == 'x'))
  {
    sscanf (&input_string[2], "%lx", &input);
  }
  else
  {
    sscanf (&input_string[0], "%ld", &input);
  }
  Print_Expression ((*((Pointer *) input)), "Contents");
  OS_tty_newline ();
  return;
}

static void 
describe_interrupt_character (name, the_char, the_handler)
     unsigned char *name, the_char, the_handler;
{
  if (the_handler == NULL_KEYBOARD_HANDLER)
  {
    printf ("The %s character is currently disabled.\n", name);
    return;
  } 
  printf ("The %s character is ", name);
  print_character_name (the_char, true);
  printf (".\n");
  if (the_handler == CONTROL_G)
  {
    printf ("When typed, scheme will get the %c character interrupt.\n",
	    CONTROL_G);
    printf ("The default action is to abort the running program,\n");
    printf ("and to resume the top level read-eval-print loop.\n");
  }
  else if (the_handler == INTERACTIVE_HANDLER)
  {
    printf ("When typed, various interrupt options are offered.\n");
    printf ("Type ");
    print_character_name (the_char, false);
    printf (" followed by `?' for a list of options.\n");
  }
  else if (the_handler == SUSPEND_HANDLER)
  {
    printf ("When typed, scheme will suspend execution.\n");
  }
  else
  {
    printf ("When typed, scheme will get the %c character interrupt.\n",
	    the_handler);
  }
  return;
}

/* Input and choice routines */

static char
read_option_character (Interrupted_ptr)
     Boolean *Interrupted_ptr;
{
  char option;
  Boolean Interrupted;

  OS_Flush_Output_Buffer ();
  if (Under_Emacs)
  {
    emacs_message (SCHEME_ENTER_INPUT_WAIT);
  }
  flush_input_buffer ();
  option = ((char) TYI_Immediate (&Interrupted, false));
  if (Under_Emacs)
  {
    emacs_message (SCHEME_EXIT_INPUT_WAIT);
  }
  if ((! Interrupted) && (! Under_Emacs) && (option != '\n'))
  {
    OS_tty_write_char (option);
  }
  if (Interrupted_ptr != ((Boolean *) NULL))
  {
    (*Interrupted_ptr) = Interrupted;
  }
  return (option);
}

static Boolean
confirm (string)
     char *string;
{
  char answer;

  while (true)
  {
    printf ("%s", string);
    answer = (read_option_character ((Boolean *) NULL));
    printf ("\n");
    if ((answer == 'y') || (answer == 'Y') ||
	(answer == 'n') || (answer == 'N'))
      return ((answer == 'y') || (answer == 'Y'));
  }
}

static char
choose_option (herald, prompt, choices)
     char *herald, *prompt, **choices;
{
  register char command, option;
  Boolean interrupted;
  register char **temp;

  while (true)
  {
    interrupted = false;
    printf ("%s\n", herald);
    for (temp = choices; *temp != ((char *) NULL); temp++)
    {
      printf ("  %s\n", *temp);
    }
    printf ("%s", prompt);
    command = (read_option_character (&interrupted));
    printf ("\n");
    if (!interrupted)
    {
      for (temp = choices; *temp != ((char *) NULL); temp++)
      {
	option = **temp;
	if ((command == option) ||
	    ((command >= 'a') && (command <= 'z') &&
	     (((command - 'a') + 'A') == option)) ||
	    ((option >= 'a') && (option <= 'z') &&
	     (command == ((option - 'a') + 'A'))))
	  return (option);
      }
    }
  }
}

/* Interactive interrupt handler. */

static int
interactive_kbd_interrupt ()
{
  char command, interrupt;
  Boolean Interrupted;
  Boolean Really_Interrupted;

  Really_Interrupted = false;
  if (!Under_Emacs)
  {
    OS_tty_beep ();
    OS_tty_newline ();
  }

 Loop:

  if (!Under_Emacs)
  {
    printf ("Interrupt option (? for help): ");
    OS_Flush_Output_Buffer ();
  }
  do
  {
    flush_input_buffer ();
    command = ((char) TYI_Immediate (&Interrupted, false));
    Really_Interrupted |= Interrupted;
    if (Interrupted && (INTERRUPT_PENDING_P(~INT_Timer)))
    {
      goto exit_gracefully;
    }
  } while (Interrupted);

  switch (command)
    {
    case 'B':
    case 'b':
      interrupt = CONTROL_B;
      break;

    case 'E':
    case 'e':
      if (!Under_Emacs)
      {
	OS_tty_newline ();
      }
      examine_memory ();
      goto exit_gracefully;

    case 'D':
    case 'd':
      if (!Under_Emacs)
      {
	OS_tty_newline ();
      }
      Handle_Debug_Flags ();
      goto exit_gracefully;

    case 'T':
    case 't':
      if (!Under_Emacs)
      {
	OS_tty_newline ();
      }
      Back_Trace (stdout);
      goto exit_gracefully;

    case 'G':
    case 'g':
      interrupt = CONTROL_G;
      break;

    case 'U':
    case 'u':
      interrupt = CONTROL_U;
      break;

    case 'X':
    case 'x':
      interrupt = CONTROL_X;
      break;

    case 'Z':
    case 'z':
      if (!Under_Emacs)
      {
	OS_tty_newline ();
      }
      (void) Suspend_Me (true);
      goto exit_gracefully;

    case 'Q':
    case 'q':
      if (!Under_Emacs)
      {
	OS_tty_newline ();
      }
      Microcode_Termination(TERM_HALT);

    case '\f':
      if (!Under_Emacs)
      {
	OS_Clear_Screen ();
      }
      goto exit_gracefully;

    case 'R':
    case 'r':
    {
      printf ("\n");
      if (WITHIN_CRITICAL_SECTION_P())
      {
	char command;
	static char * reset_choices[] =
	{
	  "D = delay reset until the end of the critical section",
	  "N = attempt reset now",
	  "P = punt reset",
	  ((char *) NULL)
	};

	printf("Scheme is executing within critical section \"%s\".\n",
	       CRITICAL_SECTION_NAME());
	printf("Resetting now is likely to kill Scheme.\n");
	command = choose_option("Choose one of the following actions:",
				"Action -> ",
				&reset_choices[0]);
	switch (command)
	{
	  case 'D':
	  {
	    static void soft_reset ();
	    
	    SET_CRITICAL_SECTION_HOOK(soft_reset);
	    goto exit_gracefully;
	  }
	  case 'N':
	    CLEAR_CRITICAL_SECTION_HOOK();
	    EXIT_CRITICAL_SECTION({});
	    return (HARD_RESET);

	  default:
	    /* Paranoia */
	  case 'P':
	    goto exit_gracefully;
	}
      }
      if (!confirm ("Do you really want to reset? [Y or N] "))
      {
	goto exit_gracefully;
      }
      return (HARD_RESET);
    }

    case 'H':
    case 'h':
      if (!Under_Emacs)
      {
	printf("\n\n");
	describe_interrupt_character ("quit",
				      current_keyboard.quit,
				      current_handlers.quit);
	printf("\n");
	describe_interrupt_character ("interrupt",
				      current_keyboard.intrpt,
				      current_handlers.intrpt);
	printf("\n");
#if defined(SIGTSTP)
	describe_interrupt_character ("terminal stop",
				      current_keyboard.tstp,
				      current_handlers.tstp);
	printf("\n");
#endif
      }
      goto Loop;

    case 'I':
    case 'i':
      if (!Under_Emacs)
      {
	printf ("Ignored.  Resuming Scheme.\n");
      }

exit_gracefully:
      return (Really_Interrupted ? INTERRUPT : DISMISS);

    default:
      if (!Under_Emacs)
	{
	  printf("\n\n");
	  printf("B: Enter a breakpoint loop.\n");
	  printf("D: Debugging: change interpreter flags.\n");
	  printf("E: Examine memory location.\n");
	  printf("G: Goto to top level read-eval-print (REP) loop.\n");
	  printf("H: Print simple information on interrupts.\n");
	  printf("I: Ignore interrupt request.\n");
	  printf("Q: Quit instantly, killing Scheme.\n");
	  printf("R: Hard reset, possibly killing Scheme in the process.\n");
	  printf("T: Stack trace.\n");
	  printf("U: Up to previous (lower numbered) REP loop.\n");
	  printf("X: Abort to current REP loop.\n");
#if defined(SIGTSTP)
	  printf("Z: Quit instantly, suspending Scheme.\n");
#endif
	  printf("^L: Clear the screen.\n");
	  printf("\n");
	}
      goto Loop;
  }
  SET_INT_CHAR (interrupt);
  return (INTERRUPT);
}

static void
standard_kbd_interrupt (culprit, intrpt_char)
     unsigned char intrpt_char;
{
  if (culprit != DISABLED_CHAR)
  {
    if (culprit == BELL)
    {
      OS_tty_beep ();
    }
    else if (culprit < 040)
    {
      OS_tty_write_char ('^');
      OS_tty_write_char (culprit + CONTROL_BIT);
    }
    else
    {
      OS_tty_write_char (culprit);
    }
    OS_Flush_Output_Buffer ();
  }
  SET_INT_CHAR (intrpt_char);
  return;
}

/* Keyboard signal handler. */

static SIGTYPE
keyboard_interrupt (sig, code, pscp)
     int sig, code;
     struct SIGCONTEXT *pscp;
{
  unsigned char handler, culprit;
  DECLARE_FULL_SIGCONTEXT(scp);

  INITIALIZE_FULL_SIGCONTEXT(pscp, scp);
  DISABLE_INTERRUPT(sig);
  switch(sig)
  {
    case SIGQUIT:
      culprit = current_keyboard.quit;
      handler = current_handlers.quit;
      break;

    case SIGINT:
      culprit = current_keyboard.intrpt;
      handler = current_handlers.intrpt;
      break;

#if defined(SIGTSTP)
    case SIGTSTP:
      culprit = current_keyboard.tstp;
      handler = current_handlers.tstp;
      break;
#endif

    default:
      culprit = DISABLED_CHAR;
      handler = NULL_KEYBOARD_HANDLER;
   }

  switch(handler)
  {
    case NULL_KEYBOARD_HANDLER:
      /* Spurious.  Ignore. */
      normal_scheme_interrupt (sig, keyboard_interrupt, DISMISS);
      break;

    case SUSPEND_HANDLER:
      (void) Suspend_Me (true);
      normal_scheme_interrupt (sig, keyboard_interrupt, DISMISS);
      break;

    case INTERACTIVE_HANDLER:
    {
      int result;

      result = interactive_kbd_interrupt ();
      if (result == HARD_RESET)
      {
	static void hard_reset ();

	aborting_scheme_interrupt (sig, keyboard_interrupt);
	hard_reset (sig, scp);
	/*NOTREACHED*/
      }
      else
      {
	normal_scheme_interrupt (sig, keyboard_interrupt, result);
	break;
      }
    }

    default:
      standard_kbd_interrupt (culprit, handler);
      normal_scheme_interrupt (sig, keyboard_interrupt, INTERRUPT);
  }
  SIGRETURN();
}

/* Timer, suspension, and termination signal handlers. */

static SIGTYPE
timer_interrupt (sig, code, scp)
     int sig, code;
     struct SIGCONTEXT *scp;
{
  DISABLE_INTERRUPT (sig);
  REQUEST_INTERRUPT (INT_Timer);
  normal_scheme_interrupt (sig, timer_interrupt, INTERRUPT);
  /*NOTREACHED*/
}

static SIGTYPE
suspension_trap (sig, code, scp)
     int sig, code;
     struct SIGCONTEXT *scp;
{
  DISABLE_INTERRUPT (sig);
  REQUEST_INTERRUPT (INT_Suspend);
  normal_scheme_interrupt (sig, suspension_trap, INTERRUPT);
  /*NOTREACHED*/
}

#if defined(hpux)
#define NICE_DELTA	5

static SIGTYPE
renice_trap (sig, code, scp)
     int sig, code;
     struct SIGCONTEXT *scp;
{
  int value;
  extern int nice();
  DISABLE_INTERRUPT (sig);

  value = nice(NICE_DELTA);
  fprintf(stderr, "\n;;; Renicing! New nice value = %d\n", (value + 20));
  normal_scheme_interrupt (sig, renice_trap, DISMISS);
  /*NOTREACHED*/
}
#endif

/*
  Kill Scheme after undoing terminal garbage.
  OS_Quit is called by Microcode_Termination.
 */

int assassin_signal;
extern Boolean inhibit_termination_messages;

static SIGTYPE
kill_me (sig, code, scp)
     int sig, code;
     struct SIGCONTEXT *scp;
{
  DISABLE_INTERRUPT (sig);
  assassin_signal = sig;
#if defined(SIGHUP)
  inhibit_termination_messages = (Under_Emacs && (sig == SIGHUP));
#endif
  aborting_scheme_interrupt (sig, kill_me);
  Microcode_Termination (TERM_SIGNAL);
  /*NOTREACHED*/
}

/* Trap signal handlers */

/* It can happen inside of compiled code as well as inside a primitive.
   What should we do then?
 */

static SIGTYPE
floating_trap (sig, code, scp)
     int sig, code;
     struct SIGCONTEXT *scp;
{
  DISABLE_INTERRUPT (sig);
  if (OBJECT_TYPE(Regs[REGBLOCK_PRIMITIVE]) != TC_PRIMITIVE)
  {
    ENABLE_INTERRUPT (sig, floating_trap);
    SIGRETURN();
  }
  ENABLE_INTERRUPT (sig, floating_trap);
  Primitive_Error (ERR_FLOATING_OVERFLOW);
  /*NOTREACHED*/
}

static SIGTYPE
hardware_trap (sig, code, pscp)
     int sig, code;
     struct SIGCONTEXT *pscp;
{
  static void trap_common();
  DECLARE_FULL_SIGCONTEXT(scp);

  INITIALIZE_FULL_SIGCONTEXT(pscp, scp);
  DISABLE_INTERRUPT (sig);
  trap_common ("The hardware", sig, code, scp, hardware_trap);
  /*NOTREACHED*/
}

static SIGTYPE
software_trap (sig, code, pscp)
     int sig, code;
     struct SIGCONTEXT *pscp;
{
  static void trap_common();
  DECLARE_FULL_SIGCONTEXT(scp);

  INITIALIZE_FULL_SIGCONTEXT(pscp, scp);
  DISABLE_INTERRUPT (sig);
  trap_common ("System software", sig, code, scp, software_trap);
  /*NOTREACHED*/
}

/* Accidental traps. */

#define TRAP_STATE_TRAPPED	-1
#define TRAP_STATE_EXIT		0
#define TRAP_STATE_SUSPEND	1
#define TRAP_STATE_QUERY	2
#define TRAP_STATE_RECOVER	3
#define MAX_TRAP_STATE		3
#define DEFAULT_TRAP_STATE	TRAP_STATE_RECOVER

static long
  trap_state = DEFAULT_TRAP_STATE,
  user_trap_state = DEFAULT_TRAP_STATE,
  saved_trap_state;

static int
  saved_signal,
  saved_code;

static struct FULL_SIGCONTEXT
  *saved_scp;

extern long OS_set_trap_state ();

long
OS_set_trap_state (state)
     long state;
{
  long old;

  if ((state < 0) || (state > MAX_TRAP_STATE))
  {
    return (-1);
  }
  else
  {
    old = user_trap_state;
    user_trap_state = state;
    trap_state = state;
    return (old);
  }
}

static void
dump_core ()
{
  signal(SIGQUIT, SIG_DFL);
  kill(Scheme_Process_Id, SIGQUIT);
  /*NOTREACHED*/
}

extern char * find_signal_name ();

static void
trap_common (message, sig, code, scp, handler)
     char *message;
     int sig, code;
     struct FULL_SIGCONTEXT *scp;
     signal_handler handler;
{
  char command;
  long old_trap_state;
  Boolean Interrupted, within_critical_section;
  static void continue_from_trap ();

  old_trap_state = trap_state;
  trap_state = TRAP_STATE_TRAPPED;

  if (WITHIN_CRITICAL_SECTION_P())
  {
    printf ("\n");
    printf (">> Signal %d (%s), code %d, received.\n", 
	    sig, find_signal_name(sig), code);
    printf (">> %s has trapped within critical section \"%s\"!\n",
	    message, (CRITICAL_SECTION_NAME()));
  }
  else if (old_trap_state != TRAP_STATE_RECOVER)
  {
    printf ("\n");
    printf (">> Signal %d (%s), code %d, received.\n",
	    sig, find_signal_name(sig), code);
    printf (">> %s has trapped!\n", message);
  }

  switch(old_trap_state)
  {
    case TRAP_STATE_TRAPPED:
    {
      if ((saved_trap_state == TRAP_STATE_RECOVER) ||
	  (saved_trap_state == TRAP_STATE_QUERY))
      {
	printf (">> The trap has occured while processing an earlier trap.\n");
	printf (">> The earlier trap raised signal %d (%s), code %d.\n",
		saved_signal, find_signal_name(saved_signal), saved_code);
	printf (">> Successful recovery is%sunlikely.\n",
		((WITHIN_CRITICAL_SECTION_P()) ? " extremely " : " "));
	goto trap_query;
      }
      else
	command = 'I';
      break;
    }

    case TRAP_STATE_RECOVER:
      if (WITHIN_CRITICAL_SECTION_P())
      {
	printf (">> Successful recovery is unlikely.\n");
	goto trap_query;
      }
      command = 'R';
      break;
    
    case TRAP_STATE_EXIT:
      command = 'N';
      break;

    default:
      printf (">> trap_state has unknown value %d.\n", old_trap_state);
      goto trap_query;

    case TRAP_STATE_QUERY:
    trap_query:
    { 
      static char * trap_query_choices[] =
      {
	"D = dump core",
	"I = terminate immediately",
	"N = terminate normally",
	"R = attempt recovery",
	((char *) NULL)
      };

      command = choose_option("Choose one of the following actions:",
			      "Action -> ",
			      &trap_query_choices[0]);
      break;
    }
  }

  saved_trap_state = old_trap_state;
  saved_signal = sig;
  saved_code = code;
  saved_scp = scp;

  switch(command)
  {
    case 'I':
      aborting_scheme_interrupt (sig, handler);
      OS_Quit (TERM_HALT, false);
      exit(1);
      /*NOTREACHED*/

    case 'N':
      aborting_scheme_interrupt (sig, handler);
      Microcode_Termination (TERM_TRAP);
      /*NOTREACHED*/

    case 'D':
      aborting_scheme_interrupt (sig, handler);
      OS_Quit (TERM_HALT, false);
      dump_core ();
      /*NOTREACHED*/

    case 'R':
      if (WITHIN_CRITICAL_SECTION_P())
      {
	CLEAR_CRITICAL_SECTION_HOOK();
	EXIT_CRITICAL_SECTION({});
      }
      aborting_scheme_interrupt (sig, handler);
      continue_from_trap (sig, scp);
      /*NOTREACHED*/

    default:
      /* Paranoia */
      goto trap_query;
  }
}

/* Signal handler descriptors */

typedef struct
  {
    int the_signal;
    char * the_name;
    Boolean do_it_always;
    signal_handler handler;
  }
signal_state;

/* The only signals which are always assumed to be there are
   SIGINT and SIGQUIT.  */

static signal_state initial_scheme_signal_handlers [] =
  {
    { SIGINT,	"SIGINT",	true,	((signal_handler) keyboard_interrupt)},
    { SIGQUIT,	"SIGQUIT",	false,	((signal_handler) keyboard_interrupt)},
#if defined(SIGTERM)
    { SIGTERM,	"SIGTERM",	true,	((signal_handler) kill_me)},
#endif
#if defined(SIGHUP)
    { SIGHUP,	"SIGHUP",	false,	((signal_handler) suspension_trap)},
#endif
#if defined(SIGTSTP)
    { SIGTSTP,	"SIGTSTP",	false,	((signal_handler) keyboard_interrupt)},
#endif
#if defined(SIGALRM)
    { SIGALRM,	"SIGALRM",	true,	((signal_handler) timer_interrupt)},
#endif
#if defined(SIGVTALRM)
    { SIGVTALRM,"SIGVTALRM",	true,	((signal_handler) timer_interrupt)},
#endif
#if defined(SIGFPE)
    { SIGFPE,	"SIGFPE",	true,	((signal_handler) floating_trap)},
#endif
#if defined(SIGILL)
    { SIGILL,	"SIGILL",	false,	((signal_handler) hardware_trap)},
#endif
#if defined(SIGBUS)
    { SIGBUS,	"SIGBUS",	false,	((signal_handler) hardware_trap)},
#endif
#if defined(SIGSEGV)
    { SIGSEGV,	"SIGSEGV",	false,	((signal_handler) hardware_trap)},
#endif
#if defined(SIGTRAP)
    { SIGTRAP,	"SIGTRAP",	false,	((signal_handler) hardware_trap)},
#endif

#if defined(SIGPIPE)
    { SIGPIPE,	"SIGPIPE",	false,	((signal_handler) kill_me)},
#endif
#if defined(SIGPWR)
    { SIGPWR,	"SIGPWR",	false,	((signal_handler) kill_me)},
#endif
#if defined(SIGIOT)
    { SIGIOT,	"SIGIOT",	false,	((signal_handler) software_trap)},
#endif
#if defined(SIGEMT)
    { SIGEMT,	"SIGEMT",	false,	((signal_handler) software_trap)},
#endif
#if defined(SIGSYS)
    { SIGSYS,	"SIGSYS",	false,	((signal_handler) software_trap)},
#endif
#if defined(SIGUSR1)
    { SIGUSR1,	"SIGUSR1",	true,	((signal_handler) suspension_trap)},
#endif
#if defined(SIGUSR2)
#if defined(hpux)
    { SIGUSR2,	"SIGUSR2",	true,	((signal_handler) renice_trap)},
#else
    { SIGUSR2,	"SIGUSR2",	false,	((signal_handler) software_trap)},
#endif
#endif
#if defined(SIGPROF)
    { SIGPROF,	"SIGPROF",	false,	((signal_handler) software_trap)},
#endif
  };

/* Missing HPUX signals:
   SIGKILL, SIGCLD, SIGIO, SIGWINDOW */

/* Missing BSD signals:
   SIGKILL, SIGURG, SIGSTOP, SIGCONT, SIGCHLD,
   SIGTTIN, SIGTTOU, SIGIO, SIGXCPU, SIGXFSZ */

#define NHANDLERS							\
((sizeof (initial_scheme_signal_handlers)) / (sizeof (signal_state)))

static signal_state scheme_signal_handlers [NHANDLERS];
static signal_state outside_signal_handlers [NHANDLERS];

static void
initialize_scheme_signals ()
{
  fast int i;

  for (i = 0; (i < NHANDLERS); i += 1)
  {
    (scheme_signal_handlers [i]) = (initial_scheme_signal_handlers [i]);
#if defined(SIGHUP)
    if (Under_Emacs &&
	(((scheme_signal_handlers [i]) . the_signal) == SIGHUP))
    {
      ((scheme_signal_handlers [i]) . do_it_always) = true;
      ((scheme_signal_handlers [i]) . handler) = kill_me;
    }
#endif
  }
  return;
}

static void
hack_signals (source, dest, do_all, save_state)
     signal_state *source;
     signal_state *dest;
     Boolean do_all;
     Boolean save_state;
{
  signal_handler old_handler;
  fast int i;
  fast signal_state *from;
  fast signal_state *to;

  /* The following is total paranoia in case a signal which undoes all
     comes in while we are not yet done setting them all up.  */
  if (save_state)
    for (i = 0, from = source, to = dest;
	 i < NHANDLERS;
	 i++, *from++, *to++)
    {
      to->the_signal = from->the_signal;
      to->the_name = from->the_name;
      to->do_it_always = from->do_it_always;
      to->handler = ((signal_handler) SIG_DFL);
    }
  for (i = 0, from = source, to = dest;
       i < NHANDLERS;
       i++, *from++, *to++)
  {
    if (from->do_it_always || do_all)
    {
      old_handler =
	((signal_handler)
	 install_signal_handler(from->the_signal, from->handler));
      if (old_handler == ((signal_handler) -1))
	old_handler = ((signal_handler) SIG_DFL);
    }
    else
      old_handler = ((signal_handler) SIG_DFL);
    if (save_state)
      to->handler = old_handler;
  }
  return;
}

char *
find_signal_name (sig)
     int sig;
{
  static char buf [128];
  fast int i;

  for (i = 0; (i < NHANDLERS); i += 1)
    if (((scheme_signal_handlers [i]) . the_signal) == sig)
      return ((scheme_signal_handlers [i]) . the_name);

  sprintf ((& (buf [0])), "unknown signal #d%d", sig);
  return (& (buf [0]));
}

#if defined(TIOCGETP) && defined(TIOCSETN)	/* BSD */

static long outside_crt_flags;

#define HACK_CRT(old, new)						\
{									\
  int crt_pgrp;								\
									\
  ioctl ((fileno (stdout)), TIOCGPGRP, (& crt_pgrp));			\
  if ((getpgrp (Scheme_Process_Id)) == crt_pgrp)			\
  {									\
    struct sgttyb sg;							\
									\
    ioctl ((fileno (stdout)), TIOCGETP, (& sg));			\
    outside_crt_flags = old;						\
    (sg . sg_flags) = new;						\
    ioctl ((fileno (stdout)), TIOCSETN, (& sg));			\
  }									\
}

static void
set_keyboard_characters(new, old)
     struct keyboard_characters *new, *old;
{
  int crt_pgrp;
  struct tchars Terminal_Chars;
  struct ltchars Extra_Terminal_Chars;

  ioctl ((fileno (stdin)), TIOCGPGRP, (& crt_pgrp));
  if ((getpgrp (Scheme_Process_Id)) != crt_pgrp)
  {
    copy_keyboard(&disabled_keyboard, &old);
    return;
  }

  ioctl ((fileno (stdin)), TIOCGLTC, (& Extra_Terminal_Chars));
  ioctl ((fileno (stdin)), TIOCGETC, (& Terminal_Chars));

  old->eof = Terminal_Chars.t_eofc;
  old->quit = Terminal_Chars.t_quitc;
  old->intrpt = Terminal_Chars.t_intrc;
  old->tstp = Extra_Terminal_Chars.t_suspc;

  Extra_Terminal_Chars.t_suspc = new->tstp;
  Terminal_Chars.t_intrc = new->intrpt;
  Terminal_Chars.t_quitc = new->quit;
  Terminal_Chars.t_eofc = new->eof;

  ioctl ((fileno (stdin)), TIOCSETC, (& Terminal_Chars));
  ioctl ((fileno (stdin)), TIOCSLTC, (& Extra_Terminal_Chars));
  return;
}

#else
#if defined(TCSETA)			/* hpux, ATT */

#define HACK_CRT(old, new)

/* A lot of conditionalization for ATT,BSD hybrids. */

static void
set_keyboard_characters(new, old)
     struct keyboard_characters *new, *old;
{
  struct termio my_termio;

#if defined(TIOCGPGRP)
  int crt_pgrp;

  ioctl ((fileno (stdin)), TIOCGPGRP, (& crt_pgrp));
  if ((getpgrp (Scheme_Process_Id)) != crt_pgrp)
  {
    copy_keyboard(&disabled_keyboard, &old);
    return;
  }
#endif

  ioctl ((fileno (stdin)), TCGETA, (& my_termio));

  old->eof = my_termio.c_cc[VEOF];
  old->quit = my_termio.c_cc[VQUIT];
  old->intrpt = my_termio.c_cc[VINTR];

#if defined(TIOCSLTC)
  {
    struct ltchars Extra_Terminal_Chars;

    ioctl ((fileno (stdin)), TIOCGLTC, (& Extra_Terminal_Chars));
    old->tstp = Extra_Terminal_Chars.t_suspc;
    Extra_Terminal_Chars.t_suspc = new->tstp;
    ioctl ((fileno (stdin)), TIOCSLTC, (& Extra_Terminal_Chars));
  }
#else
  old->tstp = DISABLED_CHAR;
#endif

  my_termio.c_cc[VEOF] = new->eof;
  my_termio.c_cc[VQUIT] = new->quit;
  my_termio.c_cc[VINTR] = new->intrpt;

  ioctl ((fileno (stdin)), TCSETA, (& my_termio));
  return;
}

#else /* ??? */

#define HACK_CRT(old, new)

static void
set_keyboard_characters(new, old)
     struct keyboard_characters *new, *old;
{
  copy_keyboard(&disabled_keyboard, &old);
  return;
}

#endif
#endif

/* TTY parameter hacking */

#define KEYBOARD_QUIT_OFFSET			0
#define KEYBOARD_INTRPT_OFFSET			1
#define KEYBOARD_TSTP_OFFSET			2

#if defined(SIGTSTP)
#define MAX_KEYBOARD_OFFSET			KEYBOARD_TSTP_OFFSET
#else
#define MAX_KEYBOARD_OFFSET			KEYBOARD_INTRPT_OFFSET
#endif

#define KEYBOARD_QUIT_INTERRUPT			(1 << KEYBOARD_QUIT_OFFSET)
#define KEYBOARD_INTRPT_INTERRUPT		(1 << KEYBOARD_INTRPT_OFFSET)
#define KEYBOARD_TSTP_INTERRUPT			(1 << KEYBOARD_TSTP_OFFSET)
#define KEYBOARD_ALL_INTERRUPTS			0xffffff

static struct keyboard_characters
  outside_keyboard, saved_keyboard;

static long
  outside_keyboard_mask, saved_keyboard_mask;

static void
initialize_scheme_keyboard()
{
  Int_Char = '\0';
  copy_keyboard(&scheme_default_keyboard, &saved_keyboard);
  copy_keyboard(&scheme_default_keyboard, &current_keyboard);
  copy_keyboard(&scheme_default_handlers, &current_handlers);
  saved_keyboard_mask = KEYBOARD_ALL_INTERRUPTS;
  return;
}

extern long
  OS_set_keyboard_interrupt_enables();
extern Boolean
  OS_set_keyboard_interrupt_characters();

static long current_keyboard_interrupt_mask = 0;

long 
OS_set_keyboard_interrupt_enables(mask)
     long mask;
{
  long old_mask;
  struct keyboard_characters new, old;
  static Boolean already_invoked = false;

  new.eof = current_keyboard.eof;
  new.tstp = ((mask & KEYBOARD_TSTP_INTERRUPT) ?
	      current_keyboard.tstp :
	      DISABLED_CHAR);
  new.quit = ((mask & KEYBOARD_QUIT_INTERRUPT) ?
	      current_keyboard.quit :
	      DISABLED_CHAR);
  new.intrpt = ((mask & KEYBOARD_INTRPT_INTERRUPT) ?
		current_keyboard.intrpt :
		DISABLED_CHAR);

  set_keyboard_characters(&new, &old);

  if (already_invoked)
  {
    old_mask = current_keyboard_interrupt_mask;
    current_keyboard_interrupt_mask = mask;
  }
  else
  {
    old_mask = 0;
    if (old.tstp != DISABLED_CHAR)
      old_mask += KEYBOARD_TSTP_INTERRUPT;
    if (old.quit != DISABLED_CHAR)
      old_mask += KEYBOARD_QUIT_INTERRUPT;
    if (old.intrpt != DISABLED_CHAR)
      old_mask += KEYBOARD_INTRPT_INTERRUPT;
    current_keyboard_interrupt_mask = mask;
    already_invoked = true;
  }
  return (old_mask);
}

Boolean
OS_set_keyboard_interrupt_characters(length_ptr,
				     new_chars, old_chars,
				     read_ptr)
     long *length_ptr;
     register unsigned char *new_chars, *old_chars;
     unsigned char **read_ptr;
{
  Boolean read_p;
  static unsigned char
    buffer_1[(2 * (MAX_KEYBOARD_OFFSET + 1))],
    buffer_2[sizeof(buffer_1)];
  struct keyboard_characters new_kbd, new_hnd, act_kbd, ignore;
  unsigned char handler;
  register long count, length;

  length = *length_ptr;
  read_p = (length < 0);

  if (read_p)
  {
    length = sizeof(buffer_1);
    new_chars = &buffer_1[0];
    old_chars = &buffer_2[0];
    *read_ptr = old_chars;
    *length_ptr = length;
  }
  else
  {
    /* Validate input. */

    for (count = 1; count < length; count += 2)
    {
      handler = new_chars[count];
      if ((handler != NULL_KEYBOARD_HANDLER)	&&
	  (handler != SUSPEND_HANDLER)		&&
	  (handler != INTERACTIVE_HANDLER)	&&
	  ((handler < 'A') || (handler > 'Z')))
	return (false);
    }
  }

  copy_keyboard(&current_keyboard, &new_kbd);
  copy_keyboard(&current_handlers, &new_hnd);

  if (length > (KEYBOARD_QUIT_OFFSET * 2))
  {
    old_chars[(KEYBOARD_QUIT_OFFSET * 2)] = new_kbd.quit;
    old_chars[(KEYBOARD_QUIT_OFFSET * 2) + 1] = new_hnd.quit;
    new_kbd.quit = new_chars[KEYBOARD_QUIT_OFFSET * 2];
    new_hnd.quit = new_chars[(KEYBOARD_QUIT_OFFSET * 2) + 1];
  }

  if (length > (KEYBOARD_TSTP_OFFSET * 2))
  {
    old_chars[(KEYBOARD_TSTP_OFFSET * 2)] = new_kbd.tstp;
    old_chars[(KEYBOARD_TSTP_OFFSET * 2) + 1] = new_hnd.tstp;
    new_kbd.tstp = new_chars[(KEYBOARD_TSTP_OFFSET * 2)];
    new_hnd.tstp = new_chars[(KEYBOARD_TSTP_OFFSET * 2) + 1];
  }

  if (length > (KEYBOARD_INTRPT_OFFSET * 2))
  {
    old_chars[(KEYBOARD_INTRPT_OFFSET * 2)] = new_kbd.intrpt;
    old_chars[(KEYBOARD_INTRPT_OFFSET * 2) + 1] = new_hnd.intrpt;
    new_kbd.intrpt = new_chars[(KEYBOARD_INTRPT_OFFSET * 2)];
    new_hnd.intrpt = new_chars[(KEYBOARD_INTRPT_OFFSET * 2) + 1];
  }

  if (read_p)
  {
    return (true);
  }

  copy_keyboard(&new_kbd, &act_kbd);

  if ((current_keyboard_interrupt_mask & KEYBOARD_QUIT_INTERRUPT) == 0)
    act_kbd.quit = DISABLED_CHAR;

  if ((current_keyboard_interrupt_mask & KEYBOARD_INTRPT_INTERRUPT) == 0)
    act_kbd.intrpt = DISABLED_CHAR;

  if ((current_keyboard_interrupt_mask & KEYBOARD_TSTP_INTERRUPT) == 0)
    act_kbd.tstp = DISABLED_CHAR;

  set_keyboard_characters(&act_kbd, &ignore);

  copy_keyboard(&new_kbd, &current_keyboard);
  copy_keyboard(&new_hnd, &current_handlers);

  return (true);
}

#if defined(TIOCNOTTY) && defined(HAS_SETPGRP_2)

#define BREAK_TERMINAL_CONNECTION()					\
{									\
  int fd;								\
  extern int open ();							\
  extern int ioctl ();							\
  extern int close ();							\
  extern int setpgrp2 ();						\
									\
  fd = (open ("/dev/tty", O_RDWR));					\
  if (fd >= 0)								\
    {									\
      (void) ioctl (fd, TIOCNOTTY, 0);					\
      (void) close (fd);						\
    }									\
  (void) setpgrp2 (0, 0);						\
}

#else /* no TIOCNOTTY */
#if defined(HAS_SETPGRP_0)

#define BREAK_TERMINAL_CONNECTION()					\
{									\
  extern int setpgrp ();						\
									\
  (void) setpgrp ();							\
}

#else /* not HAS_SETPGRP_0 */

#define BREAK_TERMINAL_CONNECTION()

#endif /* HAS_SETPGRP_0 */
#endif /* TIOCNOTTY */

void
OS_Init (ignore)
     Boolean ignore;
{
  struct stat s;
  static void initialize_trap_recovery ();

  OS_Name = SYSTEM_NAME;
  OS_Variant = SYSTEM_VARIANT;
  Scheme_Process_Id = (getpid ());
  Under_Emacs =
    ((Parse_Option ("-emacs", Saved_argc, Saved_argv, true)) != NOT_THERE);

  stdin_file_type =
    (((fstat ((fileno (stdin)), (& s))) != 0)
     ? '?'
     : (file_type_letter (& s)));
  stdin_is_a_kbd = (isatty (fileno (stdin)));
  stdout_is_a_crt = (isatty (fileno (stdout)));
  interactive_p = (Under_Emacs || (stdin_is_a_kbd && stdout_is_a_crt));

  initialize_process_clock ();
  initialize_real_time_clock ();
  initialize_scheme_signals ();
  initialize_scheme_keyboard ();
  initialize_terminal_description ();
  initialize_reader_state ();
  initialize_trap_recovery ((char *) (&ignore));

  /* Herald */

  printf ("MIT Scheme, %s [%s] version\n", OS_Name, OS_Variant);

  if (! interactive_p)
  {
    BREAK_TERMINAL_CONNECTION ();
  }
  else if (! Under_Emacs)
  {
    printf ("Type ");
    print_character_name (scheme_default_keyboard.quit, true);
    printf (" followed by `H' to obtain information about interrupts.\n");
  }
  OS_Flush_Output_Buffer ();

  OS_Re_Init ();
  return;
}

/* These procedures swap the terminal and signals from outside to
   scheme, and vice versa.  */

void
OS_Re_Init ()
{
  assassin_signal = 0;
  inhibit_termination_messages = false;
  if (stdin_is_a_kbd)
  {
    set_keyboard_characters(&saved_keyboard, &outside_keyboard);
    outside_keyboard_mask =
      OS_set_keyboard_interrupt_enables(saved_keyboard_mask);
  }
  hack_signals (scheme_signal_handlers,
		outside_signal_handlers,
		(stdin_is_a_kbd || Under_Emacs),
		true);
  if (stdout_is_a_crt)
  {
    HACK_CRT ((sg . sg_flags), ((sg . sg_flags) & (~ XTABS)));
  }
#if defined(HAS_VADVISE)
  vadvise (VA_ANOM);		/* Anomolous paging, don't try to guess. */
#endif
  return;
}

/* Use `TERM_HALT' if there is no natural value for `code'.  */

void
OS_Quit (code, abnormal_p)
     int code;
     Boolean abnormal_p;
{
  OS_Flush_Output_Buffer ();
  if (stdout_is_a_crt)
  {
    HACK_CRT (outside_crt_flags, outside_crt_flags);
  }
  hack_signals (outside_signal_handlers,
		scheme_signal_handlers,
		(stdin_is_a_kbd || Under_Emacs),
		false);
  if (stdin_is_a_kbd)
  {
    saved_keyboard_mask =
      OS_set_keyboard_interrupt_enables(outside_keyboard_mask);
    set_keyboard_characters(&outside_keyboard, &saved_keyboard);
  }
  if (abnormal_p && interactive_p && (code != TERM_SIGNAL))
  {
    printf ("\nScheme has terminated abnormally!\n");
    if ((confirm ("Would you like a core dump? [Y or N] ")) &&
	(confirm ("Do you really want a core dump? [Y or N] ")))
    {
      printf ("\n");
      dump_core ();
    }
    printf ("\n");
  }
  return;
}

/* Recovery from traps. */

#define STATE_UNKNOWN			MAKE_UNSIGNED_FIXNUM(0)
#define STATE_PRIMITIVE			MAKE_UNSIGNED_FIXNUM(1)
#define STATE_COMPILED_CODE		MAKE_UNSIGNED_FIXNUM(2)
#define STATE_PROBABLY_COMPILED		MAKE_UNSIGNED_FIXNUM(3)

struct trap_recovery_info
{
  Pointer state;
  Pointer pc_info_1;
  Pointer pc_info_2;
  Pointer extra_trap_info;
};

static struct trap_recovery_info
  dummy_recovery_info =
{
  STATE_UNKNOWN,
  SHARP_F,
  SHARP_F,
  SHARP_F
};

static char * initial_C_stack_pointer;

static void
initialize_trap_recovery (C_sp)
     char * C_sp;
{
  initial_C_stack_pointer = C_sp;
  return;
}

#if !defined(ABS)
#define ABS(x)	(((x) >= 0) ? (x) : (- (x)))
#endif

static void
setup_trap_frame (sig, info, new_stack_pointer)
     int sig;
     struct trap_recovery_info *info;
     Pointer *new_stack_pointer;
{
  long saved_mask;
  Boolean stack_recovered_p;
  Pointer handler, signal_name;

  if ((! (Valid_Fixed_Obj_Vector())) ||
      ((handler = (Get_Fixed_Obj_Slot(Trap_Handler))) == SHARP_F))
  {
    fprintf(stderr, "There is no trap handler for recovery!\n");
    Microcode_Termination(TERM_TRAP);
    /*NOTREACHED*/
  }

  saved_mask = FETCH_INTERRUPT_MASK();
  SET_INTERRUPT_MASK(0);	/* To prevent GC for now. */

  signal_name = ((sig == 0) ?
		 SHARP_F :
		 C_String_To_Scheme_String(find_signal_name(sig)));
  if (Free > MemTop)
  {
    Request_GC(0);
  }

  History = Make_Dummy_History();

  stack_recovered_p = (new_stack_pointer != ((Pointer *) NULL));
  if (! stack_recovered_p)
  {
    Initialize_Stack();
    Will_Push(CONTINUATION_SIZE);
     Store_Return(RC_END_OF_COMPUTATION);
     Store_Expression(SHARP_F);
     Save_Cont();
    Pushed();
  }
  else
  {
    Stack_Pointer = new_stack_pointer;
  }

 Will_Push((6 + CONTINUATION_SIZE) + (STACK_ENV_EXTRA_SLOTS + 2));
  Push(info->extra_trap_info);
  Push(info->pc_info_2);
  Push(info->pc_info_1);
  Push(info->state);
  Push(stack_recovered_p ? SHARP_T : SHARP_F);
  Push(signal_name);
  Store_Return(RC_HARDWARE_TRAP);
  Store_Expression(MAKE_SIGNED_FIXNUM(sig));
  Save_Cont();
  Push(signal_name);
  Push(handler);
  Push(STACK_FRAME_HEADER + 1);
 Pushed();
  SET_INTERRUPT_MASK(saved_mask);	/* Restore mask */
  longjmp(*Back_To_Eval, PRIM_APPLY);
  /* The following comment is by courtesy of LINT, your friendly sponsor. */
  /*NOTREACHED*/
}

/* 0 is an invalid signal, it means a user requested reset. */

static void
hard_reset (sig, scp)
     int sig;
     struct FULL_SIGCONTEXT *scp;
{
  static void continue_from_trap ();

  continue_from_trap (0, scp);
  /*NOTREACHED*/
}

/* Called synchronously. */

static void
soft_reset ()
{
  Pointer * new_stack_pointer;
  struct trap_recovery_info my_info;

  my_info.extra_trap_info = SHARP_F;
  new_stack_pointer = (((Stack_Pointer <= Stack_Top) &&
			(Stack_Pointer > Stack_Guard)) ?
		       Stack_Pointer :
		       ((Pointer *) NULL));
  if ((Regs[REGBLOCK_PRIMITIVE]) != SHARP_F)
  {
    my_info.state = STATE_PRIMITIVE;
    my_info.pc_info_1 = (Regs[REGBLOCK_PRIMITIVE]);
    my_info.pc_info_2 = MAKE_UNSIGNED_FIXNUM(Regs[REGBLOCK_LEXPR_ACTUALS]);
  }
  else
  {
    my_info.state = STATE_UNKNOWN;
    my_info.pc_info_1 = SHARP_F;
    my_info.pc_info_2 = SHARP_F;
  }

  if ((Free >= Heap_Top) || (Free < Heap_Bottom))
  {
    /* Let's hope this works. */
    Free = MemTop;
  }
  setup_trap_frame(0, &my_info, new_stack_pointer);
  /*NOTREACHED*/
}

#if !defined(HAS_SIGCONTEXT)

static void
continue_from_trap (sig, scp)
     int sig;
     struct FULL_SIGCONTEXT *scp;
{
  if (Free < MemTop)
  {
    Free = MemTop;
  }
  setup_trap_frame(sig, &dummy_recovery_info, ((Pointer *) NULL));
  /*NOTREACHED*/
}

#else /* HAS_SIGCONTEXT */

/* Heuristic recovery from Unix signals (traps).

   contine_from_trap attemps:

   1) to validate the trap information (pc and sp),
   2) to determine whether compiled code was executing, a primitive was
   executing, or execution was in the interpreter,
   3) guess what C global state is still valid, and
   4) set up a recovery frame for the interpreter so that debuggers can
   display more information.
 */

#include "gccode.h"

#define SCHEME_ALIGNMENT_MASK		(sizeof(long) - 1)
#define STACK_ALIGNMENT_MASK		SCHEME_ALIGNMENT_MASK
#define PC_ALIGNMENT_MASK		(sizeof(machine_word) - 1)
#define FREE_PARANOIA_MARGIN		0x100

#define C_STACK_SIZE			0x01000000

#if defined(CMPGCFILE)
#define ALLOW_ONLY_C			false
#else
#define ALLOW_ONLY_C			true
#define PLAUSIBLE_CC_BLOCK_P(block)	false
#endif

static void
continue_from_trap (sig, scp)
     int sig;
     struct FULL_SIGCONTEXT *scp;
{
  Boolean
    sp_in_C, sp_in_scheme, sp_in_hyper_space,
    pc_in_C, pc_in_heap, pc_in_constant_space,
    pc_in_scheme, pc_in_hyper_space;
  long
    the_pc, the_sp;
  Pointer
    *new_stack_pointer, *xtra_info;
  int
    counter, *regs;
  struct trap_recovery_info my_info;
  extern long etext;

  the_pc = FULL_SIGCONTEXT_PC (scp);
  the_sp = FULL_SIGCONTEXT_SP (scp);

  if ((the_pc & PC_ALIGNMENT_MASK) != 0)
  {
    pc_in_C = pc_in_heap = pc_in_constant_space = false;
  }
  else
  {
    pc_in_C = (the_pc <= ((long) (&etext)));
    pc_in_heap = ((the_pc < ((long) Heap_Top)) &&
		  (the_pc >= ((long) Heap_Bottom)));
    pc_in_constant_space = ((the_pc < ((long) Constant_Top)) &&
			    (the_pc >= ((long) Constant_Space)));
  }
  pc_in_scheme = (pc_in_heap || pc_in_constant_space);
  pc_in_hyper_space = ((!pc_in_C) && (!pc_in_scheme));

  sp_in_scheme = ((the_sp < ((long) Stack_Top))		&&
		  (the_sp >= ((long) Absolute_Stack_Base))	&&
		  ((the_sp & STACK_ALIGNMENT_MASK) == 0));
  sp_in_C = ((! sp_in_scheme) &&
	     ((ABS (((char *) the_sp) - (initial_C_stack_pointer))) <
	      (C_STACK_SIZE)));
  sp_in_hyper_space = ((!sp_in_scheme) && (!sp_in_C));

  if (sp_in_C)
  {
    new_stack_pointer = (((Stack_Pointer < Stack_Top) &&
			  (Stack_Pointer > Absolute_Stack_Base)) ?
			 Stack_Pointer :
			 ((Pointer *) NULL));
  }
  else
  {
    new_stack_pointer = (sp_in_hyper_space ?
			 ((Pointer *) NULL) :
			 ((Pointer *) the_sp));
  }

  if ((sp_in_hyper_space && pc_in_hyper_space) ||
      (ALLOW_ONLY_C && pc_in_scheme))
  {
    /* In hyper space. */

    my_info.state = STATE_UNKNOWN;
    my_info.pc_info_1 = SHARP_F;
    my_info.pc_info_2 = SHARP_F;
    new_stack_pointer = ((Pointer *) NULL);
    if ((Free < MemTop) ||
	(Free >= Heap_Top) ||
	((((unsigned long) Free) & SCHEME_ALIGNMENT_MASK) != 0))
    {
      Free = MemTop;
    }
  }
  else if (pc_in_scheme)
  {
    /* In compiled code. */

    long offset;
    Pointer block, *block_addr, *maybe_free;
    static Pointer * find_block_address ();

    block_addr =
      find_block_address(the_pc, (pc_in_heap ? Heap_Bottom : Constant_Space));
    if (block_addr == ((Pointer *) NULL))
    {
      my_info.state = STATE_PROBABLY_COMPILED;
      my_info.pc_info_1 = Make_Non_Pointer(TC_ADDRESS, the_pc);
      my_info.pc_info_2 = SHARP_F;
      if ((Free < MemTop) ||
	  (Free >= Heap_Top) ||
	  ((((unsigned long) Free) & SCHEME_ALIGNMENT_MASK) != 0))
      {
	Free = MemTop;
      }
    }

    else
    {
      my_info.state = STATE_COMPILED_CODE;
      my_info.pc_info_1 = Make_Pointer(TC_COMPILED_CODE_BLOCK, block_addr);
      my_info.pc_info_2 = MAKE_UNSIGNED_FIXNUM(the_pc - ((long) block_addr));

#if defined(HAS_FULL_SIGCONTEXT)

      maybe_free = ((Pointer *) FULL_SIGCONTEXT_RFREE (scp));
      if (((((unsigned long) maybe_free) & SCHEME_ALIGNMENT_MASK) == 0) &&
	  (maybe_free >= Heap_Bottom) &&
	  (maybe_free < Heap_Top))
      {
	Free = (maybe_free + FREE_PARANOIA_MARGIN);
      }
      else

#endif
      if ((Free < MemTop) ||
	  (Free >= Heap_Top) ||
	  ((((unsigned long) Free) & SCHEME_ALIGNMENT_MASK) != 0))
      {
	Free = MemTop;
      }
    }
  }
  else

  {
    /* In the interpreter, a primitive, or a compiled code utility. */

    Pointer primitive;

    primitive = Regs[REGBLOCK_PRIMITIVE];
    if (OBJECT_TYPE(primitive) != TC_PRIMITIVE)
    {
      my_info.state = STATE_UNKNOWN;
      my_info.pc_info_1 = SHARP_F;
      my_info.pc_info_2 = SHARP_F;
      if (sp_in_scheme)
      {
	new_stack_pointer = ((Pointer *) NULL);
      }
    }
    else
    {
      long primitive_address;

      primitive_address =
	((long) Primitive_Procedure_Table[OBJECT_DATUM(primitive)]);

      my_info.state = STATE_PRIMITIVE;
      my_info.pc_info_1 = primitive;
      my_info.pc_info_2 = MAKE_UNSIGNED_FIXNUM(Regs[REGBLOCK_LEXPR_ACTUALS]);
      if (sp_in_scheme)
      {
	/* Called from compiled code */

	if (new_stack_pointer > Stack_Pointer)
	{
	  new_stack_pointer = ((Pointer *) NULL);
	}
	else if (new_stack_pointer != ((Pointer *) NULL))
	{
	  new_stack_pointer = Stack_Pointer;
	}
      }
    }
    if ((! sp_in_C) ||
	((((unsigned long) Free) & SCHEME_ALIGNMENT_MASK) != 0) ||
	((Free < Heap_Bottom) || (Free >= Heap_Top)))
    {
      Free = MemTop;
    }
  }

  xtra_info = Free;
  Free += (1 + 2 + PROCESSOR_NREGS);
  my_info.extra_trap_info =
    Make_Pointer(TC_NON_MARKED_VECTOR, xtra_info);
  *xtra_info++ =
    Make_Non_Pointer(TC_MANIFEST_NM_VECTOR, (2 + PROCESSOR_NREGS));
  *xtra_info++ = ((Pointer) the_pc);
  *xtra_info++ = ((Pointer) the_sp);

  for (counter = FULL_SIGCONTEXT_NREGS,
       regs = FULL_SIGCONTEXT_FIRST_REG(scp);
       counter > 0;
       counter -= 1)
  {
    *xtra_info++ = ((Pointer) (*regs++));
  }
  /*
    We assume that regs,sp,pc is the order in the processor.
    Scheme can always fix this.
   */
  if ((PROCESSOR_NREGS - FULL_SIGCONTEXT_NREGS) > 0)
  {
    *xtra_info++ = ((Pointer) the_sp);
  }
  if ((PROCESSOR_NREGS - FULL_SIGCONTEXT_NREGS) > 1)
  {
    *xtra_info++ = ((Pointer) the_pc);
  }
  setup_trap_frame(sig, &my_info, new_stack_pointer);
  /*NOTREACHED*/
}

/*
  Finds the compiled code block in area which contains pc value pc_value, by
  scanning sequentially the complete area.
  For the time being it skips over manifest closures and linkage sections.
 */

static Pointer *
find_block_address_in_area (pc_value, area_start)
     register machine_word *pc_value;
     Pointer *area_start;
{
  register long count;
  register Pointer *area, object;
  Pointer *first_valid;

  first_valid = area_start;

  for (area = area_start ; ((machine_word *) area) < pc_value; area += 1)
  {
    object = *area;
    switch(OBJECT_TYPE(object))
    {
      case TC_LINKAGE_SECTION:
	if (READ_LINKAGE_KIND(object) != OPERATOR_LINKAGE_KIND)
	{
	  area += READ_CACHE_LINKAGE_COUNT(object);
	}
	else
	{
	  count = READ_OPERATOR_LINKAGE_COUNT(object);
	  area = END_OPERATOR_LINKAGE_AREA(area, count);
	}
	break;

      case TC_MANIFEST_CLOSURE:
      {
	register machine_word *word_ptr, *start_ptr;

	area += 1;
	start_ptr = FIRST_MANIFEST_CLOSURE_ENTRY(area);
	word_ptr = start_ptr;
	while (VALID_MANIFEST_CLOSURE_ENTRY(word_ptr))
	{
	  word_ptr = NEXT_MANIFEST_CLOSURE_ENTRY(word_ptr);
	}
	area = MANIFEST_CLOSURE_END(word_ptr, start_ptr);
	break;
      }

      case TC_MANIFEST_NM_VECTOR:
      {
	register Pointer *block;

        count = OBJECT_DATUM(object);
	if (((machine_word *) (&area[count + 1])) < pc_value)
	{
	  area += count;
	  first_valid = &area[1];
	  break;
	}
	block = &area[-1];
	if ((area == first_valid)				||
	    ((OBJECT_TYPE(*block)) != TC_MANIFEST_VECTOR)	||
	    ((OBJECT_DATUM(*block)) < (count + 1))		||
	    (!PLAUSIBLE_CC_BLOCK_P(block)))
	{
	  return ((Pointer *) NULL);
	}
	else
	{
	  return (block);
	}
	break;
      }

      default:
	break;
    }
  }
  return ((Pointer *) NULL);
}

/*
  Finds the compiled code block in area which contains pc value pc_value.
  This attempts to save some work over calling find_block_address_in_area
  directly.  If the pointer is in the heap, it can actually do twice as
  much work, but it is expected to pay off on the average.
 */

#define MINIMUM_SCAN_RANGE		2048

static Pointer *
find_block_address (pc_value, area_start)
     register machine_word *pc_value;
     register Pointer *area_start;
{
  if (area_start == Constant_Space)
  {
    extern Pointer * find_constant_space_block ();
    register Pointer * constant_block;
    
    constant_block = (find_constant_space_block
		      (((Pointer *) (((unsigned long) pc_value) &
				     (~(SCHEME_ALIGNMENT_MASK))))));
    return ((constant_block == ((Pointer *) NULL)) ?
	    ((Pointer *) NULL) :
	    (find_block_address_in_area (pc_value, constant_block)));
  }
  else	/* in heap */
  {
    Pointer * nearest_word, * block;
    long maximum_distance, distance;

    nearest_word = ((Pointer *) (((unsigned long) pc_value) &
				 (~(SCHEME_ALIGNMENT_MASK))));
    maximum_distance = (nearest_word - area_start);
    distance = maximum_distance;
    while ((distance / 2) > MINIMUM_SCAN_RANGE)
    {
      distance = (distance / 2);
    }
    while ((distance * 2) < maximum_distance)
    {
      block = (find_block_address_in_area (pc_value,
					   (nearest_word - distance)));
      if (block != ((Pointer *) NULL))
      {
	return (block);
      }
      distance *= 2;
    }
    /* Oh well. */
    return (find_block_address_in_area (pc_value, area_start));
  }
}
#endif /* HAS_SIGCONTEXT */

#if defined(sun3)

/*
   This code assumes that it is called very soon, before
   any registers except fp have been clobbered.

   It also assumes that it is called directly by the
   handler, so that the original fp can be found
   by indirecting through fp twice.

   The trampoline routine saves d0, d1, a0, and a1
   before invoking the handler.

   The magic constant of 276 was found by poking with adb.
 */

static void
sun3_save_regs (regs)
     int *regs;
{
  asm("\n\
	movel	a6@(8),a0\n\
	movel	a6@,a1\n\
\n\
	movel	a1@(276),a0@\n\
	movel	a1@(280),a0@(4)\n\
	movel	d2,a0@(8)\n\
	movel	d3,a0@(12)\n\
	movel	d4,a0@(16)\n\
	movel	d5,a0@(20)\n\
	movel	d6,a0@(24)\n\
	movel	d7,a0@(28)\n\
\n\
	movel	a1@(284),a0@(32)\n\
	movel	a1@(288),a0@(36)\n\
	movel	a2,a0@(40)\n\
	movel	a3,a0@(44)\n\
	movel	a4,a0@(48)\n\
	movel	a5,a0@(52)\n\
	movel	a1@,a0@(56)\n\
	");
  return;
}

#endif /* sun3 */

#if defined(vax)

/* This is a kludge. It relies on r0 being the return value register. */

static int
vax_get_r0 ()
{
  asm("ret");
}

static int *
vax_save_start (regs, r0)
     int *regs;
     int r0;
{
  asm("movl	fp,-(sp)");
  asm("movl	4(ap),fp");
  asm("movl	8(ap),(fp)");
  asm("movl	r1,4(fp)");
  asm("movl	r2,8(fp)");
  asm("movl	r3,12(fp)");
  asm("movl	r4,16(fp)");
  asm("movl	r5,20(fp)");
  asm("movl	r6,24(fp)");
  asm("movl	r7,28(fp)");
  asm("movl	r8,32(fp)");
  asm("movl	r9,36(fp)");
  asm("movl	r10,40(fp)");
  asm("movl	r11,44(fp)");
  asm("movl	(sp)+,fp");
  asm("movl	12(fp),r0");
  asm("ret");
}

#define FRAME_SAVED_REGS(fp)	((unsigned long) ((fp[1] >> 16) & 0x0fff))
#define FRAME_REGS_OFFSET	5

static void
vax_save_finish (fp, partial, full)
     int *fp;
     struct sigcontext *partial;
     struct full_sigcontext *full;
{
  int reg_number, stack_index;
  unsigned long reg_mask;

  full->fs_original = partial;
#if !defined(ULTRIX)
  /* For now, ap and fp undefined. */
  full->fs_regs[12] = partial->sc_ap;
  full->fs_regs[13] = partial->sc_fp;
#endif
  full->fs_regs[14] = partial->sc_sp;
  full->fs_regs[15] = partial->sc_pc;

  reg_number = 0;
  reg_mask = FRAME_SAVED_REGS(fp);
  stack_index = FRAME_REGS_OFFSET;
  while (reg_mask != 0)
  {
    if ((reg_mask & 1) != 0)
    {
      full->fs_regs[reg_number] = fp[stack_index++];
    }
    reg_number += 1;
    reg_mask = ((reg_mask >> 1) & 0x0fff);
  }
  return;
}

#endif /* vax */
