/* -*-C-*-

$Header: cterm.c,v 1.2 89/06/16 09:38:40 GMT cph Rel $

Copyright (c) 1989 Massachusetts Institute of Technology

This material was developed by the Scheme project at the Massachusetts
Institute of Technology, Department of Electrical Engineering and
Computer Science.  Permission to copy this software, to redistribute
it, and to use it for any purpose is granted, subject to the following
restrictions and understandings.

1. Any copy made of this software must include this copyright notice
in full.

2. Users of this software agree to make their best efforts (a) to
return to the MIT Scheme project any improvements or extensions that
they make, so that these may be included in future releases; and (b)
to inform MIT of noteworthy uses of this software.

3. All materials developed as a consequence of the use of this
software shall duly acknowledge such use, in accordance with the usual
standards of acknowledging credit in academic research.

4. MIT has made no warrantee or representation that the operation of
this software will be error-free, and MIT is under no obligation to
provide any services, by way of maintenance, update, or otherwise.

5. In conjunction with products arising from the use of this material,
there shall be no use of the name of the Massachusetts Institute of
Technology nor of any adaptation thereof in any advertising,
promotional, or sales literature without prior written consent from
MIT in each case. */

/* curses(3) terminal for Edwin. */

#include "scheme.h"
#include "prims.h"
#include "string.h"
#include <curses.h>

#ifdef hpux
#define HAS_HAIRY_CURSES
#endif

#define CURSES_CHECK(value)						\
{									\
  if ((value) == ERR)							\
    error_external_return();						\
}

#define CURSES_NOCHECK(value)	(value)

/* Missing functionality */

void
curses_setup_term()
{
  nonl();
  noecho();
  raw();
  return;
}

#ifndef HAS_HAIRY_CURSES

void
fixterm()
{
  noraw();
  echo();
  nl();
  return;
}

#define resetterm() curses_setup_term()

extern void OS_tty_beep();

#define beep() OS_tty_beep()
#define idlok(win, flag)
#define meta(win, flag)

#endif

#define FLAG_SCROLLOK	1
#define FLAG_IDLOK	2
#define FLAG_META	4

extern long OS_set_keyboard_interrupt_enables();

long
curses_set_flags(flags)
     long flags;
{
  static long curses_flags = 0;
  long old_flags, old_state;
  
  /* For some reason the calls below affect the keyboard state. */

  old_state = OS_set_keyboard_interrupt_enables(0);

  scrollok(stdscr, ((flags & FLAG_SCROLLOK) != 0));
  idlok(stdscr, ((flags & FLAG_IDLOK) != 0));
  meta(stdscr, ((flags & FLAG_META) != 0));

  OS_set_keyboard_interrupt_enables(old_state);

  old_flags = curses_flags;
  curses_flags = flags;

  return(old_flags);
}

DEFINE_PRIMITIVE("CURSES-INITIALIZE", Prim_curses_initialize, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  if (initscr() != ((WINDOW *) ERR))
  {
    curses_setup_term();
    curses_set_flags(FLAG_SCROLLOK | FLAG_META); /* idlok seems broken. */
    PRIMITIVE_RETURN (TRUTH);
  }
  else
  {
    PRIMITIVE_RETURN (NIL);
  }
}

DEFINE_PRIMITIVE("CURSES-RESET", Prim_curses_reset, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  resetterm();
  endwin();
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-SUSPEND", Prim_curses_suspend, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  resetterm();
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-RESUME", Prim_curses_resume, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  fixterm();
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-X-SIZE", Prim_curses_x_size, 0, 0, 0)
{
  PRIMITIVE_HEADER (0);
  PRIMITIVE_RETURN (MAKE_UNSIGNED_FIXNUM(COLS));
}

DEFINE_PRIMITIVE("CURSES-Y-SIZE", Prim_curses_y_size, 0, 0, 0)
{
  PRIMITIVE_HEADER (0);
  PRIMITIVE_RETURN (MAKE_UNSIGNED_FIXNUM(LINES));
}

DEFINE_PRIMITIVE("CURSES-REFRESH", Prim_curses_refresh, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_NOCHECK (refresh());
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-TOUCHWIN", Prim_curses_touchwin, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_NOCHECK (touchwin(stdscr));
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-CLEAR", Prim_curses_clear, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_NOCHECK (clear());
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-CLRTOBOT", Prim_curses_clrtobot, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_NOCHECK (clrtobot());
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-CLRTOEOL", Prim_curses_clrtoeol, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_NOCHECK (clrtoeol());
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-DELCH", Prim_curses_delch, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_CHECK (delch());
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-STANDOUT", Prim_curses_standout, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_NOCHECK (standout());
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-STANDEND", Prim_curses_standend, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_NOCHECK (standend());
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-ADDCH", Prim_curses_addch, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);
  CURSES_CHECK (addch(arg_ascii_char (1)));
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-ADDSTR", Prim_curses_addstr, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);
  CURSES_CHECK (addstr(STRING_ARG(1)));
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-INSCH", Prim_curses_insch, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);
  CURSES_CHECK (insch(arg_ascii_char (1)));
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-MOVE", Prim_curses_move, 2, 2, 0)
{
  PRIMITIVE_HEADER (2);
  CURSES_CHECK (move(arg_fixnum(1), arg_fixnum(2)));
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-MVADDCH", Prim_curses_mvaddch, 3, 3, 0)
{
  PRIMITIVE_HEADER (3);
  CURSES_CHECK (mvaddch(arg_fixnum(1), arg_fixnum(2), arg_ascii_char (3)));
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-MVADDSTR", Prim_curses_mvaddstr, 3, 3, 0)
{
  PRIMITIVE_HEADER (3);
  CURSES_CHECK (mvaddstr(arg_fixnum(1), arg_fixnum(2), STRING_ARG(3)));
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-MVADDSUBSTR", Prim_curses_mvaddsubstr, 5, 5, 0)
{
  Pointer string;
  char saved, *string_start, *string_end;
  long y, x, end, start, length, result;
  PRIMITIVE_HEADER (5);

  y = (arg_fixnum(1));
  x = (arg_fixnum(2));
  CHECK_ARG (3, STRING_P);
  string = (ARG_REF (3));
  end = (arg_index_integer (5, ((string_length (string)) + 1)));
  start = (arg_index_integer (4, (end + 1)));
  length = (end - start);
  string_start = (string_pointer (string, start));
  string_end = (string_pointer (string, end));
  
  /* This is a kludge, but... */

  saved = *string_end;
  *string_end = '\0';
  result = mvaddstr(y, x, string_start);
  *string_end = saved;

  CURSES_CHECK (result);
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-BEEP", Prim_curses_beep, 0, 0, 0)
{
  PRIMITIVE_HEADER(0);
  CURSES_NOCHECK (beep());
  PRIMITIVE_RETURN (UNSPECIFIC);
}

DEFINE_PRIMITIVE("CURSES-SET-FLAGS!", Prim_curses_set_flags, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);
  PRIMITIVE_RETURN (MAKE_UNSIGNED_FIXNUM (curses_set_flags (arg_fixnum (1))));
}
