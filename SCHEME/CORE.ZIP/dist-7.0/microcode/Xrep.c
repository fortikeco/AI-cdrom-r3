/* -*-C-*-

$Header: Xrep.c,v 1.4 88/08/15 20:35:18 GMT cph Rel $

Copyright (c) 1987, 1988 Massachusetts Institute of Technology

This material was developed by the Scheme project at the Massachusetts
Institute of Technology, Department of Electrical Engineering and
Computer Science.  Permission to copy this software, to redistribute
it, and to use it for any purpose is granted, subject to the following
restrictions and understandings.

1. Any copy made of this software must include this copyright notice
in full.

2. Users of this software agree to make their best efforts (a) to
return to the MIT Scheme project any improvements or extensions that
they make, so that these may be included in future releases; and (b)
to inform MIT of noteworthy uses of this software.

3. All materials developed as a consequence of the use of this
software shall duly acknowledge such use, in accordance with the usual
standards of acknowledging credit in academic research.

4. MIT has made no warrantee or representation that the operation of
this software will be error-free, and MIT is under no obligation to
provide any services, by way of maintenance, update, or otherwise.

5. In conjunction with products arising from the use of this material,
there shall be no use of the name of the Massachusetts Institute of
Technology nor of any adaptation thereof in any advertising,
promotional, or sales literature without prior written consent from
MIT in each case. */

/* Xlib Interface Data Representations */

#include "scheme.h"
#include "prims.h"
#include "Xlib.h"

Pointer
resource_to_object (resource)
     fast long resource;
{
  if (resource == 0)
    return (SHARP_F);
  else if (((unsigned long) resource) <= ADDRESS_MASK)
    return (MAKE_UNSIGNED_FIXNUM ((unsigned long) resource));
  else
    {
      fast Pointer result;

      result = (Make_Pointer (TC_NON_MARKED_VECTOR, Free));
      (*Free++) = (Make_Non_Pointer (TC_MANIFEST_NM_VECTOR, 1));
      (*Free++) = ((Pointer) resource);
      return (result);
    }
}

long
resource_arg (argument_number)
     int argument_number;
{
  fast Pointer object;

  object = (ARG_REF (argument_number));
  if (object == SHARP_F)
    return (0);
  if (FIXNUM_P (object))
    return (UNSIGNED_FIXNUM_VALUE (object));
  if ((NON_MARKED_VECTOR_P (object)) && ((Vector_Length (object)) == 1))
    return ((long) (Fast_Vector_Ref (object, 1)));
  error_wrong_type_arg (argument_number);
}

char *
xstruct_arg (length, argument_number)
     int argument_number, length;
{
  fast Pointer object;

  object = (ARG_REF (argument_number));
  if ((NON_MARKED_VECTOR_P (object)) && ((Vector_Length (object)) == length))
    return ((char *) (Nth_Vector_Loc (object, 1)));
  error_wrong_type_arg (argument_number);
}

Pointer
pair_cons (car, cdr, gc_check_p)
     Pointer car, cdr;
     Boolean gc_check_p;
{
  fast Pointer result;

  result = (Make_Pointer (TC_LIST, Free));
  (*Free++) = car;
  (*Free++) = cdr;
  return (result);
}

DEFINE_PRIMITIVE ("X-OBJECT=?", Prim_x_display_equal_p, 2, 2, 0)
{
  register Pointer object1, object2;
  PRIMITIVE_HEADER (2);

  object1 = (ARG_REF (1));
  object2 = (ARG_REF (2));

  if (object1 == object2)
    PRIMITIVE_RETURN (SHARP_T);

  CHECK_ARG (1, NON_MARKED_VECTOR_P);
  CHECK_ARG (2, NON_MARKED_VECTOR_P);

  PRIMITIVE_RETURN
    (BOOLEAN_TO_OBJECT
     (((Vector_Length (object1)) == 1) &&
      ((Vector_Length (object2)) == 1) &&
      ((Fast_Vector_Ref (object1, 1)) == (Fast_Vector_Ref (object2, 1)))));
}

/* Display Representation */

/* This is not an advertised data structure.  Use it at your own risk. */

DEFINE_PRIMITIVE ("X-DISPLAY->ROOT", Prim_x_display_to_root, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, root, XWINDOW_VALUE); }

DEFINE_PRIMITIVE ("X-DISPLAY->VNUMBER", Prim_x_display_to_vnumber, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, vnumber, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY->DTYPE", Prim_x_display_to_dtype, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, dtype, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY->DPLANES", Prim_x_display_to_dplanes, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, dplanes, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY->DCELLS", Prim_x_display_to_dcells, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, dcells, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY->QLEN", Prim_x_display_to_qlen, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, qlen, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY->BLACK", Prim_x_display_to_black, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, black, XPIXMAP_VALUE); }

DEFINE_PRIMITIVE ("X-DISPLAY->WHITE", Prim_x_display_to_white, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, white, XPIXMAP_VALUE); }

DEFINE_PRIMITIVE ("X-DISPLAY->DISPLAYNAME", Prim_x_display_to_displayname, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, displayname, STRING_VALUE); }

DEFINE_PRIMITIVE ("X-DISPLAY->WIDTH", Prim_x_display_to_width, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, width, long_to_object); }

DEFINE_PRIMITIVE ("X-DISPLAY->HEIGHT", Prim_x_display_to_height, 1, 1, 0)
{ STRUCT_SELECTOR (XDISPLAY_ARG, height, long_to_object); }

/* OpaqueFrame Representation */

DEFINE_PRIMITIVE ("X-MAKE-OPAQUE-FRAME", Prim_x_make_opaque_frame, 7, 7, 0)
{
  fast Pointer result;
  fast OpaqueFrame *frame;
  PRIMITIVE_HEADER (7);

  result = (X_OPAQUE_FRAME_ALLOCATE (true));
  frame = (X_OPAQUE_FRAME_DESCRIPTOR (result));
  (frame -> self) = UNDEFINED_RESOURCE;
  (frame -> x) = (FIXNUM_ARG (1));
  (frame -> y) = (FIXNUM_ARG (2));
  (frame -> width) = (FIXNUM_ARG (3));
  (frame -> height) = (FIXNUM_ARG (4));
  (frame -> bdrwidth) = (FIXNUM_ARG (5));
  (frame -> border) = (XPIXMAP_ARG (6));
  (frame -> background) = (XPIXMAP_ARG (7));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-OPAQUE-FRAME->SELF", Prim_x_opaqframe_to_self, 1, 1, 0)
{ STRUCT_SELECTOR (X_OPAQUE_FRAME_ARG, self, XWINDOW_VALUE); }

DEFINE_PRIMITIVE ("X-OPAQUE-FRAME->X", Prim_x_opaqframe_to_x, 1, 1, 0)
{ STRUCT_SELECTOR (X_OPAQUE_FRAME_ARG, x, MAKE_FIXNUM); }

DEFINE_PRIMITIVE ("X-OPAQUE-FRAME->Y", Prim_x_opaqframe_to_y, 1, 1, 0)
{ STRUCT_SELECTOR (X_OPAQUE_FRAME_ARG, y, MAKE_FIXNUM); }

DEFINE_PRIMITIVE ("X-OPAQUE-FRAME->WIDTH", Prim_x_opaqframe_to_width, 1, 1, 0)
{ STRUCT_SELECTOR (X_OPAQUE_FRAME_ARG, width, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-OPAQUE-FRAME->HEIGHT", Prim_x_opaqframe_to_height, 1, 1, 0)
{ STRUCT_SELECTOR (X_OPAQUE_FRAME_ARG, height, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-OPAQUE-FRAME->BORDER-WIDTH", Prim_x_opaqframe_to_bdrwidth, 1, 1, 0)
{ STRUCT_SELECTOR (X_OPAQUE_FRAME_ARG, bdrwidth, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-OPAQUE-FRAME->BORDER", Prim_x_opaqframe_to_border, 1, 1, 0)
{ STRUCT_SELECTOR (X_OPAQUE_FRAME_ARG, border, XPIXMAP_VALUE); }

DEFINE_PRIMITIVE ("X-OPAQUE-FRAME->BACKGROUND", Prim_x_opaqframe_to_background, 1, 1, 0)
{ STRUCT_SELECTOR (X_OPAQUE_FRAME_ARG, background, XPIXMAP_VALUE); }

/* TransparentFrame Representation */

DEFINE_PRIMITIVE ("X-MAKE-TRANSPARENT-FRAME", Prim_x_make_transparent_frame, 4, 4, 0)
{
  fast Pointer result;
  fast TransparentFrame *frame;
  PRIMITIVE_HEADER (4);

  result = (X_TRANSPARENT_FRAME_ALLOCATE (true));
  frame = (X_TRANSPARENT_FRAME_DESCRIPTOR (result));
  (frame -> self) = UNDEFINED_RESOURCE;
  (frame -> x) = (FIXNUM_ARG (1));
  (frame -> y) = (FIXNUM_ARG (2));
  (frame -> width) = (FIXNUM_ARG (3));
  (frame -> height) = (FIXNUM_ARG (4));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-TRANSPARENT-FRAME->SELF", Prim_x_transpframe_to_self, 1, 1, 0)
{ STRUCT_SELECTOR (X_TRANSPARENT_FRAME_ARG, self, XWINDOW_VALUE); }

DEFINE_PRIMITIVE ("X-TRANSPARENT-FRAME->X", Prim_x_transpframe_to_x, 1, 1, 0)
{ STRUCT_SELECTOR (X_TRANSPARENT_FRAME_ARG, x, MAKE_FIXNUM); }

DEFINE_PRIMITIVE ("X-TRANSPARENT-FRAME->Y", Prim_x_transpframe_to_y, 1, 1, 0)
{ STRUCT_SELECTOR (X_TRANSPARENT_FRAME_ARG, y, MAKE_FIXNUM); }

DEFINE_PRIMITIVE ("X-TRANSPARENT-FRAME->WIDTH", Prim_x_transpframe_to_width, 1, 1, 0)
{ STRUCT_SELECTOR (X_TRANSPARENT_FRAME_ARG, width, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-TRANSPARENT-FRAME->HEIGHT", Prim_x_transpframe_to_height, 1, 1, 0)
{ STRUCT_SELECTOR (X_TRANSPARENT_FRAME_ARG, height, MAKE_UNSIGNED_FIXNUM); }

/* BatchFrame Representation */

DEFINE_PRIMITIVE ("X-MAKE-BATCH-FRAME", Prim_x_make_batch_frame, 9, 9, 0)
{
  fast Pointer result;
  fast BatchFrame *frame;
  PRIMITIVE_HEADER (9);

  result = (X_BATCH_FRAME_ALLOCATE (true));
  frame = (X_BATCH_FRAME_DESCRIPTOR (result));
  (frame -> type) = (FIXNUM_ARG (1));
  (frame -> parent) = (XWINDOW_ARG (2));
  (frame -> self) = UNDEFINED_RESOURCE;
  (frame -> x) = (FIXNUM_ARG (3));
  (frame -> y) = (FIXNUM_ARG (4));
  (frame -> width) = (FIXNUM_ARG (5));
  (frame -> height) = (FIXNUM_ARG (6));
  (frame -> bdrwidth) = (FIXNUM_ARG (7));
  (frame -> border) = (XPIXMAP_ARG (8));
  (frame -> background) = (XPIXMAP_ARG (9));
  PRIMITIVE_RETURN (result);
}

DEFINE_PRIMITIVE ("X-BATCH-FRAME-TYPE", Prim_x_batchframe_type, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, type, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME-PARENT", Prim_x_batchframe_parent, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, parent, XWINDOW_VALUE); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME-SELF", Prim_x_batchframe_self, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, self, XWINDOW_VALUE); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME->X", Prim_x_batchframe_to_x, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, x, MAKE_FIXNUM); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME->Y", Prim_x_batchframe_to_y, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, y, MAKE_FIXNUM); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME->WIDTH", Prim_x_batchframe_to_width, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, width, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME->HEIGHT", Prim_x_batchframe_to_height, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, height, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME->BORDER-WIDTH", Prim_x_batchframe_to_bdrwidth, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, bdrwidth, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME->BORDER", Prim_x_batchframe_to_border, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, border, XPIXMAP_VALUE); }

DEFINE_PRIMITIVE ("X-BATCH-FRAME->BACKGROUND", Prim_x_batchframe_to_background, 1, 1, 0)
{ STRUCT_SELECTOR (X_BATCH_FRAME_ARG, background, XPIXMAP_VALUE); }

/* WindowInfo Representation */

DEFINE_PRIMITIVE ("X-WINDOW-INFO->WIDTH", Prim_x_window_info_to_width, 1, 1, 0)
{ STRUCT_SELECTOR (X_WINDOW_INFO_ARG, width, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-WINDOW-INFO->HEIGHT", Prim_x_window_info_to_height, 1, 1, 0)
{ STRUCT_SELECTOR (X_WINDOW_INFO_ARG, height, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-WINDOW-INFO->X", Prim_x_window_info_to_x, 1, 1, 0)
{ STRUCT_SELECTOR (X_WINDOW_INFO_ARG, x, MAKE_FIXNUM); }

DEFINE_PRIMITIVE ("X-WINDOW-INFO->Y", Prim_x_window_info_to_y, 1, 1, 0)
{ STRUCT_SELECTOR (X_WINDOW_INFO_ARG, y, MAKE_FIXNUM); }

DEFINE_PRIMITIVE ("X-WINDOW-INFO->BORDER-WIDTH", Prim_x_window_info_to_border_width, 1, 1, 0)
{ STRUCT_SELECTOR (X_WINDOW_INFO_ARG, width, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-WINDOW-INFO->MAPPED", Prim_x_window_info_to_mapped, 1, 1, 0)
{ STRUCT_SELECTOR (X_WINDOW_INFO_ARG, mapped, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-WINDOW-INFO->TYPE", Prim_x_window_info_to_type, 1, 1, 0)
{ STRUCT_SELECTOR (X_WINDOW_INFO_ARG, type, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-WINDOW-INFO->ASSOC-WINDOW", Prim_x_window_info_to_assoc_wind, 1, 1, 0)
{ STRUCT_SELECTOR (X_WINDOW_INFO_ARG, assoc_wind, XWINDOW_VALUE); }

/* Color Representation */

DEFINE_PRIMITIVE ("X-COLOR->PIXEL", Prim_x_color_to_pixel, 1, 1, 0)
{ STRUCT_SELECTOR (X_COLOR_ARG, pixel, long_to_object); }

DEFINE_PRIMITIVE ("X-COLOR->RED", Prim_x_color_to_red, 1, 1, 0)
{ STRUCT_SELECTOR (X_COLOR_ARG, red, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-COLOR->GREEN", Prim_x_color_to_green, 1, 1, 0)
{ STRUCT_SELECTOR (X_COLOR_ARG, green, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-COLOR->BLUE", Prim_x_color_to_blue, 1, 1, 0)
{ STRUCT_SELECTOR (X_COLOR_ARG, blue, MAKE_UNSIGNED_FIXNUM); }


/* FontInfo Representation */

DEFINE_PRIMITIVE ("X-FONT-INFO->ID", Prim_x_fontinfo_to_id, 1, 1, 0)
{ STRUCT_SELECTOR (X_FONT_INFO_ARG, id, XFONT_VALUE); }

DEFINE_PRIMITIVE ("X-FONT-INFO->HEIGHT", Prim_x_fontinfo_to_height, 1, 1, 0)
{ STRUCT_SELECTOR (X_FONT_INFO_ARG, height, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-FONT-INFO->WIDTH", Prim_x_fontinfo_to_width, 1, 1, 0)
{ STRUCT_SELECTOR (X_FONT_INFO_ARG, width, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-FONT-INFO->BASELINE", Prim_x_fontinfo_to_baseline, 1, 1, 0)
{ STRUCT_SELECTOR (X_FONT_INFO_ARG, baseline, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-FONT-INFO->FIXEDWIDTH", Prim_x_fontinfo_to_fixedwidth, 1, 1, 0)
{ STRUCT_SELECTOR (X_FONT_INFO_ARG, fixedwidth, BOOLEAN_VALUE); }

DEFINE_PRIMITIVE ("X-FONT-INFO->FIRSTCHAR", Prim_x_fontinfo_to_firstchar, 1, 1, 0)
{ STRUCT_SELECTOR (X_FONT_INFO_ARG, firstchar, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-FONT-INFO->LASTCHAR", Prim_x_fontinfo_to_lastchar, 1, 1, 0)
{ STRUCT_SELECTOR (X_FONT_INFO_ARG, lastchar, MAKE_UNSIGNED_FIXNUM); }

/* XEvent Representation */

#define X_KEY_EVENT_ARG(arg) ((XKeyEvent *) (XEVENT_ARG (arg)))
#define X_EXPOSE_EVENT_ARG(arg) ((XExposeEvent *) (XEVENT_ARG (arg)))

DEFINE_PRIMITIVE ("X-EVENT-TYPE", Prim_x_event_type, 1, 1, 0)
{ STRUCT_SELECTOR (XEVENT_ARG, type, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-EVENT-WINDOW", Prim_x_event_window, 1, 1, 0)
{ STRUCT_SELECTOR (XEVENT_ARG, window, XWINDOW_VALUE); }

DEFINE_PRIMITIVE ("X-EVENT-SUBWINDOW", Prim_x_event_subwindow, 1, 1, 0)
{ STRUCT_SELECTOR (XEVENT_ARG, subwindow, XWINDOW_VALUE); }

DEFINE_PRIMITIVE ("X-KEY-EVENT-TIME", Prim_x_key_event_time, 1, 1, 0)
{ STRUCT_SELECTOR (X_KEY_EVENT_ARG, time, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-KEY-EVENT-DETAIL", Prim_x_key_event_detail, 1, 1, 0)
{ STRUCT_SELECTOR (X_KEY_EVENT_ARG, detail, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-KEY-EVENT-X", Prim_x_key_event_x, 1, 1, 0)
{ STRUCT_SELECTOR (X_KEY_EVENT_ARG, x, long_to_object); }

DEFINE_PRIMITIVE ("X-KEY-EVENT-Y", Prim_x_key_event_y, 1, 1, 0)
{ STRUCT_SELECTOR (X_KEY_EVENT_ARG, y, long_to_object); }

DEFINE_PRIMITIVE ("X-KEY-EVENT-LOCATION", Prim_x_key_event_location, 1, 1, 0)
{ STRUCT_SELECTOR (X_KEY_EVENT_ARG, location, XLOCATOR_VALUE); }

DEFINE_PRIMITIVE ("X-EXPOSE-EVENT-WIDTH", Prim_x_expose_event_width, 1, 1, 0)
{ STRUCT_SELECTOR (X_EXPOSE_EVENT_ARG, width, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-EXPOSE-EVENT-HEIGHT", Prim_x_expose_event_height, 1, 1, 0)
{ STRUCT_SELECTOR (X_EXPOSE_EVENT_ARG, height, MAKE_UNSIGNED_FIXNUM); }

DEFINE_PRIMITIVE ("X-EXPOSE-EVENT-X", Prim_x_expose_event_x, 1, 1, 0)
{ STRUCT_SELECTOR (X_EXPOSE_EVENT_ARG, x, long_to_object); }

DEFINE_PRIMITIVE ("X-EXPOSE-EVENT-Y", Prim_x_expose_event_y, 1, 1, 0)
{ STRUCT_SELECTOR (X_EXPOSE_EVENT_ARG, y, long_to_object); }
