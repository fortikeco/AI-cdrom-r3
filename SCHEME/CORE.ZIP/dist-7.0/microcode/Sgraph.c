/* -*-C-*-

$Header: Sgraph.c,v 1.8 88/08/15 20:33:34 GMT cph Rel $

Copyright (c) 1988 Massachusetts Institute of Technology

This material was developed by the Scheme project at the Massachusetts
Institute of Technology, Department of Electrical Engineering and
Computer Science.  Permission to copy this software, to redistribute
it, and to use it for any purpose is granted, subject to the following
restrictions and understandings.

1. Any copy made of this software must include this copyright notice
in full.

2. Users of this software agree to make their best efforts (a) to
return to the MIT Scheme project any improvements or extensions that
they make, so that these may be included in future releases; and (b)
to inform MIT of noteworthy uses of this software.

3. All materials developed as a consequence of the use of this
software shall duly acknowledge such use, in accordance with the usual
standards of acknowledging credit in academic research.

4. MIT has made no warrantee or representation that the operation of
this software will be error-free, and MIT is under no obligation to
provide any services, by way of maintenance, update, or otherwise.

5. In conjunction with products arising from the use of this material,
there shall be no use of the name of the Massachusetts Institute of
Technology nor of any adaptation thereof in any advertising,
promotional, or sales literature without prior written consent from
MIT in each case. */

/* Simple graphics for HP 9000 series 300 machines. */

#include "scheme.h"
#include "prims.h"
#include "flonum.h"
#include "Sgraph.h"

/* Allow these to be overridden at compile time. */

#ifndef DEFAULT_REPLACEMENT_RULE
#define DEFAULT_REPLACEMENT_RULE 3
#endif

#ifndef STARBASE_DEVICE
#define STARBASE_DEVICE "/dev/crt"
#endif

#ifndef STARBASE_DRIVER
#define STARBASE_DRIVER "hp300h"
#endif

#ifndef STARBASE_XMIN
#define STARBASE_XMIN (-512.0)
#endif

#ifndef STARBASE_YMIN
#define STARBASE_YMIN (-384.0)
#endif

#ifndef STARBASE_ZMIN
#define STARBASE_ZMIN (0.0)
#endif

#ifndef STARBASE_XMAX
#define STARBASE_XMAX (511.0)
#endif

#ifndef STARBASE_YMAX
#define STARBASE_YMAX (383.0)
#endif

#ifndef STARBASE_ZMAX
#define STARBASE_ZMAX (0.0)
#endif

/* These are referenced by 6.003 primitives, so they are EXTERN */
long replacement_rule = DEFAULT_REPLACEMENT_RULE;
char * sb_device = STARBASE_DEVICE;
char * sb_driver = STARBASE_DRIVER;
float sb_xmin = STARBASE_XMIN;
float sb_ymin = STARBASE_YMIN;
float sb_zmin = STARBASE_ZMIN;
float sb_xmax = STARBASE_XMAX;
float sb_ymax = STARBASE_YMAX;
float sb_zmax = STARBASE_ZMAX;
int screen_handle = (-1);
float xposition;
float yposition;

DEFINE_PRIMITIVE ("GRAPHICS-NAME-DEVICE", Prim_graphics_name_device, 2, 2, 0)
{
  PRIMITIVE_HEADER (2);

  sb_device = (STRING_ARG (1));
  sb_driver = (STRING_ARG (2));
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("GRAPHICS-SET-COORDINATES", Prim_graphics_set_coordinates, 6, 6, 0)
{
  PRIMITIVE_HEADER (6);

  FLONUM_ARG (1, sb_xmin);
  FLONUM_ARG (2, sb_ymin);
  FLONUM_ARG (3, sb_zmin);
  FLONUM_ARG (4, sb_xmax);
  FLONUM_ARG (5, sb_ymax);
  FLONUM_ARG (6, sb_zmax);
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("GRAPHICS-INITIALIZE", Prim_graphics_initialize, 0, 0, 0)
{
  PRIMITIVE_HEADER (0);

  sb_close_device ();
  screen_handle = (gopen (sb_device, OUTDEV, sb_driver, 0));
  if (screen_handle == (-1))
    error_external_return ();
  vdc_extent (screen_handle,
	      sb_xmin, sb_ymin, sb_zmin,
	      sb_xmax, sb_ymax, sb_zmax);
  clip_rectangle (screen_handle, sb_xmin, sb_xmax, sb_ymin, sb_ymax);
  clear_control (screen_handle, CLEAR_CLIP_RECTANGLE);
  replacement_rule = DEFAULT_REPLACEMENT_RULE;
  drawing_mode (screen_handle, replacement_rule);
  text_alignment (screen_handle, TA_NORMAL_HORIZONTAL, TA_NORMAL_VERTICAL,
		 0.0, 0.0);
  interior_style (screen_handle, INT_HOLLOW, 1);
  perimeter_color_index (screen_handle, 1);
  line_color_index (screen_handle, 1); /* Needed for Gatorbox -- mhwu */
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("GRAPHICS-CLOSE", Prim_graphics_close, 0, 0, 0)
{
  PRIMITIVE_HEADER (0);

  sb_close_device ();
  PRIMITIVE_RETURN (SHARP_F);
}

void
sb_close_device ()
{
 if (screen_handle != (-1))
    {
      gclose (screen_handle);
      screen_handle = (-1);
    }
 return;
}

/* (GRAPHICS-CLEAR)
   Clear the graphics section of the screen.
   Uses the Starbase CLEAR_VIEW_SURFACE procedure.  */

DEFINE_PRIMITIVE ("GRAPHICS-CLEAR", Prim_graphics_clear, 0, 0, 0)
{
  PRIMITIVE_HEADER (0);

  xposition = (0.0);
  yposition = (0.0);
  move2d (screen_handle, xposition, yposition);
  clear_view_surface (screen_handle);
  make_picture_current (screen_handle);
  PRIMITIVE_RETURN (SHARP_F);
}

/* (GRAPHICS-MOVE X Y)
   Uses the Starbase routine MOVE2D to pick up the pen and move
   to the position (X, Y).  Both must be Scheme FIXNUMs or FLONUMs. */

DEFINE_PRIMITIVE ("GRAPHICS-MOVE", Prim_graphics_move, 2, 2, 0)
{
  PRIMITIVE_HEADER (2);

  FLONUM_ARG (1, xposition);
  FLONUM_ARG (2, yposition);
  move2d (screen_handle, xposition, yposition);
  make_picture_current (screen_handle);
  PRIMITIVE_RETURN (SHARP_F);
}

/* (GRAPHICS-LINE X Y)
   Uses the Starbase routine DRAW2D to first make sure the current
   pen is down and uses the current line type to draw to position
   indicated by X and Y. */

DEFINE_PRIMITIVE ("GRAPHICS-LINE", Prim_graphics_line, 2, 2, 0)
{
  PRIMITIVE_HEADER (2);

  FLONUM_ARG (1, xposition);
  FLONUM_ARG (2, yposition);
  draw2d (screen_handle, xposition, yposition);
  make_picture_current (screen_handle);
  PRIMITIVE_RETURN (SHARP_F);
}

/* (GRAPHICS-PIXEL X Y)
   This routine plots one point on the screen at (X, Y).
   Again, X and Y must FIXNUMs or FLONUMs. */

DEFINE_PRIMITIVE ("GRAPHICS-PIXEL", Prim_graphics_pixel, 2, 2, 0)
{
  PRIMITIVE_HEADER (2);

  FLONUM_ARG (1, xposition);
  FLONUM_ARG (2, yposition);
  move2d (screen_handle, xposition, yposition);
  draw2d (screen_handle, xposition, yposition);
  make_picture_current (screen_handle);
  PRIMITIVE_RETURN (SHARP_F);
}

/* (GRAPHICS-SET-LINE-STYLE STYLE)
   Used to change the style of the line to dashes or dots and
   dashes or whatever.  Uses Starbase `line_type' procedure. */

DEFINE_PRIMITIVE ("GRAPHICS-SET-LINE-STYLE", Prim_graphics_set_line_style, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  line_type (screen_handle, (arg_index_integer (1, 8)));
  PRIMITIVE_RETURN (SHARP_F);
}

/* (GRAPHICS-SET-DRAWING-MODE MODE)
   Used to change the replacment rule when drawing. */

DEFINE_PRIMITIVE ("GRAPHICS-SET-DRAWING-MODE", Prim_graphics_set_drawing_mode, 1, 1, 0)
{
  long rule;
  PRIMITIVE_HEADER (1);

  rule = (arg_index_integer (1, 16));
  if (rule != replacement_rule)
    {
      replacement_rule = rule;
      drawing_mode (screen_handle, replacement_rule);
    }
  PRIMITIVE_RETURN (SHARP_F);
}

/* (SET-CLIP-RECTANGLE X2 Y2)
   Restrict the graphics drawing primitives to the area between the
   pen and the given point (X2, Y2).*/

DEFINE_PRIMITIVE ("SET-CLIP-RECTANGLE", Prim_set_clip_rectangle, 2, 2, 0)
{
  fast float x2, y2;
  PRIMITIVE_HEADER (2);

  FLONUM_ARG (1, x2);
  FLONUM_ARG (2, y2);
  clip_rectangle (screen_handle, xposition, x2, yposition, y2);
  make_picture_current (screen_handle);
  PRIMITIVE_RETURN (SHARP_F);
}

/* Graphics Text */

/* (GRAPHICS-LABEL STRING)
   Prints a string label at the current pen position.  The label is
   written according to the current letter type as defined by
   `graphics-set-letter'. */

DEFINE_PRIMITIVE ("GRAPHICS-LABEL", Prim_graphics_label, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  text2d (screen_handle, xposition, yposition,
	  (STRING_ARG (1)), VDC_TEXT, FALSE);
  make_picture_current (screen_handle);
  PRIMITIVE_RETURN (SHARP_F);
}

/* (GRAPHICS-SET-LETTER HEIGHT ASPECT SLANT)
   This routine will change the way in which letters are drawn by Starbase. */

DEFINE_PRIMITIVE ("GRAPHICS-SET-LETTER", Prim_graphics_set_letter, 3, 3, 0)
{
  fast float height, aspect, slant;
  PRIMITIVE_HEADER (3);

  FLONUM_ARG (1, height);
  FLONUM_ARG (2, aspect);
  FLONUM_ARG (3, slant);
  character_height (screen_handle, height);
  character_expansion_factor (screen_handle, aspect);
  character_slant (screen_handle, slant);

  PRIMITIVE_RETURN (SHARP_F);
}

/* (GRAPHICS-SET-ROTATION ANGLE)
   Sets the character path of graphics text. */

DEFINE_PRIMITIVE ("GRAPHICS-SET-ROTATION", Prim_graphics_set_rotation , 1, 1, 0)
{
  fast float angle;
  fast int path_style;
  Primitive_1_Arg();

  FLONUM_ARG (1, angle);
  if ((angle > 315.0) || (angle <=  45.0))
    path_style = PATH_RIGHT;
  else if ((angle > 45.0) && (angle <= 135.0))
    path_style = PATH_DOWN;
  else if ((angle > 135.0) && (angle <= 225.0))
    path_style = PATH_LEFT;
  else if ((angle > 225.0) && (angle <= 315.0))
    path_style = PATH_UP;
  text_path (screen_handle, path_style);
  PRIMITIVE_RETURN (SHARP_F);
}

/* Graphics Screen Dump */

/* (PRINT-GRAPHICS FILENAME)
   Write a file containing an image of the screen, in a format
   suitable for printing on a laser printer. */

static char rasres[] = "\033*t100R";
static char rastop[] = "\033&l2E";
static char raslft[] = "\033&a2L";
static char rasbeg[] = "\033*r0A";
static char raslen[] = "\033*b96W";
static char rasend[] = "\033*rB";

static int
inquire_cmap_size (fildes)
     int fildes;
{
  float physical_limits [2][3];
  float resolution [3];
  float p1 [3];
  float p2 [3];
  int cmap_size;

  inquire_sizes (fildes, physical_limits, resolution, p1, p2, (& cmap_size));
  return (cmap_size);
}

static int
inquire_cmap_mask (fildes)
     int fildes;
{
  int cmap_size;

  cmap_size = (inquire_cmap_size (fildes));
  return (((cmap_size >= 0) && (cmap_size < 8)) ?
	  ((1 << cmap_size) - 1) :
	  (-1));
}

static int
open_dumpfile (dumpname)
  char * dumpname;
{
  int dumpfile;

  dumpfile = (creat (dumpname, 0666));
  if (dumpfile == (-1))
    {
      fprintf (stderr, "\nunable to create graphics dump file.");
      error_external_return ();
    }
  dumpfile = (open (dumpname, OUTINDEV));
  if (dumpfile == (-1))
    {
      fprintf (stderr, "\nunable to open graphics dump file.");
      error_external_return ();
    }
  return (dumpfile);
}

static void
print_graphics_internal (dumpname, inverse_p)
     char * dumpname;
     int inverse_p;
{
  int dumpfile;

  dumpfile = (open_dumpfile (dumpname));

  write (dumpfile, rasres, (strlen (rasres)));
  write (dumpfile, rastop, (strlen (rastop)));
  write (dumpfile, raslft, (strlen (raslft)));
  write (dumpfile, rasbeg, (strlen (rasbeg)));

  {
    fast unsigned char mask;
    int col;

    mask = (inquire_cmap_mask (screen_handle));
    for (col = (1024 - 16); (col >= 0); col = (col - 16))
      {
	unsigned char pixdata [(16 * 768)];

	{
	  fast unsigned char * p;
	  fast unsigned char * pe;

	  p = (& (pixdata [0]));
	  pe = (& (pixdata [sizeof (pixdata)]));
	  while (p < pe)
	    (*p++) = '\0';
	}
	dcblock_read (screen_handle, col, 0, 16, 768, pixdata, 0);
	{
	  int x;

	  for (x = (16 - 1); (x >= 0); x -= 1)
	    {
	      unsigned char rasdata [96];
	      fast unsigned char * p;
	      fast unsigned char * r;
	      int n;

	      p = (& (pixdata [x]));
	      r = rasdata;
	      for (n = 0; (n < 96); n += 1)
		{
		  fast unsigned char c;
		  int nn;

		  c = 0;
		  for (nn = 0; (nn < 8); nn += 1)
		    {
		      c <<= 1;
		      if (((* p) & mask) != 0)
			c |= 1;
		      p += 16;
		    }
		  (*r++) = (inverse_p ? (~ c) : c);
		}
	      write (dumpfile, raslen, (strlen (raslen)));
	      write (dumpfile, rasdata, 96);
	    }
	}
      }
  }
  write (dumpfile, rasend, (strlen (rasend)));
  close (dumpfile);
  return;
}

DEFINE_PRIMITIVE ("PRINT-GRAPHICS", Prim_print_graphics, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  print_graphics_internal ((STRING_ARG (1)), false);
  PRIMITIVE_RETURN (SHARP_F);
}

DEFINE_PRIMITIVE ("PRINT-GRAPHICS-INVERSE", Prim_print_graphics_inverse, 1, 1, 0)
{
  PRIMITIVE_HEADER (1);

  print_graphics_internal ((STRING_ARG (1)), true);
  PRIMITIVE_RETURN (SHARP_F);
}
