/* -*-C-*-

Copyright (c) 1987, 1988 Massachusetts Institute of Technology

This material was developed by the Scheme project at the Massachusetts
Institute of Technology, Department of Electrical Engineering and
Computer Science.  Permission to copy this software, to redistribute
it, and to use it for any purpose is granted, subject to the following
restrictions and understandings.

1. Any copy made of this software must include this copyright notice
in full.

2. Users of this software agree to make their best efforts (a) to
return to the MIT Scheme project any improvements or extensions that
they make, so that these may be included in future releases; and (b)
to inform MIT of noteworthy uses of this software.

3. All materials developed as a consequence of the use of this
software shall duly acknowledge such use, in accordance with the usual
standards of acknowledging credit in academic research.

4. MIT has made no warrantee or representation that the operation of
this software will be error-free, and MIT is under no obligation to
provide any services, by way of maintenance, update, or otherwise.

5. In conjunction with products arising from the use of this material,
there shall be no use of the name of the Massachusetts Institute of
Technology nor of any adaptation thereof in any advertising,
promotional, or sales literature without prior written consent from
MIT in each case. */

/* $Header: vmsio.h,v 9.22 88/08/15 20:58:27 GMT cph Rel $ */

#define IO$K_LOOPTEST   0x0000E000           
#define IO$M_EXTEND     0x00008000           
#define IO$M_NOW        0x00000040           
#define IO$M_TRMNOECHO  0x00001000   
#define IO$K_PTPBSC     0x00002000           
#define IO$M_FCODE      0x0000003F           
#define IO$M_NOWAIT     0x00000080           
#define IO$M_TYPEAHDCNT 0x00000040   
#define IO$K_SRRUNOUT   0x00000000           
#define IO$M_FORCE      0x00000040           
#define IO$M_OPPOSITE   0x00000200           
#define IO$M_UNLOOP     0x00000100   
#define IO$M_ABORT      0x00000100           
#define IO$M_HANGUP     0x00000200           
#define IO$M_OUTBAND    0x00000400           
#define IO$M_WORD       0x00000040   
#define IO$M_ACCEPT     0x00000080           
#define IO$M_INCLUDE    0x00000800           
#define IO$M_PACKED     0x00000080           
#define IO$M_WRTATTN    0x00000100   
#define IO$M_ACCESS     0x00000040           
#define IO$M_INHERLOG   0x00000800           
#define IO$M_PURGE      0x00000800           
#define IO$S_FCODE      0x00000006   
#define IO$M_ATTNAST    0x00000100           
#define IO$M_INHEXTGAP  0x00001000           
#define IO$M_QUALIFIED  0x00000080           
#define IO$V_ABORT      0x00000008   
#define IO$M_BINARY     0x00000040           
#define IO$M_INHRETRY   0x00008000           
#define IO$M_RD_COUNT   0x00000100           
#define IO$V_ACCEPT     0x00000007   
#define IO$M_CANCTRLO   0x00000040           
#define IO$M_INHSEEK    0x00001000           
#define IO$M_RD_MEM     0x00000040           
#define IO$V_ACCESS     0x00000006   
#define IO$M_CECYL      0x00000400           
#define IO$M_INTCLOCK   0x00001000           
#define IO$M_RD_MODEM   0x00000080           
#define IO$V_ATTNAST    0x00000008   
#define IO$M_CLEAR      0x00001000           
#define IO$M_INTERRUPT  0x00000040           
#define IO$M_READATTN   0x00000080           
#define IO$V_BINARY     0x00000006   
#define IO$M_CLR_COUNT  0x00000400           
#define IO$M_INTSKIP    0x00000100           
#define IO$M_READCSR    0x00008000           
#define IO$V_CANCTRLO   0x00000006   
#define IO$M_CNTRLENTRY 0x00000080           
#define IO$M_LASTBLOCK  0x00000400           
#define IO$M_REDIRECT   0x00000040           
#define IO$V_CECYL      0x0000000A   
#define IO$M_COMMOD     0x00000040           
#define IO$M_LINE_OFF   0x00000200           
#define IO$M_REFRESH    0x00002000           
#define IO$V_CLEAR      0x0000000C   
#define IO$M_CREATE     0x00000080           
#define IO$M_LINE_ON    0x00000800           
#define IO$M_RESET      0x00000800           
#define IO$V_CLR_COUNT  0x0000000A   
#define IO$M_CTRL       0x00000200           
#define IO$M_LOOP       0x00000080           
#define IO$M_REVERSE    0x00000040           
#define IO$V_CNTRLENTRY 0x00000007   
#define IO$M_CTRLCAST   0x00000100           
#define IO$M_LOOP_EXT   0x00001000           
#define IO$M_SETBSIZE   0x00000200           
#define IO$V_COMMOD     0x00000006   
#define IO$M_CTRLYAST   0x00000080           
#define IO$M_LPBEXT     0x00002000           
#define IO$M_SETCUADR   0x00000100           
#define IO$V_CREATE     0x00000007   
#define IO$M_CVTLOW     0x00000100           
#define IO$M_LPBINT     0x00004000           
#define IO$M_SETENQCNT  0x00000800           
#define IO$V_CTRL       0x00000009   
#define IO$M_CYCLE      0x00001000           
#define IO$M_MAINT      0x00000040           
#define IO$M_SETEVF     0x00000040           
#define IO$V_CTRLCAST   0x00000008   
#define IO$M_DATACHECK  0x00004000           
#define IO$M_MAINTLOOP  0x00000200           
#define IO$M_SETFNCT    0x00000200           
#define IO$V_CTRLYAST   0x00000007   
#define IO$M_DATAPATH   0x00000400           
#define IO$M_MORE       0x00000040           
#define IO$M_SETPOOLSZ  0x00000400           
#define IO$V_CVTLOW     0x00000008   
#define IO$M_DELDATA    0x00000040           
#define IO$M_MOUNT      0x00000200           
#define IO$M_SETPROT    0x00000200           
#define IO$V_CYCLE      0x0000000C   
#define IO$M_DELETE     0x00000100           
#define IO$M_MOVETRACKD 0x00000080           
#define IO$M_SET_MODEM  0x00000400           
#define IO$V_DATACHECK  0x0000000E   
#define IO$M_DIAGNOSTIC 0x00000100           
#define IO$M_MULTIPLE   0x00000100           
#define IO$M_SHUTDOWN   0x00000080           
#define IO$V_DATAPATH   0x0000000A   
#define IO$M_DMOUNT     0x00000400           
#define IO$M_NOCTSWAIT  0x00000040           
#define IO$M_SKPSECINH  0x00000200           
#define IO$V_DELDATA    0x00000006   
#define IO$M_DSABLMBX   0x00000400           
#define IO$M_NODSRWAIT  0x00000100           
#define IO$M_SLAVLOOP   0x00000080           
#define IO$V_DELETE     0x00000008   
#define IO$M_DSABL_ALT  0x00001000           
#define IO$M_NOECHO     0x00000040           
#define IO$M_STARTUP    0x00000040           
#define IO$V_DIAGNOSTIC 0x00000008   
#define IO$M_ENABLMBX   0x00000080           
#define IO$M_NOFILTR    0x00000200           
#define IO$M_SWAP       0x00000400           
#define IO$V_DMOUNT     0x0000000A   
#define IO$M_ENABL_ALT  0x00000800           
#define IO$M_NOFORMAT   0x00000100           
#define IO$M_SYNCH      0x00000200           
#define IO$V_DSABLMBX   0x0000000A   
#define IO$M_ESCAPE     0x00004000           
#define IO$M_NOMRSP     0x00000040           
#define IO$M_TIMED      0x00000080           
#define IO$V_DSABL_ALT  0x0000000C   
#define IO$V_ENABLMBX   0x00000007           
#define IO$V_SETENQCNT  0x0000000B           
#define IO$_READPROMPT  0x00000037           
#define IO$V_ENABL_ALT  0x0000000B           
#define IO$V_SETEVF     0x00000006           
#define IO$_READTRACKD  0x00000010           
#define IO$V_ESCAPE     0x0000000E           
#define IO$V_SETFNCT    0x00000009           
#define IO$_READVBLK    0x00000031           
#define IO$V_EXTEND     0x0000000F           
#define IO$V_SETPOOLSZ  0x0000000A           
#define IO$_RECAL       0x00000003           
#define IO$V_FCODE      0x00000000           
#define IO$V_SETPROT    0x00000009           
#define IO$_RELEASE     0x00000005           
#define IO$V_FORCE      0x00000006           
#define IO$V_SET_MODEM  0x0000000A           
#define IO$_REREADN     0x00000016           
#define IO$V_HANGUP     0x00000009           
#define IO$V_SHUTDOWN   0x00000007           
#define IO$_REREADP     0x00000017           
#define IO$V_INCLUDE    0x0000000B           
#define IO$V_SKPSECINH  0x00000009           
#define IO$_RETCENTER   0x00000007           
#define IO$V_INHERLOG   0x0000000B           
#define IO$V_SLAVLOOP   0x00000007           
#define IO$_REWIND      0x00000024           
#define IO$V_INHEXTGAP  0x0000000C           
#define IO$V_STARTUP    0x00000006           
#define IO$_REWINDOFF   0x00000022           
#define IO$V_INHRETRY   0x0000000F           
#define IO$V_SWAP       0x0000000A           
#define IO$_SEARCH      0x00000009           
#define IO$V_INHSEEK    0x0000000C           
#define IO$V_SYNCH      0x00000009           
#define IO$_SEEK        0x00000002           
#define IO$V_INTCLOCK   0x0000000C           
#define IO$V_TIMED      0x00000007           
#define IO$_SENSECHAR   0x0000001B           
#define IO$V_INTERRUPT  0x00000006           
#define IO$V_TRMNOECHO  0x0000000C           
#define IO$_SENSEMODE   0x00000027           
#define IO$V_INTSKIP    0x00000008           
#define IO$V_TYPEAHDCNT 0x00000006           
#define IO$_SETCHAR     0x0000001A           
#define IO$V_LASTBLOCK  0x0000000A           
#define IO$V_UNLOOP     0x00000008           
#define IO$_SETCLOCK    0x00000037           
#define IO$V_LINE_OFF   0x00000009           
#define IO$V_WORD       0x00000006           
#define IO$_SETCLOCKP   0x00000005           
#define IO$V_LINE_ON    0x0000000B           
#define IO$V_WRTATTN    0x00000008           
#define IO$_SETMODE     0x00000023           
#define IO$V_LOOP       0x00000007           
#define IO$_ACCESS      0x00000032           
#define IO$_SKIPFILE    0x00000025           
#define IO$V_LOOP_EXT   0x0000000C           
#define IO$_ACPCONTROL  0x00000038           
#define IO$_SKIPRECORD  0x00000026           
#define IO$V_LPBEXT     0x0000000D           
#define IO$_AVAILABLE   0x00000011           
#define IO$_SPACEFILE   0x00000002           
#define IO$V_LPBINT     0x0000000E           
#define IO$_CLEAN       0x0000001E           
#define IO$_SPACERECORD 0x00000009           
#define IO$V_MAINT      0x00000006           
#define IO$_CONINTREAD  0x0000003C           
#define IO$_STARTDATA   0x00000038           
#define IO$V_MAINTLOOP  0x00000009           
#define IO$_CONINTWRITE 0x0000003D           
#define IO$_STARTDATAP  0x00000006           
#define IO$V_MORE       0x00000006           
#define IO$_CREATE      0x00000033           
#define IO$_STARTMPROC  0x00000002           
#define IO$V_MOUNT      0x00000009           
#define IO$_DEACCESS    0x00000034           
#define IO$_STARTSPNDL  0x00000019           
#define IO$V_MOVETRACKD 0x00000007           
#define IO$_DELETE      0x00000035           
#define IO$_STOP        0x00000003           
#define IO$V_MULTIPLE   0x00000008           
#define IO$_DIAGNOSE    0x0000001D           
#define IO$_TTYREADALL  0x0000003A           
#define IO$V_NOCTSWAIT  0x00000006           
#define IO$_DRVCLR      0x00000004           
#define IO$_TTYREADPALL 0x0000003B           
#define IO$V_NODSRWAIT  0x00000008           
#define IO$_DSE         0x00000015           
#define IO$_UNLOAD      0x00000001           
#define IO$V_NOECHO     0x00000006           
#define IO$_ENDRU1      0x0000003A           
#define IO$_VIRTUAL     0x0000003F           
#define IO$V_NOFILTR    0x00000009           
#define IO$_ENDRU2      0x0000003B           
#define IO$_WRITECHECK  0x0000000A           
#define IO$V_NOFORMAT   0x00000008           
#define IO$_ERASETAPE   0x00000006           
#define IO$_WRITECHECKH 0x00000018           
#define IO$V_NOMRSP     0x00000006           
#define IO$_FORCE       0x00000037           
#define IO$_WRITEHEAD   0x0000000D           
#define IO$V_NOW        0x00000006           
#define IO$_FORMAT      0x0000001E           
#define IO$_WRITELBLK   0x00000020           
#define IO$V_NOWAIT     0x00000007           
#define IO$_INITIALIZE  0x00000004           
#define IO$_WRITEMARK   0x0000001C           
#define IO$V_OPPOSITE   0x00000009           
#define IO$_LOADMCODE   0x00000001           
#define IO$_WRITEOF     0x00000028           
#define IO$V_OUTBAND    0x0000000A           
#define IO$_LOGICAL     0x0000002F           
#define IO$_WRITEPBLK   0x0000000B           
#define IO$V_PACKED     0x00000007           
#define IO$_MODIFY      0x00000036           
#define IO$_WRITERET    0x00000018           
#define IO$V_PURGE      0x0000000B           
#define IO$_MOUNT       0x00000039           
#define IO$_WRITETRACKD 0x0000000F           
#define IO$V_QUALIFIED  0x00000007           
#define IO$_NETCONTROL  0x00000036           
#define IO$_WRITEVBLK   0x00000030           
#define IO$V_RD_COUNT   0x00000008           
#define IO$_NOP         0x00000000           
#define IO$_WRTTMKR     0x0000001D           
#define IO$V_RD_MEM     0x00000006           
#define IO$_OFFSET      0x00000006           
#define IO$V_RD_MODEM   0x00000007           
#define IO$_PACKACK     0x00000008           
#define IO$V_READATTN   0x00000007           
#define IO$_PHYSICAL    0x0000001F           
#define IO$V_READCSR    0x0000000F           
#define IO$_QSTOP       0x00000007           
#define IO$V_REDIRECT   0x00000006           
#define IO$_RDSTATS     0x0000000D           
#define IO$V_REFRESH    0x0000000D           
#define IO$_READHEAD    0x0000000E           
#define IO$V_RESET      0x0000000B           
#define IO$_READINIT    0x0000003C           
#define IO$V_REVERSE    0x00000006           
#define IO$_READLBLK    0x00000021           
#define IO$V_SETBSIZE   0x00000009           
#define IO$_READPBLK    0x0000000C           
#define IO$V_SETCUADR   0x00000008           
#define IO$_READPRESET  0x00000019           
