-*- Indented-Text -*- $Header: README,v 1.2 89/07/26 23:17:53 GMT cph Rel $

For information on installation, read INSTALL.


		Description of the distribution files

MIT Scheme is being distributed as a set of compressed tar files.
These archives are designed to be unpacked together in the same place.
For example, the file "core.tar.Z" contains these directories:

	dist-7.0/documentation/
	dist-7.0/etc/
	dist-7.0/microcode/

while the file "exe-68k.tar.Z" contains

	dist-7.0/lib/

When taken together, these two archives create four subdirectories.

Each installation needs a selection of these files; minimal
requirements are outlined below.  In addition, there are several
optional files which can be installed as well.


Archive File	Description
-------------	--------------------------------------------------
core.tar.Z	Microcode, installation tools, and basic
		documentation.  Required for all installations.

exe-68k.tar.Z	Compiled world images for 68020 machines.
exe-vax.tar.Z	Compiled world images for Vax machines.
		Required for installations that support compiled code.

psb.tar.Z	Portable binary files; used to construct world images
		for machines that do not support compiled code.
		Required for installations that do not support
		compiled code.

man.tar.Z	Scheme reference manual and Revised^3 Report.
		Optional.

edwin.tar.Z	Sources and portable binaries for Edwin.  Optional.

src.tar.Z	Sources for the runtime system, SF, and the compiler.
		Optional.

bin-68k.tar.Z	Compiled binaries for 68020 machines.
bin-vax.tar.Z	Compiled binaries for Vax machines.
		These are binaries for the runtime system, SF, the
		compiler, and Edwin.  Also included are the debugging
		files which provide symbolic debugging support for
		these programs.  Optional.

The minimal required configurations are:

68020 machines:		core.tar.Z + exe-68k.tar.Z
Vaxen:			core.tar.Z + exe-vax.tar.Z
all other machines:	core.tar.Z + psb.tar.Z


	    Description of the Scheme directory hierarchy

Assume in the following that $SCHEME is the Scheme root directory
(called "dist-7.0" in the current distribution).  This brief
description covers all of the directory heirarchy; only part of the
heirarchy may be present, depending on what part of the distribution
you install.

$SCHEME/microcode contains the C sources and object code for the
microcode.  It also contains some utility programs.  In particular, 
it contains Psbtobin, which is the program used to convert between
portable format Scheme binaries, and internal format Scheme binaries.

$SCHEME/runtime contains the Scheme sources and binaries for the
runtime system.

$SCHEME/sf contains the Scheme sources and binaries for SF, the SCode
optimizer.  Read "$SCHEME/documentation/user.txt" for a short
description of its capabilities.

$SCHEME/compiler contains the Scheme sources and binaries for Liar,
the native-code Scheme compiler.

$SCHEME/edwin contains the Scheme sources and binaries for Edwin, an
Emacs-style editor written in Scheme.

$SCHEME/cref contains the Scheme sources and binaries for an
experimental packaging system that is used in the construction of MIT
Scheme.  No documentation or support is provided for this system as we
have plans to replace it with a very different system in the future.

$SCHEME/psb contains the portable binaries for the Scheme code; it is
normally deleted after installation is complete, as the portable
binaries are converted into machine-specific binaries during the
installation process.

$SCHEME/etc contains some utilities for generating the runtime system,
and some GNU Emacs libraries which make editing scheme sources, and
manipulating inferior Scheme processes simpler.

$SCHEME/lib contains saved world images ("bands"), and some additional
files such as microcode type tables and optionally-loaded modules.
Usually "/usr/local/lib/mit-scheme" is a link to this directory.

$SCHEME/documentation contains some documentation for Scheme.  The
"r3rs" subdirectory contains the "Revised^3 Report on Scheme", written
in LaTex; the "manual" subdirectory contains the MIT Scheme reference
manual, written in Texinfo; and the "run-14" directory contains the
runtime system release notes for version 14 of the runtime system,
again written in Texinfo.

			     What to keep

If space is at a premium on your machine, you can get rid of most of
the scheme directory hierarchy once Scheme has successfully booted.

These are the files you need to run Scheme:

	microcode/scheme	(the executable image)
	lib/utabmd.bin		(microcode tables)
	lib/runtime.com		(runtime system + sf)
	lib/compiler.com	(runtime system + sf + compiler)
	lib/edwin.com		(runtime system + sf + edwin)
	lib/options/*		(optionally-loaded modules)

Everything else can be removed.  If you aren't going to use the
compiler or Edwin, you can remove those bands.  Note that the location
of the files in the "lib/" subdirectory is fixed at the time that the
Scheme microcode is compiled; it is specified in the file
"microcode/paths.h".


		     Some Interesting variations

NOTE: If you write modifications that you feel other people might be
interested in, please send them to us so that we can include them in a
later release.

1) New primitives

a) Write C procedures which will work as Scheme primitives.  See the
file "documentation/prims.txt" for more information.

b) 

Under Unix:

- Change "ymakefile" in the microcode subdirectory so that the Scheme
system will know about the new primitive files: change the following
"make" macros to be lists with all the relevant files (the example
shows the user file "foo.c" and the associated library "bar":

	USER_PRIM_SOURCES = foo.c
	USER_PRIM_OBJECTS = foo.o
	USER_LIBS = -lbar

- Execute "make scheme" in the microcode directory.  If there are no
compilation errors, a new Scheme microcode will be linked.

Under VMS or other operating systems:

- Change the files "make.com" and "usrdef.txt" to compile and declare
the relevant files.  For example, if the new primitives are defined in
the files "xdebug.c" and "Xgraph.c", replace the line

"$ Findprim -o usrdef.c -l usrdef.txt"

by the lines

"$ Findprim -o usrdef.c -l usrdef.txt"
"$ cc xdebug.c"
"$ cc Xgraph.c"

and add the lines

xdebug.c
Xgraph.c

to the file "usrdef.txt".

- Execute the commands in "make.com" to regenerate a scheme microcode.
There is no need to remake the scheme runtime binaries.

c) Once the microcode has been generated (step b above), load up a
Scheme, where the primitives can be obtained by using
MAKE-PRIMITIVE-PROCEDURE:

(MAKE-PRIMITIVE-PROCEDURE <symbol>) will return a procedure object
corresponding to a primitive named <symbol>, if there is one.  It can
then be used like any other procedure.  For examples, see the file
"Xgraph.scm" in the runtime subdirectory.

2) Executable image

When scheme starts up it loads a band (a "linked" runtime system is
called a band for historical reasons).  This may be an unreasonably
slow process, so you may want to circumvent it by dumping a Scheme
which has the runtime system already loaded (as described below).

**** NOTE: The "unexec.c" code has not been tested recently.  There is
a fair chance that it no longer works.  If you do decide to use it and
manage to make it work, please let us know of any changes that were
required. ****

The mechanism implementing this only works under unix, and uses
"unexec.c", a file from GNU-EMACS.  It is heavily conditionalized for
various machines and versions of unix, but we have only tried it on a
few configurations (VAX/Ultrix, VAX/BSD 4.2, Sun/BSD 4.2, and
HP9000s300/HPUX).  If you have GNU-EMACS on your machine, and it dumps
an executable image, you should be able to make this work.  Look at
"microcode/dumpworld.c" and "microcode/unexec.c".  The optional
primitive mechanism described in 1 above is used to add this primitive
to the system.

To obtain a version of scheme which can make an executable dump of
itself, add "dumpworld.c" and "dumpworld.o" to the USER_PRIM... lines
of the makefile as specified above.  Link a new Scheme microcode.
Once this is done, start scheme (with a normal system, instead of a
student system) and, at scheme, type (dump-world "xscheme") This will
make a file called xscheme which when executed will start a scheme
with a normal runtime system already loaded.  You may want to make
this the default scheme that users get when they type scheme.

NOTE: GNU Emacs's unexec needs to open the original scheme executable
file to copy the symbol table into the new image.  Unfortunately many
"unices" do not provide processes with the full pathname where their
binary was found, but instead provide the trailing component of the
pathname.  Scheme tries (by looking at the connected directory and the
PATH environment variable) to find the correct binary from which to
copy the symbol table, but it may not always succeed.

3) bchscheme

bchscheme is a version of Scheme that uses a disk file as a temporary
(rather than memory) to garbage collect.  Thus if you have memory
limitations, you may be interested in using this version, for it
reduces your memory requirements by about 40% at the expense of making
garbage collection somewhat slower.  The microcode is generated by
doing "make bchscheme" in the microcode subdirectory, rather than
"make scheme", and the runtime system is shared, so it can be used
interchangeably with scheme.  Currently there is a bug in the
bchscheme version of the purify procedure.  If during the purification
process, scheme runs out of space, it does not back out, instead it
crashes.  This will be fixed in an upcoming release.

4) Scheme compiler

The compiler is currently ported to the Motorola MC68020 (currently
Sun3 and HP 9000 series 300) and Vax computers.  It has been in
regular use at MIT for over a year and is believed to be debugged for
the 68020 machines; the Vax port is more recent and may still have
some bugs.  Performance improvements over interpreted code should be a
factor of between 5 and 20 for typical code.

5) Edwin editor

Edwin is an editor written in Scheme, very similar to GNU Emacs.  This
is not the trimmed-down version distributed with TI PC Scheme, but a
fully-extensible editor, with much of the look and feel of GNU Emacs.
It currently has support for running under the curses terminal driver
package, and for running directly under the X window system (version
11 only).

6) Graphics

This release contains a new generic graphics interface, with support
for the X window system (version 11) and the HP Starbase graphics
system.  This interface is designed to be easily extensible to new
kinds of graphics devices.  The standard graphics calls support
two-dimensional line and point drawings, and upright left-to-right
text drawing.  Different line styles (such as dotted or dashed) are
also supported.

The X window system support allows multiple windows to be opened on
multiple displays, provides control of colors, border widths, and
window size and position.  No mouse support is currently implemented,
although it should not be too difficult to do it.




For bug reports send computer mail to

bug-cscheme@zurich.ai.mit.edu (on the Arpanet/Internet)

or US Snail to

Scheme Team
c/o Prof. Hal Abelson
545 Technology Sq. rm 410
Cambridge MA 02139

Other relevant mailing lists:

info-cscheme@zurich.ai.mit.edu
	Questions, notices of bug fixes, etc.
	Send mail to "info-cscheme-request" to be added.

scheme@ai.mit.edu
	Applications, mostly for educational uses.
	Note that this mailing list is NOT MIT Scheme specific.  It
	covers general language issues, relevant to all the
	implementations of the scheme language (MIT Scheme, Yale
	University's T, Indiana University's Scheme84, Semantic
	Microsystems' MacScheme, and Texas Instruments' PC Scheme
	among others).
	Send mail to "scheme-request" to be added.
	If your mailer doesn't recognize "ai.mit.edu" as a valid host,
	you can use "zurich.ai.mit.edu" instead.
