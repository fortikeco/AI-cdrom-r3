#include "defs.h"
#include "expr.h"
#include "cases.h"
#include "char_array.h"
#include "cell.h"
#include "stack.h"
#include "error.h"
#include "path.h"

/*
 * The interpreter uses an extension of Krivine's machine.
 *
 * In Krivine's machine (as yet unpublished), a value is a deBruijn-form
 * lambda expression paired with an environment, which is a list of
 * values.  The machine state has 2 components: the value currently being
 * executed, and the stack, a list of values comprising its arguments.
 * Start with the expression to be evaluated, with an empty environment
 * and stack.  The transitions are as follows:
 *
 *	Current value		Stack		New current	New stack
 *	=============		=====		===========	=========
 *	(Var n, env)		s	->	env@n		s
 *	(Apply fun arg, env)	s	->	(fun, env)	(arg, env)::s
 *	(Lambda body, env)	a::s	->	(body, a::env)	s
 *	(Lambda body, env)	[]	->	stop and unravel
 *
 * Extensions involved here:
 * - Call-by-need evaluation (a simplified form of the corresponding
 *   enhancement to the TIM:
 *	(1) when a variable is entered, push a mark pointing to the value
 *	    onto the stack.
 *	(2) when taking an argument for a Lambda, if there is a mark on
 *	    the top of the stack, update the cell pointed to with the
 *	    current value.
 * - Cells representing data values: when these become current, they
 *   remove themselves, entering the first argument on the stack.
 *   Again, if there is a mark in the way, the cell it points to is updated.
 * - an extra kind of mark on the stack: FORCE_MARK.  When this is at the
 *   the top of the stack, it indicates that the current value is to be
 *   evaluated to weak head normal form.  Thus if it is a constructor or
 *   pair, instead of removing itself it must force its sub-value(s).
 * - Fetching a sub-part of an argument: DIR nodes (cf number.c, path.c).
 * - Pattern matching: CASE nodes (cf compile.c).
 */

#ifdef EBUG
#	define	DEBUG(fmt)	(void)fprintf(stderr, fmt)
#	define	DEBUG2(fmt,arg)	(void)fprintf(stderr, fmt, arg)
#	define	DEBUGV(v)	pr_value(stderr, v)
#else
#	define	DEBUG(fmt)
#	define	DEBUG2(fmt,arg)
#	define	DEBUGV(v)
#endif

local	void	run		ARGS((CELL *current));
local	CELL	*take		ARGS((CELL *current));
local	void	chk_argument	ARGS((CELL *arg));

global	STRING	cur_function;

#define	NULL_ENV	NOCELL

/* push a mark and enter p */
#define	EnterUpdate(p)	(current = (p), PushUpdate(current))

/* force evaluation (and update) of p */
#define	Force(p)	(Push(FORCE_MARK), EnterUpdate(p))

/*
 * The following two constants are properties of the abstract machine below,
 * the stream handler and the various builtins.  If any of these change,
 * these constants may also need to change.
 */
#define	MAX_NEWS	4	/* max. no. of cells required by any step */
#define	MAX_PUSHES	(2+2*UPD_FRAME)
				/* max. amount of stack growth on any step */

/* #define STATS */
#ifdef STATS
local	int	do_cell[C_NCLASSES];
local	int	do_expr[E_NCLASSES];
local	int	do_dir[P_NCLASSES];
#endif

/*
 *	Interpreter for an expression.
 *	See compile.c for the translation schemes.
 */
global void
interpret(action, expr)
	EXPR	*action, *expr;
{
#ifdef STATS
	int	i;

	for (i = 0; i < C_NCLASSES; i++)
		do_cell[i] = 0;
	for (i = 0; i < E_NCLASSES; i++)
		do_expr[i] = 0;
	for (i = 0; i < P_NCLASSES; i++)
		do_dir[i] = 0;
#endif
	start_stack();
	enable_interrupt();
	chk_stack(1);
	Push(new_susp(expr, new_pair(new_stream(stdin), NULL_ENV)));
	run(new_susp(action, NULL_ENV));
	disable_interrupt();
#ifdef STATS
	for (i = 0; i < C_NCLASSES; i++) {
		int	j;

		printf("cell %d: %d\n", i, do_cell[i]);
		if (i == C_SUSP)
			for (j = 0; j < E_NCLASSES; j++)
				printf("\texpr %d: %d\n", j, do_expr[j]);
		if (i == C_DIRS)
			for (j = 0; j < P_NCLASSES; j++)
				printf("\tdir %d: %d\n", j, do_dir[j]);
	}
#endif
}

/*
 *	Reduce a value to head normal form
 */
global CELL *
evaluate(value)
reg	CELL	*value;
{
	chk_stack(3 + UPD_FRAME);
	Push(value);	/* so that it isn't forgotten */
	Push(new_susp(e_return, NULL_ENV));
	/* Force(value); */
	Push(FORCE_MARK);
	PushUpdate(value);
	run(value);
	return Pop();
}

local void
run(current)
reg	CELL	*current;
{
/*
 *	The following variables hold temporary values during the emulation
 *	of particular instructions.
 *	Only current and the stack carry values between instructions.
 */
reg	CELL	*tmp;		/* general purpose temporary */
reg	int	itmp;		/* general purpose integer temporary */

/* special names for these.  BEWARE! Slippery when wet! */
#define	dir	itmp		/* direction value */
#define	var	itmp		/* variable number */
#define	top	tmp 		/* the top of the argument stack */

reg	CELL	*env; 		/* environment for suspensions */
reg	EXPR	*expr; 		/* expression for suspensions */
reg	UCASE	*code;
reg	LCASE	*lcase;

    repeat {
	chk_heap(current, MAX_NEWS);
	chk_stack(MAX_PUSHES);
#ifdef STATS
	do_cell[current->c_class]++;
	if (current->c_class == C_SUSP)
		do_expr[current->c_expr->c_class]++;
	if (current->c_class == C_DIRS)
		do_expr[p_top(current->c_path)]++;
#endif
	switch (current->c_class) {
	when C_NUM:
		DEBUG("NUM: "); DEBUG2(NUMfmt, current->c_num); DEBUG("\n");
		top = take(current);
		current = top == FORCE_MARK ? Pop() : top;
	when C_CHAR:
		DEBUG2("CHAR: %c\n", current->c_char);
		top = take(current);
		current = top == FORCE_MARK ? Pop() : top;
	when C_CONST:
		DEBUG2("CONST: %s\n", current->c_cons->c_name);
		top = take(current);
		current = top == FORCE_MARK ? Pop() : top;
	when C_CONS:
		DEBUG2("CONS: %s\n", current->c_cons->c_name);
		top = take(current);
		if (top == FORCE_MARK)
			Force(current->c_arg);
		else	/* top is a normal value */
			current = top;
	when C_PAIR:
		DEBUG("PAIR\n");
		top = take(current);
		if (top == FORCE_MARK) {
			tmp = current->c_right;
			Push(FORCE_MARK);
			PushUpdate(tmp);
			Push(tmp);
			Force(current->c_left);
		}
		else	/* top is a normal value */
			current = top;
	when C_STREAM:
		DEBUG("STREAM\n");
		current = read_stream(current);
	when C_DIRS:
		DEBUG("DIRS: ");
		dir = p_top(current->c_path);
		current->c_path = p_pop(current->c_path);
		switch (dir) {
		when P_END:
			DEBUG("EMPTY\n");
			EnterUpdate(current->c_val);
		when P_LEFT:
			DEBUG("LEFT\n");
			current->c_val = current->c_val->c_left;
		when P_RIGHT:
			DEBUG("RIGHT\n");
			current->c_val = current->c_val->c_right;
		when P_STRIP:
			DEBUG("STRIP\n");
			current->c_val = current->c_val->c_arg;
		when P_PRED:
			DEBUG("PRED\n");
			current->c_val = new_num(current->c_val->c_num - 1);
		when P_UNROLL:
			DEBUG("UNROLL\n");
			Push(current);
			EnterUpdate(current->c_val);
		otherwise:
			error(INTERR, "illegal direction %d", dir);
		}
	when C_SUSP:
		DEBUG("SUSP: ");
		env = current->c_env;
		expr = current->c_expr;
		switch (expr->e_class) {
		when E_PAIR:
			DEBUG("PAIR\n");
			current = new_pair(new_susp(expr->e_left, env),
					   new_susp(expr->e_right, env));
		when E_APPLY:
			DEBUG("APPLY\n");
			Push(new_susp(expr->e_arg, env));
			current = new_susp(expr->e_func, env);
		when E_IF or E_LET or E_WHERE:
			DEBUG("LET\n");
			current = new_ucase(expr->e_func->e_code,
					   new_pair(new_susp(expr->e_arg, env),
						    env));
		when E_RLET or E_RWHERE:
			DEBUG("RLET\n");
			/* build a cyclic object */
			env = new_pair(new_susp(expr->e_arg, NULL_ENV), env);
			env->c_left->c_env = env;
			current = new_ucase(expr->e_func->e_code, env);
		when E_LAMBDA or E_EQN or E_THEN or E_PRESECT or E_POSTSECT:
			DEBUG("LAMBDA\n");
			top = take(current);
			if (top == FORCE_MARK)
				current = Pop();
			else { /* top is a normal value */
				chk_argument(top);
				current = new_ucase(expr->e_code,
						new_pair(top, env));
			}
		when E_DEFUN:
			DEBUG2("DEFUN: %s\n", expr->e_defun->f_name);
			cur_function = expr->e_defun->f_name;
			if (expr->e_defun->f_branch != NULL) {
				top = take(current);
				if (top == FORCE_MARK)
					current = Pop();
				else {	/* top is a normal value */
					chk_argument(top);
					current = new_ucase(
						expr->e_defun->f_code,
						new_pair(top, NULL_ENV));
				}
			}
			else if (expr->e_defun->f_value != NULL) {
				current = new_susp(expr->e_defun->f_value,
						   NULL_ENV);
			}
			else
				error(EXECERR, "undefined name: %s",
					expr->e_defun->f_name);
		when E_NUM:
			DEBUG("NUM: ");
			DEBUG2(NUMfmt, expr->e_num);
			DEBUG("\n");
			current = new_num(expr->e_num);
		when E_CHAR:
			DEBUG2("CHAR: '%c'\n", expr->e_char);
			current = new_char(expr->e_char);
		when E_CONST:
			DEBUG2("CONST: %s\n", expr->e_const->c_name);
			current = new_cnst(expr->e_const);
		when E_CONS:
			DEBUG2("CONS: %s\n", expr->e_const->c_name);
			top = take(current);
			if (top == FORCE_MARK)
				current = Pop();
			else {	/* top is a normal value */
				chk_argument(top);
				current = new_cons(expr->e_const, top);
			}
		when E_PARAM:
			DEBUG2("PARAM(%d)\n", expr->e_level);
			for (var = expr->e_level; var > 0; var--)
				env = env->c_right;
			current = new_dirs(expr->e_where, env->c_left);
		when E_BUILTIN:
			DEBUG("BUILTIN\n");
			/* Apply the built-in function to var 0,
			 * i.e the first element of the environment
			 */
			current = (*(expr->e_fn))(env->c_left);
		when E_BU_1MATH:
			DEBUG("BU_1MATH\n");
			current = new_num((*(expr->e_1math))
					(env->c_left->c_num));
		when E_BU_2MATH:
			DEBUG("BU_2MATH\n");
			current = new_num((*(expr->e_2math))
					(env->c_left->c_left->c_num,
					 env->c_left->c_right->c_num));
		when E_RETURN:
			DEBUG("RETURN\n");
			return;
		otherwise:
			error(INTERR, "illegal expression class %d",
				expr->e_class);
		}
	when C_UCASE:
		DEBUG("UCASE: ");
		code = current->c_code;
		env = current->c_env;
		switch (code->uc_class) {
		when UC_F_NOMATCH:
			DEBUG("F_NOMATCH\n");
			pr_f_match(code->uc_defun, evaluate(env->c_left));
			error(EXECERR, "no match found");
		when UC_L_NOMATCH:
			DEBUG("L_NOMATCH\n");
			pr_l_match(code->uc_who, env->c_right,
				evaluate(env->c_left));
			error(EXECERR, "no match found");
		when UC_CASE:
			DEBUG("CASE\n");
			tmp = new_dirs(code->uc_path, env->c_left);
			Push(tmp);		/* arg to LCASE or NCASE */
			Push(new_lcase(code->uc_cases, env));
			EnterUpdate(tmp);
		when UC_SUCCESS:
			DEBUG("SUCCESS\n");
			current = new_susp(code->uc_body, env);
		when UC_STRICT:
			DEBUG("STRICT\n");
			/* force the evaluation of var 0,
			 * i.e the first element of the environment,
			 * before continuing with the body (a built-in)
			 */
			Push(new_susp(code->uc_real, env));
			Force(env->c_left);
		otherwise:
			error(INTERR, "illegal upper case class %d",
				code->uc_class);
			NOT_REACHED;
		}
	when C_LCASE:
		DEBUG("LCASE: ");
		lcase = current->c_lcase;
		env = current->c_env;
		switch (lcase->lc_class) {
		when LC_ALGEBRAIC:
			DEBUG("LCASE\n");
			top = Pop();		/* arg (now updated) */
			code = lcase->lc_limbs[top->c_cons->c_index];
		when LC_NUMERIC:
			DEBUG("NUMERIC\n");
			top = Pop();		/* arg (now updated) */
			code = lcase->lc_limbs[top->c_num < Zero ? LESS :
						top->c_num == Zero ? EQUAL :
							GREATER];
		when LC_CHARACTER:
			DEBUG("CHARACTER\n");
			top = Pop();		/* arg (now updated) */
			code = ca_index(lcase->lc_c_limbs, top->c_char);
		otherwise:
			error(INTERR, "illegal lower case class %d",
				lcase->lc_class);
			NOT_REACHED;
		}
		current = new_ucase(code, env);
	otherwise:
		error(INTERR, "illegal value class %d", current->c_class);
	}
    }
}

local CELL *
take(current)
reg	CELL	*current;
{
	while (IsUpdate())
		*PopUpdate() = *current;	/* perform the update */
	return Pop();
}

/*
 *	Desperate kludge to catch comparison of functions.
 *	Cf init_cmps() in compare.c
 */
local void
chk_argument(arg)
reg	CELL	*arg;
{
	if (arg->c_class == C_SUSP &&
	    arg->c_expr->e_class == E_APPLY &&
	    arg->c_expr->e_arg->e_class == E_BUILTIN)
		error(EXECERR, "attempt to compare functions");
}
