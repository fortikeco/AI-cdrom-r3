#include "defs.h"
#include "expr.h"
#include "cases.h"
#include "char_array.h"
#include "path.h"

#define	MAX_MATCHES	60	/* max. constrs in a pattern (not checked) */
#define	MAX_PATHS	400	/* room for path storage */

typedef	struct {
	PATH	where;
	unsigned short	index, ncases;
} MATCH;

/* number and character cases are indicated by special values of ncases */

#define	NUMCASE	 10000	/* special ncases value: number match */
#define	CHARCASE 10001	/* special ncases value: character match */

#define	IsNumCase(m)	((m)->ncases == NUMCASE)
#define	IsCharCase(m)	((m)->ncases == CHARCASE)

local	MATCH	*m_end;
local	const	MATCH	*cur_match;
local	int	cur_size;
local	UCASE	*new_body;	/* the new body */

local	void	add_match
		ARGS((PATH where, natural ncases, natural index));
local	void	gen_char_match	ARGS((PATH here, natural c));
local	void	gen_num_match	ARGS((PATH here, NUM n));
local	natural	num_cases	ARGS((CONS *constr));
local	void	gen_matches	ARGS((PATH here, EXPR *pattern));

local	int	size_pattern	ARGS((EXPR *pattern));
local	void	limb_map	ARGS((LCASE *e, ELT_MAP *f));

local	UCASE	*gen_tree	ARGS((const MATCH *matches, UCASE *failure));
local	UCASE	*new_node
	ARGS((const MATCH *matches, UCASE *failure, UCASE *subtree));
local	UCASE	*merge		ARGS((UCASE *old));
local	UCASE	*sub_merge	ARGS((UCASE *old));
local	UCASE	*compile
	ARGS((UCASE *old_body, EXPR *pattern, EXPR *new));

/*
 * add another match to the list.
 */
local void
add_match(where, ncases, index)
	PATH	where;
	natural	ncases, index;
{
	m_end->where = p_save(p_reverse(where));
	m_end->ncases = ncases;
	m_end->index = index;
	m_end++;
}

local void
gen_char_match(here, c)
	PATH	here;
	natural	c;
{
	add_match(here, CHARCASE, c);
}

local void
gen_num_match(here, n)
	PATH	here;
	NUM	n;
{
	if (n > Zero) {
		add_match(here, NUMCASE, GREATER);
		gen_num_match(p_push(P_PRED, here), n-1);
	}
	else
		add_match(here, NUMCASE, EQUAL);
}

local natural
num_cases(constr)
reg	CONS	*constr;
{
	while (constr->c_next != NULL)
		constr = constr->c_next;
	return constr->c_index + 1;
}

/*
 * Generate the nodes of the matching tree given a path and a pattern.
 */
local void
gen_matches(here, pattern)
	PATH	here;
	EXPR	*pattern;
{
reg	int	i;

	switch (pattern->e_class) {
	when E_CHAR:
		gen_char_match(here, pattern->e_char);
	when E_NUM:
		gen_num_match(here, pattern->e_num);
	when E_CONST:
		add_match(here, num_cases(pattern->e_const),
			pattern->e_const->c_index);
	when E_APPLY:
		ASSERT( pattern->e_func->e_class == E_CONS );
		if (pattern->e_func->e_const == succ) {
			add_match(here, NUMCASE, GREATER);
			gen_matches(p_push(P_PRED, here), pattern->e_arg);
		}
		else {
			add_match(here, num_cases(pattern->e_func->e_const),
					pattern->e_func->e_const->c_index);
			gen_matches(p_push(P_STRIP, here), pattern->e_arg);
		}
	when E_PLUS:
		for (i = 0; i < pattern->e_incr; i++) {
			add_match(here, NUMCASE, GREATER);
			here = p_push(P_PRED, here);
		}
		gen_matches(here, pattern->e_arg);
	when E_PAIR:
		gen_matches(p_push(P_LEFT, here), pattern->e_left);
		gen_matches(p_push(P_RIGHT, here), pattern->e_right);
	}
}

local int
size_pattern(pattern)
reg	EXPR	*pattern;
{
	switch (pattern->e_class) {
	when E_APPLY:
		return size_pattern(pattern->e_arg) + 1;
	when E_PAIR:
		return size_pattern(pattern->e_left) +
			size_pattern(pattern->e_right);
	when E_NUM:
		return (int)(pattern->e_num) + 1;
	when E_CONST or E_CHAR:
		return 1;
	when E_PARAM:
		return 0;
	}
	NOT_REACHED 0;
}

local void
limb_map(lcase, f)
reg	LCASE	*lcase;
reg	ELT_MAP *f;
{
	if (lcase->lc_class == LC_CHARACTER)
		ca_map(lcase->lc_c_limbs, f);
	else {
	reg	UCASE	**this, **finish;

		finish = lcase->lc_limbs + lcase->lc_arity;
		for (this = lcase->lc_limbs; this != finish; this++)
			*this = (*f)(*this);
	}
}

/*
 * Generate the skinny matching tree from the given nodes,
 * patching in "new_body" at the leaf, and "failure" at each side branch.
 */
local UCASE *
gen_tree(matches, failure)
	const	MATCH	*matches;
	UCASE	*failure;
{
	return matches == m_end ? new_body :
		new_node(matches, failure, gen_tree(matches+1, failure));
}

local UCASE *
new_node(matches, failure, subtree)
	const	MATCH	*matches;
	UCASE	*failure, *subtree;
{
reg	LCASE	*limbs;

	if (IsCharCase(matches)) {
		limbs = char_case(failure);
		ca_assign(limbs->lc_c_limbs, matches->index, subtree);
	}
	else {
		limbs = IsNumCase(matches) ? num_case(failure) :
				alg_case(matches->ncases, failure);
		limbs->lc_limbs[matches->index] = subtree;
	}
	return ucase(p_stash(matches->where), limbs);
}

/*
 * Given the current matching tree, merge it with the tree generated from
 * the given nodes and expression.
 */
local UCASE *
merge(old)
reg	UCASE	*old;
{
reg	natural	i;
reg	LCASE	*lcase;

	switch (old->uc_class) {
	when UC_F_NOMATCH or UC_L_NOMATCH:	/* do all the matching */
		return gen_tree(cur_match, old);
	when UC_SUCCESS:
		if (old->uc_size < cur_size)	/* maybe more specific */
			return gen_tree(cur_match, old);
	when UC_CASE:
		if (cur_match < m_end &&
		    p_less(cur_match->where, old->uc_path)) {
			old->uc_references += old->uc_cases->lc_arity - 1;
			return new_node(cur_match, old, sub_merge(old));
		}
		if (old->uc_references > 1) {
			old->uc_references--;
			old = copy_ucase(old);
		}
		lcase = old->uc_cases;
		if (cur_match == m_end ||
		    p_less(old->uc_path, cur_match->where))
			limb_map(lcase, merge);
		else {	/* same place -- keep following */
			i = cur_match->index;
			if (lcase->lc_class == LC_CHARACTER)
				ca_assign(lcase->lc_c_limbs, i,
					sub_merge(ca_index(
						lcase->lc_c_limbs, i)));
			else
				lcase->lc_limbs[i] =
					sub_merge(lcase->lc_limbs[i]);
		}
	}
	return old;
}

local UCASE *
sub_merge(old)
	UCASE	*old;
{
	cur_match++;
	old = merge(old);
	cur_match--;
	return old;
}

/*
 * Given the current body, generate the new body as dictated by the given
 * pattern and expression.
 */
local UCASE *
compile(old_body, pattern, new)
	UCASE	*old_body;
	EXPR	*pattern, *new;
{
	MATCH	matchlist[MAX_MATCHES];
	char	path_buf[MAX_PATHS];

	m_end = matchlist;
	p_init(path_buf, MAX_PATHS);
	gen_matches(p_new(), pattern);
	cur_match = matchlist;
	cur_size = size_pattern(pattern);
	new_body = success(new, cur_size);
	return merge(old_body);
}

global UCASE *
comp_branch(old_body, branch)
	UCASE	*old_body;
	BRANCH	*branch;
{
	comp_expr(branch->br_expr);
	return compile(old_body, branch->br_pattern, branch->br_expr);
}

/*
 *	Compile all the LAMBDAs in expr.
 */
global void
comp_expr(expr)
reg	EXPR	*expr;
{
reg	BRANCH	*br;

	switch (expr->e_class) {
	when E_LAMBDA or E_THEN or E_EQN or E_PRESECT or E_POSTSECT:
		for (br = expr->e_branch; br != NULL; br = br->br_next) {
			comp_expr(br->br_expr);
			expr->e_code = comp_branch(expr->e_code, br);
		}
	when E_PAIR:
		comp_expr(expr->e_left);
		comp_expr(expr->e_right);
	when E_APPLY or E_IF or E_WHERE or E_LET or E_RWHERE or E_RLET:
		comp_expr(expr->e_func);
		comp_expr(expr->e_arg);
	}
}
