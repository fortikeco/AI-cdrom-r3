#include "defs.h"
#include "error.h"
#include "expr.h"
#include "cell.h"

#define	MAX_STREAMS	20	/* max. no. of streams (checked) */
#define	MAX_FILENAME	100	/* max. len. of file name (checked) */
#define	MAX_INPUTLINE	256	/* max. len. of tty input line (not checked) */

/*
 * Table of open streams,
 * so we can close any left open at the end of evaluation.
 */
local	FILE	*str_table[MAX_STREAMS];

local	int	get_one_char	ARGS((void));
local	void	end_stream	ARGS((FILE *f));

global CELL *
open_stream(arg)
	CELL	*arg;
{
	char	filename[MAX_FILENAME];
reg	FILE	**fp;

	hope2c((unsigned char *)filename, MAX_FILENAME, arg);

	/* find a free slot in the stream table */
	for (fp = str_table; *fp != NULL; fp++)
		if (fp == &str_table[MAX_STREAMS])
			error(EXECERR, "stream table full");

	/* try to open the file */
	if ((*fp = fopen(filename, "r")) == NULL)
		error(EXECERR, "can't read file '%s'", filename);
	return new_stream(*fp);
}

global CELL *
read_stream(cell)
reg	CELL	*cell;
{
reg	int	c;

	c = cell->c_file == stdin ? get_one_char() : getc(cell->c_file);
	if (c == EOF) {
		end_stream(cell->c_file);
		return new_cnst(nil);
	}
	return new_cons(cons,
		new_pair(new_char((natural)c), new_stream(cell->c_file)));
}

local	char	str_line[MAX_INPUTLINE];
local	const	unsigned char	*str_lptr;

global void
reset_streams()
{
reg	FILE	**fp;

	str_lptr = NULL;
	for (fp = str_table; fp != &str_table[MAX_STREAMS]; fp++)
		*fp = NULL;
}

/*
 * Read a line from standard input and build the list of characters,
 * adding the newline stripped by gets().
 *
 * We read a whole line, not just a character at a time, because
 *  (1) if not all the input is used, we want to discard the rest of the
 *	last line input.
 *  (2)	some environments (e.g. LightSpeed C on the Macintosh) don't support
 *	terminal input in the usual way (see gets.c).
 */
local int
get_one_char()
{
	if (str_lptr == NULL) {
		if (gets(str_line) == NULL) {
			clearerr(stdin);
			return EOF;
		}
		str_lptr = (const unsigned char *)str_line;
	}
	if (*str_lptr == '\0') {
		str_lptr = NULL;
		return '\n';
	}
	return *str_lptr++;
}

local void
end_stream(f)
reg	FILE	*f;
{
reg	FILE	**fp;

	if (f != stdin) {
		(void)fclose(f);
		for (fp = str_table; *fp != f; fp++)
			;
		*fp = NULL;
	}
}

global void
close_streams()
{
reg	FILE	**fp;

	for (fp = str_table; fp != &str_table[MAX_STREAMS]; fp++)
		if (*fp != NULL) {
			(void)fclose(*fp);
			*fp = NULL;
		}
}
