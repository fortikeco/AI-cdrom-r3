#ifndef CASES_H
#define CASES_H

#include "expr.h"

/*
 *	The upper part of case constructs.
 */

#define	UC_CASE		0	/* upper level of case expression */
#define	UC_F_NOMATCH	1	/* no-match error on function */
#define	UC_L_NOMATCH	2	/* no-match error on lambda */
#define	UC_SUCCESS	3	/* body expression */
#define	UC_STRICT	4	/* strict function */

struct _UCASE {
	short	uc_class;
	union {
		struct {		/* CASE */
			short	ucu_references;
			PATH	ucu_path;
			LCASE	*ucu_cases;
		} uc_case;
		FUNC	*ucu_defun;	/* F_NOMATCH */
		EXPR	*ucu_expr;	/* L_NOMATCH, STRICT */
		struct {		/* SUCCESS */
			short	ucu_size;
			EXPR	*ucu_body;
		} uc_success;
	} uc_union;
};
#define	uc_references	uc_union.uc_case.ucu_references	/* CASE */
#define	uc_path	uc_union.uc_case.ucu_path	/* CASE */
#define	uc_cases uc_union.uc_case.ucu_cases	/* CASE */
#define	uc_defun uc_union.ucu_defun		/* F_NOMATCH */
#define	uc_who	uc_union.ucu_expr		/* L_NOMATCH */
#define	uc_real	uc_union.ucu_expr		/* STRICT */
#define	uc_body	uc_union.uc_success.ucu_body	/* SUCCESS */
#define	uc_size	uc_union.uc_success.ucu_size	/* SUCCESS */

extern	UCASE	*ucase		ARGS((PATH path, LCASE *cases));
extern	UCASE	*f_nomatch	ARGS((FUNC *defun));
extern	UCASE	*l_nomatch	ARGS((EXPR *who));
extern	UCASE	*success	ARGS((EXPR *body, int size));
extern	UCASE	*strict		ARGS((EXPR *real));
extern	UCASE	*copy_ucase	ARGS((UCASE *old));

/*
 *	The lower part of case constructs.
 */

#define	LC_ALGEBRAIC	0	/* algebraic data type */
#define	LC_NUMERIC	1	/* numbers -- <0, 0, succ(n) */
#define	LC_CHARACTER	2	/* characters */

struct _LCASE {
	short	lc_class;
	int	lcu_arity;
	union {
		UCASE	**lcu_limbs;		/* ALGEBRAIC, NUMERIC */
		CHAR_ARRAY *lcu_c_limbs;	/* CHARACTER */
	} lc_union;
};
#define	lc_arity	lcu_arity
#define	lc_limbs	lc_union.lcu_limbs
#define	lc_c_limbs	lc_union.lcu_c_limbs

/* indexes for number cases */
#define	LESS	0
#define	EQUAL	1
#define	GREATER	2

extern	LCASE	*alg_case	ARGS((natural arity, UCASE *def));
extern	LCASE	*num_case	ARGS((UCASE *def));
extern	LCASE	*char_case	ARGS((UCASE *def));

#endif
