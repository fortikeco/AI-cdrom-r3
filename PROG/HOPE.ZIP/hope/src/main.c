#include "defs.h"
#include "memory.h"
#include "module.h"
#include "source.h"
#include "error.h"

#ifdef RE_EDIT
local	const	char	*program_name;
#endif

global void
main(argc, argv)
	int	argc;
	const	char	*argv[];
{
	init_memory();
	init_strings();
	init_lex();
	init_source();
#ifdef RE_EDIT
	program_name = argv[0];
	if (argc == 2)
		set_script(argv[1]);	/* re-entry after an edit */
#endif
	mod_init();		/* begin standard module */
	preserve();
	(void)yyparse();	/* read commands from files and user */
	heap_stats();
	(void)exit(0);
}

#ifdef RE_EDIT
/*
 *	Restart Hope, reading from the script_file.
 *	The neatest way would be to just longjmp back to the start,
 *	but it's too much trouble to get the external data back into
 *	the right state, or to make sure the program doesn't depend on
 *	its initial state.  So, we just exec ourselves again, passing
 *	the script_file as an argument.
 */
global void
restart(script_file)
	const	char	*script_file;
{
	(void)execlp(program_name, program_name, script_file, (char *)0);
	error(FATALERR, "cannot restart");
}
#endif
