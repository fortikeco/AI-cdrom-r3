#ifndef CHAR_ARRAY_H
#define CHAR_ARRAY_H

/*
 *	Sparse arrays indexed by characters.
 *	Specification:
 *
 *	index(new(x), c) = x
 *	index(copy(a), c) = index(a, c)
 *	index(assign(a, c', x), c) = if c' = c then x else index(a, c)
 *	index(map(a, f), c) = f(index(a, c))
 */
typedef	UCASE	*ARRAY_ELEMENT;
typedef	ARRAY_ELEMENT	ELT_MAP		ARGS((ARRAY_ELEMENT x));

extern	CHAR_ARRAY	*ca_new		ARGS((ARRAY_ELEMENT x));
extern	CHAR_ARRAY	*ca_copy	ARGS((CHAR_ARRAY *a));
extern	ARRAY_ELEMENT	ca_index	ARGS((CHAR_ARRAY *a, natural c));

extern	void	ca_assign
		ARGS((CHAR_ARRAY *a, natural c, ARRAY_ELEMENT x));
extern	void	ca_map		ARGS((CHAR_ARRAY *a, ELT_MAP *f));

#endif
