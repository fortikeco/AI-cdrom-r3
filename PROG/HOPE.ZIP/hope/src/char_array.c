#include "defs.h"
#include "expr.h"
#include "char_array.h"
#include "memory.h"

struct _CHAR_ARRAY {
	short	ca_size;
	unsigned char	*ca_index;	/* ordered array of length size */
	ARRAY_ELEMENT	*ca_value;	/* corresponding array of values */
	ARRAY_ELEMENT	ca_default;
};

#define	MIN_POWER	1
#define	MIN_SIZE	(2<<MIN_POWER)

/*
 * Allocation strategy: the length of the arrays is always a power of 2,
 * starting at MIN_SIZE.  Thus the array is full if the size is >= MIN_SIZE
 * and is a power of 2.  At that point we allocate new arrays twice as long
 * as the old ones, and discard the old arrays.  This means an average
 * space wastage of 100%, but tree schemes are even worse.  This could be
 * ameliorated by free lists, and by using Fibonacci numbers for the sizes,
 * but that's a bit too tricky for me.
 */

global CHAR_ARRAY *
ca_new(x)
	ARRAY_ELEMENT	x;
{
reg	CHAR_ARRAY	*array;

	array = NEW(CHAR_ARRAY);
	array->ca_size = 0;
	array->ca_index = NEWARRAY(unsigned char, MIN_SIZE);
	array->ca_value = NEWARRAY(ARRAY_ELEMENT, MIN_SIZE);
	array->ca_default = x;
	return array;
}

global CHAR_ARRAY *
ca_copy(array)
reg	CHAR_ARRAY	*array;
{
reg	CHAR_ARRAY	*new_array;
reg	int	n;

	new_array = NEW(CHAR_ARRAY);
	new_array->ca_size = array->ca_size;
	for (n = MIN_SIZE; n < array->ca_size; n *= 2)
		;
	new_array->ca_index = NEWARRAY(unsigned char, n);
	new_array->ca_value = NEWARRAY(ARRAY_ELEMENT, n);
	for (n = 0; n < array->ca_size; n++) {
		new_array->ca_index[n] = array->ca_index[n];
		new_array->ca_value[n] = array->ca_value[n];
	}
	new_array->ca_default = array->ca_default;
	return new_array;
}

/*
 *	Binary search for element in ordered array.
 *	Returns index of c in array if successful, otherwise size.
 */
local int
ca_lookup(array, size, c)
reg	unsigned char	*array;
	int	size;
reg	natural	c;
{
reg	int	low, mid, high;

	low = 0;
	high = size;
	while (low != high) {
		/*
		 * Invariant:
		 *	0 <= n < low => array[n] < c
		 *	high <= n < size => array[n] <= c
		 * Bound function: high - low
		 */
		mid = (low+high)/2;
		if (array[mid] < c)
			low = mid+1;
		else
			high = mid;
	}
	return low < size && array[low] == c ? low : size;
}

global ARRAY_ELEMENT
ca_index(array, c)
reg	CHAR_ARRAY	*array;
	natural	c;
{
reg	int	n;

	n = ca_lookup(array->ca_index, array->ca_size, c);
	return n == array->ca_size ? array->ca_default : array->ca_value[n];
}

local void
ca_insert(array, c, x)
reg	CHAR_ARRAY	*array;
reg	natural	c;
	ARRAY_ELEMENT	x;
{
reg	int	size;
reg	int	n;
reg	unsigned char	*new_index;
reg	ARRAY_ELEMENT	*new_value;

	size = array->ca_size;
	if (size >= MIN_SIZE && (size&(size-1)) == 0) {
		new_index = NEWARRAY(unsigned char, size*2);
		new_value = NEWARRAY(ARRAY_ELEMENT, size*2);
		for (n = 0; n < size; n++) {
			new_index[n] = array->ca_index[n];
			new_value[n] = array->ca_value[n];
		}
		array->ca_index = new_index;
		array->ca_value = new_value;
	}
	for (n = size; n > 0 && array->ca_index[n-1] > c; n--) {
		array->ca_index[n] = array->ca_index[n-1];
		array->ca_value[n] = array->ca_value[n-1];
	}
	array->ca_index[n] = c;
	array->ca_value[n] = x;
	array->ca_size = size+1;
}

global void
ca_assign(array, c, x)
reg	CHAR_ARRAY	*array;
	natural	c;
	ARRAY_ELEMENT	x;
{
reg	int	n;

	n = ca_lookup(array->ca_index, array->ca_size, (natural)c);
	if (n < array->ca_size)
		array->ca_value[n] = x;
	else
		ca_insert(array, (natural)c, x);
}

global void
ca_map(array, f)
reg	CHAR_ARRAY	*array;
reg	ELT_MAP	*f;
{
reg	int	n;

	for (n = 0; n < array->ca_size; n++)
		array->ca_value[n] = (*f)(array->ca_value[n]);
	array->ca_default = (*f)(array->ca_default);
}
