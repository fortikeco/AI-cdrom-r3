#include "defs.h"
#include "expr.h"
#include "cell.h"
#include "path.h"

global CELL *
new_pair(left, right)
	CELL	*left, *right;
{
reg	CELL	*cp;

	cp = new_cell(C_PAIR);
	cp->c_left = left;
	cp->c_right = right;
	return cp;
}

global CELL *
new_dirs(path, val)
	PATH	path;
	CELL	*val;
{
reg	CELL	*cp;

	cp = new_cell(C_DIRS);
	cp->c_path = path;
	cp->c_val = val;
	return cp;
}

global CELL *
new_cons(data_constructor, arg)
	CONS	*data_constructor;
	CELL	*arg;
{
reg	CELL	*cp;

	cp = new_cell(C_CONS);
	cp->c_cons = data_constructor;
	cp->c_arg = arg;
	return cp;
}

global CELL *
new_susp(expr, env)
	EXPR	*expr;
	CELL	*env;
{
reg	CELL	*cp;

	cp = new_cell(C_SUSP);
	cp->c_expr = expr;
	cp->c_env = env;
	return cp;
}

global CELL *
new_ucase(code, env)
	UCASE	*code;
	CELL	*env;
{
reg	CELL	*cp;

	cp = new_cell(C_UCASE);
	cp->c_code = code;
	cp->c_env = env;
	return cp;
}

global CELL *
new_lcase(lcase, env)
	LCASE	*lcase;
	CELL	*env;
{
reg	CELL	*cp;

	cp = new_cell(C_LCASE);
	cp->c_lcase = lcase;
	cp->c_env = env;
	return cp;
}

global CELL *
new_cnst(data_constant)
	CONS	*data_constant;
{
reg	CELL	*cp;

	cp = new_cell(C_CONST);
	cp->c_cons = data_constant;
	return cp;
}

global CELL *
new_num(n)
	NUM	n;
{
reg	CELL	*cp;

	cp = new_cell(C_NUM);
	cp->c_num = n;
	return cp;
}

global CELL *
new_char(c)
	natural	c;
{
reg	CELL	*cp;

	cp = new_cell(C_CHAR);
	cp->c_char = c;
	return cp;
}

global CELL *
new_stream(f)
	FILE	*f;
{
reg	CELL	*cp;

	cp = new_cell(C_STREAM);
	cp->c_file = f;
	return cp;
}

global CELL *
new_tcons(tcons, targ)
	DEFTYPE	*tcons;
	CELL	*targ;
{
reg	CELL	*cp;

	cp = new_cell(C_TCONS);
	cp->c_tcons = tcons;
	cp->c_targ = targ;
	return cp;
}

global CELL *
new_tvar(var)
	TVAR	var;
{
reg	CELL	*cp;

	cp = new_cell(C_TVAR);
	cp->c_tvar = var;
	cp->c_targ = NOCELL;
	return cp;
}
