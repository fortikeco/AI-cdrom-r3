#include "defs.h"
#include "deftype.h"
#include "op.h"
#include "print.h"

/*
 *	Printing of types.
 */

local	void	ty_print	ARGS((FILE *f, TYPE *type, int context));
local	int	ty_precedence	ARGS((TYPE *type));
local	void	pr_alt		ARGS((FILE *f, CONS *alt));

global void
pr_type(f, type)
	FILE	*f;
	TYPE	*type;
{
	ty_print(f, type, PREC_BODY);
}

local void
ty_print(f, type, context)
	FILE	*f;
reg	TYPE	*type;
	int	context;
{
	OP	*op;
	int	prec;

	prec = ty_precedence(type);
	if (prec < context)
		(void)fprintf(f, "(");
	if (type->ty_variable)
		(void)fprintf(f, "%s", type->ty_var);
	else if (type->ty_firstarg == NULL)
		(void)fprintf(f, "%s", type->ty_deftype->dt_name);
	else if (type->ty_secondarg == NULL) {
		(void)fprintf(f, "%s ", type->ty_deftype->dt_name);
		ty_print(f, type->ty_firstarg, PREC_ARG);
	}
	else if ((op = op_lookup(type->ty_deftype->dt_name)) != NULL) {
		ty_print(f, type->ty_firstarg, LeftPrec(op));
		(void)fprintf(f, " %s ", type->ty_deftype->dt_name);
		ty_print(f, type->ty_secondarg, RightPrec(op));
	}
	else {
		(void)fprintf(f, "%s (", type->ty_deftype->dt_name);
		for (type = type->ty_firstarg;
		     type != NULL;
		     type = type->ty_next) {
			ty_print(f, type, PREC_BODY);
			if (type->ty_next != NULL)
				(void)fprintf(f, ", ");
		}
		(void)fprintf(f, ")");
	}
	if (prec < context)
		(void)fprintf(f, ")");
}

local int
ty_precedence(type)
reg	TYPE	*type;
{
	OP	*op;

	if (type->ty_variable || type->ty_firstarg == NULL)
		return PREC_ATOMIC;
	if (type->ty_secondarg != NULL &&
	    (op = op_lookup(type->ty_deftype->dt_name)) != NULL)
		return op->op_prec;
	return PREC_APPLY;
}

global void
pr_deftype(f, dt, full)
	FILE	*f;
reg	DEFTYPE	*dt;
	bool	full;
{
reg	TYPE	*type;
reg	CONS	*alt;

	(void)fprintf(f, "%s ",
		full && dt->dt_synonym ? "type" :
		full && dt->dt_cons != NULL ? "data" : "abstype");
	if (dt->dt_varlist == NULL)
		(void)fprintf(f, "%s", dt->dt_name);
	else if (dt->dt_varlist->ty_next == NULL)
		(void)fprintf(f, "%s %s",
			dt->dt_name, dt->dt_varlist->ty_var);
	else if (op_lookup(dt->dt_name) != NULL)
		(void)fprintf(f, "%s %s %s",
			dt->dt_varlist->ty_var,
			dt->dt_name,
			dt->dt_varlist->ty_next->ty_var);
	else {
		(void)fprintf(f, "%s(", dt->dt_name);
		for (type = dt->dt_varlist; type != NULL; type = type->ty_next)
			(void)fprintf(f, type->ty_next == NULL ? "%s" : "%s, ",
				type->ty_var);
		(void)fprintf(f, ")");
	}
	if (full)
		if (dt->dt_synonym) {
			(void)fprintf(f, " == ");
			pr_type(f, dt->dt_type);
		}
		else if (dt->dt_cons != NULL) {
			(void)fprintf(f, " == ");
			for (alt = dt->dt_cons;
			     alt != NULL;
			     alt = alt->c_next) {
				pr_alt(f, alt);
				if (alt->c_next != NULL)
					(void)fprintf(f, " ++ ");
			}
		}
	(void)fprintf(f, ";\n");
}

local void
pr_alt(f, alt)
	FILE	*f;
	CONS	*alt;
{
	OP	*op;

	if (! alt->c_constructor)
		(void)fprintf(f, "%s", alt->c_name);
	else if ((op = op_lookup(alt->c_name)) != NULL) {
		ty_print(f, alt->c_type->ty_firstarg->ty_firstarg,
			LeftPrec(op));
		(void)fprintf(f, " %s ", alt->c_name);
		ty_print(f, alt->c_type->ty_firstarg->ty_secondarg,
			RightPrec(op));
	}
	else {
		(void)fprintf(f, "%s ", alt->c_name);
		ty_print(f, alt->c_type->ty_firstarg, PREC_ARG);
	}
}
