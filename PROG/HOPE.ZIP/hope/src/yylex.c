/*
 *	Lexical analysis
 */
#include "defs.h"
#include "op.h"
#include "newstring.h"
#include "num.h"
#include "text.h"
#include "source.h"
#include "error.h"
#include "typevar.h"
#include "deftype.h"
#include "expr.h"
#include "yyparse.h"

#define	MAX_STRING	100	/* max. size of string (checked) */

typedef struct {
	const	char	*sym_name;	/* string to match -- NULL for end */
	short	sym_token;	/* token returned to yacc */
} SYMBOL;

#define	NCHARS	256

/* reserved identifiers */
local	SYMBOL	reserved[] = {
	{ "++",		OR	},
	{ "---",	VALOF	},
	{ ":",		':'	},
	{ "<=",		IS	},
	{ "==",		EQ	},
	{ "=>",		GIVES	},
	{ "\\",		LAMBDA	},
	{ "abstype",	ABSTYPE	},
	{ "data",	DATA	},
	{ "dec",	DEC	},
	{ "display",	DISPLAY	},
#ifdef	RE_EDIT
	{ "edit",	EDIT	},
#endif
	{ "else",	ELSE	},
	{ "end",	END	},
	{ "exit",	EXIT	},
	{ "if",		IF	},
	{ "in",		IN	},
	{ "infix",	INFIX	},
	{ "infixr",	INFIXR	},
	{ "infixrl",	INFIXR	},	/* for backward compatability */
	{ "lambda",	LAMBDA	},
	{ "let",	LET	},
	{ "letrec",	LETREC	},
	{ "module",	MODSYM	},
	{ "nonop",	NONOP	},	/* for backward compatability */
	{ "private",	PRIVATE	},
	{ "pubconst",	PUBCONST },
	{ "pubfun",	PUBFUN	},
	{ "pubtype",	PUBTYPE	},
	{ "save",	SAVE	},
	{ "then",	THEN	},
	{ "to",		TO	},
	{ "type",	TYPESYM	},
	{ "typevar",	TYPEVAR	},
	{ "use",	USES	},	/* for backward compatability */
	{ "uses",	USES	},
	{ "where",	WHERE	},
	{ "whererec",	WHEREREC },
	{ "write",	WRITE	},
	{ "|",		'|'	},
	{ NULL, 0}
};

/* character classes */
#define	Ill	0	/* Illegal character - must be zero */
#define	Oper	1
#define	Letter	2
#define	Digit	3
#define	String	4
#define	Char	5
#define	Comment	6
#define	Layout	7
#define	Punct	8
#define	Eol	9

/*
 *	Table mapping characters to classes.
 *	Note that trailing locations will be padded with 0 (i.e. Ill).
 */
local	const	char	symclass[NCHARS] = {
     /* nul	soh	stx	etx	eot	enq	ack	bel	*/
	Eol,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* bs	ht	nl	vt	np	cr	so	si	*/
	Ill,	Layout,	Layout,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* dle	dc1	dc2	dc3	dc4	nak	syn	etb	*/
	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* can	em	sub	esc	fs	gs	rs	us	*/
	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* sp	!	"	#	$	%	&	'	*/
	Layout,	Comment,String,	Oper,	Oper,	Oper,	Oper,	Char,
     /* (	)	*	+	,	-	.	/	*/
	Punct,	Punct,	Oper,	Oper,	Punct,	Oper,	Oper,	Oper,
     /* 0	1	2	3	4	5	6	7	*/
	Digit,	Digit,	Digit,	Digit,	Digit,	Digit,	Digit,	Digit,
     /* 8	9	:	;	<	=	>	?	*/
	Digit,	Digit,	Oper,	Punct,	Oper,	Oper,	Oper,	Oper,
     /* @	A	B	C	D	E	F	G	*/
	Oper,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* H	I	J	K	L	M	N	O	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* P	Q	R	S	T	U	V	W	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* X	Y	Z	[	\	]	^	_	*/
	Letter,	Letter,	Letter,	Punct,	Oper,	Punct,	Oper,	Letter,
     /* `	a	b	c	d	e	f	g	*/
	Oper,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* h	i	j	k	l	m	n	o	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* p	q	r	s	t	u	v	w	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* x	y	z	{	|	}	~	del	*/
	Letter,	Letter,	Letter,	Punct,	Oper,	Punct,	Oper,	Ill,
/* ISO-8859-1: */
	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* sp'	!`	cent	\pounds	curr.	yen	bar2	\S	*/
	Letter,	Oper,	Oper,	Oper,	Oper,	Oper,	Oper,	Oper,
     /* dier.	(C)	^a	<<	\neg	hyphen	(R)	macron	*/
	Oper,	Oper,	Oper,	Oper,	Oper,	Oper,	Oper,	Oper,
     /* degree	\pm	^2	^3	acute	\mu	\P	\cdot	*/
	Oper,	Oper,	Letter,	Letter,	Oper,	Letter,	Oper,	Oper,
     /* cedilla	^1	^o	>>	1/4	1/2	3/4	?`	*/
	Oper,	Letter,	Oper,	Oper,	Oper,	Oper,	Oper,	Oper,
     /* \`{A}	\'{A}	\^{A}	\~{A}	\"{A}	\AA	\AE	\c{C}	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* \`{E}	\'{E}	\^{E}	\"{E}	\`{I}	\'{I}	\^{I}	\"{I}	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* Eth	\~{N}	\`{O}	\'{O}	\^{O}	\~{O}	\"{O}	\times	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Oper,
     /* \O	\`{U}	\'{U}	\^{U}	\"{U}	\'{Y}	Thorn	\ss	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* \`{a}	\'{a}	\^{a}	\~{a}	\"{a}	\aa	\ae	\c{c}	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* \`{e}	\'{e}	\^{e}	\"{e}	\`{\i}	\'{\i}	\^{\i}	\"{\i}	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* eth	\~{n}	\`{o}	\'{o}	\^{o}	\~{o}	\"{o}	\div	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Oper,
     /* \o	\`{u}	\'{u}	\^{u}	\"{u}	\'{y}	thorn	\"{y}	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter
};

local	bool	scan_string	ARGS((void));
local	natural	charesc		ARGS((void));
local	natural	hexdigit	ARGS((natural c));
local	natural	octdigit	ARGS((natural c));
local	int	lookup		ARGS((STRING s));

global void
init_lex()
{
reg	SYMBOL	*p;

	for (p = reserved; p->sym_name != NULL; p++)
		p->sym_name = newstring(p->sym_name);
}

global int
yylex()
{
reg	natural	c;
reg	const	unsigned char	*start;

	repeat {
		start = inptr;
		switch (symclass[c = *inptr++]) {
		when Layout:
			/* ignore white space */
		when Eol:
			if (interactive() && recovering()) {
				/*
				 * try to assist syntax error recovery
				 * by inserting a semicolon, so the next
				 * line can start afresh.
				 */
				inptr--;
				return ';';
			}
			if (! getline())
				return EOF;
		when Comment:
			while (*inptr != '\0')
				inptr++;
		when Char:
			c = *inptr++;
			if (c == '\\')
				c = charesc();
			if (c >= NCHARS)
				error(LEXERR, "illegal character %d", c);
			else {
				yylval.charval = c;
				if (symclass[*inptr++] == Char)
					return CHAR;
				inptr--;
				error(LEXERR, "non-terminated character");
			}
		when String:
			if (scan_string())
				return LITERAL;
		when Digit:
			while (symclass[*inptr] == Digit)
				inptr++;
#ifdef REALS
			if (*inptr == '.' && symclass[*(inptr+1)] == Digit) {
				inptr += 2;
				while (symclass[*inptr] == Digit)
					inptr++;
			}
			if (*inptr == 'e' &&
			    ((*(inptr+1) == '+' || *(inptr+1) == '-' &&
			      symclass[*(inptr+2)] == Digit) ||
			     symclass[*(inptr+1)] == Digit)) {
				inptr += 2;
				while (symclass[*inptr] == Digit)
					inptr++;
			}
#endif
			yylval.numval = atoNUM((const char *)start);
			return NUMBER;
		when Letter:
			while (symclass[c = *inptr] == Letter ||
			       symclass[c] == Digit)
				inptr++;
			while (*inptr == '\'')
				inptr++;
			return lookup(newnstring((const char *)start,
					(int)(inptr-start)));
		when Oper:
			while (symclass[*inptr] == Oper)
				inptr++;
			return lookup(newnstring((const char *)start,
					(int)(inptr-start)));
		when Ill:
			error(LEXERR, "illegal character %d", c);
		when Punct:
			return c;
		}
	}
}

local bool
scan_string()
{
static	unsigned char	literal[MAX_STRING+1]; /* space for string constants */
static	TEXT	lit_text;
reg	unsigned char	*lp;
reg	natural	c;

	lp = literal;
	while ((c = *inptr++) != '\0') {
		if (symclass[c] == String) {
			if (lp == &literal[MAX_STRING])
				error(LEXERR, "string too long");
			*lp = '\0';
			lit_text.t_start = literal;
			lit_text.t_length = (int)(lp-literal);
			yylval.textval = &lit_text;
			return TRUE;
		}
		if (c == '\\')
			c = charesc();
		if (c >= NCHARS)
			error(LEXERR, "illegal character %d", c);
		else if (lp != &literal[MAX_STRING])
			*lp++ = c;
	}
	inptr--;
	error(LEXERR, "non-terminated string");
	return FALSE;
}

/*
 *	Escaped character sequence -- last char was a backslash.
 */
local natural
charesc()
{
	natural	c;

	switch (c = *inptr++) {
	when 'a': return '\007';	/* not all C's have \a */
	when 'b': return '\b';
	when 'f': return '\f';
	when 'n': return '\n';
	when 'r': return '\r';
	when 't': return '\t';
	when 'v': return '\013';	/* not all C's have \v */
	when 'x': /* hexadecimal */
		c = hexdigit((natural)0);
		return hexdigit(c);
	when '0' or '1' or '2' or '3' or '4' or '5' or '6' or '7': /* octal */
		c = octdigit(c - '0');
		return octdigit(c);
	when '\0':
		/* will be reported as a non-terminated character or string */
		inptr--;
		return '\\';
	}
	return c;
}

local natural
hexdigit(c)
	natural	c;
{
	if ('0' <= *inptr && *inptr <= '9')
		return c*16 + *inptr++ - '0';
	if ('a' <= *inptr && *inptr <= 'f')
		return c*16 + *inptr++ - 'a' + 10;
	if ('A' <= *inptr && *inptr <= 'F')
		return c*16 + *inptr++ - 'A' + 10;
	return c;
}

local natural
octdigit(c)
	natural	c;
{
	if ('0' <= *inptr && *inptr <= '7')
		return c*8 + *inptr++ - '0';
	return c;
}

local int
lookup(s)
reg	STRING	s;
{
reg	SYMBOL	*p;
reg	OP	*op;

	for (p = reserved; p->sym_name != NULL; p++)
		if (p->sym_name == s)
			return p->sym_token;
	yylval.strval = s;
	if ((op = op_lookup(s)) != NULL)
		/*
		 * Operator tokens: this rests on knowing the order
		 * in which the tokens are generated by Mult-op.awk,
		 * and the fact that BIN_BASE comes immediately before
		 * the first binary token (assured by Mult-op.awk).
		 */
		return (op->op_prec - MINPREC)*NUM_ASSOC +
			(int)(op->op_assoc) + BIN_BASE + 1;
	return IDENT;
}
