#ifndef PATH_H
#define PATH_H

#include "defs.h"

typedef char	*PATH;
#define MAXPATH		40

#define P_END		0
#define P_LEFT		1
#define P_RIGHT		2
#define P_STRIP		3
#define P_PRED		4
#define P_UNROLL	5

#define P_NCLASSES	6

#define	P_EMPTY		""

#define p_equal(p1,p2)	(strcmp(p1, p2) == 0)
#define p_less(p1,p2)	(strcmp(p1, p2) < 0)
#define	p_empty(p)	(*(p) == P_END)
#define p_pop(p)	((p)+1)
#define p_top(p)	(*(p))

/* new paths, overwritten by next call */
extern	PATH	p_new		ARGS((void));
extern	PATH	p_reverse	ARGS((PATH p));

/* to be used only on a path supplied by p_new() or p_push() */
extern	PATH	p_push		ARGS((int dir, PATH p));

/* temporary storage for a number of paths */
extern	void	p_init		ARGS((char *buf, int size));
extern	PATH	p_save		ARGS((PATH p));

/* permanent storage for paths */
extern	PATH	p_stash		ARGS((PATH p));

#endif
