#ifndef SET_H
#define SET_H

#define BYTESIZE	8
#define WORDSIZE	(BYTESIZE*sizeof(natural))

/* declare a set of [0..size-1] */
#define	SET(name,size)	natural	name[((size)+WORDSIZE-1)/WORDSIZE]
#define	NWords(set)	((natural)(sizeof(set)/sizeof(natural)))

typedef	natural	*SETPTR;	/* local reference to a set */

extern	void	set_clear	ARGS((SETPTR s, natural n));
extern	natural	set_card	ARGS((SETPTR s, natural n));
extern	void	set_union
		ARGS((SETPTR s1, natural n1, SETPTR s2, natural n2));

#define ADD(set,n)	(set[(n)/WORDSIZE] |= 1<<((n)%WORDSIZE))
#define REMOVE(set,n)	(set[(n)/WORDSIZE] &= ~(1<<((n)%WORDSIZE)))
#define MEMBER(set,n)	((set[(n)/WORDSIZE] & 1<<((n)%WORDSIZE)) != 0)

/* the following do NOT work on SETPTRs */
#define	CLEAR(set)	set_clear(set, NWords(set))
#define	CARD(set)	set_card(set, NWords(set))
#define	UNION(set1,set2) set_union(set1, NWords(set1), set2, NWords(set2))

#endif
