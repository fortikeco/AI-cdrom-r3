#include "defs.h"
#include "memory.h"
#include "error.h"
#include "align.h"

/* size of space for compiled code, tables, stack and heap */
#define	MEMSIZE 500000L

/*
 * The granularity of allocation is the alignment granularity.
 */
#define	RoundDown(n)	((n)/ALIGNMENT*ALIGNMENT)
#define	RoundUp(n)	(((n) + ALIGNMENT-1)/ALIGNMENT*ALIGNMENT)

global	char	*base_memory, *top_memory;
global	char	*top_string, *base_table, *base_temp;
global	char	*lim_temp;

global void
init_memory()
{
	if ((base_memory = (char *)malloc((Size_t)MEMSIZE)) == NULL)
		error(FATALERR, "not enough memory");
	top_memory = base_memory + RoundDown(MEMSIZE);

	lim_temp = top_string = base_memory;
	base_table = base_temp = top_memory;
}

global void_p
s_alloc(n)
	natural	n;
{
reg	char	*start;

	start = top_string;
	top_string += RoundUp(n);
	lim_temp = top_string;
	if (base_temp < lim_temp)
		error(FATALERR, "can't store string: out of memory");
	return (void_p)start;
}

global void_p
t_alloc(n)
	natural	n;
{
	base_temp -= RoundUp(n);
	if (base_temp < lim_temp)
		error(FATALERR, "out of memory");
	return (void_p)base_temp;
}

global void
clean_slate()
{
	base_temp = base_table;
	lim_temp = top_string;
}

global void
preserve()
{
	base_table = base_temp;
	lim_temp = top_string;
}
