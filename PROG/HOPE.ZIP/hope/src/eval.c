#include "defs.h"
#include "expr.h"
#include "error.h"
#include "exceptions.h"

/*
 *	Evaluation of expressions.
 */

global	jmp_buf	execerror;

global void
eval_expr(expr)
	EXPR	*expr;
{
	if (erroneous)
		return;
	if (nr_branch(new_branch(id_pattern(newstring("input")), expr))) {
		reset_streams();
		if (! setjmp(execerror)) {
			chk_expr(expr);
			comp_expr(expr);
			interpret(e_print, expr);
		}
		close_streams();
	}
}

global void
wr_expr(expr, file)
	EXPR	*expr;
	const	char	*file;
{
	if (erroneous)
		return;
	if (nr_branch(new_branch(id_pattern(newstring("input")), expr))) {
		reset_streams();
		if (! setjmp(execerror)) {
			open_out_file(file);
			chk_list(expr);
			comp_expr(expr);
			interpret(e_wr_list, expr);
			save_out_file();
		}
		else
			close_out_file();
		close_streams();
	}
}
