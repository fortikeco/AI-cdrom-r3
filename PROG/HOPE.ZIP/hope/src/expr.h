#ifndef EXPR_H
#define EXPR_H

#include "newstring.h"
#include "table.h"
#include "deftype.h"
#include "path.h"
#include "num.h"

typedef	struct _EXPR	EXPR;
typedef	struct _BRANCH	BRANCH;
typedef	struct _CELL	CELL;
typedef	struct _UCASE	UCASE;
typedef	struct _LCASE	LCASE;
typedef	struct _CHAR_ARRAY	CHAR_ARRAY;

typedef	CELL	*FUNCTION	ARGS((CELL *value));
typedef	NUM	UNARY		ARGS((NUM x));
typedef	NUM	BINARY		ARGS((NUM x, NUM y));

typedef	struct {
	TAB_ELT	f_linkage;
	TYPE	*f_type;
	BRANCH	*f_branch;
	union {
		UCASE	*fu_code;	/* if f_branch != NULL */
		EXPR	*fu_value;	/* if f_branch == NULL */
	} f_union;
} FUNC;
#define	f_name	f_linkage.t_name
#define	f_code	f_union.fu_code
#define	f_value	f_union.fu_value

extern	void	new_fn		ARGS((STRING name, TYPE *type));
extern	FUNC	*fn_lookup	ARGS((STRING name));
extern	FUNC	*fn_local	ARGS((STRING name));

extern	void	decl_func	ARGS((STRING name, TYPE *type));
extern	void	def_cons	ARGS((STRING name, EXPR *expr));
extern	void	define		ARGS((STRING name, BRANCH *branch));

extern	void	eval_expr	ARGS((EXPR *expr));
extern	void	wr_expr		ARGS((EXPR *expr, const char *file));

/*
 *	Expressions, including patterns.
 */

/* kinds of input expression that also appear as patterns */
#define	E_NUM	0	/* integer constant */
#define	E_CHAR	1	/* character constant */
#define	E_CONST 2	/* data structure constant */
#define	E_CONS	3	/* data structure constructor */
#define	E_PAIR	4	/* pair constructor (,) */
#define	E_APPLY 5	/* function application */
/* kinds of input pattern that don't appear in expressions */
#define	E_VAR	6	/* variable in pattern */
#define	E_PLUS	7	/* p+k pattern */
/* kinds of input expression that don't appear in patterns */
#define	E_DEFUN 8	/* declared function or constant */
#define	E_LAMBDA 9	/* anonymous (lambda) function */
#define	E_PARAM 10	/* variable in expression */
/* variants on APPLY, LAMBDA for building various constructs */
#define	E_IF	11	/* if-then-else (like APPLY) */
#define	E_THEN	12	/* body of if (like LAMBDA) */
#define	E_WHERE 13	/* where clause (like APPLY) */
#define	E_LET	14	/* let ... in clause (like APPLY) */
#define	E_RWHERE 15	/* recursive where clause */
#define	E_RLET	16	/* recursive let ... in clause */
#define	E_EQN	17	/* let/where equation (like LAMBDA) */
#define	E_PRESECT 18	/* (e op) (like LAMBDA) */
#define	E_POSTSECT 19	/* (op e) (like LAMBDA) */
/* expressions used to represent built-in functions */
#define	E_BUILTIN 20	/* lower level of built-in function */
			/* Warning: this is misused by chk_argument() */
			/* you should understand it before changing these */
#define	E_BU_1MATH 21	/* lower level of unary built-in math function */
#define	E_BU_2MATH 22	/* lower level of binary built-in math function */
/* miscellaneous */
#define	E_RETURN 23	/* return from execution */

#define	E_NCLASSES 24

typedef	char	E_CLASS;

struct _EXPR {
	E_CLASS	e_class;
	char	e_misc_num;	/* VAR, PARAM */
	union {	/* grab bag -- see the definitions below */
		NUM	eu_num;		/* NUM */
		natural	eu_char;	/* CHAR */
		CONS	*eu_const;	/* CONST, CONS */
		struct {		/* VAR */
			STRING	eu_vname;
			PATH	eu_dirs;
		} e_v;
		struct {		/* PARAM */
			EXPR	*eu_patt;
			PATH	eu_where;
		} e_p;
		struct {		/* PAIR, APPLY */
			EXPR	*eu_left;
			EXPR	*eu_right;
		} e_pair;
		struct {		/* PLUS */
			int	eu_incr;
			EXPR	*eu_rest;
		} e_plus;
		FUNC	*eu_defun;	/* DEFUN */
		struct {		/* LAMBDA */
			BRANCH	*eu_branch;
			UCASE	*eu_code;
		} e_lambda;
		FUNCTION *eu_fn;	/* BUILTIN */
		UNARY	*eu_1math;	/* BU_1MATH */
		BINARY	*eu_2math;	/* BU_2MATH */
	} e_union;
};

#define	e_num	e_union.eu_num		/* NUM */
#define	e_char	e_union.eu_char		/* CHAR */
#define	e_const	e_union.eu_const	/* CONST, CONS */
#define	e_vname	e_union.e_v.eu_vname	/* VAR */
#define	e_var	e_misc_num		/* VAR */
#define	e_dirs	e_union.e_v.eu_dirs 	/* VAR */
#define	e_patt	e_union.e_p.eu_patt	/* PARAM */
#define	e_level	e_misc_num		/* PARAM */
#define	e_where	e_union.e_p.eu_where	/* PARAM */
#define	e_left	e_union.e_pair.eu_left	/* PAIR */
#define	e_right	e_union.e_pair.eu_right	/* PAIR */
#define	e_func	e_union.e_pair.eu_left	/* APPLY */
#define	e_arg	e_union.e_pair.eu_right	/* APPLY */
#define	e_incr	e_union.e_plus.eu_incr	/* PLUS */
#define	e_rest	e_union.e_plus.eu_rest	/* PLUS */

#define	e_defun	e_union.eu_defun	/* DEFUN */
#define	e_code	e_union.e_lambda.eu_code	/* LAMBDA */
#define	e_branch e_union.e_lambda.eu_branch	/* LAMBDA */

#define	e_fn	e_union.eu_fn		/* BUILTIN */
#define	e_1math	e_union.eu_1math	/* BU_1MATH */
#define	e_2math	e_union.eu_2math	/* BU_2MATH */

/* expression constructors */
extern	EXPR	*char_expr	ARGS((natural c));
extern	EXPR	*text_expr	ARGS((const unsigned char *text, int n));
extern	EXPR	*num_expr	ARGS((NUM n));
extern	EXPR	*const_expr	ARGS((CONS *data_constant));
extern	EXPR	*cons_expr	ARGS((CONS *data_constructor));
extern	EXPR	*id_pattern	ARGS((STRING name));
extern	EXPR	*id_expr	ARGS((STRING name));
extern	EXPR	*dir_expr	ARGS((PATH where));
extern	EXPR	*pair_expr	ARGS((EXPR *left, EXPR *right));
extern	EXPR	*apply_expr	ARGS((EXPR *func, EXPR *arg));
extern	EXPR	*apply_pat	ARGS((STRING name, EXPR *arg));
extern	EXPR	*func_expr	ARGS((BRANCH *branches));
extern	EXPR	*ite_expr
	ARGS((EXPR *if_expr, EXPR *then_expr, EXPR *else_expr));
extern	EXPR	*let_expr
	ARGS((EXPR *pattern, EXPR *body, EXPR *subexpr, bool recursive));
extern	EXPR	*where_expr
	ARGS((EXPR *subexpr, EXPR *pattern, EXPR *body, bool recursive));
extern	EXPR	*presection	ARGS((STRING operator, EXPR *arg));
extern	EXPR	*postsection	ARGS((STRING operator, EXPR *arg));

extern	EXPR	*builtin_expr	ARGS((FUNCTION *fn));
extern	EXPR	*bu_1math_expr	ARGS((UNARY *fn));
extern	EXPR	*bu_2math_expr	ARGS((BINARY *fn));

struct _BRANCH {
	int	br_nvars;	/* number of variables in the pattern */
	EXPR	*br_pattern;
	EXPR	*br_expr;
	BRANCH	*br_next;	/* next branch in lambda or defined fn */
};

/* pseudo-branch to distinguish built-ins from constants */
#define	BR_BUILTIN	((BRANCH *)1)

/* branch constructors */
extern	BRANCH	*new_branch	ARGS((EXPR *pattern, EXPR *expr));
extern	BRANCH	*cons_branch	ARGS((BRANCH *branch, BRANCH *branchlist));

/* assignment of deBruijn numbers to variables */
extern	bool	nr_branch	ARGS((BRANCH *br));
extern	bool	nr_expr		ARGS((EXPR *expr));

/* the following are checked by nr_branch() and nr_expr() */
#define	MAX_VARIABLES	40	/* max. no. of variables visible */
#define	MAX_SCOPES	20	/* max. no. of nested lambdas */

extern	void	pr_fdecl	ARGS((FILE *f, FUNC *fn));
extern	void	pr_fundef	ARGS((FILE *f, FUNC *fn));
extern	void	pr_expr		ARGS((FILE *f, EXPR *expr));
extern	STRING	expr_name	ARGS((EXPR *expr, int level));

extern	void	pr_c_expr
	ARGS((FILE *f, EXPR *expr, int level, int context));
extern	void	pr_char		ARGS((FILE *f, natural c));
extern	void	pr_actual
	ARGS((FILE *f, int level, PATH path, int context));
extern	void	pr_f_actual
	ARGS((FILE *f, STRING name, int level, PATH path, int context));
extern	STRING	val_name	ARGS((int level, PATH path));

extern	UCASE	*comp_branch	ARGS((UCASE *old_body, BRANCH *branch));
extern	void	comp_expr	ARGS((EXPR *expr));
extern	void	interpret	ARGS((EXPR *action, EXPR *expr));

extern	void	init_print	ARGS((void));
extern	void	open_out_file	ARGS((const char *name));
extern	void	save_out_file	ARGS((void));
extern	void	close_out_file	ARGS((void));

extern	void	reset_streams	ARGS((void));
extern	void	close_streams	ARGS((void));

extern	void	init_builtins	ARGS((void));
extern	void	init_cmps	ARGS((void));

extern	bool	chk_func	ARGS((BRANCH *branch, FUNC *fn));
extern	bool	chk_const	ARGS((EXPR *expr, FUNC *fn));
extern	void	chk_expr	ARGS((EXPR *expr));
extern	void	chk_list	ARGS((EXPR *expr));

extern	EXPR	*e_return, *e_print, *e_wr_list;
extern	EXPR	*e_true, *e_false, *e_cons, *e_nil;

#endif
