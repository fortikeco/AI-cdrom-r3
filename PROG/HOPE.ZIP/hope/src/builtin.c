#include "defs.h"
#include "cell.h"
#include "expr.h"
#include "cases.h"
#include "error.h"

#define	MAX_TMP_STRING	1024

local	void	def_builtin	ARGS((const char *name, FUNCTION *fn));
local	void	def_1math	ARGS((const char *name, UNARY *fn));
local	void	def_2math	ARGS((const char *name, BINARY *fn));
local	bool	check_arity	ARGS((TYPE *type, int n));

local CELL *
ord(arg)
	CELL	*arg;
{
	return new_num((NUM)(arg->c_char));
}

local CELL *
chr(arg)
	CELL	*arg;
{
	if (arg->c_num < Zero || arg->c_num >= (NUM)256) {
		start_err_line();
		(void)fprintf(errout, "  %s(", cur_function);
		(void)fprintf(errout, NUMfmt, arg->c_num);
		(void)fprintf(errout, ")\n");
		error(EXECERR, "value out of range", arg->c_num);
	}
	return new_char((natural)(arg->c_num));
}

local CELL *
num2str(arg)
	CELL	*arg;
{
	unsigned char	strval[MAX_TMP_STRING];

	(void)sprintf((char *)strval, NUMfmt, arg->c_num);
	return c2hope(strval, strlen((char *)strval));
}

local CELL *
str2num(arg)
	CELL	*arg;
{
	char	strval[MAX_TMP_STRING];

	hope2c((unsigned char *)strval, MAX_TMP_STRING, arg);
	return new_num(atoNUM(strval));
}

local CELL *
user_error(arg)
	CELL	*arg;
{
	char	strval[MAX_TMP_STRING];

	hope2c((unsigned char *)strval, MAX_TMP_STRING, arg);
	error(EXECERR, "%s", strval);
	NOT_REACHED(NULL);
}

global CELL *
c2hope(start, n)
reg	const	unsigned char	*start;
	int	n;
{
reg	const	unsigned char	*s;
reg	CELL	*cp;

	cp = new_cnst(nil);
	for (s = start+n-1; s >= start; s--)
		cp = new_cons(cons, new_pair(new_char(*s), cp));
	return cp;
}

/*
 *	Convert a string value to a C string.
 */
global void
hope2c(s, n, arg)
reg	unsigned char	*s;
reg	int	n;
reg	CELL	*arg;
{
	for ( ; n > 0 && arg->c_class == C_CONS; arg = arg->c_arg->c_right) {
		*s++ = arg->c_arg->c_left->c_char;
		n--;
	}
	if (n == 0)
		error(EXECERR, "%s: string too long", cur_function);
	*s = '\0';
}

/*
 *	Arithmetic operators.
 */

local NUM plus(x, y)	NUM x, y;	{ return x + y; }
local NUM minus(x, y)	NUM x, y;	{ return x - y; }
local NUM times(x, y)	NUM x, y;	{ return x * y; }

local NUM
divide(x, y)
	NUM	x, y;
{
	if (y == Zero)
		error(EXECERR, "attempt to divide by zero");
	return x / y;
}

#ifdef REALS
local NUM
int_div(x, y)
	NUM	x, y;
{
	if (y == Zero)
		error(EXECERR, "attempt to divide by zero");
	return floor(x/y);
}

local NUM
mod(x, y)
	NUM	x, y;
{
	return x - int_div(x, y)*y;
}
#else
#define	int_div	divide

local NUM
mod(x, y)
	NUM	x, y;
{
	if (y == Zero)
		error(EXECERR, "attempt to divide by zero");
	return x % y;
}
#endif

global void
init_builtins()
{
	def_builtin("ord",	ord		);
	def_builtin("chr",	chr		);
	def_builtin("read",	open_stream 	);
	def_builtin("num2str",	num2str 	);
	def_builtin("str2num",	str2num 	);
	def_builtin("error",	user_error 	);

	def_builtin("print",	print_value 	);
	def_builtin("write_element",	write_value 	);

	def_2math("+",		plus		);
	def_2math("-",		minus		);
	def_2math("*",		times		);
	def_2math("/",		divide		);
	def_2math("div",	int_div		);
	def_2math("mod",	mod		);

#ifdef REALS
	def_1math("acos",	acos		);
	def_1math("acosh",	acosh		);
	def_1math("asin",	asin		);
	def_1math("asinh",	asinh		);
	def_1math("atan",	atan		);
	def_2math("atan2",	atan2		);
	def_1math("atanh",	atanh		);
	def_1math("ceil",	ceil		);
	def_1math("cos",	cos		);
	def_1math("cosh",	cosh		);
	def_1math("erf",	erf		);
	def_1math("erfc",	erfc		);
	def_1math("exp",	exp		);
	def_1math("abs",	fabs		);
	def_1math("floor",	floor		);
	def_2math("hypot",	hypot		);
	def_1math("log",	log		);
	def_1math("log10",	log10		);
	def_2math("pow",	pow		);
	def_1math("sin",	sin		);
	def_1math("sinh",	sinh		);
	def_1math("sqrt",	sqrt		);
	def_1math("tanh",	tanh		);
#endif
}

local void
def_builtin(name, fn)
	const	char	*name;
	FUNCTION *fn;
{
	FUNC	*bu;

	bu = fn_lookup(newstring(name));
	if (bu == NULL)
		error(FATALERR, "undeclared built-in '%s'", name);
	bu->f_code = strict(builtin_expr(fn));
	bu->f_branch = BR_BUILTIN;
}

local void
def_1math(name, fn)
	const	char	*name;
	UNARY	*fn;
{
	FUNC	*bu;

	bu = fn_lookup(newstring(name));
	if (bu == NULL)
		error(FATALERR, "undeclared built-in '%s'", name);
	if (! check_arity(bu->f_type, 1))
		error(FATALERR, "built-in '%s' has wrong type", name);
	bu->f_code = strict(bu_1math_expr(fn));
	bu->f_branch = BR_BUILTIN;
}

local void
def_2math(name, fn)
	const	char	*name;
	BINARY	*fn;
{
	FUNC	*bu;

	bu = fn_lookup(newstring(name));
	if (bu == NULL)
		error(FATALERR, "undeclared built-in '%s'", name);
	if (! check_arity(bu->f_type, 2))
		error(FATALERR, "built-in '%s' has wrong type", name);
	bu->f_code = strict(bu_2math_expr(fn));
	bu->f_branch = BR_BUILTIN;
}

local bool
check_arity(type, n)
reg	TYPE	*type;
	int	n;
{
	if (type->ty_variable ||
	    type->ty_deftype != function ||
	    type->ty_secondarg->ty_deftype != num)
		return FALSE;
	for (type = type->ty_firstarg; n-- > 1; type = type->ty_secondarg)
		if (type->ty_variable ||
		    type->ty_deftype != product ||
		    type->ty_firstarg->ty_deftype != num)
			return FALSE;
	return ! type->ty_variable && type->ty_deftype == num;
}
