#include "defs.h"
#include "module.h"
#include "expr.h"
#include "typevar.h"
#include "op.h"
#include "newstring.h"
#include "set.h"
#include "table.h"
#include "error.h"
#include "memory.h"
#include "source.h"
#include "hopelib.h"

#define	MAX_MODULES	32	/* max. no. of modules (checked) */
#define	MAX_TVARS	32	/* max. no. of type variables (checked) */
#define	MAX_MODNAME	100	/* max. len. of module path (checked) */

local	const	char	extension[] = ".hop";

typedef	struct _MODULE	MODULE;
struct _MODULE {
	STRING	mod_name;
	unsigned short	mod_num;	/* index in module table */
	sbool	mod_system;	/* system module? */
	SET(mod_uses, MAX_MODULES);
	SET(mod_all_uses, MAX_MODULES);	/* transitive closure of uses */
	SET(mod_tvars, MAX_TVARS);
	SET(mod_all_tvars, MAX_TVARS);	/* includes tvars in used modules */
	TABLE	mod_ops;
	TABLE	mod_types;
	TABLE	mod_fns;
	MODULE	*mod_public;	/* public part of a private module */
};

global	TVAR	alpha;

local	const	char	Session_name[] = "<Session>";
local	const	char	Standard_name[] = "Standard";

/* special modules */
#define SESSION 0	/* the terminal interaction */
#define	STANDARD 1	/* standard environment */
#define	ORDINARY 2	/* first ordinary module */
/*
 *	List of all modules ever encountered.
 */
local	MODULE	*mod_list[MAX_MODULES];
local	natural	mod_count;
local	SET(mod_unread, MAX_MODULES);	/* modules yet to be read */
/*
 *	Stack of modules being read to satisfy `uses' commands.
 *	The top module is the one currently being read; the bottom one is
 *	the current session.
 */
local	MODULE	*mod_stack[MAX_MODULES];
local	MODULE	**mod_current;

local	FILE	*disp_file;

local	TVAR	tvar_list[MAX_TVARS];
local	natural	tvar_count;

typedef	void_p	LOOK_FN		ARGS((STRING name, MODULE *mod));

local	MODULE	*mod_new	ARGS((STRING name));
local	void	mod_clear	ARGS((MODULE *mod));
local	void	mod_copy	ARGS((MODULE *mod1, MODULE *mod2));
local	MODULE	*module		ARGS((STRING name));
local	void	mark_as_private	ARGS((TAB_ELT *p));
local	void	reset_private	ARGS((TAB_ELT *p));
local	void	us_display	ARGS((MODULE *mod));
local	bool	mod_read	ARGS((MODULE *mod));
local	FILE	*mod_create	ARGS((STRING name));

local	void_p	look_here	ARGS((STRING name, LOOK_FN *look_fn));
local	void_p	look_everywhere	ARGS((STRING name, LOOK_FN *look_fn));

local	void_p	op_mod_lookup	ARGS((STRING name, MODULE *mod));
local	void	op_display	ARGS((TAB_ELT *p));

local	void	tv_display	ARGS((MODULE *mod));

local	void_p	dt_mod_lookup	ARGS((STRING name, MODULE *mod));
local	void_p	cons_mod_lookup	ARGS((STRING name, MODULE *mod));
local	void	ty_cons_lookup	ARGS((TAB_ELT *p));
local	void	ty_display	ARGS((TAB_ELT *p));
local	void	ty_abs_display	ARGS((TAB_ELT *p));
local	void	ty_def_display	ARGS((TAB_ELT *p));

local	void_p	fn_mod_lookup	ARGS((STRING name, MODULE *mod));
local	void	fn_display	ARGS((TAB_ELT *p));
local	void	dec_display	ARGS((TAB_ELT *p));
local	void	def_display	ARGS((TAB_ELT *p));

/*
 *	Set up the special modules
 */
global void
mod_init()
{
	tvar_count = 0;
	mod_count = 0;
	CLEAR(mod_unread);
	mod_current = mod_stack;
	*mod_current = mod_new(newstring(Session_name));
	mod_use(newstring(Standard_name));
	mod_fetch();
}

global STRING
mod_name()
{
	return (*mod_current)->mod_name;
}

global bool
mod_system()
{
	return (*mod_current)->mod_system;
}

local MODULE *
mod_new(name)
	STRING	name;
{
reg	MODULE	*mod;

	if (mod_count == MAX_MODULES) {
		error(SEMERR, "too many modules");
		return NULL;
	}
	mod = NEW(MODULE);
	mod->mod_name = name;
	mod->mod_num = mod_count;
	mod->mod_system = mod->mod_num == STANDARD;
	mod_clear(mod);
	mod_list[mod_count++] = mod;
	return mod;
}

local void
mod_clear(mod)
reg	MODULE	*mod;
{
	CLEAR(mod->mod_uses);
	CLEAR(mod->mod_all_uses);
	CLEAR(mod->mod_tvars);
	CLEAR(mod->mod_all_tvars);
	t_init(&(mod->mod_ops));
	t_init(&(mod->mod_types));
	t_init(&(mod->mod_fns));
	mod->mod_public = NULL;
}

local void
mod_copy(mod1, mod2)
reg	MODULE	*mod1, *mod2;
{
	UNION(mod1->mod_uses, mod2->mod_uses);
	UNION(mod1->mod_all_uses, mod2->mod_all_uses);
	UNION(mod1->mod_tvars, mod2->mod_tvars);
	UNION(mod1->mod_all_tvars, mod2->mod_all_tvars);
	t_copy(&(mod1->mod_ops), &(mod2->mod_ops));
	t_copy(&(mod1->mod_types), &(mod2->mod_types));
	t_copy(&(mod1->mod_fns), &(mod2->mod_fns));
	mod1->mod_public = mod2->mod_public;
}

local MODULE *
module(name)
	STRING	name;
{
reg	MODULE	*mod;
reg	natural	i;

	for (i = STANDARD; i < mod_count; i++)
		if (mod_list[i]->mod_name == name)
			return mod_list[i];	/* already here */
	/* not here -- make a note to read it */
	mod = mod_new(name);
	if (mod != NULL)
		ADD(mod_unread, mod->mod_num);
	return mod;
}

global void
mod_use(name)
	STRING	name;
{
reg	MODULE	**mp;
reg	MODULE	*mod;

	mod = module(name);
	if (mod == NULL)
		return;
	for (mp = mod_stack; mp <= mod_current; mp++)
		if (*mp == mod || (*mp)->mod_public == mod) {
			error(SEMERR, "cyclic 'uses' reference: %s",
				mod->mod_name);
			return;
		}
	ADD((*mod_current)->mod_uses, mod->mod_num);
	ADD((*mod_current)->mod_all_uses, mod->mod_num);
	UNION((*mod_current)->mod_all_uses, mod->mod_all_uses);
	UNION((*mod_current)->mod_all_tvars, mod->mod_all_tvars);
}

/*
 *	Read in any queued modules
 */
global void
mod_fetch()
{
reg	natural	i;

	/* unprocessed uses */
	for (i = STANDARD; i < mod_count; i++)
		if (MEMBER(mod_unread, i) &&
		    MEMBER((*mod_current)->mod_uses, i)) {
			REMOVE(mod_unread, i);
			if (mod_read(mod_list[i])) {
				/* go read this one */
				*++mod_current = mod_list[i];
				if (i != STANDARD)
					mod_use(newstring(Standard_name));
				return;
			}
			else {
				error(i == STANDARD ? FATALERR : SEMERR,
					"can't read module '%s'",
					mod_list[i]->mod_name);
				REMOVE((*mod_current)->mod_uses, i);
			}
		}
}

local void
mark_as_private(p)
	TAB_ELT	*p;
{
reg	DEFTYPE	*dt;

	dt = (DEFTYPE *)p;
	dt->dt_private = ! dt->dt_synonym && (dt->dt_cons == NULL);
}

/*
 *	Rest of module is to be hidden from other modules.
 */
global void
private()
{
reg	MODULE	*mod_private;

	if ((*mod_current)->mod_num == SESSION)	/* at top level -- no effect */
		return;
	/*
	 * Start a new module (which will be discarded) for any new
	 * definitions.
	 */
	mod_private = mod_new((*mod_current)->mod_name);
	if (mod_private == NULL)
		return;
	mod_private->mod_system = (*mod_current)->mod_system;
	UNION(mod_private->mod_uses, (*mod_current)->mod_uses);
	UNION(mod_private->mod_all_uses, (*mod_current)->mod_all_uses);
	UNION(mod_private->mod_tvars, (*mod_current)->mod_tvars);
	UNION(mod_private->mod_all_tvars, (*mod_current)->mod_all_tvars);
	mod_private->mod_public = *mod_current;
	/*
	 * Mark all abstype's in the current module so they can be reset
	 * at the end of the module.
	 */
	t_foreach(&((*mod_current)->mod_types), mark_as_private);

	*mod_current = mod_private;
	preserve();
}

local void
reset_private(p)
	TAB_ELT	*p;
{
reg	DEFTYPE	*dt;

	dt = (DEFTYPE *)p;
	if (dt->dt_private) {
		dt->dt_synonym = FALSE;
		dt->dt_cons = NULL;
	}
}

/* end of use */
global void
mod_finish()
{
reg	MODULE	*current;
reg	MODULE	**mp;

	current = *mod_current;
	if (current->mod_num == STANDARD ||
	    current->mod_public != NULL &&
	    current->mod_public->mod_num == STANDARD) {
		alpha = tv_var((natural)0);
		init_cmps();
		init_builtins();
		init_print();
		preserve();
	}
	if (current->mod_public != NULL) {
		current = current->mod_public;
		/*
		 * Reset any abstype's that have been privately defined
		 */
		t_foreach(&(current->mod_types), reset_private);
	}
	for (mp = mod_stack; mp < mod_current; mp++)
		if (MEMBER((*mp)->mod_uses, current->mod_num)) {
			UNION((*mp)->mod_all_uses, current->mod_all_uses);
			UNION((*mp)->mod_all_tvars, current->mod_all_tvars);
		}
	mod_current--;
	mod_fetch();
}

global void
mod_save(name)
	STRING	name;
{
	FILE	*f;
	MODULE	*mod;

	if ((*mod_current)->mod_num != SESSION) {
		error(SEMERR, "'save' not permitted in module");
		return;
	}
	f = mod_create(name);
	if (f == NULL)
		return;
	mod_dump(f);

	/* move the contents of the current session into the module */
	mod = mod_new(name);
	if (mod == NULL)
		return;
	mod_copy(mod, *mod_current);
	mod_clear(*mod_current);
	mod_use(newstring(Standard_name));
	mod_use(name);

	preserve();
}

global void
mod_dump(f)
	FILE	*f;
{
	if (f != NULL) {
		disp_file = f;
		us_display(mod_list[SESSION]);
		tv_display(mod_list[SESSION]);
		t_foreach(&(mod_list[SESSION]->mod_ops), op_display);
		t_foreach(&(mod_list[SESSION]->mod_types), ty_abs_display);
		t_foreach(&(mod_list[SESSION]->mod_types), ty_def_display);
		t_foreach(&(mod_list[SESSION]->mod_fns), dec_display);
		t_foreach(&(mod_list[SESSION]->mod_fns), def_display);
		(void)fclose(disp_file);
	}
}

global void
mod_file(buf, name)
	char	*buf;
	STRING	name;
{
	(void)sprintf(buf, "%s%s", name, extension);
}

local void
us_display(mod)
	MODULE	*mod;
{
reg	natural	i;
	bool	first;

	if (CARD(mod->mod_uses) > 1) {	/* any uses apart from STANDARD? */
		(void)fprintf(disp_file, "uses ");
		first = TRUE;
		for (i = ORDINARY; i < mod_count; i++)
			if (MEMBER(mod->mod_uses, i)) {
				(void)fprintf(disp_file, first ? "%s" : ", %s",
					mod_list[i]->mod_name);
				first = FALSE;
			}
		(void)fprintf(disp_file, ";\n");
	}
}

/*
 *	Open a module for reading.
 *	The module is sought first in the current directory, then in the
 *	directory HOPELIB (if defined), unless we are in a system module,
 *	in which case only HOPELIB (if any) is searched.
 */
local bool
mod_read(mod)
	MODULE	*mod;
{
	FILE	*f;
	char	filename[MAX_MODNAME];

	mod_file(filename, mod->mod_name);
	f = mod_system() ? NULL : fopen(filename, "r");
#ifdef HOPELIB
	if (f == NULL && sizeof(HOPELIB) + strlen(filename) <= MAX_MODNAME) {
#ifdef AMIGA
		(void)sprintf(filename, "%s:", HOPELIB);
#else
		(void)sprintf(filename, "%s/", HOPELIB);
#endif
		mod_file(filename + strlen(filename), mod->mod_name);
		f = fopen(filename, "r");
		mod->mod_system = TRUE;
	}
#endif
	if (f == NULL)
		return FALSE;
	enterfile(f);
	return TRUE;
}

/*
 *	Create a new module in the current directory.
 */
local FILE *
mod_create(name)
	STRING	name;
{
	FILE	*f;
	char	filename[MAX_MODNAME];

	mod_file(filename, name);
	if ((f = fopen(filename, "r")) != NULL) {
		(void)fclose(f);
		error(SEMERR, "a module called '%s' already exists", name);
		return NULL;
	}
	if ((f = fopen(filename, "w")) == NULL)
		error(SEMERR, "can't save module '%s'", name);
	return f;
}

/*
 *	Look for a name in the current module
 */
local void_p
look_here(name, look_fn)
	STRING	name;
	void_p	(*look_fn)();
{
reg	void_p	found;

	if ((found = (*look_fn)(name, *mod_current)) != NULL)
		return found;
	if ((*mod_current)->mod_public != NULL)
		return (*look_fn)(name, (*mod_current)->mod_public);
	return NULL;
}

/*
 *	Look for a name in the current module and all those it uses
 */
local void_p
look_everywhere(name, look_fn)
	STRING	name;
	void_p	(*look_fn)();
{
reg	void_p	found;
reg	natural	i;

	if ((found = look_here(name, look_fn)) != NULL)
		return found;
	for (i = STANDARD; i < mod_count; i++)
		if (MEMBER((*mod_current)->mod_all_uses, i) &&
		    (found = (*look_fn)(name, mod_list[i])) != NULL)
			return found;
	return NULL;
}

/*
 *	Operators
 */

global void
op_declare(name, prec, assoc)
	STRING	name;
	int	prec;
	ASSOC	assoc;
{
reg	OP	*op;

	op = NEW(OP);
	op->op_name = name;
	op->op_prec = prec < MINPREC ? MINPREC :
		      prec > MAXPREC ? MAXPREC : prec;
	op->op_assoc = assoc;
	t_insert(&((*mod_current)->mod_ops), (TAB_ELT *)op);
}

local void_p
op_mod_lookup(name, mod)
	STRING	name;
	MODULE	*mod;
{
	return (void_p)t_lookup(&(mod->mod_ops), name);
}

global OP *
op_lookup(name)
	STRING	name;
{
	return (OP *)look_everywhere(name, op_mod_lookup);
}

local void
op_display(p)
	TAB_ELT	*p;
{
reg	OP	*op;

	op = (OP *)p;
	(void)fprintf(disp_file, "%s %s : %d;\n",
		op->op_assoc == ASSOC_LEFT ? "infix" : "infixr",
		op->op_name, op->op_prec);
}

/*
 *	Type Variables.
 */

global void
tv_declare(name)
	STRING	name;
{
reg	natural	n;

	for (n = 0; n < tvar_count && tvar_list[n] != name; n++)
		;
	if (n == tvar_count) {		/* add it */
		if (tvar_count == MAX_TVARS) {
			error(SEMERR, "too many type variables");
			return;
		}
		tvar_list[tvar_count++] = name;
	}
	ADD((*mod_current)->mod_tvars, n);
	ADD((*mod_current)->mod_all_tvars, n);
}

global bool
tv_lookup(name)
	STRING	name;
{
reg	natural	n;

	for (n = 0; n < tvar_count; n++)
		if (tvar_list[n] == name &&
		    MEMBER((*mod_current)->mod_all_tvars, n))
			return TRUE;
	return FALSE;
}

/*
 *	The number of type variables visible in the current module.
 */
global natural
tv_count()
{
	return CARD((*mod_current)->mod_all_tvars);
}

/*
 *	The n'th type variable visible in the current module.
 *	There must be at least 2 (alpha and beta);
 *	if n is too large, wrap around.
 */
global TVAR
tv_var(n)
reg	natural	n;
{
reg	natural	tvn;
reg	SETPTR	known;

	ASSERT( tvar_count > 0 );
	ASSERT( set_card((*mod_current)->mod_all_tvars) > 0 );
	known = (*mod_current)->mod_all_tvars;
	tvn = tvar_count-1;
	do {
		do {
			tvn = (tvn+1)%tvar_count;
		} while (! MEMBER(known, tvn));
	} while (n-- > 0);
	return tvar_list[tvn];
}

local void
tv_display(mod)
	MODULE	*mod;
{
reg	natural	n;
	bool	first;

	if (CARD(mod->mod_tvars) > 0) {
		(void)fprintf(disp_file, "typevar ");
		first = TRUE;
		for (n = 0; n < tvar_count; n++)
			if (MEMBER(mod->mod_tvars, n)) {
				(void)fprintf(disp_file, first ? "%s" : ", %s",
					tvar_list[n]);
				first = FALSE;
			}
		(void)fprintf(disp_file, ";\n");
	}
}

/*
 *	Defined types and constructors.
 */

global	EXPR	*e_true, *e_false, *e_cons, *e_nil;

global void
dt_declare(dt)
reg	DEFTYPE	*dt;
{
	t_insert(&((*mod_current)->mod_types), (TAB_ELT *)dt);
	if ((*mod_current)->mod_num == STANDARD)
		if (dt->dt_name == newstring("->"))
			function = dt;
		else if (dt->dt_name == newstring("#"))
			product = dt;
		else if (dt->dt_name == newstring("truval")) {
			truval = dt;
			false = dt->dt_cons;
			e_false = const_expr(false);
			true = false->c_next;
			e_true = const_expr(true);
		}
		else if (dt->dt_name == newstring("num")) {
			num = dt;
			succ = dt->dt_cons;
		}
		else if (dt->dt_name == newstring("list")) {
			list = dt;
			nil = dt->dt_cons;
			e_nil = const_expr(nil);
			cons = nil->c_next;
			e_cons = cons_expr(cons);
		}
		else if (dt->dt_name == newstring("char"))
			character = dt;
}

local void_p
dt_mod_lookup(name, mod)
	STRING	name;
	MODULE	*mod;
{
	return (void_p)t_lookup(&(mod->mod_types), name);
}

global DEFTYPE *
dt_lookup(name)
reg	STRING	name;
{
	return (DEFTYPE *)look_everywhere(name, dt_mod_lookup);
}

global DEFTYPE *
dt_local(name)
	STRING	name;
{
	return (DEFTYPE *)look_here(name, dt_mod_lookup);
}

local	CONS	*cons_found;
local	STRING	cons_name;

local void
ty_cons_lookup(p)
	TAB_ELT	*p;
{
reg	DEFTYPE	*dt;
reg	CONS	*cp;

	dt = (DEFTYPE *)p;
	if (! dt->dt_synonym)
		for (cp = dt->dt_cons; cp != NULL; cp = cp->c_next)
			if (cp->c_name == cons_name)
				cons_found = cp;
}

local void_p
cons_mod_lookup(name, mod)
	STRING	name;
	MODULE	*mod;
{
	cons_name = name;
	cons_found = NULL;
	t_foreach(&(mod->mod_types), ty_cons_lookup);
	return (void_p)cons_found;
}

global CONS *
cons_lookup(name)
reg	STRING	name;
{
	return (CONS *)look_everywhere(name, cons_mod_lookup);
}

local void
ty_display(p)
	TAB_ELT	*p;
{
	pr_deftype(disp_file, (DEFTYPE *)p, TRUE);
}

local void
ty_abs_display(p)
	TAB_ELT	*p;
{
	pr_deftype(disp_file, (DEFTYPE *)p, FALSE);
}

local void
ty_def_display(p)
	TAB_ELT	*p;
{
reg	DEFTYPE	*dt;

	dt = (DEFTYPE *)p;
	if (dt->dt_synonym || dt->dt_cons != NULL)
		pr_deftype(disp_file, dt, TRUE);
}

/*
 *	Functions.
 */

global void
new_fn(name, type)
	STRING	name;
	TYPE	*type;
{
reg	FUNC	*fn;

	fn = NEW(FUNC);
	fn->f_name = name;
	fn->f_type = type;
	fn->f_branch = NULL;
	fn->f_code = NULL;
	t_insert(&((*mod_current)->mod_fns), (TAB_ELT *)fn);
}

local void_p
fn_mod_lookup(name, mod)
	STRING	name;
	MODULE	*mod;
{
	return (void_p)t_lookup(&(mod->mod_fns), name);
}

global FUNC *
fn_lookup(name)
	STRING	name;
{
	return (FUNC *)look_everywhere(name, fn_mod_lookup);
}

global FUNC *
fn_local(name)
	STRING	name;
{
	return (FUNC *)look_here(name, fn_mod_lookup);
}

local void
fn_display(p)
	TAB_ELT	*p;
{
	(void)fprintf(disp_file, "\n");
	dec_display(p);
	pr_fundef(disp_file, (FUNC *)p);
}

local void
dec_display(p)
	TAB_ELT	*p;
{
	pr_fdecl(disp_file, (FUNC *)p);
}

local void
def_display(p)
	TAB_ELT	*p;
{
reg	FUNC	*fn;

	fn = (FUNC *)p;
	if (fn->f_branch != NULL || fn->f_value != NULL) {
		(void)fprintf(disp_file, "\n");
		pr_fundef(disp_file, fn);
	}
}

/*
 *	List out all tables.
 */
global void
display()
{
	if ((*mod_current)->mod_num != SESSION) {
		error(SEMERR, "'display' not permitted in module");
		return;
	}
	disp_file = stdout;
	us_display(mod_list[SESSION]);
	tv_display(mod_list[SESSION]);
	t_foreach(&(mod_list[SESSION]->mod_ops), op_display);
	t_foreach(&(mod_list[SESSION]->mod_types), ty_display);
	t_foreach(&(mod_list[SESSION]->mod_fns), fn_display);
}
