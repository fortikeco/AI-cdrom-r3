/*
 *	Printing of inferred types.
 */

#include "defs.h"
#include "typevar.h"
#include "deftype.h"
#include "cell.h"
#include "op.h"
#include "print.h"

#define	MAX_VARS_IN_TYPE	40	/* (not checked) */

local	void	show_type	ARGS((FILE *f, CELL *type, int context));
local	void	show_var	ARGS((FILE *f, CELL *var));
local	int	n_ty_precedence	ARGS((CELL *type));

/* table of known type variables */
local	CELL	*known_tvar[MAX_VARS_IN_TYPE];
local	CELL	**last_known_tvar;

global void
init_pr_ty_value()
{
	last_known_tvar = known_tvar;
}

global void
pr_ty_value(f, type)
	FILE	*f;
	CELL	*type;
{
	show_type(f, type, PREC_BODY);
}

/*
 *	Print a type.
 */
local void
show_type(f, type, context)
	FILE	*f;
reg	CELL	*type;
	int	context;
{
	OP	*op;
	int	prec;

	type = deref(type);
	prec = n_ty_precedence(type);
	if (prec < context)
		(void)fprintf(f, "(");
	if (type->c_class == C_TVAR)
		show_var(f, type);
	else if (type->c_targ == NOCELL)		/* nullary */
		(void)fprintf(f, "%s", type->c_tcons->dt_name);
	else if (type->c_targ->c_class != C_PAIR) {	/* unary */
		(void)fprintf(f, "%s ", type->c_tcons->dt_name);
		show_type(f, type->c_targ, PREC_ARG);
	}
	else if ((op = op_lookup(type->c_tcons->dt_name)) != NULL) {
							/* infix */
		show_type(f, type->c_targ->c_left, LeftPrec(op));
		(void)fprintf(f, " %s ", type->c_tcons->dt_name);
		show_type(f, type->c_targ->c_right, RightPrec(op));
	}
	else {
		(void)fprintf(f, "%s (", type->c_tcons->dt_name);
		for (type = type->c_targ;
		     type->c_class == C_PAIR;
		     type = type->c_right) {
			show_type(f, type->c_left, PREC_BODY);
			(void)fprintf(f, ", ");
		}
		show_type(f, type, PREC_BODY);
		(void)fprintf(f, ")");
	}
	if (prec < context)
		(void)fprintf(f, ")");
}

/*
 *	Print first uninstantiated type variable encountered as alpha,
 *	next as beta, and so on, then alpha', beta', etc.
 */
local void
show_var(f, var)
	FILE	*f;
reg	CELL	*var;
{
reg	CELL	**tvp;
reg	int	n;

	/*
	 * Set n to var's index in the known-variable table,
	 * inserting var if it's new.
	 */
	*last_known_tvar = var;	/* also serves as a sentinel */
	for (tvp = known_tvar; *tvp != var; tvp++)
		;
	if (tvp == last_known_tvar)
		last_known_tvar++;
	n = tvp - known_tvar;
	/* print n as a suitably primed type variable name */
	(void)fprintf(f, "%s", tv_var(n%tv_count()));
	for (n = n/tv_count(); n > 0; n--)
		(void)fprintf(f, "'");
}

local int
n_ty_precedence(type)
reg	CELL	*type;
{
	OP	*op;

	if (type->c_class == C_TVAR || type->c_targ == NOCELL)
		return PREC_ATOMIC;
	if (type->c_targ->c_class == C_PAIR &&
	    (op = op_lookup(type->c_tcons->dt_name)) != NULL)
		return op->op_prec;
	return PREC_APPLY;
}
