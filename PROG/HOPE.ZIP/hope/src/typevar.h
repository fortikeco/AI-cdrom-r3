#ifndef TYPEVAR_H
#define TYPEVAR_H

#include "newstring.h"
/*
 *	Type variables.
 */
typedef	STRING	TVAR;

extern	void	tv_declare	ARGS((STRING name));
extern	bool	tv_lookup	ARGS((STRING name));
extern	natural	tv_count	ARGS((void));
extern	TVAR	tv_var		ARGS((natural varno));

#endif
