#include "defs.h"
#include "set.h"

global void
set_clear(set, n)
reg	SETPTR	set;
reg	natural	n;
{
	while (n-- > 0)
		*set++ = 0;
}

global natural
set_card(set, n)
reg	SETPTR	set;
reg	natural	n;
{
reg	natural	count;
reg	natural	bits;

	count = 0;
	while (n-- > 0)
		for (bits = *set++; bits != 0; bits >>= 1)
			if ((bits & 01) != 0)
				count++;
	return count;
}

global void
set_union(set1, n1, set2, n2)
reg	SETPTR	set1;
reg	natural	n1;
reg	SETPTR	set2;
	natural	n2;
{
	if (n2 < n1)
		n1 = n2;
	while (n1-- > 0)
		*set1++ |= *set2++;
}
