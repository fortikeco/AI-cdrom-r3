#include "defs.h"
#include "path.h"
#include "memory.h"

#define	MAX_PATH	40	/* max. length of a path (not checked) */
#define	MAX_PATHBUF	400	/* max. total of paths in patt (not checked) */

/*
 *	Create a new, empty path.
 *	Returned value points to a static area that will be overwritten
 *	by the next call.
 */
global PATH
p_new()
{
static	char	path_buf[MAX_PATH];

	path_buf[MAX_PATH-1] = P_END;
	return &path_buf[MAX_PATH-1];
}

global PATH
p_push(dir, p)
	int	dir;
reg	PATH	p;
{
	*--p = dir;
	return p;
}

/* permanent storage for a path */
global PATH
p_stash(p)
	PATH	p;
{
	return strcpy(NEWARRAY(char, strlen(p) + 1), p);
}

/* temporary storage for a number of paths */
local	char	*p_buffer;
local	char	*pb_end;
local	int	pb_size;	/* not checked at present */

global void
p_init(buf, size)
	char	*buf;
	int	size;
{
	pb_end = p_buffer = buf;
	pb_size = size;
}

global PATH
p_save(p)
	PATH	p;
{
	char	*new;

	new = strcpy(pb_end, p);
	pb_end += strlen(p)+1;
	return new;
}

/*
 *	Reverse a path, adding an UNROLL before each direction in the initial
 *	string of LEFTs and RIGHTs.
 *	Returned value points to a static area that will be overwritten
 *	by the next call.
 */
global PATH
p_reverse(old)
reg	PATH	old;
{
static	char	path_buf[MAX_PATH];
reg	PATH	new;
reg	int	dir;

	path_buf[MAX_PATH-1] = P_END;
	new = &path_buf[MAX_PATH-1];

	repeat {
	until(p_empty(old));
		dir = p_top(old);
		new = p_push(dir, new);
		old = p_pop(old);
	until(dir != P_LEFT && dir != P_RIGHT);
		new = p_push(P_UNROLL, new);
	}
	while (! p_empty(old)) {
		new = p_push(p_top(old), new);
		old = p_pop(old);
	}
	return new;
}
