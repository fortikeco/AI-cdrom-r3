#include "defs.h"
#include "expr.h"
#include "op.h"
#include "print.h"

local	void	pr_f_expr
	ARGS((FILE *f, STRING name, EXPR *arg, int level, int context));
local	bool	is_list		ARGS((EXPR *expr));
local	void	pr_elist	ARGS((FILE *f, EXPR *expr, int level));
local	bool	is_string	ARGS((EXPR *expr));
local	void	pr_string	ARGS((FILE *f, EXPR *expr));
local	void	pr_lambda	ARGS((FILE *f, BRANCH *branch, int level));
local	void	pr_presection	ARGS((FILE *f, EXPR *expr, int level));
local	void	pr_postsection	ARGS((FILE *f, EXPR *expr, int level));
local	int	precedence	ARGS((EXPR *expr));

local	bool	in_definition;		/* initially FALSE */

/*
 *	Printing of functions.
 */

global void
pr_fdecl(f, fn)
	FILE	*f;
	FUNC	*fn;
{
	(void)fprintf(f, "dec %s : ", fn->f_name);
	pr_type(f, fn->f_type);
	(void)fprintf(f, ";\n");
}

global void
pr_fundef(f, fn)
	FILE	*f;
	FUNC	*fn;
{
reg	BRANCH	*br;

	in_definition = TRUE;
	if (fn->f_branch != NULL)
		for (br = fn->f_branch; br != NULL; br = br->br_next) {
			(void)fprintf(f, "--- ");
			pr_f_expr(f, fn->f_name, br->br_pattern, 0, PREC_BODY);
			(void)fprintf(f, " <= ");
			pr_c_expr(f, br->br_expr, 1, PREC_BODY);
			(void)fprintf(f, ";\n");
		}
	else if (fn->f_value != NULL) {
		(void)fprintf(f, "--- %s <= ", fn->f_name);
		pr_c_expr(f, fn->f_value, 0, PREC_BODY);
		(void)fprintf(f, ";\n");
	}
	in_definition = FALSE;
}

local void
pr_f_expr(f, name, arg, level, context)
	FILE	*f;
	STRING	name;
	EXPR	*arg;
	int	level;
	int	context;
{
	OP	*op;

	if (arg->e_class == E_PARAM)
		if (arg->e_level < level)
			pr_f_expr(f, name, arg->e_patt, 0, context);
		else
			pr_f_actual(f, name,
				arg->e_level - level, arg->e_where, context);
	else if ((op = op_lookup(name)) != NULL)
		if (arg->e_class == E_PAIR) {
			if (op->op_prec < context)
				(void)fprintf(f, "(");
			pr_c_expr(f, arg->e_left, level, LeftPrec(op));
			(void)fprintf(f, " %s ", name);
			pr_c_expr(f, arg->e_right, level, RightPrec(op));
			if (op->op_prec < context)
				(void)fprintf(f, ")");
		}
		else {
			(void)fprintf(f, "(%s) ", name);
			pr_c_expr(f, arg, level, PREC_ARG);
		}
	else {
		(void)fprintf(f, "%s ", name);
		pr_c_expr(f, arg, level, PREC_ARG);
	}
}

global void
pr_expr(f, expr)
	FILE	*f;
	EXPR	*expr;
{
	pr_c_expr(f, expr, MAX_SCOPES, PREC_BODY);
}

global void
pr_c_expr(f, expr, level, context)
	FILE	*f;
	EXPR	*expr;
	int	level, context;
{
reg	int	prec;
	STRING	name;

	prec = precedence(expr);
	if (prec < context)
		(void)fprintf(f, "(");
	switch (expr->e_class) {
	when E_PAIR:
		pr_c_expr(f, expr->e_left, level, PREC_COMMA+1);
		(void)fprintf(f, ", ");
		pr_c_expr(f, expr->e_right, level, PREC_COMMA);
	when E_APPLY:
		if (is_list(expr))
			if (is_string(expr))
				pr_string(f, expr);
			else
				pr_elist(f, expr, level);
		else {
			name = expr_name(expr->e_func, level);
			if (name != NULL)
				pr_f_expr(f, name, expr->e_arg,
					level, InnerPrec(prec, context));
			else {
				pr_c_expr(f, expr->e_func, level, PREC_APPLY);
				(void)fprintf(f, " ");
				pr_c_expr(f, expr->e_arg, level, PREC_ARG);
			}
		}
	when E_IF:
		(void)fprintf(f, "if ");
		pr_c_expr(f, expr->e_arg, level, PREC_BODY);
		(void)fprintf(f, " then ");
		pr_c_expr(f, expr->e_func->e_branch->br_expr,
			level+1, PREC_BODY);
		(void)fprintf(f, " else ");
		pr_c_expr(f, expr->e_func->e_branch->br_next->br_expr,
			level+1, PREC_IF);
	when E_LET:
		(void)fprintf(f, "let ");
		pr_c_expr(f, expr->e_func->e_branch->br_pattern,
			level+1, PREC_BODY);
		(void)fprintf(f, " == ");
		pr_c_expr(f, expr->e_arg, level, PREC_BODY);
		(void)fprintf(f, " in ");
		pr_c_expr(f, expr->e_func->e_branch->br_expr,
			level+1, PREC_LET);
	when E_RLET:
		(void)fprintf(f, "letrec ");
		pr_c_expr(f, expr->e_func->e_branch->br_pattern,
			level+1, PREC_BODY);
		(void)fprintf(f, " == ");
		pr_c_expr(f, expr->e_arg, level+1, PREC_BODY);
		(void)fprintf(f, " in ");
		pr_c_expr(f, expr->e_func->e_branch->br_expr,
			level+1, PREC_LET);
	when E_WHERE:
		pr_c_expr(f, expr->e_func->e_branch->br_expr,
			level+1, PREC_WHERE);
		(void)fprintf(f, " where ");
		pr_c_expr(f, expr->e_func->e_branch->br_pattern,
			level+1, PREC_BODY);
		(void)fprintf(f, " == ");
		pr_c_expr(f, expr->e_arg, level, PREC_WHERE);
	when E_RWHERE:
		pr_c_expr(f, expr->e_func->e_branch->br_expr,
			level+1, PREC_WHERE);
		(void)fprintf(f, " whererec ");
		pr_c_expr(f, expr->e_func->e_branch->br_pattern,
			level+1, PREC_BODY);
		(void)fprintf(f, " == ");
		pr_c_expr(f, expr->e_arg, level+1, PREC_WHERE);
	when E_LAMBDA:
		pr_lambda(f, expr->e_branch, level);
	when E_PRESECT:
		if (in_definition)
			pr_presection(f, expr->e_branch->br_expr, level+1);
		else
			pr_lambda(f, expr->e_branch, level);
	when E_POSTSECT:
		if (in_definition)
			pr_postsection(f, expr->e_branch->br_expr, level+1);
		else
			pr_lambda(f, expr->e_branch, level);
	when E_NUM:
		(void)fprintf(f, NUMfmt, expr->e_num);
	when E_CHAR:
		(void)fprintf(f, "'");
		pr_char(f, expr->e_char);
		(void)fprintf(f, "'");
	when E_DEFUN:
		(void)fprintf(f, "%s", expr->e_defun->f_name);
	when E_CONS or E_CONST:
		(void)fprintf(f, "%s", expr->e_const->c_name);
	when E_PARAM:
		if (expr->e_level < level)
			pr_c_expr(f, expr->e_patt,
				0, InnerPrec(prec, context));
		else
			pr_actual(f, expr->e_level - level,
				expr->e_where, InnerPrec(prec, context));
	when E_PLUS:
		pr_c_expr(f, expr->e_rest, level, prec);
		(void)fprintf(f, " + %d", expr->e_incr);
	when E_VAR:
		(void)fprintf(f, "%s", expr->e_vname);
	}
	if (prec < context)
		(void)fprintf(f, ")");
}

local bool
is_list(expr)
reg	EXPR	*expr;
{
	while (expr->e_class == E_APPLY &&
	       expr->e_func->e_class == E_CONS &&
	       expr->e_func->e_const == cons &&
	       expr->e_arg->e_class == E_PAIR)
		expr = expr->e_arg->e_right;
	return expr->e_class == E_CONST && expr->e_const == nil;
}

local void
pr_elist(f, expr, level)
	FILE	*f;
reg	EXPR	*expr;
	int	level;
{
	(void)fprintf(f, "[");
	repeat {
		pr_c_expr(f, expr->e_arg->e_left, level, PREC_COMMA+1);
		expr = expr->e_arg->e_right;
	until(expr->e_const == nil);
		(void)fprintf(f, ", ");
	}
	(void)fprintf(f, "]");
}

/*
 *	Is expr a string?  (We already know it's a list)
 */
local bool
is_string(expr)
reg	EXPR	*expr;
{
	while (expr->e_class == E_APPLY &&
	       expr->e_arg->e_left->e_class == E_CHAR)
		expr = expr->e_arg->e_right;
	return expr->e_class == E_CONST;	/* i.e. nil */
}

local void
pr_string(f, expr)
	FILE	*f;
reg	EXPR	*expr;
{
	(void)fprintf(f, "\"");
	while (expr->e_const != nil) {
		pr_char(f, expr->e_arg->e_left->e_char);
		expr = expr->e_arg->e_right;
	}
	(void)fprintf(f, "\"");
}

global void
pr_char(f, c)
	FILE	*f;
	natural	c;
{
	switch (c) {
	when '\007':	(void)fprintf(f, "\\a");
	when '\b':	(void)fprintf(f, "\\b");
	when '\f':	(void)fprintf(f, "\\f");
	when '\n':	(void)fprintf(f, "\\n");
	when '\r':	(void)fprintf(f, "\\r");
	when '\t':	(void)fprintf(f, "\\t");
	when '\013':	(void)fprintf(f, "\\v");
	otherwise:
		if (c < ' ' || c > '~')
			(void)fprintf(f, "\\%03o", c);
		else
			(void)fprintf(f, "%c", c);
	}
}

local void
pr_lambda(f, branch, level)
	FILE	*f;
	BRANCH	*branch;
	int	level;
{
	(void)fprintf(f, "lambda ");
	while (branch != NULL) {
		pr_c_expr(f, branch->br_pattern, level+1, PREC_BODY);
		(void)fprintf(f, " => ");
		pr_c_expr(f, branch->br_expr, level+1, PREC_LAMBDA);
		branch = branch->br_next;
		if (branch != NULL)
			(void)fprintf(f, " | ");
	}
}

local void
pr_presection(f, expr, level)
	FILE	*f;
reg	EXPR	*expr;
	int	level;
{
	pr_c_expr(f, expr->e_arg->e_left, level, PREC_COMMA+1);
	(void)fprintf(f, " %s", expr->e_func->e_class == E_DEFUN ?
				expr->e_func->e_defun->f_name :
				expr->e_func->e_const->c_name);
}

local void
pr_postsection(f, expr, level)
	FILE	*f;
reg	EXPR	*expr;
	int	level;
{
	(void)fprintf(f, "%s ", expr->e_func->e_class == E_DEFUN ?
				expr->e_func->e_defun->f_name :
				expr->e_func->e_const->c_name);
	pr_c_expr(f, expr->e_arg->e_right, level, PREC_COMMA+1);
}

/*
 *	If expr amounts to an identifier, return it, else NULL.
 */
global STRING
expr_name(expr, level)
reg	EXPR	*expr;
	int	level;
{
	switch (expr->e_class) {
	when E_DEFUN:
		return expr->e_defun->f_name;
	when E_CONS:
		return expr->e_const->c_name;
	when E_PLUS:
		return newstring("+");
	when E_VAR:
		return expr->e_vname;
	when E_PARAM:
		if (expr->e_level < level)
			return expr_name(expr->e_patt, 0);
		return val_name(expr->e_level - level, expr->e_where);
	}
	return NULL;
}

local int
precedence(expr)
reg	EXPR	*expr;
{
	switch (expr->e_class) {
	when E_PAIR:
		return PREC_COMMA;
	when E_LAMBDA:
		return PREC_LAMBDA;
	when E_PRESECT or E_POSTSECT:
		return in_definition ? PREC_INFIX : PREC_LAMBDA;
	when E_WHERE or E_RWHERE:
		return PREC_WHERE;
	when E_LET or E_RLET:
		return PREC_LET;
	when E_IF:
		return PREC_IF;
	when E_APPLY:
		return PREC_APPLY;
	when E_CONS:
		if (op_lookup(expr->e_const->c_name) != NULL)
			return PREC_INFIX;
	when E_DEFUN:
		if (op_lookup(expr->e_defun->f_name) != NULL)
			return PREC_INFIX;
	when E_PLUS:
		return op_lookup(newstring("+"))->op_prec;
	when E_VAR:
		if (op_lookup(expr->e_vname) != NULL)
			return PREC_INFIX;
	when E_PARAM:
		return precedence(expr->e_patt);
	}
	return PREC_ATOMIC;
}
