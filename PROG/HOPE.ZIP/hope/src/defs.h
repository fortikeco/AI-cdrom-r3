#ifndef	DEFS_H
#define	DEFS_H
/*
 * A lazy Hope interpreter
 *
 * Ross Paterson
 *	University of Queensland, 1988, 1989.
 *	Imperial College, 1990, 1991.  (rap@doc.ic.ac.uk)
 */

/*
 * Standard Definitions
 */

#include <stdio.h>

#ifdef	THINK_C
#	define	__STDC__
#	define	const
#	define	true	MyTrue
#	define	false	MyFalse
#endif

#ifdef	unix
#	define	RE_EDIT
#endif

/*
 *	ANSI C or not ANSI C?
 */
#ifdef	__STDC__
#	define	ARGS(arglist)	arglist
typedef	void	*void_p;
#	include	<stdlib.h>
#	include	<string.h>
typedef	size_t	Size_t;
#else
#	define	ARGS(arglist)	()
typedef	char	*void_p;
typedef	unsigned int	Size_t;
#	define	const
extern	int	strcmp		ARGS((const char *s1, const char *s2));
extern	char	*strcpy		ARGS((char *s1, const char *s2));
extern	int	strlen		ARGS((const char *s));
extern	int	strncmp		ARGS((const char *s1, const char *s2, int n));
extern	char	*strncpy	ARGS((char *s1, const char *s2, int n));
extern	void_p	malloc 		ARGS((Size_t size));
#endif

#ifdef	unix
extern	int	unlink		ARGS((const char *path));
#	define	remove	unlink
#endif

#ifdef	EBUG
#	define	reg
#	define	local
#else
#	define	reg	register
#	define	local	static
#endif
#define	global

typedef	unsigned int	natural;
typedef	int	bool;
typedef	char	sbool;
#define	TRUE	1
#define	FALSE	0

#define	when	break; case
#define	or	: case
#define	otherwise	break; default

#define	repeat	for (;;)
#define	until(c)	if (c) break

#define	SIZE(array)	(sizeof(array)/sizeof(array[0]))

/* a sop to keep dumb checkers happy */
#define	NOT_REACHED	return

#ifdef	EBUG
#	define	ASSERT(x)	if (! (x)) \
		(fprintf(stderr, "assertion failed: file %s, line %d\n", \
			__FILE__, __LINE__), abort())
#else
#	define	ASSERT(x)
#endif

/*
 * System-dependent stuff
 */

#ifdef	RE_EDIT
extern	void	edit		ARGS((const char *name));
#else
#	define	edit(name)
#endif

extern	void	init_lex	ARGS((void));
extern	int	yyparse		ARGS((void));
extern	int	yylex		ARGS((void));

/*
 *	Unix functions.
 */

#ifdef	unix
extern	int	isatty		ARGS((int fd));
extern	int	execlp		ARGS((const char *path, const char *name, ...));
extern	char	*mktemp		ARGS((char *template));
extern	int	system		ARGS((const char *command));
#endif

#endif
