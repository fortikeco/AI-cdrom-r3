#include "defs.h"
#include "memory.h"
#include "expr.h"
#include "cases.h"
#include "error.h"
#include "path.h"

/*
 *	Functions, Expressions and Patterns.
 *
 *	All semantic checks here occur at the top level, so sub-expressions
 *	are always defined.
 */

local	const	char	bound_variable[] = "x'"; /* different from any STRING */

global EXPR *
char_expr(c)
	natural	c;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_CHAR;
	expr->e_char = c;
	return expr;
}

global EXPR *
text_expr(text, n)
reg	const	unsigned char	*text;
	int	n;
{
reg	const	unsigned char	*s;
reg	EXPR	*expr;

	expr = e_nil;
	for (s = text+n-1; s >= text; s--)
		expr = apply_expr(e_cons, pair_expr(char_expr(*s), expr));
	return expr;
}

global EXPR *
num_expr(n)
	NUM	n;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_NUM;
	expr->e_num = n;
	return expr;
}

global EXPR *
const_expr(data_constant)
	CONS	*data_constant;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_CONST;
	expr->e_const = data_constant;
	return expr;
}

global EXPR *
cons_expr(data_constructor)
	CONS	*data_constructor;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_CONS;
	expr->e_const = data_constructor;
	return expr;
}

/*
 *	Identifier occurring in an operand position in a pattern.
 *	If it's not a constant, it must be a variable.
 */
global EXPR *
id_pattern(name)
	STRING	name;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	if ((expr->e_const = cons_lookup(name)) != NULL &&
	    ! expr->e_const->c_constructor)
		expr->e_class = E_CONST;
	else {
		expr->e_class = E_VAR;
		expr->e_vname = name;
	}
	return expr;
}

/*
 *	Identifier occurring in an operator position in a pattern.
 *	It must be a constructor.
 */
global EXPR *
apply_pat(name, arg)
	STRING	name;
	EXPR	*arg;
{
reg	EXPR	*expr;
reg	CONS	*cp;
	int	incr;

	if ((cp = cons_lookup(name)) != NULL && cp->c_constructor) {
		expr = NEW(EXPR);
		expr->e_class = E_CONS;
		expr->e_const = cp;
		return apply_expr(expr, arg);
	}
	if (name == newstring("+") &&
		 arg->e_class == E_PAIR &&
		 arg->e_right->e_class == E_NUM) {
		/* change arg from a PAIR to a PLUS */
		expr = arg->e_left;
		incr = (int)(arg->e_right->e_num);
		arg->e_class = E_PLUS;
		arg->e_incr = incr;
		arg->e_rest = expr;
		return arg;
	}
	error(SEMERR, "unknown constructor '%s'", name);
	return NULL;
}

/*
 *	An identifier occurring as an expression.
 *	Call it a variable for now; we'll find out what it really is later.
 */
global EXPR *
id_expr(name)
	STRING	name;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_VAR;
	expr->e_vname = name;
	return expr;
}

global EXPR *
dir_expr(where)
	PATH	where;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_PARAM;
	expr->e_level = 0;
	expr->e_where = p_stash(p_reverse(where));
	return expr;
}

global EXPR *
pair_expr(left, right)
	EXPR	*left, *right;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_PAIR;
	expr->e_left = left;
	expr->e_right = right;
	return expr;
}

global EXPR *
apply_expr(func, arg)
	EXPR	*func, *arg;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_APPLY;
	expr->e_func = func;
	expr->e_arg = arg;
	return expr;
}

global EXPR *
func_expr(branches)
reg	BRANCH	*branches;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_LAMBDA;
	expr->e_branch = branches;
	expr->e_code = l_nomatch(expr);
	return expr;
}

/*
 *	Representation of various other structures.
 */

global EXPR *
ite_expr(if_expr, then_expr, else_expr)
	EXPR	*if_expr, *then_expr, *else_expr;
{
	BRANCH	*branchlist;

	branchlist = cons_branch(new_branch(e_true, then_expr),
				 new_branch(e_false, else_expr));
	if_expr = apply_expr(func_expr(branchlist), if_expr);
	if_expr->e_class = E_IF;
	if_expr->e_func->e_class = E_THEN;
	return if_expr;
}

global EXPR *
let_expr(pattern, body, subexpr, recursive)
	EXPR	*pattern, *body, *subexpr;
	bool	recursive;
{
reg	EXPR	*expr;

	expr = apply_expr(func_expr(new_branch(pattern, subexpr)), body);
	expr->e_class = recursive ? E_RLET : E_LET;
	expr->e_func->e_class = E_EQN;
	return expr;
}

global EXPR *
where_expr(subexpr, pattern, body, recursive)
	EXPR	*subexpr, *pattern, *body;
	bool	recursive;
{
reg	EXPR	*expr;

	expr = apply_expr(func_expr(new_branch(pattern, subexpr)), body);
	expr->e_class = recursive ? E_RWHERE : E_WHERE;
	expr->e_func->e_class = E_EQN;
	return expr;
}

global EXPR *
presection(operator, arg)
	STRING	operator;
	EXPR	*arg;
{
reg	EXPR	*expr;

	expr = func_expr(new_branch(id_pattern(bound_variable),
		apply_expr(id_expr(operator),
			pair_expr(arg, id_expr(bound_variable)))));
	expr->e_class = E_PRESECT;
	return expr;
}

global EXPR *
postsection(operator, arg)
	STRING	operator;
	EXPR	*arg;
{
reg	EXPR	*expr;

	expr = func_expr(new_branch(id_pattern(bound_variable),
		apply_expr(id_expr(operator),
			pair_expr(id_expr(bound_variable), arg))));
	expr->e_class = E_POSTSECT;
	return expr;
}

/*
 *	Kinds of expression used to represent built-in functions.
 */

global EXPR *
builtin_expr(fn)
	FUNCTION *fn;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_BUILTIN;
	expr->e_fn = fn;
	return expr;
}

global EXPR *
bu_1math_expr(fn)
	UNARY	*fn;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_BU_1MATH;
	expr->e_1math = fn;
	return expr;
}

global EXPR *
bu_2math_expr(fn)
	BINARY	*fn;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_BU_2MATH;
	expr->e_2math = fn;
	return expr;
}

/*
 *	Branches of lambdas or defined functions.
 */

global BRANCH *
new_branch(pattern, expr)
	EXPR	*pattern;
	EXPR	*expr;
{
reg	BRANCH	*branch;

	branch = NEW(BRANCH);
	branch->br_pattern = pattern;
	branch->br_expr = expr;
	branch->br_nvars = 0;
	branch->br_next = NULL;
	return branch;
}

global BRANCH *
cons_branch(branch, branchlist)
	BRANCH	*branch, *branchlist;
{
	branch->br_next = branchlist;
	return branch;
}

/*
 *	Defined functions and constants
 */

global void
decl_func(name, type)
	STRING	name;
	TYPE	*type;
{
	if (erroneous)
		return;
	if (fn_local(name) != NULL)
		error(SEMERR, "function '%s' already declared", name);
	else {
		new_fn(name, type);
		preserve();
	}
}

global void
def_cons(name, expr)
	STRING	name;
	EXPR	*expr;
{
reg	FUNC	*fn;

	if (erroneous)
		return;
	if ((fn = fn_local(name)) == NULL)
		error(SEMERR, "function '%s' not declared", name);
	else if (fn->f_branch != NULL || fn->f_value != NULL)
		error(SEMERR, "attempt to redefine '%s'", name);
	else if (nr_expr(expr) && chk_const(expr, fn)) {
		comp_expr(expr);
		fn->f_value = expr;
		preserve();
	}
}

global void
define(name, branch)
	STRING	name;
	BRANCH	*branch;
{
reg	FUNC	*fn;
reg	BRANCH	*br;

	if (erroneous)
		return;
	if ((fn = fn_local(name)) == NULL)
		error(SEMERR, "function '%s' not declared", name);
	else if (fn->f_branch == NULL && fn->f_value != NULL)
		error(SEMERR, "attempt to redefine '%s'", name);
	else if (nr_branch(branch) && chk_func(branch, fn)) {
		/* add the branch at the end */
		if (fn->f_branch == NULL)
			fn->f_branch = branch;
		else {
			for (br = fn->f_branch;
			     br->br_next != NULL;
			     br = br->br_next)
				;
			br->br_next = branch;
		}
		/* compile it */
		if (fn->f_code == NULL)
			fn->f_code = f_nomatch(fn);
		fn->f_code = comp_branch(fn->f_code, branch);
		preserve();
	}
}
