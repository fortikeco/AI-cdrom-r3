#include "defs.h"
#include "newstring.h"
#include "table.h"

global void
t_init(table)
	TABLE	*table;
{
	table->t_front = NULL;
	table->t_end = &(table->t_front);
}

global void
t_insert(table, element)
	TABLE	*table;
	TAB_ELT	*element;
{
	*(table->t_end) = element;
	table->t_end = &(element->t_next);
	element->t_next = NULL;
}

global void
t_copy(table1, table2)
	TABLE	*table1;
	const	TABLE	*table2;
{
	if (table2->t_front == NULL)
		t_init(table1);
	else {
		table1->t_front = table2->t_front;
		table1->t_end = table2->t_end;
	}
}

global TAB_ELT *
t_lookup(table, name)
	const	TABLE	*table;
reg	STRING	name;
{
reg	TAB_ELT	*elem;

	for (elem = table->t_front; elem != NULL; elem = elem->t_next)
		if (elem->t_name == name)
			return elem;
	return NULL;
}

global void
t_foreach(table, action)
	const	TABLE	*table;
	TAB_ACT	*action;
{
reg	TAB_ELT	*elem;

	for (elem = table->t_front; elem != NULL; elem = elem->t_next)
		(*action)(elem);
}
