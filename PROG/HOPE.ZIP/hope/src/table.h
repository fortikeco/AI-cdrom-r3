#ifndef TABLE_H
#define TABLE_H

#include "defs.h"
#include "newstring.h"

typedef	struct	_TAB_ELT TAB_ELT;

typedef	struct {
	TAB_ELT	*t_front;
	TAB_ELT	**t_end;
} TABLE;

/* Make this the first field in your structure */
struct _TAB_ELT {
	STRING	t_name;
	TAB_ELT	*t_next;
};

typedef	void	TAB_ACT		ARGS((TAB_ELT *elem));

extern	void	t_init		ARGS((TABLE *table));
extern	void	t_insert	ARGS((TABLE *table, TAB_ELT *element));
extern	void	t_copy		ARGS((TABLE *table1, const TABLE *table2));
extern	TAB_ELT	*t_lookup	ARGS((const TABLE *table, STRING name));
extern	void	t_foreach	ARGS((const TABLE *table, TAB_ACT *action));

#endif
