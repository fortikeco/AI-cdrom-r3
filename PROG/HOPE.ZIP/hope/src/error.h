#ifndef ERROR_H
#define ERROR_H

/* error categories */
/* these are also indices for an array in error() (qv) */
#define	LEXERR	0	/* lexical error */
#define	SYNERR	1	/* syntax error */
#define	SEMERR	2	/* semantic error, except type errors */
#define	TYPEERR	3	/* type conflict */
#define	EXECERR	4	/* run-time error */
#define	FATALERR 5	/* fatal error */
#define	INTERR	6	/* internal error */

extern	FILE	*errout;	/* initialized by start_err_line() */

extern	void	start_err_line	ARGS((void));
	/* call before line written to errout */
extern	void	error		ARGS((int errtype, const char *fmt, ...));
/*
 * If errtype >= TYPEERR, error() will not return.
 * Also, any error in a system module is treated as fatal.
 */
extern	void	yyerror		ARGS((const char *msg));

extern	bool	erroneous; /* error already reported in the current line */

extern	bool	recovering	ARGS((void));	/* Yacc is recovering */

extern	void	enable_interrupt	ARGS((void));
extern	void	disable_interrupt	ARGS((void));

#endif
