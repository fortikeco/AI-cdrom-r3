#ifndef NEWSTRING_H
#define NEWSTRING_H

/*
 *	Heap storage for strings.
 *	Each string is assigned a unique address, so that direct address
 *	comparisons can be used for string equality tests.
 */

typedef	const	char	*STRING;

extern	void	init_strings	ARGS((void));
extern	STRING	newstring	ARGS((const char *s));
extern	STRING	newnstring	ARGS((const char *s, int n));

#endif
