#ifndef	TEXT_H
#define	TEXT_H

/*
 * A text literal, guaranteed null-terminated, but may contain extra nulls.
 */

typedef	struct {
	const	unsigned char	*t_start;
	int	t_length;
} TEXT;

#endif
