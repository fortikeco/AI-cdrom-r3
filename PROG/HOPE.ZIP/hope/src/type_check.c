#include "defs.h"
#include "expr.h"
#include "cell.h"
#include "op.h"
#include "error.h"
#include "exceptions.h"

#define	MAX_TYPE_ARGS	20	/* max. args of a type synonym (not checked) */

global	CELL	*expr_type;	/* last inferred type */

	/* Types of local program variables, allocated with new_vars() */
local	CELL	**next_vtype;
	/* Type variables used by copy_type() */
local	CELL	**first_tvar, **next_tvar;
	/* Types of variables local to a pattern or parameter */
local	CELL	**local_var;
	/* Local variables at each level */
local	CELL	***variables;

local	void	match_type
	ARGS((STRING name, CELL *inferred, TYPE *declared));

local	CELL	*ty_expr	ARGS((EXPR *expr));
local	CELL	*ty_pattern	ARGS((EXPR *pattern, int level));
local	CELL	*ty_if		ARGS((EXPR *if_expr, BRANCH *branch));
local	CELL	*ty_eqn		ARGS((BRANCH *branch, EXPR *expr));
local	CELL	*ty_rec_eqn	ARGS((BRANCH *branch, EXPR *expr));
local	CELL	*ty_list	ARGS((BRANCH *branch));
local	CELL	*ty_branch	ARGS((BRANCH *branch));

local	void	init_vars	ARGS((void));
local	void	new_vars	ARGS((int n));
local	void	del_vars	ARGS((void));

local	CELL	*copy_type	ARGS((TYPE *type));
local	CELL	*cp_type	ARGS((TYPE *type));
local	CELL	*cp_tvar	ARGS((TVAR tvar));
local	CELL	*cp_list	ARGS((TYPE *type));
local	CELL	*cp_syn		ARGS((TYPE *type));

local	bool	instance	ARGS((TYPE *type, CELL *inf_type));

local	void	show_argument	ARGS((EXPR *func, EXPR *arg, CELL *arg_type));
local	void	show_expr	ARGS((EXPR *expr, CELL *type));
local	void	show_branch	ARGS((BRANCH *branch));

global bool
chk_func(branch, fn)
	BRANCH	*branch;
	FUNC	*fn;
{
	if (setjmp(execerror))
		return FALSE;
	init_vars();
	match_type(fn->f_name, ty_branch(branch), fn->f_type);
	return TRUE;
}

global bool
chk_const(expr, fn)
	EXPR	*expr;
	FUNC	*fn;
{
	if (setjmp(execerror))
		return FALSE;
	init_vars();
	match_type(fn->f_name, ty_expr(expr), fn->f_type);
	return TRUE;
}

/*
 *	Check that the inferred type is compatible with (at least as
 *	general as) the declared type.
 */
local void
match_type(name, inferred, declared)
	STRING	name;
	CELL	*inferred;
	TYPE	*declared;
{
	if (! instance(declared, inferred)) {
		start_err_line();
		(void)fprintf(errout, "  declared type: ");
		pr_type(errout, declared);
		(void)fprintf(errout, "\n");
		start_err_line();
		(void)fprintf(errout, "  inferred type: ");
		pr_ty_value(errout, inferred);
		(void)fprintf(errout, "\n");
		error(TYPEERR, "'%s': does not match declaration", name);
	}
}

/*
 *	Top level: must have
 *		lambda input => expr: list char -> T
 *
 *	Side effect: set expr_type to T.
 */
global void
chk_expr(expr)
	EXPR	*expr;
{
	init_vars();
	new_vars(0);
	*next_vtype++ = new_tcons(list, new_tcons(character, NOCELL));
	expr_type = ty_expr(expr);
	del_vars();
}

global void
chk_list(expr)
	EXPR	*expr;
{
	chk_expr(expr);
	if (! unify(expr_type, new_tcons(list, new_tvar(alpha)))) {
		show_expr(expr, expr_type);
		error(TYPEERR, "a 'write' expression must produce a list");
	}
}

local CELL *
ty_expr(expr)
reg	EXPR	*expr;
{
	CELL	*type1, *type2;

	switch (expr->e_class) {
	when E_NUM:
		return new_tcons(num, NOCELL);
	when E_CHAR:
		return new_tcons(character, NOCELL);
	when E_DEFUN:
		return copy_type(expr->e_defun->f_type);
	when E_CONST or E_CONS:
		return copy_type(expr->e_const->c_type);
	when E_LAMBDA or E_PRESECT or E_POSTSECT:
		return ty_list(expr->e_branch);
	when E_PARAM:
		return ty_pattern(expr->e_patt, expr->e_level);
	when E_PLUS:
		type1 = new_tcons(num, NOCELL);
		type2 = ty_expr(expr->e_rest);
		if (! unify(type1, type2)) {
			start_err_line();
			(void)fprintf(errout, "  ");
			pr_expr(errout, expr);
			(void)fprintf(errout, "\n");
			show_expr(expr->e_rest, type2);
			error(TYPEERR, "argument has wrong type");
		}
		return type1;
	when E_VAR:
		/*
		 *	... , x: t, ... => x: t
		 */
		return local_var[expr->e_var];
	when E_PAIR:
		/*
		 *	A => e1: t1
		 *	A => e2: t2
		 *	-------------
		 *	A => e1, e1: t1 # t2
		 */
		type1 = ty_expr(expr->e_left);
		type2 = ty_expr(expr->e_right);
		return new_tcons(product, new_pair(type1, type2));
	when E_IF:
		return ty_if(expr->e_arg, expr->e_func->e_branch);
	when E_WHERE or E_LET:
		return ty_eqn(expr->e_func->e_branch, expr->e_arg);
	when E_RWHERE or E_RLET:
		return ty_rec_eqn(expr->e_func->e_branch, expr->e_arg);
	when E_APPLY:
		/*
		 *	A => e1: t2 -> t
		 *	A => e2: t2
		 *	-------------
		 *	A => (e1 e2): t
		 */
		type1 = ty_expr(expr->e_func);
		type2 = ty_expr(expr->e_arg);
		if (! unify(type1,
			    new_tcons(function,
				      new_pair(type2, new_tvar(alpha))))) {
			start_err_line();
			(void)fprintf(errout, "  ");
			pr_expr(errout, expr);
			(void)fprintf(errout, "\n");
			show_expr(expr->e_func, type1);
			show_argument(expr->e_func, expr->e_arg, type2);
			error(TYPEERR, "argument has wrong type");
		}
		return deref(type1)->c_targ->c_right;
	}
	error(INTERR, "illegal expr class %d", expr->e_class);
	NOT_REACHED(NULL);
}

local CELL *
ty_pattern(pattern, level)
	EXPR	*pattern;
	int	level;
{
	local_var = variables[level];
	return ty_expr(pattern);
}

local CELL *
ty_if(if_expr, branch)
	EXPR	*if_expr;
	BRANCH	*branch;
{
reg	CELL	*type1, *type2;
	EXPR	*then_expr, *else_expr;

	then_expr = branch->br_expr;
	else_expr = branch->br_next->br_expr;
	type1 = ty_expr(if_expr);
	if (! unify(type1, new_tcons(truval, NOCELL))) {
		show_expr(if_expr, type1);
		error(TYPEERR, "predicate should have type truval");
	}

	new_vars(0);
	type1 = ty_expr(then_expr);
	type2 = ty_expr(else_expr);
	del_vars();
	if (! unify(type1, type2)) {
		show_expr(then_expr, type1);
		show_expr(else_expr, type2);
		error(TYPEERR, "conflict between branches of conditional");
	}
	return type1;
}

/*
 *	A' => pat: T1
 *	A, A' => val: T2
 *	A => exp: T1
 *	--------------------
 *	LET pat == exp IN val: T2
 */
local CELL *
ty_eqn(branch, expr)
	BRANCH	*branch;
	EXPR	*expr;
{
reg	CELL	*pat_type, *exp_type, *val_type;

	new_vars(branch->br_nvars);
	pat_type = ty_pattern(branch->br_pattern, 0);
	val_type = ty_expr(branch->br_expr);
	del_vars();
	exp_type = ty_expr(expr);
	if (! unify(pat_type, exp_type)) {
		show_expr(branch->br_pattern, pat_type);
		show_expr(expr, exp_type);
		error(TYPEERR, "sides of equation have conflicting types");
	}
	return val_type;
}

/*
 *	A' => pat: T1
 *	A, A' => val: T2
 *	A, A' => exp: T1
 *	--------------------
 *	LETREC pat == exp IN val: T2
 */
local CELL *
ty_rec_eqn(branch, expr)
	BRANCH	*branch;
	EXPR	*expr;
{
reg	CELL	*pat_type, *exp_type, *val_type;

	new_vars(branch->br_nvars);
	pat_type = ty_pattern(branch->br_pattern, 0);
	val_type = ty_expr(branch->br_expr);
	exp_type = ty_expr(expr);
	del_vars();
	if (! unify(pat_type, exp_type)) {
		show_expr(branch->br_pattern, pat_type);
		show_expr(expr, exp_type);
		error(TYPEERR, "sides of equation have conflicting types");
	}
	return val_type;
}

/*
 *	A => b1: t
 *	...
 *	A => bn: t
 *	--------------
 *	A => (lambda b1 | ... | bn): t
 */
local CELL *
ty_list(branch)
reg	BRANCH	*branch;
{
reg	CELL	*type;
reg	BRANCH	*br;

	type = ty_branch(branch);
	for (br = branch->br_next; br != NULL; br = br->br_next)
		if (! unify(type, ty_branch(br))) {
			show_branch(branch);
			error(TYPEERR, "alternatives have incompatible types");
		}
	return type;
}

/*
 *	A' => p: t1
 *	A, A' => e: t2
 *	-----------------
 *	A => (p => e): t1 -> t2
 */
local CELL *
ty_branch(branch)
reg	BRANCH	*branch;
{
	CELL	*type;

	new_vars(branch->br_nvars);
	type = ty_pattern(branch->br_pattern, 0);
	type = new_tcons(function, new_pair(type, ty_expr(branch->br_expr)));
	del_vars();
	return type;
}

/*
 *	Type variable scopes.
 */

local void
init_vars()
{
static	CELL	*first_vtype[MAX_VARIABLES];
static	CELL	**local_table[MAX_SCOPES];

	start_heap();
	next_vtype = first_vtype;
	variables = local_table + MAX_SCOPES;
	init_pr_ty_value();
}

/*
 *	New scope: allocate and initialize a new type variable
 *	for each program variable introduced in the branch.
 */
local void
new_vars(n)
reg	int	n;
{
	*--variables = next_vtype;
	/*
	 *	x1: alpha1, ..., xn: alphan
	 */
	while (n-- > 0)
		*next_vtype++ = new_tvar(alpha);
}

local void
del_vars()
{
	next_vtype = *variables++;
}

/*
 *	Make a temporary copy of a type.
 */
local CELL *
copy_type(type)
	TYPE	*type;
{
	next_tvar = first_tvar = next_vtype;
	return cp_type(type);
}

local CELL *
cp_type(type)
reg	TYPE	*type;
{
	return type->ty_variable ? cp_tvar(type->ty_var) :
		type->ty_deftype->dt_synonym ? cp_syn(type) :
			new_tcons(type->ty_deftype,
				type->ty_firstarg ?
					cp_list(type->ty_firstarg) : NOCELL);
}

local CELL *
cp_tvar(tvar)
reg	TVAR	tvar;
{
reg	CELL	**tvp;

	for (tvp = first_tvar; tvp != next_tvar; tvp++)
		if ((*tvp)->c_tvar == tvar)
			return *tvp;
	*next_tvar++ = new_tvar(tvar);
	return *tvp;
}

local CELL *
cp_list(type)
reg	TYPE	*type;
{
	return type->ty_next == NULL ? cp_type(type) :
		new_pair(cp_type(type), cp_list(type->ty_next));
}

/*
 *	Expand a type synonym
 */
local CELL *
cp_syn(type)
reg	TYPE	*type;
{
	CELL	*actual[MAX_TYPE_ARGS];
reg	CELL	**cp, *ctype;
	CELL	**old_first_tvar;
	TYPE	*tp;

	/*
	 * Collect actual type parameters
	 * (in the current type variable environment)
	 */
	cp = actual;
	for (tp = type->ty_firstarg; tp != NULL; tp = tp->ty_next)
		*cp++ = cp_type(tp);
	/*
	 * Instantiate the formal type parameters to the actuals before
	 * constructing the type synonym.
	 * (all in a new type variable environment)
	 */
	old_first_tvar = first_tvar;
	first_tvar = next_tvar;
	cp = actual;
	for (tp = type->ty_deftype->dt_varlist; tp != NULL; tp = tp->ty_next) {
		*next_tvar = new_tvar(tp->ty_var);
		(*next_tvar)->c_tref = *cp;
		next_tvar++;
		cp++;
	}
	ctype = cp_type(type->ty_deftype->dt_type);
	next_tvar = first_tvar;
	first_tvar = old_first_tvar;
	return ctype;
}

/*
 *	Is type an instance of inf_type?
 *	The test uses the fact that unify() prefers to instantiate its
 *	first argument.
 */
local bool
instance(type, inf_type)
	TYPE	*type;
	CELL	*inf_type;
{
reg	CELL	**tvp;

	if (! unify(inf_type, copy_type(type)))
		return FALSE;
	/*
	 * Check if any of the type variables created by copy_type() have
	 * been instantiated.  If so, type is not an instance of inf_type.
	 */
	for (tvp = first_tvar; tvp != next_tvar; tvp++)
		if ((*tvp)->c_tref != NOCELL)
			return FALSE;
	return TRUE;
}

/*
 *	Display various things and their types,
 *	to enlighten the user about a type error.
 */

local void
show_argument(func, arg, arg_type)
	EXPR	*func, *arg;
	CELL	*arg_type;
{
	STRING	name;

	if (arg->e_class == E_PAIR &&
	    (name = expr_name(func, MAX_SCOPES)) != NULL &&
	    op_lookup(name) != NULL) {
		arg_type = deref(arg_type);
		show_expr(arg->e_left, arg_type->c_targ->c_left);
		show_expr(arg->e_right, arg_type->c_targ->c_right);
	}
	else
		show_expr(arg, arg_type);
}

local void
show_expr(expr, type)
	EXPR	*expr;
	CELL	*type;
{
	start_err_line();
	(void)fprintf(errout, "  ");
	pr_expr(errout, expr);
	(void)fprintf(errout, " : ");
	pr_ty_value(errout, type);
	(void)fprintf(errout, "\n");
}

local void
show_branch(branch)
reg	BRANCH	*branch;
{
	for ( ; branch != NULL; branch = branch->br_next) {
		start_err_line();
		(void)fprintf(errout, "  ");
		pr_expr(errout, branch->br_pattern);
		(void)fprintf(errout, " => ");
		pr_expr(errout, branch->br_expr);
		(void)fprintf(errout, " : ");
		pr_ty_value(errout, ty_branch(branch));
		(void)fprintf(errout, "\n");
	}
}
