/*
 *	Determine the alignment of the current machine.
 */
#include <stdio.h>

typedef struct { char c; int *ptr; } ptrrec;

#define	OFFSET(rectype,field)	((int)&(((rectype *)0)->field))

extern	int	printf(), exit();

void
main()
{
	(void)printf("#define ALIGNMENT %d\n", OFFSET(ptrrec, ptr));
	(void)exit(0);
}
