#include "defs.h"
#include "error.h"

#include <signal.h>

/*ARGSUSED*/
local void
onintr(sig)
	int	sig;
{
	disable_interrupt();
	error(EXECERR, "interrupted");
}

global void
disable_interrupt()
{
	(void)signal(SIGINT, SIG_IGN);
}

global void
enable_interrupt()
{
	(void)signal(SIGINT, onintr);
}
