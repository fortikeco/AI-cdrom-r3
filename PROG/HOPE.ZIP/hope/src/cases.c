#include "defs.h"
#include "cases.h"
#include "char_array.h"
#include "memory.h"

local	LCASE	*copy_lcase	ARGS((LCASE *old));
local	UCASE	*new_reference	ARGS((UCASE *node));

/*
 *	Upper case expressions.
 */

global UCASE *
ucase(path, cases)
	PATH	path;
	LCASE	*cases;
{
reg	UCASE	*code;

	code = NEW(UCASE);
	code->uc_class = UC_CASE;
	code->uc_references = 1;
	code->uc_path = path;
	code->uc_cases = cases;
	return code;
}

global UCASE *
f_nomatch(defun)
	FUNC	*defun;
{
reg	UCASE	*code;

	code = NEW(UCASE);
	code->uc_class = UC_F_NOMATCH;
	code->uc_defun = defun;
	return code;
}

global UCASE *
l_nomatch(who)
	EXPR	*who;
{
reg	UCASE	*code;

	code = NEW(UCASE);
	code->uc_class = UC_L_NOMATCH;
	code->uc_who = who;
	return code;
}

global UCASE *
success(body, size)
	EXPR	*body;
	int	size;
{
reg	UCASE	*code;

	code = NEW(UCASE);
	code->uc_class = UC_SUCCESS;
	code->uc_body = body;
	code->uc_size = size;
	return code;
}

global UCASE *
strict(real)
	EXPR	*real;
{
reg	UCASE	*code;

	code = NEW(UCASE);
	code->uc_class = UC_STRICT;
	code->uc_real = real;
	return code;
}

global UCASE *
copy_ucase(old)
reg	UCASE	*old;
{
reg	UCASE	*new;

	new = NEW(UCASE);
	new->uc_class = old->uc_class;
	switch (old->uc_class) {
	when UC_CASE:
		new->uc_references = 1;
		new->uc_path = old->uc_path;
		new->uc_cases = copy_lcase(old->uc_cases);
	when UC_F_NOMATCH:
		new->uc_defun = old->uc_defun;
	when UC_L_NOMATCH:
		new->uc_who = old->uc_who;
	when UC_SUCCESS:
		new->uc_body = old->uc_body;
		new->uc_size = old->uc_size;
	when UC_STRICT:
		new->uc_real = old->uc_real;
	}
	return new;
}

/*
 *	Lower case expressions.
 */

global LCASE *
alg_case(arity, def)
reg	natural	arity;
reg	UCASE	*def;
{
reg	LCASE	*lcase;
reg	int	i;

	lcase = NEW(LCASE);
	lcase->lc_class = LC_ALGEBRAIC;
	lcase->lc_arity = arity;
	lcase->lc_limbs = NEWARRAY(UCASE *, arity);
	for (i = 0; i < arity; i++)
		lcase->lc_limbs[i] = def;
	return lcase;
}

global LCASE *
num_case(def)
	UCASE	*def;
{
reg	LCASE	*lcase;

	lcase = alg_case((natural)3, def);
	lcase->lc_class = LC_NUMERIC;
	return lcase;
}

global LCASE *
char_case(def)
	UCASE	*def;
{
reg	LCASE	*lcase;

	lcase = NEW(LCASE);
	lcase->lc_class = LC_CHARACTER;
	lcase->lc_arity = 256;		/* number of characters */
	lcase->lc_c_limbs = ca_new(def);
	return lcase;
}

local LCASE *
copy_lcase(old)
reg	LCASE	*old;
{
reg	LCASE	*new;
reg	int	i;

	new = NEW(LCASE);
	new->lc_class = old->lc_class;
	new->lc_arity = old->lc_arity;
	switch (old->lc_class) {
	when LC_ALGEBRAIC or LC_NUMERIC:
		new->lc_limbs = NEWARRAY(UCASE *, old->lc_arity);
		for (i = 0; i < old->lc_arity; i++)
			new->lc_limbs[i] = new_reference(old->lc_limbs[i]);
	when LC_CHARACTER:
		new->lc_c_limbs = ca_copy(old->lc_c_limbs);
		ca_map(new->lc_c_limbs, new_reference);
	}
	return new;
}

local UCASE *
new_reference(node)
reg	UCASE	*node;
{
	if (node->uc_class == UC_CASE)
		node->uc_references++;
	return node;
}
