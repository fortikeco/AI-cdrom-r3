/*
 *	Source file management and error reporting.
 */
#include "defs.h"
#include "module.h"
#include "source.h"
#include "newstring.h"
#include "error.h"
#include "exceptions.h"

#define	MAX_DEPTH	16	/* max. depth of module nesting (not checked) */
#define	MAX_LINE	1024	/* max. length of input line (not checked) */

#define	PROMPTOUT	stdout

global	FILE	*errout;

local	bool	atend;

typedef	struct {
	FILE	*file;
	int	lineno;
} SOURCE;

local	SOURCE	source[MAX_DEPTH];
local	SOURCE	*cur_source;

local	bool	istty;		/* top level input is a terminal */

local	char	src_line[MAX_LINE];
global	const	unsigned char	*inptr;

local	const	char	prompt[] = ">: ";	/* the Hope command prompt */

#ifdef RE_EDIT
#define	MAX_COMMAND	100	/* max. length of sh command (not checked) */
#define	MAX_FILENAME	100	/* max. length of file name (not checked) */

/*
 * To restart Hope after an edit, arising either from an "edit"
 * command or from an error in a source file (see below), we dump
 * the current session into a temporary file.  On restart, this file,
 * called a "script", is read first before reading the standard input.
 * Errors in the script cause the editor to be re-invoked (see below).
 */

local	const	char	tmp_stem[] = "/tmp/hope";
#define	MAX_TEMP	(sizeof(tmp_stem)+6)

local	const	char	*script;
#define	in_script()	(cur_source == source+1 && script != NULL)

/*
 * If an error is encountered while reading a file, a listing file
 * is created, consisting of the text of the source file with flagged
 * error messages embedded in it.  When the end of the file is reached,
 * The editor is invoked on the listing file.  If the user exits without
 * changing the listing, they leave Hope.  Otherwise, the source file
 * is replaced by the listing, minus error messages, and Hope attempts
 * to return to the previous state.
 */

/*
 * The prefix with which error messages are annotated in a listing.
 * Lines starting with this prefix are removed after the listing has been
 * edited, to obtain the new version of the source file.  The prefix
 * (1) should not normally occur at the start of a line in a Hope program,
 * (2) must not contain any grep(1) meta-characters.
 */
local	const	char	list_prefix[] = "@ ";

/* extension for listing files of Hope modules */
local	const	char	list_extension[] = ".LST";

/* level (if any) at which we are creating a listing file */
local	SOURCE	*listing;
local	int	first_error;	/* line no. of first error */
local	char	list_file[MAX_FILENAME];

local	void	re_edit_script	ARGS((void));
local	void	get_script	ARGS((char *buf));
local	void	temp_name	ARGS((char *buf));
#endif

global void
init_source()
{
	cur_source = source-1;
	atend = FALSE;
	enterfile(stdin);
#ifdef	unix
	istty = isatty(0);
#else
	istty = TRUE;
#endif
	if (istty)
		disable_interrupt();
#ifdef RE_EDIT
	script = NULL;
	listing = NULL;
#endif
}

global void
start_err_line()
{
#ifdef	RE_EDIT
	if (listing != cur_source) {
		if (listing != NULL) {
			/*
			 * We were already listing, but now we
			 * have an error in a deeper module --
			 * abandon the old listing.
			 */
			(void)fclose(errout);
			(void)remove(list_file);
			listing = NULL;
		}
		/* if it's in a system module, it will be fatal */
		if (istty && cur_source > source && ! mod_system()) {
			char	command[MAX_COMMAND];
			char	input_file[MAX_FILENAME];

			if (in_script()) {
				(void)strcpy(input_file, script);
				(void)strcpy(list_file, "/tmp/hopeXXXXXX");
				(void)mktemp(list_file);
			}
			else {
				mod_file(input_file, mod_name());
				(void)sprintf(list_file, "%s%s",
					mod_name(), list_extension);
			}
			(void)sprintf(command, "sed %dq %s >%s",
				cur_source->lineno, input_file, list_file);
			(void)system(command);
			first_error = cur_source->lineno;
			errout = fopen(list_file, "a");
			listing = cur_source;
		}
		else
			errout = stderr;
	}
	if (listing != NULL)
		(void)fprintf(errout, list_prefix);
#else
	errout = stderr;
#endif
}

/*
 *	Called on detecting the error -- flag the erroneous token.
 */
/*ARGSUSED*/
global void
yyerror(s)
	const	char	*s;
{
reg	const	unsigned char	*p;
reg	int	column;

	if (strcmp(s, "syntax error") == 0) {
		start_err_line();
		if (interactive())
			column = (int)sizeof(prompt)-1;
		else {
			/* line ends in a newline */
#ifdef	RE_EDIT
			if (listing == NULL) {
				(void)fprintf(errout, "%s", src_line);
				start_err_line();
			}
#else
			(void)fprintf(errout, "%s", src_line);
			start_err_line();
#endif
			column = 0;
		}
		for (p = (const unsigned char *)src_line; p < inptr; p++)
			if (*p >= ' ')
				column++;
			else if (*p == '\t')
				column += 8 - column%8;
#ifdef	RE_EDIT
		if (listing != NULL) {
			column -= (int)sizeof(list_prefix)-1;
			if (column < 0)
				column = 0;
		}
#endif
		(void)fprintf(errout, "%*s\n", column, "^");
		error(SYNERR, (const char *)0);
	}
	else
		error(SYNERR, s);
}

global	bool	erroneous;

#ifdef	__STDC__
#	include <stdarg.h>
	extern	int	vfprintf
		ARGS((FILE *f, const char *fmt, const va_list ap));
#	define	ETC
#	define	VAR_FPRINTF(f,fmt) {\
			va_list __args__;\
			va_start(__args__, fmt);\
			(void)vfprintf(f, fmt, __args__);\
			va_end(__args__);\
		}
#else
/* poor man's variable-length argument list */
#	define	ETC	, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10
#	define	VAR_FPRINTF(f,fmt)	(void)fprintf(f, fmt ETC)
#endif

/*VARARGS2*/
global void
error(errtype, fmt ETC)
	int	errtype;
	const	char	*fmt;
{
/* array indexed by error types (see error.h) */
static	const	char	*const	errname[] = {
			"lexical", "syntax", "semantic", "type",
			"run-time", "fatal", "internal"
		};

	start_err_line();
#ifdef RE_EDIT
	if (listing == NULL && ! interactive()) {
#else
	if (! interactive()) {
#endif
		if (cur_source > source)
			(void)fprintf(errout, "module %s, ", mod_name());
		(void)fprintf(errout, "line %d: ", cur_source->lineno);
	}
	(void)fprintf(errout, "%s error", errname[errtype]);
	if (fmt != NULL) {
		(void)fprintf(errout, " - ");
		VAR_FPRINTF(errout, fmt);
	}
	(void)fprintf(errout, "\n");

	if (errtype == INTERR)
		abort();
	if (errtype == FATALERR)
		(void)exit(1);
	if (mod_system())
		error(FATALERR, "error in system module");
	if (errtype >= TYPEERR) {
		if (istty)
			disable_interrupt();
		longjmp(execerror, 1);
	}
	erroneous = TRUE;
}

global void
enterfile(f)
reg	FILE	*f;
{
	cur_source++;
	cur_source->file = f;
	cur_source->lineno = 0;
	inptr = (const unsigned char *)"";
}

global bool
interactive()
{
	return cur_source == source && istty;
}

/*
 *	Get a line from the current input.
 *	The line will be terminated by a null if it comes from the terminal;
 *	otherwise it ends in a newline (whitespace) and then a null.
 */
global bool
getline()
{
	if (atend && cur_source >= source) {
		if (cur_source > source)
			(void)fclose(cur_source->file);
#ifdef	RE_EDIT
		if (listing == cur_source) {
			(void)fclose(errout);
			re_edit_script();
		}
		if (in_script()) {
			(void)remove(script);
			script = NULL;
			cur_source--;
		}
		else
#endif
		if (cur_source > source) {
			cur_source--;
			mod_finish();
		}
		else
			cur_source--;
	}
	if (cur_source < source)
		return FALSE;

	atend = FALSE;
	if (interactive()) {
		(void)fprintf(PROMPTOUT, prompt);
		(void)fflush(PROMPTOUT);
		atend = gets(src_line) == NULL;
		if (atend) {
			(void)fprintf(PROMPTOUT, "\n");
			(void)fflush(PROMPTOUT);
		}
	}
	else {
		atend = fgets(src_line, MAX_LINE, cur_source->file) == NULL;
#ifdef	RE_EDIT
		if (listing == cur_source && ! atend)
			(void)fprintf(errout, "%s", src_line); /* ends in \n */
#endif
	}
	/*
	 * Insert a line containing only a semi-colon at the end of each file,
	 * to end any un-terminated line;
	 */
	if (atend) {
		src_line[0] = '\0';
		inptr = (const unsigned char *)(interactive() ? ";" : ";\n");
	}
	else
		inptr = (const unsigned char *)src_line;
	cur_source->lineno++;
	return TRUE;
}

#ifdef RE_EDIT
/*
 *	`edit' command: save the current definitions in a file,
 *	invoke an editor on the file, and then re-enter Hope,
 *	re-reading the file.
 *	If an error occurs during re-reading, go back to the editor.
 */
global void
edit(name)
	STRING	name;
{
	char	tmp_file[MAX_TEMP];
	char	filename[MAX_FILENAME];
	char	command[MAX_COMMAND];

	if (! interactive())
		return;
	get_script(tmp_file);
	if (name != NULL)
		mod_file(filename, name);
	else
		(void)strcpy(filename, tmp_file);
	(void)sprintf(command, "${EDITOR-vi} %s", filename);
	(void)system(command);
	restart(tmp_file);
}

global void
set_script(filename)
	const	char	*filename;
{
	FILE	*f;

	if (strncmp(filename, tmp_stem, (int)sizeof(tmp_stem)-1) != 0)
		error(SEMERR, "bad argument '%s'", filename);
	else if ((f = fopen(filename, "r")) == NULL)
		error(SEMERR, "can't read script '%s'", filename);
	else {
		script = filename;
		enterfile(f);
	}
}

local void
get_script(buf)
	char	*buf;
{
	if (script)
		(void)strcpy(buf, script);
	else {
		temp_name(buf);
		mod_dump(fopen(buf, "w"));
	}
}

local void
temp_name(buf)
	char	*buf;
{
	(void)sprintf(buf, "%sXXXXXX", tmp_stem);
	(void)mktemp(buf);
}

#include <sys/types.h>
#include <sys/stat.h>

typedef	struct	stat	STAT;

extern	int	stat	ARGS((const char *filename, STAT *buf));

local time_t
mtime(file)
	const	char	*file;
{
	STAT	buf;

	if (stat(file, &buf) < 0)
		return 0;
	return buf.st_mtime;
}

local void
re_edit_script()
{
	char	filename[MAX_FILENAME];
	char	command[MAX_COMMAND];
	char	tmp_file[MAX_TEMP];
	time_t	before;

	get_script(tmp_file);
	before = mtime(list_file);
	(void)sprintf(command, "${EDITOR-vi} +%d %s", first_error, list_file);
	(void)system(command);
	if (mtime(list_file) == before) {	/* no change */
		(void)remove(list_file);
		(void)remove(tmp_file);
		(void)exit(0);
	}
	if (in_script())
		(void)strcpy(filename, tmp_file);
	else
		mod_file(filename, mod_name());
	(void)sprintf(command, "grep -v '^%s' %s >%s",
		list_prefix, list_file, filename);
	(void)system(command);
	(void)remove(list_file);
	restart(tmp_file);
}
#endif
