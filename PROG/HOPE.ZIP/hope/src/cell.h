#ifndef CELL_H
#define CELL_H

#include "path.h"
#include "expr.h"
#include "num.h"

/* classes of cell with no sub-cells */
#define	C_0_0	(-1)
#define	C_0_1	(C_0_0+1)
#define	C_0_2	(C_0_0+2)
#define	C_0_3	(C_0_0+3)
#define	C_0_4	(C_0_0+4)
#define	C_N_NO_CHILDREN	4
/* classes of cell with one sub-cell */
#define	C_1_0	C_N_NO_CHILDREN
#define	C_1_1	(C_1_0+1)
#define	C_1_2	(C_1_0+2)
#define	C_1_3	(C_1_0+3)
#define	C_1_4	(C_1_0+4)
#define	C_1_5	(C_1_0+5)
#define	C_N_ONE_CHILD	5
/* classes of cell with two sub-cells */
#define	C_2_0	(C_N_NO_CHILDREN+C_N_ONE_CHILD)
#define	C_2_1	(C_2_0+1)

#define	C_NCLASSES 8

#define	NO_CHILDREN	C_0_1 or C_0_2 or C_0_3 or C_0_4
#define	ONE_CHILD	C_1_1 or C_1_2 or C_1_3 or C_1_4 or C_1_5
#define	TWO_CHILDREN	C_2_1

#define	C_PAIR	C_2_1	/* general purpose pair and list builder */

/* type cell classes */
#define	C_TCONS	C_1_1
#define	C_TVAR	C_1_2

/* data cell classes */
#define	C_NUM	C_0_1
#define	C_CHAR	C_0_2
#define	C_CONST	C_0_3	/* constant */
#define	C_STREAM C_0_4	/* partially read input stream */
#define	C_CONS	C_1_1	/* constructed term */
#define	C_SUSP	C_1_2	/* term and environment */
#define C_DIRS	C_1_3	/* directions and value */
#define C_UCASE	C_1_4	/* upper case */
#define C_LCASE	C_1_5	/* upper case */

#define	NOCELL	((CELL *)0)

struct _CELL {
	short	c_class;
	union {
		NUM	cu_num;
		natural	cu_char;
		FILE	*cu_file;
		struct {
			union {
				CONS	*cu_cons;
				EXPR	*cu_expr;
				DEFTYPE	*cu_tcons;
				TVAR	cu_tvar;
				PATH	cu_path;
				UCASE	*cu_code;
				LCASE	*cu_lcase;
			} co_union;
			CELL	*cu_cell;
		} cu_one;
		struct {
			CELL	*cu_left, *cu_right;
		} cu_two;
	} c_union;
};

/* fields for general purpose pairs */
#define	c_left	c_union.cu_two.cu_left		/* PAIR */
#define	c_right	c_union.cu_two.cu_right		/* PAIR */

/* fields for data cells */
#define	c_num	c_union.cu_num			/* NUM */
#define	c_char	c_union.cu_char			/* CHAR */
#define	c_file	c_union.cu_file			/* STREAM */
#define	c_cons	c_union.cu_one.co_union.cu_cons	/* CONST, CONS */
#define	c_arg	c_union.cu_one.cu_cell		/* CONS */
#define	c_expr	c_union.cu_one.co_union.cu_expr	/* SUSP */
#define	c_code	c_union.cu_one.co_union.cu_code	/* UCASE */
#define	c_lcase	c_union.cu_one.co_union.cu_lcase /* LCASE */
#define	c_env	c_union.cu_one.cu_cell		/* SUSP, UCASE, LCASE */
#define	c_path	c_union.cu_one.co_union.cu_path	/* DIRS */
#define	c_val	c_union.cu_one.cu_cell		/* DIRS */

/* fields for type structures */
#define	c_tcons	c_union.cu_one.co_union.cu_tcons /* TCONS */
#define	c_targ	c_union.cu_one.cu_cell		/* TCONS */
#define	c_tvar	c_union.cu_one.co_union.cu_tvar	/* TVAR */
#define	c_tref	c_union.cu_one.cu_cell		/* TVAR */

/* free list */
#define	c_foll	c_union.cu_one.cu_cell

extern	CELL	*new_pair	ARGS((CELL *left, CELL *right));
extern	CELL	*new_susp	ARGS((EXPR *expr, CELL *env));
extern	CELL	*new_cnst	ARGS((CONS *data_constant));
extern	CELL	*new_cons	ARGS((CONS *data_constructor, CELL *arg));
extern	CELL	*new_stream	ARGS((FILE *f));
extern	CELL	*new_num	ARGS((NUM n));
extern	CELL	*new_char	ARGS((natural c));
extern	CELL	*new_dirs	ARGS((PATH path, CELL *val));
extern	CELL	*new_ucase	ARGS((UCASE *code, CELL *env));
extern	CELL	*new_lcase	ARGS((LCASE *lcase, CELL *env));
extern	CELL	*new_tcons	ARGS((DEFTYPE *tcons, CELL *targ));
extern	CELL	*new_tvar	ARGS((TVAR var));

extern	CELL	*evaluate	ARGS((CELL *value));

extern	FUNCTION print_value, write_value;

extern	void	pr_value	ARGS((FILE *f, CELL *value));
extern	void	pr_f_match	ARGS((FUNC *defun, CELL *arg));
extern	void	pr_l_match	ARGS((EXPR *func, CELL *env, CELL *arg));

/* conversions between string representations */
extern	void	hope2c		ARGS((unsigned char *s, int n, CELL *arg));
extern	CELL	*c2hope		ARGS((const unsigned char *s, int n));

extern	FUNCTION open_stream, read_stream;

extern	CELL	*expr_type;	/* type of the current expression */

extern	STRING	cur_function;	/* current built-in function */

extern	void	init_pr_ty_value ARGS((void));
extern	void	pr_ty_value	ARGS((FILE *f, CELL *type));

extern	bool	unify		ARGS((CELL *type1, CELL *type2));
extern	CELL	*deref		ARGS((CELL *type));

/*
 *	The heap of cells
 */
extern	void	start_heap	ARGS((void));
/* required before any calls to new_cell() */
extern	CELL	*new_cell	ARGS((int class));
extern	void	chk_heap	ARGS((CELL *current, int required));
extern	void	heap_stats	ARGS((void));

#endif
