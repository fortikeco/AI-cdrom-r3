#ifndef MODULE_H
#define MODULE_H

#include "newstring.h"

extern	void	mod_init	ARGS((void));
extern	STRING	mod_name	ARGS((void));	/* name of current module */
extern	bool	mod_system	ARGS((void));	/* in a system module? */
extern	void	mod_use		ARGS((STRING name));
extern	void	mod_save	ARGS((STRING name));
extern	void	mod_dump	ARGS((FILE *f));
extern	void	mod_file	ARGS((char *buf, STRING name));
extern	void	mod_fetch	ARGS((void));
extern	void	mod_finish	ARGS((void));
extern	void	private		ARGS((void));
extern	void	display		ARGS((void));

#endif
