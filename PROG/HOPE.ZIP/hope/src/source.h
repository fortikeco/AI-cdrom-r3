#ifndef SOURCE_H
#define SOURCE_H

extern	const	unsigned char	*inptr;

extern	void	init_source	ARGS((void));
extern	void	enterfile	ARGS((FILE *f));
extern	bool	interactive	ARGS((void));
extern	bool	getline		ARGS((void));

#ifdef	RE_EDIT
extern	void	set_script	ARGS((const char *filename));
extern	void	restart		ARGS((const char *script_file));
#endif

#endif
