#include "defs.h"
#include "memory.h"
#include "deftype.h"
#include "error.h"

/*
 *	Defined Types.
 */

global	DEFTYPE	*function, *product;
global	DEFTYPE	*list, *num, *truval, *character;
global	CONS	*nil, *cons, *succ, *true, *false;

/*
 *	The type currently being defined.
 *	(not yet recorded in the tables, in case of error,
 *	except in the case of an abstract type being defined)
 */
local	DEFTYPE	*cur_deftype;		/* type currently being defined */
local	bool	already_defined;	/* current type is already defined */

local	void	check_repeats	ARGS((TYPE *varlist));
local	bool	refers_to	ARGS((DEFTYPE *deftype, TYPE *type));
local	int	ty_length	ARGS((TYPE *typelist));

global void
old_type()
{
	cur_deftype = NULL;
}

global DEFTYPE *
new_deftype(name, vars)
	STRING	name;
	TYPE	*vars;
{
reg	DEFTYPE *ty;

	ty = dt_local(name);
	already_defined = ty != NULL;
	if (already_defined) {
		if (ty->dt_synonym || ty->dt_cons != NULL)
			error(SEMERR, "attempt to redefine type '%s'", name);
		else if (ty_length(vars) != ty_length(ty->dt_varlist))
			error(SEMERR,
				"'%s': variable number of type arguments",
				name);
	}
	else {
		ty = NEW(DEFTYPE);
		ty->dt_name = name;
		ty->dt_synonym = FALSE;
		ty->dt_cons = NULL;
	}
	check_repeats(vars);
	ty->dt_varlist = vars;
	cur_deftype = ty;
	return ty;
}

/*
 *	Check a list of type variables for repetitions.
 */
local void
check_repeats(varlist)
reg	TYPE	*varlist;
{
reg	TYPE	*vp;

	for ( ; varlist != NULL; varlist = varlist->ty_next)
		for (vp = varlist->ty_next; vp != NULL; vp = vp->ty_next)
			if (vp->ty_var == varlist->ty_var) {
				error(SEMERR, "argument '%s' is repeated",
					vp->ty_var);
				return;
			}
}

global void
abstype(deftype)
	DEFTYPE	*deftype;
{
	if (erroneous || already_defined)
		return;
	dt_declare(deftype);
	preserve();
}

global void
type_syn(deftype, type)
	DEFTYPE	*deftype;
	TYPE	*type;
{
	if (erroneous)
		return;
	if (refers_to(deftype, type)) {
		error(SEMERR, "recursive type abbreviation");
		return;
	}
	deftype->dt_synonym = TRUE;
	deftype->dt_type = type;
	if (! already_defined)
		dt_declare(deftype);
	preserve();
}

local bool
refers_to(deftype, type)
reg	DEFTYPE	*deftype;
reg	TYPE	*type;
{
	if (type->ty_variable)
		return FALSE;
	if (type->ty_deftype == deftype)
		return TRUE;
	if (type->ty_deftype->dt_synonym &&
	    refers_to(deftype, type->ty_deftype->dt_type))
		return TRUE;
	for (type = type->ty_firstarg; type != NULL; type = type->ty_next)
		if (refers_to(deftype, type))
			return TRUE;
	return FALSE;
}

global void
decl_type(deftype, conslist)
	DEFTYPE	*deftype;
	CONS	*conslist;
{
reg	CONS	*ct;
reg	TYPE	*result_type;
	natural	index;

	if (erroneous)
		return;
	deftype->dt_cons = conslist;
	result_type = def_type(deftype, deftype->dt_varlist);
	index = 0;
	for (ct = conslist; ct != NULL; ct = ct->c_next) {
		ct->c_type = ct->c_constructor ?
			func_type(ct->c_type, result_type) : result_type;
		ct->c_index = index++;
	}
	if (! already_defined)
		dt_declare(deftype);
	preserve();
}

/*
 *	Lists of constants and constructors.
 */

global CONS *
constant(name)
	STRING	name;
{
reg	CONS	*c;

	c = NEW(CONS);
	c->c_constructor = FALSE;
	c->c_name = name;
	c->c_next = NULL;
	return c;
}

global CONS *
constructor(name, argtype)
	STRING	name;
	TYPE	*argtype;
{
reg	CONS	*c;

	c = NEW(CONS);
	c->c_constructor = TRUE;
	c->c_name = name;
	c->c_type = argtype;
	c->c_next = NULL;
	return c;
}

global CONS *
alt_cons(constr, conslist)
	CONS	*constr, *conslist;
{
	constr->c_next = conslist;
	return constr;
}

/*
 *	Type structures.
 */

global TYPE *
id_type(name)
	STRING	name;
{
reg	TYPE	*tparam;
reg	DEFTYPE	*dt;

	if (cur_deftype != NULL) {
		for (tparam = cur_deftype->dt_varlist;
		     tparam != NULL;
		     tparam = tparam->ty_next)
			if (name == tparam->ty_var)
				return new_tv(tparam->ty_var);
		if (name == cur_deftype->dt_name &&
		    ty_length(cur_deftype->dt_varlist) == 0)
			return def_type(cur_deftype, (TYPE *)0);
	}
	else if (tv_lookup(name))
		return new_tv(name);
	if ((dt = dt_lookup(name)) != NULL &&
	    ty_length(dt->dt_varlist) == 0)
		return def_type(dt, (TYPE *)0);
	error(SEMERR, "'%s' is not a type constant", name);
	return new_tv(alpha);
}

global TYPE *
new_type(name, args)
	STRING	name;
	TYPE	*args;
{
reg	DEFTYPE	*deftype;

	if (cur_deftype != NULL && name == cur_deftype->dt_name)
		deftype = cur_deftype;
	else if ((deftype = dt_lookup(name)) == NULL) {
		error(SEMERR, "'%s' is not a defined type", name);
		deftype = list;		/* dummy */
	}
	if (ty_length(deftype->dt_varlist) != ty_length(args))
		error(SEMERR, "'%s': variable number of type arguments", name);
	return def_type(deftype, args);
}

local int
ty_length(typelist)
reg	TYPE	*typelist;
{
reg	int	len;

	len = 0;
	for ( ; typelist != NULL; typelist = typelist->ty_next)
		len++;
	return len;
}

global TYPE *
def_type(dt, args)
	DEFTYPE	*dt;
	TYPE	*args;
{
reg	TYPE	*type;

	type = NEW(TYPE);
	type->ty_variable = FALSE;
	type->ty_deftype = dt;
	type->ty_firstarg = args;
	type->ty_next = NULL;
	return type;
}

global TYPE *
new_tv(tvar)
	TVAR	tvar;
{
reg	TYPE	*type;

	type = NEW(TYPE);
	type->ty_variable = TRUE;
	type->ty_var = tvar;
	type->ty_next = NULL;
	return type;
}

global TYPE *
cons_type(type, typelist)
	TYPE	*type;
	TYPE	*typelist;
{
	if (type == NULL || typelist == NULL)
		return NULL;
	type->ty_next = typelist;
	return type;
}

global TYPE *
pair_type(type1, type2)
	TYPE	*type1, *type2;
{
	return def_type(product, cons_type(type1, type2));
}

global TYPE *
func_type(type1, type2)
	TYPE	*type1, *type2;
{
	return def_type(function, cons_type(type1, type2));
}
