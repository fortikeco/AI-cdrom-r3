/*
 *	Printing of computed values (fully evaluated)
 */

#include "defs.h"
#include "expr.h"
#include "cell.h"
#include "stack.h"
#include "path.h"
#include "op.h"
#include "print.h"
#include "error.h"

#define	set_env(e)	(chk_stack(1), Push(e))
#define	cur_env()	Top()
#define	clr_env()	Pop_void()

local	void	safe_pr_value	ARGS((FILE *f, CELL *value, int context));
local	void	real_pr_value	ARGS((FILE *f, CELL *value, int context));
local	void	pr_vlist	ARGS((FILE *f, CELL *value));
local	CELL	*get_actual	ARGS((int level, PATH path));
local	void	safe_pr_f_value
	ARGS((FILE *f, STRING name, CELL *arg, int context));
local	void	pr_f_value
	ARGS((FILE *f, STRING name, CELL *arg, int context));
local	int	prec_value	ARGS((CELL *value));

global void
pr_value(f, value)
	FILE	*f;
	CELL	*value;
{
	safe_pr_value(f, value, PREC_BODY);
}

global void
pr_f_match(defun, arg)
	FUNC	*defun;
	CELL	*arg;
{
	chk_stack(1);
	Push(arg);

	start_err_line();
	pr_f_value(errout, defun->f_name, arg, PREC_BODY);
	(void)fprintf(errout, "\n");

	Pop_void();
}

global void
pr_l_match(func, env, arg)
	EXPR	*func;
	CELL	*env, *arg;
{
	chk_stack(1);
	Push(arg);

	start_err_line();
	if (func->e_class == E_EQN) {
		pr_c_expr(errout, func->e_branch->br_pattern, 0, PREC_BODY);
		(void)fprintf(errout, " == ");
		pr_value(errout, arg);
	}
	else {	/* LAMBDA */
		set_env(env);
		pr_c_expr(errout, func, 0, PREC_APPLY);
		clr_env();
		(void)fprintf(errout, " ");
		safe_pr_value(errout, arg, PREC_ARG);
	}
	(void)fprintf(errout, "\n");

	Pop_void();
}

/*
 *	Print a value.
 *	The value is first pushed on the stack, so that it isn't treated
 *	as garbage.
 */
local void
safe_pr_value(f, value, context)
	FILE	*f;
	CELL	*value;
	int	context;
{
	chk_stack(1);
	Push(value);
	real_pr_value(f, value, context);
	Pop_void();
}

local void
real_pr_value(f, value, context)
reg	FILE	*f;
reg	CELL	*value;
	int	context;
{
	int	prec;

	prec = prec_value(value);
	if (prec < context)
		(void)fprintf(f, "(");
	switch (value->c_class) {
	when C_NUM:
		(void)fprintf(f, NUMfmt, value->c_num);
	when C_CHAR:
		(void)fprintf(f, "'");
		pr_char(f, value->c_char);
		(void)fprintf(f, "'");
	when C_CONST:
		(void)fprintf(f, "%s", value->c_cons->c_name);
	when C_CONS:
		if (value->c_cons == cons)
			pr_vlist(f, value);
		else
			pr_f_value(f, value->c_cons->c_name,
				value->c_arg, InnerPrec(prec, context));
	when C_PAIR:
		real_pr_value(f, value->c_left, PREC_COMMA+1);
		(void)fprintf(f, ", ");
		real_pr_value(f, value->c_right, PREC_COMMA);
	when C_SUSP:
		set_env(value->c_env);
		pr_c_expr(f, value->c_expr, 0, InnerPrec(prec, context));
		clr_env();
	otherwise:
		error(INTERR, "illegal cell class %d (pr_value)",
			value->c_class);
	}
	if (prec < context)
		(void)fprintf(f, ")");
}

/*
 * Print the value, which has been forced, and is known to be a list.
 */
local void
pr_vlist(f, value)
reg	FILE	*f;
reg	CELL	*value;
{
	if (value->c_arg->c_left->c_class == C_CHAR) {
		/* if one is a char, they all must be (from type checking) */
		(void)fprintf(f, "\"");
		for ( ; value->c_class == C_CONS;
		     value = value->c_arg->c_right)
			pr_char(f, value->c_arg->c_left->c_char);
		(void)fprintf(f, "\"");
	}
	else {
		(void)fprintf(f, "[");
		repeat {
			real_pr_value(f, value->c_arg->c_left, PREC_COMMA+1);
			value = value->c_arg->c_right;
		until(value->c_class == C_CONST);
			(void)fprintf(f, ", ");
		}
		(void)fprintf(f, "]");
	}
}

local CELL *
get_actual(level, path)
reg	int	level;
	PATH	path;
{
reg	CELL	*env;

	env = cur_env();
	while (level-- > 0)
		env = env->c_right;
	return evaluate(new_dirs(path, env->c_left));
}

/*
 *	Print actual parameter, taking its value from the environment.
 */
global void
pr_actual(f, level, path, context)
	FILE	*f;
	int	level;
	PATH	path;
	int	context;
{
	safe_pr_value(f, get_actual(level, path), context);
}

global void
pr_f_actual(f, name, level, path, context)
	FILE	*f;
	STRING	name;
	int	level;
	PATH	path;
	int	context;
{
	safe_pr_f_value(f, name, get_actual(level, path), context);
}

local void
safe_pr_f_value(f, name, arg, context)
	FILE	*f;
	STRING	name;
	CELL	*arg;
	int	context;
{
	chk_stack(1);
	Push(arg);
	pr_f_value(f, name, arg, context);
	Pop_void();
}

local void
pr_f_value(f, name, arg, context)
	FILE	*f;
	STRING	name;
	CELL	*arg;
	int	context;
{
	OP	*op;

	if ((op = op_lookup(name)) != NULL)
		if (arg->c_class == C_PAIR) {
			if (op->op_prec < context)
				(void)fprintf(f, "(");
			real_pr_value(f, arg->c_left, LeftPrec(op));
			(void)fprintf(f, " %s ", name);
			real_pr_value(f, arg->c_right, RightPrec(op));
			if (op->op_prec < context)
				(void)fprintf(f, ")");
		}
		else {
			(void)fprintf(f, "(%s) ", name);
			real_pr_value(f, arg, PREC_ARG);
		}
	else {
		(void)fprintf(f, "%s ", name);
		real_pr_value(f, arg, PREC_ARG);
	}
}

global STRING
val_name(level, path)
	int	level;
	PATH	path;
{
reg	CELL	*value;

	value = get_actual(level, path);
	if (value->c_class == C_SUSP)
		switch (value->c_expr->e_class) {
		when E_CONS:
			return value->c_expr->e_const->c_name;
		when E_DEFUN:
			return value->c_expr->e_defun->f_name;
		}
	return NULL;
}

local int
prec_value(value)
	CELL	*value;
{
	switch (value->c_class) {
	when C_CONS:
		return PREC_APPLY;
	when C_PAIR:
		return PREC_COMMA;
	}
	/* otherwise: */
	return PREC_ATOMIC;
}
