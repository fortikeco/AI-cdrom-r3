#include "defs.h"
#include "expr.h"
#include "error.h"
#include "path.h"

/*
 *	Resolve identifiers.
 */

local	bool	nv_branch	ARGS((BRANCH *br));
local	bool	nv_rec_eqn	ARGS((BRANCH *br, EXPR *arg));
local	bool	nv_pattern	ARGS((EXPR *p, PATH path));
local	bool	nv_expr		ARGS((EXPR *e));
local	bool	nv_var		ARGS((EXPR *e));

/*
 *	Management of variable scopes
 */
local	EXPR	*varlist[MAX_VARIABLES];
local	EXPR	**next_var;

local	EXPR	**scope[MAX_SCOPES];
local	EXPR	***ref_level;

local	void	init_scopes	ARGS((void));
local	bool	enter_scope	ARGS((BRANCH *br));
local	void	leave_scope	ARGS((void));

global bool
nr_branch(br)
	BRANCH	*br;
{
	init_scopes();
	return nv_branch(br);
}

global bool
nr_expr(expr)
	EXPR	*expr;
{
	init_scopes();
	return nv_expr(expr);
}

local void
init_scopes()
{
	ref_level = scope;
	scope[0] = next_var = varlist;
}

local bool
enter_scope(br)
	BRANCH	*br;
{
	if (! nv_pattern(br->br_pattern, p_new()))
		return FALSE;
	br->br_nvars = next_var - *ref_level;
	if (ref_level == &scope[MAX_SCOPES-1]) {
		error(SEMERR, "too many nested lambdas/lets/wheres");
		return FALSE;
	}
	*++ref_level = next_var;
	return TRUE;
}

local void
leave_scope()
{
	next_var = *--ref_level;
}

local bool
nv_branch(br)
reg	BRANCH	*br;
{
	if (! enter_scope(br))
		return FALSE;
	if (! nv_expr(br->br_expr))
		return FALSE;
	leave_scope();
	return TRUE;
}

local bool
nv_rec_eqn(br, arg)
reg	BRANCH	*br;
reg	EXPR	*arg;
{
	if (! enter_scope(br))
		return FALSE;
	if (! nv_expr(br->br_expr) || ! nv_expr(arg))
		return FALSE;
	leave_scope();
	return TRUE;
}

local bool
nv_pattern(p, path)
reg	EXPR	*p;
	PATH	path;
{
reg	EXPR	**vp;
reg	int	i;

	if (p == NULL)		/* error in apply_pat() */
		return FALSE;
	switch (p->e_class) {
	when E_PAIR:
		return nv_pattern(p->e_left, p_push(P_LEFT, path)) &&
			nv_pattern(p->e_right, p_push(P_RIGHT, path));
	when E_APPLY:
		ASSERT( p->e_func->e_class == E_CONS );
		return nv_pattern(p->e_arg,
			p_push(p->e_func->e_const == succ ? P_PRED : P_STRIP,
			       path));
	when E_PLUS:
		for (i = 0; i < p->e_incr; i++)
			path = p_push(P_PRED, path);
		return nv_pattern(p->e_rest, path);
	when E_VAR:
		if (p->e_vname != newstring("_"))
			for (vp = *ref_level; vp != next_var; vp++)
				if ((*vp)->e_vname == p->e_vname) {
					error(SEMERR,
						"%s: occurs twice in pattern",
						p->e_vname);
					return FALSE;
				}
		p->e_var = next_var - *ref_level;
		p->e_dirs = p_stash(p_reverse(path));
		if (next_var == &varlist[MAX_VARIABLES-1]) {
			error(SEMERR, "too many variables in patterns");
			return FALSE;
		}
		*next_var++ = p;
		return TRUE;
	}
	return TRUE;
}

local bool
nv_expr(e)
reg	EXPR	*e;
{
reg	BRANCH	*br;

	switch (e->e_class) {
	when E_PAIR:
		return nv_expr(e->e_left) && nv_expr(e->e_right);
	when E_APPLY or E_IF or E_WHERE or E_LET:
		return nv_expr(e->e_func) && nv_expr(e->e_arg);
	when E_RLET or E_RWHERE:
		return nv_rec_eqn(e->e_func->e_branch, e->e_arg);
	when E_LAMBDA or E_EQN or E_THEN or E_PRESECT or E_POSTSECT:
		for (br = e->e_branch; br != NULL; br = br->br_next)
			if (! nv_branch(br))
				return FALSE;
		return TRUE;
	when E_VAR:
		return nv_var(e);
	}
	return TRUE;
}

local bool
nv_var(e)
reg	EXPR	*e;
{
reg	STRING	name;
reg	EXPR	**vp;
reg	EXPR	***def_level;

	name = e->e_vname;
	ASSERT( next_var == *ref_level );
	for (vp = next_var-1; vp >= varlist; vp--)
		if ((*vp)->e_vname == name) {
			e->e_class = E_PARAM;
			e->e_patt = *vp;
			for (def_level = scope; *def_level <= vp; def_level++)
				;
			e->e_level = ref_level - def_level;
			e->e_where = (*vp)->e_dirs;
			return TRUE;
		}
	/* fiddle: succ constructor becomes succ function */
	if ((e->e_const = cons_lookup(name)) != NULL && e->e_const != succ) {
		e->e_class = e->e_const->c_constructor ? E_CONS : E_CONST;
		return TRUE;
	}
	if ((e->e_defun = fn_lookup(name)) != NULL) {
		e->e_class = E_DEFUN;
		return TRUE;
	}
	error(SEMERR, "%s: undefined variable", name);
	return FALSE;
}
