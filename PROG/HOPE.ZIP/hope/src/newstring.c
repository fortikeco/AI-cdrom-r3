#include "defs.h"
#include "memory.h"
#include "newstring.h"
#include "align.h"

#define TABSIZ	293		/* should be prime */

typedef	struct _IDENT	IDENT;
struct _IDENT {
	IDENT	*link;
	char	text[ALIGNMENT];	/* stub for size purposes */
};
#define	SizeIDENT(n)	(sizeof(IDENT) - ALIGNMENT + 1 + (n))

local	IDENT	*table[TABSIZ];
local	natural	hash	ARGS((const unsigned char *s, int n));

global void
init_strings()
{
reg	IDENT	**tp;

	for (tp = table; tp != &table[TABSIZ]; tp++)
		*tp = NULL;
}

global STRING
newstring(s)
	const	char	*s;
{
	return newnstring(s, strlen(s));
}

global STRING
newnstring(s, n)
reg	const	char	*s;
	int	n;
{
reg	IDENT	*np, **p;

	p = &table[hash((const unsigned char *)s, n)];
	for (np = *p; np != NULL; np = np->link)
		if (strncmp(np->text, s, n) == 0 && np->text[n] == '\0')
			return np->text;
	np = (IDENT *)s_alloc((natural)SizeIDENT(n));
	np->link = *p;
	*p = np;
	np->text[n] = '\0';
	return strncpy(np->text, s, n);
}

#define	A 17
#define	B 89
#define	C 167

local natural
hash(s, n)
reg	const	unsigned char	*s;
reg	int	n;
{
	return n <= 0 ? 0 :
		(natural)(n + A*s[0] + B*s[n/2] + C*s[n-1])%TABSIZ;
}
