#include "defs.h"
#include "deftype.h"
#include "cell.h"

#define	MAX_INSTANTIATIONS	40	/* just that (not checked) */

local	bool	real_unify	ARGS((CELL *type1, CELL *type2));
local	bool	assign		ARGS((CELL *var, CELL *type));
local	bool	occurs		ARGS((CELL *var, CELL *type));

/* stack of pointers changed from NOCELL by the current unification */
local	CELL	***top_trail;

/*
 *	Unification of type terms.
 *	Proceeds by direct modification of uninstantiated variables.
 *	It prefers to instantiate variables in the first term.
 *	If the unification is unsuccessful, nothing is changed.
 */
global bool
unify(type1, type2)
	CELL	*type1, *type2;
{
	CELL	**trail[MAX_INSTANTIATIONS];

	top_trail = trail;
	if (real_unify(type1, type2))
		return TRUE;
	while (top_trail > trail)
		**--top_trail = NOCELL;
	return FALSE;
}

local bool
real_unify(type1, type2)
reg	CELL	*type1, *type2;
{
	repeat {
		type1 = deref(type1);
		type2 = deref(type2);
		if (type1->c_class == C_TVAR)
			return assign(type1, type2);
		if (type2->c_class == C_TVAR)
			return assign(type2, type1);
		/* both are constructed types */
		if (type1->c_tcons != type2->c_tcons)
			return FALSE;
		/* same constructor => same no. of arguments */
		if (type1->c_targ == NOCELL)
			return TRUE;
		for (type1 = type1->c_targ, type2 = type2->c_targ;
		     type1->c_class == C_PAIR;
		     type1 = type1->c_right, type2 = type2->c_right)
			if (! real_unify(type1->c_left, type2->c_left))
				return FALSE;
		/* return real_unify(type1, type2); */
	}
}

/*
 *	Assign a term to a cell, after performing the occurs check.
 *	var is an uninstantiated variable,
 *	type has already been dereferenced.
 */
local bool
assign(var, type)
reg	CELL	*var;
reg	CELL	*type;
{
	if (type != var) {	/* action required */
		if (occurs(var, type))
			return FALSE;
		var->c_tref = type;
		*top_trail++ = &(var->c_tref);
	}
	return TRUE;
}

/*
 *	Occur check -- does the variable occur in the term?
 *	The term has already been dereferenced.
 */
local bool
occurs(var, type)
reg	CELL	*var;
reg	CELL	*type;
{
	repeat {
		if (type->c_class == C_TVAR)	/* uninstantiated variable */
			return type == var;
		if (type->c_targ == NOCELL)
			return FALSE;
		for (type = type->c_targ;
		     type->c_class == C_PAIR;
		     type = type->c_right)
			if (occurs(var, deref(type->c_left)))
				return TRUE;
		/* return occurs(var, deref(type)); */
		type = deref(type);
	}
}

/*
 *	Follow a chain of instantiated variables to either a constructor or
 *	an uninstantiated variable.
 */
global CELL *
deref(cell)
reg	CELL	*cell;
{
	while (cell->c_class == C_TVAR && cell->c_tref != NOCELL)
		cell = cell->c_tref;
	return cell;
}
