#ifndef DEFTYPE_H
#define DEFTYPE_H

#include "newstring.h"
#include "table.h"
#include "typevar.h"

typedef	struct _CONS	CONS;
typedef	struct _DEFTYPE	DEFTYPE;
typedef	struct _TYPE	TYPE;

struct _CONS {
	STRING	c_name;
	TYPE	*c_type;
	sbool	c_constructor;
	unsigned char	c_index;
	CONS	*c_next;
};

extern	CONS	*constant	ARGS((STRING name));
extern	CONS	*constructor	ARGS((STRING name, TYPE *argtype));
extern	CONS	*alt_cons	ARGS((CONS *constr, CONS *conslist));
extern	CONS	*cons_lookup	ARGS((STRING name));

/*
 *	Defined types.
 */
struct _DEFTYPE {
	TAB_ELT	dt_linkage;
	sbool	dt_synonym;	/* type is a synonym */
	sbool	dt_private;	/* definition of type is private */
	TYPE	*dt_varlist;
	union {
		CONS	*dtu_cons;	/* list of constants and constructors */
		TYPE	*dtu_type;	/* synonymous type */
	} dt_union;
};
#define	dt_name	dt_linkage.t_name
#define	dt_cons	dt_union.dtu_cons
#define	dt_type	dt_union.dtu_type

extern	void	dt_declare	ARGS((DEFTYPE *dt));
extern	DEFTYPE	*dt_lookup	ARGS((STRING name));
extern	DEFTYPE	*dt_local	ARGS((STRING name));

extern	void	old_type	ARGS((void));
extern	DEFTYPE	*new_deftype	ARGS((STRING name, TYPE *vars));

extern	void	abstype		ARGS((DEFTYPE *deftype));
extern	void	type_syn	ARGS((DEFTYPE *deftype, TYPE *type));
extern	void	decl_type	ARGS((DEFTYPE *deftype, CONS *conslist));

extern	void	pr_deftype	ARGS((FILE *f, DEFTYPE *dt, bool full));

extern	TVAR	alpha;
extern	DEFTYPE	*product, *function, *list, *num, *truval, *character;
extern	CONS	*nil, *cons, *succ, *true, *false;

struct _TYPE {
	sbool	ty_variable;	/* is a variable, not a constructor */
	union {
		TVAR	tyu_var;
		struct {
			DEFTYPE	*tyu_deftype;
			TYPE	*tyu_firstarg;
		} tyu_def;
	} ty_union;
	TYPE	*ty_next;	/* next argument of defined type */
};
#define	ty_var		ty_union.tyu_var
#define	ty_deftype	ty_union.tyu_def.tyu_deftype
#define	ty_firstarg	ty_union.tyu_def.tyu_firstarg
#define	ty_secondarg	ty_firstarg->ty_next

extern	TYPE	*id_type	ARGS((STRING name));
extern	TYPE	*new_type	ARGS((STRING name, TYPE *args));
extern	TYPE	*def_type	ARGS((DEFTYPE *dt, TYPE *args));
extern	TYPE	*new_tv		ARGS((TVAR tvar));
extern	TYPE	*cons_type	ARGS((TYPE *type, TYPE *typelist));
extern	TYPE	*pair_type	ARGS((TYPE *type1, TYPE *type2));
extern	TYPE	*func_type	ARGS((TYPE *type1, TYPE *type2));

extern	void	pr_type		ARGS((FILE *f, TYPE *type));

#endif
