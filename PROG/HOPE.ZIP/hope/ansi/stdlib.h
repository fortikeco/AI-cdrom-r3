#ifndef	MY_STDLIB_H
#define	MY_STDLIB_H

#include <sys/types.h>

extern	int	fprintf(FILE *f, const char *fmt, ...);
extern	int	sprintf(char *s, const char *fmt, ...);
extern	int	fclose(FILE *f);
extern	int	fflush(FILE *f);
extern	int	_filbuf(FILE *f);
extern	int	_flsbuf(FILE *f);

extern	int	abort(void);
extern	int	exit(int status);
extern	int	rename(const char *path1, const char *path2);
extern	int	remove(const char *path);
extern	void	*malloc(size_t size);

#endif
