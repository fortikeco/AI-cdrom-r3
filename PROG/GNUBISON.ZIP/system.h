#if defined(MSDOS) || defined(OS2)
#include <stdlib.h>
#include <io.h>
#endif /* MSDOS */

#if defined(USG) || defined(VMS)
#include <string.h>
#else /* not USG */
#if defined(MSDOS) || defined(OS2)
#include <string.h>
#else
#include <strings.h>
#endif /* not MSDOS */
#endif /* not USG */
