#include <stream.h>
#include <String.h>

String s1 = "Hello";
String s2 = " world!\n";

main()
{
	cout << s1 << s2 ;
}
