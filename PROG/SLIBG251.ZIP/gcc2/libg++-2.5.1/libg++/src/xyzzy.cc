#ifndef NO_GNULIB3
// from tiemann

/* Needed, in case there are no other objects which
   need static initialization and cleanup.  */
struct __xyzzy__
{
  __xyzzy__ () {}
  ~__xyzzy__ () {}
} __1xyzzy__;

#endif
