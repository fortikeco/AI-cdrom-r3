#include "libioP.h"
#include "stdio.h"

int ferror(FILE* fp)
{
  COERCE_FILE(fp);
  return _IO_ferror(fp);
}
