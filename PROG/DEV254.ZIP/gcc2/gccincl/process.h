#define P_WAIT 0
#define P_NOWAIT 1
int spawnl (int modeflag, const char *path, const char *arg0, ...);
int spawnle (int modeflag, const char *path, const char *arg0, ...);
int spawnlp (int modeflag, const char *path, const char *arg0, ...);
int spawnlpe (int modeflag, const char *path, const char *arg0, ...);
int spawnv (int modeflag, const char *path, const char * const *argv);
int spawnve (int modeflag, const char *path, const char * const *argv, 
	     const char * const *envp);
int spawnvp (int modeflag, const char *path, const char * const *argv);
int spawnvpe (int modeflag, const char *path, const char * const *argv, 
	      const char * const *envp);

/* The above functions all call this internal function */
#define _SPAWN_SEARCH_PATH 1
#define _SPAWN_NO_SEARCH_PATH 0
int _spawn (int modeflag, int p, const char *path, const char * const *argv,
	    const char * const *envp);
