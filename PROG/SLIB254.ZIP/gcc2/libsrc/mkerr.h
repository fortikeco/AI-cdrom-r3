#include <errno.h>

#define reterr(nerrno) return errno = nerrno, -1
