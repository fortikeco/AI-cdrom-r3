void *__CTOR_LIST__[3] = {0, 0, 0};
void *__DTOR_LIST__[3] = {0, 0, 0};

