#include <sys/time.h>
#include <sys/resource.h>

int setrlimit (int resource, const struct rlimit *rlp)
{
   return (0);
}


