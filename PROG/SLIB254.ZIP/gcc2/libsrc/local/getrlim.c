#include <sys/time.h>
#include <sys/resource.h>

int getrlimit (int resource, struct rlimit *rlp)
{
   return (0);
}

