#include <unistd.h>

char * getlogin(void)
{
   return (0);
}

