#define INCL_DOSFILEMGR
#include <os2.h>

#define __DIRENT_PRIVATE__
#include <dirent.h>

void rewinddir(dir)
   DIR *dir;
{
     dir->reset = 1;
}
