#define INCL_DOSPROCESS
#include <os2.h>

int usleep (unsigned int useconds)
{
   DosSleep ((useconds / 1000) + 1);
   return (0);
}

