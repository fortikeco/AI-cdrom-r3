#define INCL_DOSFILEMGR
#define INCL_DOSERRORS
#include <os2.h>
#include <errno.h>

ULONG Dos32DupHandle() asm ("Dos32DupHandle");
ULONG Dos32Close() asm ("Dos32Close");

extern int *__textio;

int dup2 (int oldd, int newd)
{
   int newdesc = newd;
   ULONG rc;

   rc = Dos32DupHandle (oldd, (PHFILE)&newd);

   if (rc)
      if (rc == ERROR_TOO_MANY_OPEN_FILES)
      {
         errno = EMFILE;
         return (-1);
      }
      else
      {
         errno = EBADF;
         return (-1);
      }

   __textio[newd] = __textio[oldd];

   return (newdesc);
}
