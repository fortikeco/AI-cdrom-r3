#define INCL_DOSFILEMGR
#include <os2.h>
#include <unistd.h>

int access (const char *path, int mode)
{
   FILESTATUS fs;
   ULONG rc;

   rc = DosQueryPathInfo ((PSZ)path, 1, (PBYTE)&fs, sizeof (FILESTATUS));

   if (rc)
      return (-1);

   return (0);
}

