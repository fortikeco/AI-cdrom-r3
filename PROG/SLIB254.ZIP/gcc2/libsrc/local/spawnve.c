#include <process.h>

int spawnve (int modeflag, const char *path, const char * const *argv, 
	     const char * const *envp)
{
  return _spawn (modeflag, _SPAWN_NO_SEARCH_PATH, path, 
		 (const char * const *) argv, (const char * const *) envp);
}
