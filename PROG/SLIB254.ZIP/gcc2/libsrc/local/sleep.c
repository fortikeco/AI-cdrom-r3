#define INCL_DOSPROCESS
#include <os2.h>

int sleep (unsigned int seconds)
{
   DosSleep (seconds * 1000);
   return (0);
}

