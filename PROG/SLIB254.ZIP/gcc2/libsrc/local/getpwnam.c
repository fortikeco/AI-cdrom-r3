void *
getpwnam()
{
   return (0);
}

