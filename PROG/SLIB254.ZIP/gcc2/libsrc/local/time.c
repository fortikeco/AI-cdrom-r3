#define INCL_DOSMISC
#include <os2.h>
#include <stdio.h>

int time (long *tbuf)
{
   long buf;

   DosQuerySysInfo (QSV_TIME_LOW, QSV_TIME_LOW, (PBYTE)&buf, 4);

   if (tbuf)
     *tbuf = buf;

   return (buf);
}

