#define INCL_DOSFILEMGR
#define INCL_DOSMISC
#define INCL_DOSPROCESS
#define INCL_DOSERRORS
#include <os2.h>
#include <errno.h>
#include <process.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

extern int __vfork_active;
extern int __vfork_result;
extern int __vfork_tid;

int execlp (const char *path, const char *arg0, ...)
{
   ULONG rc;
   int total_length;
   char *arg_strings;
   char *ptr;
   RESULTCODES ReturnCodes;
   char ObjNameBuf[512];
   char exe_name[512];
   char **argptr;
   char base_name[512];
   PTIB ptib;
   PPIB ppib;

   if (__vfork_active) {
      DosGetInfoBlocks (&ptib, &ppib);
      if (__vfork_tid != ptib -> tib_ptib2 -> tib2_ultid) {
         errno = EPERM;
         return (-1);
      }
   } else {
      errno = EPERM;
      return (-1);
   }


   /* Try to find the .EXE file */

   strcpy (base_name, path);

   if (strchr(base_name, '\\') || strchr(base_name, ':')) {
       /* Path is provided - use it! */
       if (!access(base_name, X_OK) == -1) {
	   strcat(base_name, ".EXE");
       }
       strcpy(exe_name, base_name);
   } else {
       /* Path not provided - search the PATH environment */
       rc = DosSearchPath (SEARCH_ENVIRONMENT | SEARCH_CUR_DIRECTORY,
			   (PSZ) "PATH",
			   (PSZ) base_name,
			   (PBYTE) exe_name,
			   512);

       if (rc)
       {
	   /* Not found.  Append .exe and try again. */
	   strcat (base_name, ".EXE");
	   
	   rc = DosSearchPath (SEARCH_ENVIRONMENT | SEARCH_CUR_DIRECTORY,
			       (PSZ) "PATH",
			       (PSZ) base_name,
			       (PBYTE) exe_name,
			       512);

	   if (rc)
	   {
	       if (rc == ERROR_FILE_NOT_FOUND || rc == ERROR_PATH_NOT_FOUND)
	       {
		   errno = ENOENT;
		   return (-1);
	       }

	       errno = EIO;
	       return (-1);
	   }
       }
   }

   /* construct the command args for DosExecPgm */

   for (argptr = (char **)&arg0, total_length = 1; *argptr; ++argptr)
      total_length += strlen (*argptr) + 1;

   arg_strings = (char *)malloc (total_length);

   for (argptr = (char **)&arg0, ptr = arg_strings; *argptr; ++argptr)
   {
      bcopy (*argptr, ptr, strlen (*argptr)+1);
      ptr += strlen (*argptr);
      if (argptr == (char **)&arg0)
         ptr++;
      else
         *ptr++ = ' ';
   }

   *ptr = '\0';

   rc = DosExecPgm (&ObjNameBuf[0],
                    512,
                    EXEC_ASYNCRESULT,
                    arg_strings,
                    NULL,
                    &ReturnCodes,
                    exe_name);

   if (rc)
   {
      if (rc == ERROR_FILE_NOT_FOUND || rc == ERROR_PATH_NOT_FOUND)
      {
         errno = ENOENT;
         return (-1);
      }

      errno = EIO;
      return (-1);
   }

   __vfork_result = ReturnCodes.codeTerminate;
   __vfork_active = 0;
   DosExit (EXIT_THREAD, ReturnCodes.codeTerminate);
   return (-1); /* for lint */
}

