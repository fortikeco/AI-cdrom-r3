int getpagesize()
{
   return (4096);
}

