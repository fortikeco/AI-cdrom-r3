#include <process.h>

int spawnvp (int modeflag, const char *path, const char * const *argv)
{
  return _spawn (modeflag, _SPAWN_SEARCH_PATH, path, 
		 (const char * const *) argv, 0);
}
