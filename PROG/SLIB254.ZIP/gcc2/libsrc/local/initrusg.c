#define INCL_DOSMISC
#define INCL_DOSDATETIME
#include <os2.h>

#include <sys/time.h>
#include <sys/resource.h>

struct rusage _rusage;
DATETIME _startup_time;

ULONG Dos32GetDateTime() asm ("Dos32GetDateTime");

void _init_rusage()
{
   Dos32GetDateTime (&_startup_time);

   _rusage.ru_utime.tv_sec = 0;
   _rusage.ru_utime.tv_usec = 0;
   _rusage.ru_stime.tv_sec = 0;
   _rusage.ru_stime.tv_usec = 0;
   _rusage.ru_maxrss = RLIM_INFINITY;
   _rusage.ru_ixrss = RLIM_INFINITY;
   _rusage.ru_idrss = RLIM_INFINITY;
   _rusage.ru_isrss = RLIM_INFINITY;
   _rusage.ru_minflt = 0;
   _rusage.ru_majflt = 0;
   _rusage.ru_nswap = 0;
   _rusage.ru_inblock = 0;
   _rusage.ru_oublock = 0;
   _rusage.ru_msgsnd = 0;
   _rusage.ru_msgrcv = 0;
   _rusage.ru_nsignals = 0;
   _rusage.ru_nvcsw = 0;
   _rusage.ru_nivcsw = 0;
}

