#define INCL_DOSEXCEPTIONS
#include <os2.h>
#include <stdio.h>

extern int _argc;
extern char **_argv;
extern char **_envp;
extern int main();
extern void _dynamic_crt1(char *command_line, int (*main)());

void crt1(char *command_line)
{
   /* Let some dynamically linked code handle as much as possible */
   _dynamic_crt1(command_line, main);
}
