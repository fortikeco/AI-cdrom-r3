#define INCL_DOSFILEMGR
#include <os2.h>
#include <errno.h>
#include <stdlib.h>

char *getcwd (char *buf, int size)
{
   char *tbuf = buf;
   unsigned long tsize = size;
   ULONG rc;

   if (tbuf == NULL)
   {
      tbuf = (char *) malloc (2048);
      tsize = 2047;
   }

   tbuf[0] = '\\';
   rc = DosQueryCurrentDir (0, tbuf + 1, &tsize);

   if (rc)
   {
      errno = EIO;
      return (NULL);
   }

   return (tbuf);
}

