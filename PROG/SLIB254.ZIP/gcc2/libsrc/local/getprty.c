#define INCL_DOSPROCESS
#include <os2.h>

int getpriority (int which, int who)
{
   PTIB tib;
   PPIB pib;

   DosGetInfoBlocks (&tib, &pib);

   if (who == 0 || who == pib -> pib_ulpid) {
      return (tib -> tib_ptib2 -> tib2_ulpri);
   }

   return (0);
}

