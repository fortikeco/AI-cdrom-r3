#include <signal.h>

extern int __signal_mask;

int sigblock (int mask)
{
   int old_mask = __signal_mask;

   __signal_mask |= mask & 0xFFFAFEFF;

   return (old_mask);
}

