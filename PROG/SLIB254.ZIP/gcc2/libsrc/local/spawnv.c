#include <process.h>

int spawnv (int modeflag, const char *path, const char * const *argv)
{
  return _spawn (modeflag, _SPAWN_NO_SEARCH_PATH, path, 
		 (const char * const *) argv, 0);
}
