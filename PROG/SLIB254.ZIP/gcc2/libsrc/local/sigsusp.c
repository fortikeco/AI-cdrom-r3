#include <sys/signal.h>
#include <errno.h>

int sigsuspend (const sigset_t *sigmask)
{
   errno = EINTR;
   return (-1);
}

