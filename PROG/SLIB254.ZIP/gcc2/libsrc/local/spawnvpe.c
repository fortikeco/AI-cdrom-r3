#include <process.h>

int spawnvpe (int modeflag, const char *path, const char * const *argv, 
	      const char * const *envp)
{
  return _spawn (modeflag, _SPAWN_SEARCH_PATH, path, 
		 (const char * const *) argv, (const char * const *) envp);
}
