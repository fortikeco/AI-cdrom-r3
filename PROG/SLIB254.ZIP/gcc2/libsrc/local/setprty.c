#define INCL_DOSPROCESS
#include <os2.h>
#include <errno.h>

int setpriority (int which, int who, int prio)
{
   unsigned long rc;

   if (prio > 31) prio = 31;
   else if (prio < -31) prio = -31;

   rc = DosSetPriority (0, 2, prio, who);

   if (rc) {
      errno = EINVAL;
      return (-1);
   }

   return (0);
}

