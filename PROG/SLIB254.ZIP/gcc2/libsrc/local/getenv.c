#include <string.h>

extern char **environ;

char *getenv (const char *name)
{
  const int len = strlen(name);
  int i;
  for (i=0; environ[i] != 0; i++)
    if (environ[i][len] == '='
	&& !memcmp(name, environ[i], len))
      return environ[i] + len + 1;
  return 0;
}
