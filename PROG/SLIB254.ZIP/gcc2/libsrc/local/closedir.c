#define INCL_DOSFILEMGR
#include <os2.h>

#define __DIRENT_PRIVATE__
#include <stdlib.h>
#include <errno.h>
#include <dirent.h>

int closedir(dir)
   DIR *dir;
{
     ULONG ret;

     /* This function frees allocated memory even if it is going to */
     /* return an error code (e.g.: if DosFindClose fails).  If a */
     /* program tries to correct the problem and call closedir() */
     /* again, a memory error will result.  What is the correct */
     /* behavior? */

     ret = DosFindClose(dir->dirhandle);
     free(dir->searchname);
     free(dir);
     if (ret != 0) {
	  errno = EBADF;
	  return -1;
     } else
	  return 0;
}

     
