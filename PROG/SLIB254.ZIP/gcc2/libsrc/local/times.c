#include <sys/types.h>
#include <sys/times.h>


clock_t	times (struct tms *ttt)
{
   return (0);
}

