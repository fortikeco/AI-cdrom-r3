#define INCL_DOSFILEMGR
#include <os2.h>

char *getwd (char pathname[])
{
   ULONG count = 2048;
   ULONG rc;

   rc = DosQueryCurrentDir (0, (PBYTE)&pathname[0], &count);

   if (rc)
      return (NULL);

   return (&pathname[0]);
}


