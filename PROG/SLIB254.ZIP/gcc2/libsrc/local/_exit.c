#define INCL_DOSPROCESS
#include <os2.h>

extern TID __vfork_tid;
extern TID __vfork_result;
extern int __vfork_active;

volatile void _exit (int status)
{
   PTIB ptib;
   PPIB ppib;

   if (__vfork_active) {
      DosGetInfoBlocks (&ptib, &ppib);
      if (__vfork_tid == ptib -> tib_ptib2 -> tib2_ultid) {
         __vfork_result = status;
         __vfork_active = 0;
         DosExit (EXIT_THREAD, status);
      }
   }

   DosExit (EXIT_PROCESS, status);
}

