#define INCL_DOSFILEMGR
#include <os2.h>

int isatty (int handle)
{
   ULONG handtype;
   ULONG flagword;
   ULONG rc;

   rc = DosQueryHType (handle, &handtype, &flagword);

   if (rc) return (0);

   if ((handtype & 0xff) == 1)
      return (1);

   return (0);
}

