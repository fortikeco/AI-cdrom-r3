int getdtablesize(void)
{
   return (20);
}

