#define INCL_DOSQUEUES
#define INCL_DOSERRORS
#include <os2.h>
#include <errno.h>

int pipe (int *fildes)
{
   ULONG rc;
   HFILE ReadHandle;
   HFILE WriteHandle;

   rc = DosCreatePipe (&ReadHandle, &WriteHandle, 0);

   if (rc == ERROR_NOT_ENOUGH_MEMORY)
   {
      errno = EFAULT;
      return (-1);
   }

   fildes[0] = (int)ReadHandle;
   fildes[1] = (int)WriteHandle;

   return (0);
}

