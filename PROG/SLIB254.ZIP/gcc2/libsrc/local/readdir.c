#define INCL_DOSFILEMGR
#include <os2.h>

#define __DIRENT_PRIVATE__
#include <dirent.h>

struct dirent *readdir(dir)
   DIR *dir;
{
     ULONG ret;
     FILEFINDBUF3 buf;
     ULONG cnt;

     cnt = 1;
     
     if (dir->reset) {
	  /* opendir() also calls DosFindFirst, so this is sometimes */
	  /* unnecessary */
	  dir->reset = 0;
	  ret = DosFindFirst(dir->searchname, &dir->dirhandle,
			     FILE_ARCHIVED | FILE_DIRECTORY | FILE_SYSTEM
			       | FILE_HIDDEN | FILE_READONLY,
			     &buf, sizeof(buf), &cnt, 1);
     } else {
	  ret = DosFindNext(dir->dirhandle, &buf, sizeof(buf), &cnt);
     }
     
     if (ret != 0 || cnt != 1)
	return NULL;
     else {
	  strcpy(dir->ent.d_name, buf.achName);
	  dir->ent.d_namlen = strlen(dir->ent.d_name);
	  dir->ent.d_reclen = dir->ent.d_namlen;
	  dir->ent.d_fileno = 0;
	  return &dir->ent;
     }
}

     
     
	  

     
