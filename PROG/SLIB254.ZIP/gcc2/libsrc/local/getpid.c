#define INCL_DOSPROCESS
#include <os2.h>

int getpid (void)
{
   PTIB tib;
   PPIB pib;

   DosGetInfoBlocks (&tib, &pib);

   return (pib -> pib_ulpid);
}

