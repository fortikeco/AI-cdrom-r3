#define INCL_DOSMISC
#include <os2.h>

extern void srandom(int);

void randomize(void)
{
    unsigned tipl; /* Millseconds since IPL */
    unsigned time; /* Time since 1970 in seconds */
    
    DosQuerySysInfo(QSV_TIME_LOW, QSV_TIME_LOW, &time, 1);
    DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &tipl, 1);
    srandom(tipl + time);
}
