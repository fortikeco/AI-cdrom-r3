
struct _dll_registry {
    struct _dll_registry *next;
    void *ctor_table;
    void *dtor_table;
};

extern void _dllctor_add_registry(struct _dll_registry *);

extern int ___CTOR_LIST__;
extern int ___DTOR_LIST__;

struct _dll_registry _dllregistry =
{
    0, &___CTOR_LIST__, &___DTOR_LIST__
};

int _dllinit(void)
{
  _dllctor_add_registry(&_dllregistry);
  return 1;
}
