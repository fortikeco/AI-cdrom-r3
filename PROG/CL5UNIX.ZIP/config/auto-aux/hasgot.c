main() {
  getgroups();
}
