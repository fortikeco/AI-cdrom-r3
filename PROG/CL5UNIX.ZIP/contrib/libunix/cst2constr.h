#ifdef ANSI
value cst_to_constr(int, int *, int, int);
#else
value cst_to_constr();
#endif
