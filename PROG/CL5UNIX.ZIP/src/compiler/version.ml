let banner = "The Caml Light compiler, version 0.5";;
