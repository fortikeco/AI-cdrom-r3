(* Equality functions *)

#open "bool";;

let prefix <> x y = not (x = y)
;;
