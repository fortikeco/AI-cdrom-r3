#ifndef _roots_
#define _roots_


#ifdef ANSI
void local_roots (void (*copy_fn) (value *, value));
#else
void local_roots ();
#endif


#endif /* _roots_ */
