let banner = "The Caml Light linker, version 0.5";;
