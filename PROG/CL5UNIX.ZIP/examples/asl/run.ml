(* $Id: run.ml,v 1.3 91/08/22 15:03:15 ddr Exp $ *)

#open "asl";;
#open "main";;
#open "sys";;

for i = 1 to vect_length command_line -1 do
  match command_line.(i) with
    "-p" ->
      trace_parsing := true
  | _ -> print_string "Usage: ";
		 print_string command_line.(0);
		 print_string " [-p]"; print_newline();
		 print_string " -p: trace parsing"; print_newline();
		 exit 1
done;;

input_stream := stdin;;

printexc__f go ();;
