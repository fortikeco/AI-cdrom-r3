(* $Id: load.ml,v 1.4 91/10/04 14:25:04 ddr Exp $ *)

#open "token";;
#open "parser";;
#open "semant";;
#open "typing";;
#open "main";;

load_object "hash";
load_object "asl";
load_object "token";
load_object "parser";
load_object "semant";
load_object "typing";
load_object "main";;

