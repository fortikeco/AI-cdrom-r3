(* $Id: asl.ml,v 1.2 91/08/22 15:03:05 ddr Exp $ *)

let init_env =  ["+";"-";"*";"/";"="];;
