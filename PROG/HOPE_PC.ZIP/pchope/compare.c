#include "defs.h"
#include "expr.h"
#include "cell.h"
#include "path.h"

/*
 * Comparisons
 *
 * This is all complicated by the fact that comparisons are done lazily.
 */

local	EXPR	*e_cmp, *e_cmppair;
local	CONS	*c_less, *c_equal, *c_greater;

local	CELL	*compare();
local	CONS	*cmp_args();

/*
 *	Set up comparison code
 *	Call after reading standard module.
 */
global void
init_cmps()
{
reg	FUNC	*fn;

	/*
	 * The following wierd structure causes the 2 arguments of cmp
	 * to be unrolled.
	 * If they are functions, and try to get their arguments, the
	 * routine chk_argument() in interpret.c will detect this structure
	 * and report an error.  Yes, we're talking major kludge, so be
	 * careful about changing it.
	 */
	e_cmp = apply_expr(dir_expr(p_push(P_LEFT, p_new())),
			   apply_expr(dir_expr(p_push(P_RIGHT, p_new())),
				      builtin_expr(compare)));
	fn = fn_lookup(newstring("cmp"));
	ASSERT( fn != (FUNC *)0 );
	fn->f_body = e_cmp;
	fn->f_branch = BR_BUILTIN;

	fn = fn_lookup(newstring("cmp_pair"));
	ASSERT( fn != (FUNC *)0 );
	e_cmppair = fn->f_body;

	c_less = cons_lookup(newstring("less"));
	c_equal = cons_lookup(newstring("equal"));
	c_greater = cons_lookup(newstring("greater"));
	ASSERT( c_less != (CONS *)0 );
	ASSERT( c_equal != (CONS *)0 );
	ASSERT( c_greater != (CONS *)0 );
}

/*
 *	Called by the the built-in function "cmp", to compare two values.
 *	Comparison of functions should be excluded by the type-checker.
 *	For now, a kludge called chk_argument() in the interpreter does it.
 */
local CELL *
compare(arg)
reg	CELL	*arg;
{
	switch (arg->c_left->c_class) {
	when C_PAIR:
		grab(arg);
		return new_susp(e_cmppair, new_pair(arg, (CELL *)0));
	when C_CONS:
		if (arg->c_left->c_cons == arg->c_right->c_cons) {
			grab(arg->c_left->c_arg);
			grab(arg->c_right->c_arg);
			return new_susp(e_cmp,
				new_pair(new_pair(arg->c_left->c_arg,
						  arg->c_right->c_arg),
					 (CELL *)0));
		}
		return new_cnst(cmp_args(arg->c_left, arg->c_right));
	}
	/* otherwise: */
	return new_cnst(cmp_args(arg->c_left, arg->c_right));
}

local CONS *
cmp_args(first, second)
reg	CELL	*first, *second;
{
	switch (first->c_class) {
	when C_NUM:
		return first->c_num == second->c_num ? c_equal :
			first->c_num < second->c_num ?
					c_less : c_greater;
	when C_CHAR:
		return first->c_char == second->c_char ? c_equal :
			first->c_char < second->c_char ?
					c_less : c_greater;
	when C_CONST:
		return first->c_cons == second->c_cons ? c_equal :
			first->c_cons->c_index < second->c_cons->c_index ?
					c_less : c_greater;
	when C_CONS:
		return first->c_cons->c_index < second->c_cons->c_index ?
					c_less : c_greater;
	}
	/*NOTREACHED*/
}
