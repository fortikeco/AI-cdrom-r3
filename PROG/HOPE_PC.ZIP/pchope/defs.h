#ifndef	DEFS_H
#define	DEFS_H
/*
 * A lazy Hope interpreter
 *
 * Ross Paterson, University of Queensland, 1988,1989.
 *	Now: Department of Computing, Imperial College, London SW7 2AZ, UK.
 *			  (rap@doc.ic.ac.uk)
 *
 * For details of the language, see
 * "Hope: an experimental applicative language" by R.M. Burstall, D.B MacQueen
 *	and D.T. Sanella, CSR-62-80, Department of Computer Science,
 *	University of Edinburgh.  (describes an early version of the language)
 * "Functional Programming", A.J. Field and P.G. Harrison, Addison Wesley,
 *	Wokingham, England, 1988.
 * "A Hope Tutorial" by R. Bailey, Byte, August 1985 pp235-258.
 *
 * Non-standard features of this implementation:
 * - all constructors and defined functions are lazy
 * - ',' is an irrefutable constructor
 * - provision for I/O: input, read, write
 * - module structure: private, abstype
 * - sections (a la Miranda): (op), (op x), (x op)
 *
 * Notice:
 * This program is freely available, subject to the following conditions:
 *  (1) This comment is left intact, and
 *  (2) any changes are marked clearly, and signed, both in the code
 *	where they occur and in the Revision History below.
 *
 * This program was developed under an educational (i.e. cheap) Unix licence.
 * Sale of the program would infringe the conditions of that licence.
 *
 *				Ross Paterson, 11 March 1989.
 */

/*
 * Revision History:
 *   31 Jul 88	initial version used in CS225 [Ross]
 *   31 Jan 89	added type, abstype, private, parameterless definitions [Ross]
 *    4 Mar 89	added operator sections [Ross]
 *   16 Jul 89	general clean-up; use of "Standard" module [Ross]
 *   25 Jul 89	#ifdef AMIGA sections [Bill Segall, Ross]
 *    6 Nov 89	back end rewritten to use lazy Krivine machine;
 *		output & comparison functions in "Standard";
 *		simplification of pattern compilation.  [Ross, Andrew Moran]
 *   11 Mar 90	edit command, and re-editing (RE_EDIT) [Ross]
 */

#define	PC

/* size of space for compiled code, tables, stack and heap */
#ifdef	macintosh
#	define	MEMSIZE	200000L
#endif	macintosh
#ifdef	AMIGA
#	define	MEMSIZE	200000L
#endif	AMIGA
#ifdef	unix
#	define	MEMSIZE	500000L
#endif	unix
/* On the PC, this is string and table space only.  The heap is not
   explicitly memory managed.
*/
#ifdef	PC
#	define	MEMSIZE 60000L
#endif	PC

#ifdef	macintosh
#	define	RAW_INPUT
#endif	macintosh

#ifdef	PC
#	define	NO_MEM_MANAGE
#endif	PC

/*
 * Standard Definitions
 */

#include <stdio.h>

#ifdef	EBUG
#	define	local
#	define	reg
#else
#	define	local	static
#	define	reg	register
#endif	EBUG
#define	global

#define	natural	unsigned
#define	bool	int
#define	sbool	char
#define	TRUE	1
#define	FALSE	0

#define	when	break; case
#define	or	: case
#define	otherwise	break; default

#ifdef	RAW_INPUT
#	define	gets(s)	_gets(s)
#endif	RAW_INPUT

#ifndef	unix
#	define	isatty(fd)	(fd <= 2)
#endif	unix

#ifdef	AMIGA
#	define	HOPELIB	"HopeLib"
#endif	AMIGA

#ifdef	PC
#	define	HOPELIB	"\\HOPE\\LIB"
#endif	PC

extern	char	*strcpy(), *gets(), *mktemp();
#ifndef	AMIGA
#	ifndef PC
	extern	char	*sprintf();
#	else
	extern	int	sprintf();
#	endif	PC
#else
extern	int	sprintf();
#endif	AMIGA

#ifdef	unix
#	define	RE_EDIT
#else
#	define	edit_script(name)
#endif	unix

#include <setjmp.h>

#ifdef	EBUG
#	define	ASSERT(x)	if (! (x)) fprintf(stderr, "assertion failed: file %s, line %d\n", __FILE__, __LINE__), abort()
#	define	NOTREACHED	fprintf(stderr, "'unreachable statement' reached: file %s, line %d\n", __FILE__, __LINE__), abort()
#else
#	define	ASSERT(x)
#	define	NOTREACHED
#endif	EBUG

#define	SIZE(array)	(sizeof(array)/sizeof(array[0]))

#endif	DEFS_H
