/*
 *	Lexical analysis
 */
#include "defs.h"
#include "typevar.h"
#include "op.h"
#include "strings.h"
#include "expr.h"
#include "module.h"
#include "yyparse.h"
#include "error.h"
#include <signal.h>

extern	long	atol();

#define	MAXLEVEL	8	/* maximum depth of file nesting */

local	FILE	*infile[MAXLEVEL];
local	int	lineno[MAXLEVEL];
local	bool	atend[MAXLEVEL];
local	int	level;
local	bool	istty;		/* top level input is a terminal */

#ifdef RE_EDIT
local	char	*script;
extern	void	re_edit_script();
#endif RE_EDIT

local	char	line[1024];
local	char	*inptr;

typedef struct {
	char	*sym_name;	/* string to match -- 0 for end of symbols */
	int	sym_token;	/* token returned to yacc */
} SYMBOL;

/* reserved identifiers */
local	SYMBOL	reserved[] = {
	{ "++",		OR	},
	{ "---",	VALOF	},
	{ ":",		':'	},
	{ "<=",		IS	},
	{ "==",		EQ	},
	{ "=>",		GIVES	},
	{ "\\",		LAMBDA	},
	{ "abstype",	ABSTYPE	},
	{ "data",	DATA	},
	{ "dec",	DEC	},
	{ "display",	DISPLAY	},
#ifdef	RE_EDIT
	{ "edit",	EDIT	},
#endif	RE_EDIT
	{ "else",	ELSE	},
	{ "end",	END	},
	{ "exit",	EXIT	},
	{ "if",		IF	},
	{ "in",		IN	},
	{ "infix",	INFIX	},
	{ "infixr",	INFIXRL	},	/* for backward compatability */
	{ "infixrl",	INFIXRL	},
	{ "lambda",	LAMBDA	},
	{ "let",	LET	},
	{ "nonop",	NONOP	},
	{ "private",	PRIVATE	},
	{ "save",	SAVE	},
	{ "then",	THEN	},
	{ "to",		TO	},
	{ "type",	TYPESYM	},
	{ "typevar",	TYPEVAR	},
	{ "use",	USE	},
	{ "uses",	USE	},	/* for backward compatability */
	{ "where",	WHERE	},
	{ "write",	WRITE	},
	{ "|",		'|'	},
	{ 0, 0}
};

/* character classes */
#define	Oper	0
#define	Letter	1
#define	Digit	2
#define	String	3
#define	Char	4
#define	Comment	5
#define	Layout	6
#define	Punct	7
#define	Eol	8
#define	Ill	9

local	char	symclass[128] = {
     /* nul	soh	stx	etx	eot	enq	ack	bel	*/
	Eol,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* bs	ht	nl	vt	np	cr	so	si	*/
	Ill,	Layout,	Layout,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* dle	dc1	dc2	dc3	dc4	nak	syn	etb	*/
	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* can	em	sub	esc	fs	gs	rs	us	*/
	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,	Ill,
     /* sp	!	"	#	$	%	&	'	*/
	Layout,	Comment,String,	Oper,	Oper,	Oper,	Oper,	Char,
     /* (	)	*	+	,	-	.	/	*/
	Punct,	Punct,	Oper,	Oper,	Punct,	Oper,	Oper,	Oper,
     /* 0	1	2	3	4	5	6	7	*/
	Digit,	Digit,	Digit,	Digit,	Digit,	Digit,	Digit,	Digit,
     /* 8	9	:	;	<	=	>	?	*/
	Digit,	Digit,	Oper,	Punct,	Oper,	Oper,	Oper,	Oper,
     /* @	A	B	C	D	E	F	G	*/
	Oper,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* H	I	J	K	L	M	N	O	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* P	Q	R	S	T	U	V	W	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* X	Y	Z	[	\	]	^	_	*/
	Letter,	Letter,	Letter,	Punct,	Oper,	Punct,	Oper,	Letter,
     /* `	a	b	c	d	e	f	g	*/
	Oper,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* h	i	j	k	l	m	n	o	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* p	q	r	s	t	u	v	w	*/
	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,	Letter,
     /* x	y	z	{	|	}	~	del	*/
	Letter,	Letter,	Letter,	Ill,	Oper,	Ill,	Oper,	Ill
/* In real Hope, this would be:
	Letter,	Letter,	Letter,	Punct,	Oper,	Punct,	Oper,	Ill
 */
};

extern	int	lookup();
extern	char	charesc();
extern	short	yyerrflag;

global int
yylex()
{
	char	word[100];
static	char	literal[100];	/* space for string constants */
reg	int	c;
reg	char	*wptr;

	wptr = word;
	for (;;)
		switch (symclass[c = *inptr++]) {
		when Layout:
		when Eol:
			/*
			 * in interactive mode, try to recover from errors
			 * by inserting a semicolon, so the next line
			 * can start afresh.
			 */
			if (yyerrflag && level == 0 && istty) {
				inptr--;
				return ';';
			}
			if (! getline())
				return level < 0 ? EOF : ENDFILE;
		when Comment:
			while (*inptr)
				inptr++;
		when Char:
			c = *inptr++;
			if (c == '\\')
				c = charesc();
			yylval.charval = c;
			if (symclass[*inptr++] == Char)
				return CHAR;
			inptr--;
			error(LEXERR, "non-terminated character");
		when String:
			wptr = literal;
			while (c = *inptr++) {
				if (symclass[c] == String) {
					*wptr = '\0';
					yylval.textval = literal;
					return TEXT;
				}
				if (c == '\\')
					c = charesc();
				*wptr++ = c;
			}
			inptr--;
			error(LEXERR, "non-terminated string");
		when Digit:
			do {
				*wptr++ = c;
			} while (symclass[c = *inptr++] == Digit);
			inptr--;
			*wptr = '\0';
			yylval.longval = atol(word);
			return NUMBER;
		when Letter:
			do {
				*wptr++ = c;
			} while (symclass[c = *inptr++] == Letter ||
				 symclass[c] == Digit);
			inptr--;
			*wptr = '\0';
			return lookup(word);
		when Oper:
			do {
				*wptr++ = c;
			} while (symclass[c = *inptr++] == Oper);
			inptr--;
			*wptr = '\0';
			return lookup(word);
		when Ill:
			error(LEXERR, "illegal character");
		when Punct:
			return c;
		}
}

/*
 *	Escaped character sequence -- last char was a backslash.
 */
local char
charesc()
{
	int	c;

	switch (c = *inptr++) {
	case 'n': return '\n';
	case 't': return '\t';
	case 'b': return '\b';
	case '\0':
		inptr--;
		return '\\';
	}
	return c;
}

local	short	op_sym[2][MAXPREC - MINPREC + 1] = {
	/* ASSOC_LEFT */
	{ BINARY1, BINARY2, BINARY3, BINARY4, BINARY5,
	  BINARY6, BINARY7, BINARY8, BINARY9, BINARY10 },
	/* ASSOC_RIGHT */
	{ RBINARY1, RBINARY2, RBINARY3, RBINARY4, RBINARY5,
	  RBINARY6, RBINARY7, RBINARY8, RBINARY9, BINARY10 }
};

local int
lookup(s)
reg	char	*s;
{
reg	SYMBOL	*p;
reg	OP	*op;

	s = newstring(s);
	for (p = reserved; p->sym_name; p++)
		if (p->sym_name == s)
			return (p->sym_token);
	yylval.strval = s;
	if ((op = op_lookup(s)) != (OP *)0)
		return op_sym[(int)(op->op_assoc)][op->op_prec - MINPREC];
	return (IDENT);
}

/*
 *	Called on detecting the error -- flag the erroneous token.
 */
/*ARGSUSED*/
global void
yyerror(s)
	char	*s;
{
	error(SYNERR, (char *)0);
}

global	int	erroneous = FALSE;

/*VARARGS2*/
global void
error(errtype, fmt, x1, x2, x3, x4, x5, x6, x7, x8, x9)
	int	errtype;
	char	*fmt;
	long	x1, x2, x3, x4, x5, x6, x7, x8, x9;
{
static	char	*errname[] = {
			"lexical", "syntax", "semantic", "type",
			"run-time", "fatal", "internal"
		};
extern	jmp_buf	execerror;
reg	char	*p;
reg	int	i = 0;

	if (level != 0 || ! istty)
		printf("%s\n", line);
	if (errtype == SYNERR) {
		for (p = line; p < inptr; p++)
			if (*p >= ' ')
				i++;
			else if (*p == '\t')
				i += 8 - i%8;
		if (level == 0 && istty)
			printf("   ");
		printf("%*s\n", i, "^");
	}

	if (level > 0)
		printf("module %s, ", mod_name());
	if (level > 0 || ! istty)
		printf("line %d: ", lineno[level]);
	if (fmt) {
		printf("%s error - ", errname[errtype]);
		printf(fmt, x1, x2, x3, x4, x5, x6, x7, x8, x9);
		printf("\n");
	}
	else
		printf("%s error\n", errname[errtype]);
#ifdef RE_EDIT
	if (level == 0 && script) {
		printf("<Hit return to continue>");
		fflush(stdout);
		while (getchar() != '\n' && ! feof(stdin))
			;
		clearerr(stdin);
		re_edit_script(script, lineno[0]);
	}
#endif RE_EDIT
	switch (errtype) {
	when EXECERR:
		signal(SIGINT, SIG_IGN);
		longjmp(execerror, 1);
	when FATALERR or INTERR:
		exit(1);
	}
	erroneous = TRUE;
}

global void
initlex()
{
reg	SYMBOL	*p;

	for (p = reserved; p->sym_name; p++)
		p->sym_name = newstring(p->sym_name);
	istty = isatty(0);
	infile[0] = stdin;
	lineno[0] = 0;
	atend[0] = FALSE;
	level = 0;
	inptr = "";
	yyerrflag = FALSE;
}

#ifdef RE_EDIT
global void
set_script(file)
	char	*file;
{
	FILE	*f;

	if ((f = fopen(file, "r")) == (FILE *)0)
		error(SEMERR, "can't read script '%s'", file);
	else {
		script = file;
		infile[0] = f;
		istty = FALSE;
	}
}
#endif RE_EDIT

global void
enterfile(f)
reg	FILE	*f;
{
	level++;
	infile[level] = f;
	lineno[level] = 0;
	atend[level] = FALSE;
	inptr = "";
}

/*
 *	Get a line from the current input.
 *	The line will be terminated by a null if it comes from the terminal;
 *	otherwise it ends in a newline (whitespace) and then a null.
 */
local bool
getline()
{
	if (level < 0)
		return FALSE;
	if (atend[level])
#ifdef RE_EDIT
		if (level == 0 && script) {
			fclose(infile[0]);
			istty = isatty(0);
			infile[0] = stdin;
			lineno[0] = 0;
			atend[0] = FALSE;
			unlink(script);
			script = (char *)0;
		}
		else
#endif RE_EDIT
		{
			if (level > 0)
				fclose(infile[level]);
			level--;
			inptr = "";
			return FALSE;
		}
	if (level == 0 && istty) {
		fprintf(stderr, ">: ");
		atend[level] = gets(line) == (char *)0;
	}
	else
		atend[level] =
			fgets(line, sizeof(line), infile[level]) == (char *)0;
	if (atend[level])
		line[0] = '\0';
	inptr = line;
	lineno[level]++;
	return TRUE;
}
