#ifndef DEFTYPE_H
#define DEFTYPE_H

#include "strings.h"
#include "typevar.h"

#define	CONS	struct _CONS
#define	DEFTYPE	struct _DEFTYPE
#define	TYPE	struct _TYPE

CONS {
	STRING	c_name;
	TYPE	*c_type;
	sbool	c_constructor;
	short	c_index;
	CONS	*c_next;
};

extern	CONS	*constant();	/* (name) */
extern	CONS	*constructor();	/* (name, type) */
extern	CONS	*alt_cons();	/* (CONS *cons, CONS *conslist) */
extern	CONS	*cons_lookup();	/* (name) */
extern	CONS	*cons_local();	/* (name) */

/*
 *	Defined types.
 */
DEFTYPE {
	STRING	dt_name;
	sbool	dt_synonym;	/* type is a synonym */
	sbool	dt_private;	/* definition of type is private */
	TYPE	*dt_varlist;
	union {
		CONS	*dtu_cons;	/* list of constants and constructors */
		TYPE	*dtu_type;	/* synonymous type */
	} dt_union;
	DEFTYPE	*dt_next;	/* next in defined type table */
};
#define	dt_cons	dt_union.dtu_cons
#define	dt_type	dt_union.dtu_type

extern	void	abstype();	/* (DEFTYPE *newtype) */
extern	void	type_syn();	/* (DEFTYPE *newtype, TYPE *type) */
extern	void	decl_type();	/* (DEFTYPE *newtype, CONS *conslist) */

extern	void	dt_declare();	/* (DEFTYPE *dt) */
extern	DEFTYPE	*dt_lookup();	/* (name) */
extern	DEFTYPE	*dt_local();	/* (name) */

extern	DEFTYPE *new_deftype();	/* (name, TYPE *varlist) */
extern	void	pr_deftype();	/* (FILE *f, DEFTYPE *dt) */

extern	DEFTYPE	*product, *function, *list, *num, *truval, *character;
extern	CONS	*nil, *cons, *succ, *true, *false;

TYPE {
	enum { TY_VAR, TY_DEF } ty_class;
	union {
		TVAR	*tyu_var;
		struct {
			DEFTYPE	*tyd_deftype;
			TYPE	*tyd_firstarg;
		} tyu_def;
	} ty_union;
	TYPE	*ty_next;	/* next argument of defined type */
};
#define	ty_var		ty_union.tyu_var
#define	ty_deftype	ty_union.tyu_def.tyd_deftype
#define	ty_firstarg	ty_union.tyu_def.tyd_firstarg
#define	ty_secondarg	ty_firstarg->ty_next

extern	TYPE	*new_vartype();	/* (tvar) */
extern	TYPE	*id_type();	/* (name) */
extern	TYPE	*new_type();	/* (name, TYPE *args) */
extern	TYPE	*cons_type();	/* (type, list) */
extern	TYPE	*pair_type();	/* (type, type) */
extern	TYPE	*func_type();	/* (type, type) */
extern	TYPE	*def_type();	/* (dt, typelist) */
extern	TYPE	*new_tv();	/* (TYPEVAR *tvar) */

extern	void	dis_type();

#endif DEFTYPE_H
