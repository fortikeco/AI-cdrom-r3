#include "defs.h"
#include "memory.h"
#include "error.h"

#ifdef	unix
extern	char	*malloc();
#define	Alloc(size)	(POINTER)malloc((unsigned)size)
#endif	unix

#ifdef	macintosh
extern	char	*mlalloc();
#define	Alloc(size)	(POINTER)mlalloc((long)size)
#endif	macintosh

#ifdef	AMIGA
extern	char	*malloc();
#define	Alloc(size)	(POINTER)malloc((unsigned)size)
#endif	AMIGA

#ifdef	PC
extern	char	*malloc();
#define	Alloc(size)	(POINTER)malloc((long)size)
#endif	PC

local	POINTER	base_memory, top_memory;
local	POINTER	top_table, top_temp, top_heap, base_string;
global	POINTER	stack;

#ifdef	STATS
local	int	max_heap = 0;	/* max. size of heap */
local	int	max_stack = 0;	/* max. size of stack */
#endif	STATS

global void
init_memory()
{
	if ((base_memory = Alloc(MEMSIZE)) == (POINTER)0)
		error(FATALERR, "not enough memory");
	top_temp = top_table = base_memory;
	base_string = top_memory = base_memory + MEMSIZE/sizeof(WORD);
}

global POINTER
s_alloc(n)
	natural	n;
{
	n = (n + sizeof(WORD)-1)/sizeof(WORD);
	base_string -= n;
	if (base_string < top_temp)
		error(FATALERR, "out of memory");
	return base_string;
}

global POINTER
h_alloc(n)
	natural	n;
{
#ifdef	NO_MEM_MANAGE
	POINTER	p;
	if ((p = Alloc(n)) == (POINTER)0)
		error(EXECERR, "out of memory");
	return p;
#else
	n = (n + sizeof(WORD)-1)/sizeof(WORD);
	top_heap += n;
	chk_stack();
#ifdef	STATS
	if (top_heap - top_temp > max_heap)
		max_heap = top_heap - top_temp;
#endif	STATS
	return top_heap-n;
#endif	NO_MEM_MANAGE
}

global POINTER
t_alloc(n)
	natural	n;
{
	n = (n + sizeof(WORD)-1)/sizeof(WORD);
	top_temp += n;
	if (base_string < top_temp)
		error(FATALERR, "out of memory");
	return top_temp-n;
}

global void
clean_slate()
{
	top_temp = top_table;
}

global void
preserve()
{
	top_table = top_temp;
}

global void
init_heap()
{
	stack = base_string;
	top_heap = top_temp;
}

global int
heap_size()
{
	return (char *)top_heap - (char *)top_temp;
}

global void
chk_stack()
{
	if ((POINTER)stack < top_heap)
		error(EXECERR, "out of memory");
#ifdef STATS
	if (base_string - stack > max_stack)
		max_stack = base_string - stack;
#endif STATS
}

global void
heap_stats()
{
#ifdef	STATS
	printf("space: %d + %d + %d + %d = %d words\n",
		top_table - base_memory, max_heap, max_stack,
		top_memory - base_string,
		(top_table - base_memory) + max_heap + max_stack +
			(top_memory - base_string));
#endif	STATS
}
