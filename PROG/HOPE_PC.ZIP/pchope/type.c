#include "defs.h"
#include "op.h"
#include "expr.h"
#include "cell.h"
#include "error.h"

#define	INFINITY	1000

local	CELL	*last_type;	/* last inferred type */

	/* Types of local program variables, allocated with new_vars() */
local	CELL	**next_vtype;
local	CELL	**first_tvar;
	/* Type variables used by copy_type() and dis_type() */
local	CELL	**next_tvar;
	/* Types of variables local to a pattern or parameter */
local	CELL	**local_var;
	/* Local variables at each level */
local	CELL	***variables;

local	CELL	*ty_expr(), *ty_if(), *ty_list(), *ty_branch();
local	CELL	*copy_type(), *cp_list(), *cp_type(), *cp_tvar(), *cp_syn();
local	void	show_expr(), show_branch();
local	CELL	*ty_eqn();
local	void	save_tvars();
local	bool	vars_changed();
local	void	init_vars(), new_vars(), del_vars();
local	bool	unify(), assign(), occurs();
local	void	deref();

extern	void	pr_expr();

extern	jmp_buf	execerror;

global bool
chk_func(branch, fn)
	BRANCH	*branch;
	FUNC	*fn;
{
reg	CELL	*type1, *type2;

	init_free_list();
	if (setjmp(execerror))
		return FALSE;
	init_vars();
	if ((type1 = ty_branch(branch)) == NOCELL)
		return FALSE;
	type2 = copy_type(fn->f_type);
	save_tvars();
	if (! unify(type1, type2) || vars_changed()) {
		error(TYPEERR, "'%s': does not match declaration", fn->f_name);
		printf("  declared type: ");
		pr_type(stdout, fn->f_type);
		printf("\n");
		printf("  inferred type: ");
	 	last_type = ty_branch(branch);
		dis_type();
		printf("\n");
		return FALSE;
	}
	release(type1);
	release(type2);
	return TRUE;
}

global bool
chk_const(expr, fn)
	EXPR	*expr;
	FUNC	*fn;
{
reg	CELL	*type1, *type2;

	init_free_list();
	if (setjmp(execerror))
		return FALSE;
	init_vars();
	if ((type1 = ty_expr(expr)) == NOCELL)
		return FALSE;
	type2 = copy_type(fn->f_type);
	save_tvars();
	if (! unify(type1, type2) || vars_changed()) {
		error(TYPEERR, "'%s': does not match declaration", fn->f_name);
		printf("  declared type: ");
		pr_type(stdout, fn->f_type);
		printf("\n");
		printf("  inferred type: ");
		last_type = ty_expr(expr);
		dis_type();
		printf("\n");
		return FALSE;
	}
	release(type1);
	release(type2);
	return TRUE;
}

local void
save_tvars()
{
reg	CELL	**tvp;

	for (tvp = first_tvar; tvp < next_tvar; tvp++)
		grab(*tvp);
}

local bool
vars_changed()
{
reg	CELL	**tvp;

	for (tvp = first_tvar; tvp < next_tvar; tvp++) {
		if ((*tvp)->c_targ != NOCELL)
			return TRUE;
		release(*tvp);
	}
	return FALSE;
}

/*
 *	Top level: must have
 *		lambda input => expr: list char -> T
 *
 *	Side effect: set last_type to T.
 */
global bool
chk_expr(expr)
	EXPR	*expr;
{
	init_vars();
	new_vars(0);
	*next_vtype++ = new_tcons(list, new_tcons(character, NOCELL));
	last_type = ty_expr(expr);
	del_vars();
	return last_type != NOCELL;
}

global bool
chk_list(expr)
	EXPR	*expr;
{
	CELL	*list_type;

	if (! chk_expr(expr))
		return FALSE;
	deref(&last_type);
	list_type = new_tcons(list, new_tvar(tv_var(0)));
	if (! unify(last_type, list_type)) {
		release(last_type);
		release(list_type);
		error(TYPEERR, "a `write' expression must produce a list");
		show_expr(expr);
		return FALSE;
	}
	release(last_type);
	release(list_type);
	return TRUE;
}

local CELL *
ty_expr(expr)
reg	EXPR	*expr;
{
	CELL	*type1;
reg	CELL	*type, *type2;

	switch (expr->e_class) {
	when E_NUM:
		return new_tcons(num, NOCELL);
	when E_CHAR:
		return new_tcons(character, NOCELL);
	when E_DEFUN:
		return copy_type(expr->e_defun->f_type);
	when E_CONST or E_CONS:
		return copy_type(expr->e_const->c_type);
	when E_LAMBDA:
		return ty_list(expr->e_branch);
	when E_PARAM:
		local_var = variables[expr->e_level];
		return ty_expr(expr->e_patt);
	when E_VAR:
		/*
		 *	... , x: t, ... => x: t
		 */
		type = local_var[expr->e_var];
		grab(type);
		return type;
	when E_PAIR:
		/*
		 *	A => e1: t1
		 *	A => e2: t2
		 *	-------------
		 *	A => e1, e1: t1 # t2
		 */
		if ((type1 = ty_expr(expr->e_left)) == NOCELL ||
		    (type2 = ty_expr(expr->e_right)) == NOCELL)
			return NOCELL;
		return new_tcons(product, new_pair(type1, type2));
	when E_IF:
		return ty_if(expr->e_arg, expr->e_func->e_branch);
	when E_WHERE or E_LET:
		return ty_eqn(expr->e_func->e_branch, expr->e_arg);
	when E_APPLY:
		/*
		 *	A => e1: t1 -> t2
		 *	A => e2: t1
		 *	-------------
		 *	A => (e1 e2): t2
		 */
		if ((type1 = ty_expr(expr->e_func)) == NOCELL ||
		    (type2 = ty_expr(expr->e_arg)) == NOCELL)
			return NOCELL;
		type = new_tcons(function,
			new_pair(type2, new_tvar(tv_var(0))));
		deref(&type1);
		if (! unify(type, type1)) {
			error(TYPEERR,
				"conflict between function and argument");
			printf("  ");
			pr_expr(stdout, expr, INFINITY, PREC_BODY);
			printf("\n");
			show_expr(expr->e_func);
			show_expr(expr->e_arg);
			return NOCELL;
		}
		release(type);
		deref(&type1);
		type = type1->c_targ->c_right;
		grab(type);
		release(type1);
		return type;
	}
	/* NOTREACHED */
}

local CELL *
ty_if(if_expr, branch)
	EXPR	*if_expr;
	BRANCH	*branch;
{
	CELL	*type1, *type2;
	EXPR	*then_expr, *else_expr;

	then_expr = branch->br_expr;
	else_expr = branch->br_next->br_expr;
	if ((type1 = ty_expr(if_expr)) == NOCELL)
		return NOCELL;
	deref(&type1);
	type2 = new_tcons(truval, NOCELL);
	if (! unify(type1, type2)) {
		error(TYPEERR, "predicate should have type truval");
		show_expr(if_expr);
		return NOCELL;
	}
	release(type1);
	release(type2);

	new_vars(0);
	if ((type1 = ty_expr(then_expr)) == NOCELL ||
	    (type2 = ty_expr(else_expr)) == NOCELL)
		return NOCELL;
	deref(&type1);
	deref(&type2);
	if (! unify(type1, type2)) {
		error(TYPEERR, "conflict between branches of conditional");
		show_expr(then_expr);
		show_expr(else_expr);
		return NOCELL;
	}
	release(type2);
	del_vars();
	return(type1);
}

/*
 *	pat => val: T1 -> T2
 *	exp: T1
 *	--------------------
 *	val WHERE pat == exp: T2
 */
local CELL *
ty_eqn(branch, expr)
	BRANCH	*branch;
	EXPR	*expr;
{
	CELL	*pat_type, *exp_type, *val_type;

	new_vars(branch->br_nvars);
	if ((pat_type = ty_expr(branch->br_pattern)) == NOCELL ||
	    (val_type = ty_expr(branch->br_expr)) == NOCELL)
		return NOCELL;
	del_vars();
	if ((exp_type = ty_expr(expr)) == NOCELL)
		return NOCELL;
	deref(&pat_type);
	deref(&val_type);
	if (! unify(pat_type, exp_type)) {
		error(TYPEERR, "conflict between sides of equation");
		show_expr(branch->br_pattern);
		show_expr(expr);
		return NOCELL;
	}
	release(pat_type);
	release(exp_type);
	return val_type;
}

local void
show_expr(expr)
	EXPR	*expr;
{
	printf("  ");
	pr_expr(stdout, expr, INFINITY, PREC_BODY);
	printf(" : ");
	last_type = ty_expr(expr);
	dis_type();
	printf("\n");
}

local CELL *
ty_list(branch)
reg	BRANCH	*branch;
{
	CELL	*type1, *type2;

	if ((type1 = ty_branch(branch)) == NOCELL)
		return NOCELL;
	if (branch->br_next) {
		/*
		 *	A => b1: t
		 *	A => b2: t
		 *	------------
		 *	A => b1 | b2: t
		 */
		if ((type2 = ty_list(branch->br_next)) == NOCELL)
			return NOCELL;
		deref(&type1);
		deref(&type2);
		if (! unify(type1, type2)) {
			error(TYPEERR, "types cannot be reconciled");
			show_branch(branch);
			return NOCELL;
		}
		release(type2);
	}
	return type1;
}

local CELL *
ty_branch(branch)
reg	BRANCH	*branch;
{
reg	CELL	*type1, *type2;

	/*
	 *	A1 => p: t1
	 *	A1, A2 => e: t2
	 *	-----------------
	 *	A2 => (p => e): t1 -> t2
	 */
	new_vars(branch->br_nvars);
	if ((type1 = ty_expr(branch->br_pattern)) == NOCELL ||
	    (type2 = ty_expr(branch->br_expr)) == NOCELL)
		return NOCELL;
	del_vars();
	return new_tcons(function, new_pair(type1, type2));
}

local void
show_branch(branch)
reg	BRANCH	*branch;
{
	do {
		printf("  ");
		pr_expr(stdout, branch->br_pattern, INFINITY, PREC_BODY);
		printf(" => ");
		pr_expr(stdout, branch->br_expr, INFINITY, PREC_BODY);
		printf(" : ");
		last_type = ty_branch(branch);
		dis_type();
		printf("\n");
		branch = branch->br_next;
	} while (branch);
}

/*
 *	Entering and exiting of scopes: allocate a new type variable
 *	for each program variable.
 */

local void
init_vars()
{
static	CELL	*first_vtype[40];
static	CELL	**local_table[20];

	next_vtype = first_vtype;
	variables = local_table + SIZE(local_table);
}

local void
new_vars(n)
reg	int	n;
{
	*--variables = local_var = next_vtype;
	/*
	 *	x1: alpha1, ..., xn: alphan
	 */
	while (n-- > 0)
		*next_vtype++ = new_tvar(tv_var(0));
}

local void
del_vars()
{
	while (next_vtype != *variables)
		release(*--next_vtype);
	variables++;
}

/*
 *	Make a temporary copy of a type.
 */
local CELL *
copy_type(type)
	TYPE	*type;
{
	next_tvar = first_tvar = next_vtype;
	return cp_type(type);
}

local CELL *
cp_type(type)
reg	TYPE	*type;
{
	return type->ty_class == TY_VAR ? cp_tvar(type->ty_var) :
		type->ty_deftype->dt_synonym ? cp_syn(type) :
			new_tcons(type->ty_deftype,
				type->ty_firstarg ?
					cp_list(type->ty_firstarg) : NOCELL);
}

local CELL *
cp_list(type)
reg	TYPE	*type;
{
	return type->ty_next == (TYPE *)0 ? cp_type(type) :
		new_pair(cp_type(type), cp_list(type->ty_next));
}

/*
 *	Expand a type synonym
 */
local CELL *
cp_syn(type)
reg	TYPE	*type;
{
	CELL	*actual[10];
reg	CELL	**cp, *ctype;
	CELL	**old_first_tvar;
	TYPE	*tp;

	/*
	 * Collect actual type parameters
	 * (in the current type variable environment)
	 */
	cp = actual;
	for (tp = type->ty_firstarg; tp; tp = tp->ty_next)
		*cp++ = cp_type(tp);
	/*
	 * Instantiate the formal type parameters to the actuals before
	 * constructing the type synonym.
	 * (all in a new type variable environment)
	 */
	old_first_tvar = first_tvar;
	first_tvar = next_tvar;
	cp = actual;
	for (tp = type->ty_deftype->dt_varlist; tp; tp = tp->ty_next) {
		*next_tvar = new_tvar(tp->ty_var);
		(*next_tvar)->c_targ = *cp;
		next_tvar++;
		cp++;
	}
	ctype = cp_type(type->ty_deftype->dt_type);
	while (next_tvar > first_tvar)
		release(*--next_tvar);
	first_tvar = old_first_tvar;
	return ctype;
}

local CELL *
cp_tvar(tvar)
reg	TVAR	*tvar;
{
reg	CELL	**tvp;

	for (tvp = first_tvar; tvp < next_tvar; tvp++)
		if ((*tvp)->c_tvar == tvar) {
			grab(*tvp);
			return *tvp;
		}
	*next_tvar++ = new_tvar(tvar);
	return *tvp;
}

/*
 *	Printing of inferred types.
 */

extern	void	show_type(), show_var();

/*
 *	Print the current type.
 */
global void
dis_type()
{
	next_tvar = first_tvar = next_vtype;
	deref(&last_type);
	show_type(last_type, PREC_BODY);
	release(last_type);
}

/*
 *	Print an already dereferenced type.
 */
local void
show_type(type, context)
reg	CELL	*type;
	int	context;
{
	OP	*op;

	if (type->c_class == C_TVAR)
		show_var(type);
	else if (type->c_targ == NOCELL)		/* nullary */
		printf("%s", type->c_tcons->dt_name);
	else if (type->c_targ->c_class != C_PAIR) {	/* unary */
		if (PREC_APPLY < context)
			printf("(");
		printf("%s ", type->c_tcons->dt_name);
		deref(&(type->c_targ));
		show_type(type->c_targ, PREC_APPLY+1);
		if (PREC_APPLY < context)
			printf(")");
	}
	else if (op = op_lookup(type->c_tcons->dt_name)) {	/* infix */
		if (op->op_prec < context)
			printf("(");
		deref(&(type->c_targ->c_left));
		show_type(type->c_targ->c_left, LeftPrec(op));
		printf(" %s ", type->c_tcons->dt_name);
		deref(&(type->c_targ->c_right));
		show_type(type->c_targ->c_right, RightPrec(op));
		if (op->op_prec < context)
			printf(")");
	}
	else {
		if (PREC_APPLY < context)
			printf("(");
		printf("%s (", type->c_tcons->dt_name);
		type = type->c_targ;
		while (type->c_class == C_PAIR) {
			deref(&(type->c_left));
			show_type(type->c_left, PREC_BODY);
			printf(", ");
			deref(&(type->c_right));
			type = type->c_right;
		}
		show_type(type, PREC_BODY);
		printf(")");
		if (PREC_APPLY < context)
			printf(")");
	}
}

/*
 *	Print first uninstantiated type variable encountered as alpha,
 *	next as beta, and so on, then alpha', beta', etc.
 */
local void
show_var(var)
reg	CELL	*var;
{
reg	CELL	**tvp;
reg	int	n;

	/*
	 * Set n to var's index in the seen-variable table,
	 * inserting var if it's new.
	 */
	*next_tvar = var;	/* also serves as a sentinel */
	for (tvp = first_tvar; *tvp != var; tvp++)
		;
	if (tvp == next_tvar)
		next_tvar++;
	n = tvp - first_tvar;
	/* print n as a suitably primed type variable name */
	printf("%s", tv_var(n%tv_count())->tv_name);
	for (n = n/tv_count(); n > 0; n--)
		printf("'");
}

/*
 *	Unification of type terms.
 *	Proceeds by direct modification of uninstantiated variables.
 *	It prefers to instantiate variables in the first term.
 *	Assumes type1 and type2 have already been dereferenced.
 */
local bool
unify(type1, type2)
reg	CELL	*type1, *type2;
{
	if (type1->c_class == C_TVAR)
		return assign(type1, type2);
	if (type2->c_class == C_TVAR)
		return assign(type2, type1);
	if (type1->c_tcons != type2->c_tcons)
		return FALSE;
	if (type1->c_targ == NOCELL)
		return TRUE;
	deref(&(type1->c_targ));
	deref(&(type2->c_targ));
	type1 = type1->c_targ;
	type2 = type2->c_targ;
	while (type1->c_class == C_PAIR) {
		deref(&(type1->c_left));
		deref(&(type2->c_left));
		if (! unify(type1->c_left, type2->c_left))
			return FALSE;
		deref(&(type1->c_right));
		deref(&(type2->c_right));
		type1 = type1->c_right;
		type2 = type2->c_right;
	}
	return unify(type1, type2);
}

/*
 *	Assign a term to a cell, after performing the occurs check.
 *	var is an uninstantiated variable,
 *	type has already been dereferenced.
 */
local bool
assign(var, type)
reg	CELL	*var;
reg	CELL	*type;
{
	if (type != var) {	/* action required */
		if (occurs(var, type))
			return FALSE;
		grab(type);
		var->c_targ = type;
	}
	return TRUE;
}

/*
 *	Occur check -- does the variable occur in the term?
 *	The term has already been dereferenced.
 */
local bool
occurs(var, type)
reg	CELL	*var;
reg	CELL	*type;
{
	if (type->c_class == C_TVAR)	/* uninstantiated variable */
		return type == var;
	if (type->c_targ == NOCELL)
		return FALSE;
	deref(&type->c_targ);
	type = type->c_targ;
	while (type->c_class == C_PAIR) {
		deref(&(type->c_left));
		if (occurs(var, type->c_left))
			return TRUE;
		deref(&(type->c_right));
		type = type->c_right;
	}
	return occurs(var, type);
}

/*
 *	Follow a chain of instantiated variables to either a constructor or
 *	an uninstantiated variable.
 *	Uses path compression to speed up subsequent derefs,
 *	and to free the used variable cells.
 */
local void
deref(cp)
reg	CELL	**cp;
{
reg	CELL	*cell;

	cell = *cp;
	if (cell->c_class == C_TVAR && cell->c_targ != NOCELL) {
		deref(&(cell->c_targ));
		*cp = cell->c_targ;
		grab(*cp);
		release(cell);
	}
}
