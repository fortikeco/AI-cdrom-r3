#include "defs.h"
#include "op.h"
#include "cell.h"
#include "expr.h"
#include "path.h"
#include "error.h"
#include "memory.h"
#include "deftype.h"

global	FUNC	*f_succ;

extern	CELL	*eq(), *ne(), *lt(), *le(), *gt(), *ge();
extern	CELL	*open_stream();
extern	CELL	*print_value(), *write_value();

local	CELL	*successor();
local	CELL	*plus(), *minus(), *mul(), *div(), *mod();
local	CELL	*ord(), *chr();

local void
def_builtin(name, fn)
	char	*name;
	CELL	*(*fn)();
{
	FUNC	*bu;

	bu = fn_lookup(newstring(name));
	if (bu == (FUNC *)0)
		error(FATALERR, "undeclared built-in '%s'", name);
	bu->f_body = strict_expr(builtin_expr(fn));
	bu->f_branch = BR_BUILTIN;
}

global void
init_builtins()
{
	def_builtin("+",	plus		);
	def_builtin("-",	minus		);
	def_builtin("*",	mul		);
	def_builtin("/",	div		);
	def_builtin("div",	div		);
	def_builtin("mod",	mod		);
	def_builtin("ord",	ord		);
	def_builtin("chr",	chr		);
	def_builtin("read",	open_stream 	);

	def_builtin("print",	print_value 	);
	def_builtin("write_element",	write_value 	);

	f_succ = NEW(FUNC);
	f_succ->f_name = newstring("succ");
	f_succ->f_type = succ->c_type;
	f_succ->f_body = strict_expr(builtin_expr(successor));
	f_succ->f_branch = BR_BUILTIN;
}

local CELL *
successor(arg)
	CELL	*arg;
{
	return new_num(arg->c_num + 1);
}

/*
 *	Arithmetic operators.
 */

local CELL *
plus(arg)
	CELL	*arg;
{
	return new_num(arg->c_left->c_num + arg->c_right->c_num);
}

local CELL *
minus(arg)
	CELL	*arg;
{
	return new_num(arg->c_left->c_num - arg->c_right->c_num);
}

local CELL *
mul(arg)
	CELL	*arg;
{
	return new_num(arg->c_left->c_num * arg->c_right->c_num);
}

local CELL *
div(arg)
	CELL	*arg;
{
	if (arg->c_right->c_num == 0)
		error(EXECERR, "attempt to divide by zero");
	return new_num(arg->c_left->c_num / arg->c_right->c_num);
}

local CELL *
mod(arg)
	CELL	*arg;
{
	if (arg->c_right->c_num == 0)
		error(EXECERR, "attempt to divide by zero");
	return new_num(arg->c_left->c_num % arg->c_right->c_num);
}

local CELL *
ord(arg)
	CELL	*arg;
{
	return new_num((long)(arg->c_char));
}

local CELL *
chr(arg)
	CELL	*arg;
{
	if (arg->c_num <= 0 || arg->c_num >= 128)
		error(EXECERR, "value out of range: chr(%ld)", arg->c_num);
	return new_char((int)(arg->c_num));
}
