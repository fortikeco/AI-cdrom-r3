#include "defs.h"
#include "expr.h"
#include "cell.h"
#include "error.h"

extern	void	init_free_list();
extern	void	interpret();
extern	void	chk_heap();
extern	void	close_streams();

extern	void	open_out_file();
extern	void	save_out_file();
extern	void	close_out_file();

/*
 *	Evaluation of expressions.
 */

global	jmp_buf	execerror;

global void
eval_expr(expr)
	EXPR	*expr;
{
	if (erroneous)
		return;
	if (nr_branch(new_branch(id_pattern(newstring("input")), expr))) {
		open_out_file((char *)0);
		init_free_list();
		if (! setjmp(execerror) && chk_expr(expr)) {
			interpret(e_print, expr);
			printf(" : ");
			dis_type();
			printf("\n");
			chk_heap();
		}
		close_streams();
	}
}

global void
wr_expr(expr, file)
	EXPR	*expr;
	char	*file;
{
	if (erroneous)
		return;
	if (nr_branch(new_branch(id_pattern(newstring("input")), expr))) {
		open_out_file(file);
		init_free_list();
		if (! setjmp(execerror) && chk_list(expr)) {
			interpret(e_wr_list, expr);
			chk_heap();
			save_out_file();
		}
		else
			close_out_file();
		close_streams();
	}
}
