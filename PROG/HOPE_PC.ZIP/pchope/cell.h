#ifndef CELL_H
#define CELL_H

#include "path.h"
#include "expr.h"

/* classes of cell with no sub-cells */
#define	C_0_1	0
#define	C_0_2	1
#define	C_0_3	2
#define	C_0_4	3
/* classes of cell with one sub-cell */
#define	C_1_1	4
#define	C_1_2	5
#define	C_1_3	6
/* classes of cell with two sub-cells */
#define	C_2_1	7

#define	NO_CHILDREN	C_0_1 or C_0_2 or C_0_3 or C_0_4
#define	ONE_CHILD	C_1_1 or C_1_2 or C_1_3
#define	TWO_CHILDREN	C_2_1

#define	C_PAIR	C_2_1	/* general purpose pair and list builder */

/* type cell classes */
#define	C_TCONS	C_1_1
#define	C_TVAR	C_1_2

/* data cell classes */
#define	C_NUM	C_0_1
#define	C_CHAR	C_0_2
#define	C_CONST	C_0_3	/* constant */
#define	C_STREAM C_0_4	/* partially read input stream */
#define	C_CONS	C_1_1	/* constructed term */
#define	C_SUSP	C_1_2	/* term and environment */
#define C_DIRS	C_1_3	/* directions and value */

#define	NOCELL	((CELL *)0)

CELL {
	short	c_class;
	short	c_refcount;
#ifdef EBUG
	int	c_realrefcount;
#endif EBUG
	union {
		long	cu_num;
		char	cu_char;
		FILE	*cu_file;
		struct {
			union {
				CONS	*cu_cons;
				EXPR	*cu_expr;
				DEFTYPE	*cu_tcons;
				TVAR	*cu_tvar;
				PATH	cu_path;
			} co_union;
			CELL	*co_cell;
		} cu_one;
		struct {
			CELL	*ct_left, *ct_right;
		} cu_two;
	} c_union;
};

/* fields for general purpose pairs */
#define	c_left	c_union.cu_two.ct_left		/* PAIR */
#define	c_right	c_union.cu_two.ct_right		/* PAIR */

/* fields for data cells */
#define	c_num	c_union.cu_num			/* NUM */
#define	c_char	c_union.cu_char			/* CHAR */
#define	c_file	c_union.cu_file			/* STREAM */
#define	c_cons	c_union.cu_one.co_union.cu_cons	/* CONST, CONS */
#define	c_arg	c_union.cu_one.co_cell		/* CONS */
#define	c_exp	c_union.cu_one.co_union.cu_expr	/* SUSP */
#define	c_env	c_union.cu_one.co_cell		/* SUSP */
#define	c_path	c_union.cu_one.co_union.cu_path	/* DIRS */
#define	c_val	c_union.cu_one.co_cell		/* DIRS */

/* fields for type structures */
#define	c_tcons	c_union.cu_one.co_union.cu_tcons /* TCONS */
#define	c_targ	c_union.cu_one.co_cell		/* TCONS */
#define	c_tvar	c_union.cu_one.co_union.cu_tvar	/* TVAR */

/* free list */
#define	c_foll	c_union.cu_one.co_cell

#define	grab(cell)	((cell)->c_refcount++)

extern	void	init_free_list();
extern	void	copy_cell();
extern	CELL	*new_pair();
extern	CELL	*new_susp(), *new_cnst(), *new_cons(), *new_stream(),
		*new_num(), *new_char(), *new_dirs();
extern	CELL	*new_tcons(), *new_tvar();
extern	void	release();
extern	void	chk_heap();

/* manipulating the stack of cells */
#define	Push(cell)	(*(CELL **)(--stack) = (cell))
#define	Pop()		(*(CELL **)(stack++))
#define	Top()		(*(CELL **)stack)
#define	Pop_void()	(stack++)

#endif	CELL_H
