#include "defs.h"
#include "memory.h"
#include "deftype.h"
#include "op.h"
#include "error.h"

/*
 *	Defined Types.
 */

global	DEFTYPE	*function, *product;
global	DEFTYPE	*list, *num, *truval, *character;
global	CONS	*nil, *cons, *succ, *true, *false;

/*
 *	The type currently being defined.
 *	(not yet recorded in the tables, in case of error,
 *	except in the case of an abstract type being defined)
 */
local	DEFTYPE	*cur_deftype;		/* type cuttently being defined */
local	bool	already_defined;	/* current type is already defined */

extern	int	ty_length();
extern	void	ty_print(), pr_alt();

/*
 *	Check a list of type variables for repetitions.
 */
local void
check_repeats(varlist)
reg	TYPE	*varlist;
{
reg	TYPE	*vp;

	for ( ; varlist; varlist = varlist->ty_next)
		for (vp = varlist->ty_next; vp; vp = vp->ty_next)
			if (vp->ty_var == varlist->ty_var) {
				error(SEMERR, "argument '%s' is repeated",
					vp->ty_var->tv_name);
				return;
			}
}

global DEFTYPE *
new_deftype(name, vars)
	STRING	name;
	TYPE	*vars;
{
reg	DEFTYPE *ty;

	already_defined = (ty = dt_local(name)) != (DEFTYPE *)0;
	if (already_defined) {
		if (ty->dt_synonym || ty->dt_cons != (CONS *)0)
			error(SEMERR, "attempt to redefine type '%s'", name);
		else if (ty_length(vars) != ty_length(ty->dt_varlist))
			error(SEMERR,
				"`%s': variable number of type arguments",
				name);
	}
	else {
		ty = NEW(DEFTYPE);
		ty->dt_name = name;
		ty->dt_synonym = FALSE;
		ty->dt_cons = (CONS *)0;
	}
	check_repeats(vars);
	ty->dt_varlist = vars;
	cur_deftype = ty;
	return ty;
}

global void
abstype(deftype)
	DEFTYPE	*deftype;
{
	if (erroneous || already_defined)
		return;
	dt_declare(deftype);
	preserve();
}

global void
type_syn(deftype, type)
	DEFTYPE	*deftype;
	TYPE	*type;
{
	if (erroneous)
		return;
	if (refers_to(deftype, type)) {
		error(SEMERR, "recursive type abbreviation");
		return;
	}
	if (ill_formed(deftype->dt_varlist, type))
		return;
	deftype->dt_synonym = TRUE;
	deftype->dt_type = type;
	if (! already_defined)
		dt_declare(deftype);
	preserve();
}

local bool
refers_to(deftype, type)
reg	DEFTYPE	*deftype;
reg	TYPE	*type;
{
	if (type->ty_class == TY_VAR)
		return FALSE;
	if (type->ty_deftype == deftype)
		return TRUE;
	if (type->ty_deftype->dt_synonym &&
	    refers_to(deftype, type->ty_deftype->dt_type))
		return TRUE;
	for (type = type->ty_firstarg; type; type = type->ty_next)
		if (refers_to(deftype, type))
			return TRUE;
	return FALSE;
}

global void
decl_type(deftype, conslist)
	DEFTYPE	*deftype;
	CONS	*conslist;
{
reg	CONS	*ct;
reg	TYPE	*result_type;
	int	index;

	if (erroneous)
		return;
	deftype->dt_cons = conslist;
	result_type = def_type(deftype, deftype->dt_varlist);
	index = 0;
	for (ct = conslist; ct; ct = ct->c_next) {
		if (ct->c_constructor) {
			if (ill_formed(deftype->dt_varlist, ct->c_type))
				return;
			ct->c_type = func_type(ct->c_type, result_type);
		}
		else
			ct->c_type = result_type;
		ct->c_index = index++;
	}
	if (! already_defined)
		dt_declare(deftype);
	preserve();
}

/*
 *	Check that all the type variables appearing in type also
 *	appear in the argument list of the type.
 */
local bool
ill_formed(varlist, type)
reg	TYPE	*varlist, *type;
{
	if (type->ty_class == TY_VAR) {
		while (varlist) {
			if (varlist->ty_var == type->ty_var)
				return FALSE;
			varlist = varlist->ty_next;
		}
		error(SEMERR, "'%s' is not an argument variable",
			type->ty_var->tv_name);
		return TRUE;
	}
	else {	/* TY_DEF */
		for (type = type->ty_firstarg; type; type = type->ty_next)
			if (ill_formed(varlist, type))
				return TRUE;
		return FALSE;
	}
}

/*
 *	Lists of constructed types.
 */

global CONS *
constant(name)
	STRING	name;
{
reg	CONS	*data_constant;

	data_constant = NEW(CONS);
	data_constant->c_constructor = FALSE;
	data_constant->c_name = name;
	data_constant->c_next = (CONS *)0;
	return data_constant;
}

global CONS *
constructor(name, argtype)
	STRING	name;
	TYPE	*argtype;
{
reg	CONS	*constr;

	constr = NEW(CONS);
	constr->c_constructor = TRUE;
	constr->c_name = name;
	constr->c_type = argtype;
	constr->c_next = (CONS *)0;
	return constr;
}

global CONS *
alt_cons(constr, conslist)
	CONS	*constr, *conslist;
{
	constr->c_next = conslist;
	return constr;
}

/*
 *	Type structures.
 */

global TYPE *
id_type(name)
	STRING	name;
{
reg	TVAR	*tvar;
reg	DEFTYPE	*dt;

	if ((tvar = tv_lookup(name, FALSE)) != (TVAR *)0)
		return new_tv(tvar);
	if (name == cur_deftype->dt_name &&
	    ty_length(cur_deftype->dt_varlist) == 0)
		return def_type(cur_deftype, (TYPE *)0);
	if ((dt = dt_lookup(name)) != (DEFTYPE *)0 &&
	    ty_length(dt->dt_varlist) == 0)
		return def_type(dt, (TYPE *)0);
	error(SEMERR, "`%s' is not a type constant", name);
	return new_tv(tv_var(0));
}

global TYPE *
new_type(name, args)
	STRING	name;
	TYPE	*args;
{
reg	DEFTYPE	*deftype;

	if (name == cur_deftype->dt_name)
		deftype = cur_deftype;
	else if ((deftype = dt_lookup(name)) == (DEFTYPE *)0) {
		error(SEMERR, "`%s' is not a defined type", name);
		deftype = list;		/* dummy */
	}
	if (ty_length(deftype->dt_varlist) != ty_length(args))
		error(SEMERR, "`%s': variable number of type arguments", name);
	return def_type(deftype, args);
}

local int
ty_length(typelist)
reg	TYPE	*typelist;
{
reg	int	len;

	len = 0;
	while (typelist) {
		len++;
		typelist = typelist->ty_next;
	}
	return len;
}

global TYPE *
def_type(dt, args)
	DEFTYPE	*dt;
	TYPE	*args;
{
reg	TYPE	*type;

	type = NEW(TYPE);
	type->ty_class = TY_DEF;
	type->ty_deftype = dt;
	type->ty_firstarg = args;
	type->ty_next = (TYPE *)0;
	return type;
}

global TYPE *
new_tv(tvar)
	TVAR	*tvar;
{
reg	TYPE	*type;

	if (tvar == (TVAR *)0)
		return (TYPE *)0;
	type = NEW(TYPE);
	type->ty_class = TY_VAR;
	type->ty_var = tvar;
	type->ty_next = (TYPE *)0;
	return type;
}

global TYPE *
cons_type(type, typelist)
	TYPE	*type;
	TYPE	*typelist;
{
	if (type == (TYPE *)0 || typelist == (TYPE *)0)
		return (TYPE *)0;
	type->ty_next = typelist;
	return type;
}

global TYPE *
pair_type(type1, type2)
	TYPE	*type1, *type2;
{
	return def_type(product, cons_type(type1, type2));
}

global TYPE *
func_type(type1, type2)
	TYPE	*type1, *type2;
{
	return def_type(function, cons_type(type1, type2));
}

/*
 *	Printing of types.
 */

global void
pr_type(f, type)
	FILE	*f;
	TYPE	*type;
{
	ty_print(f, type, PREC_BODY);
}

local void
ty_print(f, type, context)
	FILE	*f;
reg	TYPE	*type;
	int	context;
{
	OP	*op;

	if (type->ty_class == TY_VAR)
		fprintf(f, "%s", type->ty_var->tv_name);
	else if (type->ty_firstarg == (TYPE *)0)
		fprintf(f, "%s", type->ty_deftype->dt_name);
	else if (type->ty_secondarg == (TYPE *)0) {
		if (PREC_APPLY < context)
			fprintf(f, "(");
		fprintf(f, "%s ", type->ty_deftype->dt_name);
		ty_print(f, type->ty_firstarg, PREC_APPLY+1);
		if (PREC_APPLY < context)
			fprintf(f, ")");
	}
	else if (op = op_lookup(type->ty_deftype->dt_name)) {
		if (op->op_prec < context)
			fprintf(f, "(");
		ty_print(f, type->ty_firstarg, LeftPrec(op));
		fprintf(f, " %s ", type->ty_deftype->dt_name);
		ty_print(f, type->ty_secondarg, RightPrec(op));
		if (op->op_prec < context)
			fprintf(f, ")");
	}
	else {
		if (PREC_APPLY < context)
			fprintf(f, "(");
		fprintf(f, "%s (", type->ty_deftype->dt_name);
		for (type = type->ty_firstarg; type; type = type->ty_next) {
			ty_print(f, type, PREC_BODY);
			if (type->ty_next)
				fprintf(f, ", ");
		}
		fprintf(f, ")");
		if (PREC_APPLY < context)
			fprintf(f, ")");
	}
}

global void
pr_deftype(f, dt, full)
	FILE	*f;
reg	DEFTYPE	*dt;
	bool	full;
{
reg	TYPE	*type;
reg	CONS	*alt;

	fprintf(f, "%s ",
		full && dt->dt_synonym ? "type" :
		full && dt->dt_cons ? "data" : "abstype");
	if (dt->dt_varlist == (TYPE *)0)
		fprintf(f, "%s", dt->dt_name);
	else if (dt->dt_varlist->ty_next == (TYPE *)0)
		fprintf(f, "%s %s",
			dt->dt_name, dt->dt_varlist->ty_var->tv_name);
	else if (op_lookup(dt->dt_name))
		fprintf(f, "%s %s %s",
			dt->dt_varlist->ty_var->tv_name,
			dt->dt_name,
			dt->dt_varlist->ty_next->ty_var->tv_name);
	else {
		fprintf(f, "%s(", dt->dt_name);
		for (type = dt->dt_varlist; type; type = type->ty_next)
			fprintf(f, type->ty_next ? "%s, " : "%s",
				type->ty_var->tv_name);
		fprintf(f, ")");
	}
	if (full)
		if (dt->dt_synonym) {
			fprintf(f, " == ");
			pr_type(f, dt->dt_type);
		}
		else if (dt->dt_cons) {
			fprintf(f, " == ");
			for (alt = dt->dt_cons; alt; alt = alt->c_next) {
				pr_alt(f, alt);
				if (alt->c_next)
					fprintf(f, " ++ ");
			}
		}
	fprintf(f, ";\n");
}

local void
pr_alt(f, alt)
	FILE	*f;
	CONS	*alt;
{
	OP	*op;

	if (! alt->c_constructor)
		fprintf(f, "%s", alt->c_name);
	else if (op = op_lookup(alt->c_name)) {
		ty_print(f, alt->c_type->ty_firstarg->ty_firstarg,
			LeftPrec(op));
		fprintf(f, " %s ", alt->c_name);
		ty_print(f, alt->c_type->ty_firstarg->ty_secondarg,
			RightPrec(op));
	}
	else {
		fprintf(f, "%s ", alt->c_name);
		ty_print(f, alt->c_type->ty_firstarg, PREC_APPLY+1);
	}
}
