#ifndef ERROR_H
#define ERROR_H

/* error categories */
#define	LEXERR	0	/* lexical error */
#define	SYNERR	1	/* syntax error */
#define	SEMERR	2	/* semantic error, except type errors */
#define	TYPEERR	3	/* type conflict */
#define	EXECERR	4	/* run-time error */
#define	FATALERR 5	/* fatal error */
#define	INTERR	6	/* internal error */

extern	void	error(); /* (errtype, fmt, arg1, ... argn); */

extern	int	erroneous; /* error already reported in the current line */

#endif ERROR_H
