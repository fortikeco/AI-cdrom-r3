#ifndef EXPR_H
#define EXPR_H

#include "strings.h"
#include "deftype.h"
#include "path.h"

#define	FUNC	struct _FUNC
#define	EXPR	struct _EXPR
#define	BRANCH	struct _BRANCH
#define	CELL	struct _CELL

FUNC {
	STRING	f_name;
	TYPE	*f_type;
	BRANCH	*f_branch;
	EXPR	*f_body;
	FUNC	*f_next;
};

extern	void	new_fn();	/* (name, type) */
extern	FUNC	*fn_lookup();	/* (name) */
extern	FUNC	*fn_local();	/* (name) */

extern	void	decl_func();	/* (name, type) */
extern	void	define();	/* (name, branchlist) */
extern	void	def_cons();	/* (name, expr) */
extern	void	eval_expr();	/* (expr) */

/*
 *	Expressions, including patterns.
 */

typedef enum {
	/* kinds of input expression which also appear as patterns */
	E_NUM,		/* integer constant */
	E_CHAR,		/* character constant */
	E_CONST,	/* data structure constant */
	E_CONS,		/* data structure constructor */
	E_VAR,		/* variable in pattern */
	E_PAIR,		/* pair constructor (,) */
	E_APPLY,	/* function application */
	/* kinds of input expression don't appear in patterns */
	E_DEFUN,	/* declared function or constant */
	E_LAMBDA,	/* anonymous (lambda) function */
	E_PARAM,	/* variable in expression */
	/* variants on APPLY, LAMBDA for building various constructs */
	E_IF,		/* if-then-else (like APPLY) */
	E_THEN,		/* body of if (like LAMBDA) */
	E_WHERE,	/* where clause (like APPLY) */
	E_LET,		/* let ... in clause (like APPLY) */
	E_EQN,		/* let/where equation (like LAMBDA) */
	/* expressions created by compilation of patterns */
	E_UCASE,	/* upper level of case expression */
	E_LCASE,	/* lower level of case expression */
	E_NCASE,	/* lower level of numerical case expression */
	E_CCASE,	/* lower level of character case expression */
	/* expressions used to represent built-in functions */
	E_STRICT,	/* a strict expression */
	E_BUILTIN,	/* lower level of built-in function */
			/* warning: this is misused by chk_argument() */
			/* you should understand it before using these */
	E_RETURN	/* return from execution */
} E_CLASS;

#define	NOMATCH	((EXPR *) 0)

EXPR {
	E_CLASS	e_class;
	union {	/* grab bag -- see the definitions below */
		long	en_val;		/* NUM */
		int	ei_val;		/* CHAR */
		CONS	*ec_cons;	/* CONST, CONS */
		struct {		/* VAR */
			STRING	ev_name;
			int	ev_num;
			PATH	ev_dirs;
		} e_v;
		struct {		/* PARAM */
			EXPR	*ep_patt;
			int	ep_level;
			PATH	ep_where;
		} e_p;
		struct {		/* PAIR, APPLY */
			EXPR	*ep_left, *ep_right;
		} e_pair;
		FUNC	*ef_defun;	/* DEFUN */
		struct {		/* LAMBDA */
			BRANCH	*el_branch;
			EXPR	*el_expr;
		} e_lambda;
		struct {		/* UCASE */
			PATH	eu_path;
			EXPR	*eu_cases;
		} e_ucase;
		struct {		/* LCASE, NCASE, CCASE */
			char	el_char;	/* CCASE only */
			short	el_arity;
			EXPR	**el_limbs;
		} e_lcase;
		EXPR	*es_real;	/* STRICT */
		CELL	*(*eb_fn)();	/* BUILTIN */
	} e_union;
};

#define	e_num	e_union.en_val		/* NUM */
#define	e_char	e_union.ei_val		/* CHAR */
#define	e_const	e_union.ec_cons		/* CONST, CONS */
#define	e_vname	e_union.e_v.ev_name	/* VAR */
#define	e_var	e_union.e_v.ev_num	/* VAR */
#define	e_dirs	e_union.e_v.ev_dirs 	/* VAR */
#define	e_patt	e_union.e_p.ep_patt	/* PARAM */
#define	e_level	e_union.e_p.ep_level	/* PARAM */
#define	e_where	e_union.e_p.ep_where	/* PARAM */
#define	e_left	e_union.e_pair.ep_left	/* PAIR */
#define	e_right	e_union.e_pair.ep_right	/* PAIR */
#define	e_func	e_union.e_pair.ep_left	/* APPLY */
#define	e_arg	e_union.e_pair.ep_right	/* APPLY */

#define	e_defun	e_union.ef_defun	/* DEFUN */
#define	e_expr	e_union.e_lambda.el_expr	/* LAMBDA */
#define	e_branch e_union.e_lambda.el_branch	/* LAMBDA */

#define	e_path	e_union.e_ucase.eu_path	/* UCASE */
#define e_cases	e_union.e_ucase.eu_cases /* UCASE */
#define e_arity e_union.e_lcase.el_arity /* LCASE, NCASE, CCASE */
#define e_limbs e_union.e_lcase.el_limbs /* LCASE, NCASE, CCASE */
#define e_cchar e_union.e_lcase.el_char	/* CCASE */

#define	e_real	e_union.es_real		/* STRICT */
#define	e_fn	e_union.eb_fn		/* BUILTIN */

/* expression constructors */
extern	EXPR	*num_expr();	/* (n) */
extern	EXPR	*char_expr();	/* (c) */
extern	EXPR	*text_expr();	/* (text) */
extern	EXPR	*const_expr();	/* (CONS *const) */
extern	EXPR	*cons_expr();	/* (CONS *cons) */
extern	EXPR	*id_expr();	/* (name) */
extern	EXPR	*id_pattern();	/* (name) */
extern	EXPR	*id_cons();	/* (name) */
extern	EXPR	*dir_expr();	/* (path) */
extern	EXPR	*pair_expr();	/* (expr1, expr2) */
extern	EXPR	*apply_expr();	/* (expr1, expr2) */
extern	EXPR	*func_expr();	/* (branchlist) */
extern	EXPR	*ite_expr();	/* (if_expr, then_expr, else_expr) */
extern	EXPR	*let_expr();	/* (pattern, subexpr, expr) */
extern	EXPR	*where_expr();	/* (expr, pattern, subexpr) */
extern	EXPR	*presection();	/* (name, expr) */
extern	EXPR	*postsection();	/* (name, expr) */
extern	EXPR	*ucase_expr();	/* (path, body) */
extern	EXPR	*lcase_expr();	/* (arity) */
extern	EXPR	*ncase_expr();	/* () */
extern	EXPR	*ccase_expr();	/* (ch) */
extern	EXPR	*strict_expr();	/* (sexpr) */
extern	EXPR	*builtin_expr(); /* (low_level_func) */

BRANCH {
	int	br_nvars;	/* number of variables in the pattern */
	EXPR	*br_pattern;
	EXPR	*br_expr;
	BRANCH	*br_next;	/* next branch in lambda or defined fn */
};

/* pseudo-branch to distinguish built-ins from constants */
#define	BR_BUILTIN	((BRANCH *)1)

/* branch constructors */
extern	BRANCH	*new_branch();	/* (pattern, expr) */
extern	BRANCH	*cons_branch();	/* (branch, branchlist) */

/* assignment of deBruijn nunbers to variables */
extern	bool	nr_branch();	/* (BRANCH *br) */
extern	bool	nr_expr();	/* (EXPR *expr) */

extern	void	pr_expr(), pr_simple(), pr_fdecl(), pr_fundef(), pr_char();
extern	void	pr_type();
extern	void	pr_actual(), pr_f_actual();
extern	void	pr_value();

extern	EXPR	*compile();	/* (EXPR *body, EXPR *pattern, EXPR *expr) */

extern	EXPR	*e_return, *e_print, *e_wr_list;
extern	EXPR	*e_true, *e_false, *e_cons, *e_nil;
extern	FUNC	*f_succ;

#endif EXPR_H
