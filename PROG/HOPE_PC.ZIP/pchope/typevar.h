#ifndef TYPEVAR_H
#define TYPEVAR_H

#include "strings.h"
/*
 *	Type variables.
 */
#define	TVAR	struct _TVAR
TVAR {
	STRING	tv_name;
};

extern	void	tv_declare();	/* (name) */
extern	TVAR	*tv_lookup();	/* (name, serious) */
extern	int	tv_count();
extern	TVAR	*tv_var();	/* (varno) */

#endif TYPEVAR_H
