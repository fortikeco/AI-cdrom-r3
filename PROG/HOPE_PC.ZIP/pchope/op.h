#ifndef OP_H
#define OP_H
#include "strings.h"
/*
 *	Associativity and precedence of operators.
 */
#define	ASSOC_LEFT	0
#define	ASSOC_RIGHT	1
#define	NUM_ASSOC	2
typedef	short	ASSOC;

#define	OP	struct _OP
OP {
	STRING	op_name;
	short	op_prec;
	ASSOC	op_assoc;
	OP	*op_next;
};

extern	void	op_declare();	/* (name, prec, assoc) */
extern	OP	*op_lookup();	/* (name) */
extern	OP	*op_local();	/* (name) */

#define	LeftPrec(op)	(op->op_prec + (op->op_assoc != ASSOC_LEFT))
#define	RightPrec(op)	(op->op_prec + (op->op_assoc != ASSOC_RIGHT))

/* weakest binding: always needs parentheses */
#define	PREC_INFIX	(MINPREC-5)
#define	PREC_PAIR	(MINPREC-4)
#define	PREC_LAMBDA	(MINPREC-3)
#define	PREC_LET	(MINPREC-2)
#define	PREC_WHERE	PREC_LET
#define	PREC_IF		(MINPREC-1)

/*
 * User-defined infix operators.
 * If you change either of these, you should make corresponding changes in:
 *	yylex.c
 *	multiply.sed
 * and the documentation, of course.
 */
#define	MINPREC		1
#define	MAXPREC		10

#define	PREC_APPLY	(MAXPREC+1)
#define	PREC_ATOMIC	(MAXPREC+2)
/* strongest binding: never needs parentheses */

/* context precedence for a top-level expression or type */
#define	PREC_BODY	PREC_PAIR

#endif OP_H
