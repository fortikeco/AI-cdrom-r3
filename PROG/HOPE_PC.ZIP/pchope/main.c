#include "defs.h"
#include "memory.h"
#include "module.h"
#include <signal.h>

extern	void	initlex();
extern	void	init_expr();
extern	void	mod_init();

#ifdef RE_EDIT
extern	void	set_script();
extern	void	re_edit_script();

local	char	tmp_dir[] = "/tmp";

local	char	*program_name;
#endif RE_EDIT

global void
main(argc, argv)
	int	argc;
	char	*argv[];
{
#ifdef macintosh
	Click_On(0);
#endif macintosh
	signal(SIGINT, SIG_IGN);
	init_memory();
	initlex();
#ifdef RE_EDIT
	program_name = argv[0];
	if (argc == 2 && strncmp(argv[1], tmp_dir, sizeof(tmp_dir)-1) == 0)
		/* re-entry after an edit */
		set_script(argv[1]);
#endif RE_EDIT
	init_expr();
	mod_init();	/* begin standard module */
	preserve();
	yyparse();	/* read commands from files and user */
	heap_stats();
	exit(0);
}

#ifdef RE_EDIT
/*
 *	`edit' command: save the current definitions in a file,
 *	invoke vi on the file, and then re-enter Hope, re-reading the file.
 *	If an error occurs during re-reading, go back to vi.
 */
global void
edit_script(name)
	char	*name;
{
	char	tmp_file[40];

	sprintf(tmp_file, "%s/hopeXXXXXX", tmp_dir);
	mod_save(mktemp(tmp_file));
	re_edit_script(name ? name : tmp_file, 1);
}

global void
re_edit_script(script_name, line)
	char	*script_name;
	int	line;
{
	char	command[100];

	sprintf(command, "vi +%d %s; exec %s %s",
			line, script_name, program_name, script_name);
	execl("/bin/sh", "sh", "-c", command, (char *)0);
}
#endif RE_EDIT
