#include "defs.h"
#include "path.h"
#include "memory.h"

/*
 *	Create a new, empty path.
 *	Returned value points to a static area that will be overwritten
 *	by the next call.
 */
global PATH
p_new()
{
static	char	path_buf[40];

	path_buf[sizeof(path_buf)-1] = P_END;
	return &path_buf[sizeof(path_buf)-1];
}

global PATH
p_push(dir, p)
	int	dir;
reg	PATH	p;
{
	*--p = dir;
	return p;
}

global PATH
p_stash(p)
	PATH	p;
{
reg	PATH	newp;

	newp = NEWARRAY(char, strlen(p) + 1);
	strcpy(newp, p);
	return newp;
}

global PATH
p_save(bp, p)
	char	**bp;
	char	*p;
{
	char	*new;

	new = *bp;
	strcpy(new, p);
	*bp += strlen(p)+1;
	return new;
}

/*
 *	Reverse a path, adding an UNROLL before each direction in the initial
 *	string of LEFTs and RIGHTs.
 *	Returned value points to a static area that will be overwritten
 *	by the next call.
 */
global PATH
p_reverse(old)
reg	PATH	old;
{
static	char	path_buf[40];
reg	PATH	new;
reg	int	dir;

	path_buf[sizeof(path_buf)-1] = P_END;
	new = &path_buf[sizeof(path_buf)-1];

	while (! p_empty(old)) {
		dir = p_top(old);
		new = p_push(dir, new);
		old = p_pop(old);
		if (dir != P_LEFT && dir != P_RIGHT)
			break;
		new = p_push(P_UNROLL, new);
	}
	while (! p_empty(old)) {
		new = p_push(p_top(old), new);
		old = p_pop(old);
	}
	return new;
}
