#include "defs.h"
#include "expr.h"
#include "memory.h"
#include "cell.h"
#include "error.h"
#include "path.h"

local	CELL	*free_list;
extern	CELL	*new_cell();

global CELL *
new_pair(left, right)
	CELL	*left, *right;
{
reg	CELL	*cp;

	cp = new_cell(C_PAIR);
	cp->c_left = left;
	cp->c_right = right;
	return cp;
}

global CELL *
new_dirs(path, val)
	PATH	path;
	CELL	*val;
{
reg	CELL	*cp;

	cp = new_cell(C_DIRS);
	cp->c_path = path;
	cp->c_val = val;
	return cp;
}

global CELL *
new_cons(constr, arg)
	CONS	*constr;
	CELL	*arg;
{
reg	CELL	*cp;

	cp = new_cell(C_CONS);
	cp->c_cons = constr;
	cp->c_arg = arg;
	return cp;
}

global CELL *
new_susp(exp, env)
	EXPR	*exp;
	CELL	*env;
{
reg	CELL	*cp;

	cp = new_cell(C_SUSP);
	cp->c_exp = exp;
	cp->c_env = env;
	return cp;
}

global CELL *
new_cnst(data_constant)
	CONS	*data_constant;
{
reg	CELL	*cp;

	cp = new_cell(C_CONST);
	cp->c_cons = data_constant;
	return cp;
}

global CELL *
new_num(n)
	long	n;
{
reg	CELL	*cp;

	cp = new_cell(C_NUM);
	cp->c_num = n;
	return cp;
}

global CELL *
new_char(c)
	char	c;
{
reg	CELL	*cp;

	cp = new_cell(C_CHAR);
	cp->c_char = c;
	return cp;
}

global CELL *
new_stream(f)
	FILE	*f;
{
reg	CELL	*cp;

	cp = new_cell(C_STREAM);
	cp->c_file = f;
	return cp;
}

global CELL *
new_tcons(tcons, targ)
	DEFTYPE	*tcons;
	CELL	*targ;
{
reg	CELL	*cp;

	cp = new_cell(C_TCONS);
	cp->c_tcons = tcons;
	cp->c_targ = targ;
	return cp;
}

global CELL *
new_tvar(var)
	TVAR	*var;
{
reg	CELL	*cp;

	cp = new_cell(C_TVAR);
	cp->c_tvar = var;
	cp->c_targ = NOCELL;
	return cp;
}

local CELL *
new_cell(class)
	short	class;
{
reg	CELL	*cell;

	if (free_list) {
		cell = free_list;
		free_list = cell->c_foll;
	}
	else
		cell = (CELL *)h_alloc(sizeof(CELL));
	cell->c_class = class;
	cell->c_refcount = 1;
	return cell;
}

/*
 *	Release a cell (with tail-recursion eliminated).
 */
global void
release(cell)
reg	CELL	*cell;
{
reg	CELL	*nextcell;

	while (cell && --(cell->c_refcount) == 0) {
		/* rel_children(cell); */
		switch (cell->c_class) {
		when ONE_CHILD:
			nextcell = cell->c_arg;
		when TWO_CHILDREN:
			release(cell->c_left);
			nextcell = cell->c_right;
		otherwise:
			nextcell = NOCELL;
		}
		cell->c_foll = free_list;
		free_list = cell;
		cell = nextcell;	/* tail-recursive call */
	}
}

local void
rel_children(cell)
reg	CELL	*cell;
{
	switch (cell->c_class) {
	when ONE_CHILD:
		release(cell->c_arg);
	when TWO_CHILDREN:
		release(cell->c_left);
		release(cell->c_right);
	}
}

local void
grab_children(cell)
reg	CELL	*cell;
{
	switch (cell->c_class) {
	when ONE_CHILD:
		if (cell->c_arg)
			grab(cell->c_arg);
	when TWO_CHILDREN:
		if (cell->c_left)
			grab(cell->c_left);
		if (cell->c_right)
			grab(cell->c_right);
	}
}

/*
 *	Copy the contents of "from" on top of "to".
 */
global void
copy_cell(to, from)
reg	CELL	*to, *from;
{
	int	refcount;

	grab_children(from);
	rel_children(to);
	refcount = to->c_refcount;
	*to = *from;
	to->c_refcount = refcount;
}

/*
 *	Set up the free list -- required before any calls to new_cell().
 */
global void
init_free_list()
{
	init_heap();
	free_list = NOCELL;
}

global void
chk_heap()
{
#ifdef LEAKS
reg	CELL	*cp;
reg	int	count;
	int	expected;

	expected = heap_size()/sizeof(CELL);
	count = 0;
	for (cp = free_list; cp; cp = cp->c_foll)
		count++;
	if (count != expected)
		error(EXECERR, "%d cells not deallocated", expected - count);
#endif LEAKS
}

#ifdef EBUG
local void
inc_refs(cell)
	CELL	*cell;
{
	if (cell) {
		cell->c_realrefcount++;
		if (cell->c_realrefcount == 1)
			switch (cell->c_class) {
			when ONE_CHILD:
				inc_refs(cell->c_arg);
			when TWO_CHILDREN:
				inc_refs(cell->c_left);
				inc_refs(cell->c_right);
			}
	}
}
#endif EBUG

global void
chk_refcounts(current)
	CELL	*current;
{
#ifdef EBUG
reg	CELL	*cp;
reg	POINTER	sp;
extern	POINTER	base_string, top_temp, top_heap;
extern	CELL	*last_type;

	for (cp = (CELL *)top_temp; cp != (CELL *)top_heap; cp++)
		cp->c_realrefcount = 0;

	inc_refs(last_type);
	inc_refs(current);
	for (sp = stack; sp != base_string; sp++)
		inc_refs((CELL *)((int)*(CELL **)sp & ~01));

	for (cp = (CELL *)top_temp; cp != (CELL *)top_heap; cp++)
		if (cp->c_refcount != cp->c_realrefcount) {
			if (cp->c_class == C_SUSP)
				fprintf(stderr, "expr class = %d\n",
					cp->c_exp->e_class);
			error(EXECERR, "cell type %d says %d, really %d",
				cp->c_class, cp->c_refcount,
				cp->c_realrefcount);
			}
#endif EBUG
}
