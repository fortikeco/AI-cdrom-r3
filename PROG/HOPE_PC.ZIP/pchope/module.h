#ifndef MODULE_H
#define MODULE_H

#include "expr.h"
#include "op.h"
#include "strings.h"

#define	MODULE	struct _MODULE

#define	SET	long
#define	ELEM(n)	(1L<<(n))
#define	EMPTY	0L
#define	SETSIZE	(8*sizeof(long))

MODULE {
	STRING	mod_name;
	int	mod_num;	/* index in module table */
	SET	mod_uses;
	SET	mod_refs;	/* transitive closure of uses */
	SET	mod_tvars;
	OP	*mod_ops,	**mod_oend;
	DEFTYPE	*mod_types,	**mod_tend;
	FUNC	*mod_fns,	**mod_fend;
	MODULE	*mod_public;	/* public part of a private module */
};

extern	void	mod_init();
extern	MODULE	*module();	/* (STRING name) */
extern	STRING	mod_name();	/* (MODULE *mod) */
extern	void	mod_use();	/* (MODULE *mod) */
extern	void	mod_save();	/* (STRING name) */
extern	void	mod_fetch();
extern	void	mod_finish();
extern	void	private();
extern	void	display();	/* (FILE *f) */

#endif MODULE_H
