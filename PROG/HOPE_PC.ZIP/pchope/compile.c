#include "defs.h"
#include "expr.h"
#include "cell.h"
#include "path.h"

typedef	struct {
	PATH	where;
	short	index, ncases;
} MATCH;

/* number and character cases are indicated by special values of ncases */

#define	NUMCASE	1000	/* special ncases value: number match */

#define	IsNumCase(m)	((m)->ncases == NUMCASE)
#define	IsCharCase(m)	((m)->ncases <= 0)

#define	CharCase(c)	(-(c))

#define	GetCharCase(m)	(-(m)->ncases)

/* indexes for number cases */
#define	ZERO_CASE	1
#define	SUCC_CASE	2

/* for character cases, the indexes are TRUE and FALSE */

local	MATCH	matchlist[40];
local	MATCH	*m_end;
local	char	p_buf[400];
local	char	*pb_end;

/*
 * add another match to the list.
 */
local void
add_match(where, ncases, index)
	PATH	where;
	int	ncases, index;
{
	m_end->where = p_save(&pb_end, p_reverse(where));
	m_end->ncases = ncases;
	m_end->index = index;
	m_end++;
}

local void
gen_char_match(here, c)
	PATH	here;
	char	c;
{
	add_match(here, CharCase(c), TRUE);
}

local void
gen_num_match(here, n)
	PATH	here;
	long	n;
{
	if (n == 0L)
		add_match(here, NUMCASE, ZERO_CASE);
	else {
		add_match(here, NUMCASE, SUCC_CASE);
		gen_num_match(p_push(P_PRED, here), n-1);
	}
}

local int
num_cases(constr)
reg	CONS	*constr;
{
	while (constr->c_next)
		constr = constr->c_next;
	return constr->c_index + 1;
}

/*
 * Generate the nodes of the matching tree given a path and a pattern.
 */
local void
gen_matches(here, pattern)
	PATH	here;
	EXPR	*pattern;
{
	switch (pattern->e_class) {
	when E_CHAR:
		gen_char_match(here, pattern->e_char);
	when E_NUM:
		gen_num_match(here, pattern->e_num);
	when E_CONST:
		add_match(here, num_cases(pattern->e_const),
			pattern->e_const->c_index);
	when E_APPLY:
		ASSERT( pattern->e_func->e_class == E_CONS );
		if (pattern->e_func->e_const == succ) {
			add_match(here, NUMCASE, SUCC_CASE);
			gen_matches(p_push(P_PRED, here), pattern->e_arg);
		}
		else {
			add_match(here, num_cases(pattern->e_func->e_const),
					pattern->e_func->e_const->c_index);
			gen_matches(p_push(P_STRIP, here), pattern->e_arg);
		}
	when E_PAIR:
		gen_matches(p_push(P_LEFT, here), pattern->e_left);
		gen_matches(p_push(P_RIGHT, here), pattern->e_right);
	}
}

/*
 * Replace all empty branches of the lower case expression with the patch
 * expression
 */
local void
patch(lower_case, patch_expr)
reg	EXPR	*lower_case, *patch_expr;
{
reg	int	limb;
reg	EXPR	**this;

	ASSERT( lower_case->e_class == E_LCASE ||
		lower_case->e_class == E_NCASE ||
		lower_case->e_class == E_CCASE );
	limb = lower_case->e_arity;
	this = lower_case->e_limbs;
	while (limb--) {
		if (*this == NOMATCH)
			*this = patch_expr;
		else if ((*this)->e_class == E_UCASE)
			patch((*this)->e_cases, patch_expr);
		this++;
	}
}

/*
 * Generate the skinny matching tree from the given nodes,
 * patching in "expr" at the leaf. 
 */
local EXPR *
gen_tree(matches, expr)
	MATCH	*matches;
	EXPR	*expr;
{
reg	EXPR	*limbs;

	if (matches == m_end)
		return expr;
	limbs = IsNumCase(matches) ? ncase_expr() :
		IsCharCase(matches) ? ccase_expr(GetCharCase(matches)) :
			lcase_expr(matches->ncases);
	limbs->e_limbs[matches->index] = gen_tree(matches+1, expr);
	return ucase_expr(p_stash(matches->where), limbs);
}

/*
 * Given the current matching tree, merge it with the tree generated from
 * the given nodes and expression.
 */
local EXPR *
merge(old, matches, new)
reg	EXPR	*old;
reg	MATCH	*matches;
reg	EXPR	*new;
{
	if (old == NOMATCH)			/* do all the matching */
		return gen_tree(matches, new);
	if (old->e_class == E_UCASE)
		if (matches == m_end)		/* pick up the crumbs */
			patch(old->e_cases, new);
		else if (! p_equal(old->e_path, matches->where))
						/* strike out on our own */
			patch(old->e_cases, gen_tree(matches, new));
		else if (IsCharCase(matches) &&
			 GetCharCase(matches) != old->e_cases->e_cchar)
			old->e_cases->e_limbs[FALSE] =
				merge(old->e_cases->e_limbs[FALSE],
				      matches, new);
		else				/* keep following */
			old->e_cases->e_limbs[matches->index] =
				merge(old->e_cases->e_limbs[matches->index],
				      matches+1, new);
	/* otherwise the current clause is hidden by earlier ones */
	return old;
}

/*
 * Given the current body, generate the new body as dictated by the given
 * pattern and expression.
 */
global EXPR *
compile(old_body, pattern, new_expr)
	EXPR	*old_body, *pattern, *new_expr;
{
	m_end = matchlist;
	pb_end = p_buf;
	gen_matches(p_new(), pattern);
	return merge(old_body, matchlist, new_expr);
}
