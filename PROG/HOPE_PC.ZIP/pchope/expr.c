#include "defs.h"
#include "memory.h"
#include "expr.h"
#include "cell.h"
#include "error.h"
#include "path.h"

/*
 *	Functions, Expressions and Patterns.
 *
 *	All semantic checks here occur at the top level, so sub-expressions
 *	are always defined.
 */

local	STRING	bound_variable;

global void
init_expr()
{
	bound_variable = newstring("x'");
}

global EXPR *
char_expr(c)
	char	c;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_CHAR;
	expr->e_char = c;
	return expr;
}

global EXPR *
text_expr(text)
	char	*text;
{
	return *text == '\0' ? e_nil :
			apply_expr(e_cons, pair_expr(char_expr(*text),
						     text_expr(text+1)));
}

global EXPR *
num_expr(n)
	long	n;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_NUM;
	expr->e_num = n;
	return expr;
}

global EXPR *
const_expr(data_constant)
	CONS	*data_constant;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_CONST;
	expr->e_const = data_constant;
	return expr;
}

global EXPR *
cons_expr(data_constructor)
	CONS	*data_constructor;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_CONS;
	expr->e_const = data_constructor;
	return expr;
}

/*
 *	Identifier occurring in an operand position in a pattern.
 *	If it's not a constant, it must be a variable.
 */
global EXPR *
id_pattern(name)
	STRING	name;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	if ((expr->e_const = cons_lookup(name)) &&
	    ! expr->e_const->c_constructor)
		expr->e_class = E_CONST;
	else {
		expr->e_class = E_VAR;
		expr->e_vname = name;
	}
	return expr;
}

/*
 *	Identifier occurring in an operator position in a pattern.
 *	It must be a constructor.
 */
global EXPR *
id_cons(name)
	STRING	name;
{
reg	EXPR	*expr;
reg	CONS	*cp;

	if ((cp = cons_lookup(name)) && cp->c_constructor) {
		expr = NEW(EXPR);
		expr->e_class = E_CONS;
		expr->e_const = cp;
		return expr;
	}
	else {
		error(SEMERR, "unknown constructor '%s'", name);
		return (EXPR *)0;
	}
}

/*
 *	An identifier occurring as an expression.
 *	Call it a variable for now; we'll find out what it really is later.
 */
global EXPR *
id_expr(name)
	STRING	name;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_VAR;
	expr->e_vname = name;
	return expr;
}

global EXPR *
dir_expr(where)
	PATH	where;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_PARAM;
	expr->e_level = 0;
	expr->e_where = p_stash(p_reverse(where));
	return expr;
}

global EXPR *
pair_expr(left, right)
	EXPR	*left, *right;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_PAIR;
	expr->e_left = left;
	expr->e_right = right;
	return expr;
}

global EXPR *
apply_expr(func, arg)
	EXPR	*func, *arg;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_APPLY;
	expr->e_func = func;
	expr->e_arg = arg;
	return expr;
}

global EXPR *
func_expr(branches)
reg	BRANCH	*branches;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_LAMBDA;
	expr->e_branch = branches;
	expr->e_expr = NOMATCH;
	for ( ; branches; branches = branches->br_next)
		expr->e_expr = compile(expr->e_expr,
				       branches->br_pattern,
				       branches->br_expr);
	return expr;
}

/*
 *	Representation of various other structures.
 */

global EXPR *
ite_expr(if_expr, then_expr, else_expr)
	EXPR	*if_expr, *then_expr, *else_expr;
{
	BRANCH	*branchlist;

	branchlist = cons_branch(new_branch(e_true, then_expr),
				 new_branch(e_false, else_expr));
	if_expr = apply_expr(func_expr(branchlist), if_expr);
	if_expr->e_class = E_IF;
	if_expr->e_func->e_class = E_THEN;
	return if_expr;
}

global EXPR *
let_expr(pattern, subexpr, expr)
	EXPR	*pattern, *subexpr, *expr;
{
	expr = apply_expr(func_expr(new_branch(pattern, expr)), subexpr);
	expr->e_class = E_LET;
	expr->e_func->e_class = E_EQN;
	return expr;
}

global EXPR *
where_expr(expr, pattern, subexpr)
	EXPR	*expr, *pattern, *subexpr;
{
	expr = apply_expr(func_expr(new_branch(pattern, expr)), subexpr);
	expr->e_class = E_WHERE;
	expr->e_func->e_class = E_EQN;
	return expr;
}

global EXPR *
presection(operator, arg)
	STRING	operator;
	EXPR	*arg;
{
	return func_expr(new_branch(id_pattern(bound_variable),
		apply_expr(id_expr(operator),
			pair_expr(arg, id_expr(bound_variable)))));
}

global EXPR *
postsection(operator, arg)
	STRING	operator;
	EXPR	*arg;
{
	return func_expr(new_branch(id_pattern(bound_variable),
		apply_expr(id_expr(operator),
			pair_expr(id_expr(bound_variable), arg))));
}

/*
 *	Kinds of expression created by compilation of patterns.
 */

global EXPR *
ucase_expr(path, cases)
	PATH	path;
	EXPR	*cases;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_UCASE;
	expr->e_path = path;
	expr->e_cases = cases;
	return expr;
}

global EXPR *
lcase_expr(arity)
reg	int	arity;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_LCASE;
	expr->e_arity = arity;
	expr->e_limbs = NEWARRAY(EXPR *, arity);
	while (arity--)
		expr->e_limbs[arity] = NOMATCH;
	return expr;
}

global EXPR *
ncase_expr()
{
reg	EXPR	*expr;

	expr = lcase_expr(3);
	expr->e_class = E_NCASE;
	return expr;
}

global EXPR *
ccase_expr(ch)
	char	ch;
{
reg	EXPR	*expr;

	expr = lcase_expr(2);
	expr->e_class = E_CCASE;
	expr->e_cchar = ch;
	return expr;
}

/*
 *	Kinds of expression used to represent built-in functions.
 */

global EXPR *
strict_expr(real)
	EXPR	*real;
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_STRICT;
	expr->e_real = real;
	return expr;
}

global EXPR *
builtin_expr(fn)
	CELL	*(*fn)();
{
reg	EXPR	*expr;

	expr = NEW(EXPR);
	expr->e_class = E_BUILTIN;
	expr->e_fn = fn;
	return expr;
}
/*
 *	Branches of lambdas or defined functions.
 */

global BRANCH *
new_branch(pattern, expr)
	EXPR	*pattern;
	EXPR	*expr;
{
reg	BRANCH	*branch;

	branch = NEW(BRANCH);
	branch->br_pattern = pattern;
	branch->br_expr = expr;
	branch->br_nvars = 0;
	branch->br_next = (BRANCH *)0;
	return branch;
}

global BRANCH *
cons_branch(branch, branchlist)
	BRANCH	*branch, *branchlist;
{
	branch->br_next = branchlist;
	return branch;
}

/*
 *	Defined functions and constants
 */

global void
decl_func(name, type)
	STRING	name;
	TYPE	*type;
{
	if (erroneous)
		return;
	if (fn_local(name))
		error(SEMERR, "function '%s' redeclared", name);
	else {
		new_fn(name, type);
		preserve();
	}
}

global void
def_cons(name, expr)
	STRING	name;
	EXPR	*expr;
{
reg	FUNC	*fn;

	if (erroneous)
		return;
	if ((fn = fn_local(name)) == (FUNC *)0)
		error(SEMERR, "function '%s' not declared", name);
	else if (fn->f_body != NOMATCH)
		error(SEMERR, "attempt to redefine '%s'", name);
	else if (nr_expr(expr) && chk_const(expr, fn)) {
		fn->f_body = expr;
		preserve();
	}
}

global void
define(name, branch)
	STRING	name;
	BRANCH	*branch;
{
reg	FUNC	*fn;
reg	BRANCH	*br;

	if (erroneous)
		return;
	if ((fn = fn_local(name)) == (FUNC *)0)
		error(SEMERR, "function '%s' not declared", name);
	else if (fn->f_branch == (BRANCH *)0 && fn->f_body != NOMATCH)
		error(SEMERR, "attempt to redefine '%s'", name);
	else if (nr_branch(branch) && chk_func(branch, fn)) {
		fn->f_body = compile(fn->f_body,
				     branch->br_pattern,
				     branch->br_expr);
		/* add the branch at the end */
		if (fn->f_branch == (BRANCH *)0)
			fn->f_branch = branch;
		else {
			for (br = fn->f_branch; br->br_next; br = br->br_next)
				;
			br->br_next = branch;
		}
		preserve();
	}
}
