#ifndef PATH_H
#define PATH_H

#include "defs.h"

typedef char	*PATH;
#define MAXPATH		40

#define P_END		0
#define P_LEFT		1
#define P_RIGHT		2
#define P_STRIP		3
#define P_PRED		4
#define P_UNROLL	5

#define	P_EMPTY		""

#define p_equal(p1,p2)	(strcmp(p1, p2) == 0)
#define	p_empty(p)	(*(p) == P_END)
#define p_pop(p)	((p)+1)
#define p_top(p)	(*(p))

extern	PATH	p_new();	/* (void) */
extern	PATH	p_push();	/* (int dir, PATH p) */
extern	PATH	p_stash();	/* (PATH p) */
extern	PATH	p_save();	/* (char **bp, PATH p) */
extern	PATH	p_reverse();	/* (PATH p) */

#endif	PATH_H
