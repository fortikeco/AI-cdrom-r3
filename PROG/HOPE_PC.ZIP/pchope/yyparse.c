extern char *malloc(), *realloc();

# line 2 "y.tab.y"
#include "defs.h"
#include "memory.h"
#include "typevar.h"
#include "op.h"
#include "strings.h"
#include "deftype.h"
#include "cell.h"
#include "module.h"
#include "error.h"

# line 59 "y.tab.y"
typedef union  {
	long	longval;
	int	intval;
	char	*textval;
	STRING	strval;
	char	charval;
	TVAR	*tvar;
	TYPE	*type;
	DEFTYPE	*deftype;
	EXPR	*expr;
	BRANCH	*branch;
	MODULE	*module;
	CONS	*cons;
} YYSTYPE;

extern	void	yyerror();
extern	void	wr_expr();

# define TYPEVAR 257
# define ABSTYPE 258
# define DATA 259
# define TYPESYM 260
# define DEC 261
# define INFIX 262
# define INFIXRL 263
# define USE 264
# define PRIVATE 265
# define ENDFILE 266
# define DISPLAY 267
# define SAVE 268
# define WRITE 269
# define TO 270
# define EXIT 271
# define EDIT 272
# define EQ 273
# define VALOF 274
# define IS 275
# define THEN 276
# define OR 277
# define GIVES 278
# define WHERE 279
# define IN 280
# define ELSE 281
# define BINARY1 282
# define RBINARY1 283
# define BINARY2 284
# define RBINARY2 285
# define BINARY3 286
# define RBINARY3 287
# define BINARY4 288
# define RBINARY4 289
# define BINARY5 290
# define RBINARY5 291
# define BINARY6 292
# define RBINARY6 293
# define BINARY7 294
# define RBINARY7 295
# define BINARY8 296
# define RBINARY8 297
# define BINARY9 298
# define RBINARY9 299
# define BINARY10 300
# define RBINARY10 301
# define APPLY 302
# define IF 303
# define LAMBDA 304
# define IDENT 305
# define NUMBER 306
# define TEXT 307
# define CHAR 308
# define LET 309
# define END 310
# define NONOP 311
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256
extern	int yyexca[];
# define YYNPROD 232
# define YYLAST 1934
extern	int yyact[], yypact[];
extern	int yypgo[];
extern	int yyr1[], yyr2[];
extern	int yychk[];
extern	int yydef[];

#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG
extern	yytoktype yytoks[];
extern	char *yyreds[];
#endif /* YYDEBUG */
#line 1 "/usr/lib/yaccpar"
/*	@(#)yaccpar 1.10 89/04/04 SMI; from S5R3 1.10	*/

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	{ free(yys); free(yyv); return(0); }
#define YYABORT		{ free(yys); free(yyv); return(1); }
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( "syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-1000)

/*
** static variables used by the parser
*/
static YYSTYPE *yyv;			/* value stack */
static int *yys;			/* state stack */

static YYSTYPE *yypv;			/* top of value stack */
static int *yyps;			/* top of state stack */

static int yystate;			/* current state */
static int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */

int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */


/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
int
yyparse()
{
	register YYSTYPE *yypvt;	/* top of value stack for $vars */
	unsigned yymaxdepth = YYMAXDEPTH;

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yyv = (YYSTYPE*)malloc(yymaxdepth*sizeof(YYSTYPE));
	yys = (int*)malloc(yymaxdepth*sizeof(int));
	if (!yyv || !yys)
	{
		yyerror( "out of memory" );
		return(1);
	}
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

	goto yystack;
	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			(void)printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			int yyps_index = (yy_ps - yys);
			int yypv_index = (yy_pv - yyv);
			int yypvt_index = (yypvt - yyv);
			yymaxdepth += YYMAXDEPTH;
			yyv = (YYSTYPE*)realloc((char*)yyv,
				yymaxdepth * sizeof(YYSTYPE));
			yys = (int*)realloc((char*)yys,
				yymaxdepth * sizeof(int));
			if (!yyv || !yys)
			{
				yyerror( "yacc stack overflow" );
				return(1);
			}
			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			(void)printf( "Received token " );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				(void)printf( "Received token " );
				if ( yychar == 0 )
					(void)printf( "end-of-file\n" );
				else if ( yychar < 0 )
					(void)printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					(void)printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( "syntax error" );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				yynerrs++;
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						(void)printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					(void)printf( "Error recovery discards " );
					if ( yychar == 0 )
						(void)printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						(void)printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						(void)printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			(void)printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 1:
# line 93 "y.tab.y"
{ clean_slate(); erroneous = FALSE; } break;
case 3:
# line 97 "y.tab.y"
{ mod_fetch(); } break;
case 4:
# line 98 "y.tab.y"
{ yyerrok; } break;
case 5:
# line 99 "y.tab.y"
{ mod_finish(); } break;
case 6:
# line 100 "y.tab.y"
{ yyerrok; mod_finish(); } break;
case 8:
# line 104 "y.tab.y"
{ preserve(); } break;
case 9:
# line 106 "y.tab.y"
{ preserve(); } break;
case 10:
# line 107 "y.tab.y"
{ abstype(yypvt[-0].deftype); } break;
case 11:
# line 109 "y.tab.y"
{ type_syn(yypvt[-2].deftype, yypvt[-0].type); } break;
case 12:
# line 111 "y.tab.y"
{ decl_type(yypvt[-2].deftype, yypvt[-0].cons); } break;
case 13:
# line 112 "y.tab.y"
{ private(); } break;
case 15:
# line 115 "y.tab.y"
{ def_cons(yypvt[-2].strval, yypvt[-0].expr); } break;
case 16:
# line 117 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 17:
# line 119 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 18:
# line 122 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 19:
# line 125 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 20:
# line 128 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 21:
# line 131 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 22:
# line 134 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 23:
# line 137 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 24:
# line 140 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 25:
# line 143 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 26:
# line 146 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 27:
# line 149 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 28:
# line 152 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 29:
# line 155 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 30:
# line 158 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 31:
# line 161 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 32:
# line 164 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 33:
# line 167 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 34:
# line 170 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 35:
# line 173 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 36:
# line 176 "y.tab.y"
{ define(yypvt[-3].strval, new_branch(pair_expr(yypvt[-4].expr, yypvt[-2].expr),
							yypvt[-0].expr)); } break;
case 37:
# line 178 "y.tab.y"
{ eval_expr(yypvt[-0].expr); } break;
case 38:
# line 179 "y.tab.y"
{ wr_expr(yypvt[-0].expr, (char *)0); } break;
case 39:
# line 181 "y.tab.y"
{ wr_expr(yypvt[-2].expr, yypvt[-0].textval); } break;
case 40:
# line 182 "y.tab.y"
{ display(stdout); } break;
case 41:
# line 183 "y.tab.y"
{ preserve(); } break;
case 42:
# line 184 "y.tab.y"
{ mod_save(yypvt[-0].strval); } break;
case 43:
# line 185 "y.tab.y"
{ edit_script((char *)0); } break;
case 44:
# line 186 "y.tab.y"
{ edit_script(yypvt[-0].strval); } break;
case 45:
# line 187 "y.tab.y"
{ YYACCEPT; } break;
case 46:
# line 190 "y.tab.y"
{ tv_declare(yypvt[-0].strval); } break;
case 47:
# line 192 "y.tab.y"
{ tv_declare(yypvt[-0].strval); } break;
case 48:
# line 196 "y.tab.y"
{ op_declare(yypvt[-2].strval, yypvt[-0].intval, ASSOC_LEFT); yyval.intval = yypvt[-0].intval; } break;
case 49:
# line 198 "y.tab.y"
{ op_declare(yypvt[-2].strval, yypvt[-0].intval, ASSOC_LEFT); yyval.intval = yypvt[-0].intval; } break;
case 50:
# line 202 "y.tab.y"
{ op_declare(yypvt[-2].strval, yypvt[-0].intval, ASSOC_RIGHT); yyval.intval = yypvt[-0].intval; } break;
case 51:
# line 204 "y.tab.y"
{ op_declare(yypvt[-2].strval, yypvt[-0].intval, ASSOC_RIGHT); yyval.intval = yypvt[-0].intval; } break;
case 52:
# line 207 "y.tab.y"
{ yyval.intval = (int)yypvt[-0].longval; } break;
case 53:
# line 210 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-0].strval, (TYPE *)0); } break;
case 54:
# line 211 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval, new_tv(yypvt[-0].tvar)); } break;
case 55:
# line 213 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-3].strval, yypvt[-1].type); } break;
case 56:
# line 214 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 57:
# line 216 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 58:
# line 218 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 59:
# line 220 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 60:
# line 222 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 61:
# line 224 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 62:
# line 226 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 63:
# line 228 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 64:
# line 230 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 65:
# line 232 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 66:
# line 234 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 67:
# line 236 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 68:
# line 238 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 69:
# line 240 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 70:
# line 242 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 71:
# line 244 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 72:
# line 246 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 73:
# line 248 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 74:
# line 250 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 75:
# line 252 "y.tab.y"
{ yyval.deftype = new_deftype(yypvt[-1].strval,
					cons_type(new_tv(yypvt[-2].tvar), new_tv(yypvt[-0].tvar))); } break;
case 76:
# line 256 "y.tab.y"
{ yyval.type = new_tv(yypvt[-0].tvar); } break;
case 77:
# line 257 "y.tab.y"
{ yyval.type = cons_type(new_tv(yypvt[-2].tvar), yypvt[-0].type); } break;
case 78:
# line 260 "y.tab.y"
{ yyval.tvar = tv_lookup(yypvt[-0].strval, TRUE); } break;
case 79:
# line 263 "y.tab.y"
{ yyval.cons = yypvt[-0].cons; } break;
case 80:
# line 265 "y.tab.y"
{ yyval.cons = alt_cons(yypvt[-2].cons, yypvt[-0].cons); } break;
case 81:
# line 268 "y.tab.y"
{ yyval.cons = constant(yypvt[-0].strval); } break;
case 82:
# line 269 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, yypvt[-0].type); } break;
case 83:
# line 271 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 84:
# line 273 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 85:
# line 275 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 86:
# line 277 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 87:
# line 279 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 88:
# line 281 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 89:
# line 283 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 90:
# line 285 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 91:
# line 287 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 92:
# line 289 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 93:
# line 291 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 94:
# line 293 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 95:
# line 295 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 96:
# line 297 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 97:
# line 299 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 98:
# line 301 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 99:
# line 303 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 100:
# line 305 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 101:
# line 307 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 102:
# line 309 "y.tab.y"
{ yyval.cons = constructor(yypvt[-1].strval, pair_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 103:
# line 312 "y.tab.y"
{ mod_use(yypvt[-0].module); } break;
case 104:
# line 314 "y.tab.y"
{ mod_use(yypvt[-0].module); } break;
case 105:
# line 317 "y.tab.y"
{ yyval.module = module(yypvt[-0].strval); } break;
case 106:
# line 320 "y.tab.y"
{ yyval.type = id_type(yypvt[-0].strval); } break;
case 107:
# line 321 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, yypvt[-0].type); } break;
case 108:
# line 323 "y.tab.y"
{ yyval.type = new_type(yypvt[-5].strval, cons_type(yypvt[-3].type, yypvt[-1].type)); } break;
case 109:
# line 325 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 110:
# line 327 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 111:
# line 329 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 112:
# line 331 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 113:
# line 333 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 114:
# line 335 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 115:
# line 337 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 116:
# line 339 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 117:
# line 341 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 118:
# line 343 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 119:
# line 345 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 120:
# line 347 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 121:
# line 349 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 122:
# line 351 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 123:
# line 353 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 124:
# line 355 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 125:
# line 357 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 126:
# line 359 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 127:
# line 361 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 128:
# line 363 "y.tab.y"
{ yyval.type = new_type(yypvt[-1].strval, cons_type(yypvt[-2].type, yypvt[-0].type)); } break;
case 129:
# line 364 "y.tab.y"
{ yyval.type = yypvt[-1].type; } break;
case 130:
# line 367 "y.tab.y"
{ yyval.type = yypvt[-0].type; } break;
case 131:
# line 369 "y.tab.y"
{ yyval.type = cons_type(yypvt[-2].type, yypvt[-0].type); } break;
case 132:
# line 372 "y.tab.y"
{ decl_func(yypvt[-2].strval, yypvt[-0].type); yyval.type = yypvt[-0].type; } break;
case 133:
# line 373 "y.tab.y"
{ decl_func(yypvt[-2].strval, yypvt[-0].type); yyval.type = yypvt[-0].type; } break;
case 134:
# line 376 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 135:
# line 377 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 136:
# line 380 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 137:
# line 381 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 138:
# line 382 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 139:
# line 383 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 140:
# line 384 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 141:
# line 385 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 142:
# line 386 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 143:
# line 387 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 144:
# line 388 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 145:
# line 389 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 146:
# line 390 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 147:
# line 391 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 148:
# line 392 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 149:
# line 393 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 150:
# line 394 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 151:
# line 395 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 152:
# line 396 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 153:
# line 397 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 154:
# line 398 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 155:
# line 399 "y.tab.y"
{ yyval.strval = yypvt[-0].strval; } break;
case 156:
# line 402 "y.tab.y"
{ yyval.expr = id_pattern(yypvt[-0].strval); } break;
case 157:
# line 403 "y.tab.y"
{ yyval.expr = num_expr(yypvt[-0].longval); } break;
case 158:
# line 404 "y.tab.y"
{ yyval.expr = text_expr(yypvt[-0].textval); } break;
case 159:
# line 405 "y.tab.y"
{ yyval.expr = char_expr(yypvt[-0].charval); } break;
case 160:
# line 406 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval), yypvt[-0].expr); } break;
case 161:
# line 408 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 162:
# line 411 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 163:
# line 414 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 164:
# line 417 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 165:
# line 420 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 166:
# line 423 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 167:
# line 426 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 168:
# line 429 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 169:
# line 432 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 170:
# line 435 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 171:
# line 438 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 172:
# line 441 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 173:
# line 444 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 174:
# line 447 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 175:
# line 450 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 176:
# line 453 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 177:
# line 456 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 178:
# line 459 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 179:
# line 462 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 180:
# line 465 "y.tab.y"
{ yyval.expr = apply_expr(id_cons(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 181:
# line 468 "y.tab.y"
{ yyval.expr = yypvt[-1].expr; } break;
case 182:
# line 470 "y.tab.y"
{ yyval.expr = yypvt[-1].expr; } break;
case 183:
# line 471 "y.tab.y"
{ yyval.expr = e_nil; } break;
case 184:
# line 474 "y.tab.y"
{ yyval.expr = yypvt[-0].expr; } break;
case 185:
# line 476 "y.tab.y"
{ yyval.expr = pair_expr(yypvt[-2].expr, yypvt[-0].expr); } break;
case 186:
# line 479 "y.tab.y"
{ yyval.expr = apply_expr(e_cons,
						  pair_expr(yypvt[-0].expr, e_nil));
				} break;
case 187:
# line 483 "y.tab.y"
{ yyval.expr = apply_expr(e_cons,
						  pair_expr(yypvt[-2].expr, yypvt[-0].expr));
				} break;
case 188:
# line 488 "y.tab.y"
{ yyval.expr = id_expr(yypvt[-0].strval); } break;
case 189:
# line 489 "y.tab.y"
{ yyval.expr = num_expr(yypvt[-0].longval); } break;
case 190:
# line 490 "y.tab.y"
{ yyval.expr = text_expr(yypvt[-0].textval); } break;
case 191:
# line 491 "y.tab.y"
{ yyval.expr = char_expr(yypvt[-0].charval); } break;
case 192:
# line 492 "y.tab.y"
{ yyval.expr = id_expr(yypvt[-0].strval); } break;
case 193:
# line 493 "y.tab.y"
{ yyval.expr = id_expr(yypvt[-1].strval); } break;
case 194:
# line 495 "y.tab.y"
{ yyval.expr = presection(yypvt[-1].strval, yypvt[-2].expr); } break;
case 195:
# line 497 "y.tab.y"
{ yyval.expr = postsection(yypvt[-2].strval, yypvt[-1].expr); } break;
case 196:
# line 499 "y.tab.y"
{ yyval.expr = yypvt[-1].expr; } break;
case 197:
# line 501 "y.tab.y"
{ yyval.expr = yypvt[-1].expr; } break;
case 198:
# line 502 "y.tab.y"
{ yyval.expr = e_nil; } break;
case 199:
# line 504 "y.tab.y"
{ yyval.expr = apply_expr(yypvt[-1].expr, yypvt[-0].expr); } break;
case 200:
# line 506 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 201:
# line 509 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 202:
# line 512 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 203:
# line 515 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 204:
# line 518 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 205:
# line 521 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 206:
# line 524 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 207:
# line 527 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 208:
# line 530 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 209:
# line 533 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 210:
# line 536 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 211:
# line 539 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 212:
# line 542 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 213:
# line 545 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 214:
# line 548 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 215:
# line 551 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 216:
# line 554 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 217:
# line 557 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 218:
# line 560 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 219:
# line 563 "y.tab.y"
{ yyval.expr = apply_expr(id_expr(yypvt[-1].strval),
						pair_expr(yypvt[-2].expr, yypvt[-0].expr)); } break;
case 220:
# line 565 "y.tab.y"
{ yyval.expr = func_expr(yypvt[-0].branch); } break;
case 221:
# line 567 "y.tab.y"
{ yyval.expr = func_expr(yypvt[-1].branch); } break;
case 222:
# line 569 "y.tab.y"
{ yyval.expr = ite_expr(yypvt[-4].expr, yypvt[-2].expr, yypvt[-0].expr); } break;
case 223:
# line 571 "y.tab.y"
{ yyval.expr = let_expr(yypvt[-4].expr, yypvt[-2].expr, yypvt[-0].expr); } break;
case 224:
# line 573 "y.tab.y"
{ yyval.expr = where_expr(yypvt[-4].expr, yypvt[-2].expr, yypvt[-0].expr); } break;
case 225:
# line 576 "y.tab.y"
{ yyval.expr = yypvt[-0].expr; } break;
case 226:
# line 578 "y.tab.y"
{ yyval.expr = pair_expr(yypvt[-2].expr, yypvt[-0].expr); } break;
case 227:
# line 581 "y.tab.y"
{ yyval.expr = apply_expr(e_cons,
						  pair_expr(yypvt[-0].expr, e_nil));
				} break;
case 228:
# line 585 "y.tab.y"
{ yyval.expr = apply_expr(e_cons,
						  pair_expr(yypvt[-2].expr, yypvt[-0].expr));
				} break;
case 229:
# line 591 "y.tab.y"
{ yyval.branch = yypvt[-0].branch; } break;
case 230:
# line 593 "y.tab.y"
{ yyval.branch = cons_branch(yypvt[-2].branch, yypvt[-0].branch); } break;
case 231:
# line 597 "y.tab.y"
{ yyval.branch = new_branch(yypvt[-2].expr, yypvt[-0].expr); } break;
	}
	goto yystack;		/* reset registers in driver code */
}
