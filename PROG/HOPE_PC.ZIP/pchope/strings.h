#ifndef STRINGS_H
#define STRINGS_H

/*
 *	Heap storage for strings.
 *	Each string is assigned a unique address, so that direct address
 *	comparisons can be used for string equality tests.
 */

typedef	char	*STRING;

extern	STRING	newstring();	/* (char *s) */

#endif STRINGS_H
