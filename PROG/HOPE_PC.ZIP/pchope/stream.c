#include "defs.h"
#include "error.h"
#include "expr.h"
#include "cell.h"

#define	MAXSTREAMS	20

/*
 * Table of open streams,
 * so we can close any left open at the end of evaluation.
 */
local	FILE	*str_table[MAXSTREAMS];

local	CELL	*read_line();
local	void	end_stream();

global CELL *
open_stream(arg)
reg	CELL	*arg;
{
	char	filename[100];
reg	char	*s;
reg	FILE	**fp;

	/* get the file name string */
	s = filename;
	for ( ; arg->c_cons != nil; arg = arg->c_arg->c_right)
		*s++ = arg->c_arg->c_left->c_char;
	*s = '\0';
	/* find a free slot in the stream table */
	for (fp = str_table; *fp; fp++)
		if (fp == &str_table[MAXSTREAMS]) {
			error(EXECERR, "stream table full");
			return (CELL *)0;
		}
	/* try to open the file */
	if ((*fp = fopen(filename, "r")) == (FILE *)0) {
		error(EXECERR, "can't read file '%s'", filename);
		return (CELL *)0;
	}
	return new_stream(*fp);
}

global CELL *
read_stream(cell)
reg	CELL	*cell;
{
reg	int	c;

	if (cell->c_file == stdin)
		return read_line();
	if ((c = getc(cell->c_file)) == EOF) {
		end_stream(cell->c_file);
		return new_cnst(nil);
	}
	return new_cons(cons,
		new_pair(new_char(c), new_stream(cell->c_file)));
}

/*
 * Read a line from standard input and build the list of characters,
 * adding the newline stripped by gets().
 *
 * We read a whole line, not just a character at a time, because
 *  (1) if not all the input is used, we want to discard the rest of the
 *	last line input.
 *  (2)	some environments (e.g. LightSpeed C on the Macintosh) don't support
 *	terminal input in the usual way (see gets.c).
 */
local CELL *
read_line()
{
reg	CELL	*cell;
reg	char	*lp;
	char	line[100];

	if (gets(line) == (char *)0) {
		clearerr(stdin);
		return new_cnst(nil);
	}
	cell = new_cons(cons, new_pair(new_char('\n'), new_stream(stdin)));
	lp = line + strlen(line);
	while (lp > line)
		cell = new_cons(cons, new_pair(new_char(*--lp), cell));
	return cell;
}

local void
end_stream(f)
reg	FILE	*f;
{
reg	FILE	**fp;

	fclose(f);
	for (fp = str_table; *fp != f; fp++)
		;
	*fp = (FILE *)0;
}

global void
close_streams()
{
reg	FILE	**fp;

	for (fp = str_table; fp != &str_table[MAXSTREAMS]; fp++)
		if (*fp) {
			fclose(*fp);
			*fp = (FILE *)0;
		}
}
