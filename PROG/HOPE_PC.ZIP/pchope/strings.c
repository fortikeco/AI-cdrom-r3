#include "defs.h"
#include "memory.h"
#include "strings.h"

#define TABSIZ	293		/* should be prime */

#define	IDENT	struct _IDENT
IDENT {
	IDENT	*link;
	char	text[sizeof(WORD)];	/* stub for size purposes */
};
#define	SizeIDENT(s)	(sizeof(IDENT) - sizeof(WORD) + 1 + strlen(s))

local	IDENT	*table[TABSIZ];
extern	natural	hash();

global STRING
newstring(s)
reg	char	*s;
{
reg	IDENT	*n, **p;

	p = &table[hash(s)];
	for (n = *p; n != (IDENT *)0; n = n->link)
		if (strcmp(n->text, s) == 0)
			return(n->text);
	n = (IDENT *)s_alloc((natural)SizeIDENT(s));
	n->link = *p;
	*p = n;
	strcpy(n->text, s);
	return n->text;
}

local natural
hash(s)
reg	char	*s;
{
reg	natural	i = 0;
reg	int	c;

	while (c = *s++) {
		i *= 167;
		i ^= c;
	}
	return i%TABSIZ;
}
