#include "defs.h"
#include "expr.h"
#include "cell.h"
#include "op.h"
#include "deftype.h"

extern	EXPR	*val_deref();

local	void	pr_f_expr(), pr_lambda(), pr_elist(), pr_string();
local	bool	is_list(), is_string();
local	EXPR	*var_deref();

/*
 *	Printing of functions.
 */

global void
pr_fdecl(f, fn)
	FILE	*f;
	FUNC	*fn;
{
	fprintf(f, "dec %s : ", fn->f_name);
	pr_type(f, fn->f_type);
	fprintf(f, ";\n");
}

global void
pr_fundef(f, fn)
	FILE	*f;
	FUNC	*fn;
{
reg	BRANCH	*br;

	if (fn->f_branch)
		for (br = fn->f_branch; br; br = br->br_next) {
			fprintf(f, "--- ");
			pr_f_expr(f, fn->f_name, br->br_pattern, 0);
			fprintf(f, " <= ");
			pr_expr(f, br->br_expr, 1, PREC_BODY);
			fprintf(f, ";\n");
		}
	else if (fn->f_body != NOMATCH) {
		fprintf(f, "--- %s <= ", fn->f_name);
		pr_expr(f, fn->f_body, 0, PREC_BODY);
		fprintf(f, ";\n");
	}
}

local void
pr_f_expr(f, name, arg, level)
	FILE	*f;
	STRING	name;
	EXPR	*arg;
	int	level;
{
	OP	*op;

	if (op = op_lookup(name))
		if (arg->e_class == E_PAIR) {
			pr_expr(f, arg->e_left, level, LeftPrec(op));
			fprintf(f, " %s ", name);
			pr_expr(f, arg->e_right, level, RightPrec(op));
		}
		else if (arg->e_class == E_PARAM && arg->e_level >= level)
			pr_f_actual(f, name,
				arg->e_level - level, arg->e_where);
		else {
			fprintf(f, "(%s) ", name);
			pr_expr(f, arg, level, PREC_APPLY+1);
		}
	else {
		fprintf(f, "%s ", name);
		pr_expr(f, arg, level, PREC_APPLY+1);
	}
}

global void
pr_expr(f, expr, level, context)
	FILE	*f;
	EXPR	*expr;
	int	level, context;
{
	int	prec;
	EXPR	*func;

	prec = precedence(expr);
	if (prec < context)
		fprintf(f, "(");
	switch (expr->e_class) {
	when E_PAIR:
		pr_expr(f, expr->e_left, level, PREC_PAIR+1);
		fprintf(f, ", ");
		pr_expr(f, expr->e_right, level, PREC_PAIR);
	when E_APPLY:
		if (is_list(expr))
			if (is_string(expr))
				pr_string(f, expr);
			else
				pr_elist(f, expr, level);
		else {
			func = var_deref(expr->e_func, level);
			if (func->e_class == E_DEFUN)
				pr_f_expr(f, func->e_defun->f_name,
					expr->e_arg, level);
			else if (func->e_class == E_CONS)
				pr_f_expr(f, func->e_const->c_name,
					expr->e_arg, level);
			else {
				pr_expr(f, func, level, PREC_APPLY);
				fprintf(f, " ");
				pr_expr(f, expr->e_arg, level, PREC_APPLY+1);
			}
		}
	when E_IF:
		fprintf(f, "if ");
		pr_expr(f, expr->e_arg, level, PREC_BODY);
		fprintf(f, " then ");
		pr_expr(f, expr->e_func->e_branch->br_expr,
			level+1, PREC_BODY);
		fprintf(f, " else ");
		pr_expr(f, expr->e_func->e_branch->br_next->br_expr,
			level+1, PREC_IF);
	when E_WHERE:
		pr_expr(f, expr->e_func->e_branch->br_expr, level+1, prec);
		fprintf(f, " where ");
		pr_expr(f, expr->e_func->e_branch->br_pattern,
			level+1, PREC_BODY);
		fprintf(f, " == ");
		pr_expr(f, expr->e_arg, level, PREC_WHERE);
	when E_LET:
		fprintf(f, "let ");
		pr_expr(f, expr->e_func->e_branch->br_pattern,
			level+1, PREC_BODY);
		fprintf(f, " == ");
		pr_expr(f, expr->e_arg, level, PREC_BODY);
		fprintf(f, " in ");
		pr_expr(f, expr->e_func->e_branch->br_expr,
			level+1, PREC_LET);
	when E_LAMBDA:
		pr_lambda(f, expr->e_branch, level);
	when E_NUM:
		fprintf(f, "%ld", expr->e_num);
	when E_CHAR:
		fprintf(f, "'");
		pr_char(f, expr->e_char);
		fprintf(f, "'");
	when E_DEFUN:
		fprintf(f, "%s", expr->e_defun->f_name);
	when E_CONS or E_CONST:
		fprintf(f, "%s", expr->e_const->c_name);
	when E_PARAM:
		if (expr->e_level < level)
			pr_expr(f, expr->e_patt, 0, context);
		else
			pr_actual(f, expr->e_level - level,
				expr->e_where, context);
	when E_VAR:
		fprintf(f, "%s", expr->e_vname);
	}
	if (prec < context)
		fprintf(f, ")");
}

local bool
is_list(expr)
reg	EXPR	*expr;
{
	while (expr->e_class == E_APPLY &&
	       expr->e_func->e_class == E_CONS &&
	       expr->e_func->e_const == cons &&
	       expr->e_arg->e_class == E_PAIR)
		expr = expr->e_arg->e_right;
	return expr->e_class == E_CONST && expr->e_const == nil;
}

/*
 *	Is expr a string?  (We already know it's a list)
 */
local bool
is_string(expr)
reg	EXPR	*expr;
{
	while (expr->e_const != nil && expr->e_arg->e_left->e_class == E_CHAR)
		expr = expr->e_arg->e_right;
	return expr->e_const == nil;
}

local void
pr_string(f, expr)
	FILE	*f;
reg	EXPR	*expr;
{
	fprintf(f, "\"");
	while (expr->e_const != nil) {
		pr_char(f, expr->e_arg->e_left->e_char);
		expr = expr->e_arg->e_right;
	}
	fprintf(f, "\"");
}

global void
pr_char(f, c)
	FILE	*f;
	int	c;
{
	switch (c) {
	when '\b': fprintf(f, "\\b");
	when '\n': fprintf(f, "\\n");
	when '\t': fprintf(f, "\\t");
	otherwise: fprintf(f, "%c", c);
	}
}

local void
pr_elist(f, expr, level)
	FILE	*f;
reg	EXPR	*expr;
	int	level;
{
	fprintf(f, "[");
	for (;;) {
		pr_expr(f, expr->e_arg->e_left, level, PREC_BODY);
		expr = expr->e_arg->e_right;
		if (expr->e_const == nil)
			break;
		fprintf(f, ", ");
	}
	fprintf(f, "]");
}

local void
pr_lambda(f, branch, level)
	FILE	*f;
	BRANCH	*branch;
	int	level;
{
	fprintf(f, "lambda ");
	while (branch) {
		pr_expr(f, branch->br_pattern, level+1, PREC_BODY);
		fprintf(f, " => ");
		pr_expr(f, branch->br_expr, level+1, PREC_BODY);
		branch = branch->br_next;
		if (branch)
			fprintf(f, " | ");
	}
}

/*
 *	If expr is a variable which is currently bound to an expression,
 *	return the expression; otherwise return expr.
 */
local EXPR *
var_deref(expr, level)
reg	EXPR	*expr;
	int	level;
{
	EXPR	*newexpr;

	if (expr->e_class == E_PARAM && expr->e_level >= level &&
	    (newexpr = val_deref(expr->e_level - level, expr->e_where)))
		return newexpr;
	return expr;
}

global int
precedence(expr)
reg	EXPR	*expr;
{
	OP	*op;

	switch (expr->e_class) {
	when E_PAIR:
		return PREC_PAIR;
	when E_LAMBDA:
		return PREC_LAMBDA;
	when E_WHERE:
		return PREC_WHERE;
	when E_LET:
		return PREC_LET;
	when E_IF:
		return PREC_IF;
	when E_APPLY:
		if (expr->e_arg->e_class == E_PAIR &&
		    (expr->e_func->e_class == E_CONS &&
		     (op = op_lookup(expr->e_func->e_const->c_name)) ||
		     expr->e_func->e_class == E_DEFUN &&
		     (op = op_lookup(expr->e_func->e_defun->f_name))))
			return op->op_prec;
		return PREC_APPLY;
	when E_CONS:
		if (op_lookup(expr->e_const->c_name))
			return PREC_INFIX;
	when E_DEFUN:
		if (op_lookup(expr->e_defun->f_name))
			return PREC_INFIX;
	}
	return PREC_ATOMIC;
}
