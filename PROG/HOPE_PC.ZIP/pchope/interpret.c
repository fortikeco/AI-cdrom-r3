#include "defs.h"
#include "memory.h"
#include "expr.h"
#include "cell.h"
#include "error.h"
#include "path.h"
#include <signal.h>

#ifdef EBUG
#	define	DEBUG(fmt)	fprintf(stderr, fmt)
#	define	DEBUG2(fmt,arg)	fprintf(stderr, fmt, arg)
#	define	DEBUGV(v)	pr_value(stderr, v)
#else
#	define	DEBUG(fmt)
#	define	DEBUG2(fmt,arg)
#	define	DEBUGV(v)
#endif

local	void	run();
local	CELL	*take();
local	void	matcherr();
local	void	onintr();
local	void	chk_argument();

extern	CELL	*read_stream();

#define MARK 		01L
#define Mark(cell)      ((CELL *)((long)(cell) | MARK))
#define Marked(cell)    ((long)(cell) & MARK)
#define UnMark(cell)    ((CELL *)((long)(cell) & ~MARK))

#define FORCE_MARK      ((CELL *)0)
#define	NULL_ENV	((CELL *)0)

/* transfer p to current, discarding the original pointer */
#define	Enter(p)	(release(current), current = (p))

/* push a copy of p onto the stack */
#define	PushCopy(p)	(grab(p), Push(p))

/* push a mark for p onto the stack */
#define	PushMark(p)	(grab(p), Push(Mark(p)))

/* like Enter(), but push a mark as well */
#define	EnterMark(p)	(PushMark(p), Enter(p))

/* force evaluation (and update) of p, discarding the original pointer */
#define	Force(p)	(Push(FORCE_MARK), EnterMark(p))

local	POINTER	base_stack;

/*
 *	Interpreter for an expression.
 *	See compile.c for the translation schemes.
 */
global void
interpret(action, expr)
	EXPR	*action, *expr;
{
	signal(SIGINT, onintr);
	base_stack = stack;
	Push(new_susp(expr, new_pair(new_stream(stdin), NULL_ENV)));
	run(new_susp(action, NULL_ENV));
	signal(SIGINT, SIG_IGN);
}

/*
 *	Reduce a value to weak head normal form
 */
global void
evaluate(value)
reg	CELL	*value;
{
	grab(value);
	Push(new_susp(e_return, NULL_ENV));
	/* Force(value); */
	Push(FORCE_MARK);
	PushMark(value);
	run(value);
}

local void
run(current)
reg	CELL	*current;
{
/*
 *	The following variables hold temporary values during the emulation
 *	of particular instructions.
 *	Only current and the stack carry values between instructions.
 */
reg	CELL	*tmp;		/* general purpose temporary */
reg	CELL	*env; 		/* environment for suspensions */
reg	EXPR	*expr; 		/* expression for suspensions */
reg	int	itmp;		/* general purpose integer temporary */

/* special names for these.  BEWARE! Slippery when wet! */
#define	dir	itmp		/* direction value */
#define	var	itmp		/* variable number */
#define	top	tmp 		/* the top of the argument stack */

	for (;;)
#ifdef EBUG
	{
	show_stack();
	/* chk_refcounts(current); */
	ASSERT( current->c_refcount > 0 );
#endif EBUG
	switch (current->c_class) {
	when C_NUM:
		DEBUG2("NUM: %ld\n", current->c_num);
		top = take(current);
		if (top == FORCE_MARK)
			Enter(Pop());
		else	/* top is a normal value */
			Enter(top);
	when C_CHAR:
		DEBUG2("CHAR: %c\n", current->c_char);
		top = take(current);
		if (top == FORCE_MARK)
			Enter(Pop());
		else	/* top is a normal value */
			Enter(top);
	when C_CONST:
		DEBUG2("CONST: %s\n", current->c_cons->c_name);
		top = take(current);
		if (top == FORCE_MARK)
			Enter(Pop());
		else	/* top is a normal value */
			Enter(top);
	when C_CONS:
		DEBUG2("CONS: %s\n", current->c_cons->c_name);
		top = take(current);
		if (top == FORCE_MARK) {
			grab(tmp = current->c_arg);
			Force(tmp);
			chk_stack();
		}
		else	/* top is a normal value */
			Enter(top);
	when C_PAIR:
		DEBUG("PAIR\n");
		top = take(current);
		if (top == FORCE_MARK) {
			tmp = current->c_right;
			Push(FORCE_MARK);
			PushMark(tmp);
			PushCopy(tmp);
			grab(tmp = current->c_left);
			Force(tmp);
			chk_stack();
		}
		else	/* top is a normal value */
			Enter(top);
	when C_STREAM:
		DEBUG("STREAM\n");
		tmp = read_stream(current);
		Enter(tmp);
		chk_stack();
	when C_DIRS:
		DEBUG("DIRS: ");
		dir = p_top(current->c_path);
		current->c_path = p_pop(current->c_path);
		switch (dir) {
		when P_END:
			DEBUG("EMPTY\n");
			grab(tmp = current->c_val);
			EnterMark(tmp);
		when P_LEFT:
			DEBUG("LEFT\n");
			grab(tmp = current->c_val->c_left);
			release(current->c_val);
			current->c_val = tmp;
		when P_RIGHT:
			DEBUG("RIGHT\n");
			grab(tmp = current->c_val->c_right);
			release(current->c_val);
			current->c_val = tmp;
		when P_STRIP:
			DEBUG("STRIP\n");
			grab(tmp = current->c_val->c_arg);
			release(current->c_val);
			current->c_val = tmp;
		when P_PRED:
			DEBUG("PRED\n");
			tmp = new_num(current->c_val->c_num - 1);
			release(current->c_val);
			current->c_val = tmp;
		when P_UNROLL:
			DEBUG("UNROLL\n");
			PushCopy(current);
			grab(tmp = current->c_val);
			EnterMark(tmp);
		otherwise:
			error(INTERR, "illegal direction %d", dir);
		}
		chk_stack();
	when C_SUSP:
		DEBUG("SUSP: ");
		env = current->c_env;
		expr = current->c_exp;
		switch (expr->e_class) {
		when E_PAIR:
			DEBUG("PAIR\n");
			if (env) {
				grab(env);	/* one for each new_susp */
				grab(env); 
			}
			Enter(new_pair(new_susp(expr->e_left, env),
				       new_susp(expr->e_right, env)));
		when E_APPLY or E_IF or E_WHERE or E_LET:
			DEBUG("APPLY\n");
			if (env) {
				grab(env);	/* one for each new_susp */
				grab(env); 
			}
			Push(new_susp(expr->e_arg, env));
			Enter(new_susp(expr->e_func, env));
		when E_LAMBDA or E_EQN or E_THEN:
			DEBUG("LAMBDA\n");
			top = take(current);
			if (top == FORCE_MARK)
				Enter(Pop());
			else { /* top is a normal value */
				chk_argument(top);
				if (env)
					grab(env);
				Enter(new_susp(expr->e_expr,
					       new_pair(top, env)));
			}
		when E_DEFUN:
			DEBUG2("DEFUN: %s\n", expr->e_defun->f_name);
			if (expr->e_defun->f_branch) {
				top = take(current);
				if (top == FORCE_MARK)
					Enter(Pop());
				else {	/* top is a normal value */
					chk_argument(top);
					Enter(new_susp(expr->e_defun->f_body,
						new_pair(top, NULL_ENV)));
				}
			}
			else if (expr->e_defun->f_body)
				Enter(new_susp(expr->e_defun->f_body,
						NULL_ENV));
			else
				error(EXECERR, "undefined name: %s",
					expr->e_defun->f_name);
		when E_NUM:
			DEBUG2("NUM: %ld\n", expr->e_num);
			Enter(new_num(expr->e_num));
		when E_CHAR:
			DEBUG2("CHAR: '%c'\n", expr->e_char);
			Enter(new_char(expr->e_char));
		when E_CONST:
			DEBUG2("CONST: %s\n", expr->e_const->c_name);
			Enter(new_cnst(expr->e_const));
		when E_CONS:
			DEBUG2("CONS: %s\n", expr->e_const->c_name);
			top = take(current);
			if (top == FORCE_MARK)
				Enter(Pop());
			else {	/* top is a normal value */
				chk_argument(top);
				Enter(new_cons(expr->e_const, top));
			}
		when E_PARAM:
			DEBUG2("PARAM(%d)\n", expr->e_level);
			var = expr->e_level;
			while (var--)
				env = env->c_right;
			grab(tmp = env->c_left);
			tmp = new_dirs(expr->e_where, tmp);
			Enter(tmp);
		when E_UCASE:
			DEBUG("UCASE\n");
			grab(tmp = env->c_left);
			tmp = new_dirs(expr->e_path, tmp);
			PushCopy(tmp);		/* arg to LCASE or NCASE */
			grab(env);		/* at least one arg */
			Push(new_susp(expr->e_cases, env));
			EnterMark(tmp);
		when E_LCASE:
			DEBUG("LCASE\n");
			top = Pop();		/* arg (now updated) */
			expr = expr->e_limbs[top->c_cons->c_index];
			release(top);
			if (expr == NOMATCH)
				matcherr(env->c_left);
			grab(env);		/* at least one arg */
			Enter(new_susp(expr, env));
		when E_NCASE:
			DEBUG("NCASE\n");
			top = Pop();		/* arg (now updated) */
			expr = expr->e_limbs[top->c_num < 0L ? 0 :
					     top->c_num == 0L ? 1 : 2];
			release(top);
			if (expr == NOMATCH)
				matcherr(env->c_left);
			grab(env);		/* at least one arg */
			Enter(new_susp(expr, env));
		when E_CCASE:
			DEBUG("CCASE\n");
			top = Pop();		/* arg (now updated) */
			expr = expr->e_limbs[top->c_char == expr->e_cchar];
			release(top);
			if (expr == NOMATCH)
				matcherr(env->c_left);
			grab(env);		/* at least one arg */
			Enter(new_susp(expr, env));
		when E_STRICT:
			DEBUG("STRICT\n");
			/* force the evaluation of var 0,
			 * i.e the first element of the environment,
			 * before continuing with the body (a built-in)
			 */
			grab(env);		/* at least one arg */
			Push(new_susp(expr->e_real, env));
			grab(tmp = env->c_left);
			Force(tmp);
		when E_BUILTIN:
			DEBUG("BUILTIN\n");
			/* Apply the built-in function to var 0,
			 * i.e the first element of the environment
			 */
			tmp = (*(expr->e_fn))(env->c_left);
			Enter(tmp);
		when E_RETURN:
			DEBUG("RETURN\n");
			release(current);
			return;
		otherwise:
			error(INTERR, "illegal expression class %d",
				expr->e_class);
		}
		chk_stack();
	otherwise:
		error(INTERR, "illegal value class %d", current->c_class);
	}
#ifdef EBUG
	}
#endif EBUG
}

#ifdef EBUG
local
show_stack()
{
reg	POINTER	sp;
reg	CELL	*cp;

	DEBUG("Stack : ");
	if (stack > base_stack)
		DEBUG("bad stack ");
	if (stack == base_stack)
		DEBUG("empty");
	for (sp = base_stack-1; sp >= stack; sp--) {
		cp = *(CELL **)sp;
		if (cp == FORCE_MARK) {
			DEBUG("|| ");
			continue;
		}
		if (Marked(cp)) {
			DEBUG("*");
			cp = UnMark(cp);
		}
		switch (cp->c_class) {
		when C_NUM:
			DEBUG2("NUM: %ld", cp->c_num);
		when C_CHAR:
			DEBUG2("CHAR: %c", cp->c_char);
		when C_CONST:
			DEBUG2("CONST: %s", cp->c_cons->c_name);
		when C_CONS:
			DEBUG2("CONS: %s", cp->c_cons->c_name);
		when C_STREAM:
			DEBUG("STREAM");
		when C_PAIR:
			DEBUG("PAIR");
		when C_DIRS:
			DEBUG("DIRS");
		when C_SUSP:
			DEBUG("SUSP");
		}
		DEBUG(", ");
	}
	DEBUG("\n");
}
#endif EBUG

local CELL *
take(current)
reg	CELL	*current;
{
reg	CELL	*top;

	top = Pop();
	while (Marked(top)) {		/* NB: FORCE_MARK is not Marked */
		top = UnMark(top);
		if (top != current)
			copy_cell(top, current);
		release(top);
		top = Pop();
	}
	return top;
}

/*
 *	Desperate kludge to catch comparison of functions.
 *	Cf init_cmps() in compare.c
 */
local void
chk_argument(arg)
reg	CELL	*arg;
{
	if (arg->c_class == C_SUSP &&
	    arg->c_exp->e_class == E_APPLY &&
	    arg->c_exp->e_arg->e_class == E_BUILTIN)
		error(EXECERR, "attempt to compare functions");
}

local void
matcherr(arg)
	CELL	*arg;
{
	/* temporary (?) new version:
	 * the old version took a function parameter as well,
	 * but we can't seem to find the function now.
	 */
	pr_value(stdout, arg);
	printf("\n");
	error(EXECERR, "no match found");
}

local void
onintr()
{
	signal(SIGINT, SIG_IGN);
	error(EXECERR, "interrupted");
}
