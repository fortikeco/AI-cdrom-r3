
typedef union  {
	long	longval;
	int	intval;
	char	*textval;
	STRING	strval;
	char	charval;
	TVAR	*tvar;
	TYPE	*type;
	DEFTYPE	*deftype;
	EXPR	*expr;
	BRANCH	*branch;
	MODULE	*module;
	CONS	*cons;
} YYSTYPE;
extern YYSTYPE yylval;
# define TYPEVAR 257
# define ABSTYPE 258
# define DATA 259
# define TYPESYM 260
# define DEC 261
# define INFIX 262
# define INFIXRL 263
# define USE 264
# define PRIVATE 265
# define ENDFILE 266
# define DISPLAY 267
# define SAVE 268
# define WRITE 269
# define TO 270
# define EXIT 271
# define EDIT 272
# define EQ 273
# define VALOF 274
# define IS 275
# define THEN 276
# define OR 277
# define GIVES 278
# define WHERE 279
# define IN 280
# define ELSE 281
# define BINARY1 282
# define RBINARY1 283
# define BINARY2 284
# define RBINARY2 285
# define BINARY3 286
# define RBINARY3 287
# define BINARY4 288
# define RBINARY4 289
# define BINARY5 290
# define RBINARY5 291
# define BINARY6 292
# define RBINARY6 293
# define BINARY7 294
# define RBINARY7 295
# define BINARY8 296
# define RBINARY8 297
# define BINARY9 298
# define RBINARY9 299
# define BINARY10 300
# define RBINARY10 301
# define APPLY 302
# define IF 303
# define LAMBDA 304
# define IDENT 305
# define NUMBER 306
# define TEXT 307
# define CHAR 308
# define LET 309
# define END 310
# define NONOP 311
