#ifndef MEMORY_H
#define MEMORY_H

/*
 * The WORD is the granularity of allocation.  It must therefore be
 * at least as large as the alignment granularity.
 * Hence a POINTER is sufficiently aligned for most purposes.
 */
typedef	int	*WORD;		/* may be changed, but see above */
typedef	WORD	*POINTER;

/*
 *	A large chunk of memory is allocated once at the start.
 *	Subsequently, this area is divided as follows:
 *
 *				      Pointers		Allocation functions
 *				      --------		--------------------
 * High	------------------------- <-- top_memory
 *	| String space		|			s_alloc(n)
 *	|-----------------------| <-- base_string
 *	| Run-time stack	|
 *	|-----------------------| <-- stack
 *	|	   |		|
 *	|	   v		|
 *	|			|
 *	|			|
 *	|	   ^		|
 *	|	   |		|
 *	|-----------------------| <-- top_heap
 *	| Heap			|			h_alloc(n)
 *	|-----------------------| <-- top_temp
 *	| temporary table space	|			t_alloc(n)
 *	|-----------------------| <-- top_table
 *	| Table space:		|
 *	| structures and code	|
 * Low	------------------------- <-- base_memory
 *
 * Other calls:
 *	init_memory()	set it all up.
 *	preserve()	make temporary table space permanent.
 *	clean_slate()	discard temporary table space.
 *	init_heap()	set up empty heap and stack.
 *			NB: any calls to t_alloc() will destroy the heap;
 *			    any calls to s_alloc() will destroy the stack.
 */

extern	POINTER	stack;

extern	void	init_memory();
extern	POINTER	s_alloc();	/* (natural nbytes) */
extern	POINTER	h_alloc();	/* (natural nbytes) */
extern	POINTER	t_alloc();	/* (natural nbytes) */
extern	void	clean_slate();
extern	void	preserve();
extern	void	init_heap();
extern	int	heap_size();
extern	void	chk_stack();
extern	void	heap_stats();

#define	NEWARRAY(type,size)	((type *)t_alloc((natural)sizeof(type)*(size)))
#define	NEW(type)	NEWARRAY(type, 1)

#endif MEMORY_H
