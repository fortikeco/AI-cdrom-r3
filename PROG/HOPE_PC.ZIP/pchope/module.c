#include "defs.h"
#include "op.h"
#include "memory.h"
#include "expr.h"
#include "cell.h"
#include "typevar.h"
#include "module.h"
#include "error.h"
#include "deftype.h"

#define	MAXMODS	SETSIZE

/* special modules */
#define SESSION 0	/* the terminal interaction */
#define	STANDARD 1	/* standard environment */
/*
 *	List of all modules ever encountered.
 */
local	MODULE	*mod_list[MAXMODS];
local	int	mod_count;
/*
 *	Stack of modules being read to satisfy `uses' commands.
 *	The top module is the one currently being read; the bottom one is
 *	the current session.
 */
local	MODULE	*mod_stack[MAXMODS];
local	MODULE	**mod_current;
local	SET	mod_unread;	/* modules yet to be read */

local	FILE	*mopen();
local	MODULE	*mod_new();
local	void	us_display(), tv_display(), op_display(), ty_display();
local	void	dec_display(), def_display(), fn_display();

extern	void	enterfile();
extern	void	init_builtins();
extern	void	init_cmps();
extern	void	init_code();
extern	void	init_print();

/*
 *	Set up the special modules
 */
global void
mod_init()
{
	MODULE	*standard;

	mod_count = 0;
	mod_current = mod_stack;
	*mod_current = mod_new(newstring("<Terminal Session>"));
	/* "uses Standard;" */
	standard = module(newstring("Standard"));
	standard->mod_uses = standard->mod_refs = EMPTY;
	mod_fetch();
}

global STRING
mod_name()
{
	return (*mod_current)->mod_name;
}

global MODULE *
module(name)
	STRING	name;
{
reg	int	i;

	if ((*mod_current)->mod_num == STANDARD)
		error(FATALERR, "uses in Standard module");
	for (i = STANDARD; i < mod_count; i++)
		if (mod_list[i]->mod_name == name)
			return mod_list[i];	/* already here */
	/* not here -- make a note to read it */
	mod_unread |= ELEM(mod_count);
	return mod_new(name);
}

local MODULE *
mod_new(name)
	STRING	name;
{
reg	MODULE	*mod;

	mod = NEW(MODULE);
	mod->mod_name = name;
	mod->mod_uses = mod->mod_refs = ELEM(STANDARD);
	mod->mod_num = mod_count;
	mod->mod_tvars = EMPTY;
	mod->mod_ops = (OP *)0;		mod->mod_oend = &(mod->mod_ops);
	mod->mod_types = (DEFTYPE *)0;	mod->mod_tend = &(mod->mod_types);
	mod->mod_fns = (FUNC *)0;	mod->mod_fend = &(mod->mod_fns);
	mod->mod_public = (MODULE *)0;
	mod_list[mod_count++] = mod;
	return mod;
}

global void
mod_save(name)
	STRING	name;
{
	FILE	*f;

	if (f = mopen(name, "r")) {
		fclose(f);
		error(SEMERR, "a module called '%s' already exists", name);
	}
	else if ((f = mopen(name, "w")) == (FILE *)0)
		error(SEMERR, "can't save module '%s'", name);
	else {
		us_display(f, mod_list[SESSION]);
		tv_display(f, mod_list[SESSION]);
		op_display(f, mod_list[SESSION]);
		ty_display(f, mod_list[SESSION], FALSE);
		ty_display(f, mod_list[SESSION], TRUE);
		dec_display(f, mod_list[SESSION]);
		def_display(f, mod_list[SESSION]);
		fclose(f);
	}
}

global void
mod_use(mod)
	MODULE	*mod;
{
reg	MODULE	**mp;

	if (! mod || mod->mod_num == STANDARD)
		return;
	for (mp = mod_stack; mp <= mod_current; mp++)
		if (*mp == mod || (*mp)->mod_public == mod) {
			error(SEMERR, "cyclic uses reference: %s",
				mod->mod_name);
			return;
		}
	(*mod_current)->mod_uses |= ELEM(mod->mod_num);
	(*mod_current)->mod_refs |= ELEM(mod->mod_num) | mod->mod_refs;
}

/*
 *	Read in any queued modules
 */
global void
mod_fetch()
{
reg	int	i;
	FILE	*f;

	/* unprocessed uses */
	if ((*mod_current)->mod_uses & mod_unread)
		for (i = STANDARD; i < mod_count; i++)
			if (ELEM(i) & (*mod_current)->mod_uses & mod_unread) {
				mod_unread &= ~ELEM(i);
				if (f = mopen(mod_list[i]->mod_name, "r")) {
					/* go read this one */
					enterfile(f);
					*++mod_current = mod_list[i];
					break;
				}
				else {
					error(i == STANDARD ? FATALERR :
							      SEMERR,
						"can't read module '%s'",
						mod_list[i]->mod_name);
					(*mod_current)->mod_uses &= ~ELEM(i);
				}
			}
}

/*
 *	Rest of module is to be hidden from other modules.
 */
global void
private()
{
reg	MODULE	*mod_private;
reg	DEFTYPE	*dt;

	if ((*mod_current)->mod_num == SESSION)
		return;
	/*
	 * Mark all abstype's in the current module so they can be reset
	 * at the end of the module.
	 */
	for (dt = (*mod_current)->mod_types; dt; dt = dt->dt_next)
		dt->dt_private = ! dt->dt_synonym &&
					(dt->dt_cons == (CONS *)0);
	/*
	 * Start a new module (which will be discarded) for any new
	 * definitions.
	 */
	mod_private = mod_new((*mod_current)->mod_name);
	mod_private->mod_uses = (*mod_current)->mod_uses;
	mod_private->mod_refs = (*mod_current)->mod_refs;
	mod_private->mod_public = *mod_current;
	*mod_current = mod_private;
	preserve();
}

/* end of use */
global void
mod_finish()
{
reg	DEFTYPE	*dt;

	if ((*mod_current)->mod_num == STANDARD ||
	    (*mod_current)->mod_public &&
	    (*mod_current)->mod_public->mod_num == STANDARD) {
		init_cmps();
		init_builtins();
		init_print();
		preserve();
	}
	if ((*mod_current)->mod_public) {
		*mod_current = (*mod_current)->mod_public;
		/*
		 * Reset any abstype's that have been privately defined
		 */
		for (dt = (*mod_current)->mod_types; dt; dt = dt->dt_next)
			if (dt->dt_private) {
				dt->dt_synonym = FALSE;
				dt->dt_cons = (CONS *)0;
			}
	}
	mod_current--;
	(*mod_current)->mod_refs |= (*(mod_current+1))->mod_refs;
	mod_fetch();
}

local void
us_display(f, mod)
	FILE	*f;
	MODULE	*mod;
{
reg	int	i;
	bool	first;

	if (mod->mod_uses & ~ELEM(STANDARD)) {
		fprintf(f, "use ");
		first = TRUE;
		for (i = STANDARD+1; i < mod_count; i++)
			if (ELEM(i) & mod->mod_uses) {
				fprintf(f, first ? "%s" : ", %s",
					mod_list[i]->mod_name);
				first = FALSE;
			}
		fprintf(f, ";\n");
	}
}

/*
 *	Open a module for read or write (create).
 *	New modules are created in the current directory;
 *	existing modules are sought first in the current directory,
 *	then in the directory HOPELIB (if defined).
 */
local FILE *
mopen(name, mode)
	char	*name;
	char	*mode;
{
#ifdef HOPELIB
	char	filename[100];
	FILE	*f;

	f = fopen(name, mode);
	if (mode[0] == 'w' || f != (FILE *)0)
		return f;
#ifndef AMIGA
#	ifndef	PC
	sprintf(filename, "%s/%s", HOPELIB, name);
#	else
	sprintf(filename, "%s\\%s", HOPELIB, name);
#	endif	PC
#else
	sprintf(filename, "%s:%s", HOPELIB, name);
#endif AMIGA
	return fopen(filename, mode);
#else
	return fopen(name, mode);
#endif HOPELIB
}

/*
 *	Look for a name in the current module
 */
local POINTER
look_here(name, look_fn)
	STRING	name;
	POINTER	(*look_fn)();
{
reg	POINTER	found;

	if ((found = (*look_fn)(name, *mod_current)) != (POINTER)0)
		return found;
	if ((*mod_current)->mod_public)
		return (*look_fn)(name, (*mod_current)->mod_public);
	return (POINTER)0;
}

/*
 *	Look for a name in the current module and all those it uses
 */
local POINTER
look_everywhere(name, look_fn)
	STRING	name;
	POINTER	(*look_fn)();
{
reg	POINTER	found;
reg	int	i;

	if ((found = look_here(name, look_fn)) != (POINTER)0)
		return found;
	for (i = STANDARD; i < mod_count; i++)
		if ((ELEM(i) & (*mod_current)->mod_refs) &&
		    (found = (*look_fn)(name, mod_list[i])) != (POINTER)0)
			return found;
	return (POINTER)0;
}

/*
 *	Operators
 */

global void
op_declare(name, prec, assoc)
	STRING	name;
	int	prec;
	ASSOC	assoc;
{
reg	OP	*op;

	if (prec > MAXPREC)
		prec = MAXPREC;
	op = NEW(OP);
	op->op_name = name;
	op->op_prec = prec;
	op->op_assoc = assoc;
	op->op_next = (OP *)0;
	*((*mod_current)->mod_oend) = op;
	(*mod_current)->mod_oend = &(op->op_next);
}

local POINTER
op_mod_lookup(name, mod)
reg	STRING	name;
	MODULE	*mod;
{
reg	OP	*op;

	for (op = mod->mod_ops; op; op = op->op_next)
		if (op->op_name == name)
			return((POINTER)op);
	return((POINTER)0);
}

global OP *
op_lookup(name)
	STRING	name;
{
	return (OP *)look_everywhere(name, op_mod_lookup);
}

local void
op_display(f, mod)
	FILE	*f;
	MODULE	*mod;
{
reg	OP	*op;

	for (op = mod->mod_ops; op; op = op->op_next)
		fprintf(f, "%s %s : %d;\n",
			op->op_assoc == ASSOC_LEFT ? "infix" : "infixr",
			op->op_name, op->op_prec);
}

/*
 *	Type Variables.
 */

#define	MAXTYPEVAR	SETSIZE

local	TVAR	typevar[MAXTYPEVAR];
local	TVAR	*endvar = typevar;

global void
tv_declare(name)
	STRING	name;
{
reg	TVAR	*tv;

	endvar->tv_name = name;		/* sentinel */
	for (tv = typevar; tv->tv_name != name; tv++)
		;
	if (tv == endvar)		/* add it */
		endvar++;
	(*mod_current)->mod_tvars |= ELEM(tv - typevar);
}

local POINTER
tv_mod_lookup(tvp, mod)
	STRING	tvp;
	MODULE	*mod;
{
	TVAR	*tv;

	tv = (TVAR *)tvp;
	return (mod->mod_tvars & ELEM(tv-typevar)) != EMPTY ?
		(POINTER)tv : (POINTER)0;
}

global TVAR *
tv_lookup(name, serious)
	STRING	name;
	bool	serious;
{
reg	TVAR	*tv;

	for (tv = typevar; tv < endvar && tv->tv_name != name; tv++)
		;
	/* got its number, now can we see it from here? */
	if (tv < endvar && look_everywhere((STRING)tv, tv_mod_lookup))
		return tv;
	if (serious) {
		error(SEMERR, "'%s' is not a type variable", name);
		return typevar;
	}
	return (TVAR *)0;
}

global int
tv_count()
{
	return endvar - typevar;
}

global TVAR *
tv_var(n)
	int	n;
{
	if (n >= 0 && typevar+n < endvar)
		return(typevar + n);
	return (TVAR *)0;
}

local void
tv_display(f, mod)
	FILE	*f;
	MODULE	*mod;
{
reg	TVAR	*tv;
	bool	first;

	if (mod->mod_tvars) {
		fprintf(f, "typevar ");
		first = TRUE;
		for (tv = typevar; tv < endvar; tv++)
			if (mod->mod_tvars & ELEM(tv-typevar)) {
				fprintf(f, first ? "%s" : ", %s",
					tv->tv_name);
				first = FALSE;
			}
		fprintf(f, ";\n");
	}
}

/*
 *	Defined types and constructors.
 */

global	EXPR	*e_true, *e_false, *e_cons, *e_nil;

global void
dt_declare(dt)
reg	DEFTYPE	*dt;
{
	dt->dt_next = (DEFTYPE *)0;
	*((*mod_current)->mod_tend) = dt;
	(*mod_current)->mod_tend = &(dt->dt_next);
	if ((*mod_current)->mod_num == STANDARD)
		if (dt->dt_name == newstring("->"))
			function = dt;
		else if (dt->dt_name == newstring("#"))
			product = dt;
		else if (dt->dt_name == newstring("truval")) {
			truval = dt;
			false = dt->dt_cons;
			e_false = const_expr(false);
			true = false->c_next;
			e_true = const_expr(true);
		}
		else if (dt->dt_name == newstring("num")) {
			num = dt;
			succ = dt->dt_cons;
		}
		else if (dt->dt_name == newstring("list")) {
			list = dt;
			nil = dt->dt_cons;
			e_nil = const_expr(nil);
			cons = nil->c_next;
			e_cons = cons_expr(cons);
		}
		else if (dt->dt_name == newstring("char"))
			character = dt;
}

local POINTER
dt_mod_lookup(name, mod)
reg	STRING	name;
	MODULE	*mod;
{
reg	DEFTYPE	*dt;

	for (dt = mod->mod_types; dt; dt = dt->dt_next)
		if (dt->dt_name == name)
			return (POINTER)dt;
	return (POINTER)0;
}

global DEFTYPE *
dt_lookup(name)
reg	STRING	name;
{
	return (DEFTYPE *)look_everywhere(name, dt_mod_lookup);
}

global DEFTYPE *
dt_local(name)
	STRING	name;
{
	return (DEFTYPE *)look_here(name, dt_mod_lookup);
}

local POINTER
cons_mod_lookup(name, mod)
reg	STRING	name;
	MODULE	*mod;
{
reg	DEFTYPE	*dt;
reg	CONS	*cp;

	for (dt = mod->mod_types; dt; dt = dt->dt_next)
		if (! dt->dt_synonym)
			for (cp = dt->dt_cons; cp; cp = cp->c_next)
				if (cp->c_name == name)
					return (POINTER)cp;
	return (POINTER)0;
}

global CONS *
cons_lookup(name)
reg	STRING	name;
{
	return (CONS *)look_everywhere(name, cons_mod_lookup);
}

local void
ty_display(f, mod, full)
	FILE	*f;
	MODULE	*mod;
	bool	full;
{
reg	DEFTYPE	*dt;

	for (dt = mod->mod_types; dt; dt = dt->dt_next)
		pr_deftype(f, dt, full);
}

/*
 *	Functions.
 */

global void
new_fn(name, type)
	STRING	name;
	TYPE	*type;
{
reg	FUNC	*fn;

	fn = NEW(FUNC);
	fn->f_name = name;
	fn->f_type = type;
	fn->f_body = NOMATCH;
	fn->f_branch = (BRANCH *)0;
	fn->f_next = (FUNC *)0;
	*((*mod_current)->mod_fend) = fn;
	(*mod_current)->mod_fend = &(fn->f_next);
}

local POINTER
fn_mod_lookup(name, mod)
reg	STRING	name;
	MODULE	*mod;
{
reg	FUNC	*fn;

	for (fn = mod->mod_fns; fn; fn = fn->f_next)
		if (fn->f_name == name)
			return (POINTER)fn;
	return (POINTER)0;
}

global FUNC *
fn_lookup(name)
	STRING	name;
{
	return (FUNC *)look_everywhere(name, fn_mod_lookup);
}

global FUNC *
fn_local(name)
	STRING	name;
{
	return (FUNC *)look_here(name, fn_mod_lookup);
}

local void
fn_display(f, mod)
	FILE	*f;
	MODULE	*mod;
{
reg	FUNC	*fn;

	for (fn = mod->mod_fns; fn; fn = fn->f_next) {
		fprintf(f, "\n");
		pr_fdecl(f, fn);
		pr_fundef(f, fn);
	}
}

local void
dec_display(f, mod)
	FILE	*f;
	MODULE	*mod;
{
reg	FUNC	*fn;

	for (fn = mod->mod_fns; fn; fn = fn->f_next)
		pr_fdecl(f, fn);
}

local void
def_display(f, mod)
	FILE	*f;
	MODULE	*mod;
{
reg	FUNC	*fn;

	for (fn = mod->mod_fns; fn; fn = fn->f_next)
		if (fn->f_branch || fn->f_body) {
			fprintf(f, "\n");
			pr_fundef(f, fn);
		}
}

/*
 *	List out all tables.
 */
global void
display(f)
	FILE	*f;
{
	us_display(f, mod_list[SESSION]);
	op_display(f, mod_list[SESSION]);
	tv_display(f, mod_list[SESSION]);
	ty_display(f, mod_list[SESSION], TRUE);
	fn_display(f, mod_list[SESSION]);
}
