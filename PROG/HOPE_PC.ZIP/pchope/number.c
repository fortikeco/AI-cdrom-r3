#include "defs.h"
#include "expr.h"
#include "cell.h"
#include "error.h"
#include "path.h"

local	bool	nv_branch(), nv_pattern(), nv_expr(), nv_var();

/*
 *	Management of variable scopes
 */
local	EXPR	*varlist[40];
local	EXPR	**next_var;

local	EXPR	**scope[20];
local	EXPR	***ref_level;

/*
 *	Numbering of variables.
 */

global bool
nr_branch(br)
	BRANCH	*br;
{
	ref_level = scope;
	scope[0] = next_var = varlist;
	return nv_branch(br);
}

global bool
nr_expr(expr)
	EXPR	*expr;
{
	ref_level = scope;
	scope[0] = next_var = varlist;
	return nv_expr(expr);
}

local bool
nv_branch(br)
reg	BRANCH	*br;
{
	if (! nv_pattern(br->br_pattern, p_new()))
		return FALSE;
	br->br_nvars = next_var - *ref_level;
	*++ref_level = next_var;
	if (! nv_expr(br->br_expr))
		return FALSE;
	next_var = *--ref_level;
	return TRUE;
}

local bool
nv_pattern(p, path)
reg	EXPR	*p;
	PATH	path;
{
reg	EXPR	**vp;

	switch (p->e_class) {
	when E_PAIR:
		return nv_pattern(p->e_left, p_push(P_LEFT, path)) &&
			nv_pattern(p->e_right, p_push(P_RIGHT, path));
	when E_APPLY:
		if (p->e_func == (EXPR *)0)	/* error from id_cons() */
			return FALSE;
		ASSERT( p->e_func->e_class == E_CONS );
		return nv_pattern(p->e_arg,
			p_push(p->e_func->e_const == succ ? P_PRED : P_STRIP,
			       path));
	when E_VAR:
		if (p->e_vname != newstring("_"))
			for (vp = *ref_level; vp != next_var; vp++)
				if ((*vp)->e_vname == p->e_vname) {
					error(SEMERR,
						"%s: occurs twice in pattern",
						p->e_vname);
					return FALSE;
				}
		p->e_var = next_var - *ref_level;
		p->e_dirs = p_stash(p_reverse(path));
		*next_var++ = p;
		return TRUE;
	when E_DEFUN:
		error(SEMERR, "%s: function not permitted in pattern",
			p->e_defun->f_name);
		return FALSE;
	}
	return TRUE;
}

local bool
nv_expr(e)
reg	EXPR	*e;
{
reg	BRANCH	*br;

	switch (e->e_class) {
	when E_PAIR:
		return nv_expr(e->e_left) && nv_expr(e->e_right);
	when E_APPLY or E_IF or E_WHERE or E_LET:
		return nv_expr(e->e_func) && nv_expr(e->e_arg);
	when E_LAMBDA or E_EQN or E_THEN:
		for (br = e->e_branch; br; br = br->br_next)
			if (! nv_branch(br))
				return FALSE;
		return TRUE;
	when E_VAR:
		return nv_var(e);
	}
	return TRUE;
}

local bool
nv_var(e)
reg	EXPR	*e;
{
reg	STRING	name;
reg	EXPR	**vp;
reg	EXPR	***def_level;

	name = e->e_vname;
	ASSERT( next_var == *ref_level );
	for (vp = next_var-1; vp >= varlist; vp--)
		if ((*vp)->e_vname == name) {
			e->e_class = E_PARAM;
			e->e_patt = *vp;
			for (def_level = scope; *def_level <= vp; def_level++)
				;
			e->e_level = ref_level - def_level;
			e->e_where = (*vp)->e_dirs;
			return TRUE;
		}
	if (e->e_defun = fn_lookup(name)) {
		e->e_class = E_DEFUN;
		return TRUE;
	}
	if (e->e_const = cons_lookup(name)) {
		if (e->e_const == succ) {	/* fiddle: succ constructor */
			e->e_defun = f_succ;	/* becomes succ function */
			e->e_class = E_DEFUN;
		}
		else
			e->e_class = e->e_const->c_constructor ?
					E_CONS : E_CONST;
		return TRUE;
	}
	error(SEMERR, "%s: undefined variable", name);
	return FALSE;
}
