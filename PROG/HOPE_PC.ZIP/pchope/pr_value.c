#include "defs.h"
#include "op.h"
#include "memory.h"
#include "expr.h"
#include "cell.h"
#include "path.h"
#include <signal.h>

extern	void	pr_expr();
extern	void	evaluate();

local	void	val_print(), pr_list(), pr_f_value();

local	FILE	*outfile;
local	char	*out_name;

#define	TEMPFILE "TempFile"

global void
open_out_file(name)
	char	*name;
{
	out_name = name;
	outfile = name ? fopen(TEMPFILE, "w") : stdout;
}

global void
save_out_file()
{
	if (out_name) {
		fclose(outfile);
		unlink(out_name);
		/* link(TEMPFILE, out_name); unlink(TEMPFILE) */
		rename(TEMPFILE, out_name);
	}
}

global void
close_out_file()
{
	if (out_name) {
		fclose(outfile);
		unlink(TEMPFILE);
	}
}

global	EXPR	*e_return, *e_print, *e_wr_list;

global void
init_print()
{
	FUNC	*fn;

	e_return = NEW(EXPR);
	e_return->e_class = E_RETURN;
	fn = fn_lookup(newstring("return"));
	ASSERT( fn != (FUNC *)0 );
	fn->f_body = e_return;

	fn = fn_lookup(newstring("print"));
	ASSERT( fn != (FUNC *)0 );
	e_print = NEW(EXPR);
	e_print->e_class = E_DEFUN;
	e_print->e_defun = fn;

	fn = fn_lookup(newstring("write_list"));
	ASSERT( fn != (FUNC *)0 );
	e_wr_list = NEW(EXPR);
	e_wr_list->e_class = E_DEFUN;
	e_wr_list->e_defun = fn;
}

global CELL *
print_value(val)
	CELL	*val;
{
	printf(">> ");
	pr_value(outfile, val);
	return new_susp(e_return, (CELL *)0);
}

global CELL *
write_value(val)
reg	CELL	*val;
{
	if (val->c_class == C_CHAR)
		fprintf(outfile, "%c", val->c_char);
	else {
		pr_value(outfile, val);
		fprintf(outfile, "\n");
	}
	return new_susp(e_wr_list, (CELL *)0);
}

/*
 *	Printing of computed values
 */

#define	set_env(e)	Push(e)
#define	cur_env()	Top()
#define	clr_env()	Pop_void()

global void
pr_value(f, value)
	FILE	*f;
	CELL	*value;
{
	val_print(f, value, PREC_BODY);
}

local void
val_print(f, value, context)
reg	FILE	*f;
reg	CELL	*value;
	int	context;
{
	int	prec;

	prec = prec_value(value);
	if (prec < context)
		fprintf(f, "(");
	switch (value->c_class) {
	when C_NUM:
		fprintf(f, "%ld", value->c_num);
	when C_CHAR:
		fprintf(f, "'");
		pr_char(f, value->c_char);
		fprintf(f, "'");
	when C_CONST:
		fprintf(f, "%s", value->c_cons->c_name);
	when C_CONS:
		if (value->c_cons == cons)
			pr_list(f, value);
		else
			pr_f_value(f, value->c_cons->c_name, value->c_arg);
	when C_PAIR:
		val_print(f, value->c_left, PREC_PAIR+1);
		fprintf(f, ", ");
		val_print(f, value->c_right, PREC_PAIR);
	when C_SUSP:
		set_env(value->c_env);
		pr_expr(f, value->c_exp, 0, context);
		clr_env();
	otherwise:
		NOTREACHED;
	}
	if (prec < context)
		fprintf(f, ")");
}

local void
pr_list(f, value)
reg	FILE	*f;
reg	CELL	*value;
{
	if (value->c_arg->c_left->c_class == C_CHAR) {
		fprintf(f, "\"");
		for ( ; value->c_class == C_CONS;
		     value = value->c_arg->c_right)
			pr_char(f, value->c_arg->c_left->c_char);
		fprintf(f, "\"");
	}
	else {
		fprintf(f, "[");
		for (;;) {
			val_print(f, value->c_arg->c_left, PREC_BODY);
			value = value->c_arg->c_right;
			if (value->c_class != C_CONS)
				break;
			fprintf(f, ", ");
		}
		fprintf(f, "]");
	}
}

local CELL *
get_actual(level, path)
reg	int	level;
	PATH	path;
{
reg	CELL	*env;
reg	CELL	*value;

	env = cur_env();
	while (level--)
		env = env->c_right;
	grab(env->c_left);
	value = new_dirs(path, env->c_left);
	evaluate(value);
	return value;
}

/*
 *	Print actual parameter, taking its value from the environment.
 */
global void
pr_actual(f, level, path, context)
	FILE	*f;
	int	level;
	PATH	path;
	int	context;
{
reg	CELL	*value;

	value = get_actual(level, path);
	val_print(f, value, context);
	release(value);
}

global void
pr_f_actual(f, name, level, path)
	FILE	*f;
	STRING	name;
	int	level;
	PATH	path;
{
reg	CELL	*value;

	value = get_actual(level, path);
	pr_f_value(f, name, value);
	release(value);
}

local void
pr_f_value(f, name, arg)
	FILE	*f;
	STRING	name;
	CELL	*arg;
{
	OP	*op;

	if (op = op_lookup(name))
		if (arg->c_class == C_PAIR) {
			val_print(f, arg->c_left, LeftPrec(op));
			fprintf(f, " %s ", name);
			val_print(f, arg->c_right, RightPrec(op));
		}
		else {
			fprintf(f, "(%s) ", name);
			val_print(f, arg, PREC_APPLY+1);
		}
	else {
		fprintf(f, "%s ", name);
		val_print(f, arg, PREC_APPLY+1);
	}
}

global EXPR *
val_deref(level, path)
	int	level;
	PATH	path;
{
reg	CELL	*value;
reg	EXPR	*result;

	value = get_actual(level, path);
	if (value->c_class == C_SUSP) {
		result = value->c_exp;
		if (result->e_class != E_CONS && result->e_class != E_DEFUN)
			result = (EXPR *)0;
	}
	else
		result = (EXPR *)0;
	release(value);
	return result;
}

local int
prec_value(value)
	CELL	*value;
{
	OP	*op;

	switch (value->c_class) {
	when C_CONS:
		if (value->c_arg->c_class == C_PAIR &&
		    (op = op_lookup(value->c_cons->c_name)))
			return op->op_prec;
		return PREC_APPLY;
	when C_PAIR:
		return PREC_PAIR;
	}
	/* otherwise: */
	return PREC_ATOMIC;
}
