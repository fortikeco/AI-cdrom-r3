1/19/93

Introduction
============
This is version 2.5 of MineSweeper for OS/2 2.x PM.  It is a 
32-bit application, and so requires OS/2 2.0 or later.  
It has been tested under OS/2 2.0 GA, and 2.1 beta.

It is an enhanced version of my earlier 16-bit release, which was called
MINE.ZIP and (as of this writing) available on CompuServe and the 'hobbes'
ftp site.

This game is Freeware.  You are free to use it and give it to others,
as long as you don't sell it.  It is NOT public domain; I retain copyright.

That said, being a poor college student, I will accept donations of any amount,
sent to the address below.
In exchange, I'll send you the source code (via e-mail if possible.)
But you are not obligated to send me anything.

Installation:
=============
Simply place Mine.exe, Mine.hlp, and (optionally) Mine.ini in the
same directory.  You can run it from the command line:

     mine

or from the Workplace shell, after setting up an appropriate Program object.

Help is available on-line.

The .INI file
=============
The game stores its settings in its own .ini file; not in a
system .ini file such as os2.ini.  It expects to be able to write 
to this file.  Therefore, you'll have problems if you install
the game to a read-only disk, such as a network drive.  If you do so,
you will get an error message when you exit the game, and your changes
to the settings, as well as new high scores, will be lost.  (Otherwise,
the game will operate properly.)

If you erase the mine.ini file, the program will rebuild it automatically.
In this way, you can clear the high score table and the Option settings.

Contacting the Author
=====================
Please send me any bug reports, suggestions, opinions, etc.  I will appreciate
anything you send, and will attempt to fix bugs and incorporate reasonable
suggestions.  You may want to refer to the version given in the About...
box when corresponding.

Enjoy!


Bill Warner
22 Schussler Rd, Apt. 4
Worcester, MA  01609-2214

Internet:  wtw@wpi.wpi.edu



