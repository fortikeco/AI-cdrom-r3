/* Machine specific defines for the dpx2 machine */
#define dpx2
#define TC_M68K

/* The magic number is not the usual MC68MAGIC. */
#define FILE_HEADER_MAGIC       MC68KBCSMAGIC

/* end of te-dpx2.h */
