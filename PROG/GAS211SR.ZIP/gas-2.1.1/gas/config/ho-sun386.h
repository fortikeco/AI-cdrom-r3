#include <ho-sunos.h>

extern int sprintf ();

/* end of ho-sun386.h */
