#define TE_LINUX
#include "obj-format.h"
