/* Machine specific defines for the SCO Unix V.3.2 ODT */
#define scounix

/* Local labels start with a period.  */
#define DOT_LABEL_PREFIX

/* end of te-sco386.h */
