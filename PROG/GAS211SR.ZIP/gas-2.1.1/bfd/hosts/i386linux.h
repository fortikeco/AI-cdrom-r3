#include <stdlib.h>
#include <unistd.h>
#define DONTDECLARE_MALLOC
#include "hosts/i386v.h"
