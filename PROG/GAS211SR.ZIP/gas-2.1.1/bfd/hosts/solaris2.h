/* Solaris-2 host system */

#include "hosts/sysv4.h"

#ifndef __GNUC__
#include <alloca.h>
#endif
/* That's all... */
