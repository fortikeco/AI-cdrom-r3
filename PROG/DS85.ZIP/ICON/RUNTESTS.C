#include <stdio.h>

/*
 * Run sequence of tests of Icon programs from list of names contained
 *  in file given as argument
 */

main(argc,argv)
int argc;
char *argv[];
   {
   int system();
   char sbuf[15];
   char name[10];
   FILE *infile;
   FILE *in;

   if (argc != 2) {		/* one argument + program name */
      fprintf(stderr,"wrong number of arguments: %d\n", argc);
      exit(-1);
      }
   in = fopen(argv[1],"r");	/* open file of program names */
   if (in == NULL) {
      fprintf(stderr,"cannot open input\n");
      exit(-1);
      }
   while (fgets(name,10,in) != NULL) {	/* get the next file name */
      name[strlen(name) - 1] = ' ';	/* change newline to blank :-( */
      sprintf(sbuf, "itest %s", name);	/* construct the command */
      system(sbuf);			/* perform the test */
      }
   }
