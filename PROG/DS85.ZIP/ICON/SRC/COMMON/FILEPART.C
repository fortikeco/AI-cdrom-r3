/*
 * This file contains fparse(), makename(), and smatch().
 */
#include <ctype.h>
#include "../h/gsupport.h"

/*
 * The following code is operating-system dependent [@filepart.01].  Define the
 *  characters that terminate a file name prefix.
 */

#if PORT
#define Prefix "/"
Deliberate Syntax Error
#endif					/* PORT */

#if AMIGA
#define Prefix "/:"
#endif					/* AMIGA */

#if ATARI_ST
#define Prefix "/:\\"
#endif					/* ATARI_ST */

#if MSDOS || OS2
#define Prefix "/:\\"
#endif					/* MSDOS || OS2 */

#if MACINTOSH
#define Prefix ":"
#endif					/* MACINTOSH */

#if MVS || VM
#define Prefix ""
#endif					/* MVS || VM */

#if UNIX
#define Prefix "/"
#endif					/* UNIX */

#if VMS
#define Prefix "]:"
#endif					/* VMS */

/*
 * End of operating-system specific code.
 */

/*
 * fparse - break a file name down into component parts.
 *  Result is a pointer to a struct of static pointers good until the next call.
 */
struct fileparts *fparse(s)
char *s;
   {
   static char buf[MaxFileName+2];
   static struct fileparts fp;
   int n;
   char *p, *q;

   q = s;
   fp.ext = p = s + strlen(s);
   while (--p >= s) {
      if (*p == '.' && *fp.ext == '\0')
         fp.ext = p;
      else if (index(Prefix,*p)) {
         q = p+1;
         break;
         }
      }
   fp.dir = buf;
   n = q - s;
   strncpy(fp.dir,s,n);
   fp.dir[n] = '\0';
   fp.name = buf + n + 1;
   n = fp.ext - q;
   strncpy(fp.name,q,n);
   fp.name[n] = '\0';
   return &fp;
   }

/*
 * makename - make a file name, optionally substituting a new dir and/or ext
 */
char *makename(dest,d,name,e)
char *dest, *d, *name, *e;
   {
   struct fileparts fp;
   fp = *fparse(name);
   if (d != NULL)
      fp.dir = d;
   if (e != NULL)
      fp.ext = e;
   sprintf(dest,"%s%s%s",fp.dir,fp.name,fp.ext);
   return dest;
   }

/*
 * smatch - case-insensitive string match - returns nonzero if they match
 */
int smatch(s,t)
char *s, *t;
   {
   char a, b;
   for (;;) {
      while (*s == *t)
         if (*s++ == '\0')
            return 1;
         else
            t++;
      a = *s++;
      b = *t++;
      if (isupper(a))  a = tolower(a);
      if (isupper(b))  b = tolower(b);
      if (a != b)
         return 0;
      }
   }
