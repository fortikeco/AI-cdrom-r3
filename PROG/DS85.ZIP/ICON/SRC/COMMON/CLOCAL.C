#include "../h/gsupport.h"

char junkclocal; /* avoid empty module */
