#include "rtt.h"

int n_tmp_str  = 0;
int n_tmp_cset = 0;
struct sym_entry *params = NULL;

/*
 * clr_def - clear any information related to definitions.
 */
novalue clr_def()
   {
   struct sym_entry *sym;

   n_tmp_str = 0;
   n_tmp_cset = 0;
   while (params != NULL) {
      sym = params;
      params = params->u.param_info.next;
      free_sym(sym);
      }
   free_tend();
   if (v_len != NULL)
      free_sym(v_len);
   v_len = NULL;
   il_indx = 0;
   lbl_num = 0;
   abs_ret = SomeType;
   }

/*
 * ttol - convert a token representing an integer constant into a long
 *  integer value.
 */
long ttol(t)
struct token *t;
{
   register long i;
   register char *s;
   int base;

   s = t->image;
   i = 0;
   base = 10;

   if (*s == '0') {
      base = 8;
      ++s;
      if (*s == 'x') {
         base = 16;
         ++s;
         }
      }
   while (*s != '\0') {
      i *= base;
      if (*s >= '0' && *s <= '9')
         i += *s++ - '0';
      else if (*s >= 'a' && *s <= 'f')
         i += *s++ - 'a' + 10;
      else if (*s >= 'A' && *s <= 'F')
         i += *s++ - 'A' + 10;
      }
   return i;
   }
