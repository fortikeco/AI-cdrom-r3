# define CSETLIT 257
# define EOFX 258
# define IDENT 259
# define INTLIT 260
# define REALLIT 261
# define STRINGLIT 262
# define BREAK 263
# define BY 264
# define CASE 265
# define CREATE 266
# define DEFAULT 267
# define DO 268
# define ELSE 269
# define END 270
# define EVERY 271
# define FAIL 272
# define GLOBAL 273
# define IF 274
# define INITIAL 275
# define INVOCABLE 276
# define LINK 277
# define LOCAL 278
# define NEXT 279
# define NOT 280
# define OF 281
# define PROCEDURE 282
# define RECORD 283
# define REPEAT 284
# define RETURN 285
# define STATIC 286
# define SUSPEND 287
# define THEN 288
# define TO 289
# define UNTIL 290
# define WHILE 291
# define ASSIGN 292
# define AT 293
# define AUGACT 294
# define AUGAND 295
# define AUGEQ 296
# define AUGEQV 297
# define AUGGE 298
# define AUGGT 299
# define AUGLE 300
# define AUGLT 301
# define AUGNE 302
# define AUGNEQV 303
# define AUGSEQ 304
# define AUGSGE 305
# define AUGSGT 306
# define AUGSLE 307
# define AUGSLT 308
# define AUGSNE 309
# define BACKSLASH 310
# define BANG 311
# define BAR 312
# define CARET 313
# define CARETASGN 314
# define COLON 315
# define COMMA 316
# define CONCAT 317
# define CONCATASGN 318
# define CONJUNC 319
# define DIFF 320
# define DIFFASGN 321
# define DOT 322
# define EQUIV 323
# define INTER 324
# define INTERASGN 325
# define LBRACE 326
# define LBRACK 327
# define LCONCAT 328
# define LCONCATASGN 329
# define LEXEQ 330
# define LEXGE 331
# define LEXGT 332
# define LEXLE 333
# define LEXLT 334
# define LEXNE 335
# define LPAREN 336
# define MCOLON 337
# define MINUS 338
# define MINUSASGN 339
# define MOD 340
# define MODASGN 341
# define NOTEQUIV 342
# define NUMEQ 343
# define NUMGE 344
# define NUMGT 345
# define NUMLE 346
# define NUMLT 347
# define NUMNE 348
# define PCOLON 349
# define PLUS 350
# define PLUSASGN 351
# define QMARK 352
# define RBRACE 353
# define RBRACK 354
# define REVASSIGN 355
# define REVSWAP 356
# define RPAREN 357
# define SCANASGN 358
# define SEMICOL 359
# define SLASH 360
# define SLASHASGN 361
# define STAR 362
# define STARASGN 363
# define SWAP 364
# define TILDE 365
# define UNION 366
# define UNIONASGN 367

# line 140 "expanded.g"
#include "../h/gsupport.h"
#include "tproto.h"
#include "trans.h"
#include "tsym.h"
#include "tree.h"
#include "../h/keyword.h"
#undef YYSTYPE
#define YYSTYPE nodeptr
#define YYMAXDEPTH 500
extern int fncargs[];
int idflag;
int id_cnt;
int key_num;



#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#ifndef YYSTYPE
#define YYSTYPE int
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256

# line 426 "expanded.g"

int yyexca[] ={
-1, 0,
	258, 2,
	273, 2,
	276, 2,
	277, 2,
	282, 2,
	283, 2,
	-2, 0,
-1, 1,
	0, -1,
	-2, 0,
-1, 20,
	270, 40,
	359, 42,
	-2, 0,
-1, 86,
	264, 42,
	268, 42,
	269, 42,
	281, 42,
	288, 42,
	289, 42,
	292, 42,
	294, 42,
	295, 42,
	296, 42,
	297, 42,
	298, 42,
	299, 42,
	300, 42,
	301, 42,
	302, 42,
	303, 42,
	304, 42,
	305, 42,
	306, 42,
	307, 42,
	308, 42,
	309, 42,
	314, 42,
	315, 42,
	316, 42,
	318, 42,
	321, 42,
	325, 42,
	329, 42,
	331, 42,
	332, 42,
	333, 42,
	334, 42,
	337, 42,
	339, 42,
	340, 42,
	341, 42,
	344, 42,
	345, 42,
	346, 42,
	347, 42,
	349, 42,
	351, 42,
	353, 42,
	354, 42,
	355, 42,
	356, 42,
	357, 42,
	358, 42,
	359, 42,
	361, 42,
	363, 42,
	364, 42,
	367, 42,
	-2, 0,
-1, 87,
	316, 42,
	357, 42,
	-2, 0,
-1, 88,
	353, 42,
	359, 42,
	-2, 0,
-1, 89,
	316, 42,
	354, 42,
	-2, 0,
-1, 96,
	264, 42,
	268, 42,
	269, 42,
	281, 42,
	288, 42,
	289, 42,
	292, 42,
	294, 42,
	295, 42,
	296, 42,
	297, 42,
	298, 42,
	299, 42,
	300, 42,
	301, 42,
	302, 42,
	303, 42,
	304, 42,
	305, 42,
	306, 42,
	307, 42,
	308, 42,
	309, 42,
	314, 42,
	315, 42,
	316, 42,
	318, 42,
	321, 42,
	325, 42,
	329, 42,
	331, 42,
	332, 42,
	333, 42,
	334, 42,
	337, 42,
	339, 42,
	340, 42,
	341, 42,
	344, 42,
	345, 42,
	346, 42,
	347, 42,
	349, 42,
	351, 42,
	353, 42,
	354, 42,
	355, 42,
	356, 42,
	357, 42,
	358, 42,
	359, 42,
	361, 42,
	363, 42,
	364, 42,
	367, 42,
	-2, 0,
-1, 97,
	264, 42,
	268, 42,
	269, 42,
	281, 42,
	288, 42,
	289, 42,
	292, 42,
	294, 42,
	295, 42,
	296, 42,
	297, 42,
	298, 42,
	299, 42,
	300, 42,
	301, 42,
	302, 42,
	303, 42,
	304, 42,
	305, 42,
	306, 42,
	307, 42,
	308, 42,
	309, 42,
	314, 42,
	315, 42,
	316, 42,
	318, 42,
	321, 42,
	325, 42,
	329, 42,
	331, 42,
	332, 42,
	333, 42,
	334, 42,
	337, 42,
	339, 42,
	340, 42,
	341, 42,
	344, 42,
	345, 42,
	346, 42,
	347, 42,
	349, 42,
	351, 42,
	353, 42,
	354, 42,
	355, 42,
	356, 42,
	357, 42,
	358, 42,
	359, 42,
	361, 42,
	363, 42,
	364, 42,
	367, 42,
	-2, 0,
-1, 111,
	270, 40,
	359, 42,
	-2, 0,
-1, 117,
	270, 40,
	359, 42,
	-2, 0,
-1, 182,
	354, 42,
	-2, 0,
-1, 183,
	316, 42,
	-2, 0,
-1, 184,
	316, 42,
	357, 42,
	-2, 0,
-1, 311,
	316, 42,
	354, 42,
	357, 42,
	-2, 0,
-1, 313,
	353, 42,
	359, 42,
	-2, 0,
-1, 335,
	316, 42,
	353, 42,
	-2, 0,
	};
# define YYNPROD 203
# define YYLAST 769
int yyact[]={

    38,    94,   171,    84,    91,    92,    93,    86,   228,    99,
    83,   353,   352,   358,   175,   102,    95,   313,    98,   359,
   173,    20,   118,    85,    51,   117,   345,   324,   103,    96,
   177,    97,   170,   355,   101,   100,   311,    50,   118,   335,
   311,   329,   312,   119,   232,   311,   110,    41,   172,   168,
   176,   326,   174,   341,    73,    56,    52,    61,   228,   317,
   169,    53,   327,    90,    57,   118,    55,    69,    62,   346,
    88,    89,    54,   356,    67,   350,   334,   336,   228,    68,
    87,   310,    64,   314,   361,   331,    72,    65,   118,   118,
   320,   316,    66,   319,    58,   107,    71,   118,   318,   315,
   106,   360,   108,   214,    60,   325,    59,   333,   116,    63,
    70,    38,    94,   328,    84,    91,    92,    93,    86,   332,
    99,    83,   118,   231,    19,   118,   102,    95,    28,    98,
   218,    29,   105,   185,    85,    51,   180,   183,   182,   103,
    96,   118,    97,   217,   118,   101,   100,   184,    50,   118,
   118,   321,   113,   179,   181,   114,   178,    24,   309,   109,
    25,    32,     3,   115,   212,    73,    56,    52,    61,    34,
   330,   351,    53,   306,    90,    57,    44,    55,    69,    62,
    45,    88,    89,    54,    37,    67,    82,   104,    23,    27,
    68,    87,     2,    64,    31,    81,    17,    72,    65,    80,
   273,   274,    79,    66,    78,    58,    77,    71,   305,    13,
    76,    75,    15,    14,    74,    60,    49,    59,    16,    11,
    63,    70,    38,    94,    47,    84,    91,    92,    93,    86,
    42,    99,    83,    40,   112,   322,    30,   102,    95,   111,
    98,    33,    12,     4,   233,    85,    51,    18,    21,    22,
   103,    96,    26,    97,   216,    10,   101,   100,    13,    50,
     9,    15,    14,     8,     7,     6,     5,    16,    11,     1,
     0,     0,     0,     0,     0,     0,    73,    56,    52,    61,
    36,   235,     0,    53,     0,    90,    57,   238,    55,    69,
    62,     0,    88,    89,    54,   229,    67,   230,   234,     0,
   236,    68,    87,   239,    64,     0,     0,     0,    72,    65,
     0,     0,     0,     0,    66,     0,    58,     0,    71,     0,
     0,     0,     0,     0,     0,     0,    60,     0,    59,     0,
     0,    63,    70,    94,     0,    84,    91,    92,    93,    86,
     0,    99,    83,     0,     0,   289,   290,   102,    95,   308,
    98,   291,   292,   293,   294,    85,    51,     0,     0,     0,
   103,    96,     0,    97,   210,     0,   101,   100,     0,    50,
     0,     0,   362,     0,     0,     0,   347,     0,   221,   222,
   223,   224,   225,   226,   227,     0,    73,    56,    52,    61,
     0,     0,     0,    53,   237,    90,    57,     0,    55,    69,
    62,     0,    88,    89,    54,     0,    67,     0,     0,     0,
     0,    68,    87,     0,    64,    46,     0,   338,    72,    65,
   323,     0,     0,     0,    66,     0,    58,     0,    71,     0,
     0,     0,    35,     0,     0,     0,    60,    39,    59,     0,
   152,    63,    70,   121,     0,   151,   150,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,     0,     0,   304,   153,   134,     0,     0,     0,   124,
     0,     0,   126,     0,     0,   166,   131,     0,     0,     0,
   125,    48,   154,   155,   156,   157,   158,   159,    43,     0,
   129,     0,   133,     0,   167,   160,   161,   162,   163,   164,
   165,     0,   128,     0,     0,     0,   123,   122,     0,   149,
     0,     0,   132,     0,   130,   120,     0,     0,   127,   211,
   213,   215,   213,     0,     0,     0,     0,     0,     0,   219,
   220,     0,   186,   187,   188,   189,   190,   191,   192,   193,
   194,   195,   196,   197,   198,   199,   200,   201,   202,   203,
   204,   205,   206,   207,   208,   209,     0,   240,   241,   242,
   243,   244,   245,   246,   247,   248,   249,   250,   251,   252,
   253,   254,   255,   256,   257,   258,   259,   260,   261,   262,
   263,   264,   265,   266,   267,   268,   269,   270,   271,   272,
   295,   296,   297,   298,   299,     0,   339,   340,     0,   342,
   343,   344,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   348,     0,     0,     0,   303,   307,   213,     0,     0,
     0,     0,   354,     0,     0,     0,     0,     0,     0,     0,
     0,   357,     0,     0,     0,     0,     0,     0,     0,     0,
   354,   363,   364,   275,   276,   277,   278,   279,   280,   281,
   282,   283,   284,   285,   286,   287,   288,     0,     0,     0,
     0,   300,   301,   302,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   337,     0,   215,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   349 };
int yypact[]={

   -94, -1000,   -15, -1000, -1000, -1000, -1000, -1000, -1000, -1000,
 -1000, -1000,  -235, -1000,  -102,  -131, -1000,   -64,   -98, -1000,
   -34,  -127,  -216, -1000, -1000, -1000,  -221, -1000, -1000,  -213,
  -100, -1000,  -290,  -123,  -162,  -334,  -254,  -309, -1000, -1000,
   151, -1000,   152,  -268,  -318,  -310, -1000,  -157, -1000,  -189,
    76,    76,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    76, -1000, -1000, -1000, -1000, -1000, -1000,
 -1000, -1000, -1000,   -34, -1000, -1000,   -34,   -34,   -34,   -34,
  -129, -1000, -1000, -1000, -1000, -1000,   -34,   -34,   -34,   -34,
   -34,   -34,   -34,   -34,  -238, -1000,  -102,  -131,  -137,  -292,
  -127,   -34,  -127,   -34, -1000, -1000, -1000,   -34,    76,    76,
    76,    76,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,   -34,  -145,   -34,  -101, -1000, -1000, -1000, -1000,
 -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000,
 -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000,
  -254, -1000,  -276, -1000,  -311,  -342,  -271, -1000, -1000, -1000,
 -1000,  -169,  -197,  -222,  -170,  -175,  -178,  -254,  -108, -1000,
 -1000, -1000,  -127,  -330,  -238,  -165,  -308,  -297, -1000,  -309,
 -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000,
 -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000,
 -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000,
 -1000, -1000, -1000,  -151, -1000,  -268,  -268,  -268,  -268,  -268,
  -268,  -268,  -268,  -268,  -268,  -268,  -268,  -268,  -268,  -318,
  -318,  -310,  -310,  -310,  -310, -1000, -1000, -1000, -1000, -1000,
 -1000, -1000, -1000,  -313,  -230, -1000,  -277, -1000,  -280, -1000,
 -1000,   -34, -1000,   -34, -1000,   -34,   -34,  -273,   -34,   -34,
   -34, -1000,  -331,  -258, -1000, -1000, -1000, -1000,    76, -1000,
   -34, -1000, -1000, -1000, -1000,   -34, -1000, -1000, -1000,  -254,
  -194,  -256,  -254,  -254,  -254, -1000,  -321, -1000,  -281, -1000,
   -34,  -340, -1000,  -214,  -231, -1000, -1000,  -254, -1000,  -256,
   -34,   -34, -1000,  -254,  -254 };
int yypgo[]={

     0,   269,   192,   266,   265,   264,   263,   260,   255,   252,
   189,   249,   188,   248,   187,   247,   244,   242,   241,   239,
   169,   236,   235,   234,   280,   432,   184,   437,   233,    47,
   230,   488,   176,   180,   415,   224,   481,   216,   214,   211,
   210,   206,   204,   202,   199,   195,   186,   164,   103,   173,
   171,    12,   170 };
int yyr1[]={

     0,     1,     2,     2,     3,     3,     3,     3,     3,     8,
     9,     9,    10,    10,    10,     7,    11,    11,    12,    12,
    13,     6,    15,     4,    16,    16,     5,    21,    17,    22,
    22,    22,    14,    14,    18,    18,    23,    23,    19,    19,
    20,    20,    25,    25,    24,    24,    26,    26,    27,    27,
    27,    27,    27,    27,    27,    27,    27,    27,    27,    27,
    27,    27,    27,    27,    27,    27,    27,    27,    27,    27,
    27,    27,    27,    27,    27,    27,    27,    27,    27,    27,
    27,    28,    28,    28,    29,    29,    30,    30,    30,    30,
    30,    30,    30,    30,    30,    30,    30,    30,    30,    30,
    30,    31,    31,    31,    32,    32,    32,    32,    32,    33,
    33,    33,    33,    33,    34,    34,    35,    35,    35,    35,
    36,    36,    36,    36,    36,    36,    36,    36,    36,    36,
    36,    36,    36,    36,    36,    36,    36,    36,    36,    36,
    36,    36,    36,    36,    36,    37,    37,    37,    37,    37,
    37,    37,    37,    37,    37,    37,    37,    37,    37,    37,
    37,    37,    37,    37,    37,    37,    37,    37,    43,    43,
    44,    44,    45,    45,    46,    40,    40,    40,    40,    41,
    41,    42,    50,    50,    51,    51,    47,    47,    49,    49,
    38,    38,    38,    38,    39,    52,    52,    52,    48,    48,
     1,     5,    24 };
int yyr2[]={

     0,     5,     0,     4,     3,     3,     3,     3,     2,     4,
     2,     6,     2,     2,     6,     5,     2,     7,     3,     3,
     1,     7,     1,    13,     1,     3,    13,     1,    13,     1,
     3,     7,     3,     7,     1,     9,     3,     3,     1,     7,
     1,     7,     1,     2,     2,     7,     2,     7,     2,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     2,     7,    11,     2,     7,     2,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     2,     7,     7,     2,     7,     7,     7,     7,     2,
     7,     7,     7,     7,     2,     7,     2,     7,     7,     7,
     2,     5,     5,     5,     5,     5,     5,     5,     5,     5,
     5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
     5,     5,     5,     5,     5,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     5,     3,     3,     5,     7,     7,
     7,     9,     7,     9,     9,     7,     5,     5,     5,     9,
     5,     9,     5,     9,     5,     3,     5,     5,     9,     9,
    13,    13,     2,     7,     7,     7,     2,     7,     3,     7,
     3,     3,     3,     3,    13,     3,     3,     3,     2,     7,
     6,     8,     2 };
int yychk[]={

 -1000,    -1,    -2,   256,   258,    -3,    -4,    -5,    -6,    -7,
    -8,   283,   -17,   273,   277,   276,   282,    -2,   -15,   359,
   256,   -13,   -11,   -12,   259,   262,    -9,   -10,   259,   262,
   -21,   258,   259,   -18,   -20,   -25,   -24,   -26,   256,   -27,
   -28,   -29,   -30,   -31,   -32,   -33,   -34,   -35,   -36,   -37,
   293,   280,   312,   317,   328,   322,   311,   320,   350,   362,
   360,   313,   324,   365,   338,   343,   348,   330,   335,   323,
   366,   352,   342,   310,   -38,   -39,   -40,   -41,   -42,   -43,
   -44,   -45,   -46,   266,   259,   279,   263,   336,   326,   327,
   319,   260,   261,   262,   257,   272,   285,   287,   274,   265,
   291,   290,   271,   284,   -14,   259,   316,   316,   315,   259,
   336,   -19,   -23,   275,   278,   286,   270,   359,   319,   352,
   364,   292,   356,   355,   318,   329,   321,   367,   351,   339,
   363,   325,   361,   341,   314,   296,   297,   298,   299,   300,
   301,   302,   303,   304,   305,   306,   307,   308,   309,   358,
   295,   294,   289,   312,   330,   331,   332,   333,   334,   335,
   343,   344,   345,   346,   347,   348,   323,   342,   317,   328,
   350,   320,   366,   338,   362,   324,   360,   340,   313,   310,
   293,   311,   327,   326,   336,   322,   -36,   -36,   -36,   -36,
   -36,   -36,   -36,   -36,   -36,   -36,   -36,   -36,   -36,   -36,
   -36,   -36,   -36,   -36,   -36,   -36,   -36,   -36,   -36,   -36,
   -24,   -25,   -47,   -25,   -48,   -25,   -47,   272,   259,   -25,
   -25,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   316,   -12,
   -10,   260,   336,   -16,   -14,   -20,   -14,   -24,   -20,   -26,
   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,
   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,
   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,   -27,
   -27,   -27,   -27,   -29,   -29,   -31,   -31,   -31,   -31,   -31,
   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -32,
   -32,   -33,   -33,   -33,   -33,   -34,   -34,   -34,   -34,   -34,
   -36,   -36,   -36,   -25,   -24,   353,   -49,   -25,   -47,   259,
   357,   316,   353,   359,   354,   268,   288,   281,   268,   268,
   268,   259,   -22,   -14,   357,   270,   359,   359,   264,   354,
   -52,   315,   349,   337,   353,   316,   357,   -25,   -48,   -24,
   -24,   326,   -24,   -24,   -24,   357,   327,   -29,   -24,   -25,
   269,   -50,   -51,   267,   -24,   354,   354,   -24,   353,   359,
   315,   315,   -51,   -24,   -24 };
int yydef[]={

    -2,    -2,     0,     2,     1,     3,     4,     5,     6,     7,
     8,    22,     0,    20,     0,     0,    27,     0,     0,    34,
    -2,     0,    15,    16,    18,    19,     9,    10,    12,    13,
     0,   200,     0,    38,     0,     0,    43,    44,   202,    46,
    48,    81,    84,    86,   101,   104,   109,   114,   116,   120,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   145,   146,   147,   148,   149,   150,
   151,   152,   153,     0,   155,   156,    -2,    -2,    -2,    -2,
     0,   190,   191,   192,   193,   175,    -2,    -2,     0,     0,
     0,     0,     0,     0,    21,    32,     0,     0,     0,     0,
    24,    -2,     0,     0,    36,    37,   201,    -2,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,    -2,    -2,    -2,     0,   121,   122,   123,   124,
   125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
   135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
   154,   157,     0,   186,     0,   198,     0,   166,   167,   176,
   177,    43,     0,     0,   168,   170,   172,   174,     0,    17,
    11,    14,    29,     0,    25,     0,     0,     0,    41,    45,
    47,    49,    50,    51,    52,    53,    54,    55,    56,    57,
    58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
    68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
    78,    79,    80,    82,    85,    87,    88,    89,    90,    91,
    92,    93,    94,    95,    96,    97,    98,    99,   100,   102,
   103,   105,   106,   107,   108,   110,   111,   112,   113,   115,
   117,   118,   119,     0,    43,   162,     0,   188,     0,   165,
   158,    -2,   159,    -2,   160,     0,     0,     0,     0,     0,
     0,    33,     0,    30,    23,    26,    35,    39,     0,   161,
     0,   195,   196,   197,   163,    -2,   164,   187,   199,   178,
   179,     0,   169,   171,   173,    28,     0,    83,     0,   189,
     0,     0,   182,     0,     0,    31,   194,   180,   181,     0,
     0,     0,   183,   184,   185 };
typedef struct { char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"CSETLIT",	257,
	"EOFX",	258,
	"IDENT",	259,
	"INTLIT",	260,
	"REALLIT",	261,
	"STRINGLIT",	262,
	"BREAK",	263,
	"BY",	264,
	"CASE",	265,
	"CREATE",	266,
	"DEFAULT",	267,
	"DO",	268,
	"ELSE",	269,
	"END",	270,
	"EVERY",	271,
	"FAIL",	272,
	"GLOBAL",	273,
	"IF",	274,
	"INITIAL",	275,
	"INVOCABLE",	276,
	"LINK",	277,
	"LOCAL",	278,
	"NEXT",	279,
	"NOT",	280,
	"OF",	281,
	"PROCEDURE",	282,
	"RECORD",	283,
	"REPEAT",	284,
	"RETURN",	285,
	"STATIC",	286,
	"SUSPEND",	287,
	"THEN",	288,
	"TO",	289,
	"UNTIL",	290,
	"WHILE",	291,
	"ASSIGN",	292,
	"AT",	293,
	"AUGACT",	294,
	"AUGAND",	295,
	"AUGEQ",	296,
	"AUGEQV",	297,
	"AUGGE",	298,
	"AUGGT",	299,
	"AUGLE",	300,
	"AUGLT",	301,
	"AUGNE",	302,
	"AUGNEQV",	303,
	"AUGSEQ",	304,
	"AUGSGE",	305,
	"AUGSGT",	306,
	"AUGSLE",	307,
	"AUGSLT",	308,
	"AUGSNE",	309,
	"BACKSLASH",	310,
	"BANG",	311,
	"BAR",	312,
	"CARET",	313,
	"CARETASGN",	314,
	"COLON",	315,
	"COMMA",	316,
	"CONCAT",	317,
	"CONCATASGN",	318,
	"CONJUNC",	319,
	"DIFF",	320,
	"DIFFASGN",	321,
	"DOT",	322,
	"EQUIV",	323,
	"INTER",	324,
	"INTERASGN",	325,
	"LBRACE",	326,
	"LBRACK",	327,
	"LCONCAT",	328,
	"LCONCATASGN",	329,
	"LEXEQ",	330,
	"LEXGE",	331,
	"LEXGT",	332,
	"LEXLE",	333,
	"LEXLT",	334,
	"LEXNE",	335,
	"LPAREN",	336,
	"MCOLON",	337,
	"MINUS",	338,
	"MINUSASGN",	339,
	"MOD",	340,
	"MODASGN",	341,
	"NOTEQUIV",	342,
	"NUMEQ",	343,
	"NUMGE",	344,
	"NUMGT",	345,
	"NUMLE",	346,
	"NUMLT",	347,
	"NUMNE",	348,
	"PCOLON",	349,
	"PLUS",	350,
	"PLUSASGN",	351,
	"QMARK",	352,
	"RBRACE",	353,
	"RBRACK",	354,
	"REVASSIGN",	355,
	"REVSWAP",	356,
	"RPAREN",	357,
	"SCANASGN",	358,
	"SEMICOL",	359,
	"SLASH",	360,
	"SLASHASGN",	361,
	"STAR",	362,
	"STARASGN",	363,
	"SWAP",	364,
	"TILDE",	365,
	"UNION",	366,
	"UNIONASGN",	367,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"program : decls EOFX",
	"decls : /* empty */",
	"decls : decls decl",
	"decl : record",
	"decl : proc",
	"decl : global",
	"decl : link",
	"decl : invocable",
	"invocable : INVOCABLE invoclist",
	"invoclist : invocop",
	"invoclist : invoclist COMMA invocop",
	"invocop : IDENT",
	"invocop : STRINGLIT",
	"invocop : STRINGLIT COLON INTLIT",
	"link : LINK lnklist",
	"lnklist : lnkfile",
	"lnklist : lnklist COMMA lnkfile",
	"lnkfile : IDENT",
	"lnkfile : STRINGLIT",
	"global : GLOBAL",
	"global : GLOBAL idlist",
	"record : RECORD",
	"record : RECORD IDENT LPAREN fldlist RPAREN",
	"fldlist : /* empty */",
	"fldlist : idlist",
	"proc : prochead SEMICOL locals initial procbody END",
	"prochead : PROCEDURE",
	"prochead : PROCEDURE IDENT LPAREN arglist RPAREN",
	"arglist : /* empty */",
	"arglist : idlist",
	"arglist : idlist LBRACK RBRACK",
	"idlist : IDENT",
	"idlist : idlist COMMA IDENT",
	"locals : /* empty */",
	"locals : locals retention idlist SEMICOL",
	"retention : LOCAL",
	"retention : STATIC",
	"initial : /* empty */",
	"initial : INITIAL expr SEMICOL",
	"procbody : /* empty */",
	"procbody : nexpr SEMICOL procbody",
	"nexpr : /* empty */",
	"nexpr : expr",
	"expr : expr1a",
	"expr : expr CONJUNC expr1a",
	"expr1a : expr1",
	"expr1a : expr1a QMARK expr1",
	"expr1 : expr2",
	"expr1 : expr2 SWAP expr1",
	"expr1 : expr2 ASSIGN expr1",
	"expr1 : expr2 REVSWAP expr1",
	"expr1 : expr2 REVASSIGN expr1",
	"expr1 : expr2 CONCATASGN expr1",
	"expr1 : expr2 LCONCATASGN expr1",
	"expr1 : expr2 DIFFASGN expr1",
	"expr1 : expr2 UNIONASGN expr1",
	"expr1 : expr2 PLUSASGN expr1",
	"expr1 : expr2 MINUSASGN expr1",
	"expr1 : expr2 STARASGN expr1",
	"expr1 : expr2 INTERASGN expr1",
	"expr1 : expr2 SLASHASGN expr1",
	"expr1 : expr2 MODASGN expr1",
	"expr1 : expr2 CARETASGN expr1",
	"expr1 : expr2 AUGEQ expr1",
	"expr1 : expr2 AUGEQV expr1",
	"expr1 : expr2 AUGGE expr1",
	"expr1 : expr2 AUGGT expr1",
	"expr1 : expr2 AUGLE expr1",
	"expr1 : expr2 AUGLT expr1",
	"expr1 : expr2 AUGNE expr1",
	"expr1 : expr2 AUGNEQV expr1",
	"expr1 : expr2 AUGSEQ expr1",
	"expr1 : expr2 AUGSGE expr1",
	"expr1 : expr2 AUGSGT expr1",
	"expr1 : expr2 AUGSLE expr1",
	"expr1 : expr2 AUGSLT expr1",
	"expr1 : expr2 AUGSNE expr1",
	"expr1 : expr2 SCANASGN expr1",
	"expr1 : expr2 AUGAND expr1",
	"expr1 : expr2 AUGACT expr1",
	"expr2 : expr3",
	"expr2 : expr2 TO expr3",
	"expr2 : expr2 TO expr3 BY expr3",
	"expr3 : expr4",
	"expr3 : expr4 BAR expr3",
	"expr4 : expr5",
	"expr4 : expr4 LEXEQ expr5",
	"expr4 : expr4 LEXGE expr5",
	"expr4 : expr4 LEXGT expr5",
	"expr4 : expr4 LEXLE expr5",
	"expr4 : expr4 LEXLT expr5",
	"expr4 : expr4 LEXNE expr5",
	"expr4 : expr4 NUMEQ expr5",
	"expr4 : expr4 NUMGE expr5",
	"expr4 : expr4 NUMGT expr5",
	"expr4 : expr4 NUMLE expr5",
	"expr4 : expr4 NUMLT expr5",
	"expr4 : expr4 NUMNE expr5",
	"expr4 : expr4 EQUIV expr5",
	"expr4 : expr4 NOTEQUIV expr5",
	"expr5 : expr6",
	"expr5 : expr5 CONCAT expr6",
	"expr5 : expr5 LCONCAT expr6",
	"expr6 : expr7",
	"expr6 : expr6 PLUS expr7",
	"expr6 : expr6 DIFF expr7",
	"expr6 : expr6 UNION expr7",
	"expr6 : expr6 MINUS expr7",
	"expr7 : expr8",
	"expr7 : expr7 STAR expr8",
	"expr7 : expr7 INTER expr8",
	"expr7 : expr7 SLASH expr8",
	"expr7 : expr7 MOD expr8",
	"expr8 : expr9",
	"expr8 : expr9 CARET expr8",
	"expr9 : expr10",
	"expr9 : expr9 BACKSLASH expr10",
	"expr9 : expr9 AT expr10",
	"expr9 : expr9 BANG expr10",
	"expr10 : expr11",
	"expr10 : AT expr10",
	"expr10 : NOT expr10",
	"expr10 : BAR expr10",
	"expr10 : CONCAT expr10",
	"expr10 : LCONCAT expr10",
	"expr10 : DOT expr10",
	"expr10 : BANG expr10",
	"expr10 : DIFF expr10",
	"expr10 : PLUS expr10",
	"expr10 : STAR expr10",
	"expr10 : SLASH expr10",
	"expr10 : CARET expr10",
	"expr10 : INTER expr10",
	"expr10 : TILDE expr10",
	"expr10 : MINUS expr10",
	"expr10 : NUMEQ expr10",
	"expr10 : NUMNE expr10",
	"expr10 : LEXEQ expr10",
	"expr10 : LEXNE expr10",
	"expr10 : EQUIV expr10",
	"expr10 : UNION expr10",
	"expr10 : QMARK expr10",
	"expr10 : NOTEQUIV expr10",
	"expr10 : BACKSLASH expr10",
	"expr11 : literal",
	"expr11 : section",
	"expr11 : return",
	"expr11 : if",
	"expr11 : case",
	"expr11 : while",
	"expr11 : until",
	"expr11 : every",
	"expr11 : repeat",
	"expr11 : CREATE expr",
	"expr11 : IDENT",
	"expr11 : NEXT",
	"expr11 : BREAK nexpr",
	"expr11 : LPAREN exprlist RPAREN",
	"expr11 : LBRACE compound RBRACE",
	"expr11 : LBRACK exprlist RBRACK",
	"expr11 : expr11 LBRACK nexpr RBRACK",
	"expr11 : expr11 LBRACE RBRACE",
	"expr11 : expr11 LBRACE pdcolist RBRACE",
	"expr11 : expr11 LPAREN exprlist RPAREN",
	"expr11 : expr11 DOT IDENT",
	"expr11 : CONJUNC FAIL",
	"expr11 : CONJUNC IDENT",
	"while : WHILE expr",
	"while : WHILE expr DO expr",
	"until : UNTIL expr",
	"until : UNTIL expr DO expr",
	"every : EVERY expr",
	"every : EVERY expr DO expr",
	"repeat : REPEAT expr",
	"return : FAIL",
	"return : RETURN nexpr",
	"return : SUSPEND nexpr",
	"return : SUSPEND expr DO expr",
	"if : IF expr THEN expr",
	"if : IF expr THEN expr ELSE expr",
	"case : CASE expr OF LBRACE caselist RBRACE",
	"caselist : cclause",
	"caselist : caselist SEMICOL cclause",
	"cclause : DEFAULT COLON expr",
	"cclause : expr COLON expr",
	"exprlist : nexpr",
	"exprlist : exprlist COMMA nexpr",
	"pdcolist : nexpr",
	"pdcolist : pdcolist COMMA nexpr",
	"literal : INTLIT",
	"literal : REALLIT",
	"literal : STRINGLIT",
	"literal : CSETLIT",
	"section : expr11 LBRACK expr sectop expr RBRACK",
	"sectop : COLON",
	"sectop : PCOLON",
	"sectop : MCOLON",
	"compound : nexpr",
	"compound : nexpr SEMICOL compound",
	"program : error decls EOFX",
	"proc : prochead error procbody END",
	"expr : error",
};
#endif
#line 1 "/usr/lib/yaccpar"
/*	@(#)yaccpar 1.10 89/04/04 SMI; from S5R3 1.10	*/

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	{ free((char *)yys); free((char *)yyv); return(0); }
#define YYABORT		{ free((char *)yys); free((char *)yyv); return(1); }
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		tsyserr("parser: syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-1000)

/*
** static variables used by the parser
*/
static YYSTYPE *yyv;			/* value stack */
static int *yys;			/* state stack */

static YYSTYPE *yypv;			/* top of value stack */
static int *yyps;			/* top of state stack */

static int yystate;			/* current state */
static int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */

int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */


/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
int
yyparse()
{
	register YYSTYPE *yypvt;	/* top of value stack for $vars */
	unsigned yymaxdepth = YYMAXDEPTH;

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yyv = (YYSTYPE*)malloc(yymaxdepth*sizeof(YYSTYPE));
	yys = (int*)malloc(yymaxdepth*sizeof(int));
	if (!yyv || !yys)
	{
		tsyserr("parser: out of memory" );
		return(1);
	}
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

	goto yystack;
	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			(void)printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			int yyps_index = (yy_ps - yys);
			int yypv_index = (yy_pv - yyv);
			int yypvt_index = (yypvt - yyv);
			yymaxdepth += YYMAXDEPTH;
			yyv = (YYSTYPE*)realloc((char*)yyv,
				yymaxdepth * sizeof(YYSTYPE));
			yys = (int*)realloc((char*)yys,
				yymaxdepth * sizeof(int));
			if (!yyv || !yys)
			{
				tsyserr("parse stack overflow" );
				return(1);
			}
			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			(void)printf( "Received token " );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				(void)printf( "Received token " );
				if ( yychar == 0 )
					(void)printf( "end-of-file\n" );
				else if ( yychar < 0 )
					(void)printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					(void)printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror(yychar, yylval, yy_state );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				yynerrs++;
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						(void)printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					(void)printf( "Error recovery discards " );
					if ( yychar == 0 )
						(void)printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						(void)printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						(void)printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			(void)printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 1:
# line 160 "expanded.g"
{gout(globfile) ;} break;
case 4:
# line 165 "expanded.g"
{if (!nocode)	rout(globfile, Str0(yypvt[-0]));	nocode = 0;	loc_init() ;} break;
case 5:
# line 166 "expanded.g"
{if (!nocode)	codegen(yypvt[-0]);	nocode = 0;	treeinit();	loc_init() ;} break;
case 6:
# line 167 "expanded.g"
{;} break;
case 7:
# line 168 "expanded.g"
{;} break;
case 15:
# line 181 "expanded.g"
{;} break;
case 17:
# line 184 "expanded.g"
{;} break;
case 18:
# line 186 "expanded.g"
{addlfile(Str0(yypvt[-0])) ;} break;
case 19:
# line 187 "expanded.g"
{addlfile(Str0(yypvt[-0])) ;} break;
case 20:
# line 189 "expanded.g"
{idflag = F_Global ;} break;
case 21:
# line 189 "expanded.g"
{;} break;
case 22:
# line 191 "expanded.g"
{idflag = F_Argument ;} break;
case 23:
# line 191 "expanded.g"
{
		install(Str0(yypvt[-3]),F_Record|F_Global,id_cnt); yyval = yypvt[-3] ;
		} break;
case 24:
# line 195 "expanded.g"
{id_cnt = 0 ;} break;
case 25:
# line 196 "expanded.g"
{;} break;
case 26:
# line 198 "expanded.g"
{
		yyval = tree6(N_Proc,yypvt[-5],yypvt[-5],yypvt[-2],yypvt[-1],yypvt[-0]) ;
		} break;
case 27:
# line 202 "expanded.g"
{idflag = F_Argument ;} break;
case 28:
# line 202 "expanded.g"
{
		yyval = yypvt[-3];	install(Str0(yypvt[-3]),F_Proc|F_Global,id_cnt) ;
		} break;
case 29:
# line 206 "expanded.g"
{id_cnt = 0 ;} break;
case 30:
# line 207 "expanded.g"
{;} break;
case 31:
# line 208 "expanded.g"
{id_cnt = -id_cnt ;} break;
case 32:
# line 211 "expanded.g"
{
		install(Str0(yypvt[-0]),idflag,0);	id_cnt = 1 ;
		} break;
case 33:
# line 214 "expanded.g"
{
		install(Str0(yypvt[-0]),idflag,0);	++id_cnt ;
		} break;
case 34:
# line 218 "expanded.g"
{;} break;
case 35:
# line 219 "expanded.g"
{;} break;
case 36:
# line 221 "expanded.g"
{idflag = F_Dynamic ;} break;
case 37:
# line 222 "expanded.g"
{idflag = F_Static ;} break;
case 38:
# line 224 "expanded.g"
{yyval = tree1(N_Empty)  ;} break;
case 39:
# line 225 "expanded.g"
{yyval = yypvt[-1] ;} break;
case 40:
# line 227 "expanded.g"
{yyval = tree1(N_Empty)  ;} break;
case 41:
# line 228 "expanded.g"
{yyval = tree4(N_Slist,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 42:
# line 230 "expanded.g"
{yyval = tree1(N_Empty)  ;} break;
case 45:
# line 234 "expanded.g"
{yyval = tree5(N_Conj,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 47:
# line 237 "expanded.g"
{yyval = tree5(N_Scan,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 49:
# line 240 "expanded.g"
case 50:
# line 241 "expanded.g"
case 51:
# line 242 "expanded.g"
case 52:
# line 243 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 53:
# line 244 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 54:
# line 245 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 55:
# line 246 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 56:
# line 247 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 57:
# line 248 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 58:
# line 249 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 59:
# line 250 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 60:
# line 251 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 61:
# line 252 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 62:
# line 253 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 63:
# line 254 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 64:
# line 255 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 65:
# line 256 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 66:
# line 257 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 67:
# line 258 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 68:
# line 259 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 69:
# line 260 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 70:
# line 261 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 71:
# line 262 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 72:
# line 263 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 73:
# line 264 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 74:
# line 265 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 75:
# line 266 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 76:
# line 267 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 77:
# line 268 "expanded.g"
{yyval = tree5(N_Augop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 78:
# line 269 "expanded.g"
{yyval = tree5(N_Scan,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 79:
# line 270 "expanded.g"
{yyval = tree5(N_Conj,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 80:
# line 271 "expanded.g"
{yyval = tree5(N_Activat,yypvt[-1],yypvt[-1],yypvt[-0],yypvt[-2]) ;} break;
case 82:
# line 274 "expanded.g"
{yyval = tree4(N_To,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 83:
# line 275 "expanded.g"
{yyval = tree5(N_ToBy,yypvt[-3],yypvt[-4],yypvt[-2],yypvt[-0]) ;} break;
case 85:
# line 278 "expanded.g"
{yyval = tree4(N_Alt,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 87:
# line 281 "expanded.g"
case 88:
# line 282 "expanded.g"
case 89:
# line 283 "expanded.g"
case 90:
# line 284 "expanded.g"
case 91:
# line 285 "expanded.g"
case 92:
# line 286 "expanded.g"
case 93:
# line 287 "expanded.g"
case 94:
# line 288 "expanded.g"
case 95:
# line 289 "expanded.g"
case 96:
# line 290 "expanded.g"
case 97:
# line 291 "expanded.g"
case 98:
# line 292 "expanded.g"
case 99:
# line 293 "expanded.g"
case 100:
# line 294 "expanded.g"
case 102:
# line 297 "expanded.g"
case 103:
# line 298 "expanded.g"
case 105:
# line 301 "expanded.g"
case 106:
# line 302 "expanded.g"
case 107:
# line 303 "expanded.g"
case 108:
# line 304 "expanded.g"
case 110:
# line 307 "expanded.g"
case 111:
# line 308 "expanded.g"
case 112:
# line 309 "expanded.g"
case 113:
# line 310 "expanded.g"
case 115:
# line 313 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-1],yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 117:
# line 316 "expanded.g"
{yyval = tree4(N_Limit,yypvt[-2],yypvt[-2],yypvt[-0]) ;} break;
case 118:
# line 317 "expanded.g"
{yyval = tree5(N_Activat,yypvt[-1],yypvt[-1],yypvt[-0],yypvt[-2]) ;} break;
case 119:
# line 318 "expanded.g"
{yyval = tree4(N_Apply,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 121:
# line 321 "expanded.g"
{yyval = tree5(N_Activat,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 122:
# line 322 "expanded.g"
{yyval = tree3(N_Not,yypvt[-0],yypvt[-0]) ;} break;
case 123:
# line 323 "expanded.g"
{yyval = tree3(N_Bar,yypvt[-0],yypvt[-0]) ;} break;
case 124:
# line 324 "expanded.g"
{yyval = tree3(N_Bar,yypvt[-0],yypvt[-0]) ;} break;
case 125:
# line 325 "expanded.g"
{yyval = tree3(N_Bar,yypvt[-0],yypvt[-0]) ;} break;
case 126:
# line 326 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 127:
# line 327 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 128:
# line 328 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 129:
# line 329 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 130:
# line 330 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 131:
# line 331 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 132:
# line 332 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 133:
# line 333 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 134:
# line 334 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 135:
# line 335 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 136:
# line 336 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 137:
# line 337 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 138:
# line 338 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 139:
# line 339 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 140:
# line 340 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 141:
# line 341 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 142:
# line 342 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 143:
# line 343 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 144:
# line 344 "expanded.g"
{yyval = tree4(N_Unop,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 154:
# line 354 "expanded.g"
{yyval = tree3(N_Create,yypvt[-1],yypvt[-0]) ;} break;
case 155:
# line 355 "expanded.g"
{Val0(yypvt[-0]) = putloc(Str0(yypvt[-0]),0) ;} break;
case 156:
# line 356 "expanded.g"
{yyval = tree2(N_Next,yypvt[-0]) ;} break;
case 157:
# line 357 "expanded.g"
{yyval = tree3(N_Break,yypvt[-1],yypvt[-0]) ;} break;
case 158:
# line 358 "expanded.g"
{if ((yypvt[-1])->n_type == N_Elist) yyval = tree4(N_Invok,yypvt[-2],tree1(N_Empty) ,yypvt[-1]); else yyval = yypvt[-1] ;} break;
case 159:
# line 359 "expanded.g"
{yyval = yypvt[-1] ;} break;
case 160:
# line 360 "expanded.g"
{yyval = tree3(N_List,yypvt[-2],yypvt[-1]) ;} break;
case 161:
# line 361 "expanded.g"
{yyval = tree5(N_Binop,yypvt[-2],yypvt[-2],yypvt[-3],yypvt[-1]) ;} break;
case 162:
# line 362 "expanded.g"
{yyval = tree4(N_Invok,yypvt[-1],yypvt[-2],	tree3(N_List,yypvt[-1],tree1(N_Empty) )) ;} break;
case 163:
# line 363 "expanded.g"
{yyval = tree4(N_Invok,yypvt[-2],yypvt[-3],tree3(N_List,yypvt[-2],yypvt[-1])) ;} break;
case 164:
# line 367 "expanded.g"
{yyval = tree4(N_Invok,yypvt[-2],yypvt[-3],yypvt[-1]) ;} break;
case 165:
# line 368 "expanded.g"
{yyval = tree4(N_Field,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 166:
# line 369 "expanded.g"
{yyval = int_leaf(N_Key,yypvt[-1],K_FAIL) ;} break;
case 167:
# line 370 "expanded.g"
{if ((key_num = klookup(Str0(yypvt[-0]))) == 0)	tfatal("invalid keyword",Str0(yypvt[-0]));	yyval = int_leaf(N_Key,yypvt[-1],key_num) ;} break;
case 168:
# line 372 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 169:
# line 373 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-3],yypvt[-3],yypvt[-2],yypvt[-0]) ;} break;
case 170:
# line 375 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 171:
# line 376 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-3],yypvt[-3],yypvt[-2],yypvt[-0]) ;} break;
case 172:
# line 378 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 173:
# line 379 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-3],yypvt[-3],yypvt[-2],yypvt[-0]) ;} break;
case 174:
# line 381 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 175:
# line 383 "expanded.g"
{yyval = tree4(N_Ret,yypvt[-0],yypvt[-0],tree1(N_Empty) ) ;} break;
case 176:
# line 384 "expanded.g"
{yyval = tree4(N_Ret,yypvt[-1],yypvt[-1],yypvt[-0]) ;} break;
case 177:
# line 385 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-1],yypvt[-1],yypvt[-0],tree1(N_Empty) ) ;} break;
case 178:
# line 386 "expanded.g"
{yyval = tree5(N_Loop,yypvt[-3],yypvt[-3],yypvt[-2],yypvt[-0]) ;} break;
case 179:
# line 388 "expanded.g"
{yyval = tree5(N_If,yypvt[-3],yypvt[-2],yypvt[-0],tree1(N_Empty) ) ;} break;
case 180:
# line 389 "expanded.g"
{yyval = tree5(N_If,yypvt[-5],yypvt[-4],yypvt[-2],yypvt[-0]) ;} break;
case 181:
# line 391 "expanded.g"
{yyval = tree4(N_Case,yypvt[-5],yypvt[-4],yypvt[-1]) ;} break;
case 183:
# line 394 "expanded.g"
{yyval = tree4(N_Clist,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 184:
# line 396 "expanded.g"
{yyval = tree4(N_Ccls,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 185:
# line 397 "expanded.g"
{yyval = tree4(N_Ccls,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 187:
# line 400 "expanded.g"
{yyval = tree4(N_Elist,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
case 188:
# line 402 "expanded.g"
{
		yyval = tree3(N_Create,yypvt[-0],yypvt[-0]) ;
		} break;
case 189:
# line 405 "expanded.g"
{
		yyval = tree4(N_Elist,yypvt[-1],yypvt[-2],tree3(N_Create,yypvt[-1],yypvt[-0])) ;
		} break;
case 190:
# line 409 "expanded.g"
{Val0(yypvt[-0]) = putlit(Str0(yypvt[-0]),F_IntLit,0) ;} break;
case 191:
# line 410 "expanded.g"
{Val0(yypvt[-0]) = putlit(Str0(yypvt[-0]),F_RealLit,0) ;} break;
case 192:
# line 411 "expanded.g"
{Val0(yypvt[-0]) = putlit(Str0(yypvt[-0]),F_StrLit,(int)Val1(yypvt[-0])) ;} break;
case 193:
# line 412 "expanded.g"
{Val0(yypvt[-0]) = putlit(Str0(yypvt[-0]),F_CsetLit,(int)Val1(yypvt[-0])) ;} break;
case 194:
# line 414 "expanded.g"
{yyval = tree6(N_Sect,yypvt[-2],yypvt[-2],yypvt[-5],yypvt[-3],yypvt[-1]) ;} break;
case 195:
# line 416 "expanded.g"
{yyval = yypvt[-0] ;} break;
case 196:
# line 417 "expanded.g"
{yyval = yypvt[-0] ;} break;
case 197:
# line 418 "expanded.g"
{yyval = yypvt[-0] ;} break;
case 199:
# line 421 "expanded.g"
{yyval = tree4(N_Slist,yypvt[-1],yypvt[-2],yypvt[-0]) ;} break;
	}
	goto yystack;		/* reset registers in driver code */
}
