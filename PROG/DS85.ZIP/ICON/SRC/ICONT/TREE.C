/*
 * tree.c -- functions for constructing parse trees
 */

#include "../h/gsupport.h"
#include "tproto.h"
#include "tree.h"

/*
 *  tree[1-6] construct parse tree nodes with specified values.  tfree
 *   points at the next free word in the parse tree space.  Nodes are
 *   built by copying argument values into successive locations starting
 *   at tfree.  Parameters a and b are line and column information,
 *   while parameters c through f are values to be assigned to n_field[0-3].
 *   Note that this could be done with a single routine; a separate routine
 *   for each node size is used for speed and simplicity.
 */

nodeptr tree1(type)
int type;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 1);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   return t;
   }

nodeptr tree2(type, loc_model)
int type;
nodeptr loc_model;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 4);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   t->n_file = loc_model->n_file;
   t->n_line = loc_model->n_line;
   t->n_col = loc_model->n_col;
   return t;
   }

nodeptr tree3(type, loc_model, c)
int type;
nodeptr loc_model;
nodeptr c;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 5);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   t->n_file = loc_model->n_file;
   t->n_line = loc_model->n_line;
   t->n_col = loc_model->n_col;
   t->n_field[0].n_ptr = c;
   return t;
   }

nodeptr tree4(type, loc_model, c, d)
int type;
nodeptr loc_model;
nodeptr c, d;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 6);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   t->n_file = loc_model->n_file;
   t->n_line = loc_model->n_line;
   t->n_col = loc_model->n_col;
   t->n_field[0].n_ptr = c;
   t->n_field[1].n_ptr = d;
   return t;
   }

nodeptr tree5(type, loc_model, c, d, e)
int type;
nodeptr loc_model;
nodeptr c, d, e;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 7);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   t->n_file = loc_model->n_file;
   t->n_line = loc_model->n_line;
   t->n_col = loc_model->n_col;
   t->n_field[0].n_ptr = c;
   t->n_field[1].n_ptr = d;
   t->n_field[2].n_ptr = e;
   return t;
   }

nodeptr tree6(type, loc_model, c, d, e, f)
int type;
nodeptr loc_model;
nodeptr c, d, e, f;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 8);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   t->n_file = loc_model->n_file;
   t->n_line = loc_model->n_line;
   t->n_col = loc_model->n_col;
   t->n_field[0].n_ptr = c;
   t->n_field[1].n_ptr = d;
   t->n_field[2].n_ptr = e;
   t->n_field[3].n_ptr = f;
   return t;
   }

nodeptr int_leaf(type, loc_model, c)
int type;
nodeptr loc_model;
int c;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 5);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   t->n_file = loc_model->n_file;
   t->n_line = loc_model->n_line;
   t->n_col = loc_model->n_col;
   t->n_field[0].n_val = c;
   return t;
   }

nodeptr c_str_leaf(type, loc_model, c)
int type;
nodeptr loc_model;
char *c;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 5);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   t->n_file = loc_model->n_file;
   t->n_line = loc_model->n_line;
   t->n_col = loc_model->n_col;
   t->n_field[0].n_str = c;
   return t;
   }

nodeptr i_str_leaf(type, loc_model, c, d)
int type;
nodeptr loc_model;
char *c;
int d;
   {
   register nodeptr t;

   t = tfree;
   tfree = (nodeptr) ((word *)tfree + 6);
   if (tfree > tend)
      tsyserr("out of tree space");
   t->n_type = type;
   t->n_file = loc_model->n_file;
   t->n_line = loc_model->n_line;
   t->n_col = loc_model->n_col;
   t->n_field[0].n_str = c;
   t->n_field[1].n_val = d;
   return t;
   }

/*
 * Clear the tree space by setting the free pointer back to the first word
 *  of the tree space.
 */

novalue treeinit()
   {
   tfree = tree;
   }
