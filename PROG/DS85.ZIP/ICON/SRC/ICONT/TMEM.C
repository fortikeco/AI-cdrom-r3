/*
 * tmem.c -- memory initialization and allocation for the translator.
 */

#include "../h/gsupport.h"
#include "tproto.h"
#include "globals.h"
#include "trans.h"
#include "tsym.h"
#include "tree.h"

struct tlentry **lhash;		/* hash area for local table */
struct tgentry **ghash;		/* hash area for global table */
struct tcentry **chash;		/* hash area for constant table */
struct tientry **ihash;		/* hash area for identifier table */

nodeptr tree;			/* parse tree space */
nodeptr tend;			/* end of parse tree space */
struct tlentry *ltable;		/* local table */
struct tgentry *gtable;		/* global table */
struct tcentry *ctable;		/* constant table */
struct tientry *itable;		/* identifier table */

char *strings;			/* string space */
char *stre;			/* end of string space */

nodeptr tfree;			/* free pointer for parse tree space */
struct tlentry *lfree;		/* free pointer for local table */
struct tgentry *gfree;		/* free pointer for global table */
struct tcentry *ctfree;		/* free pointer to constant table */
struct tientry *ifree;		/* free pointer for identifier table */
char *strf;			/* free pointer for string space */


/*
 * tmalloc - allocate memory for the translator
 */

novalue tmalloc()
{
   chash = (struct tcentry **) tcalloc(chsize, sizeof (struct tcentry *));
   ghash = (struct tgentry **) tcalloc(ghsize, sizeof (struct tgentry *));
   ihash = (struct tientry **) tcalloc(ihsize, sizeof (struct tientry *));
   lhash = (struct tlentry **) tcalloc(lhsize, sizeof (struct tlentry *));

   ctable = (struct tcentry *) tcalloc(csize, sizeof (struct tcentry));
   gtable = (struct tgentry *) tcalloc(gsize, sizeof (struct tgentry));
   itable = (struct tientry *) tcalloc(isize, sizeof (struct tientry));
   ltable = (struct tlentry *) tcalloc(lsize, sizeof (struct tlentry));

   strings = (char *) tcalloc(stsize, sizeof(char));
   stre = strings + stsize;

   tree = (nodeptr) tcalloc(tsize, sizeof(word));
   tend = (nodeptr) ((word *)tree + tsize);
   }

/*
 * meminit - clear tables for use in translating the next file
 */
novalue tminit()
   {
   register struct tlentry **lp;
   register struct tgentry **gp;
   register struct tcentry **cp;
   register struct tientry **ip;

   /*
    * Reset the free pointer for each region.
    */
   lfree = ltable;
   gfree = gtable;
   ctfree = ctable;
   ifree = itable;
   strf = strings;
   tfree = tree;
   /*
    * Zero out the hash tables.
    */
   for (lp = lhash; lp < &lhash[lhsize]; lp++)
      *lp = NULL;
   for (gp = ghash; gp < &ghash[ghsize]; gp++)
      *gp = NULL;
   for (cp = chash; cp < &chash[chsize]; cp++)
      *cp = NULL;
   for (ip = ihash; ip < &ihash[ihsize]; ip++)
      *ip = NULL;
   }

/*
 * tmfree - free memory used by the translator
 */
novalue tmfree()
   {
   free((char *) chash);   chash = NULL;
   free((char *) ghash);   ghash = NULL;
   free((char *) ihash);   ihash = NULL;
   free((char *) lhash);   lhash = NULL;
   free((char *) ctable);  ctable = NULL;
   free((char *) gtable);  gtable = NULL;
   free((char *) itable);  itable = NULL;
   free((char *) ltable);  ltable = NULL;
   free((char *) strings); strings = NULL;
   free((char *) tree);    tree = NULL;
   }
