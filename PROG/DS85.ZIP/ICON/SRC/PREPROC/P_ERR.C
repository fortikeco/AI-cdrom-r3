#include "../preproc/preproc.h"
#include "../preproc/pproto.h"
extern char *progname;

/*
 * errt1 - error message in one string, location indicated by a token.
 */
novalue errt1(t, s)
struct token *t;
char *s;
   {
   errfl1(t->fname, t->line, s);
   }

/*
 * errfl1 - error message in one string, location given by file and line.
 */
novalue errfl1(f, l, s)
char *f;
int l;
char *s;
   {
   fflush(stdout);
   fprintf(stderr, "%s: File %s; Line %d: %s\n", progname, f, l, s);
   exit(ErrorExit);
   }

/*
 * err1 - error message in one string, no location given
 */
novalue err1(s)
char *s;
   {
   fflush(stdout);
   fprintf(stderr, "%s: %s\n", progname, s);
   exit(ErrorExit);
   }

/*
 * errt2 - error message in two strings, location indicated by a token.
 */
novalue errt2(t, s1, s2)
struct token *t;
char *s1;
char *s2;
   {
   errfl2(t->fname, t->line, s1, s2);
   }

/*
 * errfl2 - error message in two strings, location given by file and line.
 */
novalue errfl2(f, l, s1, s2)
char *f;
int l;
char *s1;
char *s2;
   {
   fflush(stdout);
   fprintf(stderr, "%s: File %s; Line %d: %s%s\n", progname, f, l, s1, s2);
   exit(ErrorExit);
   }

/*
 * err2 - error message in two strings, no location given
 */
novalue err2(s1, s2)
char *s1;
char *s2;
   {
   fflush(stdout);
   fprintf(stderr, "%s: %s%s\n", progname, s1, s2);
   exit(ErrorExit);
   }
