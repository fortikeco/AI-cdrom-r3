/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  ProcOption.c                                               */
/*                                                                           */
/*   Called By :  ReadOptions.c                                              */
/*                                                                           */
/*   Calls     :  AddToList.c, MatchWildcar.c                                */
/*                                                                           */
/*   Date      :  29-Aug-92                                                  */
/*                                                                           */
/*****************************************************************************/

#include <dirent.h>

void  ProcOption (sw, parm)
char   sw;
char  *parm;
  {
  char          *cptr;
  DIR           *dirp;
  struct dirent *dp;
  int            slen;

  if (Debug)
    {
    printf ("Processing option: %c\n", sw);
    if (parm)
      printf ("  Parm: %s\n", parm);
    }

  switch (sw)
    {
    case 'a':
    case 'A':
      if (parm)
        {
        if (strchr(parm, WILDCHR) == NULL)
          AddToList (AddLst, parm);
        else
          {
          slen = strlen  (Sufx);
          dirp = opendir (".");
          if (dirp == NULL)
            perror ("Error opening directory");
          else
            {
            printf ("The following files matched the wildcard %s...\n\n", parm);
            for (dp = readdir(dirp); dp != NULL; dp = readdir(dirp))
              {
              if (MatchWildcard (dp->d_name, parm))
                {
                printf ("  %s\n", dp->d_name);
                AddToList (AddLst, dp->d_name);
                }
              }
            closedir (dirp);
            printf ("\n");
            }
          }
        }
      else
        printf ("Option -%c requires a parameter\n", sw);
      LibBuild = TRUE;
      break;
    case 'd':
    case 'D':
      if (parm)
        AddToList (DelLst, parm);
      else
        printf ("Option -%c requires a parameter\n", sw);
      LibBuild = TRUE;
      break;
    case 'x':
    case 'X':
      if (parm)
        AddToList (ExtLst, parm);
      else
        printf ("Option -%c requires a parameter\n", sw);
      break;
    case 'b':
    case 'B':
      if (parm)
        strcpy (BatNam, parm);
      else
        printf ("Option -%c requires a parameter\n", sw);
      break;
    case 'l':
    case 'L':
      ListObjs = TRUE;
      break;
    case 't':
    case 'T':
      Debug = TRUE;
      break;
    default:
      break;
    }
  }
