/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  LibHash.c                                                  */
/*                                                                           */
/*   Called By :  DictInsert.c                                               */
/*                                                                           */
/*   Calls     :  None.                                                      */
/*                                                                           */
/*   Date      :  29-Aug-92                                                  */
/*                                                                           */
/*****************************************************************************/
void LibHash(sym, dict_size, bucket_ixp, bucket_dtp, 
                             page_ixp,   page_dtp)
unsigned char  *sym;
unsigned short  dict_size;
unsigned short *bucket_ixp;
unsigned short *bucket_dtp;
unsigned short *page_ixp;
unsigned short *page_dtp;
  {
  unsigned short bucket_ix;
  unsigned short bucket_dt;
  unsigned short page_ix;
  unsigned short page_dt;
  unsigned char  *p, *q, c;
  int            count;

  bucket_ix = bucket_dt = page_ix = page_dt = 0;

  for (count = sym[0], q = &sym[count], p = sym; count; count--)
    {
    /* Convert to lowercase */
    c = *(p++) | 0x20;

    bucket_dt  = ((bucket_dt >> 2)  | (bucket_dt << 14) ) ^ c;
    page_ix    = ((page_ix   << 2)  | (page_ix   >> 14) ) ^ c;

    /* Convert to lowercase */
    c = *(q--) | 0x20;

    bucket_ix  = ((bucket_ix >> 2)  | (bucket_ix << 14) ) ^ c;
    page_dt    = ((page_dt   << 2)  | (page_dt   >> 14) ) ^ c;
    }

  bucket_ix %= (unsigned short) HASH_SIZE;
  bucket_dt %= (unsigned short) HASH_SIZE;
  page_ix   %= dict_size;
  page_dt   %= dict_size;
  
  if (bucket_dt == 0)
    bucket_dt = 1;

  if (page_dt  == 0)
    page_dt   = 1;

  *bucket_ixp = bucket_ix;
  *bucket_dtp = bucket_dt;
  *page_ixp   = page_ix;
  *page_dtp   = page_dt;
  }
