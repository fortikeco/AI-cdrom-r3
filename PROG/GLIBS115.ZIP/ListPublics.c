/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992, 1993 Jonathan Sykes (jsykes@aol.com)                  */
/* Copyright (C)       1993 Mark Alexander                                   */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  ListPublics.c                                              */
/*                                                                           */
/*   Called By :  Lib.c                                                      */
/*                                                                           */
/*   Calls     :  DoPub2Def.c, DoTheadr.c, EatRec.c, GetByte.c               */
/*                                                                           */
/*   Date      :  20-Mar-93                                                  */
/*                                                                           */
/*****************************************************************************/
void  ListPublics (fp, block)
FILE  *fp;
Word   block;
  {
  char    ObjName[NAMELEN];
  Byte    b;
  unsigned
    long  offset;

  offset = (block * 16);

  ChkSumFlg = TRUE;
  ChkSum    = 0;

  fseek (fp, offset, SEEK_SET);

  if (GetByte (fp) != THEADR)
    {
    printf ("Invalid object module header\n");
    exit (ERROR);
    }

  CurRec = THEADR;  
  DoTheadr (fp);

  printf ("Module Name %s\n", CurObj);

  b = GetByte (fp);
  while ((b != MODEND2) && (b != MODEND) && (b != 0))
    {
    CurRec = b;
    if ((b == PUBDEF2) || (b == PUBDEF))
      DoPub2Def (fp, b);
    else
      EatRec (fp);

    b = GetByte (fp);
    }
  }
