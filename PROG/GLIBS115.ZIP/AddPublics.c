/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992, 1993 Jonathan Sykes (jsykes@aol.com)                  */
/* Copyright (C)       1993 Mark Alexander                                   */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  AddPublics.c                                               */
/*                                                                           */
/*   Called By :  Lib.c                                                      */
/*                                                                           */
/*   Calls     :  AddSymbol.c, DoChkSum.c, DoTheadr.c, DumpN.c, EatRec.c,    */
/*                GetByte.c, GetIndex.c, GetRecLen.c, GetUString.c,          */
/*                GetWord.c                                                  */
/*                                                                           */
/*   Date      :  20-Mar-93                                                  */
/*                                                                           */
/*****************************************************************************/
LibSym  *AddPublics (fp, objoffset, liboffset, sym)
FILE    *fp;
unsigned long objoffset, liboffset;
LibSym  *sym;
  {
  Byte    b;
  char   *NamPtr;
  LibSym *psym, *nsym, *csym;
  Word    RecLen, GroupIndex, SegIndex, OffsetLen, TypeIndex;

  psym      = sym;
  ChkSumFlg = TRUE;
  ChkSum    = 0;

  fseek (fp, objoffset, SEEK_SET);

  if ((b = GetByte (fp)) != THEADR)
    {
    printf ("Invalid object module header: %s\n", CurObj);
    exit (ERROR);
    }
  
  /* Module name symbols replace the .obj suffix with a ! */

  if (Debug)
    printf ("Adding symbol %s\n", CurObj);

  /* Add the module name symbol to the list */
  psym = AddSymbol (psym, CurObj, liboffset);

  while ((b != MODEND) && (b != MODEND2) && (b != 0))
    {
    /* CurRec global stores record type being parsed */
    CurRec = b;
    if ((b == PUBDEF2) || (b == PUBDEF))
      {
      OffsetLen = b == PUBDEF2 ? 4 : 2;
      RecLen = GetRecLen(fp);
      RecLen --;
      RecLen -= GetIndex(fp, &GroupIndex);
      RecLen -= GetIndex(fp, &SegIndex);
      /* If the segment index is zero a base frame index word is next */
      if (SegIndex == 0)
        {
        GetWord(fp, SWAP);
        RecLen -= 2;
        }

      while (RecLen > 0)
        {
        b = GetByte (fp);
        RecLen -= (b + 1);

        GetUString (fp, b);

 /* Discard the Public Offset field (4 or 2 bytes) */
        DumpN (fp, OffsetLen);
 RecLen -= OffsetLen;

 /* Discard the Type Index field */
 RecLen -= GetIndex(fp, &TypeIndex);

        /* Add the public name symbol to the list */
        psym = AddSymbol (psym, Buff, liboffset);
        }
      DoChkSum(fp);

      }
    else
      EatRec (fp);

    b = GetByte (fp);
    }

  return (psym);
  }
