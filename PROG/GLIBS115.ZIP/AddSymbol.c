/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  AddSymbol.c                                                */
/*                                                                           */
/*   Called By :  AddPublics.c                                               */
/*                                                                           */
/*   Calls     :  None.                                                      */
/*                                                                           */
/*   Date      :  29-Aug-92                                                  */
/*                                                                           */
/*****************************************************************************/
LibSym  *AddSymbol (sym, str, offset)
LibSym  *sym;
char    *str;
unsigned long offset;
  {
  Word     block;
  LibSym  *newsym;
  unsigned 
    char  *CPtr;

  block = (Word)(offset / 0x10);

  if (newsym = (LibSym *)malloc (sizeof (LibSym)))
    {
    if (CPtr = (unsigned char *)malloc (strlen (str) + 1))
      strcpy (CPtr, str);
    else
      {
      printf ("Failed malloc for Name in AddSymbol - %s\n", str);
      exit (-1);
      }
    }
  else
    {
    printf ("Failed malloc for LibSym in AddSymbol - %s\n", str);
    exit (-1);
    }

  newsym->Name        = CPtr;
  newsym->ModuleBlock = block;
  newsym->Updated     = FALSE;
  newsym->Next        = NULL;

  if (SymListHead == NULL)
    {
    SymListHead = newsym;
    sym         = SymListHead;
    }
  else
    {
    sym->Next  = newsym;
    sym        = sym->Next;
    }

  return (newsym);
  }
