/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  DictInsert.c                                               */
/*                                                                           */
/*   Called By :  CreateDict.c                                               */
/*                                                                           */
/*   Calls     :  LibHash.c                                                  */
/*                                                                           */
/*   Date      :  29-Aug-92                                                  */
/*                                                                           */
/*****************************************************************************/
Bool DictInsert(dict, dict_size, symbol)
DictPage *dict;
short     dict_size;
LibSym   *symbol;
  {
  unsigned short bucket;
  unsigned short bucket_del;
  unsigned short page;
  unsigned short page_del;

  unsigned short curr_page;
  unsigned short curr_bucket;

  unsigned char  buff[SYMBLEN];
  int            words_needed;
  int            loc;


  buff[0] = (char)strlen(symbol->Name);

  strcpy(&buff[1], symbol->Name);

  buff[buff[0] + 1] = (symbol->ModuleBlock & LOBYTE);
  buff[buff[0] + 2] = (symbol->ModuleBlock & HIBYTE) >> 8;
  buff[buff[0] + 3] = 0;

  words_needed = (buff[0] + 4) >> 1;

  LibHash(buff, dict_size, &bucket, &bucket_del, &page, &page_del);

  curr_page   = page;
  curr_bucket = bucket;

  do
    {
    do
      {
      /* This bucket is empty so use it for this symbol      */
      if (dict[curr_page].Bucket[curr_bucket] == 0)
        {
        if (words_needed >= (0x100 - dict[curr_page].NFree))
          /* This dictionary page is full so move to the next page */
          /* A full page is marked by 0xff in bucket 38            */
          {
          dict[curr_page].NFree = 0xFF;
          break;
          }

        loc = (dict[curr_page].NFree << 1) - (HASH_SIZE + 1);

        dict[curr_page].Bucket[curr_bucket] = dict[curr_page].NFree;
        dict[curr_page].NFree += words_needed;

        memcpy(&dict[curr_page].Names[loc], buff, words_needed << 1);

        /* symbol has been added to the page successfully    */
        return (TRUE);
        }
      /* This bucket is in use so calculate the next one     */
      else
        {
        curr_bucket += bucket_del;
        curr_bucket %= (unsigned short) HASH_SIZE;
        }
      } 
    while (bucket != curr_bucket);

    curr_page += page_del;
    curr_page %= dict_size;
    } 
  while (page != curr_page);

  /* Return FALSE if failed to insert this symbol because there */
  /* were not enough dictionary pages allocated                */
  return (FALSE);
  }
