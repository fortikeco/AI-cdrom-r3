/****************
* Include files *
*****************/
#include <stdio.h>
#include <string.h>

#include "BuildDate.h"

/********************************
* Microsoft Object Record Types *
********************************/
#define BLKDEF  0x7A
#define BLKEND  0x7C
#define COMDEF  0xB0           /* communal-names definition */
#define COMENT  0x88
#define EXTDEF  0x8C
#define FIXUPP  0x9C
#define GRPDEF  0x9A
#define LEDATA  0xA0
#define LIBHDR  0xf0
#define LIBTRL  0xf1
#define LIDATA  0xA2
#define LINNUM  0x94
#define LNAMES  0x96
#define LOCSYM  0x92
#define MODEND  0x8A
#define MODEND2 0x8B
#define PUBDEF  0x90
#define PUBDEF2 0x91           /* 32-Bit Public Definition */
#define SEGDEF  0x98
#define THEADR  0x80
#define TYPDEF  0x8E

/************************
* Miscellaneous defines *
************************/
#define BIT0    0x01
#define BIT1    0x02
#define BIT2    0x04
#define BIT3    0x08
#define BIT4    0x10
#define BIT5    0x20
#define BIT6    0x40
#define BIT7    0x80
#define BLANK   ' '
#define ERROR   -1
#define FALSE   0
#define LISTLEN 1024    /* This is an important definition - this is the max */
                        /* number of modules you can add, delete or extract  */
                        /* Increase this number if you exceed 1024 or run    */
                        /* glib more than once.                              */
#define NAMELEN 1024
#define SYMBLEN 64
#define NOSWAP  00
#define OK      0
#define SWAP    01
#define TRUE    1
#define ZERO    0x00
#define LOBYTE  0x00ff
#define HIBYTE  0xff00
#define HIWORD  0xffff0000L
#define LOWORD  0x0000ffffL
#define PAGESIZE 0x10
#define WILDSTR "*"
#define WILDCHR '*'

#ifdef SUN
#define SEEK_SET 0
#endif

#define HASH_SIZE      37
#define DICT_BOUNDARY  0x200
#define SYM_BYTES_PAGE 474

#define TMP_FNAME "tmpfile.tmp"
#define TMP_LNAME "tmplib.tmp"

#ifndef max
#define max(a,b) (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif


/***********
* Typedefs *
************/
typedef unsigned char    Byte;            /* 8 Bits                            */
typedef unsigned char   *PByte;	          /* pointer to a byte                 */
typedef unsigned short   Word;            /* 16 Bits                           */
typedef unsigned short  *PWord;	          /* pointer to a word                 */
typedef int              Bool;

typedef struct LibSym
  {
  unsigned char *Name;                    /* Symbol name Eg. _open or open!    */
  Word           ModuleBlock;             /* Object block = offset / 0x10      */
  Bool           Updated;                 /* Offset now correct for new lib    */
  struct LibSym *Next;                    /* Next symbol in linked list        */
  } LibSym;

typedef struct DictPage
  {
  Byte           Bucket [HASH_SIZE];      /* Hash table area                   */
  Byte           NFree;                   /* First free space in Names area    */
  Byte           Names  [SYM_BYTES_PAGE]; /* Symbols name space for hash table */
  } DictPage;

typedef struct LibHeadRec
  {
  Byte           RecType;                 /* Should always be LHEADR           */
  Word           RecLen;                  /* Length of this record             */
  unsigned long  DirOffset;               /* Offset where Dict Pages start     */    
  Word           DirPages;                /* Number of Dict Pages              */
  } LibHeadRec;

Bool          ChkSumFlg;                  /* Enable checksum checks on objects */
Bool          Debug      = FALSE;         /* Enable to print debug messages    */
Bool          LibBuild   = FALSE;         /* Enabled to create / rebuild a lib */
Bool          ListObjs;                   /* Enabled with -l for public list   */
Bool          ObjWrite   = FALSE;         /* GetByte writes to ObjF when TRUE  */

Byte          CurRec;                     /* Curr Rec type being parsed        */

FILE         *BatF;                       /* Batch file for commands           */
FILE         *LIBFNew;                    /* New lib - renamed to argv[1]      */
FILE         *LibF;                       /* Orig lib for reading              */
FILE         *ObjF;                       /* Object being read or new lib obj  */

LibHeadRec    LHRec = {LIBHDR, 0x000d, 0x0000, 0x0000};
LibSym       *SymListHead = NULL;

Word          ChkSum;
char          BatNam[NAMELEN];    /* Batch file name                           */
char          Buff[NAMELEN];      /* Temporary workspace                       */
char          Sufx[NAMELEN];      /* The .obj extension for object file names  */
char          CurObj[NAMELEN];    /* The current object name being parsed      */

char         *AddLst[LISTLEN];    /* List of OBJs to add (overwrite)           */
char         *DelLst[LISTLEN];    /* List of OBJs to delete                    */
char         *ExtLst[LISTLEN];    /* List of OBJs to extract (but not delete)  */

short         NumSymbols = 0;     /* Num of entries in symbol list             */
short         SizSymbols = 0;     /* Tot Size of symbol list names             */
DictPage    **DictListHead;       /* Array of Dict Pages                       */

Word    GetWord ();
Byte    GetByte ();
Word    GetRecLen ();
void    EatRec ();
void    DumpN ();
void    DoChkSum ();
Byte    GetSString ();
void    GetUString ();
Bool    SearchList ();
void    AddToList ();
void    InitLists ();
void    PrintList ();
void    ProcOption ();
void    ReadOptions ();
void    ReadLibHeader ();
void    WriteLibHeader ();
void    WriteLibTrailer ();
void    ReadDictPages ();
void    ExtractObj();
void    ListPublics ();
void    DoPub2Def ();
Byte    GetIndex ();
LibSym *DeleteObj ();
unsigned 
  long  RewriteObj ();
LibSym *AddPublics();
LibSym *AddSymbol ();
unsigned 
  long  Pad ();
void    UpdatePublics ();
Word    CreateDict ();
Bool    DictInsert ();
void    LibHash ();
void    WriteDict ();
Bool    MatchWildcard ();
Bool    IsPrime ();

#include "GetWord.c"
#include "GetByte.c"
#include "GetRecLen.c"
#include "EatRec.c"
#include "DumpN.c"
#include "DoChkSum.c"
#include "DoTheadr.c"
#include "GetSString.c"
#include "GetUString.c"
#include "SearchList.c"
#include "AddToList.c"
#include "InitLists.c"
#include "PrintList.c"
#include "ProcOption.c"
#include "ReadOptions.c"
#include "ReadLibHeader.c"
#include "WriteLibHeader.c"
#include "WriteLibTrailer.c"
#include "ReadDictPages.c"
#include "ExtractObj.c"
#include "ListPublics.c"
#include "DoPub2Def.c"
#include "GetIndex.c"
#include "DeleteObj.c"
#include "RewriteObj.c"
#include "AddPublics.c"
#include "AddSymbol.c"
#include "Pad.c"
#include "UpdatePublics.c"
#include "CreateDict.c"
#include "DictInsert.c"
#include "LibHash.c"
#include "WriteDict.c"
#include "MatchWildcard.c"
#include "IsPrime.c"