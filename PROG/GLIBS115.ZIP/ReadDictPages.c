/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  ReadDictPages.c                                            */
/*                                                                           */
/*   Called By :  Lib.c                                                      */
/*                                                                           */
/*   Calls     :  GetByte.c                                                  */
/*                                                                           */
/*   Date      :  29-Aug-92                                                  */
/*                                                                           */
/*****************************************************************************/
void ReadDictPages (fp)
FILE  *fp;
  {
  Word     PageCnt, i, j, Block;
  DictPage Page;
  Byte    *BPtr, SymLen, b;
  LibSym  *NewSym, *CurrSym;
  unsigned 
    long   PubEntry;
  unsigned 
    char  *CPtr;

  SymListHead = NULL;
  CurrSym     = NULL;

  for (PageCnt = 0; PageCnt < LHRec.DirPages; PageCnt++)
    {
    fseek (fp, (PageCnt * 512) + LHRec.DirOffset, SEEK_SET);

    BPtr = (Byte *)&Page;
    for (i = 0; i < 512; i++)
      BPtr[i] = GetByte (fp);

    for (i = 0; i < (HASH_SIZE + 1); i++)
      if (Page.Bucket[i] > 0)
        {
        PubEntry = (2 * Page.Bucket[i]);
        if ((SymLen = Page.Names[PubEntry - HASH_SIZE - 1]) > 0)
          {
	  CPtr   = (unsigned char *)malloc (SymLen + 1);
    
          if (Debug)
	    printf ("Symbol = ");
	  for (j = 0; j < SymLen; j++)
	    {
	    b = Page.Names[PubEntry - HASH_SIZE + j];
	    CPtr[j] = (unsigned char)b;
	    if (Debug)
              printf ("%c", b);
	    }
    
	  CPtr[j] = '\0';
    
	  Block  = (Page.Names[PubEntry - HASH_SIZE + SymLen]);
	  Block += (Page.Names[PubEntry - HASH_SIZE + SymLen + 1] << 8);
    
          if (Debug)
	    printf ("  Block = %x\n", Block);
	 
	  NewSym              = (LibSym *)malloc (sizeof (LibSym));
	  NewSym->Name        = CPtr;
	  NewSym->ModuleBlock = Block;
          NewSym->Updated     = FALSE;
	  NewSym->Next        = NULL;
    
	  if (SymListHead == NULL)
	    SymListHead = NewSym;
    
	  if (CurrSym)
	    CurrSym->Next = NewSym;
    
	  CurrSym       = NewSym;
          }
        }
    }
  }
