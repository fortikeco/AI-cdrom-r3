/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992, 1993 Jonathan Sykes (jsykes@aol.com)                  */
/* Copyright (C)       1993 Mark Alexander                                   */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  DoPub2Def.c                                                */
/*                                                                           */
/*   Called By :  ListPublics.c                                              */
/*                                                                           */
/*   Calls     :  DoChkSum.c, DumpN.c, GetByte.c, GetIndex.c, GetRecLen.c,   */
/*                GetUString.c, GetWord.c                                    */
/*                                                                           */
/*   Date      :  20-Mar-93                                                  */
/*                                                                           */
/*****************************************************************************/
void  DoPub2Def (fp, RecType)
FILE  *fp;
Word RecType;
  {
  Word RecLen, GroupIndex, SegIndex, TypeIndex, OffsetLen;
  Byte b;

  OffsetLen = RecType == PUBDEF2 ? 4 : 2;
  RecLen = GetRecLen(fp);
  RecLen--;
  RecLen -= GetIndex(fp, &GroupIndex);
  RecLen -= GetIndex(fp, &SegIndex);

  /* If the segment index is zero a base frame index word is next */
  if (SegIndex == 0)
    {
    GetWord(fp, SWAP);
    RecLen -= 2;
    }

  while (RecLen > 0)
    {
    b = GetByte (fp);
    RecLen -= (b + 1);

    GetUString (fp, b);

    /* Discard the Public Offset field (4 or 2 bytes) */
    DumpN (fp, OffsetLen);
    RecLen -= OffsetLen;

    /* Discard the Type Index field */
    RecLen -= GetIndex(fp, &TypeIndex);

    printf ("  %s  [Grp %02xh, Seg %02xh]\n", 
               Buff, GroupIndex, SegIndex);
    }
  DoChkSum(fp);
  
  
  }
