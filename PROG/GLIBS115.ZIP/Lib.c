/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  Lib.c                                                      */
/*                                                                           */
/*   Called By :  -                                                          */
/*                                                                           */
/*   Calls     :  AddPublics.c, CreateDict.c, DeleteObj.c, ExtractObj.c,     */
/*                InitLists.c, ListPublics.c, Pad.c, ReadDictPages.c,        */
/*                ReadOptions.c, RewriteObj.c, SearchList.c,                 */
/*                UpdatePublics.c, WriteDict.c                               */
/*                                                                           */
/*   Date      :  29-Aug-92                                                  */
/*                                                                           */
/*****************************************************************************/
#include "Lib.h"

int main (argc, argv)
int    argc;
char  *argv[];
  {
  LibSym  *PrevSym, *CurrSym, *csym;
  Bool     ObjFName;
  unsigned
    long   Offset;
  int      i;
  char    *CPtr;
  FILE    *AddF;

  /* Don't buffer stdout so printf's display immediately */
  setbuf (stdout, NULL);

        /* A ruler...
         * 12345678901234567890123456789012345678901234567890123456789012345678901234567890
         */

  printf ("Library Manager %s, Copyright (C) 1992, 1993 Jonathan Sykes\n", VERSION);
  printf ("                       Copyright (C) 1992, 1993 Mark Alexander\n\n");
  printf ("Library Manager comes with ABSOLUTELY NO WARRANTY; This is free software,\n");
  printf ("and you are welcome to redistribute it under certain conditions; for\n");
  printf ("details refer to the GNU General Public License included with this program.\n");
  printf ("\n");

  if ((argc < 2) || (argv[1][0] == '-'))
    {
    printf("Usage: %s library command ...\n", argv[0]);
    printf("\n");
    printf("Command Syntax:\n\n");
    printf("  -a file.obj               Add (overwrite) file.obj\n");
    printf("  -d file.obj               Delete file.obj\n");
    printf("  -x file.obj               Extract file.obj\n");
    printf("  -b file                   Read commands from file\n");
    printf("  -l                        List modules and public symbols\n");
    printf("\n");
    exit (-1);
    }

  LibF = fopen(argv[1], "rb");

  InitLists ();
  ReadOptions (argc, argv);

  if (LibF)
    {
    printf ("Opened %s\n", argv[1]);
    /* The LibHeader include the dictionary offset and size        */
    ReadLibHeader (LibF);
    /* Create a linked list of symbols contained in the dictionary */
    /* The head of this list is a global called SymListHead        */
    ReadDictPages (LibF);
    }
  else
    {
    /* If the library didn't exist it's safe to assume it needs to */
    /* be built                                                    */
    LibBuild = TRUE;
    printf ("Creating %s\n", argv[1]);

    /* ListObjs is TRUE in ReadOptions if the -l switch is given   */
    if (ListObjs)
      printf ("Warning: The -l option will be ignored\n");
    }

  /* This while loop runs through the list of symbols, if any. For */
  /* each symbol that refers to an object module (ends with !) it  */
  /* extracts, deletes or lists publics if that name is within the */
  /* the appropriate name list (created during ReadOptions).       */

  PrevSym = SymListHead;
  CurrSym = SymListHead;
  while (CurrSym)
    {
    if (strchr (CurrSym->Name, '!'))
      {
      ObjFName = TRUE;    /* This is the name of an object module  */
      strcpy (CurObj, CurrSym->Name);
      if (CPtr = strchr (CurObj, '!'))
        CPtr[0] = '\0';
      strcat (CurObj, Sufx);
      }
    else
      {
      strcpy (CurObj, "");
      ObjFName = FALSE;   /* This is NOT an object module name     */
      }

    if ((ObjFName) && (SearchList(ExtLst, CurrSym->Name)))
      ExtractObj (LibF, CurrSym->ModuleBlock);

    if ((ObjFName) && (ListObjs))
      {
      printf ("Object Name: %s, ", CurObj);
      ListPublics (LibF, CurrSym->ModuleBlock);
      }

    if ((ObjFName) && 
       ((SearchList(DelLst, CurrSym->Name) || SearchList(AddLst, CurrSym->Name))))
      {
      CurrSym = DeleteObj (CurrSym);
      if (Debug)
        printf ("... Deleted\n");
      /* Delete symbols for modules and all publics.              */
      /* Adding an object implies overwriting any pre-existing    */
      /* object with the same name.                               */

      }
    else
      CurrSym = CurrSym->Next;
    }

  if (LibBuild)
    {
    if ((LIBFNew = fopen(TMP_LNAME, "wb")) == NULL)
      {
      printf("Can't open temporary library file %s\n", TMP_LNAME);
      exit(ERROR);
      }

    ObjF = LIBFNew;

    WriteLibHeader (LIBFNew);
    /* Even though the header information is not correct yet this is */
    /* a simple way to reserve enough space at the head of the lib.  */

    if (Debug)
      printf ("\n\n*** New Library Contents ***\n\n");

    /* Rewrite existing objects */

    PrevSym   = SymListHead;
    CurrSym   = SymListHead;
    while (CurrSym)
      {
      if (strchr (CurrSym->Name, '!'))
        {
        if (Debug)
          printf ("Rewriting %s\n", CurrSym->Name);

        Offset = RewriteObj (LibF, CurrSym->ModuleBlock);
        UpdatePublics (CurrSym->ModuleBlock, Offset);
        }

      PrevSym = CurrSym;
      CurrSym = CurrSym->Next;
      }

    /* Add any new objects */

    for (i = 0; ((i < LISTLEN) && (AddLst[i])); i++)
      {
      strcpy (Buff, AddLst[i]);

      if (CPtr = strchr (Buff, '!'))
        CPtr[0] = '\0';

      strcat (Buff, Sufx);

      if ((AddF = fopen (Buff, "rb")) == NULL)
        printf ("Cannot open file >%s<\n", Buff);
      else
        {
        Offset  = RewriteObj (AddF, (Word)0);
        strcpy (CurObj, AddLst[i]);
        PrevSym = AddPublics (AddF, 0L, Offset, PrevSym);
        fclose (AddF);
        }      
      }

    Pad(LIBFNew, PAGESIZE);
    WriteLibTrailer (LIBFNew);

    LHRec.DirOffset = ftell(LIBFNew);

    if (Debug)
      printf ("Dirr Offset = %x\n", LHRec.DirOffset);

    LHRec.DirPages = CreateDict (&DictListHead);

    if (Debug)
      printf ("Dictionary created with %d pages\n", LHRec.DirPages);

    WriteDict (LIBFNew, DictListHead, LHRec.DirPages);

    WriteLibHeader (LIBFNew);
    fclose (LIBFNew);
    }

  if (LibF)
    fclose (LibF);

  if (LibBuild)
    {
    unlink (argv[1]);
    /* Rename didn't like overwriting an existing file in OS/2 so I */
    /* unlink any existing file first.                              */
    if (rename (TMP_LNAME, argv[1]) != 0)
      perror ("Error: Renaming temporary file");
    }

  return (0);
  }
