/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  WriteLibTrailer.c                                          */
/*                                                                           */
/*   Called By :  Lib.c                                                      */
/*                                                                           */
/*   Calls     :  None.                                                      */
/*                                                                           */
/*   Date      :  29-Aug-92                                                  */
/*                                                                           */
/*****************************************************************************/
void  WriteLibTrailer (fp)
FILE       *fp;
  {
  Word    RecLen;
  unsigned
    long  Offset, Offsetend;
  
  Offset = ftell (fp);

  if (Debug)
    printf ("Offset at start = %04xh\n", Offset);

  for (Offsetend = Offset + 3; ((Offsetend % PAGESIZE) != 0); Offsetend++);

  if (Debug)
    printf ("Offsetend calculated = %04xh\n", Offsetend);

  RecLen = (Offsetend - Offset) - 3;

  if (Debug)
    printf ("RecLen calculated = %02xh\n", RecLen);

  putc ((Byte)LIBTRL, fp);
  putc ((Byte) (RecLen & LOBYTE), fp);
  putc ((Byte)((RecLen & HIBYTE) >> 8), fp);
  
  for (Offset = ftell(fp); Offset < Offsetend; Offset++)
    putc ((Byte)ZERO, fp);

  if (Debug)
    printf ("Offset at end of libtrailer = %04xh\n", ftell (fp));
  }
