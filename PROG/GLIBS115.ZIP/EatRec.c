/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  EatRec.c                                                   */
/*                                                                           */
/*   Called By :  AddPublics.c, ExtractObj.c, ListPublics.c, RewriteObj.c    */
/*                                                                           */
/*   Calls     :  DoChkSum.c, DumpN.c, GetByte.c, GetRecLen.c                */
/*                                                                           */
/*   Date      :  29-Aug-92                                                  */
/*                                                                           */
/*****************************************************************************/
void  EatRec (fp)
FILE  *fp;
  {
  Word RecLen;
  Word DumpLen;
  
  RecLen = GetRecLen(fp);

  if (Debug)
    printf("%02xh: Dumping Record (RecLen %04x)\n", CurRec, RecLen);

  DumpLen = (RecLen - 1);
  DumpN(fp, DumpLen);

  if (ChkSumFlg)
    DoChkSum(fp);
  else
    GetByte(fp);

  ChkSum    = 0;

  return;
  }
