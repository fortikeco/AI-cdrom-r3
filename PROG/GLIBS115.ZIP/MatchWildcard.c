/*****************************************************************************/
/*                                                                           */
/* This file is part of a program which creates and manages a Microsoft .LIB */
/* format file containing Microsoft standard object modules. This version is */
/* specifically for use with IBM OS/2 2.0.                                   */
/*                                                                           */
/* Copyright (C) 1992 Jonathan Sykes (jsykes@aol.com)                        */
/*                                                                           */
/* This program is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the     */
/* Free Software Foundation; either version 2 of the License, or (at your    */
/* option) any later version.                                                */
/*                                                                           */
/* This program is distributed in the hope that it will be useful, but       */
/* WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         */
/* General Public License for more details.                                  */
/*                                                                           */
/* You should have received a copy of the GNU General Public License         */
/* along with this program; if not, write to the Free Software               */
/* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                 */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*   File Name :  MatchWildcard.c                                            */
/*                                                                           */
/*   Called By :  ProcOption.c, SearchList.c                                 */
/*                                                                           */
/*   Calls     :  None.                                                      */
/*                                                                           */
/*   Date      :  03-Sep-92                                                  */
/*                                                                           */
/*****************************************************************************/


Bool MatchWildcard (m, w)
char *m;
char *w;
  {
  /* 
     This is a simple wildcard matching function.
     The string wild contains one or more wildcard "*" characters
     The string match is tested as a possible match for string wild
  */

  char *tok, *mptr;

  int   wlen;
  char  wild[NAMELEN], match[NAMELEN];

  if ((!w) || (!m))
    return (FALSE);
/*
  printf ("Match = %s\n", m);
  printf ("Wild  = %s\n", w);
  printf ("WChar = %s\n", WILDSTR);
*/

  strcpy (wild,  w);
  strcpy (match, m);

  mptr = match;
  wlen = strlen (wild);
  tok  = strtok (wild, WILDSTR);

  while (tok)
    {
    /* printf ("Match: %s, Token: %s - ", mptr, tok); */
    if ((tok == wild) && (strncmp (mptr, tok, strlen (tok)) != 0))
      {
      return (FALSE);
      }
    else
    if ((mptr = strstr (mptr, tok)) == NULL)
      {
      /* printf ("FALSE\n"); */
      return (FALSE);
      }
    else
      {
      /* printf ("TRUE\n"); */
      mptr += strlen (tok);
      }

    tok = strtok (NULL, WILDSTR);
    }

  if (mptr[0] == '\0')
    {
    /* printf ("  All tokens found and mptr at end of match\n"); */
    return (TRUE);
    }
  else
  if (w[wlen - 1] == WILDCHR)
    {
    /* printf ("  Wildcard at end so doesn't matter what's left of match\n"); */
    return (TRUE);
    }
  else
    {
    /* printf ("  All tokens found but not at end of match: %s, %c\n", mptr, w[wlen - 1]); */
    return (FALSE);
    }
  }
