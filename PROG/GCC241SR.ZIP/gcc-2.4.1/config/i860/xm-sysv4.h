/* Configuration for GCC for Intel i860 running System V Release 4.  */

#include "i860/xm-i860.h"
#include "xm-svr4.h"
