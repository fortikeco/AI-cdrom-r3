main()
{
  return yyparse();
}
