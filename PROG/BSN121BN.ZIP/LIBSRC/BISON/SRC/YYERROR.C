#include <stdio.h>

yyerror(char *s)
{
  printf("%s\n", s);
}
