/*
**	argv.h
*/

typedef struct
{
	char **		ptrs;
	char *		strs;
	int			ptr_size;
	int			ptr_used;
	int			str_size;
	int			str_used;
} *argPtr;

argPtr	argPtr_new(int seed_size);
void	argPtr_add(argPtr arg, char *argp);
void	argPtr_insert(argPtr arg, int argpos, char **argv, int argc);
void	argPtr_delete(argPtr arg, int argpos, int num);
void	argPtr_free(argPtr arg);

/* End of File */

