(* This "program" allows you to use an editor from sml.exe *)
(* Change T to the name of the editor                      *)
(* Does not work with smlpm.exe                            *)

fun edit name=system("T "^name);
fun run name=(edit(name),use(name));
