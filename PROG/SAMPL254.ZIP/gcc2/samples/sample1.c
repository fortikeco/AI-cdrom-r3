#include <stdio.h>

main(int argc, char *argv[], char *envp[])
{
   printf ("Hello world\n");
}
