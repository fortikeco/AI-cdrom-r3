#include <iostream.h>

class sampleclass {
   public:
       sampleclass()
       {
          cout << "constructor\n";
       }

       ~sampleclass()
       {
          cout << "destructor\n";
       }
};

sampleclass GlobalInstance;

main()
{
    cout << "hello world\n";
}

