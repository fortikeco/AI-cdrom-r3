#import <stdio.h>
#import "Float.h"

@implementation Float
{
  float value;
}

- init: (float) x
{
  [super init];		// In case the parent class is doing
  			// something special in its init...
  value = x;
  return self;
}

- report
{
  printf("%4.1f", value);
  return self;
}

@end
