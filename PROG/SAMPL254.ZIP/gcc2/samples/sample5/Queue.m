
// Queue.m - comp.lang.objective-c simple sample Objective-C program

#import "Queue.h"

@implementation	Queue

+ new
{
    self = [super new];
    head = tail = 0;
    qsize = 0;
    return self;
}

- empty
{
    while([self size])
	[[self get] free];
    return self;
}

- put: anItem
{
  if (tail)
	tail = [[tail set_next : [Node new : anItem]] next];
  else
	head = tail = [Node new : anItem];
  ++qsize;
    return self;
}

- get
{
  id contents;
  id old_head = head;
  head = [head next];
  contents = [old_head free];
  if (--qsize == 0)
      tail = head;
  return contents;
}

- (unsigned) size { return qsize; }

@end
