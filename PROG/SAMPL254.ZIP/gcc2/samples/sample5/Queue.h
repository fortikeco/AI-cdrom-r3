
// Queue.h - comp.lang.objective-c simple sample Objective-C program

#import <objc/Object.h>
#import "Node.h"

@interface	Queue : Object
{
    id	head;
    id	tail;
    unsigned	qsize;
}

 +		new;		// create a new Queue
 -		empty;		// clear out all contents of the Queue
 -		put: anItem;	// put anItem on the Queue
 -		get;		// return the item on top of the Queue
 - (unsigned)	size;		// tell us the current size of the Queue
@end
