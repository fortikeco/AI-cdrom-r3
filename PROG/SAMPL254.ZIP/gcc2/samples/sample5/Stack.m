
// Stack.m - comp.lang.objective-c simple sample Objective-C program

#import "Stack.h"

@implementation	Stack

+ new
{
    self = [super new];
    stack = 0;
    stack_size = 0;
    return self;
}

- empty
{
    while([self size])
	[[self get] free];
    return self;
}

- put: anItem
{
  stack = [[Node new : anItem] set_next : stack];
  ++stack_size;
  return self;
}

- get
{
  id contents;
  id old_stack = stack;
  stack = [stack next];
  contents = [old_stack free];
  --stack_size;
  return contents;
}

- (unsigned) size { return stack_size; }

@end
