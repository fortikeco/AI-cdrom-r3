#import <objc/Object.h>

@interface Char: Object
{
  int value;
}

- init: (int) x;
- report;

@end
