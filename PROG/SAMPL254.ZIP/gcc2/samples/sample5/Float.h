#import <objc/Object.h>

@interface Float: Object
{
  float value;
}

- init: (float) x;
- report;

@end
