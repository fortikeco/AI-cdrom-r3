
// Node.h - comp.lang.objective-c simple sample Objective-C program

#import <objc/Object.h>

@interface      Node : Object
{
  id	next;
  id	data;
}

 +	new: anItem;	 // create a Node and store anItem in it
 - 	free;		 // free a Node and return the item in it
 - 	next;		 // report the id of the next node after this one
 -	set_next: aNode; // make the next node be aNode
@end
