
// Node.m - comp.lang.objective-c simple sample Objective-C program

#import <objc/Object.h>
#import "Node.h"

@implementation	Node : Object

+ new: anItem
{
    self = [super new];
    next = 0;
    data = anItem;
    return self;
}

- free
{
    id tmp = data;
    [super free];
    return tmp;
}

- next { return next; }

- set_next: aNode { next = aNode; return self; }

@end
