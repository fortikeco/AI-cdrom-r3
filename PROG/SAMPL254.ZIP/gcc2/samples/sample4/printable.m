#include <stdio.h>
#include "printable.h"

@implementation PrintableInt
- setInt: (int)aValue
{
  value = aValue;
  return self;
}
- print
{
  printf("%d", value);
}
@end


@implementation PrintableString
- setStr: (char *)aValue
{
  value = aValue;
  return self;
}
- print
{
  printf("%s", value);
}
@end


@implementation EOL
- init
{
  self = [super init];
  [super setStr: "\n"];
}
@end
