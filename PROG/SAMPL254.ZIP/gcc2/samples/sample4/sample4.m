#include "printable.h"
#include "message.h"


int main()
{
  id msg1, msg2;
  
  msg1 = [[Message alloc] init];
  [msg1 append: [[[PrintableString alloc] init] setStr: "Hello, world"]];
  [msg1 append: [[EOL alloc] init]];
  [msg1 print];
  
  msg2 = [[Message alloc] init];
  [msg2 append: [[[PrintableString alloc] init] setStr: "Oh no! Version #"]];
  [msg2 append: [[[PrintableInt alloc] init] setInt: 2]];
  [msg2 append: [[[PrintableString alloc] init] setStr: " is "]];
  [msg2 append: msg1];
  [msg2 print];
}
