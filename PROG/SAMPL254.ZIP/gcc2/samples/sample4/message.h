#include "objc/Object.h"

@interface Message: Object
{
  id list;
}
- append: printable;
- print;
@end
