#include "objc/Object.h"

@interface PrintableInt: Object
{
  int value;
}
- setInt: (int)aValue;
- print;
@end

@interface PrintableString: Object
{
  char *value;
}
- setStr: (char *)aValue;
- print;
@end

@interface EOL: PrintableString
{
}
@end
