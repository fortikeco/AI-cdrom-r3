/********************************************/
/*                                          */
/* Standard Program Header File             */ 
/*                                          */
/********************************************/

/* Name Indentifier for the program icon. */

#define ID_RESOURCE      100

/* Name Identifier for the Menu Bar Items. */

#define   IDM_FILE         110
#define     IDM_NEW          111
#define     IDM_OPEN         112
#define     IDM_SAVE         113
#define     IDM_SAVEAS       114
#define     IDM_EXIT         115
#define     IDM_ABOUT        116
#define   IDM_EDIT         120
#define     IDM_UNDO         121
#define     IDM_CUT          122
#define     IDM_COPY         123
#define     IDM_PASTE        124
#define     IDM_CLEAR        125
#define     IDM_FIND         126
#define     IDM_SELECTALL    127

