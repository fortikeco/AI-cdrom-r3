#define INCL_WIN
#define INCL_GPI
#include <os2.h>
#include <stdlib.h>
#include "sample3.h"

extern "C"
 {
   // This function must be exported so don't mangle the name

   MRESULT ClientWndProc (HWND, USHORT, MPARAM, MPARAM);
 }
                               
  BOOL  GetFileToBrowse (HWND   hwndOwner);

MRESULT EXPENTRY ClientWndProc (HWND    hwnd,
                                   USHORT  msg,
                                   MPARAM  mp1,
                                   MPARAM  mp2)

  {// Variable Declarations

              RECTL    INVLDRECT;
              HPS      hPresSp;

   //  Main Program Logic  

   switch (msg)
     {
      case WM_CREATE:

           WinMessageBox (HWND_DESKTOP,                // Parent of message box window. 
                          hwnd,                        // Owner of message box.         
                    (PSZ) "Create message received.",  // Message.                      
                    (PSZ) "Debug Info",                // Message box title.            
                          0,                           // Message box ID.               
                          MB_OK | MB_ICONASTERISK);    // OK button - * Icon.           

           return 0;

      case WM_DESTROY:

           return 0;

      case WM_PAINT:

           hPresSp = WinBeginPaint (hwnd, 0, NULL);
           WinQueryWindowRect (hwnd, &INVLDRECT);
           WinFillRect (hPresSp, &INVLDRECT, CLR_WHITE);
           WinEndPaint (hPresSp);
           return 0;

      case WM_COMMAND:

           switch (SHORT1FROMMP(mp1))
             {
              case IDM_NEW:
                GetFileToBrowse (hwnd);
                return 0;
             }
     }
   return WinDefWindowProc (hwnd, msg, mp1, mp2);
  }

