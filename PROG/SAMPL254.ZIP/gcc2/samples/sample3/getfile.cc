
#define   INCL_WIN
#include  <os2.h>

extern "C"
  {
   #include  <string.h>
  }

CHAR    szFileToBrowse[512];

BOOL    GetFileToBrowse (HWND      hwndOwner)
  {
   FILEDLG          fild;         // File dialog structure.

   memset (&fild, 0, sizeof (FILEDLG));
   fild.cbSize     = sizeof (FILEDLG);
   fild.fl         = FDS_OPEN_DIALOG    |
                     FDS_CENTER;
   fild.pszIDrive  = (PSZ) "C:";

   WinFileDlg (HWND_DESKTOP,
               hwndOwner,
               &fild);

   if (fild.lReturn == DID_OK)
     {
      strcpy (szFileToBrowse, fild.szFullFile);
      return TRUE;
     }
   return FALSE;
  }

