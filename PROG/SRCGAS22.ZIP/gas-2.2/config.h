#define TARGET_CPU       "i386"
#define TARGET_ALIAS     "i386-*-bsd"
#define TARGET_CANONICAL "i386-*-bsd"
#define GAS_VERSION      "2.2"
