
const char *manual_select_dialog(HWND owner);
