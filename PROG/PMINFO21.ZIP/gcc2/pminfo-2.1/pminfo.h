
/*
     Program PM-Info: a program for viewing GNU-style hypertext info
     documentation files.
     Copyright (C) 1992,1993  Colin Jensen
     
     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.
     
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
     
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Contact addresses:
	Colin Jensen
	email: cjensen@netcom.com
	US mail: 4902 Esguerra Terrace, Fremont CA, 94555
*/

#define ID_RESOURCE 100

#define IDM_FILE 110
#define IDM_EXIT 111

#define IDM_NODE 120
#define IDM_NODE_DIR 121
#define IDM_NODE_NEXT 122
#define IDM_NODE_PREVIOUS 123
#define IDM_NODE_UP 124
#define IDM_NODE_LAST 125
#define IDM_NODE_TOP 126
#define IDM_NODE_GOTO 127
#define IDM_NODE_MENU 128

#define IDM_ABOUT 130
#define IDM_ABOUT_ABOUT 131
#define IDM_ABOUT_WARRANTY 132
#define IDM_ABOUT_COPYING 133

#define IDM_TEST 140
#define IDM_TEST1 141
#define IDM_TEST2 142
#define IDM_TEST3 143
#define IDM_TEST4 144

#define IDM_KBD_PGUP 150
#define IDM_KBD_PGDN 151
#define IDM_KBD_LINEUP 152
#define IDM_KBD_LINEDOWN 153

#define IDM_OPTIONS 160
#define IDM_FONTSELECT 161
#define DIALOG_GOTO                 201
#define DIALOG_GOTO_NODES           202
#define DIAFONT_FACE_NAMES          301
#define DIAFONT                     300
#define DIAFONT_FAMILY_NAMES        302
#define DIAFONT_POINTS              303
#define DIAFONT_SAMPLE              304
