
/*
     Program PM-Info: a program for viewing GNU-style hypertext info
     documentation files.
     Copyright (C) 1992,1993  Colin Jensen
     
     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.
     
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
     
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Contact addresses:
	Colin Jensen
	email: cjensen@netcom.com
	US mail: 4902 Esguerra Terrace, Fremont CA, 94555
*/

MK_MSG(ACTIVATE, Activate)
MK_MSG(APPTERMINATENOTIFY, AppTerminateNotify)
MK_MSG(ADJUSTWINDOWPOS, AdjustWindowPos)
MK_MSG(BEGINDRAG, BeginDrag)
MK_MSG(BEGINSELECT, BeginSelect)

MK_MSG(BUTTON1CLICK, Button1Click)
MK_MSG(BUTTON1DBLCLK, Button1DblClk)
MK_MSG(BUTTON1DOWN, Button1Down)
MK_MSG(BUTTON1MOTIONEND, Button1MotionEnd)
MK_MSG(BUTTON1MOTIONSTART, Button1MotionStart)
MK_MSG(BUTTON1UP, Button1Up)

MK_MSG(BUTTON2CLICK, Button2Click)
MK_MSG(BUTTON2DBLCLK, Button2DblClk)
MK_MSG(BUTTON2DOWN, Button2Down)
MK_MSG(BUTTON2MOTIONEND, Button2MotionEnd)
MK_MSG(BUTTON2MOTIONSTART, Button2MotionStart)
MK_MSG(BUTTON2UP, Button2Up)

MK_MSG(BUTTON3CLICK, Button3Click)
MK_MSG(BUTTON3DBLCLK, Button3DblClk)
MK_MSG(BUTTON3DOWN, Button3Down)
MK_MSG(BUTTON3MOTIONEND, Button3MotionEnd)
MK_MSG(BUTTON3MOTIONSTART, Button3MotionStart)
MK_MSG(BUTTON3UP, Button3Up)

MK_MSG(CALCFRAMERECT, CalcFrameRect)
MK_MSG(CALCVALIDRECTS, CalcValidRects)
MK_MSG(CHAR, Char)
MK_MSG(CHORD, Chord)
MK_MSG(CLOSE, Close)
MK_MSG(COMMAND, Command)
MK_MSG(CONTEXTMENU, ContextMenu)
MK_MSG(CONTROL, Control)
MK_MSG(CONTROLPOINTER, ControlPointer)
MK_MSG(CREATE, Create)
MK_MSG(DESTROY, Destroy)
MK_MSG(DRAWITEM, DrawItem)
MK_MSG(ENABLE, Enable)
MK_MSG(ENDDRAG, EndDrag)
MK_MSG(ENDSELECT, EndSelect)
MK_MSG(ERASEBACKGROUND, EraseBackground)

#ifdef IBM_PM_REFERENCE_LIES
MK_MSG(ERASEWINDOW, EraseWindow)
#endif

MK_MSG(ERROR, Error)
MK_MSG(FOCUSCHANGE, FocusChange)
MK_MSG(FORMATFRAME, FormatFrame)
MK_MSG(HELP, Help)
MK_MSG(HITTEST, HiTest)
MK_MSG(HSCROLL, Hscroll)
MK_MSG(INITDLG, InitDlg)
MK_MSG(INITMENU, InitMenu)
MK_MSG(JOURNALNOTIFY, JournalNotify)
MK_MSG(MATCHMNEMONIC, MatchMnemonic)
MK_MSG(MEASUREITEM, MeasureItem)
MK_MSG(MENUEND, MenuEnd)
MK_MSG(MENUSELECT, MenuSelect)
MK_MSG(MINMAXFRAME, MinMaxFrame)
MK_MSG(MOUSEMOVE, MouseMove)
MK_MSG(MOVE, Move)
MK_MSG(NEXTMENU, NextMenu)
MK_MSG(NULL, Null)
MK_MSG(OPEN, Open)
MK_MSG(PACTIVATE, PActivate)
MK_MSG(PAINT, Paint)
MK_MSG(PCONTROL, PControl)
MK_MSG(PPAINT, PPaint)
MK_MSG(PRESPARAMCHANGED, PresParamChanged)
MK_MSG(PSETFOCUS, PSetFocus)
MK_MSG(PSIZE, PSize)
MK_MSG(PSYSCOLORCHANGE, PSysColorChange)
MK_MSG(QUERYACCELTABLE, QueryAccelTable)
MK_MSG(QUERYBORDERSIZE, QueryBorderSize)
MK_MSG(QUERYHELPINFO, QueryHelpInfo)
MK_MSG(QUERYICON, QueryIcon)
MK_MSG(QUERYTRACKINFO, QueryTrackInfo)
MK_MSG(QUERYWINDOWPARAMS, QueryWindowParams)
MK_MSG(QUIT, Quit)
MK_MSG(REALIZEPALETTE, RealizePalette)
MK_MSG(SAVEAPPLICATION, SaveApplication)
MK_MSG(SEM1, Sem1)
MK_MSG(SEM2, Sem2)
MK_MSG(SEM3, Sem3)
MK_MSG(SEM4, Sem4)
MK_MSG(SETACCELTABLE, SetAccelTable)
MK_MSG(SETBORDERSIZE, SetBorderSize)
MK_MSG(SETFOCUS, SetFocus)
MK_MSG(SETHELPINFO, SetHelpInfo)
MK_MSG(SETSELECTION, SetSelection)
MK_MSG(SETWINDOWPARAMS, SetWindowParams)
MK_MSG(SHOW, Show)
MK_MSG(SINGLESELECT, SingleSelect)
MK_MSG(SIZE, Size)
MK_MSG(SUBSTITUTESTRING, SubstituteString)
MK_MSG(SYSCOLORCHANGE, SysColorChange)
MK_MSG(SYSCOMMAND, SysCommand)
MK_MSG(SYSVALUECHANGED, SysValueChanged)
MK_MSG(TEXTEDIT, TextEdit)
MK_MSG(TIMER, Timer)
MK_MSG(TRACKFRAME, TrackFrame)
MK_MSG(TRANSLATEACCEL, TranslateAccel)

#ifdef IBM_PM_REFERENCE_LIES
MK_MSG(TRANSLATEMNEMONIC, TranslateMnemonic)
#endif

MK_MSG(UPDATEFRAME, UpdateFrame)
MK_MSG(VSCROLL, Vscroll)
MK_MSG(WINDOWPOSCHANGED, WindowPosChanged)


MK_MSG(QUERYFOCUSCHAIN, QueryFocusChain)
MK_MSG(QUERYDLGCODE, QueryDlgCode)


#undef MK_MSG
