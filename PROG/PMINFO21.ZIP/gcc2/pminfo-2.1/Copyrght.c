char *embedded_text_Copyrght[] = {
	"",
	"PM Info version 2.1, Copyright (C) 1992 Colin Jensen",
	"",
	"PM Info comes with ABSOLUTELY NO WARRANTY, for details select",
	"About/Warranty.",
	"",
	"This is free software, and you are welcome to redistribute",
	"it under certain conditions; select About/Copying for details.",
	"",
	"Programmer: Colin Jensen ",
	"Email: cjensen@netcom.com",
	"USMail: 4902 Esguerra Terrace, Fremont CA 94555"
};
int embedded_text_Copyrght_count = sizeof(embedded_text_Copyrght) / sizeof(*embedded_text_Copyrght);
