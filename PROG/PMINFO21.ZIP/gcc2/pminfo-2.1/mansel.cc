
class ManualSelector:
{
};
