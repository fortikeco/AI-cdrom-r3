This archive contains the executable of the IRIT solid modeler and the
accompanying files needed for proper executaion. It is highly recommended
you get the (Ansi C) sources of this package which suppose to be in a
similar zip file by the same iritsm3s.zip.

These executables were created using Borland BC++ 3.0

Gershon Elber

gershon@gr.utah.edu
