/*	Mobius - Generates a mobius strip .plg file for Rend386

	This program calculates the vertices and polygons for a
	mobius strip, and generates the file mobius.plg for use
	in rend386.  

	Written March 1993 by John T. Bell.
	Disclaimer:  This isn't the best program ever written,
	but it get's the job done quickly and simply.

	Usage: mobius n_halfs top_color bottom_color R_major r_minor n_segments

	All arguments are optional, but none may be "skipped".  That is
	to say, you can leave arguments off the end, but not the 
	beginning. 

	Argument	Default		Meaning
	========	=======		=======
	n_halfs		1		Number of half twists in strip
	top_color	0x11FF		Color of 1st side of strip ( In Hex! )
	bottom_color	0x14FF		Color of 2nd side ( if it exists! )
	R_major		1000		Radius of complete loop
	r_minor		100		radius of twist ( 1/2 strip width )
	n_segments	36		Number of polys per surface

	The vertex calculations are performed by summing two vectors.
	The larger vector loops through a circle in a plane, and describes
	the center line of the strip.  The smaller vector is the offset 
	of the edges of the strip from the centerline.  It has the same
	theta angle as the large vector at any point, plus a phi angle
	which varies according to the number of half-flips requested.

	For an interesting challenge, try "walking" along the surface
	of a mobius strip as if it were a sidewalk.  The easiest approach
	is to start with a small number of flips and gradually work up
	to more complicated configurations.
	
*/
