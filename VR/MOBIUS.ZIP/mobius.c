/*	Mobius - Generates a mobius strip .plg file for Rend386

	This program calculates the vertices and polygons for a
	mobius strip, and generates the file mobius.plg for use
	in rend386.  

	Written March 1993 by John T. Bell.
	Disclaimer:  This isn't the best program ever written,
	but it get's the job done quickly and simply.

	Usage: mobius n_halfs top_color bottom_color R_major r_minor n_segments

	All arguments are optional, but none may be "skipped".  That is
	to say, you can leave arguments off the end, but not the 
	beginning. 

	Argument	Default		Meaning
	========	=======		=======
	n_halfs		1		Number of half twists in strip
	top_color	0x11FF		Color of 1st side of strip ( In Hex! )
	bottom_color	0x14FF		Color of 2nd side ( if it exists! )
	R_major		1000		Radius of complete loop
	r_minor		100		radius of twist ( 1/2 strip width )
	n_segments	36		Number of polys per surface

	The vertex calculations are performed by summing two vectors.
	The larger vector loops through a circle in a plane, and describes
	the center line of the strip.  The smaller vector is the offset 
	of the edges of the strip from the centerline.  It has the same
	cylindrical angle as the large vector at any point, plus a 
	spherical angle which varies according to the number of half-flips 
	requested.
	
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

main( int argc, char *argv[] ) {

	double R_major = 1000.0, r_minor = 100.0, theta, phi;
	double sin_theta, cos_theta, sin_phi, cos_phi;
	double delta_theta, delta_phi;
	double base_x, delta_x, y, base_z, delta_z;

	int n_halfs = 1, i, n_segments = 36;
	int top_color = 0x11FF, bottom_color = 0x14FF;

	FILE *outfile;

	if( argc > 1 ) n_halfs      = atoi( argv[ 1 ] );
	if( argc > 2 ) sscanf( argv[ 2 ], "%x", &top_color );
	if( argc > 3 ) sscanf( argv[ 3 ], "%x", &bottom_color );
	if( argc > 4 ) R_major      = atof( argv[ 4 ] );
	if( argc > 5 ) r_minor      = atof( argv[ 5 ] );
	if( argc > 6 ) n_segments   = atoi( argv[ 6 ] );

	outfile = fopen( "mobius.plg", "w" );

	fprintf( outfile, "mobius %10d %10d\n", 
		n_segments * 2 + 2, n_segments * 2 );

	if( n_halfs % 2 ) bottom_color = top_color;

	delta_theta = 2.0 * M_PI / n_segments;
	for( i = 0; i < n_segments + 1; i++ ) {

		theta = i * delta_theta;
		phi = theta * n_halfs / 2;

		sin_theta = sin( theta );  /* Calculate these once/loop only */
		cos_theta = cos( theta );
		sin_phi   = sin( phi );
		cos_phi   = cos( phi );

		base_x = R_major * cos_theta;		/* base_y = 0 */
		base_z = R_major * sin_theta;

		y = r_minor * sin_phi;			/* = delta_y */
		delta_x = r_minor * cos_phi * cos_theta;
		delta_z = r_minor * cos_phi * sin_theta;

		fprintf( outfile, "%20.5g %20.5g %20.5g\n", 
			base_x + delta_x, y, base_z + delta_z );
		fprintf( outfile, "%20.5g %20.5g %20.5g\n", 
			base_x - delta_x, -y, base_z - delta_z );

	} /* End of for loop calculating vertices */

	/* Draw two polys for each segment */
	for( i = 0; i < ( n_segments ) * 2; i += 2 ) {

		fprintf( outfile, "0x%X   4   %10d %10d %10d %10d\n", 
			top_color, i, i + 2, i + 3, i + 1 );
		fprintf( outfile, "0x%X   4   %10d %10d %10d %10d\n", 
			bottom_color, i, i + 1, i + 3, i + 2 );
	}

}
