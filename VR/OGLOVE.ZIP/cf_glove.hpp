//  Author:  Mitch Allen
// Address:  76040.2757@compuserve.com
// Program:  cf_glove.hpp
// Revised:  11/91

/*
  Credits:

  Originally "power.c" (c) manfredo 9/91
  manfredo@opal.cs.tu-berlin.de

  Ported to PC compatibles by Greg Alt 10/91
  galt@peruvian.utah.edu or galt@es.dsd.com

  Substantially rewritten by Dave Stampe (c) 1991: PWRFILT.C
  No cash, no warranty, no flames.  This stuff works great, so gimme credit.

  dstamp@watserv1.uwaterloo.ca                   17/10/91

  This source was adapted from theGlove.c contained in pglove.zip

  Converted to C++ by Mitch Allen 11/91
*/

#ifndef _cf_glove_hpp_
#define _cf_glove_hpp_

#define XHYST 2                 /* hysterisis for X, Y low noise reduction */
#define YHYST 2                 /* 2 eliminates +/-3 quanta of noise */

#define XACC 8                  /* X, Y maximum accel/decel level. Should */
#define YACC 8                  /* be 6-10, but too high limits gesturing */

#define XXTEND 2                /* stretches deglitching time */
#define YXTEND 1

#define N 1                     /* delay scaled by N/D <CHANGED> */
#define D 1                     /* these are 1,1 for 486 PC with i/o card */

/* bits for i/o ports <CHANGED> */

#define         GDATA           0x10    /* PG data in */
#define         GLATCH          0x02    /* PG latch out */
#define         GCLOCK          0x01    /* PG clock out */
#define         GCLOLAT         0x03    /* clock + latch */

/* delay values for sending and sampling data <CHANGED> */

#define     D2BYTES      150      /* delay between 2 bytes = 96 us  */
#define     D2BITS       6        /* delay between 2 bits = 3 us    */
#define     D2SLOW       8000     /* intertest delay = 2000-4000 us */

extern "C" {
        void fdelay(unsigned int val);
}

typedef enum {
        LPT1,
        LPT2
} tPort;

typedef struct tagGloveData {
        unsigned char x;
        unsigned char y;
        unsigned char z;
        unsigned char rotation;
        unsigned char fingers;
        unsigned char keys;
} tGloveData;

class cfGlove {

        int     gloveInPort, gloveOutPort;

        union {
                unsigned char data[ 12 ]; // Should be only 6 ???
                tGloveData  gloveData;
        };

        tGloveData      oldData;

        int drawn;          // set if cursor to be erased.

        void display_glove( tGloveData& gd );

        int xx;         // plot position.

        int ox, oy;     // last x,y for hysterisis.

        int x1, y1;     // delayed 1 sample (for smoothed velocity test).
        int x2, y2;     // delayed 2 samples.
        int lx, ly;     // last good X,Y speed.
        int lax, lay;   // bad data "stretch" counter.
        int lsx, lsy;   // X,Y "hold" values to replace bad data.
        int lcx, lcy;   // last X,Y speed for accel. calc.

public:
        cfGlove();
        ~cfGlove() { C0L0(); }

        int assign_glove_port( tPort p );

        void set_glove_inPort( int ip ) { gloveInPort = ip; }
        void set_glove_outPort( int op ) { gloveOutPort = op; }

        /* defines for output line pair control */

        void C0L0() { outportb( gloveOutPort, 0 ); }        // clock 0 latch 0.
        void C0L1() { outportb( gloveOutPort, GLATCH ); }   // clock 0 latch 1.
        void C1L0() { outportb( gloveOutPort, GCLOCK ); }   // clock 1 latch 0.
        void C1L1() { outportb( gloveOutPort, GCLOLAT ); }  // clock 1 latch 1.

        int get_glove_x()  { return( gloveData.x ); }
        int get_glove_y()  { return( gloveData.y ); }
        int get_glove_z()  { return( gloveData.z ); }
        int get_glove_rotation()  { return( gloveData.rotation ); }
        int get_glove_fingers()   { return( gloveData.fingers ); }
        int get_glove_keys()      { return( gloveData.keys ); }

        void set_glove_hiResMode();             // puts glove in hires mode
        void get_glove_data();                  // get data packet from glove
        int  is_glove_ready();                  // returns 0 if not ready
                                                // delay repeats by 2-4 ms
        unsigned char get_glove_byte();    // read byte from glove

        void remove_glove_lowNoise();
        void deGlitch_glove();

        virtual void draw_glove();
        void draw_glove_plot();
};

#endif

