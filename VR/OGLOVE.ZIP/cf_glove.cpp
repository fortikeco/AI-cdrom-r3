//  Author:  Mitch Allen
// Program:  cf_glove.cpp

#include <dos.h>
#include <bios.h>
#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <math.h>
#include "cf_glove.hpp"

void fdelay(unsigned int val)
{
        // Replace this...

         long i;

         i = ( long ) ( N * val );
         for( ; i > 0; i -= D );
}

cfGlove::cfGlove()
{
        drawn = 0;
        xx = 0;
        ox = oy = -1000;        // last x,y for hysterisis.
        x1 = y1 = 0;            // delayed 1 sample (for smoothed velocity test).
        x2 = y2 = 0;            // delayed 2 samples.
        lx = ly = 0;            // last good X,Y speed.
        lax = lay = 0;          // bad data "stretch" counter.
        lsx = lsy = 0;          // X,Y "hold" values to replace bad data.
        lcx = lcy = 0;          // last X,Y speed for accel. calc.

        assign_glove_port( LPT1 );
}

int cfGlove::assign_glove_port( tPort p )
{
        switch( p ) {
                case LPT1:
                        set_glove_inPort( 0x379 );
                        set_glove_outPort( 0x378 );
                        break;
                case LPT2:
                        set_glove_inPort( 0x279 );
                        set_glove_outPort( 0x278 );
                        break;
                default:
                        return( 0 );
        }

        return( 1 );
}


unsigned char cfGlove::get_glove_byte ()
{
        // read a byte from glove <rolled code>

        register int i;
        register unsigned char x = 0;

        C1L0 ();                       /* generate a reset (latch) pulse */
        C1L1 ();
        fdelay(D2BITS);                /* hold for 5 us */
        C1L0 ();

        for( i = 0; i < 8; i++ )
        {
                x <<= 1;
                x += ( ( inportb( gloveInPort ) & GDATA ) >> 4 );
                C0L0 ();
                C1L0 ();  /* pulse */
         }

        return( x );  /* return the byte */
}

int cfGlove::is_glove_ready()
{
        // returns 1 if glove ready, 0 otherwise.

        int f = get_glove_byte();

        return( ( f== 0xA0 ) ? 1 : 0 );
}

void cfGlove::get_glove_data()
{
        // read 6 byte data packet
        register unsigned char *bp;

        bp = data;

        *bp++ = get_glove_byte();    /* read data */
        fdelay(D2BYTES);
        *bp++ = get_glove_byte();
        fdelay(D2BYTES);
        *bp++ = get_glove_byte();
        fdelay(D2BYTES);
        *bp++ = get_glove_byte();
        fdelay(D2BYTES);
        *bp++ = get_glove_byte();
        fdelay(D2BYTES);
        *bp++ = get_glove_byte();
        fdelay(D2BYTES);
                               /* throwaways (speeds up polling later) */
        // ???
        get_glove_byte();
        fdelay(D2BYTES);
        get_glove_byte();
}

int hires_code[] = { 0x06, 0xC1, 0x08, 0x00, 0x02, 0xFF, 0x01 };

void cfGlove::set_glove_hiResMode()
{
        // enter HIRES mode <rolled code- speed unimportant>.

        int i, j, k;
                             /* dummy read 4 bits from glove:  */
        C1L0 (); C1L1 ();    /* generate a reset (latch) pulse */
        fdelay(D2BITS);
        C1L0 ();

        fdelay(D2BITS);
        C0L0 (); C1L0 ();    /* pulse clock */
        fdelay(D2BITS);
        C0L0 (); C1L0 ();    /* pulse clock */
        fdelay(D2BITS);
        C0L0 (); C1L0 ();    /* pulse clock */
        fdelay(D2BITS);
        C0L0 (); C1L0 ();    /* pulse clock */

                        /* handshake for command code? */
        C1L0 ();
        fdelay(16950);  /* 7212 us delay */
        C1L1 ();
        fdelay(4750);   /* 2260 us delay */

        for( i = 0; i < 7 ; i++ )       /* send 7 bytes */
        {
                k = hires_code[ i ];
                for( j = 0; j < 8; j++ )   /* 8 bits per byte, MSB first */
                {
                        if( k & 0x80 )
                        {
                                C1L1();
                                C0L1();
                                C1L1();
                        } else {
                                C1L0();
                                C0L0();
                                C1L0();
                        }

                        k <<= 1;

                        fdelay(D2BITS);
                }

                fdelay(D2BYTES);
         }

        fdelay( 1090 );    /* 892 us delay (end of 7. byte) */

        C1L0();          /* drop the reset line */

        fdelay(30000);   /* some time for the glove controller to relax */
        fdelay(30000);
}

void cfGlove::draw_glove()        /* draw square cursor */
{
         // hold down "2" to stop drawing.
         if( get_glove_keys() == 2 )
                 return;

         if( drawn ) {
                 // erase old box.
                 setcolor( 3 );
                 display_glove( oldData );
         }

         setcolor( 15 );                  /* draw new box */
         display_glove( gloveData );
         drawn = 1;

         oldData.x = get_glove_x();         /* save pos'n for next erase */
         oldData.y = get_glove_y();
         oldData.z = get_glove_z();
}

void cfGlove::display_glove( tGloveData& gd )
{
        // draw/erase box cursor
        int x = 320 + 2 * ( gd.x );     // compute X,Y center.
        int y = 240 - 2 * ( gd.y );
        int z = 30 + ( gd.z );          // size prop. to Z.

        // rectangle( x - z, y - z, x + z, y + z );
        rectangle( x, y, x + 5, y + 5 );
}


void cfGlove::draw_glove_plot()
{
        // plot X,Y data to test smoothing.

        if( get_glove_keys() == 4 ) {
                // restart at left edge if "4" pressed.
                cleardevice();
                xx = 0;
        }

        setcolor( 0 );
        line( xx, 0, xx, 479 );
        line( xx + 1, 0, xx + 1, 479 );

        setcolor( 15 );
        line( xx, 240 - 2 * get_glove_x(), xx + 1, 240 - 2 * get_glove_x() );

        setcolor( 12 );
        line( xx + 1, 240 - 2 * get_glove_y(), xx + 2, 240 - 2 * get_glove_y() );

        xx += 2;

        if( xx > 639 ) {
               xx = 0;
        }
}

void cfGlove::remove_glove_lowNoise()
{
        // hysterisis deglitch (low noise removal).

        int x = get_glove_x();
        int y = get_glove_y();

        if( get_glove_keys() == 0 ) {
                // handle recentering ("0"key or "Center").
                ox = oy = 0;
        }

        // X hysterisis.

        if( x - ox > XHYST ) {
                ox = x-XHYST;
        }

        if( ox - x > XHYST ) {
                ox = x + XHYST;
        }

        // Y hysterisis

        if( y - oy > YHYST ) {
                oy = y-YHYST;
        }

        if( oy - y > YHYST ) {
                oy = y + YHYST;
        }

        // replace present X,Y data.
        gloveData.x = ox;
        gloveData.y = oy;
}

void cfGlove::deGlitch_glove()
{
        int vx, vy;

        int x = get_glove_x();
        int y = get_glove_y();

        if( get_glove_keys() == 0 ) {
               // reset on recentering ("0" or "Center" key).
               x1 = x2 = y1 = y2 = 0;
               lx = ly = lax = lay = 0;
               lsx = lsy = lcx = lcy = 0;
        }

        // smoothed velocity.

        vx = x - ( ( x1 + x2 ) >> 1 );
        vy = y - ( ( y1 + y2 ) >> 1 );

        x2 = x1;                       /* update last values */
        x1 = get_glove_x();

        y2 = y1;
        y1 = get_glove_y();

        if( abs( lcx - vx ) > XACC ) {
                /* check for extreme acceleration */
                lax = XXTEND;
        }

        if( lax == 0 ) {
                /* save only good velocity */
                lx = vx;
        }

        lcx = vx;       /* save velocity for next accel.  */

        if( abs( lcy - vy ) > YACC ) {
                /* same deal for Y accel. */
                lay = YXTEND;
        }

        if( lay == 0 ) {
                ly = vy;
        }

        lcy = vy;

        if( lax != 0 ) {
                /* hold X pos'n if glitch */
                gloveData.x = lsx;
                lax--;
        }

        if( lay != 0 )             /* hold Y pos'n if glitch */
        {
               lay--;
               gloveData.y = lsy;
        }

        lsx = get_glove_x();            /* save position for X,Y hold */
        lsy = get_glove_y();
}

