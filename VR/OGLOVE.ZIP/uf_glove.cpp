//  Author:  Mitch Allen
// Program:  uf_glove.cpp

// Unit test for uf_glove.cpp

#include <dos.h>
#include <bios.h>
#include <stdio.h>
#include <conio.h>
#include <graphics.h>

#include "cf_glove.hpp"

int gdriver = VGA;              /* for graphics plot and cursor */
int gmode = VGAHI;

int main()
{
        cfGlove GLOVE;
        unsigned unready;         /* number of unsuccessful tries to read glove */

        /* VGA graphics, 640x480 */
        initgraph(&gdriver, &gmode, "e:\\bc\\bgi\\");
        cleardevice();

        int pass = 0;

        /* begin again here if glove crashes */
 restart:

        if( pass++ >= 3 ) {
                printf("\n Glove not responding. ");
                return( 0 );
        }

        /* set PG into 'hires' mode */
        GLOVE.set_glove_hiResMode();

        while( ! kbhit() )
        {
                unready = 0;    /* start polling glove */

                fdelay(D2SLOW);

                /* wait for glove to become ready */
                while( ! GLOVE.is_glove_ready() )
                {
                        if( unready++ > 500 ) {
                                printf("\n Glove not ready.  Resetting... ");
                                goto restart;   /* reset mode if dead glove */
                        }
                        fdelay(D2SLOW);
                }

                /* read 6 byte packet */
                GLOVE.get_glove_data();

                gotoxy(1,1);   /* print xyz at scrren top */

                printf( "\n %04d %04d %04d  ",
                        ( 255 & GLOVE.get_glove_x() ),
                        ( 255 & GLOVE.get_glove_y() ),
                        ( 255 & GLOVE.get_glove_z() )
                );

                /* print rot, fingers, keys */
                printf(" %-2x %-2x %-2x ",
                        GLOVE.get_glove_rotation(),
                        GLOVE.get_glove_fingers(),
                        GLOVE.get_glove_keys()
                );

                /* remove spikes and jumps */
                GLOVE.deGlitch_glove();

                /* add hysteresis to remove LL noise */
                GLOVE.remove_glove_lowNoise();

                // GLOVE.draw_glove_plot(); /* plot x,y positions */
                GLOVE.draw_glove();      /* animate glove cursor */
          }

         getch();                       /* exit when keyboard hit */
}

