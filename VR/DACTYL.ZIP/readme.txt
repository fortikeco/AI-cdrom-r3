                      Dactyl World Demo (c) Todd Porter


This is the beginnings of a full VR game.  I am putting it out for people
to take a look at.  I need help in finishing it up.  I want to add some
more features that I am having trouble with.  Here is what I want to add:

        1.  Communication support (modem)
        2.  A gun that will fire a projectile
        3.  bascially get it like the arcade game

I know the world is not efficient in its use of polys but I have not had time
to go back and revamp it yet.  This will be fixed soon!  There are also some
other bugs in which I have no way to deal with...I am using the skeleton.c
with the .obj's that came out in PCVR.  This was the only way I could compile
applications with Turbo C++, since the libs were made for Borland C++ with
TASM.  The animation does not work, it locks-up if you are using expanded mem
- that is you don't have emm386 NOEMS in your config.sys.

I had orignally set up the .wld and .plg files as encrypted data to keep
people from messing with the worlds since the locations are hard coded into
the pgm...but I changed my mind right now...it took too long to load it all up
and was not efficient for its current state.   So if you mess around w/the
world you may get some funny results.

Todd Porter
so92332@gsvms2.cc.gasou.edu
