Welcome to PENDULUM!  I hope you will have fun, and you may even
learn some Physics. If this is your registered copy you will have
received the printed manual. If not, you can print the abbreviated
MANUAL.DOC on your printer. You can also start right away, by
typing PENDULUM and pressing the ENTER or RETURN key. See how far 
you can get, and read the manual later. You can also install
PENDULUM on your hard disk by typing INSTALL. 

This is a SHAREWARE program. As you know we rely on the honor
system. If you like PENDULUM and plan to use it, please send for
your registered copy. To mail you the latest version of the program
and the complete printed manual I need your name, address and a
$23 check or money order sent to:

                              Peter Thieberger
                              SCIENCE FUN
                              15 Seeley St.
                              Brookhaven, NY 11719

When you register you also get two months of free support by mail,
and future upgrade opportunities.

Feel free to distribute copies of the program, but make sure you
include all the original files including this one. You may also
distribute the original PENDULUM.ZIP file if you have it.

Happy experimenting with PENDULUM!

                                       Peter Thieberger.

