This is a very brief doc for plgfilt.

This program is to be used with NorthCad v9.8 plg files.  It will filter
out some of the polys that are uneeded.  There are two methods of fitering
I am not sure which is which so if this is wrong just switch it around.
The problem with Ncad 9.8 .plg files is that the program writes out both
sides of the poly's regardless of wether its visible or not.  (ie. a sphere
in which the inside will also be rendered)  This can double the number of
poly's you really need.  However often times you will want to keep both
sides in an object.  This program will filter objects individually and ask
what method, if any, you want to use.  Be sure to declare you surfaces in Ncad
the same way for all.  This will make it easier to filter them out later.  I
have found that the revolutions work great with this, so long as you pick
the right filter method.  The best thing to do is play around with it and try
out example .plgs with it.




A:  this method will filter out the clockwise sides of the polys.  This is
    the same as you would normally declare them in normal .plg files.  This
    means that while in NCad you must declare your surfaces in the proper
    fashion.  The surface you want to be visible must be declared 
    counterclockwise so it will not be filtered out.  

B:  this method is exactly opposite of method A:


I have also noticed that Ncad .plgs have a huge number of verts.  I have been
using combvert.exe (by Bernie Roehl) which is avail on Compuserve and 
sunee.uwaterloo.ca.  This program works good but it will only work with single
object .plg files which can lead to some problems.  I will try to incorp. it
into this pgm as time allows.  For now the best thing is to break up the 
Ncad multi-plg file into single ones and run combvert on it.

Have fun...hope it helps.  Feel free to upload this archive anywhere.  I wrote
it for personal use but have seem some interest for it so I am now sharing it 
with everyone.  Hope it helps out!

I can be reached at:

Compuserve:  76505,1574@compuserve.com
Internet:    so92332@gsvms2.cc.gasou.edu

I have recently taken a job in Florida so I am not sure if will be able to
keep the internet account.  However it is still the best way to contact me
at this time.  If you don't get a quick answer there then mail to compuserve
otherwise mail to Internet address.

