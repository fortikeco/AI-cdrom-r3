/* This program requires Release 4.01 of Rend386 to compile */


#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <math.h>
#include "rend386.h"
#include "userint.h"
#include "plg.h"
#include "splits.h"
#include "tasks.h"
#include "pointer.h"
#include "cursor.h"
#include "segasupp.h"
#include "segio.h"
#include "intmath.h"

#define to_rad(a) ((a) * 3.14159262 / 180.0)
#define sine(x)   sin(to_rad(x/65536L))
#define cosine(x) cos(to_rad(x/65536L))

#define CEILING    2400
#define FLOOR         0
#define LEFT_WALL   500
#define RIGHT_WALL 3650
#define BACK_WALL     0
#define FRONT_WALL 4000


/* Global variables */
/* This is our main object list.
   Files used:  keyboard, world, cursors
*/
OBJLIST  	*objlist;

/* This is the default values for stereo viewing.
   Files used:  keyboard, world, render
*/
STEREO 		default_stereo = {600,240,320,50,600, 1*65536L};

/* This variable indicates the type of viewing.
   Declared in file: render.c
   Files used: keyboard, gloveptr, world, render
*/
int 		stereo_type = MONOSCOPIC;

/* This variable declares the default startup view of the program.
   Files used: keyboard, world
*/
VIEW 		default_view =  {
				0,0,-1000,
				0,0,0,
				9*65536L,
				1000,15000,-5000,
				0,319,0,199,
				1,100000,
				1/1.25*65535L,
				0
				};

/* This pointer points to the location of the default view
   Files used: keyboard, world, render
*/
VIEW     	*current_view = &default_view;

/* This pointer in the beginning of the split tree for the program.  We
   will only one however, that is not a requirement.
   Files used: keyboard, world, render, cursors, hdmanip
*/
SPLIT           *split_tree = NULL;

/* This variable holds a palette.
   Files used: world
*/
unsigned char 	palette[256*3];

/* This pointer is the start of a set of tasks.
   Files used: world
*/
TASK 		*tasklist = NULL;

/* This pointer holds a handle to the current video driver installed.
   Files used: main program
*/
void		*v_driver_pointer = NULL;

/* This variable holds a loadpath specified in the configuration file or
   in a world file.
   Files used: world
*/
char 		loadpath[100] = "";

/* This variable holds a temporary filename including a loadpath.
   Files used: main program
*/
static char 	tempname[100];


char 		framefname[100];

/* Delcares an extern function. */
extern void 	*screen_data();

/* This variable is used to hold information about the current screen setup.
   File used: gloveptr, mouseptr, render, userint
*/
extern struct 	Screeninfo *screeninfo;

/* This variable is used in the userint file.  Purpose ?
*/
PDRIVER 	*menu_device = NULL;
PDRIVER		*manip_device = NULL;

/* These variable are used as the configuration settings for the glove
   pointer device, translation and rotation.
   Files used: world
*/
float 		gpdo_x = 2, gpdo_y = 2, gpdo_z = 2,
		gpdo_rx = 1, gpdo_ry = 1, gpdo_rz = 1;

/* These varaiables are used as the configuration settings for the head
   tracker device, relative position to neck, and rotation. */
float 		hdo_x = 0, hdo_y = 0, hdo_z = 0; /* relative pos'n to neck */
float 		hdo_rx = 0, hdo_ry = 0, hdo_rz = 0;

/* These variables are used as the configuration settings for the STEREOLEFT
   command in a world file.  Check world.doc for description.
   Files used: world keyboard
*/
int 		sl_xflip = 0, sl_xoff = 0;
long 		sl_left = -1, sl_top, sl_right, sl_bottom;

/* These variables are used as the configuration settings for the
   STEREORIGHT command in a world file.  Check world.doc for description.
   Files used: world keyboard
*/
int 		sr_xflip = 0, sr_xoff = 0;
long 		sr_left = -1, sr_top, sr_right, sr_bottom;

/* These variables are used as the configuration settings for the rotation
   of the STEREORIGHT and STEREOLEFT commands in the world file.  Check
   world.doc for description.
   Files used: world keyboard.
*/
float 		sl_xrot = 0, sr_xrot = 0;

/* This variable indicates whether or not a glove is being used.
   0 = false.
   Files used: cursors hdmanip
*/
int 		use_glove = 1;

/* This variable indicates whether or not a head tracker is being used.
   0 = false.
   Files used: render
*/
int 		use_ht = 0;

/* This variable indicates whether or not a wide-angle dual VGA
   head mounted display system is being used.
   0 = false.
   Files used: render
*/
int 		use_wide = 0;

/* This variable indicates whether or not a monochrome system is being used.
   0 = false.
   Files used: render
*/
int 		use_BW = 0;

/* This variable is set to 1 if the eyes are to be switched when using
   the Sega 3D glasses.
   Files used: render
*/
int 		swap_eyes = 0;

/* This variable is set to display a fancy background
   Files used: keyboard render
*/
int 		fancy_background = 0;

/* This variable is set to draw a reflection pool at the bottom of the
   screen.
   Files used: keybaord render
*/
int 		reflection_pool = 0;

/* This variable is set to indicate we have a logo to display.
   Files used: render
*/
int 		have_logo = 0;

/* This variable is set to show our logo, if we have one.
   Files used: render keyboard
*/
int 		show_logo = 0;

/* This variable is set to show the current location on-screen.
   Files used: render keyboard
*/
int 		show_location = 0;

/* This variable is set to show the 3D compass on-screen.
   Files used: render keyboard
*/
int 		show_compass = 0;

/* This variable is set to display the frames/second rate on-screen.
   Files used: render keyboard
*/
int 		show_framerate = 0;

/* This variable is set to clear the screen on each frame.
   Files used: render world keyboard
*/
int 		do_screen_clear = 1;

/* This variable is set to draw a "frame".
   Files used: world render
*/
int 		use_frame = 0;

/* These variabels define the location of a "frame".
   Files used: world render
*/
int 		frame_x = 0, frame_y = 0, frame_w = 320, frame_h = 200;

/* This variable is set to the current display mode to use.
   Files used: render world
*/
int		vdmode = 0x14;

/* This variable is set to 1 if we need to recompute the current view.
   Files used: world keyboard
*/
int 		review = 1;

/* This variable is set to 1 if we need to copy our gram back on-screen.
   Files used: keyboard world colormap render rendrep
*/
int 		reframe = 0;


/* This variable is set if the shift key is used by the user.
   Files used: main program keyboard
*/
int 		shifted = 0;

/* This variable is used to hold the current visual page being used.
   Files used: render userint
*/
int		v_page = 0;

/* This variable is set if a glove is available.
   Files used: world cursors
*/
int 		have_glove = 1;

/* This variable is set if a pointer device is available.
   Files used: world cursors
*/
int 		have_ptr = 0;

/* This variable is set if we can do mouse manipulations.
   Files used: keyboard
*/
int 		manip_2D_avail = 0;

/* This variable is set to run the main execution loop.
   Files used: main
*/
int             execution = 1;

/* This variable is set to indicate a screen redraw is necessary.
   Files used: keyboard anim world cursors render hdmanip
*/
int		redraw = 1;

/* This variable is set if a horizon should be drawn.
   Files used: keyboard render colormap
*/
int		do_horizon = 1;

/* This variable is not necessary because it is define elsewhere and can
   be set with a world file.  It is the color the system paints the top
   half of the screen after it is cleared; if the do_horizon variable is
   set to 1.
   Files used: world render colormap
*/
extern 		sky_color;

/* This variable is not necessary because it is define elsewhere and can
   be set with a world file.  It is the color the system paints the bottom
   half of the screen after it is cleared; if the do_horizon variable is
   set to 1.
   Files used: world render colormap
*/
extern		ground_color;

/* This variable is not necessary because it is define elsewhere and can
   be set with a world file.  It is the color the system paints the screen
   after it is cleared; if the do_horizon variable is set to 0.
   Files used: world render colormap
*/
extern int      screen_clear_color;


/* This variable holds the highest possible color value.
   Files used: render colormap
*/
extern 		highest_color;

/* This variable is set to 0 if no palette is loaded and
   non-zero if a palette is loaded
   Files used: world
*/
int 		npalette = 0;

/* This variable holds the name of the current switcher driver.
   Files used: world
*/
char 		swdname[40] = "sega";

/* This variable holds the name of the current glove pointer driver.
   Files used: world
*/
char 		gpdname[40] = "pglove";

/* This variable holds the name of the current head tracker driver.
   Files used: world
*/
char 		hdname[40] = "none";

/* This variable holds the name of the glove pointer driver cursor figure.
   Files used: world
*/
char 		gpcursor[40] = "handsm.fig";

/* This variable holds the name of the current video driver.
   Files used: main program and world
*/
char            vdname[40] = "vd256.rvd";

/* This variable holds the name of the current mouse driver.
   Files used: world
*/
char            mdname[40] = "none";

int head_device = 0;
int BALL_SPEED = 10;
extern SEGMENT *body_seg;


/**************************************************************************
   This function is used by the file render.c to display various things
   on the screen to the user.  This is not needed by any program just
   an option.  However, render.c needs access to this function
***************************************************************************/
void status_on_screen()
{
}


/**************************************************************************
   This function concatenates the loadpath to the string name IF
   name is not "\\" and not "/" and loadpath is not empty.  It is used by
   the files: world.c.
**************************************************************************/
char *fix_fname(char *name)
{

	if (loadpath[0] && !strchr(name, '\\') && !strchr(name, '/'))
		sprintf(tempname, "%s\\%s", loadpath, name);
	else
		strcpy(tempname, name);
	return tempname;
}


/**************************************************************************
  This function is called when the user ends the graphics program.  It
  shuts done the graphics system and exits the renders and finally exits
  the progam.
**************************************************************************/
void closeall(){
  exit_graphics();
  reset_render();
  exit(0);
}



/**************************************************************************
   This function is from Rend386 demo2.c program and is used to get
   keyboard input from the user.
***************************************************************************/
unsigned getkey(){
  unsigned c;
  union REGS regs;

  regs.h.ah = 2;
  int86(0x16, &regs,&regs );
  shifted = (regs.h.al & 3);
  if ((c=bioskey(0)) & 0xff) c &= 0xff;
  else if ( shifted ) c |= 1;
  return c;
}



/**************************************************************************
   This function handles keys pressed by the user.Handle any user keys.
**************************************************************************/
void handle_key ( unsigned int c ){
FILE *infile;

  switch ( c ) {
    case 'q':
    case 'Q':popmsg ( "Do you wish to quit? (y/n)" );
	     if ( toupper(getkey())== 'Y' ) execution = 0;
	     else redraw = 1;
	     break;

    /* Look up. Step by 1 angle value */
    case 0x4800: current_view->tilt += 65536L;
		 redraw = 1;
		 break;

    /* Look down. Step by 1 angle value */
    case 0x5000: current_view->tilt -= 65536L;
		 redraw = 1;
		 break;

    /* Look to the left.  Step by 1 angle value */
    case 0x4B00: current_view->pan -= 65536L;
		 redraw = 1;
		 break;

    /* Look to the right.  Step by 1 angle value */
    case 0x4D00: current_view->pan += 65536L;
		 redraw = 1;
		 break;


    case 'Y':
    case 'y': rel_rot_segment ( body_seg, 0L, 90*65536L, 0L, RYXZ );
	      update_segment ( body_seg );
/*	      current_view->pan += 90*65536L;  */
	      redraw = 1;
	      break;

    case 'b':
    case 'B': current_view->ex -= 50L * sine(current_view->pan);
	      current_view->ez -= 50L * cosine(current_view->pan);
	      rel_move_segment ( body_seg, -50L*sine(current_view->pan),
					   0,
					   -50L*cosine(current_view->pan));
	      update_segment ( body_seg );

	      redraw = 1;
	      break;

    case 'f':
    case 'F': current_view->ex += 50L * sine(current_view->pan);
	      current_view->ez += 50L * cosine(current_view->pan);

	      rel_move_segment ( body_seg, 50L*sine(current_view->pan),
					   0,
					   50L*cosine(current_view->pan));
	      update_segment ( body_seg );
	      redraw = 1;
	      break;

    case 'r':
    case 'R': current_view->ex += 50L * cosine(current_view->pan);
	      current_view->ez -= 50L * sine(current_view->pan);
	      rel_move_segment ( body_seg, +50L*cosine(current_view->pan),
					   0,
					   -50L*sine(current_view->pan));
	      update_segment ( body_seg );
	      redraw = 1;
	      break;

    case 'l':
    case 'L': current_view->ex -= 50L * cosine(current_view->pan);
	      current_view->ez += 50L * sine(current_view->pan);
	      rel_move_segment ( body_seg, -50L*cosine(current_view->pan),
					   0,
					   +50L*sine(current_view->pan));
	      update_segment ( body_seg );
	      redraw = 1;
	      break;


  }
}



/**************************************************************************
  This function performs the updating of the screen after any object or
  perspective movements.  The majority of the work is done in the
  function screen_refresh in the file render.c
**************************************************************************/
void refresh_display(){

  initialize_screen_factors ( current_view );
  fast_view_factors ( current_view );
  screen_refresh ( current_view );

}



int	x_position,
	y_position,
	z_position,
	inc_val_x,
	inc_val_y,
	inc_val_z;
/**************************************************************************
  This function moves the ball according to the racquet hit and the
  boundaries of the court.
**************************************************************************/
void move_ball(SEGMENT *BALL)
{
  y_position+=inc_val_y;
  if ( y_position > CEILING )
    {
      inc_val_y = -BALL_SPEED; /* (rand() % 50);*/
      y_position+=inc_val_y;
    }
  else if ( y_position <= FLOOR )
    {
      inc_val_y = BALL_SPEED; /* (rand() %50); */
      y_position+=inc_val_y;
    }


  x_position+=inc_val_x;
  if ( x_position > RIGHT_WALL )
    {
      inc_val_x = -BALL_SPEED; /*(rand() %50);*/
      x_position+=inc_val_x;
    }
  else if (x_position < LEFT_WALL )
    {
      inc_val_x = BALL_SPEED; /*(rand() % 50);*/
      x_position+=inc_val_x;
    }


  if ( inc_val_z > BALL_SPEED ) inc_val_z -= 1;
  if ( inc_val_z < -BALL_SPEED ) inc_val_z += 1;
  z_position+=inc_val_z;
  if ( z_position > FRONT_WALL )
    {
      inc_val_z = -BALL_SPEED; /*(rand() % 50); */
      z_position+=inc_val_z;
    }
  else if ( z_position <= BACK_WALL )
    {
      inc_val_z = BALL_SPEED; /* (rand() % 50);*/
      z_position+=inc_val_z;
    }

  abs_move_segment ( BALL, x_position, y_position, z_position );
  update_segment ( BALL );

}


void prprint(int x,int y, int color, char *t)
{
	int bk = (color>8) ? 0 : 15;

	printxyr(x,y,bk,t,0);
	printxyr(x+1,y+1,color,t,0);
}


SEGMENT *palm;
OBJECT  *palm_object;
OBJECT  *handle;
/**************************************************************************
  This function performs the functions of the program.  The loop terminates
  when execution = 1.
**************************************************************************/
void main_loop(SEGMENT *BALL, SEGMENT *RACQUET){
  POINTER gp;
  OBJECT *racquet_object;
  OBJECT *ball_object;
  long x,y,z,rad;

  int NO_RACQUET = 1;
  char buf[100];
  long dist;

  racquet_object = seg_get_object(find_segment_by_name(RACQUET, "racquet"));
  ball_object = seg_get_object (BALL);
  rad = get_object_bounds ( handle, &x, &y, &z );

  while ( execution )
    {
      if (bioskey(1)) 	handle_key (getkey());
      if (redraw) 	refresh_display();
      move_ball(BALL);

      glove_update( manip_device, &gp );
      update_segment ( body_seg );


      if ( NO_RACQUET )
	{
	  dist = sphere_pretest (palm_object,x,y,z);
	  sprintf(buf, "Racquet dist: %ld", dist);
	  prprint(2,3,15,buf);
	  if (( dist < 100 ) && (gp.gesture == G_FIST ))
	    {
	      attach_segment ( RACQUET, palm );
	      NO_RACQUET = 0;
	    }

	}

      if (!NO_RACQUET)
      {
	 rad = get_object_bounds ( ball_object, &x, &y, &z );
	 dist = sphere_pretest ( racquet_object, x, y, z );
	 sprintf(buf, "Ball dist: %ld", dist );
	 prprint ( 2, 3, 15, buf );
	 if (dist<300)
	   {
	     if ( inc_val_z < 0 )
	       inc_val_z = BALL_SPEED*5;
	     else
	       inc_val_z = -BALL_SPEED*5;
	     z_position += inc_val_z;
	   }
      }

    }
}



/**************************************************************************
  This function is called to load video drivers.  The pointer
  v_driver_pointer is set to a handle representing the video driver.
  The variable v_driver_pointer is used by the files: main only.
**************************************************************************/
void load_video_driver ( char *dfile )
{
  v_driver_pointer = load_driver ( dfile );
  if ( v_driver_pointer == NULL )
  {
	fprintf ( stderr, "Bad video driver/n" );
	exit ( 1 );
  }
}



/**************************************************************************
  This function is used to read the racquetball used in the game and
  assign it to a segment called ball_seg which is returned to the caller.
**************************************************************************/
SEGMENT * read_ball()
{
  FILE *in;
  OBJECT *ball;
  SEGMENT *ball_seg;

  if ((in = fopen ( "ball.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open ball file.\n" );
      exit(1);
    }

  set_loadplg_offset ( 0, 0, 0 );
  set_loadplg_scale ( 5, 5, 5 );
  ball = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading ball.plg file.\n" );
      exit(1);
    }

  add_to_objlist ( objlist, ball );
  ball_seg = new_seg ( NULL );
  seg_set_object ( ball_seg, ball );

  update_segment ( ball_seg );

  x_position = 1000;
  y_position = 500;
  z_position = 2000;
  inc_val_x = 50;
  inc_val_y = 40;
  inc_val_z = 40;

  return ball_seg;
}


/**************************************************************************
  This function is used to read the racquet used in the game and
  assign it to a segment called racquet_seg which is returned to the caller.
**************************************************************************/
SEGMENT * read_racquet()
{
  FILE *in;
  SEGMENT *racquet_seg;

  if ((in = fopen ( "racquet.fig", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open racquet file.\n" );
      exit(1);
    }

/*  set_loadplg_offset (1000, 500, 2000);
  set_loadplg_scale (3, 3, 3);  */

  set_readseg_objlist ( objlist );
  set_readseg_scale ( 3, 3, 3 );
  racquet_seg = readseg (in, NULL);
  if ( readseg_err != 0 )
    {
      fprintf ( stderr, "Error loading racquet.plg file.\n" );
      exit(1);
    }

  /*add_to_objlist ( objlist, racquet );
  racquet_seg = new_seg ( NULL );
  seg_set_object ( racquet_seg, racquet );  */

  abs_move_segment ( racquet_seg, 1500, 500, 2000 );
  abs_rot_segment ( racquet_seg, 0L, 90*65536L, 0L, RXYZ );
  update_segment ( racquet_seg );

  handle = seg_get_object (find_segment_by_name(racquet_seg, "handle" ));
  if ( handle == NULL )
    {
       fprintf ( stderr, "Cannot find handle segment.\n" );
       exit(1);
    }

  return racquet_seg;
}



void get_glove()
{
  PDRIVER *gd;
  extern PDRIVER *gloveptr_init(char *gname, long sx, long sy,
		 long sz, long srx, long sry, long srz );

  gd = gloveptr_init ( gpdname, gpdo_x*65536.0, gpdo_y*65536.0, gpdo_z*65536.0,
		       gpdo_rx*65536.0, gpdo_ry*65536.0, gpdo_rz*65536.0 );

  manip_device = menu_device = gd;
  if(gd)
    load_glove_cursor ( body_seg, manip_device, gpcursor );
}




void main(int argc, char *argv[]){
  char *fname, *in_filename;
  FILE *in;
  SEGMENT *BALL, *RACQUET;

  setup_render(40,800);
  atexit(closeall);
  set_global_split_root ( &split_tree );
  initial_world_split ( &split_tree );
  set_move_handler ( split_move_handler );
  objlist = new_objlist();


  fname = "rend386.cfg";
  if ((in = fopen ( fname, "r" )) == NULL )
    {
      fprintf ( stderr, "Configuration file not found!" );
      exit(1);
    }
  else
    {
      if ( read_world(in))
	{
	    fprintf ( stderr, "Error reading configuration file!" );
	    exit(1);
	}
      fclose ( in );
    }

  in_filename = fix_fname(argv[1] );
  if ( strstr (in_filename, ".wld"))
    {
      if ((in = fopen ( in_filename, "r" )) == NULL )
	{
	  fprintf ( stderr, "Error opening world file.\n" );
	  exit(1);
	}
      if (read_world(in))
	{
	  fprintf ( stderr, "Error reading world file.\n");
	  exit(1);
	}
      fclose(in);
    }





  load_video_driver ( vdname );
  screeninfo = screen_data();
  highest_color = screeninfo->colors-1;
  preset_default_colors();

  frame_x = screeninfo->xmin;
  frame_y = screeninfo->ymin;
  frame_w = screeninfo->xmax - screeninfo->xmin+1;
  frame_h = screeninfo->ymax - screeninfo->ymin+1;

  default_view.left = screeninfo->xmin;
  default_view.top = screeninfo->ymin;
  default_view.right = screeninfo->xmax;
  default_view.bottom = screeninfo->ymax;
  default_view.aspect = screeninfo->aspect;


  if (enter_graphics()) {
    fprintf ( stderr, "could not enter graphics mode\n\n");
    exit(1);
    }

  screen_clear_color = 0;

  sky_color  = 1; ground_color = 2;


  initialize_screen_factors ( current_view );
  fast_view_factors ( current_view );


  BALL = read_ball();
  RACQUET = read_racquet();

  body_seg = new_seg(NULL);
  set_readseg_scale ( 1,1,1 ); /* Must do or will get previous readseg scale */
  get_glove();


  abs_move_segment ( body_seg, 2250, 800, -300 );
  update_segment ( body_seg );




  palm = find_segment_by_name (body_seg, "palm" );
  rel_rot_segment ( palm, 0L,0L, -45*65536L, RZXY );
  update_segment ( palm );
  if ( palm == NULL )
    {
       fprintf ( stderr, "Cannot find palm segment.\n" );
       exit(1);
    }
  palm_object = seg_get_object ( palm );

  main_loop(BALL, RACQUET);   /* start us off */

}
