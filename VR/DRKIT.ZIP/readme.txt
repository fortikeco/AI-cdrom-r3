This package contains all the tools and files needed to build drivers for 
REND386, as of 7/10/92.  It includes 16 color and 256 color 320x200
video drivers.  For use with a Fresnel lens viewer, there is also a
640x200 driver (for ATI, may work for othe SVGA cards by changing the 
vdriver mode parameter in the .cfg file) and a "tweaked"  392x200 256-color 
driver.

Pointer drivers are documented, and a simple mouse driver is included.

Code and compile batch files are included for all drivers.

- Dave Stampe, 7/10/92

