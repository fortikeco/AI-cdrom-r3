                                PRISM v1.1

This simple program can be used to create .PLG files for use with the
REND386 libaries and routines.  I wrote it because I didn't have any 3-D
modelling software and I was getting bored of scribbling on bits of
graph paper.


CONTENTS OF THIS ARCHIVE

READ.ME ....... this text file
PRISM.EXE ..... the executable program
PRISM.C ....... the source code
PRISM.MAK ..... makefile (originally for Borland C++ v2.0; may
                          require some alteration)
LINTEL.PLG .... )
PODIUM.PLG .... ) Sample .PLG files created by PRISM
COL20.PLG ..... )
PORTICO.FIG ... a sample FIGure file combining the above .PLG files.
                For use with REND386.


USING THE PROGRAM

Briefly, you tell the program how many sides you want your prism
to have (eg. 3 for a triangular prism, 8 for octagonal etc.).  It
will then calculate the positions of the vertices and output the
data in .PLG file format.

Number of sides, as well as other information, may optionally be
specified using the following command-line format:


	prism [-n <sides>] [-f <output-file>] [-o <object-name>]
	      [-r <radius>] [-R <inner-radius>] [-l <length>]

where:

	<sides>		is the number of sides of the end polygons
			(default is 4)

	<output-file>	is the file name to use for output
			(default is to use standard output)

	<object-name>	is the name given to the object within the
			.PLG-format data
			(default is "prism")
			
	<radius>	is the radius of the circle that circumscribes
			the end polygons
			(default is 100 units)

	<inner-radius>	is the radius of the circle that describes the
			narrower part for "fluted" prisms (see below).

	<length>	is the length in the Z-axis direction of the
			prism.
			(default is 100 units)


Additionally it's possible to get a usage message (if you forget the
command-line format) by specifying any of "-help", "-?", "/?" etc.

FLUTED PRISMS

For a normal prism the figures at each end will be a simple polygon such
as a triangle or hexagon.  For a "fluted" prism the end figures will be
stars, with the number of sides specified by the "-n" option.  The star
will have half as many points as sides; for example, a 10-sided fluted
prism would have 5-pointed stars at the ends.  Since stars are concave
polygons they have to be constructed from other, convex polygons.  This
makes the .PLG file slightly more complicated, but the user needn't
worry about this.

EXAMPLES

  prism -n 8 -f octagon.plg        
		creates an octagonal prism of default size

  prism -n 20 -f cyl.plg -o cylinder -r 60 -l 150
		creates (almost) a cylinder of radius 60 and length 150
		units.

  prism -n 18 -f cog.plg -r 300 -R 150 -l 100
		creates a fluted prism based on a 9-pointed star. 
		Making the length short makes it look like a cog.

And so on.




DISCLAIMER

I wrote this in a few hours one afternoon because I needed it.
If it turns out to be useful, then great.  If not, never mind.


Chris Hand   cph@leicp.ac.uk

