/*
 *  PRISM -- create a prism in .PLG format 
 *
 *  Copyright (c) Chris Hand 1992
 *
 *  This program is intended for use with the marvellous REND386 3-D
 *  rendering software for the IBM PC, written by Bernie Roehl
 *  <broehl@sunee.uwaterloo.ca> and Dave Stampe <dstampe@sunee.uwaterloo.ca>.  
 *
 *  This code is Public Domain.
 *
 *  History
 *  -------
 *		v1.0	09-Aug-92	Original version.
 *		v1.1	12-Aug-92	Added "fluted" prism capability.
 */
#include <stdio.h>
#include <math.h>


#ifndef TRUE

#define TRUE (1==1)
#define FALSE (1==0)

#endif

static char *BlortyMsg[] = {
  "PRISM version 1.1  (c) Chris Hand 1992",
  "This program is Public Domain.",
  "",
  NULL};

static char *UsageMsg[] = {
  "\n\rUsage:",
  "prism [-n <sides>] [-f <output-file>] [-o <object-name>]",
  "      [-r <radius>] [-R <inner-radius>] [-l <length>]",
  "",
  NULL};


/*
 * EmitPrism -- create a prism with polygonal ends of given number
 *              of sides.  Send to output stream "fd".
 *
 *           If "radius" > "radius2" then prism will be "fluted".
 *
 *           Number of vertices will be (sides * 2) and number
 *           of polygons required will be (sides + 2).
 *
 * Method:   Consider the polygon with number of edges = "sides".
 *           Calculate the x and y co-ords for the polygon
 *           in the plane z = 0.
 *
 *           Once all vertices in this polygon have been calculated,
 *           step through them in order and for each edge 
 *           x1,y1,0 --> x2,y2,0 we can emit a rectangle in 3-space
 *           as (x1,y1,0)(x2,y2,0)(x2,y2,z)(x1,y1,z) where "z" is the
 *           depth.  (actually use +/- z/2 so that prism is centred
 *           on the origin.)
 *
 *           All that then remains is to emit the "end pieces", both
 *           polygons with number of edges = "sides".
 *
 *    A classic example of a function that does too much!
 */

void EmitPrism(FILE *fd, int sides, char *name, int radius, int radius2,
		int length, int fluted)
{
	float		angle, step, counter;
	int		r, i, x = 0, y = 0;
	int		NumVerts = sides * 2, NumPolys = sides + 2;
	long		RectColour = 0x18af;


	/* Fluted prisms have more complex ends, so total
	 * number of polys = sides 
	 *   PLUS 2 end polygons
	 *   PLUS "sides/2" triangles at each end --> "sides" triangles.
	 */
	if (fluted)
		NumPolys = sides + 2 + sides; 
		
	fprintf(fd, "# A%s%d-sided prism created by the PRISM program\n\n\r",
			(fluted ? " fluted " : " "), sides);
	fprintf(fd, "%s   %d %d  \n\r", name, NumVerts, NumPolys);
	
	step = (2.0 * M_PI) / sides;

	angle = step;

	/*   Step round the circle, calculating points on
	 *   the plane z = 0.  Emit vertices for near face
	 *   and far face.
	 */
	r = radius;
	
	for (i = 0; i < sides; i++)
	{
		x = (int)(r * cos(angle));
		y = (int)(r * sin(angle));

		fprintf(fd, "%d %d %d\n\r", x, y, -length / 2);
		fprintf(fd, "%d %d %d\n\r", x, y,  length / 2);
		
		angle += step;

		if (fluted) /* alternate between the 2 radii */
		{
			if (r == radius) r = radius2;
			else r = radius;
		}
	}

	/* (Even-numbered vertices are THIS side, odd-numbered
	 * vertices are THAT side.)
	 */

	/* Emit the rectangles for side pieces, with vertices
	 * specified ANTI-CLOCKWISE from outside.
	 */

	i = 0; /* first side-piece uses last 2 vertices */
	
	fprintf(fd, "0x%lx 4 %d %d %d %d\n\r", RectColour,
		NumVerts-2, NumVerts-1, i+1, i);
		
	/* For each remaining side piece ... */
	for (i += 2; i < NumVerts; i += 2)
		fprintf(fd, "0x%lx 4 %d %d %d %d\n\r", RectColour,
			i-2, i-1, i+1, i);

	/* Finally, emit the polygons for the end pieces.
	 * If the prism is fluted the end pieces will be
	 * concave, so we'll have to split them up.
	 */
	
	if (fluted)
	{
		int vert = 2;
		
		/* Triangles: number = num of sides/2 */

		fprintf(fd, "\n\r# Triangles to patch up near end\n\r");

		/* First triangle uses last vertex and first two. */
		fprintf(fd, "0x%lx 3 %d %d %d\n\r", RectColour,
				NumVerts-2, 0, 2);
				
		for (i = 1; i < sides/2; i++, vert +=4) /* do the rest */
		{
			fprintf(fd, "0x%lx 3 %d %d %d\n\r", RectColour,
				vert, vert+2, vert+4);
		}

		/* Now plug the hole with a polygon with
		 * number of sides = sides/2.
		 *
		 * Assume that first vertex on "inner circle"
		 * (smaller radius) is vertex 2.
		 */
		fprintf(fd, "\n\r# Plug near end with %d-sided polygon\n\r", 
				sides/2);

		fprintf(fd, "0x%lx %d ", RectColour, sides/2);
		for (i=0, vert=2; i < sides/2; i++, vert+=4)
			fprintf(fd, "%d ", vert);

		fprintf(fd, "\n\r");


		/******************************************************
	             Now do the same for the other end of the prism.

		   NB: All polygons must face in the other direction,
		       so we have to given vertices in the opposite
		       order to that used for the "near" end.

		 ******************************************************/

		fprintf(fd, "\n\r# Triangles to patch up far end\n\r");

		/* First triangle uses last vertex and first two. 
		 * NB: "far end" so all verts offset by 1 
		 */
		fprintf(fd, "0x%lx 3 %d %d %d\n\r", RectColour,
				3, 1, NumVerts-1);
				
		for (vert=3, i=1; i < sides/2; i++, vert +=4) /* do the rest */
		{
			fprintf(fd, "0x%lx 3 %d %d %d\n\r", RectColour,
				vert+4, vert+2, vert);
		}

		/* plug end with polygon as for other end */

		fprintf(fd, "\n\r# Plug far end with %d-sided polygon\n\r", 
			sides/2);

		fprintf(fd, "0x%lx %d ", RectColour, sides/2);
		for (vert=NumVerts-1, i = 0; i < sides/2; i++, vert -= 4)
			fprintf(fd, "%d ", vert);

		fprintf(fd, "\n\r");

	}
	else
	{
		fprintf(fd, "0x%lx %d ", RectColour, sides);
		for (i = 0; i < sides * 2; i += 2)
			fprintf(fd, "%d ", i);

		fprintf(fd, "\t# end piece 1\n\r0x%lx %d ", RectColour, sides);
		for (i = (sides*2)-1; i >= 1; i -= 2)
			fprintf(fd, "%d ", i);
		
		fprintf(fd, "\t# end piece 2\n\r");
	}
	
	fflush(fd);
	
	return;
}

/*
 *      -------  MAIN  ---------
 */		
int main(int argc, char *argv[])
{
	int	NumSides = 4; /* default is square */
	int	radius   = 100, InnerRadius = 80, length = 100;
	int	fluted 	 = FALSE, i;
	char	ObjName[128] = "prism";
	FILE	*outfile = stdout;  /* stdout is default output */

	for (i = 0; BlortyMsg[i] != NULL; ++i)
		fprintf(stderr, "%s\n\r", BlortyMsg[i]);

	/* Give usage message if 1st argument matches [-/]{?,{help,h}
	 * or if bad number of arguments given
	 */
	if ((argc >= 1 && (argv[1][0] == '-' || argv[1][0] == '/') &&
		(argv[1][1] == '?' || argv[1][1] ==  'h')) || 
		argc > 12)
	{ int i;
		for (i = 0; UsageMsg[i] != NULL; ++i)
			fprintf(stderr, "%s\n\r", UsageMsg[i]);
		exit(-1);
	}

	for (i = 1; i < argc; i++)
	{
		if (argv[i][0] == '/' || argv[i][0] == '-')
		{
			switch(argv[i][1])
			{
				default: /* unknown flag */
				{ int line;
					fprintf(stderr, "Unknown flag: '%c'\n\r", argv[i][1]);

					for (line = 0; UsageMsg[line] != NULL; ++line)
						fprintf(stderr, "%s\n", UsageMsg[line]);
					exit(-1);
				}
				break;
				
				case 'n': /* number of sides */
				NumSides = atoi(argv[++i]);
				if (NumSides < 3)
				{
					fprintf(stderr, "Number of sides must be greater than 3!\n\r");
					exit(-1);
				}
				break;
				
				case 'f': /* output filename */	
				if ((outfile = fopen(argv[++i], "w")) == (FILE *)NULL)
				{
					fprintf(stderr, "Can't open \"%s\".\n\r",
						argv[i]);
					exit(-1);
				}
				break;

				case 'o': /* object name */
				strcpy(ObjName, argv[++i]);
				break;
				
				case 'r': /* (outer) radius */
				radius = atoi(argv[++i]);
				break;

				case 'R': /* inner radius (ie. fluted) */
				InnerRadius = atoi(argv[++i]);
				fluted = TRUE;
				break;
				
				case 'l': /* length (z direction) */
				length = atoi(argv[++i]);
				break;
				
			} /* switch */
		} /* if */
	} /* for */

	if (fluted && (((NumSides >> 1) << 1) == 1))
	{
		fprintf(stderr, "error: Fluted prism must have even number of sides!\n\r");
		exit(-1);
	}
	

	EmitPrism(outfile, NumSides, ObjName, radius, InnerRadius, 
			length, fluted);
	
	return 0;
}
