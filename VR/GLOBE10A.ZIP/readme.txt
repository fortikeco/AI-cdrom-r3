This is version 1.0A of Rend Globe, 

It produces plg files (format 4.0) for use with 
Bernie Roehl's Rend386. 

The figure it produces are Globes or Ball like objects.

So on the commandline type

rendglobe <outputfile> objectname radius longtitude latitude colour

for example...

    rendglob ball.plg ball 500 20 10 1

 will get you a file ball.plg containing plg called ball with
 20 lines of longtitue and 10 lies of latitude evely spaced.
 (thus making them 18 degrees apart)


 Restrictions on input

   longtitude>=3
   latitude>=2 


 Globe.plg is a cute little world globe made with RendGlobe.
 It uses 450 polygons. 30x15

 Version 2.0A will include facilities for "wrapping" bitmaps onto globes,
 better command line support, and will remove the silly restriction on
 input values.

 !!! Note !!! 
 This program can produce very large input files.
 Try keeping the number of polys to less than 1600
 otherwise Rend386 might have a hard time with it.  
 Also keep plg file to less than 64k.


 Kevin Perry (3A computer engineering)
 Feb. 27th 93

 kevinp@csg.uwaterloo.ca
 kperry@electrical.watstar.uwaterloo.ca
