/*
 * RendGlobe 1.0
 * By Kevin Perry
 * The basic idea here is to make a list of vertices and a list of lines
 * joining those vertices, into a ball.
 * Later what we do is take a bitmap file and overlay that onto psuedo
 * square polys.
 * That can wait for version 2
 */
#include <math.h>
#include <stdio.h>


void ball(char *, int,int,int,int,int );


FILE *fp;


main(int argc,char *argv[]){
   double f;
   int i,rad,lng,lat,col;


   /* simple command line reading code */
   if(argc<7){
    printf("Command line should be ... \n");
    printf("rendglob <filename> objname radius lng lat color\n");
    printf("for example...\n");
    printf("rendglob  ball.plg     ball    300  30  15    10\n");
   }
   else {
     printf("Rend Globe 1.0 by Kevin Perry\n");
     fp = fopen(argv[1], "w+");
     rad = atoi(argv[3]);
     lng = atoi(argv[4]);
     lat = atoi(argv[5]);
     col = atoi(argv[6]);
     ball( argv[2], rad, lng, lat, col, 0 );             /* do it */
   }
   return(0);
}


void ball( char *name, int rad, int lng, int lat, int colour, int saddle ) {
   int i, j;
   double yang, ang, yinc,rinc;
   int last,vertices,polys;
   int r,x,y,z;
   int count;

   vertices = (lat-1)*lng + 2;
   polys = lat*lng;

   yinc = (180.0/((double)lat));
   rinc = (360.0/((double)lng));

   fprintf(fp,"#plg file produced by RendGlobe\n");
   fprintf(fp,"#written by Kevin Perry\n");
   fprintf(fp,"\n");
   fprintf(fp,"%s %d %d\n", name, vertices, polys );

   /* Generate the Vertices */
   fprintf(fp,"\n");
   fprintf(fp,"#Vertices\n");
   fprintf(fp,"\n");
   count =0;           /* use count to number vertices (debug aid) */
   for( i=0,yang=yinc; i<(lat-1); yang+=yinc, i++ ) {
     /* find the radius of this ring of points */
     r = rad*sin( yang/57.2958 );
     for( ang=0.0,j=0; j<lng ; ang+=rinc,j++ ) {
       /* calculate vertices on this ring */
       x = r * cos( ang/57.2958 ) ;
       y = rad - (rad * cos( yang/57.2958 ));
       if(saddle)  /* make a cool looking saddle rather than ball ??? */
	 z = r* sin( yang/57.2958 );
       else
	 z = r* sin( ang/57.2958 );

       fprintf(fp,"%d %d %d \t #%d\n",x,y,z,count++);
     }
   }

   /* place the poles at the end */
   fprintf(fp,"0 %d 0 \t #%d\n",2*rad,count++);
   fprintf(fp,"0 0 0     \t #%d\n",count++);

   /* Now make the Polys */
   fprintf(fp,"\n");
   fprintf(fp,"#Polys\n");
   fprintf(fp,"\n");

   for( i=0; i<(lng-1); i++){
     fprintf(fp,"%d 3 %d %d %d\n", colour, vertices-1,      i+1,      i );
   }
   fprintf(fp,"%d 3 %d %d %d\n", colour, vertices-1,         0, lng-1 );

   for( j=0; j<(lng*(lat-2) ); j+=lng){
     /* move north along the prime meridian from the south pole */
     for( i=j; i<(lng+j-1); i++){
       /* make the Polys for this latitude */
       fprintf(fp,"%d 4 %d %d %d %d\n",colour, i, i+1, i+lng+1, i+lng );
     }
     /* and join the circle at the end */
     fprintf(fp,"%d 4 %d %d %d %d\n",colour, j, j+lng, j+(2*lng)-1, j+lng-1);
   }

   for( i=vertices - lng - 2; i< (vertices-3) ; i++){
     fprintf(fp,"%d 3 %d %d %d\n", colour, vertices-2,      i,      i+1 );
   }
   /* and join up the ends */
   fprintf(fp,"%d 3 %d %d %d\n", colour, vertices-2, vertices -3 , vertices-lng-2 );
}


