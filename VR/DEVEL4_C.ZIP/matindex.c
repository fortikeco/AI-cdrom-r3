int matchindex (char *buff) {
int retval;

	retval = 9999; 	/* Default value */
        if (match(buff, "loadpath "))    retval = 1;
        if (match(buff, "palette "))     retval = 2;
        if (match(buff, "skycolor "))    retval = 3;
        if (match(buff, "groundcolor ")) retval = 4;
        if (match(buff, "screenclear ")) retval = 5;
        if (match(buff, "ambient "))     retval = 6;
        if (match(buff, "worldscale "))  retval = 7;
        if (match(buff, "light "))       retval = 8;
        if (match(buff, "window "))      retval = 9;
        if (match(buff, "key "))         retval = 10;
        if (match(buff,"control "))      retval = 11;
        if (match(buff,"frame "))        retval = 12;
        if (match(buff,"start "))        retval = 13;
        if (match(buff, "hither "))      retval = 14;
        if (match(buff, "yon "))         retval = 15;
        if (match(buff, "eyespacing "))  retval = 16;
        if (match(buff, "screendist "))  retval = 17;
        if (match(buff, "screenwidth ")) retval = 18;
        if (match(buff, "convergence ")) retval = 19;
        if (match(buff, "figure "))      retval = 20;
        if (match(buff,"object "))       retval = 21;
        if (match(buff,"task "))         retval = 22;
        if (match(buff,"position "))     retval = 23;
        if (match(buff, "rotate "))      retval = 24;
        if (match(buff, "camera "))      retval = 25;
/*
        if (match(buff, "eyespacing "))  retval = 26;
        if (match(buff, "screendist "))  retval = 27;
        if (match(buff, "screenwidth ")) retval = 28;
        if (match(buff, "convergence ")) retval = 29;
        if (match(buff, "figure "))      retval = 30;
*/
        return retval;
}