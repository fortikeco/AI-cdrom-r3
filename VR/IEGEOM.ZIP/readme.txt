IE Geometry Library Documentation
Version 2.1 February 5, 1993
Created by Jerry Isdale, Isdale Engineering

INTRODUCTION

The IE Geometry library is a basic 3D geometry manipulation library
along with some other lower level functions. There are also a number
of utility tools written using the library. All code has compiled
with the Borland C++ V3.0 and makefiles are provided for Borland's
make. I did not create a borland project for the library. All code is
now public domain.

The source to the library code is in .\geomsrc. The source for the
utilities is in .\tools. When compiled, the library installs its .lib
in the directory .\lib and the include files in .\include. Tools are
installed in .\exec.

Version 2.0 is a fairly major update from the original version
released in January 1992. I have added a Doubly Linked List library
and a specialized version of printf for error reporting. I have
changed from using the Digital Arts AOB file format to the PLG file
format used by Rend386. Some functions from the original were deleted
(like splitPoly, etc) and some new ones added (ieg_Interpolate,
ieg_Shrink, ieg_Edge, etc).

This library is intended to be a basis on which to build a 3D
modeling package for use with Rend386 and other systems. It is not a
complete package and there is lots of things that can and hopefully
will be added. I am very interested in hearing about problems,
suggestions, and ways that you have used this library. Please email
me or post messages in the Compuserve GraphDev forum's VR Tech
section.

NOTE: dynamic allocation is used throughout this library. If there is
a failure to allocate memory in one of the allocation routines, there
will be an assertion error. This will terminate your program
immeadiately. Also, if you pass a NULL pointer to a routine that MUST
have a valid pointer, there will also be an assertion error.
Assertions are part of the ANSI standard and are described in the
Borland library reference manual, see assert().

Jerry Isdale
Isdale Engineering
4053 Beethoven St
Los Angeles CA 90066
CIS: 72330,770
