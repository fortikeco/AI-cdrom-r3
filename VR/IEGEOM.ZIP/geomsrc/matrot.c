// FILE: matrot.c
//  matrix rotation functions
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iematrix.h"
  
//-----------------------------------------------
//- void MatRotate33(Mat33 a, VECTOR axis, double theta)
//-   multiply 3 x 3 matrix a by rotation matrix, rotation
//-   about an arbitrary axis by theta radians.
void MatRotate33(Mat33 a, VECTOR axis, double theta)
{
   Mat33 r;
   double  ct,ct1,st;
  
   VNORM( (*(Vector *)axis) );
  
   ct = cos(theta);  st = sin(theta);
   ct1 = 1.0 - ct;
  
   r[0][0] = ct1*axis[XIDX]*axis[XIDX] + ct;
   r[0][1] = ct1*axis[XIDX]*axis[YIDX] + st*axis[ZIDX];
   r[0][2] = ct1*axis[XIDX]*axis[ZIDX] - st*axis[YIDX];
  
   r[1][0] = ct1*axis[YIDX]*axis[XIDX] - st*axis[ZIDX];
   r[1][1] = ct1*axis[YIDX]*axis[YIDX] + ct;
   r[1][2] = ct1*axis[YIDX]*axis[ZIDX] + st*axis[XIDX];
  
   r[2][0] = ct1*axis[ZIDX]*axis[XIDX] + st*axis[YIDX];
   r[2][1] = ct1*axis[ZIDX]*axis[YIDX] - st*axis[XIDX];
   r[2][2] = ct1*axis[ZIDX]*axis[ZIDX] + ct;
  
   MatMpy333(a, r, a);
}
  
//-----------------------------------------------
//- void MatRotate44( Mat44 a, VECTOR axis, double theta)
//-   multiply 4 x 4 matrix a by rotation matrix,
//-   rotation about an arbitrary axis by theta radians
void MatRotate44( Mat44 a, VECTOR axis, double theta)
{
   double ct,ct1,st;
   Mat44 r;
  
   VNORM( (*(Vector *)axis) );
  
   ct = cos(theta);  st = sin(theta);
   ct1 = 1.0 - ct;
  
   r[0][0] = ct1*axis[XIDX]*axis[XIDX] + ct;
   r[0][1] = ct1*axis[XIDX]*axis[YIDX] + st*axis[ZIDX];
   r[0][2] = ct1*axis[XIDX]*axis[ZIDX] - st*axis[YIDX];
  
   r[1][0] = ct1*axis[YIDX]*axis[XIDX] - st*axis[ZIDX];
   r[1][1] = ct1*axis[YIDX]*axis[YIDX] + ct;
   r[1][2] = ct1*axis[YIDX]*axis[ZIDX] + st*axis[XIDX];
  
   r[2][0] = ct1*axis[ZIDX]*axis[XIDX] + st*axis[YIDX];
   r[2][1] = ct1*axis[ZIDX]*axis[YIDX] - st*axis[XIDX];
   r[2][2] = ct1*axis[ZIDX]*axis[ZIDX] + ct;
  
   r[0][3] = r[1][3] = r[2][3] = r[3][0] = r[3][1] = r[3][2] = 0.0;
   r[3][3] = 1.0;
   MatMpy444(a, r, a);
}
  
//-----------------------------------------------
//- void MatPreRotateX(float theta, Mat44 m)
//-   pre-rotate a matrix about X axis theta radians
void MatPreRotateX(float theta, Mat44 m)
{
  /*
   *| 1 0   0   0 | | a b c d |
   *| 0 cosT  sinT  0 | | e f g h |  use nsinT == -sinT;
   *| 0 -sinT cosT  0 | | i j k l |
   *| 0 0   0   1 | | m n o p |
   */
   Mat44 d;
   float cosT, sinT, nsinT;
  
   sinT=sin(theta); cosT= cos(theta); nsinT = -sinT;
  
   d[1][0] = cosT*m[1][0] + sinT*m[2][0];
   d[1][1] = cosT*m[1][1] + sinT*m[2][1];
   d[1][2] = cosT*m[1][2] + sinT*m[2][2];
   d[1][3] = cosT*m[1][3] + sinT*m[2][3];
  
   d[2][0] = nsinT*m[1][0] + cosT*m[2][0];
   d[2][1] = nsinT*m[1][1] + cosT*m[2][1];
   d[2][2] = nsinT*m[1][2] + cosT*m[2][2];
   d[2][3] = nsinT*m[1][3] + cosT*m[2][3];
  
   m[1][0] = d[1][0];
   m[1][1] = d[1][1];
   m[1][2] = d[1][2];
   m[1][3] = d[1][3];
  
   m[2][0] = d[2][0];
   m[2][1] = d[2][1];
   m[2][2] = d[2][2];
   m[2][3] = d[2][3];
}
  
//-----------------------------------------------
//- void MatPreRotateY ( float theta, Mat44 m)
//-   pre-rotate a matrix about Y axis theta radians
void MatPreRotateY ( float theta, Mat44 m)
{
  /*
   *| cosT  0 nsinT 0 | | a m c d |
   *| 0   1 0   0 | | e f g h |  use nsinT == -sinT;
   *| sinT  0 cosT  0 | | i j k l |
   *| 0   0 0   1 | | m n o p |
   */
   Mat44 d;
   float cosT, sinT, nsinT;
   sinT=sin(theta); cosT= cos(theta); nsinT = -sinT;
  
   d[0][0] = cosT*m[0][0] + nsinT*m[2][0];
   d[0][1] = cosT*m[0][1] + nsinT*m[2][1];
   d[0][2] = cosT*m[0][2] + nsinT*m[2][2];
   d[0][3] = cosT*m[0][3] + nsinT*m[2][3];
  
   d[2][0] = sinT*m[0][0] + cosT*m[2][0];
   d[2][1] = sinT*m[0][1] + cosT*m[2][1];
   d[2][2] = sinT*m[0][2] + cosT*m[2][2];
   d[2][3] = sinT*m[0][3] + cosT*m[2][3];
  
   m[0][0] = d[1][0];
   m[0][1] = d[1][1];
   m[0][2] = d[1][2];
   m[0][3] = d[1][3];
  
   m[2][0] = d[2][0];
   m[2][1] = d[2][1];
   m[2][2] = d[2][2];
   m[2][3] = d[2][3];
}
  
//-----------------------------------------------
//- void MatPreRotateZ(float theta, Mat44 m)
//-   pre-rotate a matrix about Z axis theta radians
void MatPreRotateZ(float theta, Mat44 m)
{
  /*
   *| cosT  sinT  0 0 | | a m c d |
   *| nsinT cosT  0 0 | | e f g h |  use nsinT == -sinT;
   *| 0   0   1 0 | | i j k l |
   *| 0   0   0 1 | | m n o p |
   */
   Mat44 d;
   float cosT, sinT, nsinT;
   sinT=sin(theta); cosT= cos(theta); nsinT = -sinT;
  
   d[0][0] = cosT*m[0][0] + sinT*m[1][0];
   d[0][1] = cosT*m[0][1] + sinT*m[1][1];
   d[0][2] = cosT*m[0][2] + sinT*m[1][2];
   d[0][3] = cosT*m[0][3] + sinT*m[1][3];
  
   d[1][0] = nsinT*m[0][0] + cosT*m[1][0];
   d[1][1] = nsinT*m[0][1] + cosT*m[1][1];
   d[1][2] = nsinT*m[0][2] + cosT*m[1][2];
   d[1][3] = nsinT*m[0][3] + cosT*m[1][3];
  
   m[0][0] = d[1][0];
   m[0][1] = d[1][1];
   m[0][2] = d[1][2];
   m[0][3] = d[1][3];
  
   m[1][0] = d[1][0];
   m[1][1] = d[1][1];
   m[1][2] = d[1][2];
   m[1][3] = d[1][3];
}
