// FILE: iegeom.h V2.0
//
// header file for ie geometry modeling library
// defines 3D polygonal structures
// pulls in ie_base.h, llist.h and iematrix.h
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//

#ifndef IEGEOM_DEFINES
#define IEGEOM_DEFINES

#include <math.h>
// llist also pulls in ie_base.h
#include "llist.h"
#include "iematrix.h"

//-----------------------------
// arbitrary maximum on number vertices per polygon
#define MAX_VERTICES 250

//-----------------------------
// Typedefs for Polygonal Geometry, 
// Linked Lists for the shared points method of Polygons

typedef struct ie_point {
	LLNode links; // link list nodes
   int num;   // index in points list of object
   Point loc; // homogeneous location
} IePoint, *pIePoint;

typedef struct ie_vertex {
	LLNode links;  // link list nodes
   pIePoint ppt; // Pointer to point in list
} IeVertex, *pIeVertex;

typedef struct ie_poly {
	LLNode links;
	int flag;	// bit 0 = ON => OPEN (polyline)
	unsigned long color;
	pVector pnorm;
	float d; // fourth value for plane eqn of a polygon
	pLList vtx;
} IePoly, *pIePoly;

typedef struct ie_object {
	LLNode links;
   char *name;
   char *attrib;
   pLList points;
   pLList polys;
} IeObject, *pIeObject;

//-----------------------------
// an array of these is created to note which poly/vertex 
// uses each point in the object. 
// Each point has a simple linklist of these structs
typedef struct point_ref {
	struct point_ref *next; // real simple link list method
	pIePoly ppoly;
	pIeVertex pvtx;
} IePointRef, *pIePointRef;

//-----------------------------
// masks to note polylines and polygons
// default on New is POLY_CLOSED == polygon
#define POLY_CLOSED 0x0001
#define POLY_OPEN 0x0002
#define ieg_PolyFlag(ply,mask) (ply->flag&mask)

//-----------------------------
typedef void _Cdecl (*PolyFunc)(pIePoly poly);
typedef void _Cdecl (*PointFunc)(pIePoint ppt);
extern void ieg_DoPoints(pIeObject op, PointFunc pfunc);
extern void ieg_DoPolys(pIeObject op, PolyFunc pfunc);

//-----------------------------
#define ieg_NumPoints(obj) (LL_Count(obj->points))
#define ieg_NumPolys(obj) (LL_Count(obj->polys))
#define ieg_NumVtx(poly) (LL_Count(poly->vtx))

//-----------------------------

extern pIePoly ieg_NewPoly(void);
extern pIePoint ieg_NewPoint(void);
extern pIeVertex ieg_NewVtx(void);
extern pIeObject ieg_NewObject(void);

// adds to end of point list, keep num current
extern int ieg_AddPoint(pIeObject pobj, pIePoint ppt);
#define ieg_AddPoly(pobj,ppoly) (LL_AddTail(pobj->polys,ppoly))
#define ieg_AddVtx(ppoly,pvtx) (LL_AddTail(ppoly->vtx,pvtx))

#define ieg_RmPoint(obj,iept) (LL_Remove(obj->points,iept))
#define ieg_RmPoly(obj,ieply) (LL_Remove(obj->polys,ieply))
#define ieg_RmVtx(poly,pvtx) (LL_Remove(poly->vtx,pvtx))

extern void ieg_FreePoly( pIePoly dfp);
extern void ieg_FreeObj( pIeObject op);

extern void ieg_RenumObj(pIeObject op);
extern void ieg_PolyNormal(pIePoly poly);
extern void ieg_ObjName(pIeObject op, char *name);
extern void ieg_ObjAttrib(pIeObject op, char *attrib);
//-----------------------------
extern pIeObject ieg_ReadPLG (char *name);
extern pIeObject ieg_fpReadPLG( FILE *stream);
extern int  ieg_WritePLG (pIeObject op, char *name, float scale, int new);
extern void ieg_fpWritePLG (pIeObject op, FILE *fp, float scale);

extern void ieg_DumpObj(pIeObject op);
extern void ieg_DumpPoly( pIePoly dfp);
//-----------------------------
extern float ieg_AbsMax(pIeObject op);
extern float ieg_AbsMin(pIeObject op);
extern void ieg_BBox (pIeObject op, pPoint min, pPoint max);
extern void ieg_CenterRad( pIeObject pobj, pPoint c, float *r );
extern void ieg_CenterRadP( pIePoly poly, pPoint c, float *r );

#define ieg_RevPoly(poly) (LL_Reverse(poly->vtx))
void ieg_ReverseObj( pIeObject op);

extern void ieg_AddObj ( pIeObject dest, pIeObject source);
extern void ieg_CatObj (pIeObject dest, pIeObject source);
extern pIeObject ieg_CopyObj( pIeObject oop);

extern void ieg_ObjMat44( Mat44 matrix, pIeObject op);
extern pIeObject ieg_CopyObjMat44( Mat44 matrix, pIeObject oop);
extern void ieg_ObjXlate(pIeObject op, float x, float y, float z);
extern void ieg_ObjScale(pIeObject op, float x, float y, float z);

extern pIeObject ieg_PlaceObj( pIeObject op1, pIeObject op2);

extern void ieg_ExtrudeF( pIeObject op, pIePoly xf1, pIePoly xf2, int close);
extern void ieg_ExtrudeObj( pIeObject op, int closeObj, int cap1, int cap2);

extern int ieg_WeldPoints( pIeObject op, double distance);
extern int ieg_RmDegenPoly( pIeObject op);

extern int ieg_RmRepeatRef( pIeObject op);
extern int ieg_RmUnusedPoints( pIeObject op);
extern int ieg_MergePoints( pIePoint ppt1, pIePoint ppt2, pIePointRef *array);

extern int ieg_PlanarP(pIePoly poly, float delta);

extern void ieg_ColorPolys(pIeObject op, unsigned long color);
extern void ieg_ColorPolysSeq(pIeObject op, int start);
extern void ieg_ColorPolysRand(pIeObject op, int indexed);

extern void ieg_ShrinkP(pIePoly ppoly, pIeObject dest, float amt);
extern void ieg_EdgeP(pIePoly poly, pIeObject dest, float amt);
extern pIeObject ieg_Shrink(pIeObject src, float amt);
extern pIeObject ieg_Edge(pIeObject src, float amt);

extern pIeObject ieg_Interpolate(pIeObject obj1, pIeObject obj2, float amt);
extern pIeObject ieg_UniqueVtx(pIeObject src);

extern pIePoint *ieg_SortPoints( pIeObject op, int axis);
extern pIePointRef *ieg_GetPointRef( pIeObject op);
extern void ieg_FreePointRefArray( pIePointRef *array, int npts);
extern pIePoint *ieg_MkArray( pIeObject op);

extern pIeObject ieg_Circle( float radius, int npolyt);
extern pIeObject ieg_LineFromTo( Point from_pt, Point to_pt, int npoints);
extern pIeObject ieg_LineDir( Point from_pt, Vector indir, float len, int npoints);
extern pIeObject ieg_Cube( Point min, Point max);
extern pIeObject ieg_Sphere( float radius, int npolyt, int extrude);

#endif // IEGEOM_DEFINES
