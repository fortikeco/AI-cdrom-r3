// FILE: iematrix.h
//  Matrix stuff for 3D & Homogeneous 3D Math
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//

#ifndef IE_MATRIX_DEFINES
#define IE_MATRIX_DEFINES

#include "ie_base.h"

//-----------------------------
// can use these to index into arrays
#define XIDX 0
#define YIDX 1
#define ZIDX 2
#define WIDX 3

typedef float POINT[4];
typedef float VECTOR[3];
typedef float Mat33[3][3];
typedef float Mat44[4][4];

typedef struct {
   float x;
   float y;
   float z;
   float w;
} Point, *pPoint;

typedef struct {
   float x;
   float y;
   float z;
} Vector, *pVector;

typedef struct {
	float _01, _02, _03;
	float _11, _12, _13;
	float _21, _22, _23;
} MatStruct33, *pMatStruct33;

typedef struct {
	float _01, _02, _03, _04;
	float _11, _12, _13, _14;
	float _21, _22, _23, _24;
	float _31, _32, _33, _34;
} MatStruct44, *pMatStruct44;

//-----------------------------
// Vector Macros: one for structs, one for struct pointers
// Vector dot product
#define VDOT(a, b)  (a.x*b.x + a.y*b.y + a.z*b.z)
#define VDOTP(a, b) ((a)->x * (b)->x + (a)->y * (b)->y + (a)->z*(b)->z)

// Vector normalization  macro
#define VNORM(a) { \
  float	temp;    \
  temp = VDOT(a,a);\
  if (temp > 0)   \
  {               \
    temp = 1.0/sqrt(temp);\
	 a.x *= temp;	\
	 a.y *= temp;	\
	 a.z *= temp;	\
  }               \
}

#define VNORMP(a) { \
  float	temp;    \
  temp = DOTP(a,a);\
  if (temp > 0)   \
  {               \
    temp = 1.0/sqrt(temp);\
	 a->x *= temp;	\
	 a->y *= temp;	\
	 a->z *= temp;	\
  }               \
}

// Vector cross product c = a x b
#define CROSS(a, b, c) {   \
  c.x = a.y*b.z - a.z*b.y;	\
  c.y = a.z*b.x - a.x*b.z;	\
  c.z = a.x*b.y - a.y*b.x;	\
}

#define CROSSP(a, b, c) {   \
  c->x = a->y*b->z - a->z*b->y;	\
  c->y = a->z*b->x - a->x*b->z;	\
  c->z = a->x*b->y - a->y*b->x;	\
}

// Vector subtraction
#define VSUB(a, b, c) { \
  c.x = a.x - b.x; \
  c.y = a.y - b.y; \
  c.z = a.z - b.z; \
}

#define VSUBP(a, b, c) { \
  (c)->x = (a)->x - (b)->x; \
  (c)->y = (a)->y - (b)->y; \
  (c)->z = (a)->z - (b)->z; }

// Vector addition
#define	VADD(a, b, c) {\
  c.x = a.x + b.x;		\
  c.y = a.y + b.y;		\
  c.z = a.z + b.z;		\
}

#define	VADDP(a, b, c) {\
  (c)->x = (a)->x + (b)->x; \
  (c)->y = (a)->y + (b)->y; \
  (c)->z = (a)->z + (b)->z; }

//-----------------------------

extern void MatAdd33( Mat33 a,Mat33 b,Mat33 c);
extern void MatCvt3344(Mat33 a,Mat44 b);
extern void MatEPrint33(Mat33 a);
extern void MatEPrint44( Mat44 a);
extern void MatIdentity33(Mat33 a);
extern void MatIdentity44(Mat44 a);
extern void MatMpy133(VECTOR a, Mat33 b, VECTOR c);
extern void MatMpy144( POINT a, Mat44 b, POINT c);
extern void MatMpy333(Mat33 a, Mat33 b, Mat33 c);
extern void MatMpy444(Mat44 a, Mat44 b, Mat44 c);
extern void MatPreRotateX ( float theta, Mat44 m);
extern void MatPreRotateY ( float theta, Mat44 m);
extern void MatPreRotateZ ( float theta, Mat44 m);
extern void MatPrint33( FILE *file, Mat33 a);
extern void MatPrint44( FILE *fp, Mat44 a);
extern void MatProject33(VECTOR v, Mat33 m);
extern void MatRotate33(Mat33 a, VECTOR axis, double theta);
extern void MatRotate44( Mat44 a, VECTOR axis, double theta);
extern void MatScale33(Mat33 a, double sx, double sy, double sz);
extern void MatScale44( Mat44 a, double sx, double sy, double sz, double sw);
extern void MatStretch44( Mat44 n, VECTOR v, float a);
extern void MatTranslate44(Mat44 a, double dx, double dy, double dz);

extern double ieg_Distance( Point pt1, Point pt2);

extern Vector Xaxis, Yaxis, Zaxis;

#endif //IE_MATRIX_DEFINES

