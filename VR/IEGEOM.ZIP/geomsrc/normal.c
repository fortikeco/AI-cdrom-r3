// FILE: normal.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- void ieg_PolyNormal(pIePoly poly)
//-   calculate normal & plane constant for given polygon
//-   replace previous norm value, allocate norm if needed
//-   use with ieg_DoPoly() to get all polys in an object
void ieg_PolyNormal(pIePoly poly)
{
   pIeVertex pvtx;
   double x, y, z, x1, y1, z1;
   Vector norm;
   Point ref_pt;
   float len;
  
   assert(poly != NULL);
  
   norm.x = norm.y = norm.z = 0.0;
   ref_pt.x = ref_pt.y = ref_pt.z = ref_pt.w = 0.0;
  
  // Compute polygon normal using Newell Method
  // from GraphGems III, also plane eqn constant from same book
  // use interm variables to avoid LOTS of pointer refs
   pvtx = LL_First(poly->vtx);
   x = pvtx->ppt->loc.x;
   y = pvtx->ppt->loc.y;
   z = pvtx->ppt->loc.z;
   for (pvtx=LL_Next(pvtx); pvtx; pvtx=LL_Next(pvtx))
   {
      ref_pt.x += x;  ref_pt.y += y;  ref_pt.z += z;
      x1 = pvtx->ppt->loc.x;
      y1 = pvtx->ppt->loc.y;
      z1 = pvtx->ppt->loc.z;
      norm.x += (z + z1)*(y1 - y);
      norm.y += (x + x1)*(z1 - z);
      norm.z += (y + y1)*(x1 - x);
      x = x1; y = y1; z = z1;
   }
  
   if (ieg_PolyFlag(poly,POLY_CLOSED))
   {
      ref_pt.x += x;  ref_pt.y += y;  ref_pt.z += z;
      pvtx = LL_First(poly->vtx);
      x1 = pvtx->ppt->loc.x;
      y1 = pvtx->ppt->loc.y;
      z1 = pvtx->ppt->loc.z;
      norm.x += (z + z1)*(y1 - y);
      norm.y += (x + x1)*(z1 - z);
      norm.z += (y + y1)*(x1 - x);
   }
  
  // create poly normal vector if needed
   if (!poly->pnorm)
   {
      poly->pnorm = (pVector) calloc(1,sizeof(Vector));
      assert (poly->pnorm != NULL);
   }
  
   len = sqrt(VDOT(norm,norm));
  
   if (len != 0.0)
   {
      poly->pnorm->x = norm.x/len;
      poly->pnorm->y = norm.y/len;
      poly->pnorm->z = norm.z/len;
      len *= ieg_NumVtx(poly);
      poly->d = -VDOT(ref_pt,norm)/len;
   } else
   {
      eprintf("Error Zero Length Normal!\n");
      free(poly->pnorm);
      poly->pnorm = NULL;
   }
}
  
