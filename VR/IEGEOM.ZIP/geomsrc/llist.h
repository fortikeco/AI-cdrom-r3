// FILE: llist.h V2.0
//
//	Implements an encapsulated data structure and 
// methods for double link list (null terminated).
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//

#ifndef LINKLIST_DEFINES
#define LINKLIST_DEFINES

#include "ie_base.h"

typedef struct LLNode {
	struct LLNode *ll_prev;
	struct LLNode *ll_next;
} LLNode, *pLLNode;

typedef struct LList {
	pLLNode ll_first;
	pLLNode ll_last;
	int ll_count;
} LList, *pLList;

// Functions defined as Macros: BE CAREFUL
#define LL_First(lp) ((void*)((pLList)(lp))->ll_first)
#define LL_Last(lp) ((void*)((pLList)(lp))->ll_last)
#define LL_Prev(pln) ((void*)((pLLNode)(pln))->ll_prev)
#define LL_Next(pln) ((void*)((pLLNode)(pln))->ll_next)

#define LL_HasNext(pln) ((!pln || !(pLList)pln->ll_next)? FALSE : TRUE))
#define LL_HasPrev(pln) ((!pln || !(pLList)pln->ll_prev)? FALSE : TRUE))

#define LL_Count(llp) (llp->ll_count)
extern int LL_ReCount(pLList llp);

// These defines eliminate the need for casting the Node pointer
// to avoid warning messages
extern pLList LL_NewList(void);
extern void LL_InitList( pLList llp);

#define LL_InitNode(lnp) (_ll_initnode((pLLNode) lnp))
#define LL_AddHead(llp, lnp) (_ll_addhead( (pLList) llp, (pLLNode) lnp))
#define LL_AddTail(llp, lnp) (_ll_addtail( (pLList)llp, (pLLNode)lnp))
#define LL_AddAfter(llp,lnp_new,lnp_old) (_ll_addafter((pLList)llp,(pLLNode lnp_new),(pLLNode)lnp_old))
#define LL_AddBefore(llp,new,old) (_ll_addbefore(llp,(pLLNode)new,(pLLNode)old))
#define LL_Remove(llp,lnp) (_ll_remove(llp,(pLLNode)lnp))

// These are the Real Functions
extern int _ll_initnode ( pLLNode lnp);
extern int _ll_addhead ( pLList llp, pLLNode lnp);
extern int _ll_addtail ( pLList llp, pLLNode lnp);
extern int _ll_addbefore ( pLList llp, pLLNode lnp_new, pLLNode lnp_old);
extern int _ll_addafter ( pLList llp, pLLNode lnp_new, pLLNode lnp_old);
extern void _ll_remove ( pLList llp, pLLNode lnp);

extern void LL_Destroy ( pLList lp);
extern void *LL_GetNth ( pLList llp, int num);

extern int LL_IsMember(pLList lp, pLLNode np);
extern int LL_ConCat(pLList dest, pLList source);
extern void LL_Reverse(pLList plist);

#endif // LINKLIST_DEFINES
