// FILE: remove.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- int ieg_RmRepeatRef( pIeObject obj)
//-   remove repeated reference to same vertext in polygon
//-   repeats may be adjecent or elsewhere in polygon
//-   returns number of vertices removed
int ieg_RmRepeatRef( pIeObject obj)
{
   int count;
   pIeVertex dvp, lvp;
   pIePoly dfp;
  
   assert(obj != NULL);
  
   count = 0;
   for (dfp = LL_First(obj->polys); dfp; dfp = LL_Next(dfp))
   {
      lvp = LL_First(dfp->vtx);
      dvp = LL_Next(lvp);
    // check for vtx that point to same place as this one
      while (dvp)
      {
         if (dvp->ppt == lvp->ppt)
         {
            ieg_RmVtx( dfp, dvp);
            dvp = LL_Next(lvp);
            count++;
            continue;
         }
         lvp = dvp;
         dvp = LL_Next(dvp);
      }
   }
   return (count);
}
  
//-----------------------------------------------
//- int ieg_RmDegenPoly( pIeObject obj)
//-   removes polygons that have less than 3 vertices
//-   returns number of polygons removed
int ieg_RmDegenPoly( pIeObject obj)
{
   pIePoly dfp, nfp;
   pIeVertex dvp;
   int nvtx, count, fnum;
  
   count = 0; fnum = 1;
   for (dfp = LL_First(obj->polys); dfp; dfp = nfp, fnum++)
   {
      nfp = LL_Next(dfp);
      if (LL_Count(dfp->vtx) < 3)
      {
         count++;
         ieg_RmPoly( obj, dfp);
      }
   }
   return(count);
}
