// FILE: mkarray.c
// routine to make array of pIePoints from IeObject
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- pIePoint *ieg_MkArray( pIeObject op)
//-   create an array of pointers to points in object
//-   useful for accessing points by reference number
pIePoint *ieg_MkArray( pIeObject op)
{
   int n, i;
   pIePoint dpp;
   pIePoint *parray;
  
   n = ieg_NumPoints(op);
   parray = (pIePoint *) calloc( (n+1),sizeof(pIePoint));
   assert(parray != NULL);
  
   parray[0] = NULL;
   for (i=1, dpp=LL_First(op->points); i <= n; i++, dpp=LL_Next(dpp))
      parray[i] = dpp;
  
   return (parray);
}
