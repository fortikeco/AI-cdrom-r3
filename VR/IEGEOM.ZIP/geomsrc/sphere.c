// FILE: sphere.c
// creates a sphere at origin, given radius, number facets, extrude flag
// without extrude flag, object is a set of circles
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- pIeObject ieg_Sphere( float radius, int nfacet, int extrude)
//-   creates a sphere at origin, given radius, number facets
//-   internally creates nfacet half-circles with nfacets
//-   the extrudes between successive half-circles.
//-   without extrude flag, object is a set of half-circles
pIeObject ieg_Sphere( float radius, int nfacet, int extrude)
{
   pIeObject xop;
   pIePoint npole, spole, dpp;
   pIeVertex dvp;
   pIePoly ppoly, xp1, xp2;
   pLList xpoly;
   double theta, dtheta, cosTheta, sinTheta;
   double phi, dphi, sinPhi;
   int i, j;
  
//eprintf("Sphere: r= %f n=%d x=%d\n", radius, nfacet, extrude);
  
   dtheta = 2.0*PI/nfacet;
   dphi = PI/nfacet;
  
   xop = ieg_NewObject();
   xop->name = strdup("sphere");
  
  // create single north & south pole points
  // which are used by each cross section
   npole = ieg_NewPoint();
   npole->loc.z = radius;
   ieg_AddPoint( xop, npole);
   spole = ieg_NewPoint();
   spole->loc.z = -radius;
   ieg_AddPoint( xop, spole);
  
  // create cross sections around theta direction
   for (i = 0, theta= 0; i < nfacet; i++, theta += dtheta )
   {
//eprintf("face: %d theta: %lf\n", i, RADTODEG(theta));
      ppoly = ieg_NewPoly();
      dvp = ieg_NewVtx();
      dvp->ppt = spole;
      ieg_AddVtx( ppoly, dvp);
      cosTheta = cos (theta);
      sinTheta = sin (theta);
    // create points on cross section
      for (j = 1, phi = PI - dphi; j < nfacet; j++, phi -= dphi)
      {
         dpp = ieg_NewPoint();
         sinPhi = sin(phi);
         dpp->loc.x = radius * cosTheta * sinPhi;
         dpp->loc.y = radius * sinTheta * sinPhi;
         dpp->loc.z = radius * cos(phi);
         ieg_AddPoint( xop, dpp);
         dvp = ieg_NewVtx();
         dvp->ppt = dpp;
         ieg_AddVtx( ppoly, dvp);
      }
      dvp = ieg_NewVtx();
      dvp->ppt = npole;
      ieg_AddVtx( ppoly, dvp);
      ieg_AddPoly( xop, ppoly);
   }
  
  //eprintf("Extrude Sphere\n");
   if (extrude)
   {
      xpoly = xop->polys;
      xop->polys = LL_NewList();
      xp1 = LL_First(xpoly);
      xp2 = LL_Next(xp1);
      while (xp2)
      {
      //eprintf("Extrude face pair %d: %p %p\n", i, xp1, xp2);
         ieg_ExtrudeF(xop, xp1, xp2, FALSE);
         xp1 = xp2;
         xp2 = LL_Next(xp2);
      }
    // close from last to first
      xp2 = LL_First(xpoly);
      xp1 = LL_Last(xpoly);
      ieg_ExtrudeF(xop, xp1, xp2, FALSE);
  
    //eprintf("Remove repeat\n");
      ieg_RmRepeatRef( xop);
   }
  
   return (xop);
}
  
