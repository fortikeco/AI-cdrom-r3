// FILE: pointref.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
#define DEBUG
  
//-----------------------------------------------
#ifdef DEBUG
void ieg_DumpPointRef( pIeObject op, pIePointRef *refarray)
{
   int i;
   pIePointRef ptref;
  
   eprintf("\nPoint References:\n");
   for (i=0;i <= ieg_NumPoints(op); i++)
   {
      eprintf("Point %d: ",i);
      for (ptref = refarray[i]; ptref != NULL; ptref = ptref->next)
      {
         eprintf("\t%p=(f%p,v%p,n%p,#%d)\n",ptref,ptref->ppoly,
            ptref->pvtx,ptref->next,ptref->pvtx->ppt->num);
      }
   }
}
#endif
  
//-----------------------------------------------
//- pIePointRef *ieg_GetPointRef( pIeObject op)
//-   create an array of PointRef's for each point in object
//-   if a point is used by a polygon, a PointRef is created
//-   and added to the list at the point's index in this array
//-   if the array index is NULL, the point is not used
pIePointRef *ieg_GetPointRef( pIeObject op)
{
   pIePointRef *array, ptref;
   pIeVertex dvp;
   pIePoly dfp;
   int i,j;
  
  //eprintf("IeGetPointRef: entered\n");
   ieg_RenumObj( op);
  
   array = (pIePointRef *)calloc(ieg_NumPoints(op)+1, sizeof(pIePointRef));
   assert (array != NULL);
  
   for (j=1,dfp = LL_First(op->polys); dfp; dfp = LL_Next(dfp),j++)
   {
      for (dvp = LL_First(dfp->vtx); dvp; dvp = LL_Next(dvp))
      {
         ptref = (pIePointRef) malloc(sizeof(IePointRef));
         assert(ptref != NULL);
         ptref->ppoly = dfp;
         ptref->pvtx = dvp;
         ptref->next = NULL;
         i = dvp->ppt->num;
         ptref->next = array[i];
         array[i] = ptref;
      }
   }
  
   return(array);
}
  
//-----------------------------------------------
//- void ieg_FreePointRefArray( pIePointRef *array, int npts)
//-   releases a point reference array of the given number of points
void ieg_FreePointRefArray( pIePointRef *array, int npts)
{
   int i, j;
   pIePointRef ptref, nref;
  
   for (i=npts; i > 0; i--)
   {
      for(j=0,ptref=array[i];ptref!=NULL;ptref=nref,j++)
      {
         nref = ptref->next;
         free(ptref);
      }
   }
  
   free(array);
}
  
//-----------------------------------------------
//- int ieg_MergePoints( pIePoint ppt1, pIePoint ppt2, pIePointRef *array)
//-   routine to merge points, used by consolidation functions
//-   locates each reference to each point and in the PointRef array
//-   and maps them all to the lowest of ppt1->num & ppt2->num
//-   thus keeping the first point in a object's point list
int ieg_MergePoints( pIePoint ppt1, pIePoint ppt2, pIePointRef *array)
{
   pIePoint toPoint;
   pIePointRef ptref;
   int k,l,t;
   int first = FALSE;
  
   k = ppt1->num;
   l = ppt2->num;
  
  //eprintf(" merge pt %d(%d) and %d(%d) \n",k,ppt1,l,ppt2);
  //eprintf(" array[%d] = %d, array[%d]= %d\n",k,array[k],l,array[l]);
  
   if (k < l)
   {
      toPoint = ppt1;
   } else
   {
      t = l;
      l = k;
      k = t;
      toPoint = ppt2;
      first = TRUE;
   }
  
  // changing the vertex->ppt ref as we search
   for (ptref=array[l]; ptref->next; ptref=ptref->next)
   {
      ptref->pvtx->ppt = toPoint;
    //eprintf("\tUsed in vertex %p\n", ptref->pvtx);
   }
  
  // fix the last node
   ptref->pvtx->ppt = toPoint;
  
  // move list segment
   ptref->next = array[k];
   array[k] = array[l];
   array[l] = (IePointRef *)0;
  
   //eprintf(" merge into point %d (%p), return %d\n", k, toPoint, first);
  
   return(first);
}
  
//-----------------------------------------------
//- int ieg_RmUnusedPoints( pIeObject obj)
//-   removes points that are not referenced by any polygon vertex
//-   returns number of points removed
int ieg_RmUnusedPoints( pIeObject obj)
{
   pIePointRef *array;
   pIePoint dpp, npp;
   int i, j;
  
  // get array of point usage
   array = ieg_GetPointRef(obj);
  
   for (i = 1,j= 0, dpp = LL_First(obj->points); dpp; dpp = npp, i++)
   {
      npp = LL_Next(dpp);
      if (array[i] == NULL)
      {
         ieg_RmPoint(obj,dpp);
         free(dpp);
         j++;
      }
   }
   ieg_FreePointRefArray( array, ieg_NumPoints(obj));
   ieg_RenumObj(obj);
   return(j);
}
  
