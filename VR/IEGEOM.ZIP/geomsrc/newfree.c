// FILE: newfree.c
// all ieg_New functions do an assert(new_pointer != NULL)
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include "assert.h"
#include "iegeom.h"
  
#define DEFAULT_COLOR 0
  
//-----------------------------------------------
//- pIePoint ieg_NewPoint(void)
//-   create a new iePoint structure & initializes it
//-   causes an assertion error if allocation fails
pIePoint ieg_NewPoint(void)
{
   pIePoint ppt;
  
   ppt = (pIePoint) calloc(1,sizeof(IePoint));
   assert(ppt != NULL);
  // calloc insures loc.x,y,z == 0 && num == 0
   ppt->loc.w = 1.0;
  
   return (ppt);
}
  
//-----------------------------------------------
//- pIeVertex ieg_NewVtx(void)
//-   create a new ieVertex structure & initializes it
//-   causes an assertion error if allocation fails
pIeVertex ieg_NewVtx(void)
{
   pIeVertex pvtx;
  
   pvtx = (pIeVertex) calloc(1,sizeof(IeVertex));
   assert(pvtx != NULL);
  
   pvtx->ppt = NULL;
  
   return (pvtx);
}
  
//-----------------------------------------------
//- pIePoly ieg_NewPoly(void)
//-   create a new iePoly structure & initializes it
//-   new polygon is CLOSED,
//-   list header for vertices is allocated
//-   causes an assertion error if allocation fails
pIePoly ieg_NewPoly(void)
{
   pIePoly poly;
  
   poly = (pIePoly) calloc(1,sizeof(IePoly));
   assert(poly != NULL);
  
   poly->flag = POLY_CLOSED;
   poly->color = DEFAULT_COLOR;
   poly->vtx = LL_NewList();
   assert(poly->vtx != NULL);
  
   return (poly);
}
  
//-----------------------------------------------
//- pIeObject ieg_NewObject(void)
//-   create a new ieObject structure & initializes it
//-   list headers for points and polys are allocated
//-   causes an assertion error if allocation fails
pIeObject ieg_NewObject(void)
{
   pIeObject op;
  
   op = (pIeObject) calloc(1,sizeof(IeObject));
   assert(op != NULL);
  
   op->points = LL_NewList();
   assert(op->points != NULL);
  
   op->polys = LL_NewList();
   assert(op->polys != NULL);
  
   return (op);
}
  
//-----------------------------------------------
//- void ieg_FreePoly( pIePoly poly)
//-   free's all vertices for polygon, and vtx list header
//-   free's polygon's normal if there is one
//-   free's polygon, client should NULL pointer
void ieg_FreePoly( pIePoly poly)
{
   pIeVertex pvtx, nvp;
  
   if (poly== NULL)
      return;
  
   LL_Destroy(poly->vtx);
   free (poly->vtx);
   poly->vtx = NULL;
  
   if (poly->pnorm)
      free(poly->pnorm);
   poly->pnorm = NULL;
   free (poly);
}
  
//-----------------------------------------------
//- void ieg_FreeObj( pIeObject op)
//-   free's all points and polygons in object & list headers
//-   free's name & attrib strings if exist
void ieg_FreeObj( pIeObject op)
{
   pIePoint ppt, npt;
   pIePoly poly, npoly;
  
   if (op == NULL)
      return;
  
   if (op->name)
      free(op->name);
  
   if (op->attrib)
      free(op->attrib);
  
   LL_Destroy(op->points);
   free(op->points);
  
  // we could do a LL_Remove for each poly
  // but since we are destroying the list, this is faster
   for (poly = LL_First(op->polys); poly; poly = npoly)
   {
      npoly = LL_Next(poly);
      ieg_FreePoly (poly);
   }
   free(op->polys);
  
   free (op);
}
  
//-----------------------------------------------
//- int ieg_AddPoint(pIeObject pobj, pIePoint ppt)
//-   adds point to object
//-   sets point num so it can be used in various arrays
int ieg_AddPoint(pIeObject pobj, pIePoint ppt)
{
   if (!LL_AddTail(pobj->points,ppt))
      return (0);
   ppt->num = ieg_NumPoints(pobj);
   return (ppt->num);
}
  
//-----------------------------------------------
//- void ieg_ObjName(pIeObject op, char *name)
//-   duplicates string and sets object name to point to duplicate
void ieg_ObjName(pIeObject op, char *name)
{
   assert(op);
   assert(name);
   if (op->name)
      free(op->name);
   op->name = strdup(name);
}
  
//-----------------------------------------------
//- void ieg_ObjAttrib(pIeObject op, char *attrib)
//-   duplicates string and sets object attrib to point to duplicate
void ieg_ObjAttrib(pIeObject op, char *attrib)
{
   assert(op);
   assert(attrib);
   if (op->attrib)
      free(op->attrib);
   op->attrib = strdup(attrib);
}
