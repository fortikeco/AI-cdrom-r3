// FILE: bbox.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include "iegeom.h"
#include "assert.h"
  
//-----------------------------------------------
//- void ieg_BBox (pIeObject op, pPoint min, pPoint max)
//-   calculates the bounding box of the given object
//-   returns min and max points in the supplied pointers
void ieg_BBox (pIeObject op, pPoint pmin, pPoint pmax)
{
   pIePoint ppt;
   Point min, max;
  
  // null object pointer or zero points
   if (op == NULL || ieg_NumPoints(op) == 0)
   {
      max.x = max.y = max.z = 0;
      min.x = min.y = min.z = 0;
      return;
   }
  
   max.x = max.y = max.z = -99999999.99;
   min.x = min.y = min.z =  99999999.99;
   for (ppt = (pIePoint)LL_First(op->points); ppt; ppt = LL_Next(ppt))
   {
      if (ppt->loc.x > max.x) max.x = ppt->loc.x;
      if (ppt->loc.y > max.y) max.y = ppt->loc.y;
      if (ppt->loc.z > max.z) max.z = ppt->loc.z;
      if (ppt->loc.x < min.x) min.x = ppt->loc.x;
      if (ppt->loc.y < min.y) min.y = ppt->loc.y;
      if (ppt->loc.z < min.z) min.z = ppt->loc.z;
   }
  
   if (pmin)
      *pmin = min;
   if (pmax)
      *pmax = max;
}
  
//-----------------------------------------------
//- float ieg_AbsMin(pIeObject op)
//-   returns the smallest absolute value number greater than zero
//-   for any of the point axis. Useful? for PLG scale generation
float ieg_AbsMin(pIeObject op)
{
   pIePoint ppt;
   float min = 99999999.99;
  
   for (ppt = (pIePoint)LL_First(op->points); ppt; ppt = LL_Next(ppt))
   {
      if (ppt->loc.x != 0.0 && fabs(ppt->loc.x) < min)
         min = fabs(ppt->loc.x);
      if (ppt->loc.y != 0.0 && fabs(ppt->loc.y) < min)
         min = fabs(ppt->loc.y);
      if (ppt->loc.z != 0.0 && fabs(ppt->loc.z) < min)
         min = fabs(ppt->loc.z);
   }
   return(min);
}
  
//-----------------------------------------------
//- float ieg_AbsMax(pIeObject op)
//-   returns the smallest absolute value number greater than zero
//-   for any of the point axis. Useful? for PLG scale generation
float ieg_AbsMax(pIeObject op)
{
   pIePoint ppt;
   float max = 0.0;
  
   for (ppt = (pIePoint)LL_First(op->points); ppt; ppt = LL_Next(ppt))
   {
      if (fabs(ppt->loc.x) > max)
         max = fabs(ppt->loc.x);
      if (fabs(ppt->loc.y) > max)
         max = fabs(ppt->loc.y);
      if (fabs(ppt->loc.z) > max)
         max = fabs(ppt->loc.z);
   }
   return(max);
}
