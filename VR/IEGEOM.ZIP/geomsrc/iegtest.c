// FILE: iegtest.c
//
// Test program for Ie Geom Library
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <time.h>
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
#define TESTFILE "test.plg"
  
char *pathname;
char progname[MAXPATH];
char tmpname[MAXPATH];
  
#define UNIT 100.0
#define NUM_FACETS 10
  
int vFlag = TRUE;
int lFlag = TRUE;
int cFlag = TRUE;
int dump = FALSE;
  
extern void info(pIeObject op);
extern void doDir(char *infile);
extern void dofile(char *infile);
  
//-----------------------------------------------
void Usage(void)
{
   eprintf("%s\n",pathname);
   eprintf("\
   Tests IE Geom by creating Sphere.aob\n\
   then reading it & giving an Info\n");
   exit(0);
}
  
//-----------------------------------------------
void testExtrude(void);
void testExtrude(void)
{
   Point from, to;
   pIeObject oop = NULL;
   pIeObject line = NULL;
   pIeObject circle = NULL;
  
   eprintf("\n-----------------------------\n");
   eprintf("Extrusion Test\n");
   eprintf("-----------------------------\n");
   from.x = from.y = from.z = 0.0;
   to.x = to.y = to.z = 5000.0;
  
   eprintf("make Line:\n");
   line = ieg_LineFromTo(from,to,10);
   info(line);
   eprintf("\nmake Circle:\n");
   circle = ieg_Circle(100.0, 10);
   info(circle);
  
   eprintf("\nmake Place Object:\n");
   oop = ieg_PlaceObj(line,circle);
   ieg_WritePLG ( oop, "xsection.plg", 1.0, TRUE);
   dofile("xsection.plg");
  
   eprintf("Extrude Object\n");
   ieg_ExtrudeObj(oop,FALSE, TRUE, TRUE);
   ieg_ColorPolysRand(oop, TRUE);
   ieg_WritePLG ( oop, "tube.plg", 1.0, TRUE);
}
  
void doSphere(void);
void doSphere(void)
{
   pIeObject oop = NULL;
   int nfacet = NUM_FACETS;
   float radius = UNIT;
   int extrude = TRUE;
  
  // malloc errors taken care of by assert's in ieg_New*()
   oop = ieg_Sphere( radius, nfacet, extrude);
   ieg_ColorPolysRand(oop, TRUE);
  
   eprintf("Created Sphere object\n");
  
  //info(oop);
  
   ieg_WritePLG ( oop, "sphere.plg", 1.0, TRUE);
   ieg_FreeObj(oop);
   dofile("sphere.plg");
}
  
void doCube(void);
void doCube(void)
{
   pIeObject oop = NULL;
  
   Point min = {0,0,0};
   Point max = {UNIT,UNIT,UNIT};
   oop = ieg_Cube(min, max);
   ieg_ColorPolysRand(oop, TRUE);
  
   ieg_WritePLG ( oop, "cube.plg", 1.0, TRUE);
   ieg_FreeObj(oop);
   dofile("cube.plg");
}
  
//-----------------------------------------------
void main( int argc, char *argv[])
{
   char drive[MAXDRIVE];
   char path[MAXPATH];
   char filename[MAXPATH];
  
   randomize();
  
   pathname = *argv++;
   strlwr(pathname);
   fnsplit(pathname,tmpname,tmpname, progname, tmpname);
  
  //eopenf("iegtest.err");
   eopenf(NULL);
  
   argc--;
   if (argc > 0)
      Usage();
  
   doSphere();
   doCube();
   testExtrude();
  
   eprintf("\n\nEnd IEGEOM Test\n");
}
  
//-----------------------------------------------
void dofile(char *infile)
{
   pIeObject iop = NULL;
   unsigned long memleft;
   char tmpname[10];
  
   strlwr(infile);
  
   eprintf(  "\nReading from %s\n", infile);
   fnsplit(infile,NULL, NULL, NULL, tmpname);
  
   iop = ieg_ReadPLG(infile);
   if (!iop)
   {
      eprintf( "Error Reading input file %s\n", infile);
      return;
   }
  
  //ieg_fpWritePLG(iop, stdout, 1.0);
  
   eprintf("Add Polygon Normals\n");
   ieg_DoPolys(iop, ieg_PolyNormal);
  
   info(iop);
  
   if (dump)
      ieg_DumpObj(iop);
   ieg_FreeObj(iop);
}
  
//-----------------------------------------------
void info(pIeObject op)
{
   int memPerPoint;
   int numVertex, memPerVertex;
   int memPerPoly;
   int i, j, k;
   pIePoint ppt;
   pIePoly poly;
   pIeVertex pvtx, nvtx;
   Point max, min, avg;
   double dist, d;
   double total = 0.0;
   Point c;
   float r;
  
   eprintf("Object %s contains %d points and %d faces\n", op->name,
   ieg_NumPoints(op), ieg_NumPolys(op));
  
  // use BBox to determine bounding box
   ieg_BBox(op, &min, &max);
   eprintf("Bounding Box of object:\n");
   eprintf("\tMin of X,Y,Z= \t%6g\t%6g\t%6g\n", min.x, min.y,min.z);
   eprintf("\tMax of X,Y,Z= \t%6g\t%6g\t%6g\n", max.x, max.y,max.z);
  
  // Determine Max/Min points
   eprintf("Max/Min/Avg Points\n");
   max.x = max.y = max.z = -99999999.99;
   min.x = min.y = min.z =  99999999.99;
   for (ppt = LL_First(op->points); ppt; ppt = LL_Next(ppt))
   {
      if (ppt->loc.x > max.x) max.x = ppt->loc.x;
      if (ppt->loc.y > max.y) max.y = ppt->loc.y;
      if (ppt->loc.z > max.z) max.z = ppt->loc.z;
      if (ppt->loc.x < min.x) min.x = ppt->loc.x;
      if (ppt->loc.y < min.y) min.y = ppt->loc.y;
      if (ppt->loc.z < min.z) min.z = ppt->loc.z;
      avg.x += ppt->loc.x;
      avg.y += ppt->loc.y;
      avg.z += ppt->loc.z;
   }
   avg.x /= ieg_NumPoints(op);
   avg.y /= ieg_NumPoints(op);
   avg.z /= ieg_NumPoints(op);
  
   eprintf("\tMin of X,Y,Z= \t%6g\t%6g\t%6g\n", min.x, min.y,min.z);
   eprintf("\tMax of X,Y,Z= \t%6g\t%6g\t%6g\n", max.x, max.y,max.z);
   eprintf("\tAvg of X,Y,Z= \t%6g\t%6g\t%6g\n", avg.x, avg.y,avg.z);
  
  // Bounding Sphere
   ieg_CenterRad(op, &c, &r);
   eprintf("Bounding sphere radius: %6g center: %6g %6g %6g\n",
   r, c.x, c.y, c.z);
  
   if (vFlag)
      eprintf( "\nNum Vertices for each face:\n\t");
   numVertex = 0;
  
  // i counts polys, j counts vtx, k keeps lines short
   for (i=1,k=0,poly=LL_First(op->polys); poly; poly=LL_Next(poly),i++,k++)
   {
      j = ieg_NumVtx(poly);
      if (vFlag)
      {
         eprintf("F%d = %dv ",i,j);
         if (k == 5) {k=0;eprintf("\n\t");}
      }
      numVertex +=j;
   }
  
   if (vFlag)
      eprintf("\n");
   eprintf("Object has total of %d vertices\n", numVertex);
  
  // calculate length of each polygon perimeter
   if (lFlag)
   {
      for (i=1, poly=LL_First(op->polys);poly; poly=LL_Next(poly), i++)
      {
         if (ieg_NumVtx(poly) > 1)
         {
            eprintf("\tPoly %d:\n", i);
            dist = 0;
            pvtx=LL_First(poly->vtx);
            nvtx=LL_Next(pvtx);
            for (j=1; nvtx; j++)
            {
               d = ieg_Distance( pvtx->ppt->loc, nvtx->ppt->loc);
               dist += d;
               eprintf("\t   edge: %d\tlenEdge: %-10lg\tlenPoly: %-1lg\n",
               j, d, dist);
               pvtx = nvtx;
               nvtx=LL_Next(nvtx);
            }
            if (ieg_PolyFlag(poly,POLY_CLOSED))
            {
               nvtx = LL_First(poly->vtx);
               d = ieg_Distance( pvtx->ppt->loc, nvtx->ppt->loc);
               dist += d;
               eprintf("\t c-edge: %d\tlenEdge: %-10lg\tTotal lenPoly: %-1lg\n",
               j, d, dist);
               total += dist;
            }
         }
      }
      eprintf("\tTotal edge length for object %lg\n", total);
   }
  
   if (cFlag)
   {
      for (i=1, poly=LL_First(op->polys); poly; poly = LL_Next(poly),i++)
      {
         ieg_CenterRadP( poly, &c, &r);
         eprintf("\tPoly %d: c(%g %g %g) r: %g\n",
         i, c.x, c.y, c.z, r);
      }
   }
  
   eprintf("Polygon Normals & plane constants\n");
   for (i=1, poly=LL_First(op->polys); poly; poly = LL_Next(poly),i++)
   {
      if (poly->pnorm)
         eprintf("\tPoly %d: norm(%g %g %g) d:%6g\n",
         i, poly->pnorm->x, poly->pnorm->y, poly->pnorm->z,poly->d);
   }
  
   memPerPoint = sizeof(IePoint);
   memPerVertex =sizeof(IeVertex);
   memPerPoly = sizeof(IePoly);
  
   eprintf( "Each Point  uses %d bytes\n", memPerPoint);
   eprintf( "Each Vertex uses %d bytes\n", memPerVertex);
   eprintf( "Each Poly   uses %d bytes\n", memPerPoly);
   eprintf( "Each Object uses %d bytes\n", sizeof(IeObject));
  
   eprintf( "Object uses:\n");
   j = 0;
   i = ieg_NumPoints(op) * memPerPoint;
   eprintf( "\t%d bytes for %d Points\n", i, ieg_NumPoints(op));
   j +=i;
   i = numVertex * memPerVertex;
   eprintf( "\t%d bytes for %d Vertices\n", i , numVertex);
   j +=i;
   i = ieg_NumPolys(op) * memPerPoly;
   eprintf( "\t%d bytes for %d Polys\n", i, ieg_NumPolys(op));
   j += i + sizeof(IeObject);
   eprintf( "\tTotal %d bytes\n", j);
  
}
  
