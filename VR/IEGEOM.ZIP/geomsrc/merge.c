/*
 * AUTHOR: Jerry Isdale
 * Isdale Engineering
 * 4053 Beethoven St.
 * Los Angeles, CA, 90066
 *
 * NAME : merge.c
 * CONTENTS: merge Points
 *
 */
  
#include <assert.h>
#include "iegeom.h"
  
