// FILE: objmat44.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
#pragma warn -sus
//-----------------------------------------------
//- void ieg_ObjMat44( Mat44 matrix, pIeObject op)
//-   applies a 4x4 transform to an object
//-   by applying it to each point in the object
void ieg_ObjMat44( Mat44 matrix, pIeObject op)
{
   pIePoint dpp;
  
   assert(op != NULL);
  
   for( dpp = LL_First(op->points); dpp; dpp = LL_Next(dpp))
      MatMpy144( &(dpp->loc), matrix, &(dpp->loc));
  
   return;
}
  
//-----------------------------------------------
//- pIeObject ieg_CopyObjMat44( Mat44 matrix, pIeObject oop)
//-   create a new object that is copy of given object
//-   but transformed by given 4x4 matrix
pIeObject ieg_CopyObjMat44( Mat44 matrix, pIeObject oop)
{
   pIeObject nop;
   pIePoint opt, npt;
   pIePoly opoly, npoly;
   pIeVertex ovp, nvp, lvp;
   pIePoly ohp, nhp, lhp;
   pIePoint *parray;
  
   assert(oop != NULL);
  
   nop = ieg_NewObject();
   if (oop->attrib != NULL)
      nop->attrib = strdup(oop->attrib);
  
  // uses parray to keep track of new point pointers
  // so new vertices can be added properly
   parray = ieg_MkArray(oop);
   assert (parray != NULL);
  
   for (opt = LL_First(oop->points); opt; opt = LL_Next(opt))
   {
      npt = ieg_NewPoint();
      MatMpy144( &(opt->loc), matrix, &(npt->loc));
      parray[npt->num] = npt;
      ieg_AddPoint( nop, npt);
   }
  
   for (opoly = LL_First(oop->polys); opoly; opoly = LL_Next(opoly))
   {
      npoly = ieg_NewPoly();
      for (ovp = LL_First(opoly->vtx); ovp; ovp = LL_Next(ovp))
      {
         nvp = ieg_NewVtx();
         nvp->ppt = parray[ ovp->ppt->num];
         ieg_AddVtx(npoly, nvp);
      }
      ieg_AddPoly( nop, npoly);
   }
  
   free(parray);
   ieg_RenumObj(nop);
   return (nop);
}
  
//-----------------------------------------------
//- void ieg_ObjScale(pIeObject op, float x, float y, float z)
//-   scale the object by given values (different for each axis)
void ieg_ObjScale(pIeObject op, float x, float y, float z)
{
   pIePoint dpp;
  
   assert(op != NULL);
  
   for( dpp = LL_First(op->points); dpp; dpp = LL_Next(dpp))
   {
      dpp->loc.x *= x;
      dpp->loc.y *= y;
      dpp->loc.z *= z;
   }
}
  
//-----------------------------------------------
//- void ieg_ObjXlate(pIeObject op, float x, float y, float z)
//-   translate object by given x, y and z values
void ieg_ObjXlate(pIeObject op, float x, float y, float z)
{
   pIePoint dpp;
  
   assert(op != NULL);
  
   for( dpp = LL_First(op->points); dpp; dpp = LL_Next(dpp))
   {
      dpp->loc.x += x;
      dpp->loc.y += y;
      dpp->loc.z += z;
   }
}
