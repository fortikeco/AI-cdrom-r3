// FILE: lldump.c
//   routine to dump link list header & nodes
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <stdio.h>
#include "llist.h"
  
//-----------------------------------------------
//- void LL_DumpList (pLList lp)
//-   dumps list using eprintf
void LL_DumpList (pLList lp)
{
   LLNode *lnp;
   int i;
  
   eprintf("Dump Link List %p\n",lp);
   if (!lp)
   {
      eprintf( "\tNot a List\n");
      eflush();
      return;
   }
  
   eprintf("   First: %p, Last %p, Count %d\n",
   lp->ll_first, lp->ll_last, lp->ll_count);
  
   for (i=1,lnp=lp->ll_first;lnp; i++,lnp=lnp->ll_next)
      eprintf("    Node %d (%p): Prev: %p Next: %p\n",
      i, lnp, lnp->ll_prev, lnp->ll_next);
  
   eprintf("LL_Dump Complete\n");
   eflush();
}
  
