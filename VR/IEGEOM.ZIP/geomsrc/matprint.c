// FILE: matprint.c
// routines to print maticies
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
  
#include <assert.h>
#include "iematrix.h"
  
//-----------------------------------------------
//- void MatPrint33( FILE *file, Mat33 a)
//-   print a 3x3 matrix on given stdio FILE
void MatPrint33(FILE *file, Mat33 a)
{
   int i,j;
   for (i = 0; i < 3; ++i)
   {
      for (j = 0; j < 3; ++j)
         fprintf(file, "  %f",a[i][j]);
      fprintf(file, "\n");
   }
}
  
//-----------------------------------------------
//- void MatPrint44( FILE *fp, Mat44  a)
//-   print a 4x4 matrix on given stdio FILE
void MatPrint44( FILE *fp, Mat44 a)
{
   int i,j;
   for (i = 0; i < 4; ++i)
   {
      for (j = 0; j < 4; ++j)
         fprintf(fp, "  %f",a[i][j]);
      fprintf(fp, "\n");
   }
}
  
//-----------------------------------------------
//- void MatEPrint33(Mat33 a)
//-   print a 3x3 matrix using eprintf
void MatEPrint33(Mat33 a)
{
   int i,j;
   for (i = 0; i < 3; ++i)
   {
      for (j = 0; j < 3; ++j)
         eprintf("  %f",a[i][j]);
      eprintf("\n");
   }
}
  
//-----------------------------------------------
//- void MatEPrint44( Mat44 a)
//-   print a 4x4 matrix using eprintf
void MatEPrint44( Mat44 a)
{
   int i,j;
   for (i = 0; i < 4; ++i)
   {
      for (j = 0; j < 4; ++j)
         eprintf("  %f",a[i][j]);
      eprintf("\n");
   }
}
  
