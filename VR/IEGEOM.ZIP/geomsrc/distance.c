// FILE: distance
//
// calculate distance between two Points
//   could be done as a macro, but often params are two or
//   three pointer de-refs (vtx->point->loc), so function
//   reduces memory refs & is faster
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- double ieg_Distance( Point pt1, Point pt2)
//-   calculate the distance between two 3D points
double ieg_Distance( Point pt1, Point pt2)
{
   double d;
  
   d = (pt2.x - pt1.x) * (pt2.x - pt1.x) +
   (pt2.y - pt1.y) * (pt2.y - pt1.y) +
   (pt2.z - pt1.z) * (pt2.z - pt1.z);
  
   d = sqrt(d);
  
   return (d);
}
  
