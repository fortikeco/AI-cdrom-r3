// FILE: planar.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- int ieg_PlanarP(pIePoly poly, float delta)
//-   calculate if polygon is planar
//-   checks that each vertex point satisfies (within error of delta)
//-   the plane equation derived from the normal & 1st vertex
//-   Returns TRUE if planar, FALSE otherwise
int ieg_PlanarP(pIePoly poly, float delta)
{
   pIeVertex pvtx, ipvtx;
   float x, y, z;
   float a, b, c, d, result;
  
   assert(poly != NULL);
   assert(poly->vtx != NULL);
  
  // this computes normal and plane constant values
   PolyNormalP(poly);
  
   pvtx = LL_First(poly->vtx);
   assert(pvtx != NULL);
  
  // for faster referencing
   a = poly->pnorm->x;
   b = poly->pnorm->y;
   c = poly->pnorm->z;
   d = poly->d;
  
   for (pvtx=LL_Next(pvtx); pvtx; pvtx=LL_Next(pvtx))
   {
      x = pvtx->ppt->loc.x;
      y = pvtx->ppt->loc.y;
      z = pvtx->ppt->loc.z;
      result = a*x + b*y + c*z + d;
      if (ABS(result) > ABS(delta))
         return FALSE;
   }
  
   return TRUE;
}
  
