// FILE: center.c
//
// calculate the center and radius of bounding sphere of an object
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- void ieg_CenterRad( pIeObject op, pPoint pcent, float *prad )
//-   locates the center and radius of bounding sphere for given
//-   object. returns values in pcent & prad if given
void ieg_CenterRad( pIeObject op, pPoint pcent, float *prad )
{
   pIePoint ppt;
   float d;
   Point c;
  
   c.x = c.y = c.z = 0.0;
   if (prad) *prad = 0.0;
  
   assert(op != NULL);
   assert(op->points != NULL);
  
  // traverse once to find average point (center)
   for (ppt = LL_First(op->points); ppt; ppt = LL_Next(ppt))
   {
      c.x += ppt->loc.x;
      c.y += ppt->loc.y;
      c.z += ppt->loc.z;
   }
   c.x /= ieg_NumPoints(op);
   c.y /= ieg_NumPoints(op);
   c.z /= ieg_NumPoints(op);
  
   if (pcent)
      *pcent = c;
  
   if (*prad != NULL)
   {
    // traverse again to find furthest from center
      for (ppt = LL_First(op->points); ppt; ppt = LL_Next(ppt))
      {
         d = ieg_Distance(c, ppt->loc);
         if (d > *prad)
            *prad = d;
      }
   }
}
  
//-----------------------------------------------
//- void ieg_CenterRadP( pIeObject op, pPoint pcent, float *prad )
//-   locates the center and radius of bounding sphere for given
//-   polygon. returns values in pcent & prad if given
void ieg_CenterRadP( pIePoly poly, pPoint pcent, float *prad )
{
   pIeVertex pvtx;
   pIePoint ppt;
   float d;
   Point c;
  
   c.x = c.y = c.z = 0.0;
   if (prad) *prad = 0.0;
  
   assert(poly != NULL);
  
  // traverse once to find average point (center)
   for (pvtx = LL_First(poly->vtx); pvtx; pvtx = LL_Next(pvtx))
   {
      c.x += pvtx->ppt->loc.x;
      c.y += pvtx->ppt->loc.y;
      c.z += pvtx->ppt->loc.z;
   }
   c.x /= ieg_NumVtx(poly);
   c.y /= ieg_NumVtx(poly);
   c.z /= ieg_NumVtx(poly);
  
   if (pcent)
      *pcent = c;
  
   if (*prad != NULL)
   {
    // traverse again to find furthest from center
      for (pvtx = LL_First(poly->vtx); pvtx; pvtx = LL_Next(pvtx))
      {
         d = ieg_Distance(c, pvtx->ppt->loc);
         if (d > *prad)
            *prad = d;
      }
   }
}
  
