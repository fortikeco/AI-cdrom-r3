// FILE: extrude.c
//
// extrusion functions for creating objects (aka lofting, sweep)
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- void ieg_ExtrudeF( pIeObject op, pIePoly xf1, pIePoly xf2, int close)
//-   Create rectangular polys between point of two given faces
//-   and add new polys to the given object.
void ieg_ExtrudeF( pIeObject op, pIePoly xf1, pIePoly xf2, int close)
{
   pIePoly dfp;
   pIeVertex dvp, vtx1, vtx2;
   pIeVertex nvtx1, nvtx2;
   pIeVertex vtxArray[5];
   int i, j, npts, k;
  
   assert(op != NULL);
   assert(xf1 != NULL);
   assert(xf2 != NULL);
  
   npts = Min(ieg_NumVtx(xf1), ieg_NumVtx(xf2));
  
   for (i=1,vtx1 = LL_First(xf1->vtx), vtx2 = LL_First(xf2->vtx);
      i < npts;
      i++, vtx1 = nvtx1, vtx2 = nvtx2)
   {
      for ( k = 1 ; k < 5 ; k++)
         vtxArray[k] = ieg_NewVtx();
      vtxArray[1]->ppt = vtx1->ppt;
      vtxArray[2]->ppt = vtx2->ppt;
      nvtx1 = LL_Next(vtx1);
      nvtx2 = LL_Next(vtx2);
      vtxArray[3]->ppt = nvtx2->ppt;
      vtxArray[4]->ppt = nvtx1->ppt;
  
      dfp = ieg_NewPoly();
      for ( k = 1 ; k < 5 ; k++)
         ieg_AddVtx(dfp, vtxArray[k]);
      ieg_AddPoly(op, dfp);
   }
  
  // last point to first for closure
   if (close)
   {
      for ( k =1; k < 5; k++)
      {
         vtxArray[k] = ieg_NewVtx();
      }
      vtxArray[1]->ppt = vtx1->ppt;
      vtxArray[2]->ppt = vtx2->ppt;
      nvtx1 = LL_First(xf1->vtx);
      nvtx2 = LL_First(xf2->vtx);
      vtxArray[3]->ppt = nvtx2->ppt;
      vtxArray[4]->ppt = nvtx1->ppt;
  
      dfp = ieg_NewPoly();
      for ( k = 1 ; k < 5 ; k++)
         ieg_AddVtx(dfp, vtxArray[k]);
      ieg_AddPoly(op, dfp);
   }
}
  
//-----------------------------------------------
//- void ieg_ExtrudeObj( pIeObject op, int closeObj, int cap1, int cap2)
//-   Extrude between succesive faces of given object
//-   closeObj determines if extrude from last to first polygon
//-   cap1 means keep first poly as cap
//-   cap2 means keep last poly as cap
//-   original cross section polys are destroyed
//-   face-face extrusion considers closure only if both polys are closed
void ieg_ExtrudeObj( pIeObject op, int closeObj, int cap1, int cap2)
{
   int i;
   pLList plist;
   pIePoly ppoly, xpoly1, xpoly2, tpoly;
   int close_faces;
  
   assert(op != NULL);
  
  // disconnect old polygon list
   plist = op->polys;
   op->polys = LL_NewList();
  
   xpoly1 = LL_First(plist);
   xpoly2 = LL_Next(xpoly1);
   i = 1;
   while (xpoly2)
   {
    //eprintf("\nextrude face pair %d = %p -> %p\n", i, xpoly1, xpoly2);
      i++;
      close_faces = ieg_PolyFlag(xpoly1,POLY_CLOSED) &
      ieg_PolyFlag(xpoly2,POLY_CLOSED);
      ieg_ExtrudeF(op, xpoly1, xpoly2, close_faces);
      xpoly1 = xpoly2;
      xpoly2 = LL_Next(xpoly2);
   }
   if (closeObj)
   {
      xpoly1 = LL_Last(plist);
      xpoly2 = LL_First(plist);
      close_faces = ieg_PolyFlag(xpoly1,POLY_CLOSED) &
      ieg_PolyFlag(xpoly2,POLY_CLOSED);
      ieg_ExtrudeF(op, xpoly1, xpoly2, close_faces);
   }
  
   if (cap2)
   {
      ppoly = LL_Last(plist);
      LL_Remove(plist, ppoly);
      ieg_RevPoly(ppoly);
      ieg_AddPoly (op, ppoly);
   }
  
   if (cap1)
   {
      ppoly = LL_First(plist);
      LL_Remove(plist, ppoly);
      ieg_AddPoly (op, ppoly);
   }
  
  // destroy remaining cross section polygons
   for (ppoly = LL_First(plist); ppoly; ppoly = tpoly)
   {
      tpoly = LL_Next(ppoly);
      ieg_FreePoly (ppoly);
   }
   free(plist);
  
}
