// FILE: color.c
//
// routines to color polygons of an object
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- void ieg_ColorPolys(pIeObject op, unsigned long color)
//-  assign given color to all polygons of object
void ieg_ColorPolys(pIeObject op, unsigned long color)
{
   pIePoly poly;
  
   assert(op != NULL);
  
   for (poly = LL_First(op->polys);poly;poly = LL_Next(poly))
   {
      poly->color = color;
   }
}
  
//-----------------------------------------------
//- void ieg_ColorPolysSeq(pIeObject op, int start)
//-  assign polygons sequential colors starting with given value
void ieg_ColorPolysSeq(pIeObject op, int start)
{
   pIePoly poly;
   unsigned long color = start;
  
   assert(op != NULL);
  
   for (poly = LL_First(op->polys);poly;poly = LL_Next(poly))
   {
      poly->color = color;
      color++;
   }
}
  
//-----------------------------------------------
//- void ieg_ColorPolysRand(pIeObject op, int indexed)
//-  randomly color each polygon. (color range 1-256)
//-  if indexed == TRUE then or color values with 0x8000
void ieg_ColorPolysRand(pIeObject op, int indexed)
{
   pIePoly poly;
   unsigned long color;
  
   assert(op != NULL);
  
   for (poly = LL_First(op->polys);poly;poly = LL_Next(poly))
   {
      color = random(256);
      if (indexed)
         poly->color = color | 0x8000;
      else
         poly->color = color;
   }
}
