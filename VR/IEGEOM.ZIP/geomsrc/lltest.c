// FILE: lltest.c
//
// test driver for link list library
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <stdio.h>
#include "llist.h"
  
// an example structure using LLNodes
typedef struct TestNode {
   LLNode links;
   int i;
} TestNode, *pTestNode;
  
//-----------------------------------------------
void main()
{
   pLList list;
   pTestNode node, tn;
   int i;
  
   eopenf(NULL);
  
   eprintf("Create List \n");
   list = LL_NewList();
   if (!list)
   {
      eprintf("Error Cant Create list\n");
      return;
   }
  
   LL_DumpList(list);
  
   eprintf("Add 10 nodes, with datum = 10 * index\n");
  
   for (i=1;i<=10;i++)
   {
      eprintf(" %d",i);
  
      node = malloc (sizeof(TestNode));
      if (!node)
      {
         eprintf("Error Cant create node %d\n", i);
         return;
      }
      node->i = i*10;
      LL_AddTail(list,node);
   }
   eprintf("\n");
  
   eprintf("Dump filled list\n");
   LL_DumpList(list);
  
   eprintf("\nTraverse List with LL_First/Next\n");
  // (pTestNode)
   for(i=0,node=LL_First(list);node;
      i++,node=LL_Next(node))
      eprintf("   %d = %p, %d (prev= %p, next=%p)\n",
      i, node, node->i, node->links.ll_prev, node->links.ll_next);
   eprintf("\n");
  
   eprintf("\nGet Nth tests\n");
   for(i=0;i < 10;i+=2)
   {
      node = LL_GetNth(list,i);
      eprintf("  GO: %d = %p, %d (prev= %p, next=%p)\n",
      i, node, node->i, node->links.ll_prev, node->links.ll_next);
   }
  
   eprintf("\nDestroy List\n");
   LL_Destroy(list);
  
   LL_DumpList(list);
  
   eprintf("\nEnd Test\n");
}
  
