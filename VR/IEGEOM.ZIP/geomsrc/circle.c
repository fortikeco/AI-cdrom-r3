// FILE: circle
//
//  Routines to create a circle and a line object
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- pIeObject ieg_Circle( float radius, int nfacet)
//-   creates a circle object in the XY plane centered on 0,0
//-   with the given radius and number of facets.
pIeObject ieg_Circle( float radius, int nfacet)
{
   pIeObject op;
   pIePoint ppt;
   pIeVertex pvtx;
   pIePoly ppoly;
   float delta;
   float theta;
   int i;
  
   op = ieg_NewObject();
   ppoly = ieg_NewPoly();
   ieg_AddPoly(op, ppoly);
  
   delta = (2*PI)/nfacet;
  
   ppt = ieg_NewPoint();
   ieg_AddPoint(op, ppt);
   ppt->loc.x = radius;
   ppt->loc.y = ppt->loc.z = 0.0;
  
   pvtx = ieg_NewVtx();
   pvtx->ppt = ppt;
   ieg_AddVtx(ppoly,pvtx);
  
   if (nfacet == 1)
   {
      // single line from origin to radius
      ppt = ieg_NewPoint();
      ieg_AddPoint( op, ppt);
      pvtx = ieg_NewVtx();
      pvtx->ppt = ppt;
      ieg_AddVtx( ppoly, pvtx);
  
   } else 
	{
	   for (i = 1; i < nfacet; i++)
      {
         ppt = ieg_NewPoint();
         theta = 2*PI - delta * i;
         ppt->loc.x = radius * cos( theta);
         ppt->loc.y = radius * sin( theta);
         ppt->loc.z = 0.0;
  
         ieg_AddPoint(op, ppt);
         pvtx = ieg_NewVtx();
         pvtx->ppt = ppt;
         ieg_AddVtx( ppoly, pvtx);
      }
   }
  
   return(op);
}
  
//-----------------------------------------------
//- pIeObject ieg_LineFromTo( Point from_pt, Point to_pt, int npoints)
//-  create object that is single line given endpoints
//-  line will have npoint-1 line segments.
//-  useful for extruding along a line
pIeObject ieg_LineFromTo( Point from_pt, Point to_pt, int npoints)
{
   pIeObject op;
   pIePoint ppt, last_pt;
   pIeVertex pvtx;
   pIePoly ppoly;
   Vector dir;
   Point size;
   int i;
  
  // generate dir vector & size of each section
   VSUB(to_pt, from_pt, dir);
   size.x = dir.x/(npoints-1);
   size.y = dir.y/(npoints-1);
   size.z = dir.z/(npoints-1);
  
  // create object and polygon
   op = ieg_NewObject();
   ieg_ObjName(op,"LineFromTo");
   ppoly = ieg_NewPoly();
   ppoly->flag = POLY_OPEN;
   ieg_AddPoly(op, ppoly);
  
  // add first point to line
   ppt = ieg_NewPoint();
   ppt->loc = from_pt;
   pvtx = ieg_NewVtx();
   pvtx->ppt = ppt;
   ieg_AddPoint(op,ppt);
   ieg_AddVtx(ppoly, pvtx);
   last_pt = ppt;
  
  // add intermediate points
   for (i=1; i < npoints-1;i++)
   {
      ppt = ieg_NewPoint();
      VADD(last_pt->loc, size, ppt->loc);
  
      pvtx = ieg_NewVtx();
      pvtx->ppt = ppt;
      ieg_AddPoint(op,ppt);
      ieg_AddVtx(ppoly, pvtx);
      last_pt = ppt;
   }
  
  // add end point
   ppt = ieg_NewPoint();
   ppt->loc = to_pt;
   pvtx = ieg_NewVtx();
   pvtx->ppt = ppt;
   ieg_AddPoint(op,ppt);
   ieg_AddVtx(ppoly, pvtx);
  
//ieg_fpWritePLG(op,stdout,1.0);
  
   return(op);
}
  
//-----------------------------------------------
//- pIeObject ieg_LineDir( Point from_pt, Vector indir, float len, int npoints)
//-  create object that is single line given start point, direction & length
//-  line will have npoint-1 line segments.
//-  useful for extruding along a line
pIeObject ieg_LineDir( Point from_pt, Vector indir, float len, int npoints)
{
   pIeObject op;
   pIePoint ppt, last_pt;
   pIeVertex pvtx;
   pIePoly ppoly;
   Vector dir; // normalized direction of line
   Point size; // size of line segments
   int i;
  
  // normalize dir vector & find size of each section
   dir = indir;
   VNORM(dir);
   size.x = (dir.x*len)/(npoints-1);
   size.y = (dir.y*len)/(npoints-1);
   size.z = (dir.z*len)/(npoints-1);
  
  // create object and polygon
   op = ieg_NewObject();
   ieg_ObjName(op,"LineDirDist");
   ppoly = ieg_NewPoly();
   ppoly->flag = POLY_OPEN;
   ieg_AddPoly(op, ppoly);
  
  // add first point to line
   ppt = ieg_NewPoint();
   ppt->loc = from_pt;
   pvtx = ieg_NewVtx();
   pvtx->ppt = ppt;
   ieg_AddPoint(op,ppt);
   ieg_AddVtx(ppoly, pvtx);
   last_pt = ppt;
  
  // add intermediate points
   for (i=1; i < npoints;i++)
   {
      ppt = ieg_NewPoint();
      VADD(last_pt->loc, size, ppt->loc);
  
      pvtx = ieg_NewVtx();
      pvtx->ppt = ppt;
      ieg_AddPoint(op,ppt);
      ieg_AddVtx(ppoly, pvtx);
   }
  
   return(op);
}
  
