// FILE: matadd.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iematrix.h"
  
//-----------------------------------------------
//- void MatAdd33( Mat33 a,Mat33 b,Mat33 c)
//-   3 x 3 matrix add c = a + b
void  MatAdd33( Mat33 a,Mat33 b,Mat33 c)
{
   c[0][0] = a[0][0] + b[0][0];
   c[0][1] = a[0][1] + b[0][1];
   c[0][2] = a[0][2] + b[0][2];
  
   c[1][0] = a[1][0] + b[1][0];
   c[1][1] = a[1][1] + b[1][1];
   c[1][2] = a[1][2] + b[1][2];
  
   c[2][0] = a[2][0] + b[2][0];
   c[2][1] = a[2][1] + b[2][1];
   c[2][2] = a[2][2] + b[2][2];
}
  
