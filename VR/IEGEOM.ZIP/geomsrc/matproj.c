// FILE: matproject.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
  
#include <assert.h>
#include "iematrix.h"
  
//-----------------------------------------------
//- void MatProject33(VECTOR v, Mat33 m)
//-   matrix is projection of vector onto three axis
void MatProject33(VECTOR v, Mat33 m)
{
  
   VNORM( (*(Vector *)v) );
  
   m[0][0] = v[0] * v[0];
   m[0][1] = v[0] * v[1];
   m[0][2] = v[0] * v[2];
  
   m[1][0] = v[1] * v[0];
   m[1][1] = v[1] * v[1];
   m[1][2] = v[1] * v[2];
  
   m[2][0] = v[2] * v[0];
   m[2][1] = v[2] * v[1];
   m[2][2] = v[2] * v[2];
}
  
