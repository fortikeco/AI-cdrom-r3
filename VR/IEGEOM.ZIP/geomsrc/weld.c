// FILE: weld.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
//#define DEBUG
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- int ieg_WeldPoints( pIeObject op, double distance)
//-   merges points in object that are within the given distance
//-   distance is considered a cube rather than sphere
//-   this greatly reduces the comparisons & calculations needed
int ieg_WeldPoints( pIeObject op, double distance)
{
   int numCons = 0;
   pIePointRef *array;
   pIePoint *sortArray;
   pIePointRef ptref;
   int numPoints;
   int i,j,k,l;
  
   eprintf("Weld points within %f \n", distance);
  
   assert(op != NULL);
  
   array = ieg_GetPointRef(op);
  
   sortArray = ieg_SortPoints(op,XIDX);
   numPoints = ieg_NumPoints(op);

#ifdef DEBUG
eprintf("Points Sorted by X:\n");
for (i=1;i <= numPoints; i++)
{
	pIePoint ppt;
	ppt = sortArray[i];
	eprintf("%2d = %p = %2d = %6g %6g %6g\n",
	  i, ppt, ppt->num, ppt->loc.x, ppt->loc.y, ppt->loc.z);
}   
#endif

   eprintf("Check Points\n");
   for (i=1;i < numPoints; i++)
   {
      if (i%100 == 0)
         eprintf(".");
  
#ifdef DEBUG
      eprintf("Check Point %d (sort:%d):\n", sortArray[i]->num, i);
      eprintf("\t array[%d] = %d\n",
         sortArray[i]->num, array[sortArray[i]->num]);
#endif
      if ( array[ sortArray[i]->num] == NULL)
      {
#ifdef DEBUG
      	eprintf("\tunused point, skipping\n");
#endif
         continue;
      }
      for (j=i+1; 
         sortArray[j]->loc.x <= sortArray[i]->loc.x + distance &&
         sortArray[j]->loc.x >= sortArray[i]->loc.x - distance;
         j++)
      {
         if (j > numPoints)
            break;
         if (sortArray[j]->loc.y <= sortArray[i]->loc.y + distance &&
            sortArray[j]->loc.y >= sortArray[i]->loc.y - distance &&
            sortArray[j]->loc.z <= sortArray[i]->loc.z + distance &&
            sortArray[j]->loc.z >= sortArray[i]->loc.z - distance)
         {
#ifdef DEBUG
            eprintf("\tFound Match: %d (sort:%d)\n", sortArray[j]->num, j);
#endif
	        // point is within distance
            if (array[ sortArray[j]->num] == NULL)
               continue;
  
#ifdef DEBUG
            eprintf("\tMatch is used: %d\n", array[sortArray[j]->num]);
			#endif
  
            numCons++;
            // merge into lower numbered point
            // break if that is point 2
            if (ieg_MergePoints(sortArray[i],sortArray[j],array))
               break;
         }
      }
   }
   eprintf("\n");
  
   free(sortArray);
   //eprintf("After Free sort array core of %ld\n",coreleft());
   ieg_FreePointRefArray(array, numPoints);
   //eprintf("After Free ptref array core of %ld\n",coreleft());
  
   return(numCons);
}
