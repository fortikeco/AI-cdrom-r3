// FILE: dofunc.c
//
// Generic functions that apply one function repeatedly to all
// points or polygons of the given object.
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- void ieg_DoPoints(pIeObject op, PointFunc pfunc)
//-   applies pfunc to each point in given object
void ieg_DoPoints(pIeObject op, PointFunc pfunc)
{
   pIePoint point;
  
   assert(op != NULL);
  
   for (point = LL_First(op->points);point;point = LL_Next(point))
   {
      (*pfunc)(point);
   }
}
  
//-----------------------------------------------
//- void ieg_DoPolys(pIeObject op, PolyFunc pfunc)
//-   applies pfunc to each polygon in given object
void ieg_DoPolys(pIeObject op, PolyFunc pfunc)
{
   pIePoly poly;
  
   assert(op != NULL);
  
   for (poly = LL_First(op->polys);poly;poly = LL_Next(poly))
   {
      (*pfunc)(poly);
   }
}
  
