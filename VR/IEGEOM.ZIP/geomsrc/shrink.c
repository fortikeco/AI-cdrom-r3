// FILE: shrink.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- pIeObject ieg_Shrink(pIeObject src, float amt)
//-   create new object by shrinking all polygons of source
pIeObject ieg_Shrink(pIeObject src, float amt)
{
   pIePoly poly;
   pIeObject dest;
   char name[80];
  
   assert(src != NULL);
  
   dest = ieg_NewObject();
   if (src->name)
      sprintf(name,"%s_shrunk%g ",src->name,amt);
   else
      sprintf(name,"shrunk%g ",amt);
   dest->name = strdup(name);
  
   for (poly = LL_First(src->polys);poly;poly = LL_Next(poly))
      ieg_ShrinkP(poly,dest,amt);
  
   return (dest);
}
  
//-----------------------------------------------
//- void ieg_ShrinkP(pIePoly poly, pIeObject dest, float amt)
//-   shrink a polygon away from its edges, creating new points
//-   and a new polygon in the dest object.
void ieg_ShrinkP(pIePoly poly, pIeObject dest, float amt)
{
   pIePoint ppt;
   pIeVertex pvtx, nvtx;
   pIePoly npoly;
   Point center;
   float radius;
  
   assert(poly != NULL);
   assert(dest != NULL);
  
   ieg_CenterRadP(poly,&center,&radius);
  
   npoly = ieg_NewPoly();
   npoly->flag = poly->flag;
   npoly->color = poly->color;
  
  // for each vertex,
  //  duplicate point, then move it towards center by amt
  //  then add to dest object, make new vtx pointing to it
   for (pvtx=LL_First(poly->vtx);pvtx;pvtx= LL_Next(pvtx))
   {
      ppt = ieg_NewPoint();
      *ppt = *(pvtx->ppt);
  
      ppt->loc.x = ppt->loc.x + (center.x - ppt->loc.x) * amt;
      ppt->loc.y = ppt->loc.y + (center.y - ppt->loc.y) * amt;
      ppt->loc.z = ppt->loc.z + (center.z - ppt->loc.z) * amt;
  
      ieg_AddPoint(dest, ppt);
  
    /* make a new vertex to point at the Point */
      nvtx = ieg_NewVtx();
      nvtx->ppt = ppt;
      ieg_AddVtx(npoly, nvtx);
   }
   ieg_AddPoly(dest,npoly);
}
  
//-----------------------------------------------
//- pIeObject ieg_Edge(pIeObject src, float amt)
//-   create new object that is edge'd polygons of src
//-   edge'nig shrinks polygons away from center towards edges.
//-   effectively creates 1 new polygon for each edge
pIeObject ieg_Edge(pIeObject src, float amt)
{
   pIePoly poly;
   pIeObject dest;
   int i;
   char name[80];
  
   assert(src != NULL);
  
   dest = ieg_NewObject();
   if (src->name)
      sprintf(name,"%s_edged%g ",src->name,amt);
   else
      sprintf(name,"edged%g ",amt);
   dest->name = strdup(name);
  
   for (poly = LL_First(src->polys);poly;poly = LL_Next(poly))
      ieg_EdgeP(poly,dest,amt);
  
   return (dest);
}
  
//-----------------------------------------------
//- void ieg_EdgeP(pIePoly poly, pIeObject dest, float amt)
//-   replace polys of object with edge polygons
//-   edge'nig shrinks polygons away from center towards edges.
//-   effectively creates 1 new polygon for each edge
//-   looks like original polygon but with an apparent hole
void ieg_EdgeP(pIePoly poly, pIeObject dest, float amt)
{
   pIePoint ppt, dup_pt;
   pIeVertex pvtx, nvtx1, nvtx2, nvtx3, nvtx4;
   pIePoly npoly;
   Point center;
   float radius;
   pIePoint *origpts, *newpts;
   int i;
   int npts;
  
   assert(poly != NULL);
   assert(dest != NULL);
  
  // locate center point, ignore radius
   ieg_CenterRadP(poly,&center,&radius);
  
   npts = ieg_NumVtx(poly);
  
  // arrays to remember points for each vertex
  // one array for the original point locations
  // and second for points that are shrunk
   origpts = (pIePoint *)malloc(npts*sizeof(pIePoint));
   newpts =  (pIePoint *)malloc(npts*sizeof(pIePoint));
  
   for (i=0,pvtx=LL_First(poly->vtx);pvtx;i++,pvtx= LL_Next(pvtx))
   {
      dup_pt = ieg_NewPoint();
      *dup_pt = *(pvtx->ppt);
      origpts[i] = dup_pt;
  
      ppt = ieg_NewPoint();
      *ppt = *(pvtx->ppt);
      newpts[i] = ppt;
  
    /* shrink the coordinates of the newpts point */
      ppt->loc.x += (center.x - ppt->loc.x) * amt;
      ppt->loc.y += (center.y - ppt->loc.y) * amt;
      ppt->loc.z += (center.z - ppt->loc.z) * amt;
  
      ieg_AddPoint(dest, dup_pt);
      ieg_AddPoint(dest, ppt);
   }
  
  // now connect up sets of four points per edge
  // two original plus two that were shrunk
   for (i=0; i < npts-1;i++)
   {
      npoly = ieg_NewPoly();
      npoly->color = poly->color;
  
      nvtx1 = ieg_NewVtx();
      nvtx2 = ieg_NewVtx();
      nvtx3 = ieg_NewVtx();
      nvtx4 = ieg_NewVtx();
  
      nvtx1->ppt = origpts[i];
      nvtx2->ppt = origpts[i+1];
      nvtx3->ppt = newpts[i+1];
      nvtx4->ppt = newpts[i];
  
      ieg_AddVtx(npoly, nvtx1);
      ieg_AddVtx(npoly, nvtx2);
      ieg_AddVtx(npoly, nvtx3);
      ieg_AddVtx(npoly, nvtx4);
  
      ieg_AddPoly(dest, npoly);
   }
  
   if (ieg_PolyFlag(poly,POLY_CLOSED))
   {
      i = npts -1;
      npoly = ieg_NewPoly();
      npoly->color = poly->color;
  
      nvtx1 = ieg_NewVtx();
      nvtx2 = ieg_NewVtx();
      nvtx3 = ieg_NewVtx();
      nvtx4 = ieg_NewVtx();
  
      nvtx1->ppt = origpts[i];
      nvtx2->ppt = origpts[0];
      nvtx3->ppt = newpts[0];
      nvtx4->ppt = newpts[i];
  
      ieg_AddVtx(npoly, nvtx1);
      ieg_AddVtx(npoly, nvtx2);
      ieg_AddVtx(npoly, nvtx3);
      ieg_AddVtx(npoly, nvtx4);
  
      ieg_AddPoly(dest, npoly);
   }
   free(origpts);
   free(newpts);
}
  
