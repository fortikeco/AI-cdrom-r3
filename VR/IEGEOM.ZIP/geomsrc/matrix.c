// FILE: matrix.c
//
// axis arrays, identity and conversion routines
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iematrix.h"
  
//-----------------------------------------------
//- Axis vectors
Vector Xaxis = { 1.0, 0.0, 0.0};
Vector Yaxis = { 0.0, 1.0, 0.0};
Vector Zaxis = { 0.0, 0.0, 1.0};
  
//-----------------------------------------------
//- void  MatIdentity33(Mat33 a)
//-   sets given 3 x 3 matrix to identity matrix
void MatIdentity33(Mat33 a)
{
   static MatStruct33  I = { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 };
  
   *(MatStruct33 *)a = I;
}
  
//-----------------------------------------------
//- void MatIdentity44(Mat44  a)
//-  sets given 4 x 4 matrix to identity matrix
void MatIdentity44(Mat44 a)
{
   static MatStruct44 I = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
   *(MatStruct44 *)a = I;
}
  
//-----------------------------------------------
//- void MatCvt3344(Mat33 a, Mat44 b)
//-   expand 3 x 3 matrix a to a 4 x 4 matrix,
//-   fourth row and column are zero, except the diagonal which is 1.0
void MatCvt3344(Mat33 a, Mat44 b)
{
   b[0][0] = a[0][0];  b[0][1] = a[0][1];  b[0][2] = a[0][2];
   b[1][0] = a[1][0];  b[1][1] = a[1][1];  b[1][2] = a[1][2];
   b[2][0] = a[2][0];  b[2][1] = a[2][1];  b[2][2] = a[2][2];
  
   b[3][0] = b[3][1] = b[3][2] = b[0][3] = b[1][3] = b[2][3] = 0.0;
   b[3][3] = 1.0;
}
  
