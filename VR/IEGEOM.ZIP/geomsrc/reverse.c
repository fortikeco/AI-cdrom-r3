// FILE: reverse.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- void ieg_ReverseObj( pIeObject op)
//-   reverses esch polygon in an object
//-   cant use DoPoly() for this since RevPoly is a macro
void ieg_ReverseObj( pIeObject op)
{
   pIePoly ppoly;
  
   assert(op != NULL);
  
   for (ppoly = LL_First(op->polys); ppoly; ppoly = LL_Next(ppoly))
      ieg_RevPoly(ppoly);
}
  
