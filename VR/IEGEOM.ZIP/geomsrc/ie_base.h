// FILE: ie_base.h
//  collection of basic includes and defines
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//

#ifndef IE_BASE_DEFINES
#define IE_BASE_DEFINES

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <dir.h>

//-----------------------------
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

//#define MAXSTRING 256

//-----------------------------
#define Max(x,y) (((x) > (y))? x : y)
#define Min(x,y) (((x) < (y))? x : y)

//-----------------------------
#define PI 3.1415926535897
#define RADTODEG( r) (r * 180.0 / PI)
#define DEGTORAD( d) (d *  PI / 180.0)

//-----------------------------
// Error Print routines
// call eopenf with file name to log to file
// or with NULL to use stderr
// otherwise eprintf/edump/edumpstr wont output
extern void eFlushAlways(int flag); // force flush on each write
extern void eClose2Flush(int flag); // use close/reopen to flush
extern int eopenf( char *fname );
extern void eclose( void );
extern void ereopen(void);
extern void eflush( void );
extern void eprintf( char *fmt, ... );
extern void edumpstr(char *ptr);
extern void edump(void*lp, long len);
//-----------------------------

#endif // IE_BASE_DEFINES
