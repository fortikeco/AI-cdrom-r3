// FILE: dump.c
//
// debugging routines to dump objects & points using eprint
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- void ieg_DumpObj(pIeObject op)
//-  dumps object using eprint function
void ieg_DumpObj(pIeObject op)
{
   pIePoint dpp;
   pIePoly dfp;
   pIeVertex dvp;
   int i, j;
  
   eprintf("IeObject pointer: %p\n", op);
  
   eprintf("IeObject claims %d points and %d faces\n",
   ieg_NumPoints(op), ieg_NumPolys(op));
   eprintf("Points:\n");
  
   for (i=1,dpp = LL_First(op->points); dpp; dpp = LL_Next(dpp), i++)
   {
      eprintf("%d:\tdpp = %p\t num = %d\n",i, dpp, dpp->num);
      eprintf("\tloc= %f %f %f %f\n",
      dpp->loc.x,dpp->loc.y, dpp->loc.z, dpp->loc.w);
   }
  
   eprintf("\nPolys:\n");
   for (i=1, dfp = LL_First(op->polys); dfp; dfp = LL_Next(dfp), i++)
   {
      eprintf("%d: %d vertices, color: %lu\n", i, ieg_NumVtx(dfp),dfp->color);
      if (dfp->pnorm)
         eprintf("\tnormal %f %f %f\n",
         dfp->pnorm->x,  dfp->pnorm->y,  dfp->pnorm->z);
      for (j = 1, dvp = LL_First(dfp->vtx); dvp; dvp = LL_Next(dvp), j++)
         eprintf("\t vtx %d = %p, ppt = %p (%d)\n",
         j, dvp, dvp->ppt, dvp->ppt->num);
   }
  
   eprintf("end Dump Object\n\n");
}
  
  
//-----------------------------------------------
//- void ieg_DumpPoly( pIePoly dfp)
//-   dumps polygon using eprint function
void ieg_DumpPoly( pIePoly dfp)
{
   pIeVertex dvp;
   int j;
  
   if (dfp == NULL)
   {
      eprintf("Dump NULL Poly\n");
      return;
   }
  
   eprintf("Dump Poly %p\n\t flag: %d npts: %d \n",
   dfp, dfp->flag, ieg_NumVtx(dfp));
   for (j = 1, dvp = LL_First(dfp->vtx); dvp; dvp = LL_Next(dvp), j++)
      eprintf("\t vtx %d = %p, ppt = %p (%d)\n",
      j, dvp, dvp->ppt, dvp->ppt->num);
}
