// FILE: matscale.c
//  matrix scaling functions
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iematrix.h"
  
//-----------------------------------------------
//- void MatScale33(Mat33 a, double sx, double sy, double sz)
//-   multiply 3 x 3 matrix a by scale matrix with diagonal (sx, sy, sz)
void MatScale33(Mat33 a, double sx, double sy, double sz)
{
   a[0][0] *= sx;  a[0][1] *= sy;  a[0][2] *= sz;
   a[1][0] *= sx;  a[1][1] *= sy;  a[1][2] *= sz;
   a[2][0] *= sx;  a[2][1] *= sy;  a[2][2] *= sz;
}
  
//-----------------------------------------------
//- void MatScale44(Mat44 a, double sx, double sy, double sz, double sw)
//-   multiply 4 x 4 matrix a by scale matrix with diagonal (sx, sy, sz)
void MatScale44(Mat44 a, double sx, double sy, double sz, double sw)
{
   a[0][0] *= sx;  a[0][1] *= sy;  a[0][2] *= sz;  a[0][3] *= sw;
   a[1][0] *= sx;  a[1][1] *= sy;  a[1][2] *= sz;  a[1][3] *= sw;
   a[2][0] *= sx;  a[2][1] *= sy;  a[2][2] *= sz;  a[2][3] *= sw;
   a[3][0] *= sx;  a[3][1] *= sy;  a[3][2] *= sz;  a[3][3] *= sw;
}
  
