// FILE: copy.c
//
// copy and concatenate objects
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- pIeObject ieg_CopyObj( pIeObject oop)
//-   Create a copy of given object
pIeObject ieg_CopyObj( pIeObject oop)
{
   pIeObject nop;
   pIePoint opt, npt;
   pIePoly opl, npl;
   pIeVertex ovp, nvp, lvp;
   pIePoint *parray;
  
   assert(oop != NULL);
  
   nop = ieg_NewObject();
   if (oop->attrib != NULL)
      nop->attrib = strdup(oop->attrib);
  
  // uses parray to keep track of new point pointers
  // so new vertices can be added properly
   parray = ieg_MkArray(oop);
   assert (parray != NULL);
  
   for (opt = LL_First(oop->points); opt; opt = LL_Next(opt))
   {
      npt = ieg_NewPoint();
      *npt = *opt;
      parray[npt->num] = npt;
      ieg_AddPoint( nop, npt);
   }
  
   for (opl = LL_First(oop->polys); opl; opl = LL_Next(opl))
   {
      npl = ieg_NewPoly();
      for (ovp = LL_First(opl->vtx); ovp; ovp = LL_Next(ovp))
      {
         nvp = ieg_NewVtx();
         nvp->ppt = parray[ ovp->ppt->num];
         ieg_AddVtx(npl, nvp);
      }
      ieg_AddPoly( nop, npl);
   }
  
   free(parray);
   ieg_RenumObj(nop);
   return (nop);
}
  
//-----------------------------------------------
//- void ieg_CatObj (pIeObject dest, pIeObject source)
//-   merges 2nd object to first by concatenting point & poly lists
//-   this leaves obj2 with no points or polygons
void ieg_CatObj (pIeObject dest, pIeObject source)
{
   assert(dest != NULL);
   assert(source != NULL);
  
   LL_ConCat(dest->points, source->points);
   LL_ConCat(dest->polys, source->polys);
  
   ieg_RenumObj(dest);
}
  
//-----------------------------------------------
//- void ieg_AddObj ( pIeObject dest, pIeObject source)
//-   merges 2nd object into first by copying points & polys
//-   new points/polys are added to end of dest's lists
void ieg_AddObj ( pIeObject dest, pIeObject source)
{
   int i;
   pIePoint opt, npt;
   pIePoly oply, nply;
   pIeVertex ovp, nvp, lvp;
   pIePoint *parray;
  
   assert(dest != NULL);
   assert(source != NULL);
  
  // copy points from source into end of dest points list
  // keep record of new point in array that can be indexed
  
   parray = ieg_MkArray(source);
   assert(parray != NULL);
  
   for (i=1,opt = LL_First(source->points); opt; opt = LL_Next(opt), i++)
   {
      npt = ieg_NewPoint();
      assert(npt != NULL);
      *npt = *opt; // copies all data, incl links
      parray[i] = npt;
      ieg_AddPoint( dest, npt); // overwrite links
   }
  
   for (oply = LL_First(source->polys); oply; oply = LL_Next(oply))
   {
      nply = ieg_NewPoly();
      assert(nply != NULL);
      for (ovp = LL_First(oply->vtx); ovp; ovp = LL_Next(ovp))
      {
         nvp = ieg_NewVtx();
         assert(nvp != NULL);
         nvp->ppt = parray[ ovp->ppt->num];
         ieg_AddVtx(nply, nvp);
      }
      ieg_AddPoly( dest, nply);
   }
  
   free(parray);
   ieg_RenumObj(dest);
}
  
  
  
