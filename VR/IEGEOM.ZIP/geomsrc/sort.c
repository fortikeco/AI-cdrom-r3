// FILE: sort.c
//  sort ie geom points
//
//  A simple shell sort is used. Algorithm adapted from:
//    Jamsa,Kris; The C Library; Osborne McGraw-Hill;1985;pg 162
//    Sedgewick,R.; "Algorithms"; Addison-Wesley; 1983;page 98
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- pIePoint *ieg_SortPoints(pIeObject op, int axis)
//-   Create an array of point pointers that is sorted according to
//-   the specified axis (XIDX, YIDX, ZIDX)
pIePoint *ieg_SortPoints(pIeObject op, int axis)
{
   int numPoints;
   pIePoint *array;
   pIePoint tpt;
   int exchanged = FALSE;
   int i, gap;
   double value1, value2;
  
   assert(op != NULL);
  
  // allocate space for array of pointers & initialize
   array = ieg_MkArray(op);
   numPoints = ieg_NumPoints(op);
  
  // get a good value for the partition
   for (gap=1;gap < numPoints;gap =3*gap+1)
      ;
  
   do{
      gap = gap/3;
      do {
         exchanged = FALSE;
         for (i = 1;i < numPoints+1 - gap;i++)
         {
            switch (axis)
            {
               case YIDX:
                  value1 = array[i]->loc.y;
                  value2 = array[i+gap]->loc.y;
                  break;
               case ZIDX:
                  value1 = array[i]->loc.z;
                  value2 = array[i+gap]->loc.z;
                  break;
               case XIDX:
               default:
                  value1 = array[i]->loc.x;
                  value2 = array[i+gap]->loc.x;
                  break;
            }
            if (value1 > value2)
            {
               tpt = array[i];
               array[i] = array[i+gap];
               array[i+gap] = tpt;
               exchanged = TRUE;
            }
         }
      } while (exchanged);
   } while (gap >1);
  
   return (array);
}
