// FILE: llist.c V2.0
//
//  With llist.h, implements an encapsulated data structure and
// methods for double link list (null terminated).
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "llist.h"
  
//-----------------------------------------------
//- int _ll_initnode( pLLNode lnp)
//-   initialzes next/prev for list node
//-   LL_InitNode() should be used instead to avoid
//-   warnings about pointer types
int _ll_initnode( pLLNode lnp)
{
   assert(lnp != NULL);
  
   lnp->ll_prev = lnp->ll_next = NULL;
  
   return(TRUE);
}
  
//-----------------------------------------------
//- pLList LL_NewList(void)
//-  create a new linked list header structure & return pointer to it
pLList LL_NewList(void)
{
   pLList pnew_list;
  
   pnew_list = malloc(sizeof(LList));
   assert(pnew_list != NULL);
  
   LL_InitList(pnew_list);
  
   return(pnew_list);
}
  
//-----------------------------------------------
//- void LL_InitList( pLList plist)
//-   initialize given linked list header
void LL_InitList( pLList plist)
{
   assert(plist != NULL);
  
   plist->ll_first = plist->ll_last = NULL;
   plist->ll_count = 0;
}
  
//-----------------------------------------------
//- int _ll_addhead( pLList llp, pLLNode lnp)
//-   adds "lnp" to list "llp" as 1st node, updates count
//-   LL_AddHead() should be used instead to avoid
//-   warnings about pointer types
int _ll_addhead( pLList llp, pLLNode lnp)
{
   assert(llp != NULL);
   assert(lnp != NULL);
  
   LL_InitNode(lnp);
  
   if (!llp->ll_first)
   {
      llp->ll_first = llp->ll_last = lnp;
   } else
   {
      lnp->ll_next = llp->ll_first;
      llp->ll_first->ll_prev = lnp;
      llp->ll_first = lnp;
   }
   llp->ll_count++;
  
   return(TRUE);
}
  
//-----------------------------------------------
//- int _ll_addtail ( pLList llp, pLLNode lnp)
//-   adds node "lnp" to list "llp" as last node, updates count
//-   LL_AddTail () should be used instead to avoid
//-   warnings about pointer types
int _ll_addtail ( pLList llp, pLLNode lnp)
{
   assert(llp != NULL);
   assert(lnp != NULL);
  
   LL_InitNode(lnp);
  
   if (!llp->ll_last)
   {
      llp->ll_first = llp->ll_last = lnp;
   } else
   {
      lnp->ll_prev = llp->ll_last;
      llp->ll_last->ll_next = lnp;
      llp->ll_last = lnp;
   }
   llp->ll_count++;
  
   return(TRUE);
}
  
//-----------------------------------------------
//- int _ll_addafter ( pLList llp, pLLNode lnp_new, pLLNode lnp_old)
//-   adds node lp_new to list llp after lnp_old, updates count
//-   LL_AddAfter() should be used instead to avoid
//-   warnings about pointer types
int _ll_addafter ( pLList llp, pLLNode lnp_new, pLLNode lnp_old)
{
   assert(llp != NULL);
   assert(lnp_old != NULL);
   assert(lnp_new != NULL);
  
   if (!LL_IsMember(llp, lnp_old))
      return (FALSE);
  
   LL_InitNode(lnp_new);
  
   if (!lnp_old->ll_next)
   {
    // effectively an AddTail
      if (!llp->ll_last)
      {
         llp->ll_first = llp->ll_last = lnp_new;
      } else
      {
         lnp_new->ll_prev = llp->ll_last;
         llp->ll_last->ll_next = lnp_new;
         llp->ll_last = lnp_new;
      }
   } else
   {
      lnp_new->ll_prev = lnp_old;
      lnp_new->ll_next = lnp_old->ll_next;
      lnp_old->ll_next->ll_prev = lnp_new;
      lnp_old->ll_next = lnp_new;
   }
   llp->ll_count++;
  
   return(TRUE);
}
  
//-----------------------------------------------
//- int _ll_addbefore ( pLList llp, pLLNode lnp_new, pLLNode lnp_old)
//-   adds node lp_new to list llp before lnp_old, updates count
//-   LL_AddBefore() should be used instead to avoid
//-   warnings about pointer types
int _ll_addbefore ( pLList llp, pLLNode lnp_new, pLLNode lnp_old)
{
  
   assert(llp != NULL);
   assert(lnp_old != NULL);
   assert(lnp_new != NULL);
  
   if (!LL_IsMember(llp, lnp_old))
      return (FALSE);
  
   LL_InitNode(lnp_new);
  
   if (!lnp_old->ll_prev)
   {
    // effectivel an AddHead
      if (!llp->ll_first)
         llp->ll_first = llp->ll_last = lnp_new;
      else
      {
         lnp_new->ll_next = llp->ll_first;
         llp->ll_first->ll_prev = lnp_new;
         llp->ll_first = lnp_new;
      }
   } else
   {
      lnp_new->ll_prev = lnp_old->ll_prev;
      lnp_new->ll_next = lnp_old;
      lnp_old->ll_prev->ll_next = lnp_new;
      lnp_old->ll_prev = lnp_new;
   }
   llp->ll_count++;
  
   return(TRUE);
}
  
//-----------------------------------------------
//- void _ll_remove ( pLList llp, pLLNode lnp)
//-  remove element from list
//-   LL_Remove () should be used instead to avoid
//-   warnings about pointer types
void _ll_remove ( pLList llp, pLLNode lnp)
{
  
   assert(llp != NULL);
   assert(lnp != NULL);
  
   if (llp->ll_first == lnp )
   {
      llp->ll_first = lnp->ll_next;
      if (llp->ll_first)
         llp->ll_first->ll_prev = NULL;
      if (llp->ll_last == lnp)
      {
         llp->ll_last = lnp->ll_prev;
         if (llp->ll_last)
            llp->ll_last->ll_next = NULL;
      }
   } else if (llp->ll_last == lnp)
   {
      llp->ll_last = lnp->ll_prev;
      if (llp->ll_last)
         llp->ll_last->ll_next = NULL;
   } else
   {
      lnp->ll_prev->ll_next = lnp->ll_next;
      lnp->ll_next->ll_prev = lnp->ll_prev;
   }
   LL_InitNode(lnp);
   llp->ll_count--;
}
  
//-----------------------------------------------
//- void LL_Destroy(pLList lp)
//-   destroy entire list held by given linked list header
//-   free's each node, so this should NOT be used if nodes
//-   contain pointers to dynamically allocated memory
//-   leaves header in the Initialized state
//-   client must free header
void LL_Destroy(pLList lp)
{
   pLLNode pn, npn;
   for (pn= LL_First(lp); pn; pn = npn)
   {
      npn = pn->ll_next;
      free(pn);
   }
   lp->ll_first = lp->ll_last = NULL;
   lp->ll_count = 0;
}
  
//-----------------------------------------------
//- void *LL_GetNth(pLList llp, int num)
//-   return pointer to Nth entry. start with 1
void *LL_GetNth(pLList llp, int num)
{
   int i;
   pLLNode np;
  
   assert(llp != NULL);
  
   if (num < 1 || num > llp->ll_count)
      return (NULL);
  
   for ( i=1, np = LL_First(llp);
      np;
      i++, np = LL_Next(np))
      if (i == num) break;
   return (np);
}
  
//-----------------------------------------------
//- int LL_IsMember(pLList lp, pLLNode np)
//-   Return TRUE if is a member of list, False otherwise
int LL_IsMember(pLList lp, pLLNode np)
{
   pLLNode p;
  
   assert(lp != NULL);
  
   for (p= LL_First(lp);p; p=LL_Next(p))
      if (p == np) return TRUE;
  
   return FALSE;
}
  
//-----------------------------------------------
//- int LL_ConCat(pLList dest, pLList source)
//-   concatenate source onto end of dest, null out source
//-   returns total number of nodes in final dest list
int LL_ConCat(pLList dest, pLList source)
{
   pLLNode pn1, pn2;
  
   if (dest->ll_first)
   {
      dest->ll_last->ll_next = source->ll_first;
      source->ll_first->ll_prev = dest->ll_last;
      dest->ll_last = source->ll_last;
   } else
   {
      dest->ll_first = source->ll_first;
      dest->ll_last = source->ll_last;
   }
   dest->ll_count += source->ll_count;
   source->ll_count = 0;
   source->ll_first = source->ll_last = NULL;
  
   return (dest->ll_count);
}
  
//-----------------------------------------------
//- void LL_Reverse(pLList plist)
//-   reverses the given linked list
void LL_Reverse(pLList plist)
{
   pLLNode pn, ptmp;
  
   for (pn = plist->ll_first; pn; pn = ptmp)
   {
      ptmp = pn->ll_next;
      pn->ll_next = pn->ll_prev;
      pn->ll_prev = ptmp;
   }
   ptmp = plist->ll_first;
   plist->ll_first = plist->ll_last;
   plist->ll_last = ptmp;
}
  
//-----------------------------------------------
//- int LL_ReCount(pLList lp)
//-   count number of nodes in list and update count in header
//-   should never really be needed, but ...
int LL_ReCount(pLList lp)
{
   pLLNode p;
   int i;
  
   assert(lp != NULL);
  
   for (i=0,p= LL_First(lp);p; p=LL_Next(p),i++)
      ;
   lp->ll_count = i;
   return(i);
}
  
