// FILE: renum.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- void ieg_RenumObj(pIeObject op)
//-   recounts points and polygons in object
//-   insures that point numbers are correct
void ieg_RenumObj(pIeObject op)
{
   int i = 0;
   pIePoint ppt;
   pIePoly ppoly;
  
   for (ppt = LL_First(op->points); ppt; ppt = LL_Next(ppt))
      ppt->num = ++i;
  
   LL_ReCount(op->polys);
   for (ppoly = LL_First(op->polys);ppoly; ppoly = LL_Next(ppoly))
      LL_ReCount(ppoly->vtx);
}
