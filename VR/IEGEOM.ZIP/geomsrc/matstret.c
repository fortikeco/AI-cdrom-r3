// FILE: matstret.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iematrix.h"
  
//-----------------------------------------------
//- void MatStretch44( Mat44 n, VECTOR v, float a)
//-   matrix stretch == scale along arbitrary axis
void MatStretch44( Mat44 n, VECTOR v, float a)
{
   Mat33 m;
   Mat44 l;
  
   a -= 1;
   MatProject33(v,m);
   m[0][0] = 1.0 + a * m[0][0];
   m[0][1] = a * m[0][1];
   m[0][2] = a * m[0][2];
  
   m[1][0] = a * m[1][0];
   m[1][1] = 1.0 + a * m[1][1];
   m[1][2] = a * m[1][2];
  
   m[2][0] = a * m[2][0];
   m[2][1] = a * m[2][1];
   m[2][2] = 1.0 + a * m[2][2];
  
   MatCvt3344(m,l);
   MatMpy444(n,l,n);
}
  
