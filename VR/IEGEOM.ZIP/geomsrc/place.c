// FILE: place.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- pIeObject ieg_PlaceObj( pIeObject obj1, pIeObject obj2)
//-   create a new object by placing a copy of obj2
//-   at each point of obj1
pIeObject ieg_PlaceObj( pIeObject obj1, pIeObject obj2)
{
   pIePoint ppt;
   pIeObject new_obj, tmp;
   int i;
  
   assert(obj1 != NULL);
   assert(obj2 != NULL);
  
   new_obj = ieg_NewObject();
  
   for (i=1,ppt = LL_First(obj1->points); ppt; ppt = LL_Next(ppt),i++)
   {
      tmp = ieg_CopyObj(obj2);
      ieg_ObjXlate(tmp, ppt->loc.x, ppt->loc.y, ppt->loc.z);
      ieg_CatObj(new_obj,tmp);
      free(tmp);
   }
   return (new_obj);
}
  
  
