// FILE: matxlate.c
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iematrix.h"
  
//-----------------------------------------------
//- void MatTranslate44(Mat44 a, double dx, double dy, double dz)
//-   multiply 4 x 4 matrix a by translation matrix,
//-   translation by dx, dy, dz
void MatTranslate44(Mat44 a, double dx, double dy, double dz)
{
   register  i;
  
   for (i = 0; i < 4; ++i)
   {
      a[i][0] = a[i][0] + a[i][3]*dx;
      a[i][1] = a[i][1] + a[i][3]*dy;
      a[i][2] = a[i][2] + a[i][3]*dz;
   }
}
  
