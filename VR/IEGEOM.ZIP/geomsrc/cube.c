// FILE: cube.c
//
// creates a cube with given min & max points
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include "assert.h"
#include "iegeom.h"
  
//-----------------------------------------------
//- pIeObject ieg_Cube( Point min, Point max)
//-   create cube object oriented parallel to axis
//-   with its min and max points as given
pIeObject ieg_Cube( Point min, Point max)
{
   pIePoint pts[8];
   pIeVertex vtx;
   pIePoly ply;
   pIeObject op;
   int i;
   char name[80];
  
   op = ieg_NewObject();
   op->name = strdup("cube");
  
   for (i = 0; i< 8; i++)
      pts[i] = ieg_NewPoint();
  
   pts[0]->loc.x = min.x; pts[0]->loc.y = min.y; pts[0]->loc.z = min.z;
   pts[1]->loc.x = max.x; pts[1]->loc.y = min.y; pts[1]->loc.z = min.z;
   pts[2]->loc.x = max.x; pts[2]->loc.y = max.y; pts[2]->loc.z = min.z;
   pts[3]->loc.x = min.x; pts[3]->loc.y = max.y; pts[3]->loc.z = min.z;
   pts[4]->loc.x = min.x; pts[4]->loc.y = min.y; pts[4]->loc.z = max.z;
   pts[5]->loc.x = max.x; pts[5]->loc.y = min.y; pts[5]->loc.z = max.z;
   pts[6]->loc.x = max.x; pts[6]->loc.y = max.y; pts[6]->loc.z = max.z;
   pts[7]->loc.x = min.x; pts[7]->loc.y = max.y; pts[7]->loc.z = max.z;
  
   for (i = 0; i< 8; i++)
      ieg_AddPoint(op, pts[i]);
  
  /* FACE 1 */
   ply = ieg_NewPoly();
   vtx = ieg_NewVtx();
   vtx->ppt = pts[0];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[1];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[2];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[3];
   ieg_AddVtx(ply,vtx);
   ieg_AddPoly(op, ply);
  
  /* FACE 2 */
   ply = ieg_NewPoly();
   vtx = ieg_NewVtx();
   vtx->ppt = pts[0];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[3];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[7];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[4];
   ieg_AddVtx(ply,vtx);
   ieg_AddPoly(op, ply);
  
  /* FACE 3 */
   ply = ieg_NewPoly();
   vtx = ieg_NewVtx();
   vtx->ppt = pts[7];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[6];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[5];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[4];
   ieg_AddVtx(ply,vtx);
   ieg_AddPoly(op, ply);
  
  /* FACE 4 */
   ply = ieg_NewPoly();
   vtx = ieg_NewVtx();
   vtx->ppt = pts[6];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[2];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[1];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[5];
   ieg_AddVtx(ply,vtx);
   ieg_AddPoly(op, ply);
  
  /* FACE 5 */
   ply = ieg_NewPoly();
   vtx = ieg_NewVtx();
   vtx->ppt = pts[0];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[1];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[5];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[4];
   ieg_AddVtx(ply,vtx);
   ieg_AddPoly(op, ply);
  
  /* FACE 6 */
   ply = ieg_NewPoly();
   vtx = ieg_NewVtx();
   vtx->ppt = pts[3];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[2];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[6];
   ieg_AddVtx(ply,vtx);
   vtx = ieg_NewVtx();
   vtx->ppt = pts[7];
   ieg_AddVtx(ply,vtx);
   ieg_AddPoly(op, ply);
  
   return (op);
}
