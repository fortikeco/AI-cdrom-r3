// FILE: interp.c
//
// functions to interpolate (morph) between two objects
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
//-----------------------------------------------
//- pIeObject ieg_Interpolate(pIeObject obj1, pIeObject obj2, float amt)
//-   create new object that has interpolated the postions
//-   of points of obj1 towards positions of points in obj2
//-   by the given amount
pIeObject ieg_Interpolate(pIeObject obj1, pIeObject obj2, float amt)
{
   pIeObject nobj;
   pIePoint ppt, npt;
   pIePoly poly1,poly2;
  
   assert(obj1 != NULL);
   assert(obj2 != NULL);
  
   nobj = ieg_CopyObj(obj1);
  
   for(npt=LL_First(nobj->points),ppt=LL_First(obj2->points);
      npt && ppt; npt = LL_Next(npt), ppt = LL_Next(ppt))
   {
      npt->loc.x = (ppt->loc.x * amt) + (1.0 -amt)*npt->loc.x;
      npt->loc.y = (ppt->loc.y * amt) + (1.0 -amt)*npt->loc.y;
      npt->loc.z = (ppt->loc.z * amt) + (1.0 -amt)*npt->loc.z;
   }
  
   return (nobj);
}
  
//-----------------------------------------------
//- pIeObject ieg_UniqueVtx(pIeObject src)
//-   create new object equivalent to source
//-   but with each polygon having unique vertex points
//-   polygon ordering determines ordering of points
//-   thus this can help the interpolation of objects
pIeObject ieg_UniqueVtx(pIeObject src)
{
   pIePoly poly, npoly;
   pIePoint ppt;
   pIeVertex pvtx, nvtx;
   pIeObject dest;
   char name[80];
  
   assert(src != NULL);
  
   dest = ieg_NewObject();
   if (src->name)
      sprintf(name,"%s_unique\n",src->name);
   else
      sprintf(name,"unique\n");
   dest->name = strdup(name);
  
   for (poly = LL_First(src->polys);poly;poly = LL_Next(poly))
   {
      npoly = ieg_NewPoly();
      npoly->flag = poly->flag;
      npoly->color = poly->color;
  
      for (pvtx=LL_First(poly->vtx);pvtx;pvtx= LL_Next(pvtx))
      {
         ppt = ieg_NewPoint();
         *ppt = *(pvtx->ppt);
  
         ieg_AddPoint(dest, ppt);
  
      /* make a new vertex to point at the Point */
         nvtx = ieg_NewVtx();
         nvtx->ppt = ppt;
         ieg_AddVtx(npoly, nvtx);
      }
      ieg_AddPoly(dest,npoly);
   }
  
   return (dest);
}
  
