// FILE: rw_plg.c
//  routines to read/write PLG format objects
//
// created by Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// this code is public domain.
//
// Version 2.0 created November 1992
//
  
#include <assert.h>
#include "iegeom.h"
  
extern int errno;
  
#define IO_STRING  5000
  
//-----------------------------------------------
// strip comments & newline characters
// borrowed this directly from D.Stampe's plg.c
static void strip_comment(char *buff) ;
static void strip_comment(char *buff)
{
   char *p;
  
   if ((p = strchr(buff, '\n')) != NULL) *p = '\0'; /* trim newline */
   if ((p = strchr(buff, '#')) != NULL) *p = '\0'; /* trim comment */
   if ((p = strchr(buff, '*')) != NULL) *p = '\0'; /* future expansion */
}
  
//-----------------------------------------------
static int get_next_line(FILE *fp, char *buf);
static int get_next_line(FILE *fp, char *buf)
{
   char tmp[40];
   do {
      if (fgets( buf, IO_STRING, fp) == NULL)
      {
         eprintf("Error: premature EOF in plg file\n");
         return (FALSE);
      }
      strip_comment(buf);
   } while (sscanf(buf,"%40s",tmp) != 1);
   return(TRUE);
}
  
//-----------------------------------------------
//- pIeObject ieg_ReadPLG (char *name)
//-   read a PLG file from the given filename
//-   assertion errors occur on bad allocates
//-   NULL is returned if a bad read occurs
//-      errors also cause output with eprintf
pIeObject ieg_ReadPLG (char *name)
{
   pIeObject iop = NULL;
   FILE *fp;
  
   fp = fopen(name, "r");
   if (!fp)
   {
      eprintf("Error %d opening file %s\n",errno,name);
      return NULL;
   }
  
   iop = ieg_fpReadPLG( fp);
   fclose(fp);
   return(iop);
}
  
//-----------------------------------------------
//- pIeObject ieg_fpReadPLG (FILE *fp)
//-   read a single PLG from the given FILE*
//-   assertion errors occur on bad allocates
//-   NULL is returned if a bad read occurs
//-      errors also cause output with eprintf
pIeObject ieg_fpReadPLG (FILE *fp)
{
   pIeObject op;
   pIePoint ppt = NULL;
   pIePoly poly = NULL;
   pIeVertex pvtx = NULL;
   pIePoint *parray = NULL;
   int nvtx, npts, npoly, vnum;
   unsigned long color;
   int i, j;
   char name[100]; // used to get object name
   char *buf; // dynamic alloc buffer to read data
   char *p;
   float x, y, z;
  
   buf = calloc(IO_STRING, sizeof(char));
   assert(buf != NULL);
  
  // skip blank & comment lines
   if (!get_next_line(fp,buf))
   {
      eprintf("before found first line!\n");
      return (NULL);
   }
  
   if (sscanf(buf,"%s %d %d",name,&npts,&npoly) != 3)
   {
      eprintf("Error parsing first line of file\n");
      return (NULL);
   }
  
   op = ieg_NewObject();
   op->name = strdup(name); // duplicate the object name
  
   parray = (pIePoint *) calloc( (npts+1),sizeof(pIePoint));
   assert(parray != NULL);
  
   for (i=1; i <= npts;i++)
   {
    // skip blank & comment lines
      if (!get_next_line(fp,buf))
      {
         eprintf("reading point %d of %d\n", i, npts);
         goto error;
      }
  
      if (sscanf(buf,"%f %f %f",&x,&y,&z) != 3)
      {
         eprintf("Error: bad point line. point %d\n", i);
         goto error;
      }
      ppt = ieg_NewPoint();
      ppt->loc.x = x;
      ppt->loc.y = y;
      ppt->loc.z = z;
      parray[i] = ppt; // keep track of point numbers
      ieg_AddPoint(op,ppt);
   }
  
   for (i=1; i<= npoly;i++)
   {
    // skip blank & comment lines
      if (!get_next_line(fp,buf))
      {
         eprintf("reading poly %d of %d\n", i, npoly);
         goto error;
      }
  
    // color read from plg.c: req so hex colors usable
      color = (unsigned) strtoul(buf,&p,0);
  
      p = strtok(p," \t");
      if (!p)
      {
         eprintf("Error: reading poly num vertex\n");
         eprintf("reading poly %d of %d\n", i, npoly);
         goto error;
      }
      if (sscanf(p,"%d", &nvtx) != 1)
      {
         eprintf("Error: converting poly num vertex\n");
         eprintf("reading poly %d of %d\n", i, npoly);
         goto error;
      }
  
      poly = ieg_NewPoly();
      poly->flag = POLY_CLOSED; // all PLG polygons are closed
      poly->color = color;
      for (j=1;j <= nvtx;j++)
      {
         p = strtok(NULL," \t");
         if (sscanf(p,"%d", &vnum) != 1)
         {
            eprintf("Error: reading poly vertex\n");
            eprintf("reading vtx %d of %d (%s)\n", j, nvtx, p);
            eprintf("reading poly %d of %d\n", i, npoly);
            ieg_FreePoly(poly);
            goto error;
         }
         vnum++; // PLG numbers vertices from 0
              // ieg array numbers from 1
         if (vnum < 1 || vnum > npts)
         {
            eprintf("Error: bad poly vertex\n");
            eprintf("reading vtx %d of %d (%s)\n", j, nvtx, p);
            eprintf("reading poly %d of %d\n", i, npoly);
            ieg_FreePoly(poly);
            goto error;
         }
         pvtx = ieg_NewVtx();
         pvtx->ppt = parray[vnum];
         ieg_AddVtx(poly,pvtx);
      }
      ieg_AddPoly(op,poly);
   }
  
   free(buf);
   free(parray);
   return(op);
  
   error:
   free(buf);
   free(parray);
   ieg_FreeObj(op);
   return (NULL);
}
  
//-----------------------------------------------
//- int ieg_WritePLG (pIeObject op, char *name, float scale, int new)
//-   writes the given object to name'd file
//-   uses scale to set object scale, for use with fixed point systems
//-   if (new) file is created/overwritten. If false, then file is
//-   appended to. (useful for #MULTI objects?)
int ieg_WritePLG (pIeObject op, char *name, float scale, int new)
{
   FILE *fp;
   if (new)
      fp = fopen(name, "w");
   else
      fp = fopen(name, "a");
   if (!fp)
   {
      eprintf("Error %d opening file %s\n", errno,name);
      return FALSE;
   }
   ieg_fpWritePLG ( op, fp, scale);
   fclose(fp);

	return TRUE;
}
  
//-----------------------------------------------
//- void ieg_fpWritePLG (pIeObject op, FILE *fp, float scale)
//-   writes the given object to open'd FILE*
//-   uses scale to set object scale, for use with fixed point systems
void ieg_fpWritePLG (pIeObject op, FILE *fp, float scale)
{
   pIePoint ppt;
   pIePoly poly;
   pIeVertex pvtx;
  
   assert(op != NULL);
   assert(fp != NULL);
  
   ieg_RenumObj(op);
  
   fprintf(fp,"# Ascii IeGeom Object, PLG format \n");
   if (op->name)
      fprintf(fp,"%s %d %d\n",
      op->name, ieg_NumPoints(op), ieg_NumPolys(op));
   else
      fprintf(fp,"noname %d %d\n",ieg_NumPoints(op), ieg_NumPolys(op));
  
   fprintf(fp,"# Points\n");
   for (ppt = LL_First(op->points); ppt; ppt = LL_Next(ppt))
      fprintf( fp, "%ld %ld %ld\n",
      (long)(ppt->loc.x*scale),
      (long)(ppt->loc.y*scale),
      (long)(ppt->loc.z*scale));
  
   fprintf(fp,"# Polys\n");
   for (poly = LL_First(op->polys); poly; poly = LL_Next(poly))
   {
      fprintf( fp, "0x%lx %d ", poly->color, ieg_NumVtx(poly));
      for (pvtx = LL_First(poly->vtx); pvtx; pvtx = LL_Next(pvtx))
         fprintf( fp, "%d ", pvtx->ppt->num-1);
      // PLG numbers vertices from 0, ieg numbers from 1
      fprintf( fp, "\n");
   }
   fprintf( fp, "\n");
}
  
  
  
