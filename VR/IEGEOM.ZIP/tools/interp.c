// FILE: interp.c
//
// main routine for Interpolate program
//		interpolate between two objects
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf( "\
   Creates an object that is the interpolation between two input objects\n\
	by interpolating between the corresponding points of the inputs\n");
eprintf("Usage: %s -a amt obj1 obj2 outfile\n",progname);
eprintf("\
   -a amt  The linear percentage of distance from obj1 to obj2\n\
	        note: should be between 0 and 1.0 for best results\n\
			  values over 1 or negative will have strange results\n");
   exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   pIeObject iop1 = NULL;
   pIeObject iop2 = NULL;
   char infile1[MAXPATH];
   char infile2[MAXPATH];
   char outfile[MAXPATH];
	float amount;

	infile1[0] = NULL;
	infile2[0] = NULL;
	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();

	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
		{
	      switch (argv[0][1])
			{
				case 'a':
					if (argv[1] == NULL) 
					{
						eprintf("%s: mising amt given\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&amount) != 1)
					{
						eprintf( "%s: Bad amount given: %s\n", progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					break;
				default:
					eprintf("Unkown Option %s\n",argv[0]);
					Usage();
			}
	   } else if (!infile1[0]) 
		{
			strcpy( infile1, argv[0]);
		   argc--; argv++;
	   } else if (!infile2[0]) 
		{
			strcpy( infile2, argv[0]);
		   argc--; argv++;
		} else 
		{
		   strcpy(outfile,argv[0]);
			argc--; argv++;
	   }
   }

	if (!infile1[0] || !infile2[0])
	{
		eprintf("Missing input file\n");
		Usage();
	}
	if (!outfile[0])
	{
		eprintf("%s: missing output file\n", progname);
		Usage();
	}

//-----------------------------------------------
	eprintf( "Interpolate %g percent from %s towards %s\n",
		amount, infile1, infile2);
	eprintf( "Output to %s\n", outfile);

	iop1 = ieg_ReadPLG( infile1);
	if (!iop1)
	{
		eprintf( "Error Reading input file 1: %s\n", infile1);
		return;
	}

	eprintf("Input Object 1 contains %d points and %d faces\n", 
		ieg_NumPoints(iop1), ieg_NumPolys(iop1));

	iop2 = ieg_ReadPLG( infile2);
	if (!iop2)
	{
		eprintf( "Error Reading input file 2: %s\n", infile2);
		return;
	}

	eprintf("Input Object 2 contains %d points and %d faces\n", 
		ieg_NumPoints(iop2), ieg_NumPolys(iop2));

	oop = ieg_Interpolate(iop1, iop2, amount);

//-----------------------------------------------
	eprintf("Output Object contains %d points and %d faces\n", 
		ieg_NumPoints(oop), ieg_NumPolys(oop));

	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

