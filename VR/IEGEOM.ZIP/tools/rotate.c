// FILE: rotate.c
//
// main routine for ROTATE program
//   rotates an object in 3D
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf("   Rotates object about one or more axis in order specified\n\
   Rotations can be about the origin, object center, or a specified point.\n");
eprintf("Usage: %s infile outfile [-x deg] [-y deg] [-z deg] ...\n\
   [-a xval yval zval deg] [-c | -p x y z]\n", progname);
eprintf( "\
   -x deg | -y deg | -z deg\n\
      Rotate specified degrees about given axis.\n\
   -a xval yval zval deg\n\
      Rotate about the axis defined by the vector (xval, yval, zval).\n\
   -c\n\
      Rotate about center of bounding box. Applies to ALL rotations\n\
   -p x y z\n\
      Rotate about the given point. Applies to ALL rotations\n");
exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   pIeObject iop = NULL;
   char infile[MAXPATH];
   char outfile[MAXPATH];
   int inflag = FALSE;

	Point max, min, point;
	Vector axis;
	int cFlag = FALSE;
	int pFlag = FALSE;
	float deg;
	Mat44 matrix, tmpMatrix;

	int i;

	infile[0] = NULL;
	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	MatIdentity44( matrix);
	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
	      switch (argv[0][1])
			{
				case 'x':
					if(argv[1] == NULL) 
					{
						eprintf("%s: ERROR: no x deg given\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&deg) != 1)
					{
						eprintf( "%s: Bad x deg given: %s\n", progname, argv[0]);
						exit(0);
					}
					MatRotate44(matrix,&Xaxis,DEGTORAD(deg));
					argc--; argv++;
					break;
				case 'y':
					if (argv[1] == NULL) 
					{
						eprintf(  "%s: ERROR: no y deg given\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&deg) != 1)
					{
						eprintf( "%s Bad y deg given: %s\n", progname, argv[0]);
						exit(0);
					}
					MatRotate44(matrix,&Yaxis,DEGTORAD(deg));
					argc--; argv++;
					break;
				case 'z':
					if (argv[1] == NULL) 
					{
						eprintf( "%s: ERROR: no z deg given\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&deg) != 1)
					{
						eprintf( "%s: Bad z deg given: %s\n", progname, argv[0]);
						exit(0);
					}
					MatRotate44(matrix,&Zaxis,DEGTORAD(deg));
					argc--; argv++;
					break;
				case 'a':
					if (argc < 5) 
					{
						eprintf("%s: -a requires 5 values\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&axis.x) != 1)
					{
						eprintf( "%s: -a x value given: %s is not a number\n", progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&axis.y) != 1)
					{
						eprintf( "%s: -a y value given: %s is not a number\n", progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&axis.z) != 1)
					{
						eprintf( "%s: -a z value given: %s is not a number\n", progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&deg) != 1)
					{
						eprintf( "%s: -a deg value given: %s is not a number\n", progname, argv[0]);
						exit(0);
					}
					MatRotate44(matrix,&axis,DEGTORAD(deg));
					argc--; argv++;
					break;
				case 'p':
					if (cFlag)
					{
						eprintf("%s: cant use -c with -p\n");
						exit(0);
					}
					if (argc < 4) 
					{
						eprintf("%s: -p requires 5 values\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&point.x) != 1)
					{
						eprintf( "%s: -p x value given: %s is not a number\n", progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&point.y) != 1)
					{
						eprintf( "%s: -p y value given: %s is not a number\n", progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&point.z) != 1)
					{
						eprintf( "%s: -p z value given: %s is not a number\n", 
							progname, argv[0]);
						exit(0);
					}
					pFlag = TRUE;
					argc--; argv++;
					break;
				case 'c' :
					if (pFlag)
					{
						eprintf("%s: cant use -c with -p\n");
						exit(0);
					}
					cFlag = TRUE;
		   		argc--; argv++;
					break;
				default:
					eprintf("Unkown Option %s\n",argv[0]);
					Usage();
		  }
		else if (inflag) 
		{
		   strcpy(outfile,argv[0]);
		   argc--; argv++;
		} else {
			strcpy( infile, argv[0]);
			argc--; argv++;
			inflag = TRUE;
	   }
   }

	if (!inflag)
		Usage();
	if (outfile[0] == 0)
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}

//-----------------------------------------------
	eprintf( "Reading from %s\n", infile);
	eprintf( "Output to %s\n", outfile);

	iop = ieg_ReadPLG( infile);
	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return;
	}

	eprintf("Input Object contains %d points and %d faces\n", 
		ieg_NumPoints(iop), ieg_NumPolys(iop));

//-----------------------------------------------
	if (cFlag) 
	{
		MatIdentity44(tmpMatrix);
		ieg_BBox(iop, &min, &max);
		point.x = (max.x + min.x)/2.0;
		point.y = (max.y + min.y)/2.0;
		point.z = (max.z + min.z)/2.0;
		MatTranslate44(tmpMatrix,-point.x,-point.y,-point.z);
		MatMpy444(matrix,tmpMatrix,matrix);
		eprintf("BBox coords:\n Max %g %g %g\n Min %g %g %g\n",
				max.x, max.y, max.z,	min.x, min.y, min.z);
		eprintf("Center: %g %g %g\n",point.x,point.y,point.z);
		MatTranslate44(matrix,point.x,point.y,point.z);
	} else if (pFlag) 
	{
		MatIdentity44(tmpMatrix);
		MatTranslate44(tmpMatrix, -point.x, -point.y, -point.z);
		MatMpy444( matrix, tmpMatrix, matrix);
		MatTranslate44(matrix,point.x,point.y,point.z);
	}

	eprintf("Rotation Matrix:\n");
	MatEPrint44(matrix);

	oop = iop;
	ieg_ObjMat44( matrix, oop);

//-----------------------------------------------
	eprintf("Output Object contains %d points and %d faces\n", 
		ieg_NumPoints(oop), ieg_NumPolys(oop));

	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

