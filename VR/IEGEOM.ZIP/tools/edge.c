// FILE: edge.c
//
// main routine for Edge program
//		'edges' polygons of input object
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf( "\
   Replace each polygon with set of polys around the original edges\n\
	size of edge polys is specified by percentage amount\n\
	to shrink away from center of polygon.\n");
eprintf("Usage: %s -a amt infile outfile\n",progname);
eprintf("\
   -a amt  The percentage to shrink away from center of each polygon\n\
	        note: should be between 0 and 1.0 for best results\n\
			  values over 1 or negative will have strange results\n");

   exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   pIeObject iop = NULL;
   char infile[MAXPATH];
   char outfile[MAXPATH];
   int inflag = FALSE;
	float amount;

	infile[0] = NULL;
	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();

	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
		{
	      switch (argv[0][1])
			{
				case 'a':
					if (argv[1] == NULL) 
					{
						eprintf("%s: mising amt given\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&amount) != 1)
					{
						eprintf( "%s: Bad amount given: %s\n", progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					break;
				default:
					eprintf("Unkown Option %s\n",argv[0]);
					Usage();
			}
	   } else if (inflag) 
		{
		   strcpy(outfile,argv[0]);
		   argc--; argv++;
		} else 
		{
			strcpy( infile, argv[0]);
			argc--; argv++;
			inflag = TRUE;
	   }
   }

	if (!inflag)
		Usage();
	if (!outfile[0])
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}

	eprintf( "Reading from %s\n", infile);
	eprintf( "Output to %s\n", outfile);

	iop = ieg_ReadPLG( infile);
	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return;
	}

	eprintf("Input Object contains %d points and %d faces\n", 
		ieg_NumPoints(iop), ieg_NumPolys(iop));
//-----------------------------------------------

	oop = ieg_Edge(iop, amount);

	eprintf("Output Object contains %d points and %d faces\n", 
		ieg_NumPoints(oop), ieg_NumPolys(oop));

//-----------------------------------------------
	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

