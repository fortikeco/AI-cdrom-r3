// FILE: scale.c
//
// main routine for SCALE program
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf("   Scale an object in one or more directions.\n");
eprintf("Usage: %s [-x amt] [-y amt] [-z amt] [-g amt] ...\n\
   [-a xval yval zval amt] infile outfile\n",progname);
eprintf( "\
   -x amt | -y amt | -z amt\n\
      Scale object specified amount along x, y and/or z axis\n\
   -g amt\n\
      Globally scale object specified amount\n\
   -a xval yval zval amt\n\
      Scale along vector (xval yval zval) by amt (Vector NOT normalized\n");
exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   pIeObject iop = NULL;
   char infile[MAXPATH];
   char outfile[MAXPATH];
   int inflag = FALSE;

	Point max, min;
	Vector axis;
	float amt;
	Mat44 matrix;

	infile[0] = NULL;
	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

//-----------------------------------------------
   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	MatIdentity44( matrix);

	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
		{
	      switch (argv[0][1])
			{
			case 'x':
				if (argv[1] == NULL) 
				{
					eprintf("%s: ERROR: no x amt given\n", progname);
					exit(0);
				}
				argc--; argv++;
				if (sscanf(argv[0],"%f",&amt) != 1)
				{
					eprintf( "%s: Bad x amt given: %s\n", progname, argv[0]);
					exit(0);
				}
				MatScale44( matrix, amt, 1.0, 1.0, 1.0);
				argc--; argv++;
				break;
			case 'y':
				if (argv[1] == NULL) 
				{
					eprintf(  "%s: ERROR: no y amt given\n", progname);
					exit(0);
				}
				argc--; argv++;
				if (sscanf(argv[0],"%f",&amt) != 1)
				{
					eprintf( "%s Bad y amt given: %s\n", progname, argv[0]);
					exit(0);
				}
				MatScale44( matrix, 1.0, amt, 1.0, 1.0);
				argc--; argv++;
				break;
			case 'z':
				if (argv[1] == NULL) 
				{
					eprintf( "%s: ERROR: no z amt given\n", progname);
					exit(0);
				}
				argc--; argv++;
				if (sscanf(argv[0],"%f",&amt) != 1)
				{
					eprintf( "%s: Bad z amt given: %s\n", progname, argv[0]);
					exit(0);
				}
				MatScale44( matrix, 1.0, 1.0, amt, 1.0);
				argc--; argv++;
				break;
			case 'g':
				if (argv[1] == NULL) 
				{
					eprintf(  "%s: ERROR: no y amt given\n", progname);
					exit(0);
				}
				argc--; argv++;
				if (sscanf(argv[0],"%f",&amt) != 1)
				{
					eprintf( "%s Bad y amt given: %s\n", progname, argv[0]);
					exit(0);
				}
				MatScale44( matrix, amt, amt, amt, 1.0);
				argc--; argv++;
				break;
			case 'a':
				if (argc < 5) 
				{
					eprintf("%s: -a requires 5 values\n", progname);
					exit(0);
				}
				argc--; argv++;
				if (sscanf(argv[0],"%f",&axis.x) != 1)
				{
					eprintf( "%s: -a x value given: %s is not a number\n", progname, argv[0]);
					exit(0);
				}
				argc--; argv++;
				if (sscanf(argv[0],"%f",&axis.y) != 1)
				{
					eprintf( "%s: -a y value given: %s is not a number\n", progname, argv[0]);
					exit(0);
				}
				argc--; argv++;
				if (sscanf(argv[0],"%f",&axis.z) != 1)
				{
					eprintf( "%s: -a z value given: %s is not a number\n", progname, argv[0]);
					exit(0);
				}
				argc--; argv++;
				if (sscanf(argv[0],"%f",&amt) != 1)
				{
					eprintf( "%s: -a amnt value given: %s is not a number\n", progname, argv[0]);
					exit(0);
				}
				MatStretch44( matrix, &axis, amt);
				argc--; argv++;
				break;
			default:
				eprintf("Unkown Option %s\n",argv[0]);
				Usage();
		  }
	   } else 
		{
			if (inflag) 
			{
			   strcpy(outfile,argv[0]);
			   argc--; argv++;
			} else 
			{
				strcpy( infile, argv[0]);
				argc--; argv++;
				inflag = TRUE;
			}
	   }
   }
//-----------------------------------------------

	if (!inflag)
		Usage();
	if (outfile[0] == 0)
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}

	eprintf( "Reading from %s\n", infile);
	eprintf( "Output to %s\n", outfile);

	iop = ieg_ReadPLG( infile);
	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return;
	}

	eprintf("Input Object contains %d points and %d faces\n", 
		ieg_NumPoints(iop), ieg_NumPolys(iop));

//-----------------------------------------------
	eprintf("Translation Matrix:\n");
	MatEPrint44(matrix);

	oop = iop;
	ieg_ObjMat44( matrix, oop);

//-----------------------------------------------
	eprintf("Output Object contains %d points and %d faces\n", 
		ieg_NumPoints(oop), ieg_NumPolys(oop));

	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

