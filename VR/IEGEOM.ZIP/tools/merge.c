// FILE: merge.c
//
// main routine for MERGE program
//   merges input objects into one single object
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

// forward reference
pIeObject dofile(char *infile);

//-----------------------------------------------
void Usage(void) 
{
/* eprintf( "Isdale Engineering Modeling Tool: %s\n", pathname);*/
eprintf("%s\n",pathname);
eprintf( "   Merges all input objects into one output object\n");
eprintf( "   Wildcards '*' can be used in the file names\n");
eprintf("Usage: %s [-o outfile] infile [infile*]\n",progname);
eprintf( "\
   -o outfile\n\
      Name of output file. Default is 'merge.plg'\n");
exit(0);
}

//-----------------------------------------------
// this tool does most of its processing in the input loop
// each argument is treated as a file name (except -o filename)
// and is read and added to the internal merged object
// when all input has been read, the output file is created
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   pIeObject iop = NULL;
   char infile[MAXPATH];
   char outfile[MAXPATH];
   int inflag = FALSE;

	struct ffblk ffblk;
	char drive[MAXDRIVE];
   char path[MAXPATH];
   char filename[MAXPATH];

	pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);
 
	strcpy (outfile, "merge.plg");

	// set error reporting to stdout
	eopenf(NULL);

   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
		{
	      switch (argv[0][1])
			{
	   	    case 'o':
		   		if (argv[1] == NULL) 
					{
		   			eprintf("%s: ERROR no output file given\n",progname);
	   				Usage();
		   		}
	   			argc--; argv++;
					strcpy(outfile,argv[0]);
	   			argc--; argv++;
				break;
			default:
				eprintf("Unkown Option %s\n",argv[0]);
				Usage();
		  }
	   } else 
		{
			strcpy( infile, argv[0]);
			argc--; argv++;
			if (findfirst( infile, &ffblk, 0) == 0) 
			{
				fnsplit(infile, drive, path, NULL, NULL);
				sprintf(filename,"%s%s%s", drive, path, ffblk.ff_name);
				if (!oop)
					oop = dofile( filename);
				else 
				{
					iop = dofile( filename);
					if (iop)
					{
						ieg_CatObj(oop, iop);
						ieg_FreeObj(iop);
					}
				}
				while( findnext(&ffblk) >=0) 
				{
					sprintf(filename,"%s%s%s", drive, path, ffblk.ff_name);
					if (!oop)
						oop = dofile( filename);
					else 
					{
						iop = dofile( filename);
						if (iop)
						{
							ieg_CatObj(oop, iop);
							ieg_FreeObj(iop);
						}
					}
				}
			}
			inflag = TRUE;
	   }
   }

	if (!inflag)
	{
		eprintf("%s: Missing input files\n", progname);
		exit(0);
	}

	if (oop == NULL)
	{
		eprintf("%s: Null object merge... no output created\n", progname);
		exit(1);
	}

	eprintf("\nOutput Object %s contains %d points and %d faces\n", 
			outfile,	ieg_NumPoints(oop), ieg_NumPolys(oop));

	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

//-----------------------------------------------
pIeObject dofile(char *infile)
{
   pIeObject iop = NULL;

	strlwr(infile);

	eprintf("\nReading from %s\n", infile);

	iop = ieg_ReadPLG( infile);
	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return(NULL);
	}

	eprintf("\tinput object has %d point and %d faces\n", 
		ieg_NumPoints(iop), ieg_NumPolys(iop));

	return(iop);
}
