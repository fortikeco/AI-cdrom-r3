// FILE: reverse.c
//
// main routine for Reverse program
//		reverses all polygons in an object
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf( "\
	reverses all polygons in input object\n");
	eprintf("Usage: %s infile outfile\n",progname);
   exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject iop = NULL;
   char infile[MAXPATH];
   char outfile[MAXPATH];
   int inflag = FALSE;

	Point max, min;


	infile[0] = NULL;
	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();

	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
		{
		 	Usage();
	   } else if (inflag) 
		{
		   strcpy(outfile,argv[0]);
		   argc--; argv++;
		} else 
		{
			strcpy( infile, argv[0]);
			argc--; argv++;
			inflag = TRUE;
	   }
   }

	if (!inflag)
		Usage();
	if (!outfile[0])
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}

	eprintf( "Reading from %s\n", infile);
	eprintf( "Output to %s\n", outfile);
//-----------------------------------------------

	iop = ieg_ReadPLG( infile);
	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return;
	}

	eprintf("Object contains %d points and %d faces\n", 
		ieg_NumPoints(iop), ieg_NumPolys(iop));

	ieg_ReverseObj(iop);

//-----------------------------------------------
	ieg_WritePLG ( iop, outfile, 1.0, TRUE);
}

