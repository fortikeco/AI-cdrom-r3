// FILE: cube.c
//
// main routine for cube program
//		Make an object consisting of a cube
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXPATH];
char tmpname[MAXPATH];

#define DEF_MIN 0.0
#define DEF_MAX 1.0

//-----------------------------------------------
void Usage(void)
{
/* eprintf( "Isdale Engineering Modeling Tool: %s\n", pathname);*/
eprintf("%s\n",pathname);
eprintf( "   Creates a cube object, default is unit cube\n");
eprintf( "Usage: %s [-m x y z] [-M x y z] outfile\n", progname);
eprintf( "\
   -m x y z\n\
      min point of cube in X Y Z, (default = %g)\n\
   -M x y z\n\
      max point of cube in X Y Z, (default = %g)\n", DEF_MIN, DEF_MAX);
exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   char outfile[MAXPATH];
   int inflag = FALSE;
   
   Point min, max;
	min.x = min.y = min.z = DEF_MIN;
	max.x = max.y = max.z = DEF_MAX;

	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
			switch (argv[0][1])
			{
	   		case 'm':
			   	if (argc < 4)
					{
		   			eprintf( "%s: -m missing values\n",	progname);
						exit(0);
					}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%f",&min.x) != 1)
					{
	   				eprintf( "%s: ERROR Bad -m X value : %s\n", 
							progname,argv[0]);
						exit(0);
					}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%f",&min.y) != 1)
					{
	   				eprintf( "%s: ERROR Bad -m Y value : %s\n", 
							progname,argv[0]);
						exit(0);
					}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%f",&min.z) != 1)
					{
	   				eprintf( "%s: ERROR Bad -m Z value : %s\n", 
							progname,argv[0]);
						exit(0);
					}
	   			argc--; argv++;
					break;
	   		case 'M':
			   	if (argc < 4)
					{
		   			eprintf( "%s: -M missing values\n",	progname);
						exit(0);
					}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%f",&max.x) != 1)
					{
	   				eprintf( "%s: ERROR Bad -M X value : %s\n", 
							progname,argv[0]);
						exit(0);
					}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%f",&max.y) != 1)
					{
	   				eprintf( "%s: ERROR Bad -M Y value : %s\n", 
							progname,argv[0]);
						exit(0);
					}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%f",&max.z) != 1)
					{
	   				eprintf( "%s: ERROR Bad -M Z value : %s\n", 
							progname,argv[0]);
						exit(0);
					}
	   			argc--; argv++;
					break;
				default:
					eprintf("%s: Unkown Option %s\n",progname, argv[0]);
					exit(0);
		  }
		else if (inflag) 
		{
			eprintf("%s: only one output file per run\n", progname);
			exit(0);
		} else {
		   strcpy( outfile, argv[0]);
		   argc--; argv++;
			inflag = TRUE;
	   }
   }

	if (!inflag) 
	{
		Usage();
	}
	if (outfile[0] == NULL)
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}
					  
	eprintf( "Output to %s\n", outfile);
//-----------------------------------------------

	oop = ieg_Cube( min, max);
	if (!oop)
	{
		eprintf("%s:Cant make cube\n", progname);
		exit(1);
	}

	eprintf("Output object has %d points and %d faces\n", 
			ieg_NumPoints(oop), ieg_NumPolys(oop));

//-----------------------------------------------
	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

