// FILE: sphere.c
//
// main routine for sphere program
//		Make an object consisting of a sphere
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXPATH];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf( "   Creates a sphere object\n");
eprintf( "Usage: %s [-r radius] [-f nfacets] [-x] outfile\n", progname);
eprintf( "\
   -r radius\n\
      radius of sphere, (default = 1.0)\n\
   -f nfacets\n\
      number of latitude and longitudinal sections. (Default = 6)\n\
   -x do not extrude\n\
      creates a 'fin' object of arcs instead of a sphere\n");
exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   char outfile[MAXPATH];
   int inflag = FALSE;
   
   int nfacet = 6;
   float radius = 1.0;
	int extrude = TRUE;

	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

//-----------------------------------------------
   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
		{
			switch (argv[0][1])
			{
	   		case 'r':
			   	if (argv[1] == NULL)
					{
		   			eprintf( "%s: -r missing radius\n",	progname);
						exit(0);
					}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%f",&radius) != 1)
					{
	   				eprintf( "%s: ERROR Bad -r radius : %s\n", 
							progname,argv[0]);
						exit(0);
					}
	   			argc--; argv++;
					break;
	   	    case 'f':
		   		if (argv[1] == NULL) 
					{
		   			eprintf(  "%s: ERROR no facets given\n", progname);
						exit(0);
					}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%d",&nfacet) != 1)
					{
	   				eprintf( "%s: ERROR Bad -f facets : %s\n", 
							progname,argv[0]);
						exit(0);
					}
	   			argc--; argv++;
					break;
				case 'x' :
		   		argc--; argv++;
					extrude = FALSE;
					break;
				default:
				{
					eprintf("%s: Unkown Option %s\n",progname, argv[0]);
					exit(0);
				}
		  }
		} else if (inflag) 
		{
			eprintf("%s: only one output file per run\n", progname);
			exit(0);
		} else 
		{
		   strcpy( outfile, argv[0]);
		   argc--; argv++;
			inflag = TRUE;
	   }
   }
//-----------------------------------------------

	if (!inflag) 
		Usage();

	if (outfile[0] == NULL)
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}
					  
	eprintf( "Output to %s\n", outfile);
	eprintf( "Radius = %g, Num Facets = %d\n", radius, nfacet);
	if (extrude)
		eprintf("extruded to sphere\n");
	else
		eprintf("left as fin cross sections\n");

//-----------------------------------------------
	oop = ieg_Sphere( radius, nfacet, extrude);
	if (oop)
	{
		eprintf("%s:Cant make sphere\n", progname);
		exit(0);
	}

//-----------------------------------------------
	eprintf("Output object has %d points and %d faces\n", 
			ieg_NumPoints(oop), ieg_NumPolys(oop));

	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

