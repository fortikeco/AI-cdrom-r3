// FILE: place.c
//
// main routine for Place program
//		places a second object at each point of the first
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf("   Place an object at each point of another object\n");
eprintf("   Places the infile object at each point of the object in pointfile\n\
   Simple copy operation if point object file is missing.)\n");
eprintf("Usage: %s [-p pointfile] infile outfile\n",progname);
eprintf( "\
   -p pointfile\n\
      Name of file containing points at which to position infile\n");
exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   pIeObject iop = NULL;
   char infile[MAXPATH];
   char outfile[MAXPATH];
   int inflag = FALSE;

   pIeObject pop = NULL;
   char pointfile[MAXPATH];
	int pointFlag = FALSE;

	infile[0] = NULL;
	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
	      switch (argv[0][1])
			{
	   	    case 'p':
		   		if (argv[1] == NULL) 
					{
		   			eprintf("%s: ERROR no pointfile given\n",	progname);
	   				Usage();
		   		}
	   			argc--; argv++;
				strcpy( pointfile, argv[0]);
				pointFlag = TRUE;
	   			argc--; argv++;
				break;
			default:
				eprintf("Unkown Option %s\n",argv[0]);
				Usage();
		  }
	   else 
		{
			if (inflag) 
			{
			   strcpy(outfile,argv[0]);
			   argc--; argv++;
			} else 
			{
				strcpy( infile, argv[0]);
				argc--; argv++;
				inflag = TRUE;
			}
	   }
   }

	if (!inflag)
		Usage();
	if (outfile[0] == 0)
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}

	eprintf( "Reading from %s\n", infile);
	eprintf( "Output to %s\n", outfile);
	
//-----------------------------------------------
	if (pointFlag)
		eprintf( "Point object: %s\n", pointfile);

	iop = ieg_ReadPLG( infile);
	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return;
	}

	eprintf("Input Object contains %d points and %d faces\n", 
		ieg_NumPoints(iop), ieg_NumPolys(iop));

//-----------------------------------------------
	if (pointFlag) 
	{
		pop = ieg_ReadPLG( pointfile);
		if (!pop)
		{
			eprintf("Error reading point file %s\n", pointfile);
			exit(0);
		}

		eprintf("Point Object contains %d points and %d faces\n", 
			ieg_NumPoints(pop), ieg_NumPolys(pop));

		oop = ieg_PlaceObj( pop, iop);

	} else
		oop = iop;

	ieg_RenumObj(oop);

//-----------------------------------------------
	eprintf("Output Object contains %d points and %d faces\n", 
		ieg_NumPoints(oop), ieg_NumPolys(oop));

	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}
