// FILE: weld.c
//
// main routine for WELD program
//		combines vertices within given neighborhood
//		removes unused vertices & degenerate polygons
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf( "\
   Weld neighboring points into single point\n\
   Points within a cube of given size are combined into \n\
	a single point. This removes holes that often occur \n\
	when digitizing or combining objects\n\
	also removes duplicat consecutive vertices, degenerate polys\n\
	(less than three vertices) and unused points\n");
eprintf("Usage: %s [-d distance] [infile] [outfile]\n", progname);
eprintf("\
   -d distance\n\
      consolidate points within specified distance\n\
      Default = 0.0 (Exact match in x, y and z)\n");
exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   pIeObject iop = NULL;
   char infile[MAXPATH];
   char outfile[MAXPATH];
   int inflag = FALSE;

	float distance = 0.0000001;
	int numWeld;
	int numRm;

	infile[0] = NULL;
	outfile[0] = NULL;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

//-----------------------------------------------
   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
		{
	      switch (argv[0][1])
			{
				case 'd' :
		   		if (argv[1] == NULL) 
					{
		   			eprintf("%s: ERROR no distance given\n",pathname);
	   				Usage();
		   		}
		   		argc--; argv++;
	   			if (sscanf(argv[0],"%f",&distance) != 1)
					{
	   				eprintf("%s: ERROR Bad -w distance : %s\n",
	   			    	pathname,argv[0]);
		   			Usage();
		   		}
		   		argc--; argv++;
				break;
			case 'H':
				/* the standard help flag */
				Usage();
			default:
				eprintf("Unkown Option %s\n",argv[0]);
				Usage();
		  }
		} else if (inflag) 
		{
		   strcpy(outfile,argv[0]);
		   argc--; argv++;
		} else 
		{
			strcpy( infile, argv[0]);
			argc--; argv++;
			inflag = TRUE;
		}
   }
//-----------------------------------------------

	if (!inflag)
		Usage();
	if (outfile[0] == 0)
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}

	eprintf( "Reading from %s\n", infile);
	eprintf( "Output to %s\n", outfile);

	iop = ieg_ReadPLG( infile);
	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return;
	}

	eprintf("Input Object contains %d points and %d faces\n", 
		ieg_NumPoints(iop), ieg_NumPolys(iop));

//-----------------------------------------------
	oop = iop;

	numWeld = ieg_WeldPoints( oop, (double) distance);
	eprintf("Welded %d points\n", numWeld);

	eprintf("Remove repeat vertex references: ");
	numRm = ieg_RmRepeatRef(oop);
		eprintf("%d removed\n", numRm);

	eprintf("Remove degenerate polygons: ");
	numRm = ieg_RmDegenPoly(oop);
		eprintf("%d removed\n", numRm);

	eprintf("Remove unused points: ");
	numRm = ieg_RmUnusedPoints( oop);
		eprintf("%d removed\n", numRm);

//-----------------------------------------------
	eprintf("Output Object contains %d points and %d faces\n", 
		ieg_NumPoints(oop), ieg_NumPolys(oop));

	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

