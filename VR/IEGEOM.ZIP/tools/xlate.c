// FILE: xlate.c
//
// main routine for XLATE program
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

extern int errno;
char *pathname;
char progname[MAXFILE];
char tmpname[MAXPATH];

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf( "   Translate an object in one or more directions.\n\
	Translations are applied in order specified.\n");
eprintf("Usage: %s [-m] [-c] [-x amt] [-y amt] [-z amt] ...\n\
   [-a xval yval zval amt] infile outfile\n",progname);
eprintf( "\
   -m Translate minimum corner of bounding box to origin\n\
   -c Translate center of bounding box to origin\n\
   -x amt | -y amt | -z amt\n\
      Translate object specified amount along x, y and/or z axis\n\
   -a xval yval zval amt\n\
      Translate along vector (xval yval zval) by amt (Vector NOT normalized\n");
exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   pIeObject oop = NULL;
   pIeObject iop = NULL;
   char infile[MAXPATH];
   char outfile[MAXPATH];
   int inflag = FALSE;

	Point max, min;
	Vector axis;
	int cFlag = FALSE;
	int mFlag = FALSE;
	float amt;
	int i;
	float x,y,z;

	infile[0] = NULL;
	outfile[0] = NULL;
	x = y = z = 0.0;

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

//-----------------------------------------------
   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
		{
	      switch (argv[0][1])
			{
				case 'm':
					if (cFlag)
					{
						eprintf("%s: cannot spec -m and -c\n",progname);
						exit(0);
					}
					mFlag = TRUE;
					argc--;argv++;
					break;
				case 'c':
					if (mFlag)
					{
						eprintf("%s: cannot spec -m and -c\n",progname);
						Usage();
					}
					cFlag = TRUE;
					argc--;argv++;
					break;
				case 'x':
					if (argv[1] == NULL) 
					{
						eprintf("%s: ERROR: no x amt given\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&amt) != 1)
					{
						eprintf( "%s: Bad x amt given: %s\n", progname, argv[0]);
						exit(0);
					}
					x +=amt;
					argc--; argv++;
					break;
				case 'y':
					if (argv[1] == NULL) 
					{
						eprintf(  "%s: ERROR: no y amt given\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&amt) != 1)
					{
						eprintf( "%s Bad y amt given: %s\n", progname, argv[0]);
						exit(0);
					}
					y += amt;
					argc--; argv++;
					break;
				case 'z':
					if (argv[1] == NULL) 
					{
						eprintf( "%s: ERROR: no z amt given\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&amt) != 1)
					{
						eprintf( "%s: Bad z amt given: %s\n", progname, argv[0]);
						exit(0);
					}
					z += amt;
					argc--; argv++;
					break;
				case 'a':
					if (argc < 5) 
					{
						eprintf("%s: -a requires 5 values\n", progname);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&axis.x) != 1)
					{
						eprintf( "%s: -a x value given: %s is not a number\n", 
							progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&axis.y) != 1)
					{
						eprintf( "%s: -a y value given: %s is not a number\n", 
							progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&axis.z) != 1)
					{
						eprintf( "%s: -a z value given: %s is not a number\n", 
							progname, argv[0]);
						exit(0);
					}
					argc--; argv++;
					if (sscanf(argv[0],"%f",&amt) != 1)
					{
						eprintf( "%s: -a amnt value given: %s is not a number\n", 
							progname, argv[0]);
						exit(0);
					}
					x += axis.x*amt;
					y += axis.y*amt;
					z += axis.z*amt;
					argc--; argv++;
					break;
				default:
					eprintf("Unkown Option %s\n",argv[0]);
					Usage();
		  }
	   } else if (inflag) 
		{
		   strcpy(outfile,argv[0]);
		   argc--; argv++;
		} else 
		{
			strcpy( infile, argv[0]);
			argc--; argv++;
			inflag = TRUE;
	   }
   }
//-----------------------------------------------

	if (!inflag)
		Usage();
	if (outfile[0] == 0)
	{
		eprintf("%s: missing output file\n", progname);
		exit(1);
	}

	eprintf( "Reading from %s\n", infile);
	eprintf( "Output to %s\n", outfile);

	iop = ieg_ReadPLG( infile);
	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return;
	}

	eprintf("Input Object contains %d points and %d faces\n", 
		ieg_NumPoints(iop), ieg_NumPolys(iop));

//-----------------------------------------------
	if (cFlag) 
	{
		ieg_BBox(iop, &min, &max);
		axis.x = (max.x + min.x)/2.0;
		axis.y = (max.y + min.y)/2.0;
		axis.z = (max.z + min.z)/2.0;
		x -= axis.x;
		y -= axis.y;
		z -= axis.z;
		eprintf("BBox coords:\n Max %g %g %g\n Min %g %g %g\n",
				max.x, max.y, max.z,	min.x, min.y, min.z);
		eprintf("Center: %g %g %g\n",axis.x,axis.y,axis.z);
	} else if (mFlag) 
	{
		ieg_BBox(iop, &min, &max);
		x -= min.x;
		y -= min.y;
		z -= min.z;
		eprintf("BBox coords:\n Max %g %g %g\n Min %g %g %g\n",
				max.x, max.y, max.z,	min.x, min.y, min.z);
	}

	oop = iop;
	ieg_ObjXlate(oop, x, y, z);

//-----------------------------------------------
	eprintf("Output Object contains %d points and %d faces\n", 
		ieg_NumPoints(oop), ieg_NumPolys(oop));

	ieg_WritePLG ( oop, outfile, 1.0, TRUE);
}

