// FILE: info.c
//
// main routine for INFO program
//   reads PLG format object, gives info on it
//
// Created by
// Jerry Isdale
// Isdale Engineering
// 4053 Beethoven St.
// Los Angeles, CA, 90066
//
// This code is public domain
//

#include <dir.h>
#include <dos.h>
#include <iegeom.h>

char *pathname;
char progname[MAXPATH];
char tmpname[MAXPATH];

int memFlag = FALSE;
int vFlag = FALSE;
int lFlag = FALSE;
int nFlag = FALSE;
int cFlag = FALSE;
int dump = FALSE;

extern void info(pIeObject op);
extern void dofile(char *infile);

//-----------------------------------------------
void Usage(void)
{
eprintf("%s\n",pathname);
eprintf("\
    Gives number of points and faces plus the bounding box of one\n\
    or more input objects. The wildcard '*' can be used in a filename.\n");
eprintf("Usage: %s [-v] [-f] [l] [-c] infile [...infile]\n",	progname);
eprintf("\
   -v\tGive # vertices of each face\n\
   -l\tGive length of each edge of each face\n\
   -c\tGive center and average radius from center for each face\n");
exit(0);
}

//-----------------------------------------------
void main( int argc, char *argv[])
{
   char infile[MAXPATH];
   int inflag = FALSE;
	struct ffblk ffblk;

	char drive[MAXDRIVE];
   char path[MAXPATH];
   char filename[MAXPATH];

   pathname = *argv++;
	strlwr(pathname);
	fnsplit(pathname,tmpname,tmpname, progname, tmpname);

	// set error reporting to stdout
	eopenf(NULL);

   argc--;
	if (argc == 0)
		Usage();
	if (strcmp(*argv,"-") == 0)
		Usage();
	while (argc > 0) 
	{
	   if (argv[0][0] == '-') 
	      switch (argv[0][1])
			{
				case 'd' :
			  		argc--; argv++;
					dump = TRUE;
					break;
				case 'm' :
		   		argc--; argv++;
					memFlag = TRUE;
					break;
				case 'c' :
			   	argc--; argv++;
					cFlag = TRUE;
					break;
				case 'l' :
			   	argc--; argv++;
					lFlag = TRUE;
					break;
				case 'v' :
			   	argc--; argv++;
					vFlag = TRUE;
					break;

				default:
					eprintf( "Unkown Option %s\n",argv[0]);
					Usage();
			}
		else 
		{
			strcpy( infile, argv[0]);
				argc--; argv++;
			inflag = TRUE;
			if (findfirst( infile, &ffblk,0) == 0) 
			{
				fnsplit(infile, drive, path, NULL, NULL);
				sprintf(filename,"%s%s%s", drive, path, ffblk.ff_name);
				dofile( filename);
				while( findnext(&ffblk) >=0) 
				{
					sprintf(filename,"%s%s%s", drive, path, ffblk.ff_name);
					dofile( filename);
				}
		   }
	   }
   }

	if (!inflag)
		Usage();

}

//-----------------------------------------------
void dofile(char *infile)
{
	pIeObject iop = NULL;
	char tmpname[10];

	strlwr(infile);

	eprintf(  "\nReading from %s\n", infile);
	fnsplit(infile,NULL, NULL, NULL, tmpname);

	iop = ieg_ReadPLG( infile);

	if (!iop)
	{
		eprintf( "Error Reading input file %s\n", infile);
		return;
	}
	
	info(iop);
	if (dump)
		ieg_DumpObj(iop);
	ieg_FreeObj(iop);
}

//-----------------------------------------------
void info(pIeObject op)
{
	int memPerPoint;
	int numVertex, memPerVertex;
	int memPerPoly;
	int i, j, k;
	pIePoint ppt;
	pIePoly poly;
	pIeVertex pvtx, nvtx;
	Point max, min, avg;
	double dist, d;
	double total = 0.0;
	Point c;
	float r;

//-----------------------------------------------
	eprintf("Object %s contains %d points and %d faces\n", op->name,
		ieg_NumPoints(op), ieg_NumPolys(op));

//-----------------------------------------------
	// Determine Max/Min points
	eprintf("Max/Min/Avg Points\n");
	max.x = max.y = max.z = -99999999.99;
	min.x = min.y = min.z =  99999999.99;
	for (ppt = LL_First(op->points); ppt; ppt = LL_Next(ppt))
	{
		if (ppt->loc.x > max.x) max.x = ppt->loc.x;
		if (ppt->loc.y > max.y) max.y = ppt->loc.y;
		if (ppt->loc.z > max.z) max.z = ppt->loc.z;
		if (ppt->loc.x < min.x) min.x = ppt->loc.x;
		if (ppt->loc.y < min.y) min.y = ppt->loc.y;
		if (ppt->loc.z < min.z) min.z = ppt->loc.z;
		avg.x += ppt->loc.x;
		avg.y += ppt->loc.y;
		avg.z += ppt->loc.z;
	}
	avg.x /= ieg_NumPoints(op);
	avg.y /= ieg_NumPoints(op);
	avg.z /= ieg_NumPoints(op);

	eprintf("\tMin of X,Y,Z= \t%6g\t%6g\t%6g\n", min.x, min.y,min.z);
	eprintf("\tMax of X,Y,Z= \t%6g\t%6g\t%6g\n", max.x, max.y,max.z);
	eprintf("\tAvg of X,Y,Z= \t%6g\t%6g\t%6g\n", avg.x, avg.y,avg.z);

//-----------------------------------------------
	// Bounding Sphere
	ieg_CenterRad(op, &c, &r);
	eprintf("Bounding sphere radius: %6g center: %6g %6g %6g\n",
		r, c.x, c.y, c.z);

//-----------------------------------------------
	if (vFlag)
		eprintf( "\nNum Vertices for each face:\n\t");
	numVertex = 0;

	// i counts polys, j counts vtx, k keeps lines short
	for (i=1,k=0,poly=LL_First(op->polys); poly; poly=LL_Next(poly),i++,k++)
	{
		j = ieg_NumVtx(poly);
		if (vFlag) 
		{
			eprintf("F%d = %dv ",i,j);
			if (k == 5) {k=0;eprintf("\n\t");}
		}
		 numVertex +=j;
	}

	if (vFlag)
		eprintf("\n");
	eprintf("Object has total of %d vertices\n", numVertex);

//-----------------------------------------------
	// calculate length of each polygon perimeter
	if (lFlag) 
	{
		for (i=1, poly=LL_First(op->polys);poly; poly=LL_Next(poly), i++)
		{
			if (ieg_NumVtx(poly) > 1) 
			{
				eprintf("\tPoly %d:\n", i);
				dist = 0;
				pvtx=LL_First(poly->vtx);
				nvtx=LL_Next(pvtx);
				for (j=1; nvtx; j++) 
				{
					d = ieg_Distance( pvtx->ppt->loc, nvtx->ppt->loc);
					dist += d;
					eprintf("\t   edge: %d\tlenEdge: %-10lg\tlenPoly: %-1lg\n", 
						j, d, dist);
					pvtx = nvtx;
					nvtx=LL_Next(nvtx);
				}
				if (poly->flag & POLY_CLOSED)
				{
					nvtx = LL_Last(poly->vtx);
					d = ieg_Distance( pvtx->ppt->loc, nvtx->ppt->loc);
					dist += d;
					eprintf("\t   edge: %d\tlenEdge: %-10lg\tTotal lenPoly: %-1lg\n", 
					j, d, dist);
					total += dist;
				}
			}
		}
		eprintf("\tTotal edge length for object %lg\n", total);
	} 

//-----------------------------------------------
	// Center Radius of each polygon
	if (cFlag) 
	{
		for (i=1, poly=LL_First(op->polys); poly; poly = LL_Next(poly),i++)
		{
			ieg_CenterRadP( poly, &c, &r);
			eprintf("\tPoly %d: c(%g %g %g) r: %g\n",
				i, c.x, c.y, c.z, r);
		}
	}

//-----------------------------------------------
	// Normals for each polygon
	if (nFlag)
	{
		for (i=1, poly=LL_First(op->polys); poly; poly = LL_Next(poly),i++)
		{
			if (poly->pnorm)
				eprintf("\tPoly %d: norm(%g %g %g)\n",
					i, poly->pnorm->x, poly->pnorm->y, poly->pnorm->z);
		}
	}
//-----------------------------------------------
}
