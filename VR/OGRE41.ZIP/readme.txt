Current Version: OGRE 4.1

General Information about OGRE  (Object GeneRator / Editor)
    OGRE is a program written to automatically create three dimensional
data files for use in virtual reality simulations.  This geometry can
be converted into PLG (REND386) format, or NFF (Sense8 WorldToolkit)
format.  OGRE allows the creation of basic building blocks such as
blocks, pyramids, cylinders, spheres, objects of revolution, terrains
in the form of post arrays, fuzzy spheres, and panels.  In addition,
OGRE has the capability to assemble these basic objects into larger,
more complex objects.  It thereby changes objects creation from a
difficult and often inaccurate manual task into a fairly simple and
automatic one.
    OGRE was written by David Boeren, a member of the Toy Scouts of
America at the University of Central Florida.  The Toy Scouts are a
group of undergraduate students at UCF who are dedicated to Virtual
Reality research.  OGRE outputs to PLG format, which is used by the
program REND386, a standard hobbyist VR simulator for the IBM PC.  It
also can output to NFF format, which is used by Sense8 Corporation's
WorldToolkit simulation libraries.  For further information, suggestions,
or feedback, you can contact the author in any of the following ways:

Voice Phone:
    David Boeren  (407) 381-2495

Internet:
    boeren@next2.ist.ucf.edu

Mail:
    David Boeren
    12119 Pepperdine Place
    Orlando, Florida 32826-3901


OGRE Misc Information
    Formats:
        NFF - Object Datafile in Sense8 WorldToolkit Format
        OGR - Object Datafile in OGRE Internal Format
        OSF - OGRE Script File
        PLG - Object Datafile in REND386 Format


OGRE in the Future
    A torus datatype should be out soon.

    A connecting rod datatype may or may not be included in later
    versions.  It would just be an easier way of connecting objects
    with rods, and it's primary use would be for easy chemical
    modeling.

    I may or may not include DXF output support in later versions,
    depending partly on whether I can get some docs and their
    format is simple enough.  Quite frankly, I've seen some DXFs
    and they look horrible.

    I may or may not add support for some raytracer formats, like Vivid.

    A couple of other features are planned, but are very early in the
    planning stages and I am not mentioning them in self-defense against
    everyone expecting them to appear within a couple of months.  Some
    of these may be pretty hairy.


OGRE in the Past
    Changes since 4.0:
        1.  I found a bug which occurred if many (4 or more) panels were
            used.  The program would crash with a "Floating Point Error:
            Domain" message.  After several hours of tracing code, I turned
            off the Borland optimization flags and it worked perfectly.  It
            was one of those days.  Future versions will NOT be using the
            optimization flags!
        2.  The torus datatype is finished.
        3.  I also added an object type called a "twist".  A twist is exactly
            like a revolution, except it has a 2D offset at each level.  This
            allows making spirals, curves, etc...  Look at luxo.plg for an
            example, or the dactyl's neck.
        4.  The fuzzy spheres have been modified to be able to take their
            radii from a datafile.  This allows fairly complex sculpting of
            shapes, perhaps we can get some decent-looking heads now.  It
            takes a 2D terrain and wraps it around a sphere.  There is also
            an automatic detection and reduction of coplanar patches.  This
            means that if the patch is flat, it will be one rectangle instead
            of two triangles.  This will considerably help rendering speed.

