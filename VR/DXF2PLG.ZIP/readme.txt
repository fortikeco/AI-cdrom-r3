Usage : DXF2PLG <fname> [<scale>]

 The DXF file can be Binary or ASCII format without .DXF

 Default scale converts 1 in.-> 25.6 mm, scale can be any +interger,
 	i.e.   dxf2plg myfile 0.3   (this will create 1/3 the dxf object size
 								in the new PLG file)

 At present 3D faces, polylines, polyface and meshs, BLOCKS and ENTITIES are 
 both supported, direct support for DXF files created in AutoCad and 3D Studio
  *(will NOT do AME solids from AutoCad)*

Once you start DXF2PLG.EXE you will be asked if you want to import each object
that is in the DXF. This allows you to convert to PLG only those Objects you
desire. i.e

 Import: ?   Y to include this object in your PLG file.
      Chooseing `N  jumps to the next (if any) object.


Once you choose to import an Object you will have the choice to customize it
through material and color choices. i.e

 Select color for ?   Y to select a custom material and color.
      Chooseing `N  defaults to cosine white.


That's about it, it won't do every type of dxf out there but it will do
3d object dxf's. Have fun and prosper.

 AutoCAD(R) and 3D Studio(R) are registered trade marks of AutoDesk, Inc.
