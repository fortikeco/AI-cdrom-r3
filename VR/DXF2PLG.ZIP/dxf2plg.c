/***************************************************************************
    DXF.C  --  Parse a DXF file.
               This program segment is used to parse ASCII
               and binary DXF(tm) files produced by AutoCAD.
               The DXF file format as documented in the Release 10
               AutoCAD User Reference is supported by this code.
               In addition, supplementary routines for performing
               coordinate transformation are supported in ARBAXIS.C
               and are required by this program.

               This code currently supports parsing of the "ENTITIES"
               section of DXF files only.

               This code is in the public domain, and has no implied
               guarantees of fitness for purpose, reliability, etc.

               This code has been tested with Borland's Turbo C(tm)
               and the Sun Workstation's C compiler.

               1988 Autodesk, Inc.


    DXF3D.C    Modified from DXF.C to DXF3D.C 1/7/92

               All references to tran were removed.

               This code is in the public domain, and has no implied
               guarantees of fitness for purpose, reliability, etc.

    DXF2PLG.C  Modified from DXF3D.C to DXF2PLG.C 10/30/92

               revised to support REND386 PLG file format W/Color
               added blocks/3dface/polyline
               
                           dido to the above, -ED Schindler

***************************************************************************/
#include <stdio.h>
#include <ctype.h>
#include <conio.h>
#include <math.h>
#include <alloc.h>
#include <string.h>

#define Boolean short
#define real double
#define TRUE  1
#define FALSE 0
#define EOS   0

static Boolean inent(), ingroup(), getline();
static void dxferr(), getstring();
static char *alloc();
static void pline(), vert(), face(), seqend();
static int color = 0x2FFF;         /* Default color, cosine Hi-white */
static int choice = NULL;          /* to import or not to import */
float scale = 25.6;                /* convert inch to mm for rend386 coords */
FILE *fname, *plgfile;             /* Input file pointer */
static char *tbfr;                 /* General purpose text buffer */
static char *gtext;                /* Group text value */
static char *tgroup[10];           /* Group store table for text */
static real *rgroup;               /* Group store table for reals */
static short *igroup;              /* Group store table for integers */
static long normal[3];             /* Extrusion direction array */
static int binary;                 /* Binary type DXF file flag */
static short gcode;                /* Group code */
static short gint;                 /* Group integer value */
static real greal;                 /* Group real value */
static char binsent[20];           /* Binary DXF file sentinel buffer */
static char ename[20];             /* Entity type name */
static char object[20];            /* Object name */
static real plsw, plew;            /* Polyline default start and end width */
static char stemp1[40];            /* String input temporary */
static Boolean errored;            /* Error occurred flag */

#define OPENMODE "rb"              /* Most MS-DOS compilers */

shocol()
{
   cprintf("\r\n\n  1"); printf(" = Red");
   cprintf("\r\n  2"); printf(" = Orange");
   cprintf("\r\n  3"); printf(" = Pink");
   cprintf("\r\n  4"); printf(" = Beige");
   cprintf("\r\n  5"); printf(" = Lt Yellow");
   cprintf("\r\n  6"); printf(" = Yellow");
   cprintf("\r\n  7"); printf(" = Lt green");
   cprintf("\r\n  8"); printf(" = Green");
   cprintf("\r\n  9"); printf(" = Turqoise");
   cprintf("\r\n 10"); printf(" = Lt Blue");
   cprintf("\r\n 11"); printf(" = Blue");
   cprintf("\r\n 12"); printf(" = Lt Purple");
   cprintf("\r\n 13"); printf(" = Purple");
   cprintf("\r\n 14"); printf(" = Dk gray");
   cprintf("\r\n 15"); printf(" = Lt Gray\n");
   return 0;
}

/* Function returns the color number for the material string in p */
int add_texture()
{
   int i, user;
   color = 0;

   cprintf("\r\n\nN"); printf("ormal/");
   cprintf("C"); printf("osine/");
   cprintf("M"); printf("etal/");
   cprintf("G"); printf("lass ? ");

   switch (getche())
   {
      case 'n':
      case 'N':
	 color = 0x0000;
	 printf("\nNormal color index (0-255): ");
	 scanf("%d",&user);
	 color |= user;

	 break;
      case 'm':
      case 'M':
	 color = 0x2000;
	 shocol();
	 printf("\nMetal base color: ");
	 scanf("%d",&user);
	 color |= ((user << 8) & 0x0f00);
	 user = 255;
	 color |= (0x00ff);
	 break;

      case 'g':
      case 'G':
	 color = 0x3000;
	 shocol();
	 printf("\nGlass base color: ");
	 scanf("%d",&user);
	 color |= ((user << 8) & 0x0f00);
	 user = 255;
	 color |= (0x00ff);
	 break;

	default:
	 color = 0x1000;
	 shocol();
	 printf("\nCosine base color: ");
	 scanf("%d",&user);
	 color |= ((user << 8) & 0x0f00);
	 user = 255;
	 color |= (0x00ff);
	 break;
   }
   return color;
}


/* Read a dxf file */
void readxf(inname,utname)
char *inname,*utname;
{
	int c, length;
	short i, j;
	unsigned long l;
	char *name;
	if (fname = fopen(inname,"r")){
	   plgfile = fopen(utname,"w");
	}

	length = strlen(utname);
	for (i=0; i<length; i++)
	{
	utname[i] = toupper(utname[i]);
	}

	if (!fname || !plgfile) {
	   printf("\nCannot open DXF file ...");
	   exit(1);
	}
      clrscr();
	printf("Working on");cprintf(" %s...",utname);
	binsent[18] = 0;

	/*  Peek at the header to see if it's binary  */
	if ((fread(binsent, 1, 18, fname) != 18) ||
	    (strcmp(binsent, "AutoCAD Binary DXF") != 0)) {
	   rewind(fname);
	   binary = FALSE;
	} else {

	   /* This is a binary DXF file.  To insure correct processing
		of binary information we must close the file and re-open
		it with the binary I/O attribute. */

	   fclose(fname);
	   if ((fname = fopen(inname, OPENMODE)) == NULL) {
		printf("\nCannot open binary DXF file %s\n", fname);
		exit(1);
	   }

	   /* Skip past the header */

	   fseek(fname, 22L, 0);
	   binary = TRUE;
	}

	/*  Allocate dynamic storage to read file  */

	tbfr = (char *) alloc(200);
	gtext = (char *) alloc(200);
	for (i = 0; i < 10; i++)
	tgroup[i] = alloc(80);
	rgroup = (real *) alloc(60 * sizeof(real));
	igroup = (short *) alloc(80 * sizeof(short));

	/*  Ignore all of DXF file before ENTITIES section  */
	/*  This code could be modified to recognized other sections */

	errored = FALSE;
	while (!errored && ingroup()) {
	   if (gcode == 0 && !strcmp(gtext, "SECTION")) {
		if (!ingroup()) {
		 dxferr();
		 break;
		}
		if (gcode != 2) {
		 dxferr();
		}
		if (!strcmp(gtext, "ENTITIES")|| !strcmp(gtext, "BLOCKS"))
		 break;
	   }
	}

	 /*  Now process entities and build entity items  */

	if (!errored && !ingroup())
	   dxferr();
	 c = 0;
	 while (!errored && inent()){
	   if (!strcmp(ename, "POLYLINE") && igroup[70] == 64 ||
		 !strcmp(ename, "BLOCK") && igroup[70] == 64)
		   {
		   clrscr();
		   printf("Working on");cprintf(" %s...",utname);
		   get_object(); c = ++c;
		   printf("\n\nImport # %d object",c);
			cprintf(" %s", object);	printf(" ? ");
			switch (getche())
			  {
			   case 'y':
			   case 'Y':
			   choice = 1;
			   if (!strcmp(ename, "POLYLINE")){
			   fprintf(plgfile,"%s %d %d\n", object, igroup[71], igroup[72]);
			   }
			   length = strlen(object);
			   for (i=0; i<length; i++)
				{
			    object[i] = tolower(object[i]);
				}
			   printf("\n\nSelect color for");
				cprintf(" %s", object); printf(" ? ");
				{
				switch (getche())
				   {
					case 'y':
					case 'Y':
						 add_texture();
						 choice = 1;
						 break;

					case 'n':
					case 'N':
						 color = 0x2FFF;
						 choice = 1;
						 break;

					default:
						 color = 0x2FFF;
						 choice = 1;
						 break;
				    }
				  break;
				}
			   case 'n':
			   case 'N':
			     choice = NULL;
			     break;

			   default:
			     choice = NULL;
			     break;
			  }
	   } else if (!strcmp(ename, "VERTEX") && choice) {
		vert();
	   } else if (!strcmp(ename, "3DFACE")) {
		c = ++c;
		clrscr(); cprintf("3D face #: %d",c);
		face();
	   } else if (!strcmp(ename, "SEQEND") && choice) {
		seqend();
	   }
	}

	/* Release dynamic storage used whilst reading DXF file */
	clrscr();
	cprintf("\r\n\n -->  %s ", utname);
		printf("convertion complete...\n\n");
	textcolor(7);
	free(tbfr);
	free(gtext);
	for (i = 0; i < 10; i++)
		free(tgroup[i]);
		free(rgroup);
		free(igroup);
	if (errored)
		printf("\nError reading DXF file.\n");
	fclose(plgfile);
	fclose(fname);

}


/*  INENT  --  Read in next entity  */

static short inent()
{
	short i;

	if (gcode != 0) {
	   dxferr();
	   return FALSE;
	}
	if (!strcmp(gtext, "ENDSEC"))
	   return FALSE;           /* End of entity section */
	strcpy(ename, gtext);

	/* Supply defaults to fields  */

	igroup[62] = 0;
	rgroup[38] = 0.0;
	rgroup[39] = 0.0;
	normal[0] = normal[1] = normal[2] = 0.0;
	for (i = 0; i < 10; i++)
	   tgroup[i][0] = EOS;
	if (!strcmp(ename, "TEXT")) {
	   rgroup[50] = 0.0;
	   rgroup[41] = 1.0;
	   rgroup[51] = 0.0;
	   igroup[71] = 0;
	   igroup[72] = 0;
	} else if (!strcmp(ename, "SHAPE")) {
	   rgroup[50] = 0.0;
	   rgroup[40] = 1.0;
	   rgroup[51] = 0.0;
	} else if (!strcmp(ename, "INSERT")) {
	   igroup[66] = 0;
	   rgroup[41] = 1.0;
	   rgroup[42] = 1.0;
	   rgroup[43] = 1.0;
	   rgroup[50] = 0.0;
	   igroup[70] = 1;
	   igroup[71] = 1;
	   rgroup[44] = 0.0;
	   rgroup[45] = 0.0;
	} else if (!strcmp(ename, "ATTDEF")) {
	   igroup[73] = 0;
	   rgroup[50] = 0.0;
	   rgroup[41] = 1.0;
	   rgroup[51] = 0.0;
	   igroup[71] = 0;
	   igroup[72] = 0;
	} else if (!strcmp(ename, "ATTRIB")) {
	   igroup[73] = 0;
	   rgroup[50] = 0.0;
	   rgroup[41] = 1.0;
	   rgroup[51] = 0.0;
	   igroup[71] = 0;
	   igroup[72] = 0;
	} else if (!strcmp(ename, "POLYLINE")) {
	   igroup[70] = 0;
	   rgroup[40] = 0.0;
	   rgroup[41] = 0.0;
	}  else if (!strcmp(ename, "VERTEX")) {
	   rgroup[40] = plsw;
	   rgroup[41] = plew;
	   rgroup[42] = 0.0;
	   igroup[70] = 0;
	   rgroup[50] = 0.0;
	}

	while (TRUE) {
	   if (!ingroup()) {
		dxferr();
		break;
	   }
	   if (gcode == 0)
		break;
	   if (gcode < 10)
		strncpy(tgroup[gcode], gtext, 80); /* text */
	   else if (gcode < 60)                  /* reals */
		rgroup[gcode] = greal;
	   else if (gcode >= 210 && gcode < 240) /* extrusion dirs */
		normal[gcode / 10 - 21] = greal;
	   else if (gcode >= 60 && gcode < 240)   /* ints */
		igroup[gcode] = gint;
	}
     if (!strcmp(ename, "POLYLINE")) {
	   plsw = rgroup[40];
	   plew = rgroup[41];
	}
	return TRUE;
}

/*  INGROUP  --  Read in group from DXF file  */

static short ingroup()
{
    /* If we're reading a binary file */

    if (binary)
    {
		if (!gettype(&gcode)) {
		   /* End of file */
		   return FALSE;
		}
		if (gcode < 0) {
		  errored = TRUE;
		   return FALSE;
		}
		if (gcode < 10)
		   getstring(gtext);

		else if (gcode < 60)
		   getreal(&greal);

		else if (gcode >= 210 && gcode < 240)
		   getreal(&greal);

		else if (gcode >= 60 && gcode < 193)
		   getshort(&gint);

		else {              /* unknown gcode */
		   errored = TRUE;
		   return FALSE;
	}

	return TRUE;

    } else {

    /* We're reading an ASCII DXF file */

	if (getline()) {
	   if (sscanf(tbfr, "%hd", &gcode) != 1) {
		errored = TRUE;
		return FALSE;
	   }
	   if (gcode < 0) {
		errored = TRUE;
		return FALSE;
	   }
	   if (!getline()) {
		errored = TRUE;
		return FALSE;
	   }
	   if (gcode < 10) {
		strcpy(gtext, tbfr);

	   } else if (gcode < 60) {
		if (sscanf(tbfr, "%lf", &greal) != 1) {
		 errored = TRUE;
		 return FALSE;
		}
	   } else if (gcode >= 210 && gcode < 240) {
		if (sscanf(tbfr, "%lf", &greal) != 1) {
		 errored = TRUE;
		 return FALSE;
		}
	   } else if (gcode >= 60 && gcode < 193) {
		if (sscanf(tbfr, "%d", &gint) != 1) {
		 errored = TRUE;
		 return FALSE;
		}
	   } else if (gcode == 999);
	    else {                       /* unknown gcode */
		errored = TRUE;
		return FALSE;
	   }
	   return TRUE;
	}
	return FALSE;              /* End of file */
    }
}


static void dxferr()
{
	errored = TRUE;
	printf("\nError in DXF file!\n");
}


char un_space(str)
char *str;
{
   while (*str)
   {
	if (*str == ' ') *str = '_';
	if (*str == '"') *str = ' ';
	str++;
   }
   return 0;
}

static get_object()
{
	   if (binary){             /* get binary object name */
		   getstring(tbfr);
		   strrev(tbfr);
		   tbfr[strlen(tbfr) - 1] = EOS;
		   strrev(tbfr);
		   }
	   else if(fgets(tbfr, 132, fname)){ 	  /* skip 2 lines */
		   fgets(tbfr, 132, fname);   	  /* get ascii object name */
		   tbfr[strlen(tbfr) - 1] = EOS;
		   }
	   un_space(object);
	   strcpy(object, tbfr);
	return 0;
}

/*  GETLINE  --  Obtain next line from input file  */

static Boolean getline()
{
	if (fgets(tbfr, 132, fname)) {
	   tbfr[strlen(tbfr) - 1] = EOS;
	   return TRUE;
	}
	return FALSE;
}

/*  GETTYPE  --  Get the identifier (gcode) for the data item */

static int gettype(type)
  short *type;
{
   unsigned char c;

   if (fread(&c, 1, 1, fname)) {
	*type = (short) c;
	return TRUE;
   }
   return FALSE;
}

/*  GETSTRING  --  Get a string from the binary file */

static void getstring(str)
  char *str;
{
   char *s;
   s = str;
   while (*(s++) = getc(fname));
}

/*  GETSHORT  --  Get an integer (in 8086 order!) from the binary file */

static int getshort(ptr)
  short *ptr;
{
   if (fread(ptr, 2, 1, fname)) {
	return TRUE;
   }
   return FALSE;
}

/*  GETREAL  --  Get a real (double) from the binary file in IEEE */

static int getreal(ptr)
  real *ptr;
{
   if (fread(ptr, 8, 1, fname)) {
     return TRUE;
   }
   return FALSE;
}

static char *
alloc(size)
  unsigned size;
{
   char *ptr;
   register int i;

   if ((ptr = (char *) malloc(size)) == NULL) {
	printf("Out of memory\n");
	exit(1);
   }
   for (i=0; i<size; i++)
	ptr[i] = 0;
   return ptr;
}

/* ------------- below this line lie your local routines ----- */

static long pnorm[3];
static int inpoly,inmesh;

/*  Main calling routine */

void main(argc, argv)
int argc;
char **argv;
{
   char inname[80],utname[80];
   char *p;
   textcolor(14);
   if (argc < 2)
   {
   clrscr();
   cprintf("\r\nUsage: DXF2PLG <fname> [<scale>]\n");
    printf("\n The DXF file can be Binary or ASCII format without .DXF\n");
    printf("\n Default scale converts 1 in.-> 25.6 mm, scale can be any +interger\n");
    printf("\n At present 3D polyface/mesh ENTITIES are supported, direct support");
    printf("\n for DXF files created in 3D Studio(R) 1.0 or rev2.\n");
    printf("\n If you use AutoCad(R) EXPLODE any blocks, and PFACE your objects,");
    printf("\n this will change all objects into Polyline 3D polyfaces. Then you");
    printf("\n can ..DXFOUT, choose ..BINARY ..ENTITIE and your precision factor.\n");
    printf("\n Import:");cprintf(" OBJECT");printf(" ?");
    printf("   Y to include this object in your PLG file.");
    printf("\n      Chooseing `N  jumps to the next (if any) object.\n");
    printf("\n Select color for");cprintf(" object");printf(" ?");
    printf("   Y to select a custom material and color.");
    printf("\n      Chooseing `N  defaults to cosine white.\n");
   cprintf("\r\n DXF2PLG v1.0 is written and given away, by Edmond E. Schindler [71700,3516]\r\n");
    printf(" AutoCAD(R) and 3D Studio(R) are registered trade marks of AutoDesk, Inc.\n");
    exit(0);
   }

   if (argc == 3){
	sscanf(argv[2],"%g",&scale);
	scale = scale*25.6;
	}

   p = strrchr(argv[1],'.');

   if (p) *p = 0;

   strcpy(inname,argv[1]);
   strcpy(utname,argv[1]);

   strcat(inname,".dxf");
   strcat(utname,".plg");
   textcolor(14);
   readxf(inname,utname);
}


static void vert ()    /* have this working great -ED */
{
   float pt[3];
   unsigned int x, y, z;

   x=(abs(igroup[71])-1); y=(abs(igroup[72])-1); z=(abs(igroup[73])-1);
   pt[0]=(rgroup[10]*scale); pt[1]=(rgroup[20]*scale); pt[2]=(rgroup[30]*scale);


   if (!strcmp(ename, "VERTEX") && igroup[70] == 192) {
	 fprintf(plgfile,"%.2f %.2f %.2f\n", pt[0], pt[2], pt[1]);
	 }

   if (!strcmp(ename, "VERTEX") && igroup[70] == 128) {
	 fprintf(plgfile,"0x%04.4X 3 %d %d %d\n", color, x, y, z);
	 }
}

static void face()
{
  float pt[12];

  pt[0] = (rgroup[10]*scale); pt[1] = (rgroup[20]*scale); pt[2] = (rgroup[30]*scale);
  pt[3] = (rgroup[11]*scale); pt[4] = (rgroup[21]*scale); pt[5] = (rgroup[31]*scale);
  pt[6] = (rgroup[12]*scale); pt[7] = (rgroup[22]*scale); pt[8] = (rgroup[32]*scale);
  pt[9] = (rgroup[13]*scale); pt[10] = (rgroup[23]*scale); pt[11] = (rgroup[33]*scale);

  if((pt[6],pt[8],pt[7])==(pt[9],pt[11],pt[10]))
	  fprintf(plgfile,"3DFACE 3 1\n");
  else if((pt[6],pt[8],pt[7])!=(pt[9],pt[11],pt[10]))
	  fprintf(plgfile,"3DFACE 4 1\n");

  fprintf(plgfile,"%.2f %.2f %.2f\n",pt[0],pt[2],pt[1]);
  fprintf(plgfile,"%.2f %.2f %.2f\n",pt[3],pt[5],pt[4]);
  fprintf(plgfile,"%.2f %.2f %.2f\n",pt[6],pt[8],pt[7]);

  if((pt[6],pt[8],pt[7])==(pt[9],pt[11],pt[10]))
	fprintf(plgfile,"0x%04.4X 3 0 1 2 \n", color);

  else if((pt[6],pt[8],pt[7])!=(pt[9],pt[11],pt[10])){
	 fprintf(plgfile,"%.2f %.2f %.2f\n",pt[9],pt[11],pt[10]);
	 fprintf(plgfile,"0x%04.4X 4 0 1 2 3\n", color);
	 }
}

static void seqend ()
{
   if (inpoly)
     inpoly = FALSE;
     inmesh = FALSE;
}

static int normtest (norm)
real *norm;
{
   return (norm[0] == 0.0 && norm[1] == 0.0 && norm[2] == 0.0);
}
