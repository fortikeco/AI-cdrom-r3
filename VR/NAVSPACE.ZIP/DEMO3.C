/* demo3:  full system, glove only 				*/

/****************************************************************/
/* Mod version of Info. Space to use PowerGlove as navigation   */
/* tool.                                                        */ 
/*                                                              */
/* To translate, grab (make a fist):                            */
/*   Move in X, Y, and Z plane - data moves with you!           */
/*                                                              */
/* To rotate, point (first finger or more):                     */
/*   Hand level, move left and right for X axia                 */
/*   Hand at 90 degree angle, move up and down for Y axis       */   
/****************************************************************/

/****************************************************************/
/* Gregory B. Newby                                             */
/* Graduate School of Library and Information Science           */
/* University of Illinois at Urbana-Champaign			*/
/* All rights reserved.                                         */
/****************************************************************/

/****************************************************************/
/* Program history:                                             */
/* Version 1.0 -- navigate through data with mouse  (Jan. 1991) */
/* Version 2.0 -- navigate with Mattel PowerGlove   (May, 1991) */
/* Version 2.1 -- add sphere and map window for navigation cues */
/*						(June 19, 1991) */
/* Version 3.0 -- add Document and Word windows for closest     */
/* 		  items (August 16, 1991)			*/
/* Version 3.1 -- depthcueing (finally) and document proc.      */
/*		  (September 15, 1991)				*/
/* Version 4.0 -- Changed look and feel to full-screen space   	*/
/* 		  with popup windows for eveything else		*/
/****************************************************************/

/****************************************************************/
/* Document and keyterm data are all mixed up together, as      */
/* the display program doesn't need to know which are which!    */
/****************************************************************/


#include<gl.h>
#include<stdio.h>
#include<stdlib.h>
#include<device.h>
#include<limits.h>
#include<string.h>
#include<math.h>
#include<termios.h>
#include<ctype.h>
#include<sys/types.h>
#include<fcntl.h>
#include "sys/callo.h"
#include</usr/people/gbnewby/include/powerglove.h>

#define NDATA 1000	/* Maximum number of data points */
#define PORT_ID "/dev/ttyd1" /* serial port 1 */

pglove_data pglove;
int numdocs, numkey;
extern double sin(), cos(), sqrt();
float xord[NDATA], yord[NDATA], zord[NDATA];
float orig_xord[NDATA], orig_yord[NDATA], orig_zord[NDATA];
float map_xord[NDATA], map_yord[NDATA], map_zord[NDATA];
char *word[NDATA];
int file_id;

pglove_data pglove; /* structure for glove info */

float INITX, INITY, INITZ;
float deltaY, deltaX, deltaZ;
float totdeltaY, totdeltaX, totdeltaZ;
float newX, newY, newZ;
float tempX, tempY, tempZ;
int trans = 0, maparray = 0, crap = 0;
float tval=0.15; flicker=0, flick=0;

/* FILE *fp2; */

/* structure for muliple windows */
typedef struct {
	int gid;
} wrecord;
wrecord wins[9]; /* leave 0th spot empty */

/* structure for movement history */
typedef struct {
	float X, Y, Z;
} hist;
hist history[1000];

float dist[NDATA];
int mouse_mode = 1;
int mode;

int SpaceWindow, MapWindow, CloseDocs, CloseWords, 
    Mode, Output, Message, Background;

int Retrieve_docs(int, char[], int, pglove_data);
/****************************************************************/
/*  User's choice:						*/
/*	rotate on X and Y simultaneously, or 			*/
/*	translate data on X, Y, or Z				*/
/****************************************************************/
main(int argc, char *argv[]) 
{

/****************************************************************/
/* Initialize variables:                                        */
/****************************************************************/
   int i, j;
   char dummy[80];
   float Xaxis, Yaxis;
   float hypot, costheta, sintheta, radtheta;
   long znear, zfar; /* for depthcueing */
   float negcostheta, Xsintheta, costhetaX2negcostheta,
       XYnegcostheta, Ysintheta, costhetaY2negcostheta;

/****************************************************************/
/* Read in coordinate data:                                     */
/****************************************************************/
   getord(argc, argv);  /* get the keyterms */


/****************************************************************/
/* Mouse or glove??? 						*/ 
/****************************************************************/
  system("clear");
   pagecolor(BLACK);
   mouse_mode = 0;
  printf("\nInitializing...\n");


/****************************************************************/
/* Initialize the PowerGlove (MUST be before windows are opened!*/ 
/****************************************************************/
  if(mouse_mode == 0) file_id = init_pglove();	
     else file_id = 0;

/****************************************************************/
/* Initialize IRIS graphics:                                    */
/****************************************************************/
   setvaluator(MOUSEX,-2000,-20000,20000);
   setvaluator(MOUSEY,-2000,-20000,20000);
   foreground(); /* necessary for textport calls to work */

/* initialize the textport */
   pagecolor(BLUE); textcolor(WHITE); 

/* Background for screen (all black) */
   noborder();
    prefposition(0,1280,0,1024);
     wins[0].gid = winopen();
      Background = wins[0].gid;
     gconfig();
    color(BLACK); clear();

/* open the document window */
/*    prefposition(10, 180, 120, 600);
     wins[3].gid = winopen("Close Docs");
      CloseDocs = wins[3].gid;
    RGBmode();
   gconfig();
*/

/* open the word window */
/*    prefposition(10, 180, 630, 980); 
     wins[4].gid = winopen("Close Words");
      CloseWords = wins[4].gid;
    RGBmode();
   gconfig();
*/


/* Open the retrieval window */
/*   prefposition(250,900,200,800); */
   prefposition(250,975,190,950);
    wins[6].gid = winopen("Output");
     Output = wins[6].gid;
    RGBmode();
   gconfig();

/* open the navigation window */
   prefposition(6, 1000, 6, 1018);
    wins[1].gid = winopen();
     SpaceWindow = wins[1].gid;
     doublebuffer();
    RGBmode();
   gconfig();

/* open the map window */
   keepaspect(1,1); 
    prefposition(1010,1270,762,992);
     wins[2].gid = winopen("Position");
      MapWindow = wins[2].gid;
     doublebuffer();
    RGBmode();
   gconfig();

/* open the mode window */
   keepaspect(1,1);
    prefposition(1010,1270,522,752);
     wins[5].gid = winopen("Mode");
    Mode = wins[5].gid;
   gconfig();

/* initialize windows */
   winset(Background); winpop();

/* open the vocabulary window */
   system("wsh -f Courier-Bold11 -H -p 1010,3 -m 26,30 -t \"Vocabulary\" -c cat eric.label &");

   winset(SpaceWindow); winpop();
          cpack(0); clear(); swapbuffers(); cpack(0); clear();

/* Depthcueing only works with ORTHO view! */
/*   ortho(-1.2,1.2,-1.2,1.2,0.000001,3); */
   ortho(-.8,.8,-.8,.8,0.000001,2); 
   glcompat(GLC_ZRANGEMAP, 0);
   lsetdepth(0, 0x000001);
   lRGBrange(0,0,0,0,255,255,0,0x000001);
   depthcue(1);

   winset(MapWindow); winpop(); 
             cpack(0); clear(); swapbuffers(); cpack(0); clear();
	     perspective(500,1,0.000001,100);
	     polarview(8,0,0);

/*   winset(CloseDocs);
             cpack(0); clear(); swapbuffers(); cpack(0); clear(); 
             ortho2(-20,20,-20,20);
*/

/*   winset(CloseWords);
             cpack(0); clear(); swapbuffers(); cpack(0); clear();
             ortho2(-20,20,-20,20);
*/

   winset(Mode); winpop();
	     mode = 1;
	     ortho2(0,10,0,10);
	     color(mode); clear();
             cpack(0); 
              linewidth(3);
               move2(4,2); draw2(4,4); draw2(6,4); move2(6,6.5); draw2(6,2);
               move2(3.2,2); draw2(3.7,2); draw2(3.7,4.3); draw2(5.7,4.3); draw2(5.7,7);
               move2(5.7,6); draw2(4.2,5.0);
              circf(5.7,7.6,.6); 
             linewidth(1);

   winset(Output);
	     cpack(0xFF808080); clear();

/* Ditch buffered data and initialize variables */
   gloveinit();
   trans = 1; mode = 1; 
   drawhistory();

/*  pythag(); */


/****************************************************************/
/* The main loop to plot points (QKEY to exit)             	*/
/****************************************************************/
while(!getbutton(QKEY))
{
Top_Loop: /* check for change in status */
  if (getbutton(SKEY) || 
     ((pglove.one) > 2) && (pglove.two = 3) && 
      (pglove.three = 3) && (pglove.thumb = 3))
      Retrieve_docs(argc, argv, file_id, &pglove);
  if (getbutton(VKEY)) search_vocabulary(file_id, &pglove);
  if (getbutton(FKEY)) find_term(file_id, &pglove);
  if (getbutton(QKEY)) goto ByeBye;
  if (getbutton(HKEY)) help();
  if (getbutton(RKEY))
  {
   RubySlippers(); /* reinit coords */
    maparray = 0;
     totdeltaX = totdeltaY = totdeltaZ = 0;
    newX = newY = newZ = 0;
   goto DrawData;
  }

  if (crap == 1) 
  { 
   sginap(8);
    read_pglove(file_id, &pglove);
   crap = 0; 
  }

  if (pglove.three <= 1) 
  {
    if (trans == 0) 
    { /* no screen update needed */
    	sginap(8);
    	 read_pglove(file_id, &pglove);
    	goto Top_Loop;
    }

    trans = 0; /* just stopped moving.  Update screen */
    mode = 1;
    winset(Mode); cpack(mode); clear();
     cpack(0); 
      linewidth(3);
       move2(4,2); draw2(4,4); draw2(6,4); move2(6,6.5); draw2(6,2);
       move2(3.2,2); draw2(3.7,2); draw2(3.7,4.3); draw2(5.7,4.3); draw2(5.7,7);
       move2(5.7,6); draw2(4.2,5.0);
       circf(5.7,7.6,.6); 
      linewidth(1);

 /*   pythag(); */
  goto DrawData;  
  }


/****************************************************************/
/* Translation sequence        					*/
/****************************************************************/
if ((pglove.one <= 2) && (pglove.two >=1))  /* Translation mode */ 
   {
      if (trans != 1)               /* just started translating */
         {
          INITX = (float)pglove.x; INITY = (float)pglove.y; 
                  INITZ = (float)pglove.z;
           mode = 2; trans = 1;
           winset(Mode); cpack(mode); clear(); cpack(0);
	    linewidth(3);
	     move2(2.5,5); draw2(7.5,5); move2(5,2.5); draw(5,7.5);
  	     linewidth(10);
	      move2(2.5,5.5); draw2(1.5,5); draw2(2.5,4.5); draw2(2.5,5.5);
	      move2(7.5,5.5); draw2(8.5,5); draw2(7.5,4.5); draw2(7.5,5.5);
	      move2(4.5,7.5); draw2(5,8.5); draw2(5.5,7.5); draw2(4.5,7.5);
	      move2(4.5,2.5); draw2(5,1.5); draw2(5.5,2.5); draw2(4.5,2.5);
	     linewidth(1);
	    sginap(8);
           read_pglove(file_id, &pglove);
         }

      deltaX = ((float)pglove.x - INITX) *6.; 
               deltaY = ((float)pglove.y - INITY) *6.;
               deltaZ = ((float)pglove.z - INITZ) * 20.; 

      /* (Use permanent translation of data, because translate();*/
      /* would put the center of the data somewhere else.)       */
      tempX = deltaX/200.;
      tempY = deltaY/200.;
      tempZ = deltaZ/200.;
      for (j=0; j < numdocs; ++j)
      {
       xord[j] += tempX;
        yord[j] += tempY;
       zord[j] += tempZ;
      }

      INITX = (float)pglove.x; 
              INITY = (float)pglove.y;
              INITZ = (float)pglove.z;
  goto DrawData;
  }


/****************************************************************/
/* Rotation sequence                                            */
/****************************************************************/
else
  {
     if (trans != 2) /* just started rotation */
     {
      mode = 3; trans = 2;
       winset(Mode); cpack(mode); clear(); cpack(0); 
        linewidth(3);
       	 circ(5,5,3);
          linewidth(10);
 	   move2(7.5,5); draw2(8.5,5); draw2(8,4.5); draw2(7.5,5);
	  linewidth(1);
	 INITX = (float)pglove.x; INITY = (float)pglove.y;
	sginap(8);
       read_pglove(file_id, &pglove);	 
      }

      deltaX = ((float)pglove.x - INITX) * 0.75;
               deltaY = ((float)pglove.y - INITY) * 0.75;
               deltaZ = 0;
      INITX = (float)pglove.x; INITY = (float)pglove.y;
             

/****************************************************************/
/* compute length of movement vector				*/
/* figure out the new axis (about which we want to rotate)      */
/****************************************************************/
   if (deltaX == 0.0) deltaX = 0.00000000000001;
   if (deltaY == 0.0) deltaY = 0.00000000000001;
   hypot = sqrt((deltaX * deltaX) + (deltaY * deltaY));
   Xaxis = 0.0 - (deltaY / hypot);
   Yaxis = deltaX / hypot;

/****************************************************************/
/* Get sin and cos of movement vector for transformation        */
/****************************************************************/
   radtheta = (M_PI * hypot) / 180.0;
   costheta = (float)(cos(radtheta));
   sintheta = (float)(sin(radtheta)); 

/****************************************************************/
/* Transform the data.	hypot, the length of the movement 	*/
/* vector, is also the desired angle of rotation.		*/
/*   note:  For this transformation, Zaxis is zero.  All Z terms*/
/* have been dropped from the transformation matrix.            */
/****************************************************************/
negcostheta = 1. - costheta;
Xsintheta = Xaxis * sintheta;
Ysintheta = Yaxis * sintheta;
XYnegcostheta = Xaxis * Yaxis * negcostheta;
costhetaY2negcostheta = costheta + (Yaxis * Yaxis * negcostheta);
costhetaX2negcostheta = costheta + (Xaxis * Xaxis * negcostheta);

     for (j=0; j < numdocs; ++j) /* data coordinate rotation */
     {
      float txord, tyord, tzord;
       txord = xord[j]; tyord = yord[j]; tzord = zord[j];
        xord[j] = (txord * (costhetaX2negcostheta))
 	        + (tyord * XYnegcostheta)
	        - (tzord * Ysintheta);

        yord[j] = (txord * XYnegcostheta)
	        + (tyord * (costhetaY2negcostheta))
	        + (tzord * Xsintheta);

        zord[j] = (txord * Ysintheta)
	        - (tyord * Xsintheta)
	        + (tzord * costheta);
      }

     for (j=0; j < numdocs; ++j) /* map window coordinates */
     {
      float txord, tyord, tzord;
       txord = map_xord[j]; tyord = map_yord[j]; tzord = zord[j];
        map_xord[j] = (txord * (costhetaX2negcostheta))
 	        + (tyord * XYnegcostheta)
	        - (tzord * Ysintheta);

        map_yord[j] = (txord * XYnegcostheta)
	        + (tyord * (costhetaY2negcostheta))
	        + (tzord * Xsintheta);

        map_zord[j] = (txord * Ysintheta)
	        - (tyord * Xsintheta)
	        + (tzord * costheta);
      }

     for (j=0; j < maparray; ++j) /* map history coordinates */
     {
      float txord, tyord, tzord;
       txord = history[j].X; tyord = history[j].Y; tzord = history[j].Z;       
        history[j].X = (txord * (costhetaX2negcostheta))
 	        + (tyord * XYnegcostheta)
	        - (tzord * Ysintheta);

        history[j].Y = (txord * XYnegcostheta)
	        + (tyord * (costhetaY2negcostheta))
	        + (tzord * Xsintheta);

        history[j].Z = (txord * Ysintheta)
	        - (tyord * Xsintheta)
	        + (tzord * costheta);
      }

}


/****************************************************************/
/* Routine to draw the data:                              	*/
/****************************************************************/
DrawData:
winset(SpaceWindow); /* First do the SpaceWindow */
 cpack(0); clear(); cpack(0xFFFFFF00);
  for (i=0; i < numdocs; ++i) 
  { 
   cmov(xord[i], yord[i], zord[i]);    
   charstr(*(word+i));
  }

if (trans)
  {
   pushmatrix();
    totdeltaX += tempX; totdeltaY += tempY; totdeltaZ += tempZ;       
     ortho(0.0,1024.0,0.0,768.0,0,10); 
      cmov ( 10.0,30.0,0);
     if (trans == 1) charstr("Translation Mode");
    if (trans == 2) charstr("Rotation Mode");
   popmatrix();
  }
  else write_note(); /* tell how to Quit */
  swapbuffers();

  /* Second do the MapWindow */
  if (trans) drawhistory();

  /* Get the next glove position */
  if (read_pglove(file_id, &pglove) != 0) 
     printf("Bad glove data received\n");
}


/****************************************************************/
/* End of main()                                                */
/****************************************************************/
ByeBye:
 setvaluator(MOUSEX,500,-20000,20000);
  setvaluator(MOUSEY,100, -20000,20000);
   textcolor(WHITE);
    pagecolor(BLACK);
   system("clear");
  printf("\nSession ended\n\n");
 gexit();
return(0); 
}


/****************************************************************/
/* Read in coordinate data from file specified as argument.     */
/* (Thanks to Bob Zeh for solving the array-of-strings problem)	*/
/****************************************************************/
getord(argc, argv)
     int argc; char *argv[];
{
  FILE * fp;
  int i=0;
  char buffer[48];

  if ((fp = fopen(argv[1], "r")) == NULL)
  {
   printf("Could not open input file!\n");
   exit(1);
  }     

Read_em:
  while ((i < NDATA) && (fscanf(fp, "%s", buffer) != EOF))
  {
   word[i] = (char *) malloc(strlen(buffer) +1);
    strcpy(word[i], buffer);
    if(*buffer == '*') 
    {
     numkey = i-1;
     goto Read_em; /* end of keywords */
    }

  /* arcane knowledge:  scanf and family do NOT work with double*/
  /* precision data!						*/
     fscanf(fp,"%f%f%f", xord+i, yord+i, zord+i);
     i++;
  }
  numdocs = i-1;

  for (i=0; i <= numdocs; i++) 
  {
   orig_xord[i] = xord[i];
    orig_yord[i] = yord[i];
   orig_zord[i] = zord[i];
  }
return;
}


/****************************************************************/
/* Place stationary text on the screen                          */
/****************************************************************/
write_note()  /* So the text on the screen stays put */
{
 pushmatrix();
  ortho(0.0,1024.0,0.0,768.0,0,10); 
   cmov(10,30,0);
  charstr("Type 'Q' to Quit,");
 popmatrix();
}


/****************************************************************/
/* Get glove and user ready; flush data from glove buffer       */
/****************************************************************/
gloveinit()
{
 winset(SpaceWindow);
  pushmatrix();
   ortho(0.0,1024.0,0.0,768.0,0,10); 
    cmov (10,30,0);
    charstr("SpaceKey to Start");
   popmatrix();
  swapbuffers();
 
                        while(!getbutton(SPACEKEY))
  {
   read_pglove(file_id, &pglove);
   sginap(8);
  }
}


/****************************************************************/
/* Draw a grid		        				*/
/****************************************************************/
drawgrid()
{
   int i,ii; float fi, fii;
   pushmatrix();
   translate(totdeltaX, totdeltaY, totdeltaZ);
   cpack(0xFF383838);

   fi = -200;
   for (i = 1; i <= 40; i++) {
	fi += 10.; /* was 1 */
	fii = -200;
	   for (ii = 1; ii <= 40; ii++) {
		fii += 10.; /* was 5 */
	
/* transform the fi and fii values below for 'rotate' mode */
		move(fi,fii,-10);
		draw(fi,fii,10);
		}
   }   
   rot(90,'y'); 
   fi = -200;
   for (i = 1; i <= 40; i++) {
	fi += 10.;
	fii = -200;
	   for (ii = 1; ii <= 40; ii++) {
		fii += 10.;
		move(fi,fii,-10);
		draw(fi,fii,10);
		}
   }  
   rot(90,'x'); 
   fi = -200;
   for (i = 1; i <= 40; i++) {
	fi += 10.;
	fii = -200;
	   for (ii = 1; ii <= 40; ii++) {
		fii += 10.;
		move(fi,fii,-10);
		draw(fi,fii,10);
		}
   }
   popmatrix();
   return(0);
}


/****************************************************************/
/* Draw a set of axes for X, Y, and Z coordinate system		*/
/****************************************************************/
makeaxes() 
{
 move(-50,0,0); draw(50,0,0);
  move(0,-50,0); draw(0,50,0);
 move(0,0,-50); draw(0,0,50);
return(0);
}


/****************************************************************/
/* Update the matrix of where the user has been; draw the path  */
/****************************************************************/
drawhistory()
{
   int i, k;

 winset(MapWindow);
 cpack(0); clear(); 
  pushmatrix();
   polarview(8,0,0);
   cpack(0xFF00FFFF); /* yellow */
    for (i=0; i < numkey; ++i) 
    { 
     pnt(xord[i], yord[i], zord[i]);    
    }
    cpack(0xFFFFB000); /* bright blue */
    for (i=numkey+1; i < numdocs; ++i) 
    { 
     pnt(xord[i], yord[i], zord[i]);    
    }
    cpack(0xFF00FF00); move(-6,0,0); draw(6,0,0);
    cpack(0xFFFF8000); move(0,-6,0); draw(0,6,0);
    /*cpack(0xFF00FFFF); move(0,0,0); draw(3,-3,5); */
  popmatrix();
 swapbuffers();
return;
}


/****************************************************************/
/* Initialie the PowerGlove  				 	*/
/****************************************************************/
int init_pglove() /* Routine to initialize the serial port */
{
  extern char *sys_errlist[];
  int rslt;
  struct termios tbuf;

  file_id = open(PORT_ID, O_RDWR, 0);
  if (file_id == -1)
  {
    printf("Error on open call\n");
    perror(*sys_errlist);
    exit(1);
  }

  tbuf.c_iflag = 0;
  tbuf.c_oflag = 0;
  tbuf.c_lflag = 0;
  tbuf.c_cflag = B9600 | CS8 | CLOCAL | CREAD;

  rslt = ioctl(file_id, TCSETA, &tbuf);
  if (rslt == -1)
  {
    fprintf(stderr, "ioctl failed\n");
    perror(*sys_errlist);
    exit(1);
  }
  ioctl(file_id, TCFLSH,2); /* flush the port */
return(file_id);
}


/****************************************************************/
/* Read current glove information 				*/
/****************************************************************/
int read_pglove(file_id, pglove)
    pglove_data *pglove; 
    int file_id;
{
  int ret, temp;
  char buf[BUFSIZ];
  char command[BUFSIZ];

  if(mouse_mode == 0)  /* read glove data, else mouse */
  { 
   command[0] = 2;
    write(file_id,command,1); /* query the glove */
     ret = read(file_id,buf,14); /* read data from the glove */

  /* Check if data are good */
     if (!((ret > 3) && (buf[0] == (0x81 - 127)) && (buf[1] == (0xDE - 127)) &&
          (buf[2] == (0xDE - 127)))) return(1); 

  /* Assign X, Y, and Z (need to query 1st bit for sign) */
   pglove->x = buf[3]; if (buf[3] > 127) pglove->x -= 256;
    pglove->y = buf[4]; if (buf[4] > 127) pglove->y -= 256;
   pglove->z = buf[5]; if (buf[5] > 127) pglove->z -= 256;  

  /* Assign rotation and (bit-shifted) rotation values */  
   pglove->rot = buf[6];
    temp = buf[7];
     pglove->three = temp & 3;
      temp = temp >> 2;
       pglove->two = temp & 3;
      temp = temp >> 2;
     pglove->one = temp & 3;
    temp = temp >> 2;
   pglove->thumb = temp & 3;
  }

else /* we're in mouse mode.  assign values */
  {  
   pglove->x = getvaluator(MOUSEX);
    pglove->y = getvaluator(MOUSEY);
     if (getbutton(MIDDLEMOUSE)) pglove->z -=1;
      if (getbutton(RIGHTMOUSE))  pglove->z +=1;
       if (getbutton(LEFTMOUSE)) 
       {
        sginap(18); /* prevent double-mode changes */
         if (mode >= 3) mode = 0;
         mode += 1;
         if (mode == 2) /* translate mode */
         { 
	  pglove->one = 0;
	   pglove->two = 3;
	  pglove->three = 3;
         }
         if (mode == 3) /* rotate mode */
         { 
	  pglove->one = 0;
	   pglove->two = 0;
	  pglove->three = 3;
         }
         if (mode == 1) /* input/wait mode */
	  pglove->three = 0;
       }
  }

/* Calculate averages/smooth data for X, Y, and Z */
/* (under construction) */
return(0);
}


/****************************************************************/
/* What are the closest datapoints in the space?		*/
/****************************************************************/
pythag()
{
  int i;
  float tempx, tempy, tempz;

  for (i=0; i <numdocs; i++) 
  {
   tempx = orig_xord[i] - totdeltaX;
    tempy = orig_yord[i] - totdeltaY;
    tempz = orig_zord[i] - totdeltaZ;
   dist[i] = sqrt((tempx * tempx) + (tempy * tempy) + (tempz * tempz));
  }
  slowsort();
return(0);
}


/****************************************************************/
/* SlowSort copyright 1991.  Find the 20 closest...		*/
/****************************************************************/
slowsort() /* your standard bubble sort */
{
  int i, j, l;
  float k;
  int closewords[NDATA]; 
  int closedocs[NDATA];

/* First do the keywords */
  for (i=0; i<=numkey; i++) closewords[i] = i;  for (i=0; i<=numkey; i++) /* for each item */
  { 
   for (j=i+1; j<=numkey-1; j++) 
   { 
    if(dist[j] < dist[i]) /* swap 'em */
    { 
     k = dist[j]; l = closewords[j];
      dist[j] = dist[i]; closewords[j] = closewords[i];
     dist[i]=k; closewords[i]=l;
    }
   }
  }

  winset(CloseWords);
   cpack(0xFF000000); clear(); cpack(0xFFFFFFFF);
    k=13.;
     for(i=0; i<=25; i++)
     {
      int temp;
       k-=1.;
        temp = closewords[i-1];
       cmov2(-18.,(k*1.5));
      charstr(*(word+temp));
     }

  /* Now do the documents */
  for (i=numkey+1; i<=numdocs; i++) closedocs[i] = i;
  for (i=numkey+1; i<=numdocs; i++) /* for each item */
  { 
   for (j=i+1; j<=numdocs; j++) 
   { 
    if(dist[j] < dist[i]) /* swap 'em */ 
    { 
     k = dist[j]; l = closedocs[j];
      dist[j] = dist[i]; closedocs[j] = closedocs[i];
     dist[i]=k; closedocs[i]=l;
    }
   }
  }

  winset(CloseDocs);
   cpack(0xFF000000); clear(); cpack(0xFFFFFFFF);
   k=13.;
    for(i=numkey+1; i<=numkey+26; i++) 
    {
     int temp;
      k-=1.;
       temp = closedocs[i-1];
      cmov2(-18.,(k*1.5));
     charstr(*(word+temp));
    }
return(0);
}


/****************************************************************/
/* Routine to reinitialize coordinates to originals 		*/
/****************************************************************/
RubySlippers()
{
int i;

  for(i=0;i<=numdocs;++i) 
  {
   xord[i] = orig_xord[i];
    yord[i] = orig_yord[i];
   zord[i] = orig_zord[i];
  }
return(0);
}


/****************************************************************/
/* Display documents based on their number			*/
/****************************************************************/
int Retrieve_docs(argc, argv, file_id, pglove)
    int argc; char *argv[];
    pglove_data *pglove; 
    int file_id;
{
  char ident[10], line[80], buffer[80], term[2];
  int k;
  FILE *fp2;

  /* Assign terminator between documents in database file */
  term[0] = ';';
   term[1] = '\n';   
  term[2] = '\0';  

  /* Open the database file */
  if ((fp2 = fopen(argv[2], "r")) == NULL)
  {
   printf("Could not open database file!\n");
   exit(1);
  }     

  /* Get user input for document number to search for */
  Start:
   system("clear");
    tpon();
     setvaluator(MOUSEX,500,-20000,20000);
     setvaluator(MOUSEY,100, -20000,20000);
      pagecolor(WHITE); textcolor(BLUE);
       printf("*** Please type the document NUMBER (ex: 204933).  Then press  <ENTER>\n");
       printf("    Type C to cancel\n");
        scanf("%s",ident);  
         if((ident[0] == 'c') || (ident[0] == 'C')) 
         {
          pagecolor(BLUE); textcolor(WHITE);         
           system("clear");
            winset(SpaceWindow); winpop();
             setvaluator(MOUSEX,-2000,-20000,20000);
             setvaluator(MOUSEY,-2000,-20000,20000); 
              mode = 1; /* read_pglove(file_id,&pglove); */
              pglove->thumb = pglove->one = pglove->two = pglove->three = 0; 
             trans = 0; /* need to read glove again, because data
                           are being buffered!! */
            crap = 1;
           return 1; 
          }

  /* Flash the screen while looking... */
  Find:
   printf("\n*** Looking for document number %s\n",ident);
   printf("    Please wait.\n");
    rewind(fp2);
     while(!feof(fp2)) 
     {
      if(slow_search(ident,fp2) == 0) goto Display;
       pagecolor(BLUE); textcolor(WHITE);       
        if(slow_search(ident,fp2) == 0) goto Display;
       pagecolor(WHITE); textcolor(BLUE);     
     }

  /* Document was not found */
  system("clear");
   textcolor(WHITE); pagecolor(RED);
    printf("\n*** Document not found !\n\n");
    printf("   Enter C to cancel or type a new document number:\n");
     scanf("%s",ident);
     if((ident[0] == 'c') || (ident[0] == 'C')) 
     {
      pagecolor(BLUE); textcolor(WHITE);       
       system("clear");
        winset(SpaceWindow); winpop();
         setvaluator(MOUSEX,-3000,-20000,20000);
         setvaluator(MOUSEY,-3000,-20000,20000);
        mode = 1; /* read_pglove(file_id,&pglove); */
       pglove->thumb = pglove->one = pglove->two = pglove->three = 0; trans = 1;
      return(1); 
     }
    goto Find; /* try again.... */

  /* Document was found */
  Display:
   textcolor(WHITE); pagecolor(BLUE);  
    printf("\n\n\nFound!\n");
    printf("\nPress the LEFT mouse button to continue....\n");
     winset(Output); winpop();      
      cpack(0xFF808080); clear(); cpack(0xFF0000A0); /* darkish red */     
       cmov2i(120,720); /* was 120,580 */
        charstr("*** Click LEFT mouse button to continue ***");
         k = 700; /* was 560 */
          cpack(0);

         fgets(line, 79, fp2); /* read the first line */
        while (strcmp(term, line) != 0) 
        {
         cmov2i(10,k);
          charstr(line);
          fgets(line,79,fp2);
         k-=15;
        }
  while(!getbutton(LEFTMOUSE)); /* wait... */

  /* Done.  Cleanup and return */
  winpush(Output);
   pagecolor(BLUE); textcolor(WHITE);      
    system("clear");
     mode = 1; /* read_pglove(file_id,&pglove); */
    pglove->thumb = pglove->one = pglove->two = pglove->three = 0; trans = 1;
   winset(SpaceWindow); winpop();
  setvaluator(MOUSEX,-3000,-20000,20000);
  setvaluator(MOUSEY,-3000,-20000,20000);
return(0); 
}


/****************************************************************/
/* Find the start of the desired document			*/
/****************************************************************/
slow_search(ident, fp2)
     char *ident;
     FILE *fp2;
{
  char line[80];
  char test[12];
  int identLen;
  int j=0;

  /* Assign string to search for */
  identLen = strlen(ident);
   strcpy(test,ident);
    test[identLen] = ';';
   test[identLen + 1] = '\n'; 
  test[identLen + 2] = '\0';

  while(j < 5000) 
  {
   fgets(line,80,fp2);
    if (strcmp(test, line) == 0) return(0);
     if (feof(fp2)) return(1);
    j+=1;
  }
return(1);
}


/****************************************************************/
/* Stop leftmouse from changing modes				*/
/****************************************************************/
search_vocabulary(file_id, pglove)
     pglove_data *pglove; 
     int file_id;
{
   setvaluator(MOUSEX,1020,-20000,20000);
   setvaluator(MOUSEY,50,-20000,20000);
    tpon(); 
     textcolor(BLACK); pagecolor(GREEN);   
      system("clear");
       printf("\n\n*** Use the left mouse button to scroll the Vocabulary\n");
       printf("    window (to the right of the screen).\n\n");
       printf("*** To find a term in the space, press the F key\n");
       printf("    Press the MIDDLE mouse button to return to Interactive mode\n");
        while((!getbutton(MIDDLEMOUSE)) && (!getbutton(FKEY))); /* wait... */
       winset(SpaceWindow); winpop();
      system("clear");
     pagecolor(BLUE); textcolor(WHITE);  
    setvaluator(MOUSEX,-3000,-20000,20000);
    setvaluator(MOUSEY,-3000,-20000,20000);
   mode = 1; /* read_pglove(file_id,&pglove); */
  pglove->thumb = pglove->one = pglove->two = pglove->three = 0; trans = 1;
return(0);
}


/****************************************************************/
/* Goto a chosen vocabulary word				*/
/****************************************************************/
find_term(file_id, pglove)
     pglove_data *pglove; 
     int file_id;
{
  int i, p;
  char ident[48];
  register float moveX, moveY, moveZ;

  system("clear");
   tpon();
    setvaluator(MOUSEX,500,-20000,20000);
    setvaluator(MOUSEY,100, -20000,20000);
     pagecolor(CYAN); textcolor(MAGENTA);     
      printf("*** Please type the term you want to find, then press <ENTER>\n");
      printf("    Type enough to uniquely identify the term.  Type C to cancel\n");
       scanf("%s",ident);  
        if (strlen(ident) <= 2) /* cancel request? */
        { 
         if((ident[0] == 'c') || (ident[0] == 'C')) 
         {
          pagecolor(BLUE); textcolor(WHITE);         
           system("clear");
            winset(SpaceWindow); winpop();
            setvaluator(MOUSEX,-3000,-20000,20000);
            setvaluator(MOUSEY,-3000,-20000,20000);
           mode = 1; /* read_pglove(file_id,&pglove); */ 
          pglove->thumb = pglove->one = pglove->two = pglove->three = 0; trans = 1;
         return(1); 
         }
        }


  Find:
  p = strlen(ident);
   for(i=0; i<=numkey; i++) 
   {
    if (strncmp(*(word+i),ident,p) == 0) goto Move_it;
   }

  /* Term was not found */
  system("clear");
   textcolor(WHITE); pagecolor(RED);
    printf("\n*** Term not found !\n\n");
    printf("   Enter C to cancel or type a new term:\n");
     scanf("%s",ident);
      if (strlen(ident) <= 2) /* cancel request? */
      { 
       if((strlen(ident) == 1) && ((ident[0] == 'c') || (ident[0] == 'C'))) 
       {
        pagecolor(BLUE); textcolor(WHITE);        
        system("clear");
         mode = 1; trans = 1;
         winset(SpaceWindow); winpop();
          setvaluator(MOUSEX,-3000,-20000,20000);
          setvaluator(MOUSEY,-3000,-20000,20000);
         mode = 1; /* read_pglove(file_id,&pglove); */
        pglove->thumb = pglove->one = pglove->two = pglove->three = 0; trans = 1;
       return(1); 
       }
      }
  goto Find; /* try again.... */

  Move_it:
  moveX = -orig_xord[i]; moveY = -orig_yord[i]; moveZ = -orig_zord[i] - .5;
   for (i=0; i <= numdocs; ++i)
   {
    xord[i] = orig_xord[i] + moveX;
     yord[i] = orig_yord[i] + moveY;
    zord[i] = orig_zord[i] + moveZ;
   }
   totdeltaX = moveX; totdeltaY = moveY; totdeltaZ = moveZ;

  /* Done.  Cleanup and return */
  winpush(Output);
   pagecolor(BLUE); textcolor(WHITE);   
    system("clear");
     winset(SpaceWindow); winpop();
    setvaluator(MOUSEX,-3000,-20000,20000);
    setvaluator(MOUSEY,-3000,-20000,20000);
   mode = 1; /* read_pglove(file_id,&pglove); */
  pglove->thumb = pglove->one = pglove->two = pglove->three = 0; trans = 1;
return(0);
}


/****************************************************************/
/* Display help screen						*/
/****************************************************************/
help()
{
 tpon();
  pagecolor(BLACK); textcolor(GREEN);
   system("cat help.file");
  while(!getbutton(MIDDLEMOUSE));
 tpoff(); winset(SpaceWindow); winpop();
return;
}















