#include <stdio.h>
#include <math.h>
#include <signal.h>
#include "DG2define.h"
#include "view.h"
#include "define_color.h"
#include "defs.h"
#include "state_exts.h"
#include "hand.h"

#define DEG2RAD         0.0174532
#define NUM_JOINTS      10
#define PI              3.14159
#define ROT180(a)       ((a<0.0)?((a)+PI):(a-PI))
#define SKIN_1          0.75, 0.50, 0.40
#define SKIN_2          0.75, 0.44, 0.30

static double hand_Angle[NUM_JOINTS];
static double hand_X,hand_Y,hand_Z;
static double hand_Roll, hand_Pitch, hand_Yaw;

extern load_gesture_table();
extern recognize_gesture();
extern open_devices();
extern init_grid();
extern track_fingers();

init_glove();
draw_hand();
/*********************************************************************************/
/**                                                                             **/
/**                                    get_hand_vals()                          **/
/**                                                                             **/
/*********************************************************************************/
get_hand_vals(gdata, fd)
DG2_glove *gdata;
int fd;
{
    int i, n;

    DG2_get(0, gdata);
    
    /* Assign joint angles */
    hand_Angle[0] = (double)gdata->flexion[0];
    hand_Angle[1] = (double)gdata->flexion[1];
    hand_Angle[2] = (double)gdata->flexion[2];
    hand_Angle[3] = (double)gdata->flexion[3];
    hand_Angle[4] = (double)gdata->flexion[4];
    hand_Angle[5] = (double)gdata->flexion[5];
    hand_Angle[6] = (double)gdata->flexion[6];
    hand_Angle[7] = (double)gdata->flexion[7];
    hand_Angle[8] = (double)gdata->flexion[8];
    hand_Angle[9] = (double)gdata->flexion[9];
    
    /* Assign orientation and position of hand */
    hand_X = (double)gdata->spatial.x;
    hand_Y = (double)gdata->spatial.y;
    hand_Z = (double)gdata->spatial.z;
    
    hand_Roll = gdata->spatial.roll;
    hand_Pitch = gdata->spatial.pitch;
    hand_Yaw = gdata->spatial.yaw;
   
    hand_Roll = -ROT180(hand_Roll);
    hand_Pitch = -hand_Pitch;
    hand_Yaw = ROT180(hand_Yaw);
    
    /*hand_Roll = -ROT180(hand_Roll);
    hand_Pitch = -hand_Pitch;
    hand_Yaw = ROT180(hand_Yaw);*/
    
    recognize_gesture(gdata, 1, fd);
}

/*********************************************************************************/
/**                                                                             **/
/**                                    draw_hand()                              **/
/**                                                                             **/
/*********************************************************************************/
draw_hand(fd)
int     fd;
{
int     i, j, u, v;
float   xform[4][4];
float   thumb_side_surface[15][8][3];
float   finger_side_surface[15][8][3];
float   sine,cosine;
double  theta;
static  float pi=3.141592654;
gescape_arg arg1,arg2;

static float thumb_side[8][3] = {       /* b-spline surface on the thumb side of palm */
        {1.25, 1.25, -4.0},
        {1.50, 1.25, -2.5},
        {1.75, 1.20, -1.6},
        {2.00, 1.10, -1.00},
        {2.20, 0.90, -0.50},
        {2.40, 0.75, -0.25},
        {2.60, 0.40, 0.1},
        {2.80, 0.40, 0.0}
};
static float finger_side[8][3] = {      /* b-spline surface on the little finger side of palm */
        {-3.25, 1.25, -4.0},
        {-3.75, 1.25, -2.5},
        {-4.00, 1.20, -1.6},
        {-4.25, 1.10, -1.00},
        {-4.25, 0.90, -0.50},
        {-4.25, 0.75, -0.25},
        {-4.25, 0.40, 0.1},
        {-4.25, 0.25, 0.0}
};

static float u_knots[12] = {    /* b-spline surface knots of palm */
        {0.0, 0.0, 0.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 5.0, 5.0, 5.0}
};

     curve_resolution(fd, STEP_SIZE, 1.2, 1.2, 1.2, 1.2);

     /************************** Orientation and Position ************************/
     translate3d(hand_X, hand_Y, hand_Z, xform);
     concat_transformation3d(fd, xform, PRE, PUSH); 
     rot3d(hand_Pitch, hand_Yaw, hand_Roll, xform);
     concat_transformation3d(fd, xform, PRE, REPLACE);
     translate3d(-0.5, -0.5, -0.5, xform);
     concat_transformation3d(fd, xform, PRE, REPLACE);
     scale3d(0.8, 0.8, 0.8, xform);
     concat_transformation3d(fd, xform, PRE, REPLACE);

     arg1.i[0] = 0xA5A5;
     /* arg1.i[0] = 0x0505;*/
     gescape(fd, TRANSPARENCY, &arg1, &arg2);

     fill_color(fd, SKIN_2);
     interior_style(fd, INT_SOLID, NoEdges);
     vertex_format(fd,0,0,NoRGB,NoNormals,CLOCKWISE);           /* only for the top of palm polygon */
     polygon3d(fd,palm_top_end[0],PALM_END_POINTS,FlagForIntStyle);
     vertex_format(fd,3,0,NoRGB,NoNormals,CLOCKWISE);           /* for the other polygons in fingers */

     /*********************************** Palm ***********************************/

     interior_style(fd, INT_SOLID, NoEdges);
     fill_color(fd, SKIN_2);
     scale3d(0.9, 0.4, 0.6, xform);
     concat_transformation3d(fd, xform, PRE, PUSH);

     /* create bspline palm control points for one side */
     theta = -pi/6.0;
        for (i=0; i<15; i++) {
                sine = sin(theta);
                cosine = cos(theta);
                for (j=0; j<8; j++) {
                        thumb_side_surface[i][j][0] = thumb_side[j][0]*sine;
                        thumb_side_surface[i][j][1] = thumb_side[j][1]*cosine;
                        thumb_side_surface[i][j][2] = thumb_side[j][2];
                }
                theta += pi/6.0;
        }
     u_knot_vector (fd,u_knots,12);
     spline_surface (fd,thumb_side_surface,8,9,CUBIC,CUBIC,NONRATIONAL);

     /* create bspline palm control points for other side */
     theta = -pi/6.0;
        for (i=0; i<15; i++) {
                sine = sin(theta);
                cosine = cos(theta);
                for (j=0; j<8; j++) {
                        finger_side_surface[i][j][0] = finger_side[j][0]*sine;
                        finger_side_surface[i][j][1] = finger_side[j][1]*cosine;
                        finger_side_surface[i][j][2] = finger_side[j][2];
                }
                theta += pi/6.0;
        }
     u_knot_vector (fd,u_knots,12);
     spline_surface (fd,finger_side_surface,8,9,CUBIC,CUBIC,NONRATIONAL);
     pop_matrix(fd);            /* pop the scaling matrix as it's used for the palm only */

     arg1.i[0] = 0xFFFF;
     gescape(fd, TRANSPARENCY, &arg1, &arg2);
     interior_style(fd, INT_SOLID, NoEdges);

     /*********************************** Thumb ***********************************/

     translate3d(1.25, 0.2, -0.20, xform);      /* raised in x and y but z is at the base of fingers */
     concat_transformation3d(fd, xform, PRE, PUSH); 
     /*rot3d(0.0, -hand_Angle[0], 0.0, xform);*/
     rot3d(-hand_Angle[0], -hand_Angle[0], 0.0, xform); /* rot about axis different from the finger rot axis */
     concat_transformation3d(fd, xform, PRE, REPLACE);

     /*fill_color(fd, SKIN_1);*/
     fill_color(fd, RED);
     for (j = 0; j < FINGER_FACETS; j++) 
            polygon3d(fd,inner_knuckle[j],FINGER_POINTS,FlagForIntStyle);

     polygon3d(fd,inner_knuckle_end[1],KNUCKLE_END_POINTS,FlagForIntStyle);
     polygon3d(fd,inner_knuckle_end[0],KNUCKLE_END_POINTS,FlagForIntStyle);

     /* upper knuckle */
     translate3d(0.0, 0.0, 0.65, xform);
     concat_transformation3d(fd, xform, PRE, REPLACE); 
     rot3d(0.0, -hand_Angle[1], 0.0, xform);
     concat_transformation3d(fd, xform, PRE, REPLACE);

     for (j = 0; j < FINGER_FACETS; j++) 
            polygon3d(fd,thumb_outer_knuckle[j],FINGER_POINTS,FlagForIntStyle);

     polygon3d(fd,thumb_outer_knuckle_end[1],KNUCKLE_END_POINTS,FlagForIntStyle);
     polygon3d(fd,thumb_outer_knuckle_end[0],KNUCKLE_END_POINTS,FlagForIntStyle);

     pop_matrix(fd);

     /*********************************** Fingers ***********************************/
     for (i=0; i<4; i++)
     {
             if(i==0) fill_color(fd, MIDNIGHTBLUE);
             if(i==1) fill_color(fd, LIMEGREEN);
             if(i==2) fill_color(fd, LIGHTBLUE);
             if(i==3) fill_color(fd, SALMON);
             /*translate3d(((double)i * -1.0), 0.0, 1.0, xform);*/
             translate3d(((double)i * -1.0), 0.5, 0.0, xform);
             concat_transformation3d(fd, xform, PRE, PUSH); 
             rot3d(-hand_Angle[(i+1)*2], 0.0, 0.0, xform);
             concat_transformation3d(fd, xform, PRE, REPLACE);

             /*fill_color(fd, SKIN_1);*/
             for (j = 0; j < FINGER_FACETS; j++) 
                        polygon3d(fd,inner_knuckle[j],FINGER_POINTS,FlagForIntStyle);
             polygon3d(fd,inner_knuckle_end[1],KNUCKLE_END_POINTS,FlagForIntStyle);
             polygon3d(fd,inner_knuckle_end[0],KNUCKLE_END_POINTS,FlagForIntStyle);

             translate3d(0.0, 0.0, 0.8, xform);       /* to make the edges touch */
             concat_transformation3d(fd, xform, PRE, REPLACE);
             rot3d(-hand_Angle[((i+1)*2)+1], 0.0, 0.0, xform);
             concat_transformation3d(fd, xform, PRE, REPLACE);

             for (j = 0; j < FINGER_FACETS; j++) 
                        polygon3d(fd,outer_knuckle[j],FINGER_POINTS,FlagForIntStyle);
             polygon3d(fd,outer_knuckle_end[1],KNUCKLE_END_POINTS,FlagForIntStyle);
             polygon3d(fd,outer_knuckle_end[0],KNUCKLE_END_POINTS,FlagForIntStyle);

             pop_matrix(fd);
     }
     
     pop_matrix(fd);
}

/*********************************************************************************/
/**                                                                             **/
/**                                    init_glove()                             **/
/**                                                                             **/
/*********************************************************************************/
init_glove()
{
        char glovepath[128], dummy[16];
        int retval, Ans, c;
        DG2_glove gdata;
        char path1[50], path2[50];
        char Str1[3], Str2[3]; 

        printf("The Path to DataGlove Port is /dev/tty1p5 \n");
        printf ("Initializing Glove\n");
        retval = DG2_open(0, "/dev/tty1p5");
        if (retval != DG2_OK)
                {
                printf("Initialization Error %d\n", retval);
                DG2_close(0);
                return;
                }

        printf("Do you want to load Cailbration file cal? \n");
        printf("<y><retif Yes and <n><retif No... ");

        /*gets(Str1);*/
        gets(Str1);

        if(Str1[0] == 'n')
                {
                printf("Flat Hand, <retwhen ready ... "); getchar();
                retval = DG2_calibrate_limits(0, DG2_FLAT);
                if (retval != DG2_OK)
                        {
                        printf("Calibration Error %d\n", retval);
                        DG2_close(0);
                        return;
                        }

                printf("Bend Thumb, <retwhen ready ... "); getchar();
                retval = DG2_calibrate_limits(0, DG2_BENT1);
                if (retval != DG2_OK)
                        {
                        printf("Calibration Error %d\n", retval);
                        DG2_close(0);
                        return;
                        }
        
                printf("Bend Fingers, <retwhen ready ... "); getchar();
                retval = DG2_calibrate_limits(0, DG2_BENT2);
                if (retval != DG2_OK)
                        {
                        printf("Calibration Error %d\n", retval);
                        DG2_close(0);
                        return;
                        }
        
                printf("Do you want to save Cailbration file cal? \n");
                printf("<y><retif Yes and <n><retin No... ");
                gets(Str2);
                if(Str2[0] == 'y')
                        {
                        printf("Enter name of file to saved : \n");
                        gets(path2);
                        printf("Saving Cailbration file %s \n", path2);
                        retval = DG2_calibrate_file(0, DG2_SAVE, path2);
                        if (retval != DG2_OK)
                                {
                                printf("Calibrate File Saving Error %d\n", retval);
                                DG2_close(0);
                                return;
                                }
                        }
                }       /* End of main if loop */

        else 
                {
                printf("Enter name of file to load : \n");

                gets(path1);

                printf("Loading Cailbration file %s \n", path1);
                retval = DG2_calibrate_file(0, DG2_LOAD, path1);
                if (retval != DG2_OK)
                        {
                        printf("Calibrate File Loading Error %d\n", retval);
                        DG2_close(0);
                        return;
                        }
                }

        printf("Set Origin, <retwhen ready ... "); getchar();
        retval = DG2_origin( 0 );
        if (retval != DG2_OK)
                {
                printf("Set_origin Error %d\n", retval);
                DG2_close(0);
                return;
                }

        retval = DG2_calibrate_output(0, DG2_ANGLES);
        if (retval != DG2_OK)
                {
                printf("Units Error %d\n", retval);
                DG2_close(0);
                return;
                }

        printf("Starting Glove ...\n");
        retval = DG2_start(0);
        
        if (retval != DG2_OK)
                {
                printf("Start Error %d\n", retval);
                DG2_close(0);
                return;
                }

/*      load_gesture_table("ges_table.c");*/

}
/******************************************************************/
/*   EXCEPTION HANDLING OF TLOSS ERRORS                           */
/*****************************************************************/

int matherr (x)
register struct exception *x;
{
switch(x->type) {

     case TLOSS:
               return(1);

               }}
