This archive contains the executable of the IRIT solid modeler and the
accompanying files needed for proper executaion. It is highly recommended
you get the (Ansi C) sources of this package which suppose to be in a
similar zip file by the name iritsm3s.zip.

These executables were created using DJGPP, the GCC port to MSDOS. The
executables will run on a system with at least a 386. This port is new
and have its problems. The major problems are bugs in the 387 emulation
code and its slowness. Since I do not posses a 387, these executables were
compiled using emu387 and therefore may introduce incorrect code (even if
you have a 387 since during the compilation emu387 is used). If you encounter
such a problem you may consider recompiling the code from the sources.
Since emu387 is so slow, these executables were not fully tested.

In order to use these executables you must unzip the runtime.zip file into
a directory in your path (Same place as executables themselves is probably
o.k.). This zip file holds the runtime files of DJGPP - all files that are
required for proper execution. Edit djgcc.bat and set the right
directory where this run time is. djgcc.bat assumes the directory is c:/djgpp
so search for 'c:/djgpp' and replace with your directory location. Note
this batch file add 'c:/djgpp' to your path. You may not need that if the
directory is already in your path. Remove the 'emu c:/djgpp/emu387' if you
have 387. Finally this batch file sets your Super VGA driver - find out
which driver is for you in the drivers directory of the runtime.zip and
copy it to your runtime directory. Change the driver name in djgpp.bat
appropriately. If none can be used remove the 'driver c:/...' from GO32
variable. The regular VGA in 320x200 in 256 colors mode will be used by
default. Dont expect much in this LOW resolution.

Now type 'djgpp.bat' to set the environment. You need do it only once.
After that you can run any of the executables as a regular MSDOS executables.

Problems associated with this run time package/compiler should be addressed
to DJGPP author DJ Delorie (dj@ctron.com) or the DJGPP mailing list
djgpp@sun.soe.clarkson.edu or djgpp-resuest@sun.soe.clarkson.edu.

The full DJGPP GCC to MSDOS port is also available in simtel20.arpa.mil
and its mirrors at PD:<MSDOS.DJGPP> directory.

Gershon Elber

gershon@gr.utah.edu
