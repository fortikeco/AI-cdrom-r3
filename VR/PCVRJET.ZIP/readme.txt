PCVR Presents...



                                PCVR Jet



This program represents a simple Virtual Reality implementation of a
jet fighter.  Although crude, the program will allow you to interact in
a three-dimensional jet fighter.  Using the Mattel Powerglove, you can
control the movement of the jet as well as change different aspects of the
jet.

REQUIREMENTS:

                * 80386 PC or better
                * Mattel Powerglove connected to PC
                  (Check the file PCVRINFO for information on PCVR and
                   the interconnection)
                * Sega 3D Glasses (or equivalent)

CONTROLS:
Controlling the jet is very simple.  Once the program starts, you will see
a control stick in the lower middle part of the screen.  This is what controls
the jet.  To move, place your virtual hand on the top of the control stick and
grip your hand.  Once you have done this, you can move your hand in the
direction that you want to go.  To stop moving, simple release your grip.

To change the speed of the jet, use the index finger of the virtual hand to
touch the top red button to the right of the control stick.  A floating menu
will appear.  This menu allows you to change the speed of the jet.  Touch the
top button to increase the speed, touch the middle button to decrease the speed
and touch the bottom button when you are finished.

In addition to moving around, you can fire a missile.  Press B on the keyboard
and an explosion will appear in the distance.  To change the range of the
missile, press the middle button on the main control panel.  A different
floating menu will appear that will allow you to change the missile distance.
The last button allows you to leave the menu.

It is possible to hit and remove the different mound formations that
appear in the landscape but its not easy.  The mounds were formed using
the program makecld.exe included in the distribution.

The bottom button on the control panel allows you to leave the simulation or
press Q on the keyboard.


3D:
This program cannot be used in 3D because of problems detailed in the
racquetball game and column in PCVR magazine.  I know it's not as good
in monoscopic as in 3D but there's nothing I can do about it.

PURPOSE:
The purpose of this program is not one of entertaiment.  The capabilities of
the rendering system, my artistic abilities, and the poor resolution of the
Powerglove do not make for a good game.  But what this program should do is
give you ideas for additional programs.  We have included the source code in
order to show you 1) how collision detection is done, 2) how to use
floating menus, 3) how movement can be perfomred using the Mattel Powerglove.

The program is written in REND386 using the same libraries included in the
PCVR Racquetball game released some time ago.

Enjoy using the simulation and let's see some more uses for the Powerglove
in the near future.

FUTURE:
Coming from PCVR late December, a Virtual Drum set using the 3D sound
system described in our sixth issue.

DISTRIBUTION:
The program is called PCVRJET.EXE and is a self-extracting executable file.
The program is uploaded on karazm.math.uh.edu in their incoming directory.
The program should also be available at sunee.uwaterloo.ca in the
pub/REND386/application directory as soon as it is moved from the incoming
directory.
