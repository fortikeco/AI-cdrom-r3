/*	Soccer - generate a "soccer ball" .plg file for Rend386

	Written March 1993 by John T. Bell

	Syntax: soccer side out_hex_color out_pent_color do_inside
			in_hex_color in_pent_color

	where the arguments are all optional and have the following default
	values.  ( Note that arguments may only be left off of the end,
	not from the beginning. )

	Parameter	Default		Meaning
	=========	=======		=======
	side		100		Length of a side joining two polys
	out_hex_color	0x1FFF		Color of outer hexagons ( Base 16! )
	out_pent_color	0x1E0F		Color of outer pentagons (  "   "  )
	do_inside	not present	The inside of the soccer ball is
					generated if this argument has a value
	in_hex_color	0x11FF		Color of inner hexagons ( Base 16! )
	in_pent_color	0x1AFF		Color of inner pentagons (  "   "  )

	The original purpose in generating this program was to create a
	faster sphere than the one I had previously, by generating a sphere
	with the fewest possible number of vertices.  On my machine the 
	soccer ball is rendered two and a half times faster than the sphere
	which I started with, so on that score the program is a definite
	success.  ( 30 frames / sec vs 12, "twirling", with neither sphere 
	having an "inside" ).

	An additional beneficial side effect, is the creation of some pretty
	neat spheres with the right combinations of surfaces and colors.
	For example, try using a "glass" surface for the outer pentagons,
	along with some contrasting inner colors.  Also, in the output
	file, soccer.plg, the lines for an outer polygon and it's
	corresponding inner mate are always adjacent lines, so by editing
	the soccer.plg file and deleting a pair of lines you can create
	a soccer ball with a "hole" in it.  Or if you just need a simple
	sphere, use identical colors for outer hexagons and pentagons and
	don't do the inside.
