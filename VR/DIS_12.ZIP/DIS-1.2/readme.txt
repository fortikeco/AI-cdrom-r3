DIS Network Utilities
=====================
To build the binaries, follow the instructions in "src".
For more information on DIS, obtain the military standard, "Protocol Data Units
for Entity Information and Entity Interaction in a Distributed Interactive
Simulation," October 31, 1991, from:

                 Institute for Simulation and Training (IST)
                12424 Research Parkway, Suite 300
                Orlando, FL 32826

[This distribution is based on Version 1.0 of DIS

Files
-----
InteropDISLib.txt - ASCII version of paper presented to Seventh DIS Workshop
InteropDISLib.ps  - PostScript version of same
