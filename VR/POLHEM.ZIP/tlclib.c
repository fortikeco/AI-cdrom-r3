#include  "tlclib.h"
/*****************************************************************************/
/*                                                                           */
/* library:	tlc_lib		                                             */
/*                                                                           */
/* purpose:	Provide a coherent interface between a host computer         */
/*		and the TLC, ISOTRAK or SHMS 4.				     */
/*                                                                           */
/* routines:	tlc_open()	open the 3space for communication	     */
/*		tlc_get()	get a record from the 3space		     */
/*		tlc_cnv()	convert current data record		     */
/*		tlc_put()	send a character string to the 3space	     */
/*		tlc_sbr()	set baud rate on TLC			     */
/*		tlc_clos()	close the 3space for communication	     */
/*									     */
/*****************************************************************************/

#define    	port		0
#define	   	MAXSOR		2
#define    	MAXSTA		8
#define	   	BUFSIZ		512
#define	   	MAXUSE		256
#define    	MINUSE		128
#define    	STK_SIZ		128
#define    	TIMOUT		32766
#define    	MAXTRY		10
#define    	XON		"\021"
#define    	XOFF		"\023"
#define    	CR		0x0D
#define    	LF		0x0A
#define    	NULL		'\0'
#define    	S		(station - '1')
#define    	vector(i)    	(_vector + i)
#define    	convert(x,y,z)	(sys_for ? binfnc(x,y,z) : ascfnc(x,y))
#define    	encoded		(sys_stm && sys_for)
/**/
/*****************************************************************************/
/*									     */
/*                          EXTERNAL DECLARATIONS	 		     */
/*									     */
/*****************************************************************************/

extern	int 	com_open();			/* open a serial port */
extern	int	com_on();			/* enable port interrupts */
extern	int	com_off();			/* disable port interrupts */
extern	int	com_sbr();			/* set baud rate on 8250 */
extern	int	com_put();			/* output byte thru port */
extern	int	com_clos();			/* close serial port */

extern	char    *getmem();			/* memory allocator */
extern  int     rlsmem();			/* memory deallocator */
extern	int	atoi();				/* ascii to integer */
extern	double	atof();				/* ascii to floating point */

/**/
/*****************************************************************************/
/*									     */
/*                        STATIC DATA DEFINITIONS	 		     */
/*									     */
/*****************************************************************************/

struct	radiator   sources [MAXSOR];
struct	sensor     stations [MAXSTA];
struct	_tlcdata   tlcdata;
struct	_sptrs     sptrs = {&tlcdata, sources, stations};
struct  _sptrs     *psptrs = &sptrs, *tlc_open();

union   _bdata{
  int 	_int;
  char	_chr[2];}  bdata;

char	tlc_get();				/* get record from tlc */
float	matof();				/* string to float converter */

static char *stk_ptr;				/* pointer to stack */

static int	xoff_flg;			/* XOFF issued to system */
static int 	dig_ofs;			/* comp record offset count */
static int	index;				/* char string index */
static int	inp_cnt;			/* input byte count */
static int	head;				/* head of input list */
static int	tail;				/* tail of input list */
static int	cr_snt;				/* <CR> sent flag */
static char	lst_com;			/* last command sent */
static int	Oflag;				/* # 'O' chars sent */

static int	sys_ext;			/* extended commands on */
static int	sys_trk;			/* tracker commands on */
static int	sys_for;			/* data record format */
static int	sys_unt;			/* english or metric units */
static int	sys_stm;			/* continuous input mode */
static int	sys_siz;			/* bytes in data record */
static int	sys_tcn;			/* items in data record */
static int	sys_tbl[32];			/* table of item values */
static int	opn_flag;			/* port open/closed flag */

static char	inp[BUFSIZ];			/* incoming data buffer */
static char	data_rec();			/* returns data record type */

static int      asc_siz[13] = {1,2,21,0,21,21,21,21,21,21,21,28,49};
static int      bin_siz[13] = {1,2,6,0,6,6,6,6,6,6,6,8,14};

static float	rngscl[2] = {65.49/32767,166.33/32767}; 

static float	angscl   = 229.19/32767;	/* angular scale factor */
static float	fulscl   = 1./32767;		/* full scale value */
static float	slfscl   = 10./32767;		/* self-cal scale factor */
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	tlc_col (word)                                               */
/*                                                                           */
/* purpose:	interrupt service routine for TLC                            */
/*                                                                           */
/* inputs:	word contains the input byte in the lower order bits         */
/*		     and the status bits in the higher order byte.           */
/*									     */
/* outputs:	Data is stored in a circular buffer at the current value     */
/*		of 'tail' and the count of data in the buffer is updated.    */
/*                                                                           */
/*****************************************************************************/
static 	 tlc_col(word)
unsigned word;
{
	inp [tail++] = (char) (word & 0xff);
  	tail %= BUFSIZ;

  	if (++inp_cnt > MAXUSE)
        	if (xoff_flg == 0)
                {
                	xoff_flg = 1;
                	com_put (port,'\023');
              	}
}
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	tlc_open ()		                                     */
/*                                                                           */
/* purpose:	open the TLC and initialize the data base                    */
/*                                                                           */
/* inputs:	none.							     */
/*									     */
/* outputs:	0		if open was not successful   		     */
/*		psptrs		if open was successful                       */
/*                                                                           */
/*****************************************************************************/
struct 	_sptrs 	*tlc_open ()
{
int	i;

	if (opn_flag) 				        return (0);
	if ((stk_ptr = getmem(STK_SIZ)) == NULL)   	return (0);
	if (com_open(port,&tlc_col,stk_ptr,STK_SIZ)) 	return (0);

	opn_flag = 1;
	xoff_flg = 0;
	
	tlc_put (XOFF);
	wait (1,TIMOUT);
	
	head = tail = inp_cnt = 0;
  
  	tlc_put ("S");
  	com_on (port);
  	tlc_put (XON);

	if (tlc_get ('S') != 'S')
	{
		tlc_clos ();
      		return (0);
	}

	tlc_cnv ();

	sys_for = format;
	sys_unt = metflg;
	sys_stm = pcmode;
	sys_ext = extenb;
	sys_trk = trkenb;

	if (upd_oval ())
	{
		tlc_clos ();
		return (0);
	}
	else
		return (psptrs);  
}
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	char tlc_get (t) 	                                     */
/*                                                                           */
/* purpose:	retrieve a record from the tlc, decode and store             */
/*                                                                           */
/* inputs:	t		type of record to retrieve		     */
/*				 where NULL implies any record type	     */
/*									     */
/* outputs:	0		if record was not retrieved		     */
/*		record type	if record was retrieved                      */
/*                                                                           */
/*****************************************************************************/
char 	tlc_get (t)
char	t;
{
int	i,j;
char	c;

	if (opn_flag)
	{
		for (i = 0; i < MAXTRY; i++)
		{
			for (j = 0; tlc_cpy () == 0; j++)
			if ((t == NULL) || (j > TIMOUT)) 
				return (NULL);
	
			if (((c = data_rec ()) == '*')||(c == t)||(t == NULL))
				return (c);
		}
	}   
	return (NULL);
}
/**/
/*****************************************************************************/
/*									     */
/* function:	tlc_cnv ()						     */
/*									     */
/* purpose:	convert the current tlc data record using the definitions    */
/*		from the structure pointed to by pdata.			     */
/*									     */
/* inputs:	none							     */
/*									     */
/* outputs:	converted tlc data record stored at image		     */
/*									     */
/*****************************************************************************/
tlc_cnv ()
{
	type    = image(0);
	station = image(1);
	comkey  = image(2);

	switch (type)
	{
		case '1':
 	          dec_1rec();
		  break;

		case '2':
                  dec_2rec();
     		  break;

		default:
                  dec_0rec();
                  break;
	}
}
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	tlc_put (string)                                             */
/*                                                                           */
/* purpose:	output a data string to the TLC                              */
/*                                                                           */
/* inputs:	string		pointer to character string to output	     */
/*									     */
/* outputs:	0		if output was successful      		     */
/*		1		if output was not successful	             */
/*                                                                           */
/*****************************************************************************/
tlc_put (string)
char	*string;
{
int 	i;
char	c;

	if (opn_flag == 0) return (1);

	cr_snt = snd_stg (string);

	switch (c = (lst_com ? lst_com : *string))
	{
          case 'O':
            Oflag++;
          case 'A':
          case 'B':
          case 'G':
          case 'H':
          case 'I':
          case 'L':
          case 'N':
          case 'R':
          case 'V':
          case 'X':
          case 'Z':
          case 'b':
          case 'g':
          case 'l':
          case 'r':
          case 's':
          case 'y':
            if (cr_snt)
            {
        	        lst_com = NULL;
        	        if ((c == 'O') && (Oflag > 2)) upd_oval ();
        	        Oflag = 0;
            }
            else
        	      lst_com = c;
            break;
      
          case '\031':
            wait (15,TIMOUT);
            tlc_clos ();
            psptrs = tlc_open ();
            break;

          case 'C':
            sys_stm = pcmode = 1;
            if (encoded)
	              upd_oval ();
            break;
           
          case 'F':
            sys_for = format = 0;
            upd_oval ();
            break;

          case 'T':
            sys_trk = (sys_trk ? 0 : 1);
            trkenb = sys_trk;
            break;

          case 'U':
            sys_unt = metflg = 0;
            break;

          case 'W':
            if (sys_ext)
	    {
            	  sys_for = format = 0;
            	  sys_unt = metflg = 0;
            	  sys_stm = sys_ext = 0;
              	upd_oval ();
            }
            break;

          case 'c':
            sys_stm = pcmode = 0;
            upd_oval ();
            break;

          case 'f':
            sys_for = format = 1;
            upd_oval ();
            break;

          case 'a':
          case 'h':
          case 'k':
            upd_oval ();
            break;

          case 't':
            if (sys_trk)
	    {
	              sys_ext = (sys_ext ? 0 : 1);
	              extenb  = sys_ext;
            }
            break;

          case 'u':
            sys_unt = metflg = 1;
            break;

          default:
            break;
        }
} 
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	tlc_sbr (rate)                                               */
/*                                                                           */
/* purpose:	change the baud rate on TLC			             */
/*                                                                           */
/* inputs:	rate	new baud rate. Allowed rates are: 300, 1200, 	     */
/*			2400, 4800 and 9600.				     */
/*									     */
/* outputs:	none							     */
/*                                                                           */
/*****************************************************************************/
tlc_sbr (rate)
int	rate;
{
	if (opn_flag)
    		switch (rate)
    		{
    			case 300:
    			    com_sbr (port,2);
    			    break;
	
			case 1200:
		            com_sbr (port,4);
	        	    break;

        		case 2400:
        		    com_sbr (port,5);
        	            break;

 	                case 4800:
        		    com_sbr (port,6);
        		    break;

		       case 9600:
	                   com_sbr (port,7);
        	   	   break;
  
		      default:
        		   break;
		}
}
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	tlc_clos ()                                                  */
/*                                                                           */
/* purpose:	close the TLC					             */
/*                                                                           */
/* inputs:	none							     */
/*									     */
/* outputs:	none							     */
/*                                                                           */
/*****************************************************************************/
tlc_clos ()
{
	if (opn_flag)
	{
		      opn_flag = 0;
		      com_clos (port);
		      rlsmem (stk_ptr,STK_SIZ);
	}
}
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	tlc_cpy ()                                                   */
/*                                                                           */
/* purpose:	copy an input record to the user data area                   */
/*                                                                           */
/* inputs:      none							     */
/*                                                                           */
/* outputs:	0		if record was not copied                     */
/*		bytes copied	if record was copied                         */
/*                                                                           */
/*****************************************************************************/
static 	tlc_cpy()
{
int	count,new_head;

	if (inp_cnt)
	{
		switch (inp[head] & 0x7f)
		{
			case '1':
			case '2':
				new_head = move_inp(count=loc_lf());
				break;

			default:
				if (inp_cnt >= sys_siz)
					new_head = move_inp(count = sys_siz);
				else
					count = 0;
				break;
		}

		if (count)
		{
			com_off (port);
			head = new_head;
			if (((inp_cnt -= count) < MINUSE) && (xoff_flg))
			{
				xoff_flg = 0;
				com_put (port,'\021');	
			}
			com_on (port);
			tlc_twd (&count);
			return (count);
		}
	} 
	return (0);
}
/**/
/*****************************************************************************/
/*									     */
/* function:	tlc_twd (bytes)						     */
/*									     */
/* purpose:	unscramble tlc binary-continuous mode output data	     */
/*									     */
/* inputs:	bytes	pointer to number of bytes in record.		     */
/*									     */
/* outputs:	input data image is updated by removing the sync bits	     */
/*									     */
/*****************************************************************************/
static 	tlc_twd (bytes)
int	*bytes;
{
int i,j,imax;
char mask;

	if (image(0) & 0x80)
	{
		for (i = j = 0; i < *bytes;)
		{
			imax = (i+7 >= *bytes) ? *bytes - 1 : i + 7;
			mask = image(imax);
			for (; i < imax; i++,j++)
			{
				image(j) = image(i) | ((mask & 1) << 7);
				mask = mask >> 1;
			}
			i++;	
		}
		*bytes = j - 1;  
		image (0) &= 0x7f;
		image(j) = NULL;
	}
}
/**/
/*****************************************************************************/
/*									     */
/* function:	upd_oval ()						     */
/*									     */
/* purpose:	Update the system data record definitions.		     */
/*									     */
/* inputs:	none							     */
/*									     */
/* outputs:	0	if parameters updated.				     */
/*		1	otherwise.					     */
/*									     */
/*****************************************************************************/
static 	upd_oval ()
{
int	 i, temp;

	com_put (port,'\023');
	com_put (port,'c');
	temp = sys_stm;
	sys_stm = 0;
	wait (1,TIMOUT);

	snd_stg ("O\r\0");
	head = tail = inp_cnt = 0;
	com_put (port,'\021');
  
	if (tlc_get ('O') != 'O')
		return (1);

	tlc_cnv ();

	sys_tcn = tblcnt;
	for (i = 0;i < tblcnt; i++)
		sys_tbl[i] = tblout(i);
	
	if (temp) 
	{
		if (sys_for)
			dat_siz += ((dat_siz - 1) / 7) + 1;
		com_put (port,'C');
		sys_stm = 1;
	}
	sys_siz = dat_siz;

	return (0);
}
/**/
/*****************************************************************************/
/*									     */
/* function:	dec_0rec()						     */
/*									     */
/* purpose:	Decode the system data record.				     */
/*									     */
/* inputs:	System structure definition and data record.		     */
/*									     */
/* outputs:	Decoded data record stored at structure definition.	     */
/*									     */
/*****************************************************************************/
static 	dec_0rec ()
{
int	i;

	index = 3;
	for (i = 0; i < tblcnt; i++)
	{
		switch(tblout(i))
		{
			case 0:
				index++;
				break;

			case 1:
				index += 2;
				break;

			case 2:
				convert (&position(S,0),3,rngscl[sys_unt]);
				break;

			case 4:
				convert (&attitude(S,0),3,angscl);
				break;

			case 5:
				convert (&x_dircos(S,0),3,fulscl);
				break;

			case 6:
				convert (&y_dircos(S,0),3,fulscl);
				break;

			case 7:
				convert (&z_dircos(S,0),3,fulscl);
				break;

			case 8:
				convert (&x_rawsen(S,0),3,fulscl);
				break;

			case 9:
				convert (&y_rawsen(S,0),3,fulscl);
				break;

			case 10:
				convert (&z_rawsen(S,0),3,fulscl);
				break;

			case 11:
				convert (&q(S,0),4,fulscl);
				break;

			case 12:
				convert (&selfcal(0),7,slfscl);
				break;

			default:
				break;
		}
	}
}
/**/
/*****************************************************************************/
/*									     */
/* function:	dec_1rec()						     */
/*									     */
/* purpose:	Decode the system keypad records.			     */
/*									     */
/* inputs:	System structure definition and data record.		     */
/*									     */
/* outputs:	Decoded keypad record stored at structure definition.	     */
/*									     */
/*****************************************************************************/
static 	dec_1rec ()
{
int	i;

	switch (comkey)
	{
		case 'L':
			for (i = 0; i < 32; i++)
				padbuf(i) = image(i + 3);
			padbuf (i) = NULL;
			break;

		case 'Z':
			endflg = 1;
			break;
	
		default:
			break;
	}
}
/**/
/*****************************************************************************/
/*									     */
/* function:	dec_2rec()						     */
/*									     */
/* purpose:	Decode the system command response records.		     */
/*									     */
/* inputs:	System structure definition and data record.		     */
/*									     */
/* outputs:	Decoded command response record 	   		     */
/*									     */
/*****************************************************************************/
static 	dec_2rec ()
{
int	i,j,k,flags;

	index = 3;
	switch (comkey)
	{
		case 'A':
			ascfnc (&algcrd(S,0),9);
			break;

		case 'H':
			ascfnc (&hemcrd(S,0),3);
			break;
		
		case 'I':
			diginc = matof (&image(3), 7);
			break;

		case 'M':
			ascfnc (&isoprm(S,0),9);
			break;

		case 'N':
			ascfnc (&delpos(0),3);
			break;

		case 'V':
			ascfnc (&envtab(S,0),6);
			break;

		case 'R':
			ascfnc (&moucor(S,0),3);
			break;

		case 'l':
			for (i = 0; i < 8; i++)
				sspair(i) = image(3 + i) - '0';
			break;

		case 'O':
			for (i=dat_siz = 3,j = 0; image(i) != CR; i += 2, j++)
			{
				k = tblout(j) = matoi (&image(i), 2);
				dat_siz += (sys_for ? bin_siz[k] : asc_siz[k]);
			}
			tblcnt = j;
			if ((sys_stm)&&(sys_for)) dat_siz += ((dat_siz-1)/7)+1;
			break;

		case 'S':
			flags = matoi (&image(3), 3);
			format = flags & 1;
			metflg = (flags >> 1) & 1;
			comflg = (flags >> 2) & 1;
			pcmode = (flags >> 3) & 1;
			trkenb = (flags >> 4) & 1;
			extenb = (flags >> 5) & 1;
			digmod = (flags >> 6) & 3;
			biterr = matoi (&image(6), 3);
			biterw = matoi (&image(9), 6);
			sofrev = matof (&image(15),3)+(matof(&image(18),3)/1000);
			for (i = 0; i < 32; i++)
				condat(i) = image(21 + i);
			break;

		case '*':
			errcod = matoi (&image(9), 3);
			break;

		case 'C':
			ascfnc (&digcmp(dig_ofs),10);
			if ((dig_ofs += 10) > 110)
				dig_ofs = 0;
			break;

		default:
			break;
	}
}
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	loc_lf ()                                                    */
/*                                                                           */
/* purpose:	locate the next line feed in the input buffer.               */
/*                                                                           */
/* inputs:      none							     */
/*                                                                           */
/* outputs:	number bytes up to and including next line feed.             */
/*                                                                           */
/*****************************************************************************/
static 	loc_lf ()
{
int i,j;

	for (i = 1, j = head; j != tail; i++, j++, j %= BUFSIZ)
		if (inp[j] == LF)
	return (encoded ? i + 1 : i);

	return (0);
}
/**/
/*****************************************************************************/
/*                                                                           */
/* function:	move_inp (n)                                                 */
/*                                                                           */
/* purpose:	copy an input record to the user data area                   */
/*                                                                           */
/* inputs:      number of bytes to copy					     */
/*                                                                           */
/* outputs:	index to new head byte			                     */
/*                                                                           */
/*****************************************************************************/
static 	move_inp (n)
int 	n;
{
int 	i,j;

	if (n)
	{
		for (i = 0, j = head; i < n; i++, j++, j %= BUFSIZ)
			image(i) = inp [j];

		image(i) = NULL;
		return (j);
	}
	return (head);
}
/**/
/*****************************************************************************/
/*									     */
/* function:	ascfnc (_vector, n)					     */
/*									     */
/* purpose:	Decode a character string into a vector.                     */
/*									     */
/* inputs:	_vector pointer to vector to convert.			     */
/*		n	number of elements to decode.			     */
/*									     */
/* outputs:	The output values stored at _vector.			     */
/*									     */
/*****************************************************************************/
static	 ascfnc (_vector, n)

int	n;
float	*_vector;
{
int	i;

	for (i = 0; i < n; i++, index += 7)
		*vector(i) = matof (&image(index), 7);
}
/**/
/*****************************************************************************/
/*									     */
/* function:	binfnc (_vector, n, scale)				     */
/*									     */
/* purpose:	Decode a character string into a vector.                     */
/*									     */
/* inputs:	_vector pointer to vector to convert.			     */
/*		n	number of elements to decode.			     */
/*		scale   conversion scale factor.			     */
/*									     */
/* outputs:	The output values stored at _vector.			     */
/*									     */
/*****************************************************************************/
static 	binfnc (_vector, n, scale)

int	n;
float	*_vector, scale;
{
int	i;

	for (i = 0; i < n; i++, index += 2)
	{
		bdata._chr[0] = image (index);
		bdata._chr[1] = image (index + 1);
		*vector(i) = scale * (float) bdata._int;
	}
}
/**/
/*****************************************************************************/
/*									     */
/* function:	snd_stg (string)					     */
/*									     */
/* purpose:	Send a command string to the TLC.			     */
/*									     */
/* inputs:	string	pointer to character string to send.		     */
/*									     */
/* outputs:	string is output to TLC					     */
/*		returns 0 if no CR was sent, otherwise returns 1.	     */
/*									     */
/*****************************************************************************/
static snd_stg (string)
char	*string;
{
char	c;

	while ((c = *string++) != NULL)
	{
		if ((c == '\021') && (xoff_flg == 1))
			continue;
		com_put (port,c);
		if (c == CR) return (1);
	}
	return (0);
}
/**/
/*****************************************************************************/
/*									     */
/* function:	char data_rec() 					     */
/*									     */
/* purpose:	Determine the type of data record.			     */
/*									     */
/* inputs:	none.							     */
/*									     */
/* output:	Type of record present in image.			     */
/*									     */
/*****************************************************************************/
static 	char 	data_rec()
{
	switch (image(0))
	{
		case '1':
		case '2':
			return (image(2));

		default:
			return ('0');
	}
}
/**/
/*****************************************************************************/
/*									     */
/* function:	matoi ( string, length)					     */
/*									     */
/* purpose:	Convert a 'string' to integer.				     */
/*									     */
/* inputs:	string		pointer to string to convert.		     */
/*		length		number of bytes to convert.		     */
/*									     */
/* output:	returns the converted string.				     */
/*									     */
/*****************************************************************************/
static 	matoi (string, length)
int	length;
char	*string;
{
int	i;
char	temp[8];

	for (i = 0; i < length; i++)
		temp[i] = *string++;
	temp[i] = NULL;
	
	return (atoi(temp));
}
/**/
/*****************************************************************************/
/*									     */
/* function:	float matof ( string, length)				     */
/*									     */
/* purpose:	Convert a 'string' to floating point.			     */
/*									     */
/* inputs:	string		pointer to string to convert.		     */
/*		length		number of bytes to convert.		     */
/*									     */
/* output:	returns the converted string.				     */
/*									     */
/*****************************************************************************/
static	 float 	matof (string, length)
int	length;
char	*string;
{
int	i;
char	temp[8];

	for (i = 0; i < length; i++)
		temp[i] = *string++;
	temp[i] = NULL;

	return ((float)atof(temp));
}
/**/
/*****************************************************************************/
/*									     */
/* function:	wait (n, m) 						     */
/*									     */
/* purpose:	Provide a wait state for data arrival.			     */
/*									     */
/* inputs:	n	primary loop control variable.			     */
/*		m	secondary loop control variable.		     */
/*									     */
/* output:	none.							     */
/*									     */
/*****************************************************************************/
static 	wait (n, m)
int 	n,m;
{
int i, j, k;

	k = 1;
	for (i = 0; i < n; i++)
		for (j = 0; j < m; j++)
			k *= 1;
}