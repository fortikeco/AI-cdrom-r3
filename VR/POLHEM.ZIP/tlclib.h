/******************************************************************************





	                   Polhemus Inc.
		    A Kaiser Aerospace and Electronics Company
                                P.O. Box 560
                          Colchester, Vermont 05446
                               (802) 655-3159






                                3 S P A C E

                  F U N C T I O N A L   I N T E R F A C E

                       L I B R A R Y   P A C K A G E




                                Version 1.0
                             Copyright (c) 1986
	This program may not be reproduced in whole or in part without
	 the inclusion of this copyright notice.







      The  purpose  of  this program is to provide an interface to the
	3SPACE  family  of products which can be used in any of the user
	or in-house applications packages.
******************************************************************************/

/******************************************************************************
                        General 3SPACE System Data
******************************************************************************/

/*  Structure '_tlcdata' contains those data elements which are not specific 
    to either the source or sensor number. 				     */

struct	_tlcdata
{
	char  _type;				/* record type */
	char  _station;				/* station number */
	char  _comkey;				/* command response letter */
	int   _format;				/* ascii/binary input data */
	int   _metflg;				/* english/metric input data */
	int   _comflg;				/* compensation ON/OFF */
	int   _pcmode;				/* continuous print ON/OFF */
	int   _trkenb;				/* tracker enabled */
	int   _extenb;				/* extended tracker enabled */
	int   _digmod;				/* point/run/track mode flag */ 
	int   _biterr;				/* byte error flag */
	int   _biterw;				/* word error flag */
	float _sofrev;				/* software revision number */
	char  _condat[33];			/* configuration control data */
	char  _errcod;				/* command error code */
	int   _tblcnt;				/* number of output items */
	int   _tblout[32];			/* table of output items */
	int	_dat_siz;				/* bytes in data record */
	int	_count;				/* bytes in current record */
	float _diginc;				/* output increment values */
	int   _sspair[8];				/* active station flags */
	char	_padbuf[33];			/* keypad message record */
	int   _endflg;				/* <ctrl Z> keypad flag */
	float _delpos[3];				/* stylus tip offsets */
	float _digcmp[120];			/* digitizer compensation data */
	float _selfcal[7];			/* system self_calibration data */
	float _tstout[19];			/* SHMS4 test data values */
	char  _image[128];			/* input record image */
};

/******************************************************************************
                     Source/Station Dependent Structures
******************************************************************************/

/* Structure 'radiator' contains those elements specific to the source index */

struct radiator
{
	float _algcrd[9];				/* alignment coordinates */
	float _moucor[3];				/* radiator mount coordinates */
	float _isoprm[9];				/* isotrak source/sensor proms */
	float _chrdat[9];				/* all other source proms */
};

/* Structure 'sensor' contains those elements specific to the sensor index   */

struct sensor
{
	float	_position[3];			/* cartesian coordinates */
	float	_attitude[3];			/* euler angles */
	float _x_dircos[3];			/* line_of_sight */
	float _y_dircos[3];			/* line_of_hearing */
	float _z_dircos[3];			/* line_of_plumb */
	float _x_rawsen[3];			/* x_sensor A/D data */
	float _y_rawsen[3];			/* y_sensor A/D data */
	float _z_rawsen[3];			/* z_sensor A/D data */
	float _q[4];				/* quaternion */
	float _hemcrd[3];				/* hemisphere vector */
	float _envtab[6];				/* operational envelope limits */
	float _anglim[6];				/* angular operational envelope */
	float _borlim[6];				/* boresight operational envelope */
	float _chrdat[9];				/* all other sensor proms */
};

/* Structure '_sptrs' contains pointers to each of the previous structures   */

struct _sptrs
{
	struct _tlcdata *pdata;
	struct radiator *psource;
	struct sensor   *psensor;
};

/******************************************************************************
                             Macro Definitions
******************************************************************************/

/*   In the following group of macros 'i' is an index to an array element    */

#define  	type			(psptrs->pdata->_type)
#define	station		(psptrs->pdata->_station)
#define  	comkey		(psptrs->pdata->_comkey)
#define  	format		(psptrs->pdata->_format)
#define  	metflg		(psptrs->pdata->_metflg)
#define  	comflg		(psptrs->pdata->_comflg)
#define  	pcmode		(psptrs->pdata->_pcmode)
#define  	trkenb		(psptrs->pdata->_trkenb)
#define  	extenb		(psptrs->pdata->_extenb)
#define  	digmod		(psptrs->pdata->_digmod)
#define  	biterr		(psptrs->pdata->_biterr)
#define  	biterw		(psptrs->pdata->_biterw)
#define  	sofrev		(psptrs->pdata->_sofrev)
#define  	condat(i)		(psptrs->pdata->_condat[i])
#define  	errcod		(psptrs->pdata->_errcod)
#define  	tblcnt		(psptrs->pdata->_tblcnt)
#define  	tblout(i)		(psptrs->pdata->_tblout[i])
#define  	dat_siz		(psptrs->pdata->_dat_siz)
#define	count			(psptrs->pdata->_count)
#define  	diginc		(psptrs->pdata->_diginc)
#define  	sspair(i)		(psptrs->pdata->_sspair[i])
#define  	padbuf(i)		(psptrs->pdata->_padbuf[i])
#define  	endflg		(psptrs->pdata->_endflg)
#define  	delpos(i)		(psptrs->pdata->_delpos[i])
#define  	digcmp(i)		(psptrs->pdata->_digcmp[i])
#define  	selfcal(i)		(psptrs->pdata->_selfcal[i])
#define	tstout(i)		(psptrs->pdata->_tstout[i])
#define  	image(i)		(psptrs->pdata->_image[i])

/* In the next group of macros 'i' is a station index and 'j an array index  */

#define  	algcrd(i,j)		((psptrs->psource+i)->_algcrd[j])
#define  	moucor(i,j)		((psptrs->psource+i)->_moucor[j])
#define  	isoprm(i,j)		((psptrs->psource+i)->_isoprm[j])
#define	radchr(i,j)		((psptrs->psource+i)->_chrdat[j])

#define  	position(i,j)	((psptrs->psensor+i)->_position[j])
#define  	attitude(i,j)	((psptrs->psensor+i)->_attitude[j])
#define  	x_dircos(i,j)	((psptrs->psensor+i)->_x_dircos[j])
#define  	y_dircos(i,j)	((psptrs->psensor+i)->_y_dircos[j])
#define  	z_dircos(i,j)	((psptrs->psensor+i)->_z_dircos[j])
#define  	x_rawsen(i,j)	((psptrs->psensor+i)->_x_rawsen[j])
#define  	y_rawsen(i,j)	((psptrs->psensor+i)->_y_rawsen[j])
#define  	z_rawsen(i,j)	((psptrs->psensor+i)->_z_rawsen[j])
#define  	q(i,j)		((psptrs->psensor+i)->_q[j])
#define  	hemcrd(i,j)		((psptrs->psensor+i)->_hemcrd[j])
#define  	envtab(i,j)		((psptrs->psensor+i)->_envtab[j])
#define	anglim(i,j)		((psptrs->psensor+i)->_anglim[j])	
#define	borlim(i,j)		((psptrs->psensor+i)->_borlim[j])
#define	senchr(i,j)		((psptrs->psensor+i)->_chrdat[j])
