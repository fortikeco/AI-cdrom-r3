/******************************************************************************




			        Polhemus Inc.
                    A Kaiser Aerospace and Electronics Company
                                P.O. Box 560
                          Colchester, Vermont 05446
                               (802) 655-3159



                      3 S P A C E   P R O D U C T   L I N E

                       T E R M I N A L   I N T E R F A C E



                                Version 1.0
                             Copyright (c) 1986, 1989.

	Software may not be copied in Whole or part without the inclusion
	of this software notice.


	The purpose of this program is to act as a terminal type interface
	to any of the Polhemus  3SPACE family members.



	Polhemus Inc. makes no warranty of any kind with regard to this
	material, including  but not limited to, the implied warranties
	of merchantability and fitness for a particular purpose.
	Polhemus Inc. assumes no responsibility for any errors that may
	appear in this document or associated software. Polhemus Inc.
	makes no committment to update nor to keep current the
	information contained in this document or related support
	software.

******************************************************************************/
/*	Errors that may be reduced or eliminated:			    */
/*	get_string uses a delimiter as parameter 3 that is insensitive to   */
/*	the extended character set(function keys, and numeric keypad).	    */
/*	Resolution is to change the definition of this item to a short int  */
/*	then in get_key(int *scancode), use scan code only as an extended   */
/*	characterset flag, then use a redefined(or not necessarily so)	    */
/*	return value of get_key(source file KEYS.C) to match without use of */
/*	the secondary value in scancode. Suggest:			    */
/*	union	Console_key_def	{					    */
/*		int	return_value;					    */
/*		struct	{						    */
/*			char	char-part,				    */
/*				ext_flag_part;	value 0 -> normal character */
/*	get_key() is found in KEYS.c

#include	"dos.h"
#include	"stdio.h"
#include	"tlclib.h"
/******************************************************************************
                         System Macro Definitions
******************************************************************************/

#define		LF			10
#define		CR			13
#define		BS			8
#define		ESC			27
#define		END			79
#define		SPACE			32
#define		Length		80
#define		MAXBIT		43
#define		ControlY		25
#define		Center(x)		(short)((Length - strlen(x))/2), x
#define		INPUT(x)		get_line(string); screen.x=atoi(string)
#define		BERROR		berrors[biterr < MAXBIT ? biterr : MAXBIT]
#define		INDEX			screen.index

#define		SROWS			screen.srows
#define		SCOLS			screen.scols
#define		WROWS			screen.wrows
#define		WCOLS			screen.wcols
#define		WROW			screen.wrow
#define		WCOL			screen.wcol
#define		WINCOL		screen.winatr
#define		BOXTYP		screen.boxtyp
#define		BOXCOL		screen.boxatr

#define		WZERO			ids[0]
#define		WONE			ids[1]
#define		WTWO			ids[2]
#define		WTHREE		ids[3]
#define		WFOUR			ids[4]
#define		WFIVE			ids[5]
#define		WSIX			ids[6]
#define		WSEVEN		ids[7]
#define		WEIGHT		ids[8]

#define		F1			59
#define		F2			60
#define		F3			61
#define		F4			62
#define		F5			63
#define		F6			64
#define		F7			65
#define		F8			66
#define		F9			67
#define		F10			68

/******************************************************************************
                         System Macro Definitions
******************************************************************************/

#define	POSITION(x)		position(x,0),position(x,1),position(x,2)
#define	ATTITUDE(x)		attitude(x,0),attitude(x,1),attitude(x,2)
#define	X_DIRCOS(x)		x_dircos(x,0),x_dircos(x,1),x_dircos(x,2)
#define	Y_DIRCOS(x)		y_dircos(x,0),y_dircos(x,1),y_dircos(x,2)
#define	Z_DIRCOS(x)		z_dircos(x,0),z_dircos(x,1),z_dircos(x,2)
#define	X_RAWSEN(x)		x_rawsen(x,0),x_rawsen(x,1),x_rawsen(x,2)
#define	Y_RAWSEN(x)		y_rawsen(x,0),y_rawsen(x,1),y_rawsen(x,2)
#define	Z_RAWSEN(x)		z_rawsen(x,0),z_rawsen(x,1),z_rawsen(x,2)
#define	Q(x)			q(x,0),q(x,1),q(x,2),q(x,3)
#define	SELFCAL1		selfcal(0)
#define	SELFCAL2		selfcal(1),selfcal(2),selfcal(3)
#define	SELFCAL3		selfcal(4),selfcal(5),selfcal(6)
#define	ALGCRD1(x)		algcrd(x,0),algcrd(x,1),algcrd(x,2)
#define	ALGCRD2(x)		algcrd(x,3),algcrd(x,4),algcrd(x,5)
#define	ALGCRD3(x)		algcrd(x,6),algcrd(x,7),algcrd(x,8)
#define	HEMCRD(x)		hemcrd(x,0),hemcrd(x,1),hemcrd(x,2)
#define	ISOPRM1(x)		isoprm(x,0),isoprm(x,3),isoprm(x,6)
#define	ISOPRM2(x)		isoprm(x,1),isoprm(x,4),isoprm(x,7)
#define	ISOPRM3(x)		isoprm(x,2),isoprm(x,5),isoprm(x,8)
#define	DELPOS		delpos(0),delpos(1),delpos(2)
#define	ENVTAB1(x)		envtab(x,0),envtab(x,1),envtab(x,2)
#define	ENVTAB2(x)		envtab(x,3),envtab(x,4),envtab(x,5)
#define	MOUCOR(x)		moucor(x,0),moucor(x,1),moucor(x,2)
#define	ANGLIM1(x)		anglim(x,0),anglim(x,1),anglim(x,2)
#define	ANGLIM2(x)		anglim(x,3),anglim(x,4),anglim(x,5)
#define	BORLIM1(x)		borlim(x,0),borlim(x,1),borlim(x,2)
#define	BORLIM2(x)		borlim(x,3),borlim(x,4),borlim(x,5)
#define	TSTPOS		tstout(0),tstout(1),tstout(2)
#define	TSTATT		tstout(3),tstout(4),tstout(5)
#define	TSTXDC		tstout(6),tstout(7),tstout(8)
#define	TSTYDC		tstout(9),tstout(10),tstout(11)
#define	TSTZDC		tstout(12),tstout(13),tstout(14)
#define	TSTQUT		tstout(15),tstout(16),tstout(17),tstout(18)
#define	RADCHR1(x)		radchr(x,0),radchr(x,1),radchr(x,2)
#define	RADCHR2(x)		radchr(x,3),radchr(x,4),radchr(x,5)
#define	RADCHR3(x)		radchr(x,6),radchr(x,7),radchr(x,8)
#define	SENCHR1(x)		senchr(x,0),senchr(x,1),senchr(x,2)
#define	SENCHR2(x)		senchr(x,3),senchr(x,4),senchr(x,5)
#define	SENCHR3(x)		senchr(x,6),senchr(x,7),senchr(x,8)

/******************************************************************************
				   System Function Definitions
******************************************************************************/

void	show_0();		/* input data record */
void	show_S();		/* status record */
void	show_LL();		/* keypad message record */
void	show_Z();		/* ControlZ message from keypad */
void	show_A();		/* system alignment record */
void	show_H();		/* hemisphere definition record */
void	show_I();		/* position increment record */
void	show_M();		/* source/sensor EEPROM definition record */
void	show_N();		/* stylus tip offset definition record */
void	show_V();		/* motion box limits record */
void	show_R();		/* mounting frame coordinates record */
void	show_l();		/* active/inactive stations record */
void	show_O();		/* data output stream definition record */
void	show_E();		/* system ERROR record */
void	show_C();		/* EEPROM compensation definition record */
void	show_QQ();		/* angular limits definition record */
void	show_q();		/* boresight limits definition record */
void	show_j();		/* test data output definition record */
void	show_nn();		/* source/sensor characterization data */

struct _record
{
	char 	class;
	short	pause;
	void 	(*function)();
}	record[] = {
				'0', 0, show_0,
				'S', 1, show_S,
				'L', 1, show_LL,
				'Z', 1, show_Z,
				'A', 1, show_A,
				'H', 1, show_H,
				'I', 1, show_I,
				'M', 1, show_M,
				'N', 1, show_N,
				'V', 1, show_V,
				'R', 1, show_R,
				'l', 1, show_l,
				'O', 1, show_O,
				'*', 1, show_E,
				'C', 1, show_C,
				'Q', 1, show_QQ,
				'q', 1, show_q,
				'j', 1, show_j,
				'n', 1, show_nn,
			};

/******************************************************************************
				    System Data Definitions
******************************************************************************/

struct _screen
{
	short	index;				/* index to screen number */
	short	srows;				/* rows in screen */
	short	scols;				/* columns in screen */
	short	wrows;				/* rows in window */
	short	wcols;				/* columns in window */
	short	wrow;					/* top row of window */
	short	wcol;					/* top left column of window */
	short	winatr;				/* attribute of window */
	short	boxtyp;				/* box type */
	short	boxatr;				/* attribute of box */
} screen;

extern struct _sptrs *tlc_open(), *psptrs;
extern char tlc_get();

FILE	*in, *out;
short	ids[99],
	rate = 9600,
	current_window,
	digoff,
	datcol,
	omode,
	prone,
	C_flag = 1,
	_fmode;
char	string[81],
	command[] = {NULL, NULL};

/******************************************************************************
				    System Data Definitions
******************************************************************************/

char	*system_message[] =
{
	"Unable to open 3SPACE!",
	"Type <ESC> to exit, any other key to retry!",
	"Strike any key to continue!",
	"System Ready",
	"Open in progress. Please wait!",
	"***** Binary Format Enabled *****",
	"Unable to open output file! Strike any key to continue!",
	"Adjust baud rate switches. Strike any key to continue!",
	"Invalid entry. Strike any key to continue!",
	"********** Message from Keypad User **********",
	"********** <ctrl_Z> Received from Keypad **********",
	"********** Command Interpreter Input Error **********",
	"***** Invalid Command *****",
	"***** Alignment Plane Definition *****",
	"x_coordinate     y_coordinate     z_coordinate",
	"**** Hemisphere Vector Definition ****",
	"***** System Increment Value *****",
	"***** Source/Sensor EEPROM Definition *****",
	"Column 1         Column 2         Column 3",
	"****** Stylus Tip Offset Values ******",
	"    x_offset         y_offset         z_offset",
	"********** Motion Box Limits **********",
	"***** Mounting Frame Coordinates *****",
	"   azimuth        elevation             roll",
	"***** Source/Sensor Pair Status *****",
	"1     2     3     4     5     6     7     8",
	"********** System Data Record Variables **********",
	"     t0     t1     t2     t3     t4     t5     t6     t7     t8     t9",
	" ********** System Data Input Values **********",
	"...(a)...   ...(b)...   ...(c)...   ...(d)... ",
	"********** Boresight Limits **********",
	"***** Source Characterization Data *****",
	"***** Sensor Characterization Data *****",
	"...(a)...        ...(b)...        ...(c)...",
};

/******************************************************************************
				    System Data Definitions
******************************************************************************/

char	*mask[] =
{
	 " Position ..........%12.4f%12.4f%12.4f\0",
	 " Attitude ..........%12.4f%12.4f%12.4f\0",
	 " X_direction Cosine %12.4f%12.4f%12.4f\0",
	 " Y_direction Cosine %12.4f%12.4f%12.4f\0",
	 " Z_direction Cosine %12.4f%12.4f%12.4f\0",
	 " X_Sensor ..........%12.4f%12.4f%12.4f\0",
	 " Y_Sensor ..........%12.4f%12.4f%12.4f\0",
	 " Z_Sensor ..........%12.4f%12.4f%12.4f\0",
	 " Q .................%12.4f%12.4f%12.4f%12.4f\0",
	 " Offset ............%12.4f\0",
	 " Source 0 ..........%12.4f%12.4f%12.4f\0",
	 " Source 1 ..........%12.4f%12.4f%12.4f\0",
	 " Origin ...........%17.4f%17.4f%17.4f\0",
	 " Positive x .......%17.4f%17.4f%17.4f\0",
	 " Positive y .......%17.4f%17.4f%17.4f\0",
	 " LOS vector .......%17.4f%17.4f%17.4f\0",
	 " Increment ...........%20.4f %-s\0",
	 " Value ............%17.4f%17.4f%17.4f\0",
	 " Maximum ...........%17.4f%17.4f%17.4f\0",
	 " Minimum ...........%17.4f%17.4f%17.4f\0",
	 " Value ............%17.4f%17.4f%17.4f\0",
	 " Row 1 ............%17.f%17.f%17.f\0",
	 " Row 2 ............%17.f%17.f%17.f\0",
	 " Row 3 ............%17.f%17.f%17.f\0",
	 "         %10d .......... %-s\0",
	 "         %10d .......... data record size\0",
	 " Row 1 ............%17.4f%17.4f%17.4f\0",
	 " Row 2 ............%17.4f%17.4f%17.4f\0",
	 " Row 3 ............%17.4f%17.4f%17.4f\0",
};

/******************************************************************************
				    System Data Definitions
******************************************************************************/

char	*berrors[] =
{
	"Null Message 00",
	"CRITICAL ERROR 01: EPROM checksum failure",
	"CRITICAL ERROR 02: EEPROM checksum failure",
	"CRITICAL ERROR 03: RAM test failure",
	"CRITICAL ERROR 04: Sample calculation failure",
	"CRITICAL ERROR 05: Timer 0 failure",
	"CRITICAL ERROR 06: Timer 1 failure",
	"CRITICAL ERROR 07: Timer 2 failure",
	"CRITICAL ERROR 08: Analog power supply failure",
	"CRITICAL ERROR 09: LP filter failure",
	"CRITICAL ERROR 10: Demodulation failure",
	"CRITICAL ERROR 11: Driver reference failure",
	"CRITICAL ERROR 12: Driver failure",
	"CRITICAL ERROR 13: B filter and AGC failure",
	"CRITICAL ERROR 14: Preamp and MUX failure",
	"CRITICAL ERROR 15: Sine-cosine chip failure",
	"CRITICAL ERROR 16: System linearity failure",
	"CRITICAL ERROR 17: Preamp noise failure",
	"CRITICAL ERROR 18: On-going RAM test failure",
	"CRITICAL ERROR 19: Self-calibration test failure",
	"CRITICAL ERROR 20: Self-test, 1553 interface failure",
	"CRITICAL ERROR 21: Source/sensor ID PROM failure",
	"CRITICAL ERROR 22: Invalid switch setting for stations",
	"CRITICAL ERROR 23: Discrete/reticle driver test failure",
	"CRITICAL ERROR 24: Failure in ongoing self-test",
	"Null Message 25",
	"Null Message 26",
	"WARNING 27: Trace calculation for S4TS4",
	"WARNING 28: Self-calibration divide error",
	"WARNING 29: Self-calibration A/D input error",
	"WARNING 30: Sensor A/D input error",
	"WARNING 31: Sensor out-of-motion envelope",
	"WARNING 32: Self-calibration offset overflow",
	"WARNING 33: Error in calculation of TRMOI",
	"WARNING 34: Path 1 error",
	"WARNING 35: Path 2 error",
	"WARNING 36: Path 3 error",
	"WARNING 37: Path 4 error",
	"WARNING 38: System running too slow",
	"WARNING 39: Error in fixed metal compensation",
	"WARNING 40: Attitude matrix calculation error",
	"WARNING 41: Error in processing DAC value",
	"WARNING 42: Norm of XORVEC too low",
	"Null Message 43",
	"Null Message 44",
	"Null Message 45",
	"Null Message 46",
	"Null Message 47",
	"Null Message 48",
	"Null Message 49",
	"WARNING 50: Clinometer A/D saturation error",
	"WARNING 51: Outside boresight coverage limits",
	"WARNING 52: Outside system angular coverage limits",
};

/******************************************************************************
				    System Data Definitions
******************************************************************************/

char	*t0_[] = {"ASCII   ", "BINARY  "};
char	*t1_[] = {"ENGLISH ", "METRIC  "};
char	*t2_[] = {"OFF     ", "ON      "};
char	*t3_[] = {"POINT   ", "RUN     ", "TRACK   ", "OFF     "};
char	*t4_[] = {"inches", "centimeters"};
char	*t5_[] = {"X...(c)  "," ...(p)  ",
                  "Y...(c)  "," ...(p)  ",
                  "Z...(c)  "," ...(p)  ",
                  "A...(c)  "," ...(p)  ",
                  "E...(c)  "," ...(p)  ",
                  "R...(c)  "," ...(p)  "};
char	*t6_[] = {"OFF"," ON"};

char	*recopt[] = {  "space",
                     "CR, LF",
                     "x,y,z - position",
                     " ",
                     "euler angles (azimuth primary)",
                     "x_direction cosine",
                     "y_direction cosine",
                     "z_direction cosine",
                     "x_sensor data",
                     "y_sensor data",
                     "z_sensor data",
                     "orientation quaternion",
                     "offsets, self-calibration"};

/******************************************************************************
                            System Main Line
******************************************************************************/
main(argc, argv)
int	argc;
char	*argv[];
{
short	scancode;

	Vinit();
	linit();
	printf (" loading screens - please wait");
	load_screens("screens.asc", ids);
	Vwindopn(WZERO);

	do
	{
		Vpos(WZERO, 5, 0);
		Vclearl(WZERO);
		Vwriteat(WZERO, 5, Center(system_message[4]));
		if (tlc_open() == 0)
		{
			Vclearl(WZERO);
			Vwriteat(WZERO, 5, Center(system_message[0]));
			delay(3000);
			Vclearl(WZERO);
			Vwriteat(WZERO, 5, Center(system_message[1]));
		}
		else goto OK;
	}
	while (get_key(&scancode) != ESC);
	Vwindclo(WZERO);
	Vbyebye();
	exit();

OK:	if (biterr)
	{
		Vclearl(WZERO);
		Vwriteat(WZERO, 5, Center(BERROR));
		Vwarning(WONE, system_message[2]);
	}
	else
	{
		Vclearl(WZERO);
		Vwriteat(WZERO, 5, Center(system_message[3]));
		delay(3000);
	}
	Vwindclo(WZERO);
	show_S();
	if (pcmode)
		Vwarning(WONE, system_message[2]);
	Vwindopn(WTHREE);
	KBIO_install();	
	cycle();
}

/******************************************************************************

function:	cycle()

purpose:	Cycle the system until user exits.

returns:	Nothing

******************************************************************************/
cycle()
{
short	c, scancode;

	for(;;)
		if (kbhit())
			if((c = get_key(&scancode)) == 0)
				switch(scancode)
				{
					case F1:
						process_function_key01();
						break;

					case F2:
						process_function_key02();
						break;

					case F3:
						process_function_key03();
						break;

					case F4:
						process_function_key04();
						break;

					case F5:
						process_function_key05();
						break;

					case F6:
						process_function_key06();
						break;

					case F9:
						process_function_key09();
						break;

					case F10:
						process_function_key10();
						break;

					default:
						break;
				}
			else	process_command(c);
		else	read_system();
}

/******************************************************************************

function:	process_command(c)
		short	c;

purpose:	Process console commands to the 3SPACE.

returns:	Nothing

******************************************************************************/
process_command(c)
short	c;
{
	command[0] = (char)c;

	if (c == ControlY)
	{
		Vwindopn(WZERO);
		Vpos(WZERO, 5, 0);
		Vclearl(WZERO);
		Vwriteat(WZERO, 5, Center(system_message[4]));
		tlc_put(command);
		if (biterr)
		{
			Vclearl(WZERO);
			Vwriteat(WZERO, 5, Center(BERROR));
			Vwarning(WONE, system_message[2]);
		}
		else
		{
			Vclearl(WZERO);
			Vwriteat(WZERO, 5, Center(system_message[3]));
			delay(3000);
		}
		Vwindclo(WZERO);
		show_S();
		Vwindopn(WTHREE);
	}
	else	tlc_put(command);
}

/******************************************************************************

function:	read_system()

purpose:	Process input records from the 3SPACE.

returns:	Nothing

******************************************************************************/
read_system()
{
short	i;
char	c;

	if (c = tlc_get(NULL))
	{
		if (datcol)
			fwrite(&image(0), count, 1, out);

		if (omode)
			if (format)
				Vwrite(WFIVE, system_message[5]);
			else
				Vwrite(WFIVE, &image(0));
		else
			for (i = 0; i < sizeof(record)/sizeof(struct _record); i++)
				if (c == record[i].class)
				{	(*record[i].function)();
					if (record[i].pause && pcmode && C_flag)
						Vwarning(WONE, system_message[2]);	}
	}
}

/******************************************************************************

function:	show_(window)
		short	window;

purpose:	Display the system header record on the user console.

returns:	Nothing

******************************************************************************/
show_(window)
short	window;
{
short	 i;
static short not_open = 1;

	tlc_cnv();

	if (not_open)
	{
		not_open--;
		Vwindopn(WTWO);
	}

	Vpos(WTWO, 3, 0);
	if (format)
	{
		Vclearl(WTWO);
		Vwriteat(WTWO, 3, Center(system_message[5]));
	}
	else
	{
		Vclearl(WTWO);
		image(Length-2) = NULL;
		for (i = 0; i < strlen(&image(0)); i++)
			if (image(i) == CR || image(i) == LF) image(i) = SPACE;
		Vwriteat(WTWO, 3, Center(&image(0)));
	}
	Vconvert(WTWO, 5, 18, "%c", type);
	Vconvert(WTWO, 5, 45, "%c", station);
	Vconvert(WTWO, 5, 74, "%c", comkey);

	if (current_window != window)
	{
		Vwindclo (ids[current_window]);
		current_window = window;
		Vwindopn(ids[window]);
	}
}

/******************************************************************************

function:	show_0()

purpose:	Process type '0' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_0()
{
short	i, row, s;

	row = 6;
	Vdispoff();
	show_(7);
	Vpos(WSEVEN, row, 0);
	Vcleares(WSEVEN);
	s = station - '1';

	for (i = 0; i < tblcnt; i++)
		switch (tblout(i))
		{	
			case 2:
				sprintf (string, mask[0], POSITION(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 4:
				sprintf (string, mask[1], ATTITUDE(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 5:
				sprintf (string, mask[2], X_DIRCOS(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 6:
				sprintf (string, mask[3], Y_DIRCOS(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 7:
				sprintf (string, mask[4], Z_DIRCOS(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 8:
				sprintf (string, mask[5], X_RAWSEN(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 9:
				sprintf (string, mask[6], Y_RAWSEN(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 10:
				sprintf (string, mask[7], Z_RAWSEN(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 11:
				sprintf (string, mask[8], Q(s));
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			case 12:
				sprintf (string, mask[9],  SELFCAL1);
				Vwriteat(WSEVEN, row++, 0, string);
				sprintf (string, mask[10], SELFCAL2);
				Vwriteat(WSEVEN, row++, 0, string);
				sprintf (string, mask[11], SELFCAL3);
				Vwriteat(WSEVEN, row++, 0, string);
				break;

			default:
				break;
		}
	Vdispon();
}

/******************************************************************************

function:	show_A()

purpose:	Process type 'A' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_A()
{
short	row, s;

	row = 6;

	Vdispoff();
	show_(8);
	s = station - '1';
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 2, 31, system_message[13]);
	Vwriteat(WEIGHT, 4, 26, system_message[14]);
	sprintf(string, mask[12], ALGCRD1(s));
	Vwriteat(WEIGHT, row++, 0, string);
	sprintf(string, mask[13], ALGCRD2(s));
	Vwriteat(WEIGHT, row++, 0, string);
	sprintf(string, mask[14], ALGCRD3(s));
	Vwriteat(WEIGHT, row++, 0, string);
	Vdispon();
}

/******************************************************************************

function:	show_C()

purpose:	Process type 'C' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_C()
{
static short row;

	if (digoff == 0)
	{
		row = 2;
		C_flag = 0;
		Vdispoff();
		show_(8);
		Vclear(WEIGHT);
		Vwriteat(WEIGHT, 0, 9, system_message[27]);
	}
	else
		tlc_cnv ();
		
	sprintf (string, "%-s\0", t5_[(int)(digoff/10)]);
	Vwriteat(WEIGHT, row, 1, string);
	
	sprintf (string,"%7.0f%7.0f%7.0f%7.0f%7.0f%7.0f%7.0f%7.0f%7.0f%7.0f\0",
								digcmp (digoff + 0),
								digcmp (digoff + 1),
								digcmp (digoff + 2),
								digcmp (digoff + 3),
								digcmp (digoff + 4),
								digcmp (digoff + 5),
								digcmp (digoff + 6),
								digcmp (digoff + 7),
								digcmp (digoff + 8),
								digcmp (digoff + 9));
	Vwriteat(WEIGHT, row++, 9, string);

	if ((digoff += 10) > 110)
	{
		digoff = 0;
		C_flag = 1;
		Vdispon();
	}
}

/******************************************************************************

function:	show_E()

purpose:	Process type '*' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_E()
{
	Vdispoff();
	show_(8);
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 5, Center(system_message[11]));
	if (errcod == 99)
		Vwriteat(WEIGHT, 8, Center(system_message[12]));
	Vdispon();
}

/******************************************************************************

function:	show_H()

purpose:	Process type 'H' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_H()
{
short	 s;

	Vdispoff();
	show_(8);
	s = station - '1';
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 2, 31, system_message[15]);
	Vwriteat(WEIGHT, 4, 26, system_message[14]);
	sprintf(string, mask[15], HEMCRD(s));
	Vwriteat(WEIGHT, 6, 0, string);
	Vdispon();
}

/******************************************************************************

function:	show_I()

purpose:	Process type 'I' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_I()
{
	Vdispoff();
	show_(8);
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, Center(system_message[16]));
	sprintf(string, mask[16], diginc, t4_[metflg]);
	Vwriteat(WEIGHT, 6, Center(string));
	Vdispon();
}

/******************************************************************************

function:	show_M()

purpose:	Process type 'M' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_M()
{
short	s;

	Vdispoff();
	show_(8);
	s = station - '1';
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, 27, system_message[17]);
	Vwriteat(WEIGHT, 5, 28, system_message[18]);
	sprintf(string, mask[21], ISOPRM1(s));
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[22], ISOPRM2(s));
	Vwriteat(WEIGHT, 8, 0, string);
	sprintf(string, mask[23], ISOPRM3(s));
	Vwriteat(WEIGHT, 9, 0, string);
	Vdispon();
}

/******************************************************************************

function:	show_N()

purpose:	Process type 'N' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_N()
{
	Vdispoff();
	show_(8);
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, 31, system_message[19]);
	Vwriteat(WEIGHT, 5, 25, system_message[20]);
	sprintf(string, mask[17], DELPOS);
	Vwriteat(WEIGHT, 7, 0, string);
	Vdispon();
}

/******************************************************************************

function:	show_O()

purpose:	Process type 'O' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_O()
{
short	i,
	row;

	Vdispoff();

	show_(8);
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 0, Center(system_message[26]));

	row = 2;
	for (i = 0; i < (tblcnt > 10 ? 10: tblcnt); i++)
	{
		sprintf(string, mask[24], tblout(i), recopt[tblout(i)]); 
		Vwriteat(WEIGHT, row++, 5, string);
	}
	sprintf(string, mask[25], dat_siz);
	Vwriteat(WEIGHT, ++row, 5, string);

	Vdispon();
}

/******************************************************************************

function:	show_R()

purpose:	Process type 'R' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_R()
{
short	s;

	Vdispoff();
	show_(8);
	s = station - '1';
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, 31, system_message[22]);
	Vwriteat(WEIGHT, 5, 26, system_message[23]);
	sprintf(string, mask[20], MOUCOR(s));
	Vwriteat(WEIGHT, 7, 0, string);
	Vdispon();
}

/******************************************************************************

function:	show_S()

purpose:	Process type 'S' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_S()
{
	Vdispoff();
	show_(4);
	Vwriteat(WFOUR, 1, 35, t0_[format]);
	Vwriteat(WFOUR, 1, 70, t1_[metflg]);
	Vwriteat(WFOUR, 2, 35, t2_[comflg]);
	Vwriteat(WFOUR, 2, 70, t2_[pcmode]);
	Vwriteat(WFOUR, 3, 35, t2_[trkenb]);
	Vwriteat(WFOUR, 3, 70, t2_[extenb]);
	Vwriteat(WFOUR, 4, 35, t3_[digmod]);
	Vconvert(WFOUR, 4, 70, "%-3d\0", biterr);
	Vconvert(WFOUR, 5, 35, "%-8d", biterw);
	Vfconvert(WFOUR, 5, 70, "%5.3f\0", sofrev);
	Vconvert(WFOUR, 6, 35, "%-4d\0", rate);
	Vwriteat(WFOUR, 8, 41, &condat(0));
	Vdispon();
}

/******************************************************************************

function:	show_V()

purpose:	Process type 'V' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_V()
{
short	s;

	Vdispoff();
	show_(8);
	s = station - '1';
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, 32, system_message[21]);
	Vwriteat(WEIGHT, 5, 27, system_message[14]);
	sprintf(string, mask[18], ENVTAB1(s));
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[19], ENVTAB2(s));
	Vwriteat(WEIGHT, 8, 0, string);
	Vdispon();
}

/******************************************************************************

function:	show_Z()

purpose:	Process type 'Z' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_Z()
{
	Vdispoff();
	show_(8);
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 6, Center(system_message[10]));
	Vdispon();
}

/******************************************************************************

function:	show_j()

purpose:	Process type 'j' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_j()
{
short	s;

	Vdispoff();
	show_(8);
	s = station - '1';
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, 23, system_message[28]);
	Vwriteat(WEIGHT, 5, 24, system_message[29]);
	sprintf(string, mask[0], TSTPOS);
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[1], TSTATT);
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[2], TSTXDC);
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[3], TSTYDC);
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[4], TSTZDC);
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[8], TSTQUT);
	Vwriteat(WEIGHT, 7, 0, string);
	Vdispon();
}

/******************************************************************************

function:	show_l()

purpose:	Process type 'l' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_l()
{
	Vdispoff();
	show_(8);
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, 31, system_message[24]);
	Vwriteat(WEIGHT, 5, 28, system_message[25]);
	Vwriteat(WEIGHT, 7, 0, " Station ..........");
	sprintf (string," %6s%6s%6s%6s%6s%6s%6s%6s\0",
									t6_[sspair(0)],
									t6_[sspair(1)],
									t6_[sspair(2)],
									t6_[sspair(3)],
									t6_[sspair(4)],
									t6_[sspair(5)],
									t6_[sspair(6)],
									t6_[sspair(7)]);
	Vwriteat(WEIGHT, 7, 22, string);
	Vdispon();
}

/******************************************************************************

function:	show_nn()

purpose:	Process type 'n' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_nn()
{
short	row, s;

	row = 6;

	Vdispoff();
	show_(8);
	Vclear(WEIGHT);
	s = station - '1';
	if (s > 3)
	{
		Vwriteat(WEIGHT, 2, 30, system_message[31]);
		Vwriteat(WEIGHT, 4, 28, system_message[33]);
		sprintf(string, mask[26], RADCHR1(s-4));
		Vwriteat(WEIGHT, row++, 0, string);
		sprintf(string, mask[27], RADCHR2(s-4));
		Vwriteat(WEIGHT, row++, 0, string);
		sprintf(string, mask[28], RADCHR3(s-4));
		Vwriteat(WEIGHT, row++, 0, string);
	}
	else
	{
		Vwriteat(WEIGHT, 2, 30, system_message[32]);
		Vwriteat(WEIGHT, 4, 28, system_message[33]);
		sprintf(string, mask[26], SENCHR1(s));
		Vwriteat(WEIGHT, row++, 0, string);
		sprintf(string, mask[27], SENCHR2(s));
		Vwriteat(WEIGHT, row++, 0, string);
		sprintf(string, mask[28], SENCHR3(s));
		Vwriteat(WEIGHT, row++, 0, string);
	}
	Vdispon();
}

/******************************************************************************

function:	show_q()

purpose:	Process type 'q' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_q()
{
short	s;

	Vdispoff();
	show_(8);
	s = station - '1';
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, 31, system_message[30]);
	Vwriteat(WEIGHT, 5, 25, system_message[23]);
	sprintf(string, mask[18], BORLIM1(s));
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[19], BORLIM2(s));
	Vwriteat(WEIGHT, 7, 0, string);
	Vdispon();
}

/******************************************************************************

function:	show_LL()

purpose:	Process type 'L' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_LL()
{
	Vdispoff();
	show_(8);
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, Center(system_message[9]));
	Vwriteat(WEIGHT, 6, Center(&padbuf(0)));
	Vdispon();
}

/******************************************************************************

function:	show_QQ()

purpose:	Process type 'Q' records from 3SPACE.

returns:	Nothing

******************************************************************************/
void show_QQ()
{
short	s;

	Vdispoff();
	show_(8);
	s = station - '1';
	Vclear(WEIGHT);
	Vwriteat(WEIGHT, 3, 32, system_message[21]);
	Vwriteat(WEIGHT, 5, 25, system_message[23]);
	sprintf(string, mask[18], ANGLIM1(s));
	Vwriteat(WEIGHT, 7, 0, string);
	sprintf(string, mask[19], ANGLIM2(s));
	Vwriteat(WEIGHT, 7, 0, string);
	Vdispon();
}

/******************************************************************************

function:	process_function_key01()

purpose:	Process console function key strike.

returns:	Nothing

******************************************************************************/
process_function_key01()
{
	omode = 0;
	Vwindclo(WFIVE);
}

/******************************************************************************

function:	process_function_key02()

purpose:	Process console function key strike.

returns:	Nothing

******************************************************************************/
process_function_key02()
{
	omode = 1;
	Vclear(WFIVE);
	Vwindopn(WFIVE);
}

/******************************************************************************

function:	process_function_key03()

purpose:	Process console function key strike.

returns:	Nothing

******************************************************************************/
process_function_key03()
{
short	baud;

	get_number(" New Baud rate > ", 5, string);
	if (strlen(string))
	{
		sscanf(string, "%d", &baud);
		switch(baud)
		{
			case  300:
			case 1200:
			case 2400:
			case 4800:
			case 9600:
				Vwarning(WONE, system_message[7]);
				tlc_sbr(baud);
				break;

			default:
				Vwarning(WONE, system_message[8]);
				break;
		}
	}
}

/******************************************************************************

function:	process_function_key04()

purpose:	Process console function key strike.

returns:	Nothing

******************************************************************************/
process_function_key04()
{
short	i;

	get_string(" Command > ", 60, END, string);
	for (i = 0; i < strlen(string); i++)
		process_command(string[i]);
}

/******************************************************************************

function:	process_function_key05()

purpose:	Process console function key strike.

returns:	Nothing

******************************************************************************/
process_function_key05()
{
	if (datcol)
	{
		datcol--;
		fclose(out);
		Vpos(WTHREE, 0, 34);
		Vprpgate(WTHREE, 0, 2, 5, 0);
	}
	else
	{
		_fmode = 0x8000;
		get_string(" Enter output file name > ", 60, CR, string);
		if (strlen(string))
			if (out = fopen(string, "w"))
			{
				datcol++;
				Vpos(WTHREE, 0, 34);
				Vprpgate(WTHREE, 0, 4, 5, 0);
			}
			else
				Vwarning(WONE, system_message[6]);
	}
}

/******************************************************************************

function:	process_function_key06()

purpose:	Process console function key strike.

returns:	Nothing

******************************************************************************/
process_function_key06()
{
	get_string(" DOS command > ", 60, CR, string);
	if (strlen(string))
	{
		Vwindopn(WSIX);
		system(string);
		Vwarning(WONE, system_message[2]);
		Vwindclo(WSIX);
	}
}

/******************************************************************************

function:	process_function_key09()

purpose:	Process line printer print screen function.

returns:	Nothing

******************************************************************************/
process_function_key09()
{
union	REGS	inregs;
union	REGS	outregs;

	int86(5, &inregs, &outregs);
	prone = 1;
	lput(12);
}

/******************************************************************************

function:	process_function_key10()

purpose:	Process program termination.

returns:	Nothing

******************************************************************************/
process_function_key10()
{
	tlc_clos();
	KBIO_remove();
	if (prone) lput(12);
	lterm();
	Vbyebye();
	exit();
}

/******************************************************************************

function:	get_string (prompt, length, delimiter, string)
		char	*prompt;
		short	length;
		char	delimiter;
		char	*string;

purpose:	input a string from the console w/edit

returns:	number of bytes read

******************************************************************************/
get_string(prompt, length, delimiter, string)
short	length;
char	*prompt, delimiter, *string;
{
short	index = 0, key, scancode, row, col;

	row = 0;
	col = strlen(prompt) + 1;
	Vcurtype (WONE, 1);
	Vpos (WONE, 0, 0);
	Vclearl (WONE);
	Vwriteat (WONE, 0, 1, prompt);
	Vwindopn (WONE);

	while (1)
	{
		key = get_key (&scancode);
		if ((key == delimiter) || ((key == 0) && (scancode == delimiter)))
		{
			*string = NULL;
			Vcurtype (WONE, 0);
			Vwindclo (WONE);
			return (index);
		}
		if (key == BS)
		{
			if (index)
			{
				index--;
				string--;
				Vpos (WONE, row, --col);
				Vprpgate (WONE, 32, 2, 1, 0);
			}
		}
		else	if (index < length)
			{
				index++;
				*string++ = (char)key;
				Vprpgate (WONE, key, 2, 1, 0);
				Vpos (WONE, row, ++col);
			}
	}
}

/******************************************************************************

function:	get_number (prompt, length, string)
		short	length;
		char	*prompt;
		char	*string;

purpose:	input a numeric string from the console w/edit

returns:	length of input string

******************************************************************************/
get_number(prompt, length, string)
short	length;
char	*prompt, *string;
{
short	index = 0, key, scancode, row, col;

	row = 0;
	col = strlen(prompt) + 1;
	Vcurtype (WONE, 1);
	Vpos (WONE, 0, 0);
	Vclearl (WONE);
	Vwriteat (WONE, 0, 1, prompt);
	Vwindopn (WONE);

	while (1)
	{
		key = get_key (&scancode);
		if (key == CR)
		{
			*string = NULL;
			Vcurtype (WONE, 0);
			Vwindclo (WONE);
			return (index);
		}
		if (key == BS)
		{
			if (index)
			{
				index--;
				string--;
				Vpos (WONE, row, --col);
				Vprpgate (WONE, 32, 2, 1, 0);
			}
		}
		else	if ((key >= 48) && (key <= 57))
			{
				if (index < length)
				{
					index++;
					*string++ = (char)key;
					Vprpgate (WONE, key, 2, 1, 0);
					Vpos (WONE, row, ++col);
				}
			}
	}
}

/******************************************************************************

function:	Vconvert (screen, row, col, cstring, value)
		short	screen, row, col, value;
		char	*cstring;

purpose:	convert a decimal value and output to screen 

returns:	nothing

******************************************************************************/
Vconvert (screen, row, col, cstring, value)
short	screen, row, col, value;
char	*cstring;
{
char	out[40];

	sprintf (out, cstring, value);
	Vwriteat (screen, row, col, out);
}

/******************************************************************************

function:	Vfconvert (screen, row, col, cstring, value)
		short	screen, row, col;
		float	value;
		char	*cstring;

purpose:	convert a decimal value and output to screen 

returns:	nothing

******************************************************************************/
Vfconvert (screen, row, col, cstring, value)
short	screen, row, col;
float	value;
char	*cstring;
{
char	out[40];

	sprintf (out, cstring, value);
	Vwriteat (screen, row, col, out);
}

