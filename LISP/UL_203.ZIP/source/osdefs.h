/* osdefs.h - system specific function declarations */

extern LVAL xgetkey();
extern LVAL xtime();
extern LVAL xrandomize();
extern LVAL xgraphiccharp();

/* Now provided by XLISP 2.0
extern LVAL xdigitcharp(),xuppercasep(),xlowercasep();
*/

/* string */
extern LVAL xstringposition();
extern LVAL xstringsearch();
extern LVAL xparser();

/* file system */
extern LVAL xdeletefile(),xfilesize();

/* Spawning processes */
extern LVAL xsystem();

#ifdef CLOSUREACCESS
/* Closure access */
extern LVAL xclosurename(),xclosuretype(),xclosurelambda();
extern LVAL xclosureargs(),xclosureoargs(),xclosurerest();
extern LVAL xclosurekargs(),xclosureaargs(),xclosurebody();
extern LVAL xclosureenv(),xclosurefenv();
#endif

/* get-plist */
extern LVAL xgetf_primitive();

/* find-symbol */
extern LVAL xfindsym();
