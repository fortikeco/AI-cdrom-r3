/* stuff.c - machine/os dependant code */

#include "xlisp.h"

#ifdef UNIX
#include <signal.h>
#include <sgtty.h>
#endif

#ifdef IS /* Integrated Solutions */
#include <strings.h>
#else
#include <string.h>
#endif

#ifdef MSDOS
#include <time.h>
#define END_OF_STRING '\0'
#endif

#include <sys/types.h>
#include <sys/stat.h>

#define LBSIZE 200

#ifdef UNIX
#define ERROR (-1)
#endif

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif

/* library external functions */
extern char *calloc();
extern char *realloc();
extern char *getenv();

/* external variables */
extern LVAL s_unbound, true, obarray;
extern FILE *tfp;
extern int errno;
extern char *sys_errlist[];

/* local variables */
static char lbuf[LBSIZE];
static int lpos[LBSIZE];
static int lindex;
static int lcount;
static int lposition;
static long rseed = 1L;

char *expand_path();

#ifdef UNIX
  static struct sgttyb terminal_state, xlisp_terminal_state;
  
  int handle_interrupts()
  {
      xltoplevel();
      set_handlers();
  }
  
  int handle_segmentation_violation()
  {
      oserror("Segmentation violation trapped!");
      xltoplevel();
      set_handlers();
  }
  
#ifdef IS
  int handle_bus_error()
  {
      oserror("Bus error trapped!");
      xltoplevel();
      set_handlers();
  }
#endif
  
  int set_handlers()
  {
      signal(SIGINT, handle_interrupts);
      signal(SIGQUIT, handle_interrupts);
      signal(SIGSEGV, handle_segmentation_violation);
#ifdef IS
      signal(SIGBUS, handle_bus_error);
#endif
  }
#endif

/* osinit - initialize */
osinit(banner)
  char *banner;
{
#ifdef UNIX
      set_handlers();
#endif
    printf("%s\n",banner);
    lposition = 0;
    lindex = 0;
    lcount = 0;

#ifdef UNIX
      /* Save the terminal state.
         Go into CBREAK mode with ECHO OFF. */
  
      {
        int status;
  
        status=ioctl(0, TIOCGETP, &terminal_state);
        if (status==ERROR) perror("TIOCGETP on 0");
      }
      xlisp_terminal_state=terminal_state;
      xlisp_terminal_state.sg_flags |= CBREAK;
      xlisp_terminal_state.sg_flags &= ~ECHO;
      xlisp_terminal_state.sg_flags &= ~CRMOD;
      {
        int status;
  
        status=ioctl(0, TIOCSETP, &xlisp_terminal_state);
        if (status==ERROR) perror("TIOCSETP on 0");
      }
#endif
}

/* osfinish - clean up before returning to the operating system */
osfinish()
{
#ifdef UNIX
  /* Restore the saved terminal state */
  ioctl(0, TIOCSETP, &terminal_state);
#endif
}

/* oserror - print an error message */
oserror(msg)
  char *msg;
{
    printf("error: %s\n",msg);
}

/* osrand - return a random number between 0 and n-1 */
int osrand(n)
  int n;
{
    long k1;

    /* make sure we don't get stuck at zero */
    if (rseed == 0L) rseed = 1L;

    /* algorithm taken from Dr. Dobbs Journal, November 1985, page 91 */
    k1 = rseed / 127773L;
    if ((rseed = 16807L * (rseed - k1 * 127773L) - k1 * 2836L) < 0L)
	rseed += 2147483647L;

    /* return a random number between 0 and n-1 */
    return ((int)(rseed % (long)n));
}

/* osaopen - open an ascii file */
FILE *osaopen(name,mode)
  char *name,*mode;
{
    return (fopen(expand_path(name),mode));
}

/* osbopen - open a binary file */
FILE *osbopen(name,mode)
  char *name,*mode;
{
    char bmode[10];
    strcpy(bmode,mode); strcat(bmode,"b");
    return (fopen(expand_path(name),bmode));
}

/* osclose - close a file */
int osclose(fp)
  FILE *fp;
{
    return (fclose(fp));
}

/* osagetc - get a character from an ascii file */
int osagetc(fp)
  FILE *fp;
{
    return (getc(fp));
}

/* osaputc - put a character to an ascii file */
int osaputc(ch,fp)
  int ch; FILE *fp;
{
    return (putc(ch,fp));
}

/* osbgetc - get a character from a binary file */
int osbgetc(fp)
  FILE *fp;
{
    return (getc(fp));
}

/* osbputc - put a character to a binary file */
int osbputc(ch,fp)
  int ch; FILE *fp;
{
    return (putc(ch,fp));
}

/* ostgetc - get a character from the terminal */
int ostgetc()
{
    int ch;

    /* check for a buffered character */
    if (lcount--)
	return (lbuf[lindex++]);

    /* get an input line */
    for (lcount = 0; ; )
	switch (ch = xgetc()) {
	case '\r':
		lbuf[lcount++] = '\n';
		xputc('\r'); xputc('\n'); lposition = 0;
		if (tfp)
		    for (lindex = 0; lindex < lcount; ++lindex)
			osaputc(lbuf[lindex],tfp);
		lindex = 0; lcount--;
		return (lbuf[lindex++]);
	case '\010':	/* BS */
	case '\177':	/* DEL */
		if (lcount) {
		    lcount--;
		    while (lposition > lpos[lcount]) {
			xputc('\010'); xputc(' '); xputc('\010');
			lposition--;
		    }
		}
		break;
	case '\032':	/* CTRL-Z */
		xflush();
		return (EOF);
	default:
		if (ch == '\t' || (ch >= 0x20 && ch < 0x7F)) {
		    lbuf[lcount] = ch;
		    lpos[lcount] = lposition;
		    if (ch == '\t')
			do {
			    xputc(' ');
			} while (++lposition & 7);
		    else {
			xputc(ch); lposition++;
		    }
		    lcount++;
		}
		else {
		    xflush();
		    switch (ch) {
		    case '\003':	xltoplevel();	/* control-c */
		    case '\007':	xlcleanup();	/* control-g */
		    case '\020':	xlcontinue();	/* control-p */
		    case '\032':	return (EOF);	/* control-z */
		    default:		return (ch);
		    }
		}
	}
}

/* ostputc - put a character to the terminal */
ostputc(ch)
  int ch;
{
    /* check for control characters */
    oscheck();

    /* output the character */
    if (ch == '\n') {
	xputc('\r'); xputc('\n');
	lposition = 0;
    }
    else {
	xputc(ch);
	lposition++;
   }

   /* output the character to the transcript file */
   if (tfp)
	osaputc(ch,tfp);
}

/* osflush - flush the terminal input buffer */
osflush()
{
    lindex = lcount = lposition = 0;
}

/* oscheck - check for control characters during execution */
oscheck()
{
    int ch;
    if (ch = xcheck())
	switch (ch) {
	case '\002':	/* control-b */
	    xflush();
	    xlbreak("BREAK",s_unbound);
	    break;
	case '\003':	/* control-c */
	    xflush();
	    xltoplevel();
	    break;
	case '\024':	/* control-t */
	    xinfo();
	    break;
	}
}

/* xinfo - show information on control-t */
static xinfo()
{
    extern int nfree,gccalls;
    extern long total;
    char buf[80];
    sprintf(buf,"\n[ Free: %d, GC calls: %d, Total: %ld ]",
	    nfree,gccalls,total);
    errputstr(buf);
}

/* xflush - flush the input line buffer and start a new line */
static xflush()
{
    osflush();
    ostputc('\n');
}

/* xgetc - get a character from the terminal without echo */
static int xgetc()
{
#ifdef UNIX
  return (getc(stdin));
#endif
#ifdef MSDOS
  return (bdos(7) & 0xFF);
#endif
}

/* xputc - put a character to the terminal */
static xputc(ch)
  int ch;
{
#ifdef MSDOS
  bdos(6,ch);
#endif
#ifdef UNIX
  return(putc(ch, stdout));
#endif
}

/* xcheck - check for a character */
static int xcheck()
{
#ifdef MSDOS
  return (bdos(6,0xFF));
#endif
#ifdef UNIX
  int characters_ready, result;

  result=NULL;
  {
    int status;

    status=ioctl(0, FIONREAD, &characters_ready);
    if (status==ERROR) perror("FIONREAD on 0");
  }

  if (characters_ready != 0) result=getc(stdin);
  return(result);
#endif
}

/* xsystem - execute a system command */
LVAL xsystem()
{
#ifdef MSDOS
  char *cmd="COMMAND";
  if (moreargs())
    cmd = (char *)getstring(xlgastring());
  xllastarg();
  return (system(cmd) == 0 ? true : cvfixnum((FIXTYPE)errno));
#endif
#ifdef UNIX
  int status;
  LVAL command_line_object;
  unsigned char *command_line;

  /* retrieve the command to be executed from the argument list */
  command_line_object = xlgastring();
  xllastarg();
  command_line = getstring(command_line_object);

  /* Restore the saved terminal state */
  ioctl(0, TIOCSETP, &terminal_state);

  /* Execute the command */
  status=system(command_line);

  /* Return the terminal state to what XLISP wants it to be */
  ioctl(0, TIOCSETP, &xlisp_terminal_state);

  /* See if it worked */
  if (status != 0)
    {
      char msg[80];
      sprintf(msg, "system(3) on [%s]", command_line);
      perror(msg);
    }
#endif
}

/* xgetkey - get a key from the keyboard */
LVAL xgetkey()
{
    xllastarg();
    return (cvfixnum((FIXTYPE)xgetc()));
}

/* xgraphiccharp - graphic-char-p */
LVAL xgraphiccharp()
{
    int ch;
    ch = getchcode(xlgachar());
    xllastarg();
#ifdef IS
    return (isprint(ch) ? true : NIL);
#else
    return (isgraph(ch) ? true : NIL);
#endif
}

/* xtime - implements non-Common-Lisp TIME
   returns time in seconds since 1 January 1970 */
LVAL xtime()
{
    xllastarg();
    return (cvfixnum((FIXTYPE)time(0)));
}

LVAL xrandomize()
{
    xllastarg();
    rseed=time(0);
    return (cvfixnum((FIXTYPE)rseed));
}

#ifdef CLOSUREACCESS
/* xclosurename returns closure */
LVAL xclosurename()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getname(arg));
}

/* xclosuretype returns closure */
LVAL xclosuretype()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (gettype(arg));
}

/* xclosurelambda returns closure */
LVAL xclosurelambda()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getlambda(arg));
}

/* xclosureargs returns closure */
LVAL xclosureargs()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getargs(arg));
}

/* xclosureoargs returns closure */
LVAL xclosureoargs()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getoargs(arg));
}

/* xclosurerest returns closure */
LVAL xclosurerest()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getrest(arg));
}

/* xclosurekargs returns closure */
LVAL xclosurekargs()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getkargs(arg));
}

/* xclosureaargs returns closure */
LVAL xclosureaargs()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getaargs(arg));
}

/* xclosurebody returns closure */
LVAL xclosurebody()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getbody(arg));
}

/* xclosureenv returns closure */
LVAL xclosureenv()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (xlgetenv(arg));
}

/* xclosurefenv returns closure */
LVAL xclosurefenv()
{
    LVAL arg;

    arg=xlgetarg();
    xllastarg();
    return (getfenv(arg));
}
#endif

/* xdeletefile - delete a file */
LVAL xdeletefile()
{
  LVAL filename_string;
  unsigned char *f;

  filename_string = xlgastring();
  xllastarg();
  f = getstring(filename_string);
  if (unlink(f) == -1)
    return(cvstring(sys_errlist[errno]));
  else
    return(true);
}

/* xfilesize - return size of a file in bytes */
LVAL xfilesize()
{
  LVAL filename_string;
  unsigned char *f;
  struct stat file_status_structure;

  filename_string = xlgastring();
  xllastarg();
  f = getstring(filename_string);
  if (stat(f, &file_status_structure) == -1)
    return(cvstring(sys_errlist[errno]));
  else
    return(cvfixnum((FIXTYPE)file_status_structure.st_size));
}

/* xstringposition - string:position */
LVAL xstringposition()
{
  int c, i;
  char *p, *s;
  LVAL string_object;
  
  c = getchcode(xlgachar());
  string_object = xlgastring();
  xllastarg();
  s = (char *)getstring(string_object);
#ifdef IS
  p = index(s,c);
#else
  p = strchr(s,c);
#endif
  if ( p == NULL )
    return(NIL);
  else
    return(cvfixnum((FIXTYPE)p-(FIXTYPE)s));
}

extern int substr();

LVAL xstringsearch()
{
  LVAL substring_object, string_object;
  char *substring, *string;
  FIXTYPE result;
  
  substring_object = xlgastring();
  string_object = xlgastring();
  xllastarg();
  substring = (char *)getstring(substring_object);
  string = (char *)getstring(string_object);
  
  result = (FIXTYPE)substr(substring, string);
  
  if ( result < 0 )
    return(NIL);
  else
    return(cvfixnum(result));
    
}

extern int parser();

/* xparser - interface to C string parser */
LVAL xparser()
{
  int brkused, done, maxtok, next, quoted;
  char escape, flag;
  char *break_chars, *quote, *string, *token, *white;
  LVAL result;
  
  next = 0;
  done = FALSE;
  result = NIL;
  
  /* read input arguments */
  flag = (char)getfixnum(xlgafixnum());
  maxtok = getfixnum(xlgafixnum());
  string = (char *)getstring(xlgastring());
  white = (char *)getstring(xlgastring());
  break_chars = (char *)getstring(xlgastring());
  quote = (char *)getstring(xlgastring());
  escape = getchcode(xlgachar());
  xllastarg();
  
  /* allocate memory for output */
  token = (char *)calloc(maxtok+1, sizeof(char));
  
  while ( !done )
  {
    done = parser ( flag,               /* IN flag */
                    token,              /* OUT token */
                    maxtok,             /* IN maxtok */
                    string,             /* IN string */
                    white,              /* IN white */
                    break_chars,        /* IN break */
                    quote,              /* IN quote */
                    escape,             /* IN escape */
                    &brkused,           /* OUT brkused */
                    &next,              /* IN/OUT next */
                    &quoted             /* OUT quoted */
                  );
    if ( !done )
      result = cons(cvstring(token), result);
  }
  return(result);
} 

/* ossymbols - enter os specific symbols */
ossymbols()
{
#ifdef SOCKETS
  /* socket-related symbols */
  define_socket_symbols();
  
  /* some error status values */
  define_errno_value_symbols();

#endif
}

#define BIG			(unsigned)1000 
#define VARIABLE_DELIMITER	'$'

char *expand_path(path)
  char *path;
{
  char *result, *rp;

  result = calloc(BIG, sizeof(char));
  rp = result;

  while (*path != NULL)
  {
    if ( *path == VARIABLE_DELIMITER )
    {
      char *name, *np, *value;

      path++;
      name = calloc(BIG, sizeof(char));
      np = name;
      while ( isalnum(*path) )
	*np++ = *path++;

#ifdef MSDOS
/* If this is (RETCH) MS-DOS, all the environment variable names
   are upper case, so make the name upper case before trying to get
   the value */
      np = name;
      while ( *np != END_OF_STRING )
        {
          *np = toupper(*np);
          np++;
        }
#endif        

      value=getenv(name);
      strcpy(rp, value);
      rp += strlen(value);

      free(name);
    }
    else
      *rp++ = *path++;
  };

  result=realloc(result, (unsigned)1+strlen(result));
  return(result);
}

#ifdef SOCKETS
LVAL xsocket()
{
  int s, af, type, protocol;
  LVAL arg;

  arg = xlgafixnum();
  af = getfixnum(arg);
  arg = xlgafixnum();
  type = getfixnum(arg);
  arg = xlgafixnum();
  protocol = getfixnum(arg);

  s = socket(af, type, protocol);

  return(cvfixnum(s));
}
#endif

/* xgetf_primitive - getf building block */
LVAL xgetf_primitive()
{
    LVAL p, plist, prp, result;

    /* get plist and property*/
    plist = xlgetarg();
    prp = xlgasymbol();
    xllastarg();

    /* see findprop in xlsym.c */
    for ( p = plist; consp(p) && consp(cdr(p)); p = cdr(cdr(p)) )
      if ( car(p) == prp )
      {
	  result = car(cdr(p));
	  break;
      }

    return (result);
}

/* xfindsym - find-symbol */
LVAL xfindsym()
{
    LVAL pname, sym, array;
    int i;
    char *name;

    /* get the print name of the symbol to look for */
    pname = xlgastring();
    xllastarg();

    name = (char *)getstring(pname);

    /* check for nil */
    if (strcmp(name,"NIL") == 0)
	return (NIL);

    /* search the obarray for the symbol */
    array = getvalue(obarray);
    i = hash(name,HSIZE);
    for (sym = getelement(array,i); sym; sym = cdr(sym))
	if (strcmp(name,getstring(getpname(car(sym)))) == 0)
	    return (car(sym));

    /* It's just not there */
    return (NIL);
}
