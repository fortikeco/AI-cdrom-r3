/* osptrs.h - system specific function pointers */

{	"GET-KEY",		S,	xgetkey		},
{	"TIME",			S,	xtime		},
{	"RANDOMIZE",		S,	xrandomize	},

{	"GRAPHIC-CHAR-P",	S,	xgraphiccharp	},

/* File system */
{	"DELETE-FILE",		S,	xdeletefile	},
{	"FILE-SIZE",		S,	xfilesize	},

/* Spawning processes */
{	"SYSTEM",		S,	xsystem		},

/* Strings */
{	"STRING:POSITION",	S,	xstringposition	},
{	"STRING-SEARCH",	S,	xstringsearch	},
{	"PARSER",		S,	xparser		},

#ifdef CLOSUREACCESS
/* Closure access */
{	"CLOSURE-NAME",		S,	xclosurename	},
{	"CLOSURE-TYPE",		S,	xclosuretype	},
{	"CLOSURE-LAMBDA",	S,	xclosurelambda	},
{	"CLOSURE-ARGS",		S,	xclosureargs	},
{	"CLOSURE-OPTIONAL-ARGS",S,	xclosureoargs	},
{	"CLOSURE-REST-ARGS",	S,	xclosurerest	},
{	"CLOSURE-KEYWORD-ARGS",	S,	xclosurekargs	},
{	"CLOSURE-AUX-ARGS",	S,	xclosureaargs	},
{	"CLOSURE-BODY",		S,	xclosurebody	},
{	"CLOSURE-ENV",		S,	xclosureenv	},
{	"CLOSURE-FENV",		S,	xclosurefenv	},
#endif

/* get-plist */
{	"GET-PLIST",		S,	xgetf_primitive	},

/* find-symbol */
{	"FIND-SYMBOL",		S,	xfindsym	},
