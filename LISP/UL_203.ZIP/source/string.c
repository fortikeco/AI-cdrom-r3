/* returns index into string at which substring begins
   or -1 if substring not present */

#ifdef IS /* Integrated Solutions */
#include <strings.h>
#else
#include <string.h>
#endif

int substr(substring, string)
  char *substring, *string;
{
  int result;
  char *k;
#ifdef MSC
  k = strstr(string, substring);
  if ( k )
    result = (int)(k - string);
  else
    result = -1;
#else
  int len;

  result = -1;

  len = strlen(substring);
  k = string;
  while (k)
  {
#ifdef IS
    if (k = index(k, *substring))
#else
    if (k = strchr(k, *substring))
#endif
      if (!strncmp(k, substring, len))
        result = (int)(k - string);
      else
        k++;
  }

#endif

  return(result);

}

