#include "kalypso.h"

#if !defined (MYDUMP) || defined (sun)
char	data_start[1] = { '\0' };
#endif
