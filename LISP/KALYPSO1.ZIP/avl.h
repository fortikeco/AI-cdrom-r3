/*
 * avl_tree.h
 *
 * balanced binary tree
 */

struct block {
	struct block		*left, *right;
	short			balance;
	short			sizeIndex;
	short			ref;
	short			bitmapsize;	/* chars in bitmap */
	int			datasize;	/* chars in data */
	char			*bitmap;
	char			*data;
};

typedef struct block	tree;
typedef char		*tree_data;
