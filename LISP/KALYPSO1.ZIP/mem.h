/*
 * mem.h
 *
 * definitions for the memory manager
 */

# define MINHUNK	(sizeof (struct bfree *))
# define NUMSIZES	9
# define MAXHUNK	(MINHUNK * 256)		/* MINHUNK * 2^(NUMSIZES-1) */
