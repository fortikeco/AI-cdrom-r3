/*
 * float.c
 *
 * floating pointer number primitives
 */

# include	"kalypso.h"
# include	"mem.h"

setFloatRef (l)
register double	*l;
{
	(void) setObjectRef ((char *) l);
}

lispval
makeFloat (dv)
double	dv;
{
	double		*nd;
	int		i;
	double		floor ();

	if ((((double) ((int) MININT)) <= dv && dv <= ((double) MAXINT))
 		&& floor (dv) == dv) {
		i = dv;
		return numtoitem (i);
	}
	nd = newFloat ();
	*nd = dv;
	return floatptoitem (nd);
}
