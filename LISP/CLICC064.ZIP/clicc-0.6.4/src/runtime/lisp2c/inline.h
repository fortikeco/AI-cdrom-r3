
void Fatom(CL_FORM *base);
void Fcharacterp(CL_FORM *base);
void Fcons(CL_FORM *base);
void Fconsp(CL_FORM *base);
void Feq(CL_FORM *base);
void Feql(CL_FORM *base);
void Ffloatp(CL_FORM *base);
void Ffunctionp(CL_FORM *base);
void Fintegerp(CL_FORM *base);
void rt_fixnump(CL_FORM *base);
void Flistp(CL_FORM *base);
void Fnumberp(CL_FORM *base);
void Fsimple_string_p(CL_FORM *base);
void Fsimple_vector_p(CL_FORM *base);
void Fsimple_bit_vector_p(CL_FORM *base);
void Fsymbolp(CL_FORM *base);
