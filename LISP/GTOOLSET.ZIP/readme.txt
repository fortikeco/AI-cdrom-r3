OSU LAIR Generic Task Toolset
Fafner Release 1.1-DoD

Important: if you use this software, please send mail to
	lair-toolset-info@cis.ohio-state.edu

  Include your name, email address, organization, and the date you got
the software. This will allow us to let you know about updates, bugs,
etc. (If you also include the type of machine and lisp you will be
running it in, as well as possible applications you are interested
in, it'd be greatly appreciated.)

--------------------------------------------------------------------
What you need to get the Fafner release of the toolset up & running:


1) The files. If you're reading this, you probably have already ftp'ed
and uncompressed/untarred the files.


2) PCL (CLOS)

This release runs under the Dec. 7 version of pcl. The 1.1 release
may run under the March 17 and Feb 3 releasees also, if there is enough
demand & it turns out to be possible.

The source files for this pcl are in the directory ./pcl. To bring
this pcl up on your system, edit the file defsys.lsp in the pcl source
directory (following the directions given in that file). Make sure
that the values you give for directory names end with a separator
character (ex. to specify a Unix directory, you must say /foo/bar/,
not /foo/bar). Then, start up a new lisp (of whatever variety you want
to run the toolset in), load defsys.lsp into it, and run the function
(pcl::compile-pcl).  (Note: the lisp world in which you compile pcl
*cannot* have a pcl already loaded into it.) When you're done, move
the compiled files (if necessary) to the directory you listed in
defsys.lsp as their location.  Then, exit the lisp you compiled pcl in
(you can't use it to run pcl in either).

3) The toolset:
	the source files for the toolset are in the directory ./toolset
 (toolset/toolset, from the top...)
 a) edit the file load-toolset.lsp to reflect your preferred directory,
	filename extensions, etc. (again, make sure directory names
	end with a separator character) Directions can be found in the
	load-toolset file.

 b) (optional) compile the toolset.
	Start a lisp, and load load-toolset.lsp into it.
	 This will load the compiled pcl files, as well as defining a few
	 functions, setting up packages, etc. You may see some warnings about
	 "redefining defsystem...(and a lot of other functions)". They
	 appear because the load-toolset file loads in a modified version
	 of pcl's defsys.lsp for its own use. You can ignore them.
	
	Load the toolset source files by running the function 
	 (load-toolset).  (In a perfect world, you wouldn't need this
	 step, but skipping it causes problems in some lisps.)

	Run the function (compile-toolset). This should compile all the
	 toolset files.

	Move the compiled toolset files into the directory you indicated
	 as their location in load-toolset.lsp. 

 c) load the toolset
	Start a lisp and load load-toolset.lsp into it. (As above, it
	 will load the pcl compiled files, and some other stuff, possibly
	 generating the
	 
	Load the toolset source or compiled files by running the function
	 (load-toolset). This should load any compiled toolset files that
	 you have. If it looks for the compiled version of a file in the
	 directory indicated in the load-toolset.lsp file (to see what
	 that is, look at the variable toolset::*gt-directory* -- the
	 car is the source directory, and the cdr is the compiled-files
	 directory), and it fails to find the uncompiled version, it
	 will look for the source file in the source directory indicated
	 by toolset::*gt-directory*.

Once you've loaded the toolset, you're ready to go. See the section in
the manual on installing, compiling, and running the toolset for more
details.

There are several example cases in the two directories: toolset/testcases/ra
and toolset/testcases/csrl. The file ./testcases/run.testcases gives more
information about them.

The documentation is in the toolset/doc directory, including a README
file giving directions for formatting and printing the documentation.

One additional note to the manual: if you are loading test systems
(or any system where load speed is more critical than run-time
speed, but which you have not compiled into fasload forms), you
can turn off system compilation of dragons' internal controllers.
Simply do (setf toolset::*compile-controllers* nil).

See the manual for more information.
