/* xlprint - xlisp print routine */
/*	Copyright (c) 1985, by David Michael Betz
	All Rights Reserved
	Permission is granted for unrestricted non-commercial use	*/

#include "xlisp.h"

/* external variables */
extern LVAL s_printcase,k_downcase,k_const,k_nmacro;
extern LVAL s_ifmt,s_ffmt;
extern LVAL obarray;
extern FUNDEF funtab[];
#ifdef PRINDEPTH
extern LVAL s_printlevel, s_printlength;	/* TAA mod */
#endif
#ifdef HASHFCNS
extern LVAL a_hashtable;
#endif

/* forward declarations */
#ifdef ANSI
#ifdef COMMONLISP
void NEAR putsymbol(LVAL fptr, char *str);
#else
void NEAR putsymbol(LVAL fptr, char *str, int escflag);
#endif
void NEAR putstring(LVAL fptr, LVAL str);
void NEAR putqstring(LVAL fptr, LVAL str);
void NEAR putatm(LVAL fptr, char *tag, LVAL val);
void NEAR putsubr(LVAL fptr, char *tag, LVAL val);
void NEAR putclosure(LVAL fptr, LVAL val);
void NEAR putfixnum(LVAL fptr, FIXTYPE n);
void NEAR putflonum(LVAL fptr, FLOTYPE n);
void NEAR putchcode(LVAL fptr, int ch, int escflag);
void NEAR putoct(LVAL fptr, int n);
#else
FORWARD VOID putsymbol();
FORWARD VOID putstring();
FORWARD VOID putqstring();
FORWARD VOID putatm();
FORWARD VOID putsubr();
FORWARD VOID putclosure();
FORWARD VOID putfixnum();
FORWARD VOID putflonum();
FORWARD VOID putchcode();
FORWARD VOID putoct();
#endif

#ifdef PRINDEPTH
#ifdef ANSI
void xlprintl(LVAL fptr, LVAL vptr, int flag);
#else
FORWARD VOID xlprintl();
#endif

int plevel,plength;

/* xlprint - print an xlisp value */
VOID xlprint(fptr,vptr,flag)
  LVAL fptr,vptr; int flag;
{
    LVAL temp;
    temp = getvalue(s_printlevel);
    if (fixp(temp) && getfixnum(temp) <= 32767 && getfixnum(temp) >= 0) {
	plevel = (int)getfixnum(temp);
    }
    else {
	plevel = 32767;	    /* clamp to "reasonable" level */
    }
    temp = getvalue(s_printlength);
    if (fixp(temp) && getfixnum(temp) <= 32767 && getfixnum(temp) >= 0) {
	plength = (int)getfixnum(temp);
    }
    else
	plength = 32767;
    xlprintl(fptr,vptr,flag);
}

VOID xlprintl(fptr,vptr,flag)
#else
#define xlprintl xlprint		/* alias */
VOID xlprint(fptr,vptr,flag)
#endif
  LVAL fptr,vptr; int flag;
{
    LVAL nptr,next;
    int n,i;
#ifdef PRINDEPTH
    int llength;
#endif

#ifndef NILSYMBOL
    /* print nil */
    if (vptr == NIL) {
	xlputstr(fptr,
	    (((!flag) || (getvalue(s_printcase) != k_downcase))?"NIL":"nil"));
	return;
    }
#endif

    /* check value type */
    switch (ntype(vptr)) {
    case SUBR:
	    putsubr(fptr,"Subr",vptr);
	    break;
    case FSUBR:
	    putsubr(fptr,"FSubr",vptr);
	    break;
    case CONS:
#ifdef PRINDEPTH
	    if (plevel-- == 0) {	    /* depth limitation */
		xlputc(fptr,'#');
		plevel++;
		break;
	    }
#endif
	    xlputc(fptr,'(');
#ifdef PRINDEPTH
	    llength = plength;
#endif
	    for (nptr = vptr; nptr != NIL; nptr = next) {
#ifdef PRINDEPTH
		if (llength-- == 0) { /* length limitiation */
		    xlputstr(fptr,"... ");
		    break;
		}
#endif
		xlprintl(fptr,car(nptr),flag);
		if ((next = cdr(nptr)) != NIL)
		    if (consp(next))
			xlputc(fptr,' ');
		    else {
			xlputstr(fptr," . ");
			xlprintl(fptr,next,flag);
			break;
		    }
	    }
	    xlputc(fptr,')');
#ifdef PRINDEPTH
	    plevel++;
#endif
	    break;
    case SYMBOL:
#ifdef COMMONLISP   /* check for uninterned symbol */
	{
	    char *str = (char *) getstring(getpname(vptr));
	    if (flag) {
		next = getelement(getvalue(obarray), hash(str, HSIZE));
		for (; !null(next); next = cdr(next))
		    if (car(next) == vptr) goto doprintsym;
		xlputstr(fptr,"#:");
		doprintsym: putsymbol(fptr,str);
	    }
	    else xlputstr(fptr,str);
	    break;
	}
#else
	    putsymbol(fptr,(char *)getstring(getpname(vptr)),flag);
	    break;
#endif
    case FIXNUM:
	    putfixnum(fptr,getfixnum(vptr));
	    break;
    case FLONUM:
	    putflonum(fptr,getflonum(vptr));
	    break;
    case CHAR:
	    putchcode(fptr,getchcode(vptr),flag);
	    break;
    case STRING:
	    if (flag)
		putqstring(fptr,vptr);
	    else
		putstring(fptr,vptr);
	    break;
    case STREAM:
#ifdef BETTERIO
	{
	    char *msg;
	    FILEP fp = getfile(vptr);
	    if (fp == CLOSED)	msg = "Closed-Stream";
	    else if (fp == STDIN) msg = "Stdin-Stream";
	    else if (fp == STDOUT) msg = "Stdout-Stream";
	    else if (fp == CONSOLE) msg = "Terminal-Stream";
	    else switch (vptr->n_sflags & (S_FORREADING | S_FORWRITING)) {
		case S_FORREADING: msg = "Input-Stream"; break;
		case S_FORWRITING: msg = "Output-Stream"; break;
		default: msg = "IO-Stream"; break;
	    }
	    putatm(fptr,msg,vptr);
	}
#else
	putatm(fptr,"File-Stream",vptr);
#endif
	break;
    case USTREAM:
	    putatm(fptr,"Unnamed-Stream",vptr);
	    break;
    case OBJECT:
#ifdef OBJPRNT
	    /* putobj fakes a (send obj :prin1 file) call */
	    putobj(fptr,vptr);
#else
	    putatm(fptr,"Object",vptr);
#endif
	    break;
    case VECTOR:
#ifdef PRINDEPTH
	    if (plevel-- == 0) {	    /* depth limitation */
		xlputc(fptr,'#');
		plevel++;
		break;
	    }
#endif
	    xlputc(fptr,'#'); xlputc(fptr,'(');
#ifdef PRINDEPTH
	    llength = plength;
#endif
	    for (i = 0, n = getsize(vptr); n-- > 0; ) {
#ifdef PRINDEPTH
		if (llength-- == 0) { /* length limitiation */
		    xlputstr(fptr,"... ");
		    break;
		}
#endif
		xlprintl(fptr,getelement(vptr,i++),flag);
		if (n) xlputc(fptr,' ');
	    }
	    xlputc(fptr,')');
#ifdef PRINDEPTH
	    plevel++;
#endif
	    break;
#ifdef STRUCTS
    case STRUCT:
#ifdef HASHFCNS
	    if (getelement(vptr,0) == a_hashtable) {
		putatm(fptr,"Hash-table",vptr);
		break;
	    }
#endif
	    xlprstruct(fptr,vptr,flag);
	    break;
#endif
    case CLOSURE:
	    putclosure(fptr,vptr);
	    break;
#ifdef COMPLX
    case COMPLEX:
	xlputstr(fptr, "#C(");
	if (ntype(next = getelement(vptr,0)) == FIXNUM)
	    putfixnum(fptr, getfixnum(next));
	else
	    putflonum(fptr, getflonum(next));
	xlputc(fptr,' ');
	if (ntype(next = getelement(vptr,1)) == FIXNUM)
	    putfixnum(fptr, getfixnum(next));
	else
	    putflonum(fptr, getflonum(next));
	xlputc(fptr, ')');
	break;
#endif
    case FREE:
	    putatm(fptr,"Free",vptr);
	    break;
    default:
	    putatm(fptr,"Unknown",vptr);	/* was 'Foo`   TAA Mod */
	    break;
    }
}

/* xlterpri - terminate the current print line */
VOID xlterpri(fptr)
  LVAL fptr;
{
    xlputc(fptr,'\n');
}

#ifdef BETTERIO
extern int lposition;	/* imported from the *stuff.c file */
/* xlgetcolumn -- find the current file column */

int xlgetcolumn(fptr)
  LVAL fptr;
{
    if (fptr == NIL) return 0;
    else if (ntype(fptr) == USTREAM) { /* hard work ahead :-( */
	LVAL ptr = gethead(fptr);
	int count = 0;

	while (ptr != NIL) {
	    if (getchcode(ptr) == '\n') count = 0 ;
	    else count++;
	    ptr = cdr(ptr);
	}
	return count;
    }
    else if (getfile(fptr) == CONSOLE)
	return lposition;
    else
	return ((fptr->n_sflags & S_WRITING)? fptr->n_cpos : 0);
}


/* xlfreshline -- start new line if not at beginning of line */
int xlfreshline(fptr)
  LVAL fptr;
{
    if (xlgetcolumn(fptr) != 0) {
	xlterpri(fptr);
	return TRUE;
    }
    return FALSE;
}
#endif


/* xlputstr - output a string */
VOID xlputstr(fptr,str)
  LVAL fptr; char *str;
{
    while (*str)
	xlputc(fptr,*str++);
}

/* putsymbol - output a symbol */
#ifdef COMMONLISP
LOCAL VOID NEAR putsymbol(fptr,str)
  LVAL fptr; char *str;
#else
LOCAL VOID NEAR putsymbol(fptr,str,escflag)
  LVAL fptr; char *str; int escflag;
#endif
{
    int downcase;
    LVAL type;
    char *p,c;

#ifndef COMMONLISP
    /* check for printing without escapes */
    if (!escflag) {
	xlputstr(fptr,str);
	return;
    }
#endif
    /* check to see if symbol needs escape characters */
/*  if (tentry(*str) == k_const) {*/	/* always execute this code! TAA Mod*/
	for (p = str; *p; ++p)
	    if (islower(*p)
	    ||	((type = tentry(*p)) != k_const
	      && (!consp(type) || car(type) != k_nmacro))) {
		xlputc(fptr,'|');
		while (*str) {
		    if (*str == '\\' || *str == '|')
			xlputc(fptr,'\\');
		    xlputc(fptr,*str++);
		}
		xlputc(fptr,'|');
		return;
	    }
/*  } */

    /* get the case translation flag */
    downcase = (getvalue(s_printcase) == k_downcase);

    /* check for the first character being '#' */
    if (*str == '#' || isnumber(str,NULL))
	xlputc(fptr,'\\');

    /* output each character */
    while ((c = *str++) != 0) {
	/* don't escape colon until we add support for packages */
	if (c == '\\' || c == '|' /* || c == ':' */)
	    xlputc(fptr,'\\');
	xlputc(fptr,(downcase && isupper(c) ? tolower(c) : c));
    }
}

/* putstring - output a string */
/* rewritten to	 print strings containing nulls TAA mod*/
LOCAL VOID NEAR putstring(fptr,str)
  LVAL fptr,str;
{
    char* p = getstring(str);
    unsigned len = getslength(str);

    /* output each character */
    while (len-- > 0) xlputc(fptr,*p++);
}

/* putqstring - output a quoted string */
/* rewritten to	 print strings containing nulls TAA mod*/
LOCAL VOID NEAR putqstring(fptr,str)
  LVAL fptr,str;
{
    char* p = getstring(str);
    unsigned len = getslength(str);
    int ch;

    /* output the initial quote */
    xlputc(fptr,'"');

    /* output each character in the string */
    while (len-- > 0) {
	ch = *(unsigned char *)p++;

	/* check for a control character */
	if (ch < 040 || ch == '\\' || ch == '"' || ch > 0176) { /* TAA MOD quote quote */
	    xlputc(fptr,'\\');
	    switch (ch) {
		case '\011':
		    xlputc(fptr,'t');
		    break;
		case '\012':
		    xlputc(fptr,'n');
		    break;
		case '\014':
		    xlputc(fptr,'f');
		    break;
		case '\015':
		    xlputc(fptr,'r');
		    break;
		case '\\':
		case '"':
		    xlputc(fptr,ch);
		    break;
		default:
		    putoct(fptr,ch);
		    break;
	    }
	}

		/* output a normal character */
	else
	    xlputc(fptr,ch);
    }


    /* output the terminating quote */
    xlputc(fptr,'"');
}

/* putatm - output an atom */
LOCAL VOID NEAR putatm(fptr,tag,val)
  LVAL fptr; char *tag; LVAL val;
{
    sprintf(buf,"#<%s: #",tag); xlputstr(fptr,buf);
    sprintf(buf,AFMT,val); xlputstr(fptr,buf);
    xlputc(fptr,'>');
}

/* putsubr - output a subr/fsubr */
LOCAL VOID NEAR putsubr(fptr,tag,val)
  LVAL fptr; char *tag; LVAL val;
{
/*    sprintf(buf,"#<%s-%s: #",tag,funtab[getoffset(val)].fd_name); */
    char *str;	    /* TAA mod */
    if ((str = funtab[getoffset(val)].fd_name) != NULL)
	sprintf(buf,"#<%s-%s: #",tag,str);
    else
	sprintf(buf,"#<%s: #",tag);
    xlputstr(fptr,buf);
    sprintf(buf,AFMT,val); xlputstr(fptr,buf);
    xlputc(fptr,'>');
}

/* putclosure - output a closure */
LOCAL VOID NEAR putclosure(fptr,val)
  LVAL fptr,val;
{
    LVAL name;
    if ((name = getname(val)) != NIL)
	sprintf(buf,"#<Closure-%s: #",getstring(getpname(name)));
    else
	strcpy(buf,"#<Closure: #");
    xlputstr(fptr,buf);
    sprintf(buf,AFMT,val); xlputstr(fptr,buf);
    xlputc(fptr,'>');
}

/* putfixnum - output a fixnum */
LOCAL VOID NEAR putfixnum(fptr,n)
  LVAL fptr; FIXTYPE n;
{
    char *fmt;
    LVAL val;
    fmt = (((val = getvalue(s_ifmt)) != NIL) && stringp(val) ? getstring(val)
	: IFMT);
    sprintf(buf,(char *)fmt,n);
    xlputstr(fptr,buf);
}

/* putflonum - output a flonum */
LOCAL VOID NEAR putflonum(fptr,n)
  LVAL fptr; FLOTYPE n;
{
    char *fmt;
    LVAL val;
#ifdef IEEEFP
    union { FLOTYPE fpn; long intn[2]; } k/*ludge*/;

    k.fpn = n;
    if ((k.intn[1] & 0x7fffffffL) == 0x7ff00000L && k.intn[0] == 0) {
	xlputstr(fptr,k.intn[1]<0 ? "-INF" : "+INF");
	return;
    }
    if ((k.intn[1]&0x7ff00000L) == 0x7ff00000L &&
	((k.intn[1]&0xfffffL) != 0 || k.intn[0] != 0)) {
	xlputstr(fptr,"NaN");
	return;
    }
#endif

    fmt = (((val = getvalue(s_ffmt)) != NIL) && stringp(val) ? getstring(val)
	: "%g");
    sprintf(buf,(char *)fmt,n);
    xlputstr(fptr,buf);
}

/* putchcode - output a character */
/* modified to print control and meta characters TAA Mod */
LOCAL VOID NEAR putchcode(fptr,ch,escflag)
  LVAL fptr; int ch,escflag;
{
    if (escflag) {
	xlputstr(fptr,"#\\");
	if (ch > 127) {
	    ch -= 128;
	    xlputstr(fptr,"M-");
	}
	switch (ch) {
	    case '\n':
		xlputstr(fptr,"Newline");
		break;
	    case ' ':
		xlputstr(fptr,"Space");
		break;
	    case 127:
		xlputstr(fptr,"Rubout");
		break;
	    default:
		if (ch < 32) {
		    ch += '@';
		    xlputstr(fptr,"C-");
		}
		xlputc(fptr,ch);
		break;
	}
    }
    else xlputc(fptr,ch);
}

/* putoct - output an octal byte value */
LOCAL VOID NEAR putoct(fptr,n)
  LVAL fptr; int n;
{
    sprintf(buf,"%03o",n);
    xlputstr(fptr,buf);
}
