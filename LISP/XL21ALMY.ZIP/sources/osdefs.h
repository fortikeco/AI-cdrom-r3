/* osdefs.h - system specific function declarations */

extern LVAL xsystem(V);

#ifndef UNIX
extern LVAL xgetkey(V);
#endif

#ifdef GRAPHICS
extern LVAL xmode(V), xcolor(V), xmove(V), xdraw(V),
    xmoverel(V), xdrawrel(V);
extern LVAL xcls(V), xcleol(V), xgotoxy(V);
#endif
