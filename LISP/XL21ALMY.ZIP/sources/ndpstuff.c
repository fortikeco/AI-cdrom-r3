/* cannot redirect standard input and output with this version */
/* ndpstuff.c - NDP C specific routines */

/* For some reason, this version has ceased to work. Since I don't like
   this compiler, I don't intend to fix it. */


#include "xlisp.h"
#include "osdefs.h"
#include <time.h>

#define LBSIZE 200

/* external variables */
extern LVAL s_unbound,s_dosinput,true;
extern FILE *tfp;
extern int errno;

/* local variables */
static char lbuf[LBSIZE];
static int lpos[LBSIZE];
static int lindex;
static int lcount;
int lposition;	/* export this */

/* forward declarations */
void xinfo();
void xflush();
void xputc();
void oscheck();

/* osinit - initialize */
VOID osinit(banner)
  char *banner;
{
    sprintf(stderr,"%s\n",banner);
    lposition = 0;
    lindex = 0;
    lcount = 0;
    setraw();
}

/* osfinish - clean up before returning to the operating system */
VOID osfinish()
{
    unsetraw();
}

/* xoserror - print an error message */
VOID xoserror(msg)
  char *msg;
{
    printf("error: %s\n",msg);
}

/* osrand - return next random number in sequence */
long osrand(rseed)
  long rseed;
{
    long k1;

    /* make sure we don't get stuck at zero */
    if (rseed == 0L) rseed = 1L;

    /* algorithm taken from Dr. Dobbs Journal, November 1985, page 91 */
    k1 = rseed / 127773L;
    if ((rseed = 16807L * (rseed - k1 * 127773L) - k1 * 2836L) < 0L)
	rseed += 2147483647L;

    /* return a random number between 0 and MAXFIX */
    return rseed;
}

/* osbopen - open a binary file */
FILE *osbopen(name,mode)
  char *name,*mode;
{
    FILE *temp;
    extern int _pmode;
    _pmode = 0x8000;
    temp = fopen(name,mode);
    _pmode = 0x4000;
}

#ifdef PATHNAMES
/* ospopen - open using a search path */
FILE *ospopen(name, ascii)
char *name;
int ascii;
{
    FILE *fp;
    char *path = getenv(PATHNAMES);
    char *newnamep;
    char ch;
    char newname[256];

    /* don't do a thing if user specifies explicit path */
    if (strchr(name,'/') != NULL && strchr(name, '\\') != NULL)
	return (ascii? fopen : osbopen)(name, "r");

    do {
	if (*path == '\0')  /* no more paths to check */
	    /* check current directory just in case */
	    return (ascii? fopen : osbopen)(name, "r");

	newnamep = newname;
	while ((ch = *path++) != '\0' && ch != ';' && ch != ' ')
	    *newnamep++ = ch;

	if (*(newnamep-1) != '/' && *(newnamep-1) != '\\')
	    *newnamep++ = '/';	/* final path separator needed */
	*newnamep = '\0';

	strcat(newname, name);
	fp = (ascii? fopen : osbopen)(newname, "r");
    } while (fp == NULL);   /* not yet found */

    return fp;
}
#endif

#ifdef BETTERIO

/* rename argument file as backup, return success name */
/* For new systems -- if cannot do it, just return TRUE! */

int renamebackup(filename)
  char *filename;
{
    char *bufp, ch=0;

    strcpy(buf, filename);  /* make copy with .bak extension */

    bufp = &buf[strlen(buf)];	/* point to terminator */
    while (bufp > buf && (ch = *--bufp) != '.' && ch != '/' && ch != '\\') ;


    if (ch == '.') strcpy(bufp, ".bak");
    else strcat(buf, ".bak");

    unlink(buf);

    return !rename(filename, buf);
}

#endif

/* ostgetc - get a character from the terminal */
int ostgetc()
{
    int ch;

    /* check for a buffered character */
    if (lcount--)
    return (lbuf[lindex++]);

    /* get an input line */
    if (getvalue(s_dosinput) != NIL) {
	lindex = 2;
	lbuf[0] = LBSIZE - 2;
	readline(lbuf);
	putchar('\n');
	lcount = lbuf[1];
	lbuf[lcount+2] = '\n';
	if (tfp) fwrite(&lbuf[2],1,lcount+1,tfp);
	lposition = 0;
	return (lbuf[lindex++]);
    }
    else {
    for (lcount = 0; ; )
    switch (ch = xgetc()) {
    case '\r':
	lbuf[lcount++] = '\n';
	xputc('\r'); xputc('\n'); lposition = 0;
	if (tfp) fwrite(lbuf,1,lcount,tfp);
	lindex = 0; lcount--;
	return (lbuf[lindex++]);
    case '\010':
    case '\177':
	if (lcount) {
	    lcount--;
	    while (lposition > lpos[lcount]) {
	    xputc('\010'); xputc(' '); xputc('\010');
	    lposition--;
	    }
	}
	break;
    case '\032':
	xflush();
	return (EOF);
    default:
	if (ch == '\t' || (ch >= 0x20 && ch < 0x7F)) {
	    lbuf[lcount] = ch;
	    lpos[lcount] = lposition;
	    if (ch == '\t')
	    do {
		xputc(' ');
	    } while (++lposition & 7);
	    else {
	    xputc(ch); lposition++;
	    }
	    lcount++;
	}
	else {
	    xflush();
	    switch (ch) {
	    case '\003':    xltoplevel();   /* control-c */
	    case '\007':    xlcleanup();    /* control-g */
	    case '\020':    xlcontinue();   /* control-p */
	    case '\032':    return (EOF);   /* control-z */
	    case '\024':    xinfo();	    /* control-t */
			    return ostgetc();
	    default:	    return (ch);
	    }
	}
    }
    }
}

/* ostputc - put a character to the terminal */
VOID ostputc(ch)
  int ch;
{
    /* check for control characters */
    oscheck();

    /* output the character */
    if (ch == '\n') {
    xputc('\r'); xputc('\n');
    lposition = 0;
    }
    else if (ch == '\t')
	do { xputc(' '); } while (++lposition & 7);
    else {
    xputc(ch);
    lposition++;
   }

   /* output the character to the transcript file */
   if (tfp)
    fputc(ch,tfp);
}

/* osflush - flush the terminal input buffer */
VOID osflush()
{
    lindex = lcount = lposition = 0;
}

/* oscheck - check for control characters during execution */
VOID oscheck()
{
    int ch;
    if ((ch = xcheck()) != 0)
    switch (ch) {
    case '\002':    /* control-b */
	xflush();
	xlbreak("BREAK",s_unbound);
	break;
    case '\003':    /* control-c */
	xflush();
	xltoplevel();
	break;
    case '\023':    /* control-s */
	xgetc();    /* paused -- get character and toss */
	break;
    case '\024':    /* control-t */
	xinfo();
	break;
    }
}

/* xinfo - show information on control-t */
static VOID xinfo()
{
    extern int nfree,gccalls;
    extern long total;

    sprintf(buf,"\n[ Free: %d, GC calls: %d, Total: %ld ]",
	nfree,gccalls,total);
    errputstr(buf);
}

/* xflush - flush the input line buffer and start a new line */
static VOID xflush()
{
    osflush();
    ostputc('\n');
}

/* xsystem - execute a system command */
LVAL xsystem()
{
    char command[128], commandtail[128],*s;
    int Err;

    if (moreargs()) {
	strcpy(commandtail," /c ");
	s = (char *)getstring(xlgastring());
	strcat(commandtail,s);
	strcat(commandtail,"\r");
	commandtail[0] = strlen(commandtail) - 2;
	xllastarg();
    }
    else
	strcpy(commandtail,"\001 \r");

    unsetraw();
    Err = ssystem(getenv("COMSPEC"),commandtail);
    setraw();

    return (Err == 0 ?
	true : cvfixnum((FIXTYPE)Err));
}

/* xgetkey - get a key from the keyboard */
LVAL xgetkey()
{
    xllastarg();
    return (cvfixnum((FIXTYPE)xgetc()));
}

/* ossymbols - enter os specific symbols */
VOID ossymbols()
{
}
#ifdef TIMES

unsigned long ticks_per_second() { return((unsigned long) 100); }

unsigned long run_tick_count()
{
  return((unsigned long) sec_100_()); /* Real time in MSDOS */
}

unsigned long real_tick_count()
{				   /* Real time */
  return((unsigned long) sec_100_());
}


LVAL xtime()
{
    LVAL expr,result;
    unsigned long tm;

    /* get the expression to evaluate */
    expr = xlgetarg();
    xllastarg();

    tm = run_tick_count();
    result = xleval(expr);
    tm = run_tick_count() - tm;
    sprintf(buf, "The evaluation took %.2f seconds.\n",
	    ((double)tm) / ticks_per_second());
    trcputstr(buf);
#ifdef BUFFERED
    fflush(stdout);
#endif
    return(result);
}

LVAL xruntime() {
    xllastarg();
    return(cvfixnum((FIXTYPE) run_tick_count()));
}

LVAL xrealtime() {
    xllastarg();
    return(cvfixnum((FIXTYPE) real_tick_count()));
}

#endif
