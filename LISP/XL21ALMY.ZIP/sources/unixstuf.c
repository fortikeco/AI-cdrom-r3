/*I doubt that standard input and output can be redirected with this version*/
/* -*-C-*-
********************************************************************************
*
* File:		unixstuff.c
* Description:	UNIX-Specific interfaces for XLISP
* Author:	David Michael Betz; Niels Mayer
*
* WINTERP 1.0 Copyright 1989 Hewlett-Packard Company (by Niels Mayer).
* XLISP version 2.1, Copyright (c) 1989, by David Betz.
*
* Modified again by Tom Almy
********************************************************************************
*/

#include <signal.h>
#include <sys/types.h>
#include <sys/times.h>

#ifdef BSD
#include <sys/ioctl.h>
struct sgttyb savetty;
struct sgttyb newtty;
#define stty(fd,arg)	(ioctl(fd, TIOCSETP, arg))
#define gtty(fd,arg)	(ioctl(fd, TIOCGETP, arg))
#else
#include <termio.h>
struct termio savetty;
struct termio newtty;
#define stty(fd,arg)	(ioctl(fd, TCGETA, arg))
#define gtty(fd,arg)	(ioctl(fd, TCSETAF, arg))
#endif

#include "xlisp.h"

#define LBSIZE	200
#define HZ 60

/* -- external variables */
extern	FILE	*tfp;
extern long times();
extern LVAL xlenv, xlfenv, xldenv;

/* -- local variables */
static	char	lbuf[LBSIZE];
static	int	lpos[LBSIZE];
int	lposition;  /* export this */
static	int	lindex;
static	int	lcount;

char *xfgets();
char read_keybd();


/******************************************************************************
 * xsystem - run a process, sending output (if any) to stdout/stderr
 *
 * syntax: (system <command line>)
 *		   <command line> is a string to be sent to the subshell (sh).
 *
 * Returns T if the command executed succesfully, otherwise returns the
 * integer shell exit status for the command.
 *
 * Added to XLISP by Niels Mayer
 ******************************************************************************/
LVAL xsystem()
{
  extern LVAL true;
  extern int sys_nerr;
  extern char *sys_errlist[];
  extern int errno;
  LVAL command;
  int  result;
  char temptext[1024];

  /* get shell command */
  command = xlgastring();
  xllastarg();

  /* run the process */
  result = system((char *) getstring(command));

  if (result == -1) {		/* if a system error has occured */
    if (errno < sys_nerr)
      (void) sprintf(temptext, "Error in system(3S): %s\n", sys_errlist[errno]);
    else
      (void) strcpy(temptext, "Error in system(3S): unknown error\n");
    xlfail(temptext);
  }

  /* return T if success (exit status 0), else return exit status */
  return (result ? cvfixnum(result) : true);
}

/******************************************************************************/
/* -- Written by dbetz for XLISP 2.0 */


/* -- osinit - initialize */
osinit(banner)

char	*banner;
{
	fprintf(stderr,"%s\nUNIX version\n", banner );
	init_tty();
	lindex	= 0;
	lcount	= 0;
}

/* -- osfinish - clean up before returning to the operating system */
osfinish()
{
	stty(0, &savetty);
}


/* -- xoserror - print an error message */
xoserror(msg)

char	*msg;

{
	printf( "error: %s\n", msg );
}


/* osrand - return next random number in sequence */
long osrand(rseed)
  long rseed;
{
    long k1;

    /* make sure we don't get stuck at zero */
    if (rseed == 0L) rseed = 1L;

    /* algorithm taken from Dr. Dobbs Journal, November 1985, page 91 */
    k1 = rseed / 127773L;
    if ((rseed = 16807L * (rseed - k1 * 127773L) - k1 * 2836L) < 0L)
	rseed += 2147483647L;

    /* return a random number between 0 and MAXFIX */
    return rseed;
}

#ifdef PATHNAMES
/* ospopen - open using a search path */
FILE *ospopen(name, ascii)
char *name;
int ascii;  /* value not used in UNIX */
{
    FILE *fp;
    char *path = getenv(PATHNAMES);
    char *newnamep;
    char ch;
    char newname[256];

    /* don't do a thing if user specifies explicit path */
    if (strchr(name,'/') != NULL || path == NULL)
	return fopen(name, "r");

    do {
	if (*path == '\0')  /* no more paths to check */
	    /* check current directory just in case */
	    return fopen(name, "r");

	newnamep = newname;
	while ((ch = *path++) != '\0' && ch != ';' && ch != ' ')
	    *newnamep++ = ch;

	if (*(newnamep-1) != '/')
	    *newnamep++ = '/';	/* final path separator needed */
	*newnamep = '\0';

	strcat(newname, name);
	fp = fopen(newname, "r");
    } while (fp == NULL);   /* not yet found */

    return fp;
}
#endif

#ifdef BETTERIO

/* rename argument file as backup, return success name */
/* For new systems -- if cannot do it, just return TRUE! */

int renamebackup(filename)
  char *filename;
{
    char *bufp, ch=0;

    strcpy(buf, filename);  /* make copy with .bak extension */

    bufp = &buf[strlen(buf)];	/* point to terminator */
    while (bufp > buf && (ch = *--bufp) != '.' && ch != '/') ;


    if (ch == '.') strcpy(bufp, ".bak");
    else strcat(buf, ".bak");

    unlink(buf);

    return !rename(filename, buf);
}

#endif


/* -- ostgetc - get a character from the terminal */
int	ostgetc()
{

	while(--lcount < 0 )
		{
		if ( xfgets(lbuf,LBSIZE,stdin) == NULL )
			return( EOF );
		if ( tfp )
			fputs( lbuf, tfp );

		lcount = strlen( lbuf );
		lindex = 0;
		lposition = 0;
		}

	return( lbuf[lindex++] );
}


/* -- ostputc - put a character to the terminal */
ostputc( ch )
int	ch;
{
	char buf[1];

	buf[0] = ch;

	if (ch == '\n') lposition = 0;
	else lposition++;

	/* -- output the character */
/*	  putchar( ch ); */
	write(1,buf,sizeof(buf));

	/* -- output the char to the transcript file */
	if ( tfp )
		fputc( ch, tfp );
}




/* -- osflush - flush the terminal input buffer */
osflush()
{
	lindex = lcount = lposition = 0;
}

void oscheck()
{
}

osx_check(ch)
char ch;
{
     switch (ch) {
	case '\003':
	  xltoplevel(); /* control-c */
	case '\007':
	  xlcleanup();	/* control-g */
	case '\020':
	  xlcontinue(); /* control-p */
	case '\024':	/* control-t */
	  xinfo();
	  printf("\n ");
     }
}


/* -- ossymbols - enter os-specific symbols */
ossymbols()
{
}


/* xinfo - show information on control-t */
static xinfo()
{
  extern int nfree,gccalls;
  extern long total;
  char tymebuf[20];
  int tyme;

  tyme = time(0);
  strcpy(tymebuf, ctime(&tyme));
  tymebuf[19] = '\0';
  sprintf(buf,"\n[ %s Free: %d, GC calls: %d, Total: %ld ]",
    tymebuf, nfree,gccalls,total);
  errputstr(buf);
}

/* xflush - flush the input line buffer and start a new line */
static xflush()
{
  osflush();
  ostputc('\n');
}


char read_keybd()
{
   int nrd;
   char buf[1];

   nrd = read(0, buf, sizeof(buf));
   buf[nrd] = 0;

   if (buf[0] == 127) {	    /* perform the BACKSPACE */
      stdputstr("\010");
      stdputstr(" ");
      stdputstr("\010");
   }
   else
      stdputstr(buf);

   return(buf[0]);
}


init_tty()
{
	/* extern sigcatch(); */
    extern onsusp();

	signal(SIGINT, xltoplevel);
    signal(SIGQUIT, SIG_IGN);
    if (signal(SIGTSTP, onsusp) == SIG_DFL) {
	signal(SIGTSTP, onsusp);
    }
	if (gtty(0, &savetty) == -1)
	{
		printf("ioctl failed: not a tty\n");
		exit();
	}
#ifdef BSD
	newtty = savetty;
	newtty.sg_flags |= CBREAK;	/* turn off canonical mode */
					/* i.e., turn on cbreak mode */
	newtty.sg_flags &= ~ECHO;	/* turn off character echo */
#else
	newtty.c_lflag &= ~ICANON;  /* SYS 5 */
	newtty.c_lflag &= ~ECHO;
	newtty.c_cc[VMIN] = 1;
	newtty.c_cc[VTIME] = 1;
#endif
	/*
	 * You can't request that it try to give you at least
	 * 5 characters, nor set the timeout to 10 seconds,
	 * as you can in the S5 example.  If characters come
	 * in fast enough, though, you may get more than one.
	 */
	if (stty(0, &newtty) == -1)
	{
		printf("cannot put tty into cbreak mode\n");
		exit();
	}
}

onsusp()
{
    /* ignore SIGTTOU so we dont get stopped if csh grabs the tty */
    signal(SIGTTOU, SIG_IGN);
    stty(0, &savetty);
    xflush();
    signal(SIGTTOU,SIG_DFL);

    /* send the TSTP signal to suspend our process group */
    signal(SIGTSTP, SIG_DFL);
    sigsetmask(0);
    kill(0, SIGTSTP);
    /* pause for station break */

    /* we re back */
    signal(SIGTSTP, onsusp);
    stty(0, &newtty);
}



char *xfgets(s, n, iop)
char *s;
register FILE *iop;
{
	register c;
	register char *cs;

	cs = s;
	while (--n>0 && (c = read_keybd()) != EOF) {
	     switch(c) {
		  case '\002' :			/* CTRL-b */
		  case '\003' :			/* CTRL-c */
		  case '\007' :			/* CTRL-g */
		  case '\020' :			/* CTRL-p */
		  case '\024' : osx_check(c);	/* CTRL-t */
				n++;
				break;

		  case 8      :
		  case 127    : n+=2;		/* BACKSPACE */
				*cs--;
				*cs = ' ';
				break;

		  default     : *cs++ = c;	/* character */
		}
		if (c=='\n') break;
	}
	if (c == EOF && cs==s) return(NULL);
	*cs++ = '\0';
	return(s);
}

#ifdef TIMES
/***********************************************************************/
/**								      **/
/**		     Time and Environment Functions		      **/
/**								      **/
/***********************************************************************/

unsigned long ticks_per_second() { return((unsigned long) HZ); }

unsigned long run_tick_count()
{
  struct tms tm;

  times(&tm);
  return((unsigned long) tm.tms_utime + tm.tms_stime );
}

unsigned long real_tick_count()
{				   /* Real time */
  return((unsigned long) (60 * (time((unsigned long *) NULL))));
}


LVAL xtime()
{
  LVAL expr, result;
  unsigned long tm, rtm;
  double dtm, rdtm;

/* get the expression to evaluate */
  expr = xlgetarg();
  xllastarg();

  tm = run_tick_count();
  rtm = real_tick_count();
  result = xleval(expr);
  tm = run_tick_count() - tm;
  rtm = real_tick_count() - rtm;
  dtm = (tm > 0) ? tm : -tm;
  rdtm = (rtm > 0) ? rtm : -rtm;
  sprintf(buf, "CPU %.2f sec., Real %.2f sec.\n", dtm / ticks_per_second(),
					    rdtm / ticks_per_second());
  trcputstr(buf);
  return(result);
}

LVAL xruntime() {
    xllastarg();
    return(cvfixnum((FIXTYPE) run_tick_count()));
}

LVAL xrealtime() {
    xllastarg();
    return(cvfixnum((FIXTYPE) real_tick_count()));
}
#endif

