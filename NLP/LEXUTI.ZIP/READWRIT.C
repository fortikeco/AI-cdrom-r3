/* READWRIT.C -- binary tree record-based I/O procedures */

#ifndef BT_REC_SIZE
#include "btree.h"			/* make sure we have standard types */
#endif

int position_index (FILE *, long);
int put_bt_rec (FILE *, BT_rec *);
int get_bt_rec (FILE *, BT_rec *);


/* position file pointer at point corresponding to node number */
/* returns zero on successful call [see fseek()] */
int position_index (FILE *index, long node_number) {

int status;

status = fseek (index, (node_number * BT_REC_SIZE), SEEK_SET);
if (status == 0)
	return (OK);
return (ERR);
}


/* write contents of binary tree record to index file, leave file position
   unchanged afterwards */
int put_bt_rec (FILE *index, BT_rec *record) {

if (fwrite (record, BT_REC_SIZE, 1, index) != 1) {
	printf ("Error writing BT record.\n");
	return (ERR);
    }
/* now resore original file position */
if (fseek (index, (BT_REC_SIZE * (BT_rec)-1), SEEK_CUR) != 0) {
	printf ("Error restoring file position after write.\n");
	return (ERR);
	}
return (OK);
}

/* read in a b-tree record at current file position, restore file pointer
   to original location, and return record */
int get_bt_rec (FILE *index, BT_rec *record) {

if (fread (record, BT_REC_SIZE, 1, index) != 1) {
	printf ("Error reading BT record.\n");
	return (ERR);
    }
/* now resore original file position */
if (fseek (index, (BT_REC_SIZE * (BT_rec)-1), SEEK_CUR) != 0) {
	printf ("Error restoring file position after read.\n");
	return (ERR);
	}
return (OK);
}


