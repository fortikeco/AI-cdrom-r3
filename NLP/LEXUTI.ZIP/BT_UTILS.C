/* 	BT_UTILS.C -- binary-tree utilities 
	2/9/93	Jim Rodlin
*/

#include <dir.h>
#include <stdlib.h>
#define IBTT_START 0
#define IBTT_NEXT 1
#define MAX_DEPTH 20				/* A depth 20 tree has 1M nodes */
#define MAX_PATH 135


/* prototypes */
char *itoa (int value, char *string, int radix);
long ibtt (int flag, int depth);
void set_filename (char *filename, int depth);
int make_ibtt (char *, int depth);
int ibtt_sequence (long node_num, int cur_depth);
long l_child (long node_num);
long r_child (long node_num);
int index_depth (FILE *index);	    /* depth of B-Tree index file */

FILE *ibtt_file;					/* extern for recursive ibtt_sequence() */
int max_depth;						/* ditto */

/* 	IBTT returns the next node number of an Inorder Binary Tree Traversal
	of depth D each time it is called. The procedure maintains a sequential
	file containing the traversal sequence for a binary tree of each depth
	1 thru MAX_DEPTH, creating one if it does not already exist. It keeps
	indices for each sequence independantly, so different trees may be
	spanned at the same time (but not the same tree multiple times). The
    files are kept closed between calls, for safety.
*/
long ibtt (int flag, int depth) {

char ibtt_fn[] = "depth_00.ibt";		/* std. IBTT sequence filename */
char filepath[MAX_PATH];				/* path to file */
char *s; 
FILE *ibtt_file;
static fpos_t ibtt_offset[MAX_DEPTH+1];	/* file offsets for each sequence */
long node_number;

if ((flag != IBTT_START && flag != IBTT_NEXT) ||
	(depth < 1 || depth > MAX_DEPTH))
		return (ERR);					/* illegal command */
switch (flag) {
	case IBTT_START:
		set_filename(ibtt_fn, depth); 	/* get filename for depth N index */
		/* if IBTT file doesn't exist, create it */
		if ((s = searchpath (ibtt_fn)) != NULL)
			strncpy (filepath, s, MAX_PATH);
		else
			if (make_ibtt (ibtt_fn, depth) != OK) {
				printf ("Error creating IBTT file, aborting.\n");
				return (ERR);
				}
        ibtt_offset[depth] = 0L;	    /* where to start reading */
		node_number = 0L;				/* proper START response */
    	break;

	case IBTT_NEXT:
		set_filename (ibtt_fn, depth);
		if ((s = searchpath (ibtt_fn)) != NULL)
			strncpy (filepath, s, MAX_PATH);
		else { 							
			printf ("Error locating file %s, aborting.\n", ibtt_fn);
			return (ERR);               /* file should already exist */
            }
		if ((ibtt_file = fopen (filepath, "rb")) == NULL) {
			printf ("Error opening file %s, aborting.\n", filepath);
			return (ERR);
			}
		if (fseek (ibtt_file, ibtt_offset[depth], SEEK_SET) != 0) {
			printf ("Error seeking data record, aborting.\n");
			return (ERR);
            }
		if (fread (&node_number, sizeof (node_number), 1, ibtt_file) != 1) {
			printf ("Error reading data, aborting.\n");
			return (ERR);
			}
		fgetpos (ibtt_file, &ibtt_offset[depth]);	/* store new offset */
		fclose (ibtt_file);
		break;

	default:	printf ("WARNING: IBTT illegal case reached.");
				break;
	}
return (node_number);
}


/* 	This procedure assumes *fn points to a string of format "depth_nn.idx". It
	writes two digit characters in place of 'nn' to produce the correct name.  
*/
void set_filename(char *fn, int depth) {

char depstr[4];						/* room for a two digit string */

itoa (depth, depstr, 10);

if (depth < 10)   					/* copy digits into filename string */
	{ fn[6] = '0'; fn[7] = depstr[0]; }
else
	{ fn[6] = depstr[0]; fn[7] = depstr[1]; }
}


/* 	Create an Inorder Binary Tree Traversal sequence and write it to file. We
	open the output file, then call a recursive tree builder from node one.
*/
int make_ibtt (char *filename, int depth) {

extern FILE *ibtt_file;
extern int max_depth;
int status;

max_depth = depth;
if ((ibtt_file = fopen (filename, "wb")) == NULL)
	return (ERR);
	printf ("Creating IBTT file for depth %d.\n", depth);
status = ibtt_sequence (1L, 1);	/* either OK or ERR */
fclose (ibtt_file);
return (status);
}


/* 	Build a tree, recursively. Algorithm: If cur_depth == max_depth, write
	node_num and return OK. Else call ibtt_sequence for l_child(node_num),
	write node_num, and call ibtt_sequence for r_child(node_num). If any
	calls to ibtt_sequence return ERR, abort and return ERR.
	For a tree of depth N, this procedure recurses up to 2^(N-1) times! Each
	instance pushes an INT and a LONG onto the stack. Be sure there is plenty
	of stack space.
*/
int ibtt_sequence (long node_num, int cur_depth) {

extern FILE *ibtt_file;
extern int max_depth;

if (cur_depth == max_depth) {	/* leaf node only */
	if (fwrite ((void *)&node_num, sizeof (long), 1, ibtt_file) != 1)
		return (ERR);
	return (OK);
	}

/* make a tree: left children first, then node, then right children */
if (ibtt_sequence (l_child (node_num), (cur_depth + 1)) == ERR)
	return (ERR);
if (fwrite ((void *)&node_num, sizeof (long), 1, ibtt_file) != 1)
	return (ERR);
if (ibtt_sequence (r_child (node_num), (cur_depth + 1)) == ERR)
	return (ERR);

return (OK);
}


/* The left child of a B-Tree node is node * 2. */
long l_child (long node_num) {
return (node_num * 2L);
}


/* The right child of a node is (node * 2) + 1. */
long r_child (long node_num) {
return ((node_num * 2L) + 1L);
}


/*  Get index file depth from BT_marker without altering file position after
	call.
*/
int index_depth (FILE *index) {

fpos_t current;
BT_rec record;
extern BT_rec BT_marker_blank;
int depth;

if (fgetpos (index, &current) != 0)    		/* store current file position */
	return (ERR);
rewind (index);
if (fread (&record, sizeof (record), 1, index) != 1)	/* read BT marker */                     	
	return (ERR);
depth = (int)(record - BT_marker_blank);	/* extract depth from marker */
if (fsetpos (index, &current) != 0)			/* restore file position */
	return (ERR);
return (depth);
}