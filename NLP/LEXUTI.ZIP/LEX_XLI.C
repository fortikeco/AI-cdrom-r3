/* LEX_XLI.C -- Scheme lexicon lookup utility
*/

#include "dos.h"
#include "math.h"
#include "stdlib.h"
#include "lexicon.c"

#define F_NEAR	 0x0001  /*  Set model flag to near.  */
#define F_INT	 0x0002  /*  Set integer flag to 16 bits. */
#define F_REL	 0x0004  /*  Set release env block by extern pgm flag. */
#define F_PAD	 0x0008  /*  Set parm blocking flag to unblocked. */

#define RT_INTEGER 0  /* Set return type to be an integer. */
#define RT_BOOLEAN 1  /* Set return type to be boolean. */
#define RT_STRING  2  /* Set return type to be a string. */
#define RT_DOUBLE  3  /* Set the return type to be a float num. */

typedef unsigned short WORD;		/* 16-bit unsigned value (2 bytes ) */

typedef struct xli_string {
	char *post_list;
	WORD post_len;
};


/* This variable is set during startup code contained in C0NEW.OBJ. Be sure
   to link that file with this one.
*/
extern WORD _tsize;

/*
   Xwait and xbye will contain the actual addresses, XLI entry points, that
   we'll jump to when we call XLI so they need to be big enough to hold FAR
   pointers.
*/
WORD xwait[2];
WORD xbye[2];


struct xli_file_struct {
  WORD id;
  WORD flags;
  WORD table[2];       /* offset in 0, segment in 1 */
  WORD parm_block[2];
  WORD reserved[8];
} file_block;

struct xli_routine_struct {
  WORD select;
  WORD special_service;
  WORD ss_args[8];
  WORD reserved[8];
  WORD r_type;						/* return type two bytes */
  /* return value location 8 bytes */
  union xli_return {
	struct xli_string string;
	WORD *boolean;
	double stub;					/* eight byte filler */
  } r_val;
  /* XCALL arguments are here */
  char *lookup_word;
} p_block;

char table[] =
/*
   @@ The following string contains the names of the functions that can
   be called from within SCHEME when this file is loaded thru XLI.

   0	1   2	3   4	 5    6    7	 8   9	  10 11    12
*/
  "open-lex/close-lex/lookup//";


/*
   These functions take advantage of TURBO C's ability to have actual
   Assembly Code inline. _wait's purpose is to set up the stack, call the
   XLI function XWAIT, and upon returning pop the stack and return the
   value in AX which will either be non-zero or zero.
*/

int xli_wait(void)
{
   asm	push _psp
   asm	push _tsize
   asm	call dword ptr [xwait]
   asm	pop  ax
   asm	pop  ax
   return (_AX);
}

/* If xli_wait() returns zero, the while {} loop is terminated and this
   function is called, allowing XLI to clean up after us prior to the
   termination of Scheme.
*/
void xli_bye(void)
{
   asm	call dword ptr [xbye]
}

void main()
/*
  Within the main body of code the only portions that you will need to
  change are:
   1)  The value of the FILE-BLOCK.FLAGS and
   2)  The functions that you will call from within the CASE stmts.
*/
{
  WORD result;

  struct SREGS segregs;
  int xli_wait(void);
  void xli_bye(void);

  union {
	WORD far *psp_ptr;
	WORD p_array[2];
  }  p1;

  char the_word[MAX_WORD_LEN];

  p1.p_array[0] = 0;	  /* The offset and */
  p1.p_array[1] = _psp; /* segment address for the PSP. */

/*   The following code will initialize the File Block as needed. */

  file_block.id = 0x4252;
  file_block.flags = F_INT+F_NEAR;  /* @@ 16 bit integers */

  segread(&segregs); /* Get the register information */
  file_block.table[0] = (WORD) table;
  file_block.table[1] = segregs.ds;
  file_block.parm_block[0] = (WORD) &p_block;
  file_block.parm_block[1] = segregs.ds;

/* Establish the connection between C and the PSP. */

  p1.psp_ptr[46] = (WORD) &file_block; /* Set into the PSP the offset and */
  p1.psp_ptr[47] = segregs.ds;	       /* segment address of file_block */

  xwait[0] = p1.psp_ptr[5];   /* Store into XWAIT the offset and the */
  xwait[1] = p1.psp_ptr[6];   /* segment address of DOS's terminate routine.*/

  xbye[0] = xwait[0];  /* Copy the termination offset and */
  xbye[1] = xwait[1];  /* segment address from above into here. */

  xwait[0] += 3;   /* incr by 3 for normal call */
  xbye[0] += 6;    /* incr by 6 for termination */

  while (xli_wait()) {
	switch (p_block.select) {
	  case  0:	result = (WORD)open_lex ();
				p_block.r_val.boolean = &result;
				p_block.r_type = RT_BOOLEAN;
				break;
	  case  1:	result = (WORD)close_lex ();
				p_block.r_val.boolean = &result;
				p_block.r_type = RT_BOOLEAN;
				break;
	  case  2:  p_block.special_service = 1;	/* swap in string */
				p_block.ss_args[0] = 0;
                p_block.ss_args[1] = (int)MAX_WORD_LEN;
                p_block.ss_args[2] = (WORD)the_word;  /* len will be in */
				xli_wait();						/* ss_args[0] after call */
				the_word[p_block.ss_args[0]] = '\0'; 	/* null terminate string */
				p_block.r_val.string.post_list = look_up(the_word);
				p_block.r_val.string.post_len =
					strlen (p_block.r_val.string.post_list);
				p_block.r_type = RT_STRING;
				break;
	  case  3:
	  case  4:
	  case  5:
	  case  6:
	  case  7:
	  case  8:
	  case  9:
	  case 10:
	  case 11:
	  case 12:
	  default:  p_block.r_val.string.post_list = "XLI Error!";
				p_block.r_val.string.post_len =
					strlen (p_block.r_val.string.post_list);
				p_block.r_type = RT_STRING;
				break;
	} /* end switch */
  } /* end while */

  xli_bye();

} /* end main */
