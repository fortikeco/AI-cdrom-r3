/* 	lexicon.C -- lexical search utility for use with prebuilt dictionary
	2/10/93		Jim Rodlin
*/

#include <stdio.h>
#include <string.h>
#include "lexicon.h"			/* data structures for lexicon */
#include "btree.h"
#include "readwrit.c"			/* for index I/O */
#include "bt_utils.c"			/* for l/r_child() */

#define SCHEME_FALSE 0
#define SCHEME_TRUE 1
#define MAX_LIST_LEN 80

/* prototypes */
int seek (FILE *lexicon, FILE *index, int depth,
			Lex_Entry *entry, const char *word);
int get_lex_entry (FILE *lexicon, BT_rec location, Lex_Entry *entry);
int compare_lex_entry (const char *word, const Lex_Entry *entry);
void convert_lex_entry (const Lex_Entry *entry, char *post_list);
int stricmp(const char *s1, const char *s2);

/* globals */
char lexicon_filename[] = "lexicon.txt";
char index_filename[] = "index16.idx";
FILE *lexicon, *index;
int lex_depth, status;
Lex_Entry word_entry;


int open_lex (void) {

if ((lexicon = fopen (lexicon_filename, "r")) == NULL) {
	return (SCHEME_FALSE);
	}
if ((index = fopen (index_filename, "rb")) == NULL) {
	fclose (lexicon);
	return (SCHEME_FALSE);
	}
if ((lex_depth = index_depth (index)) == ERR) {
	fclose (lexicon);
	fclose (index);
	return (SCHEME_FALSE);
	}
return (SCHEME_TRUE);
}

int close_lex (void) {

fclose (lexicon);
fclose (index);
return (SCHEME_TRUE);
}

char *look_up (char *word) {

char post_list[MAX_LIST_LEN] = "";

status = seek (lexicon, index, lex_depth, &word_entry, word);
switch (status) {
	case TRUE:	convert_lex_entry (&word_entry, post_list);
				break;

	case FALSE: break;		/* no action if not found */

	case ERR:	break;

	default:	break;
	}
return (post_list);
}


/* Locate word in lexicon file and copy entry */
int seek (FILE *lexicon, FILE *index, int max_depth,
			Lex_Entry *entry, const char *word) {

long node_number = 1;
int current_depth = 0;
extern BT_rec BT_slug;			/* an empty node */
BT_rec record;
int status;

while (++current_depth <= max_depth) {	/* don't go past bottom of tree */
	/* find node */
	if ((status = position_index (index, node_number)) == ERR) {
		return (ERR);
		}
	/* get node record */
	if ((status = get_bt_rec (index, &record)) == ERR)
		return (ERR);
	/* check if empty */
	if (record == BT_slug)	/* empty node means word not in lexicon */
		return (FALSE);
	/* get the entry */
	if ((status = get_lex_entry (lexicon, record, entry)) == ERR) {
		return (ERR);
		}
	/* check for match */
	status = compare_lex_entry (word, entry);
	switch (status) {
		case LEX_MATCH:	return (TRUE);

		case LEX_LESS:	node_number = l_child (node_number);
						break;

		case LEX_MORE:	node_number = r_child (node_number);
						break;

		default:		return (ERR);
		}
	}		/* end while */

/* 	If we reach this point, we have hit the bottom of the B-Tree.
	Display a warning and return FALSE for no match.
*/
return (FALSE);
}


/* Given a file offset, read lexical entry into data structure */
int get_lex_entry (FILE *lexicon, BT_rec location, Lex_Entry *entry) {

char lex_data[MAX_ENTRY_LEN];
char *sp;
int c;

if (fseek (lexicon, location, SEEK_SET) != 0)
	return (ERR);
if (fscanf (lexicon, "%s", lex_data) != 1)
	return (ERR);

/* 	Get information from data record. Structure as follows:
	Byte	Format			Meaning
	0		char			part of speech (see key)
	1		char 0/1		participle flag
	2		char 0/1		negative flag
	3		char 0/1		infinitive flag
	4		char 0/1		gerund flag
	5		char 0/1		auxiliary flag
	6-25	string			the word
*/
entry->speech = lex_data[0];
/* scan through five flags */
c = 0;
for (sp = lex_data + 1; sp < &lex_data[6]; ++sp)
	entry->flags[c++] = *sp;
/* now sp points to the word entry */
strncpy(entry->word, sp, MAX_WORD_LEN - 1);

return (OK);
}


/* 	lexicographically compare word from lexical entry to string and
	return results of comparison */
int compare_lex_entry (const char *word, const Lex_Entry *entry) {

int compare;

compare = stricmp (word, entry->word);
if (compare == 0)
	return (LEX_MATCH);
if (compare < 0)           	/* user word precedes current entry */
	return (LEX_LESS);
return (LEX_MORE);			/* user word follows entry */
}


/* 	Convert lexical entry to POST string. Parts of speech follow:
	Key:	J adjective	j adj/verb	A adverb	a adv/verb	B article
			C conjunct	I interjec	N noun		d noun/adj	n noun/verb
			P preposit	O pronoun	V verb		q poss/pron	o adj/pron
			Q pos-pron	p prep/adv	X 'not'

*/
void convert_lex_entry (const Lex_Entry *entry, char *post_list) {

switch (entry->speech) {
	case 'J': 	strcpy (post_list, "ADJEC");	break;
	case 'j':   strcpy (post_list, "ADJEC VERB");	break;
	case 'A':   strcpy (post_list, "ADV");	break;
	case 'a':   strcpy (post_list, "ADV VERB");	break;
	case 'B':   strcpy (post_list, "DET");	break;
	case 'C':   strcpy (post_list, "CONJ");	break;
	case 'I':   strcpy (post_list, "INTJ");	break;
	case 'N':   strcpy (post_list, "NOUN");	break;
	case 'd':   strcpy (post_list, "NOUN ADJEC");	break;
	case 'n':   strcpy (post_list, "NOUN VERB");	break;
	case 'P':   strcpy (post_list, "PREP");	break;
	case 'O':   strcpy (post_list, "PRON");	break;
	case 'V':   strcpy (post_list, "VERB");	break;
	case 'q':   strcpy (post_list, "PRON");	break;
	case 'o':   strcpy (post_list, "ADJEC PRON");	break;
	case 'Q':   strcpy (post_list, "PRON");	break;
	case 'p':   strcpy (post_list, "PREP ADV");	break;
	case 'i':	strcpy (post_list, "PREP INF"); break;
	default:    break;		/* ignore unknown cases */
	}

if (entry->flags[4] == '1')
	strcat (post_list, " AUX-V");

return;
}


