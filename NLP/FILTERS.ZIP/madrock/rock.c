/*---------------------------------------------------------------
	      C implementation of MAD magazine's

		ALL-INCLUSIVE DO-IT-YOURSELF
		       ROCK CONCERT
		      Newspaper Story

			  by

		  satyr@ucscb.ucsc.edu			1987
------------------------------------------------------------------*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#define when break;case

main ()
{
	char *w1, *w2, *w3, *w4, *w5;
	char *w6, *w7, *w8, *w9, *w10;
	char *w11, *w12, *buf;
	int  flag=0, mark, x, i;

/*    srand(56);*/
	randomize();

	buf = malloc(BUFSIZ);

	switch (rand() % 12)
	{
		case 0 : sprintf(buf, "Thousands of");
		when 1 : sprintf(buf, "Millions of");
		when 2 : sprintf(buf, "Hundreds of");
		when 3 : sprintf(buf, "Several");
		when 4 : sprintf(buf, "Uncounted millions of");
	 	when 5 : sprintf(buf, "Fourteen");
		when 6 : sprintf(buf, "A huge number of");
		when 7 : sprintf(buf, "Billions of");
		when 8 : sprintf(buf, "Seven and a half");
		when 9 : sprintf(buf, "Many");
		when 10 : sprintf(buf, "Quite a few");
		when 11 : sprintf(buf, "More than one");
		break;
	}
	strcat(buf, " ");

	switch (rand() % 12)
	{
		case 0 : strcat(buf, "screaming");
		when 1 : strcat(buf, "ripped-off");
		when 2 : strcat(buf, "born-again");
		when 3 : strcat(buf, "Bloom County");
		when 4 : strcat(buf, "suicidal");
	 	when 5 : strcat(buf, "toxic");
		when 6 : strcat(buf, "whacked-out");
		when 7 : strcat(buf, "slightly used");
		when 8 : strcat(buf, "pregnant");
		when 9 : strcat(buf, "molting");
		when 10 : strcat(buf, "frigid");
		when 11 : strcat(buf, "calcium deficient");
		break;
	}

	strcat(buf, " ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf, "rock fans");
		when 1 : strcat(buf, "teenagers");
		when 2 : strcat(buf, "marmot-breeders");
		when 3 : strcat(buf, "Sandanistas");
		when 4 : strcat(buf, "Bob Uecker look-alikes");
	 	when 5 : strcat(buf, "boat people");
		when 6 : strcat(buf, "amnesiacs");
		when 7 : strcat(buf, "Trivial Pursuit players");
		when 8 : strcat(buf, "owl worshippers");
		when 9 : strcat(buf, "bed-wetters");
		when 10 : strcat(buf, "Delorean dealers");
		when 11 : strcat(buf, "soothsayers");
		break;
	}
	strcat(buf, " packed ");

	switch (rand() % 12)
	{
		case 0 : strcat(buf, "the City Auditorium");
		when 1 : strcat(buf, "the Kingdome");
		when 2 : strcat(buf, "Bernie's Car Wash");
		when 3 : strcat(buf, "St Patrick's Cathedral");
		when 4 : strcat(buf, "the Oval Office");
	 	when 5 : strcat(buf, "Buddy Hackett's hot tub");
		when 6 : strcat(buf, "the Australian outback");
		when 7 : strcat(buf, "a new Honda Civic");
		when 8 : strcat(buf, "Ted and Rita's family room");
		when 9 : strcat(buf, "the K Mart linens section");
		when 10 : strcat(buf, "Lake Huron");
		when 11 : strcat(buf, "the Exit 17 offramp");
		break;
	}

	strcat(buf, " last night to see ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf, "the Jacksons");
		when 1 : strcat(buf, "Van Halen");
		when 2 : strcat(buf, "Boy George");
		when 3 : strcat(buf, "the Little Rascals");
		when 4 : strcat(buf, "Kate and Allie");
	 	when 5 : strcat(buf, "Botswana wife-swappers");
		when 6 : strcat(buf, "the Dallas Mavericks");
		when 7 : strcat(buf, "Mr T's caterer");
		when 8 : strcat(buf, "the Miss Bulgaria finalists");
		when 9 : strcat(buf, "the last Civil War veteran");
		when 10 : strcat(buf, "Casper Weinberger");
		when 11 : strcat(buf, "a KGB double agent");
		break;
	}
	strcat(buf, " in concert.  Many fans ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf, "stood in line");
		when 1 : strcat(buf, "counted their toes");
		when 2 : strcat(buf, "shouted pygmy oaths");
		when 3 : strcat(buf, "chanted \"DEE-fense!\"");
		when 4 : strcat(buf, "aged prematurely");
	 	when 5 : strcat(buf, "licked Snickers wrappers");
		when 6 : strcat(buf, "donned wet suits");
		when 7 : strcat(buf, "polished their nose-rings");
		when 8 : strcat(buf, "wept openly");
		when 9 : strcat(buf, "broke wind");
		when 10 : strcat(buf, "swapped zip codes");
		when 11 : strcat(buf, "fondled their ear lobes");
	}

	strcat(buf, " for more than ten hours while waiting to ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf, "pay $30");
		when 1 : strcat(buf, "sell their sisters");
		when 2 : strcat(buf, "grovel shamelessly");
		when 3 : strcat(buf, "lose their virginity");
		when 4 : strcat(buf, "renounce Satan");
	 	when 5 : strcat(buf, "give up breathing");
		when 6 : strcat(buf, "sacrifice a beagle");
		when 7 : strcat(buf, "betray their scoutmaster");
		when 8 : strcat(buf, "sell their vital organs");
		when 9 : strcat(buf, "give up their citizenship");
		when 10 : strcat(buf, "pawn their phony Omegas");
		when 11 : strcat(buf, "change their sex");
		break;
	}

	strcat(buf, " for a ticket.  Despite ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf, "a few outbreaks of");
		when 1 : strcat(buf, "the usual");
		when 2 : strcat(buf, "some harmless");
		when 3 : strcat(buf, "post-Olympic");
		when 4 : strcat(buf, "sloppy attempts at");
	 	when 5 : strcat(buf, "authentic Haitian");
		when 6 : strcat(buf, "precision drill");
		when 7 : strcat(buf, "the romantic lure of");
		when 8 : strcat(buf, "the Reagan Cabinet's");
		when 9 : strcat(buf, "some very creative");
		when 10 : strcat(buf, "the lethal effects of");
		when 11 : strcat(buf, "the distinctive odor of");
		break;
	}
	strcat(buf, " ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf, "rioting");
		when 1 : strcat(buf, "terrorism");
		when 2 : strcat(buf, "drunkenness");
		when 3 : strcat(buf, "car-stripping");
		when 4 : strcat(buf, "pillaging");
	 	when 5 : strcat(buf, "nude break-dancing");
		when 6 : strcat(buf, "possum worship");
		when 7 : strcat(buf, "Karl Malden impersonations");
		when 8 : strcat(buf, "silicone rejection");
		when 9 : strcat(buf, "out-of-body retching");
		when 10 : strcat(buf, "estate planning");
		when 11 : strcat(buf, "parakeet training");
		break;
	}

	strcat(buf, " and the occasional ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf, "arrest");
		when 1 : strcat(buf, "flogging");
		when 2 : strcat(buf, "hearing loss");
		when 3 : strcat(buf, "death screams");
		when 4 : strcat(buf, "melt-down");
	 	when 5 : strcat(buf, "spraying");
		when 6 : strcat(buf, "flossing");
		when 7 : strcat(buf, "glassy-eyed stares");
		when 8 : strcat(buf, "pre-soaking");
		when 9 : strcat(buf, "poor penalty-killing");
		when 10 : strcat(buf, "factory recall");
		when 11 : strcat(buf, "painless removal");
		break;
	}
	strcat(buf, " of ");

	switch (rand() % 12)
	{
		case 0 : strcat(buf,  "unruly");
		when 1 : strcat(buf,  "off-duty");
		when 2 : strcat(buf,  "stoned");
		when 3 : strcat(buf,  "pre-Columbian");
		when 4 : strcat(buf,  "singles-bar");
	 	when 5 : strcat(buf,  "fur-bearing");
		when 6 : strcat(buf,  "Lucasfilm");
		when 7 : strcat(buf,  "Libyan-backed");
		when 8 : strcat(buf,  "reincarnated");
		when 9 : strcat(buf,  "moss-covered");
		when 10 : strcat(buf,  "cutesy-pie");
		when 11 : strcat(buf,  "splattered");
		break;
	}
	strcat(buf, " ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf, "punks");
		when 1 : strcat(buf, "drug dealers");
		when 2 : strcat(buf, "Sagittarians");
		when 3 : strcat(buf, "nerds");
		when 4 : strcat(buf, "welfare cheats");
	 	when 5 : strcat(buf, "Unitarians");
		when 6 : strcat(buf, "surfers");
		when 7 : strcat(buf, "mercenaries");
		when 8 : strcat(buf, "Cornhuskers");
		when 9 : strcat(buf, "skycaps");
		when 10 : strcat(buf, "Munchkins");
		when 11 : strcat(buf, "centerfolds");
		break;
	}
	
	strcat(buf, ", the promoters of the event called it ");
	switch (rand() % 12)
	{
		case 0 : strcat(buf,  "an unqualified success.");
		when 1 : strcat(buf,  "a victory for good taste.");
		when 2 : strcat(buf,  "more fun than Pearl Harbor.");
		when 3 : strcat(buf,  "a vindication of greed.");
		when 4 : strcat(buf,  "proof of God's love.");
	 	when 5 : strcat(buf,  "an incredible waste of time.");
		when 6 : strcat(buf,  "as significant as Flag Day.");
		when 7 : strcat(buf,  "a triumph for Jerry Falwell.");
		when 8 : strcat(buf,  "a glorification of self-abuse.");
		when 9 : strcat(buf,  "as memorable as 'Lottery'.");
		when 10 : strcat(buf,  "a festival for degenerates.");
		when 11 : strcat(buf,  "an answer for Communism.");
		break;
	}

	printf("                         MAD Magazine\n");
	printf("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n");
	printf("                    ROCK CONCERT LAST NIGHT\n\n");

		/* this is gross, dont look */
	x = 70;
	mark = 0;
gack:	
	if (!flag)
		if (buf[x] != ' ')
			while (buf[x--] != ' ')
				;

	for (i=mark;i<x+1;i++) {
		if ( (mark == i) && (buf[i] == ' ') ) continue;
		putchar(buf[i]);
	}
	putchar('\n');

	if (flag)
	 	putchar('\n'), exit(0);

	mark = x + 1;
	x = mark + 71;
	if (x >= strlen(buf)) {
		x = strlen(buf);
		flag++;
	}
	goto gack;


	for (i=0;i<BUFSIZ;i++) {
		if ( ((i % 72) == 0) && (buf[i] == ' ') ) continue;
		putchar(buf[i]);
		if ( (i != 0) && ((i % 71) == 0) )
			putchar('\n');
	}
	putchar('\n');
}
