#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/time.h>

/*
 * Copyright?  Hell, if asked, I'll deny I even wrote this bit of trash.
 */

typedef struct Words {
    char *word;
    int visited;
    int nfollows;
    int *counts;
    int class;
    struct Words **follows;
    struct Words *before;
    struct Words *after;
} Words;

enum { FullStop, Punct, Word };

char *fetchWord();
Words *addWord( Words **, char * );
Words *newWord( char * );
void erisify( Words *, long, long );
void setup();
void tally( Words *, Words * );
void search( long, Words * );
Words *chase( Words *, long * );
void fsort( Words * );
Words *findNewWord( Words * );

int wordcount = 0;

int tgrid[128] = { 0 };
FILE *f;

int main( int argc, char **argv )

{

    char *word;
    Words *w = ( Words *) NULL;
    Words *last;

    setup();

    last = addWord( &w, fetchWord() );
    while ( word = fetchWord() ) {

	Words *wd;

	wd = addWord( &w, word );
	tally( last, wd );
	last = wd;

    }	

    srandom( ( int ) time( ( time_t *) NULL ) );

    erisify( w, ( random() % 10 ) + 1, random() % wordcount );

    exit( 0 );

}

void setup()

{

    tgrid['@'] = 1;
    tgrid['#'] = 1;
    tgrid['$'] = 1;
    tgrid['%'] = 1;
    tgrid['^'] = 1;
    tgrid['&'] = 1;
    tgrid['*'] = 1;
    tgrid['('] = 1;
    tgrid[')'] = 1;
    tgrid['_'] = 1;
    tgrid['-'] = 1;
    tgrid['='] = 1;
    tgrid['+'] = 1;
    tgrid['|'] = 1;
    tgrid['\\'] = 1;
    tgrid['`'] = 1;
    tgrid['~'] = 1;
    tgrid['['] = 1;
    tgrid[']'] = 1;
    tgrid['{'] = 1;
    tgrid['}'] = 1;
    tgrid[':'] = 1;
    tgrid[';'] = 1;
    tgrid['\"'] = 1;
    tgrid['<'] = 1;
    tgrid['>'] = 1;
    tgrid['/'] = 1;

}

char *fetchWord()

{

    static char text[30];
    int ch;
    int tp = 1;
    char *txt;

    while ( ( ( ch = getchar() ) != EOF ) && 
	    ( ( isspace( ch ) || 
	        isdigit( ch ) ||
	        tgrid[ch] ) ) )
	;

    if ( ch != EOF ) {

	text[0] = ch;
	if ( !ispunct( ch ) ) {

	    while ( ( ( isalnum( text[tp] = getchar() ) ) ||
		     ( text[tp] == '\'' ) ) && ( tp < 30 ) )
		tp++;
		
	    if ( ( text[0] != 'M' ) || 
		 ( text[1] != 'r' ) ||
		 ( text[2] != '.' ) )
		ungetc( text[tp], stdin );
	    else
		tp++;

	}
	
	text[tp] = '\0';
	
	txt = text;

    } else
	txt = ( char *) NULL;

    return txt;

}

Words *addWord( Words **w, char *word )

{

    Words *nw;

    if ( !*w )
	*w = nw = newWord( word );
    else {

	int s = strcmp( ( *w )->word, word );

	if ( s < 0 )
	    nw = addWord( &( *w )->after, word );
	else if ( s > 0 )
	    nw = addWord( &( *w )->before, word );
	else
	    nw = *w;

    }

    return nw;

}

Words *newWord( char *word )

{

    static int left = 0;
    static Words *w;
    
    wordcount++;
    if ( !left )
	w = ( Words *) calloc( sizeof( Words ), left = 32768 );

    left--;
    ( w + left )->word = strdup( word );
    switch ( *word ) {

      case '!':
      case '?':
      case '.': {

	  ( w + left )->class = FullStop;
	  break;

      }
      default: {

	  ( w + left )->class = ispunct( *word ) ? Punct : Word;
	  break;

      }

    }

    return ( w + left );

}

void tally( Words *last, Words *wd )

{

    int i;

    for ( i = 0; i < last->nfollows; i++ )
	if ( strcmp( last->follows[i]->word, wd->word ) == 0 ) {

	    ( *( last->counts + i ) )++;
	    return;

	}

    if ( last->nfollows ) {

	last->follows = ( Words **) realloc( last->follows, sizeof( Words *) *
					    ( last->nfollows + 1 ) );
	
	last->counts = ( int *) realloc( last->counts, sizeof( int ) *
					( last->nfollows + 1 ) );
	
    } else {

	last->follows = ( Words **) malloc( sizeof( Words *) *
					    ( last->nfollows + 1 ) );
	
	last->counts = ( int *) malloc( sizeof( int ) *
					( last->nfollows + 1 ) );

    }
    *( last->follows + last->nfollows ) = wd;
    *( last->counts + last->nfollows ) = 1;
    last->nfollows++;

}

void erisify( Words *w, long paragraphs, long start )

{

    Words *lastword = chase( w, &start );
    int count = 0;
    int paralen = ( random() % 5 ) + 1;
    int capitalize = 1;

    fsort( lastword );

    printf( ".PP\n" );
    do {

	Words *theword;

	if ( lastword->nfollows && ( lastword->class != FullStop ) )
	    theword = findNewWord( lastword );
	else
	    do {

		long where = random() % wordcount;

		fsort( theword = chase( w, &where ) );

	    } while ( theword->class != Word );
	
	if ( capitalize )
	    printf( "%c%s", toupper( *( lastword->word ) ), 
		                      ( lastword->word + 1 ) );
	else
	    printf( "%s", lastword->word );

	if ( random() % 200 == 0 )
	    printf( " fnord" );
	if ( ( theword->class != Punct ) &&
	     ( theword->class != FullStop ) &&
	     ( lastword->class != FullStop ) )
	    printf( " " );
	if ( !( ++count % 5 ) && 
	      ( theword->class != Punct ) &&
	      ( theword->class != FullStop ) &&
	      ( lastword->class != FullStop ) )
	    printf( "\n" );

	if ( lastword->class == FullStop ) {

	    printf( "\n" );
	    if ( !( --paralen ) ) {

		printf( ".PP\n" );
		count = 0;
		paralen = ( random() % 5 ) + 1;
		--paragraphs;

	    }

	}
	capitalize = lastword->class == FullStop;
	fsort( lastword = theword );

    } while ( paragraphs );

}

Words *chase( Words *w, long *count )

{

    Words *wd;

    if ( w->before )
	wd = chase( w->before, count );
    if ( *count ) {

	if ( --( *count ) == 0 )
	    wd = w;
	else if ( w->after )
	    wd = chase( w->after, count );

    }

    return wd;

}

void fsort( Words *w )

{

    if ( !w->visited && w->nfollows ) {

	int i;
	int wsum;

	for ( i = 0; i < w->nfollows - 1; i++ ) {

	    int j;

	    for ( j = i + 1; j < w->nfollows; j++ ) {

		if ( w->counts[i] < w->counts[j] ) {

		    int temp = w->counts[i];
		    Words *wtemp = w->follows[i];

		    w->counts[i] = w->counts[j];
		    w->follows[i] = w->follows[j];
		    
		    w->counts[j] = temp;
		    w->follows[j] = wtemp;

		}

	    }

	}

	wsum = w->counts[0];
	for ( i = 1; i < w->nfollows; i++ ) {

	    wsum += w->counts[i];
	    w->counts[i] = wsum;

	}
	w->visited = wsum;

    }

}

Words *findNewWord( Words *w )

{

    if ( w->visited ) {

	int rnum = random() % w->visited;
	int i;

	for ( i = 0; i < w->nfollows - 1; i++ )
	    if ( w->counts[i] > rnum )
		break;
	
	return w->follows[i];

    }

}
