/***************************************************************************/
/**                                                                       **/
/** : ogrify.c                                                            **/
/** : Version 2.0                                                         **/
/**                                                                       **/
/** : This is a souped-up version of the original ogrify.c posted to the  **/
/**   rec.music.industrial newsgroup.  It contains several new features   **/
/**   as well as sane argument parsing.                                   **/
/**                                                                       **/
/** : v 2.0 - by Morpheus, Friday March 13th, 1992                        **/
/**         - major rewrite                                               **/
/**         - added -p (allow punctuation), -number (probability),        **/
/**           -lnumber (line length), -u (upper-case), and -n (no         **/
/**           character case-switching) switches.                         **/
/**                                                                       **/
/***************************************************************************/
 
/** Header files. **/
#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include <malloc.h>
 
/** Define constants. **/
#define NOMANGLE 0x01           /* Allow punctuation.           */
#define NOLOWER  0x02           /* Use lowercase only.          */
#define NOCHANGE 0x04           /* Don't change capitalization. */
 
int main( argc, argv )
unsigned   argc;
char     **argv;
{
    FILE *fp;
 
    char   lett,                /* A letter.                          */
           line[80],            /* A line.                            */
           word[80],            /* A word.                            */
          *ogre,                /* Ogre words database filename.      */
          *lyric,               /* Pointer to a lyric.                */
         **lyrics;              /* Pointer to the list of ogre words. */
 
    int prob,                   /* The probability of changing a word.  */
        linelen,                /* The char length of a line.           */
        switches,               /* Punctuation and capitalization bits. */
        len,                    /* Length of a string.                  */
        lines,                  /* Number of lines in the ogre words.   */
        loop;                   /* A loop index.                        */
 
    /* Initialize our variables to the defaults. */
    prob     = 5;
    linelen  = 40;
    switches = 0;
    len      = 0;
    lines    = 0;
    loop     = 0;
 
    for( loop = 0; loop < 80; loop++ )
        line[loop] = word[loop] = 0x00;
        
    /* Seed the random number generator. */
    srand( (unsigned)time( NULL ) );
 
    /* Parse the argument list. */
    for( loop = 1; loop < argc; loop++ )
    {
        if( argv[loop][0] == '-' )
            switch( argv[loop][1] )
            {
                case '?':
                case 'h':
                case 'H':
           puts( "Usage: ogrify [ogre.words] [-p] [-lnnn] [-nnn] [-u] [-n]" );
                    puts( "       ogre.words - Ogre words database." );
                    puts( "       -p         - Leave punctuation alone." );
                    puts( "       -lnnn      - Set line width to nnn." );
                puts( "       -nnn       - Set the Ogre probability to nnn.");
             puts( "       -u         - Change the characters to upper-case." );
 puts( "       -n         - Leave punctuation/character-case alone." );
                    return( 0 );
                    break;
 
                case 'p':
                case 'P':
                    switches |= NOMANGLE;
                    break;
 
                case 'l':
                case 'L':
                    if( argv[loop][2] == 0x00 )
                        linelen = atoi( argv[++loop] );
                    else
                        linelen = atoi( &(argv[loop][2]) );
 
                    if( linelen < 1 )
                    {
                        printf( "ogrify: bad line length of %d\n", linelen );
                        return( -1 );
                    }
                    break;
 
                case 'u':
                case 'U':
                    switches |= NOLOWER;
                    break;
 
                case 'n':
                case 'N':
                    if( switches & NOLOWER )
                    {
                        puts( "ogrify: can't have -u and -n" );
                        return( -1 );
                    }
                    switches |= NOCHANGE;
                    break;
 
               default:
                    if( isdigit( argv[loop][1] ) )
                    {
                        prob = atoi( &(argv[loop][1]) );
 
                        if( prob < 0 || prob > 100 )
                        {
                            printf( "ogrify: bad probability of %d\n", prob );
                            return( -1 );
                        }
                    }
                    else
                    {
                        printf( "ogrify: unknown option \"%s\"\n", argv[loop] );
                        return( -1 );
                    }
                    break;
            }
        else
            /* Save the name of the ogre words file. */
            ogre = argv[loop];
    }    
 
    /* Read the ogre words database if one has been specified. */
    fp = fopen( ogre, "r" );
    if( fp == NULL )
    {
        printf( "ogrify: unable to open \"%s\"\n", ogre );
        return( -1 );
    }
    else
    {
        /* Load the Ogre words... */
        lyrics = (char **)malloc( 1 );
        if( lyrics == NULL )
        {
            puts( "ogrify: unable to allocate buffer" );
            fclose( fp );
            return( -1 );
        }
        
        while( fgets( line, 80, fp ) != NULL )
        {
            len = strlen( line );
            if( len )
            {
                if( switches & NOLOWER )
                    for( loop = 0; loop < len; loop++ )
                        line[loop] = toupper( line[loop] );
                else        
                    if( switches & ~NOCHANGE )
                        for( loop = 0; loop < len; loop++ )
                            line[loop] = tolower( line[loop] );
 
                line[len - 1] = ' ';
 
                lyric = (char *)malloc( ( len + 1 ) * sizeof( char ) );
                if( lyric == NULL )
                {
                    puts( "ogrify: unable to allocate memory" );
                    fclose( fp );
                    return( -1 );
                }
 
                strcpy( lyric, line );
 
                lyrics = (char **)realloc( lyrics, ++lines * sizeof( ogre ) );
 
                if( lyrics == NULL )
                {
                    puts( "ogrify: unable to reallocate memory" );
                    fclose( fp );
                    return( -1 );
                }
                lyrics[lines - 1] = lyric;
            }
        }
        fclose( fp );
    }
 
    /* Ogrify the text... */
    len  = 0;
    loop = 0;
    while( ( lett = getc( stdin ) ) != EOF )
    {
        if( isspace( lett ) )
        {
            if( word[0] == '\0' )
                continue;
 
            if( lines && ( rand() % 100 < prob ) )
                lyric = lyrics[rand() % lines];
            else
            {
                word[loop++] = ' ';
                word[loop++] = '\0';
                lyric = word;
            }
 
            len += strlen( lyric );
 
            if( len > linelen )
            {
                fprintf( stdout, "\n" );
                len = strlen( lyric );
            }
            
            if( lyric[0] != ' ' )
                fputs( lyric, stdout );
 
            loop = 0;
            word[0] = '\0';
        }
        else
            if( ispunct( lett ) )
                if( switches & ( NOMANGLE | NOCHANGE ) )
                    word[loop++] = lett;
                else
                    continue;
            else
                if( switches & NOLOWER )
                    word[loop++] = toupper( lett );
                else
                    if( switches & NOCHANGE )
                        word[loop++] = lett;
                    else
                        word[loop++] = tolower( lett );
    }
 
    fprintf( stdout, "\n" );
    
    return( 0 );
}
