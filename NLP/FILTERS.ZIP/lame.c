/*
 *  The Lame Filter            Version 1.5
 *  for IRC:  /alias l /exec -out lame "$0- 
 *
*/

#include <stdio.h>
#include <ctype.h>

main(argc, argv)
int argc;
char *argv[];
{
int i, j, count;
char buf[1000], out[1000];
     for(i=1; i<argc; i++) {
	    count=0;
            sprintf(buf, "%s", argv[i]);

            for(j=0; j<strlen(buf); j++) {
		if( buf[j]=='y' && buf[j+1]=='o' && buf[j+2]=='u') {
		    out[count++]='U'; j+=2;
                }
		else if( buf[j]=='o' || buf[j]=='O') {
                      if( rand()%3==1 ) {
                        out[count++]='('; out[count++]=')';
                      } else out[count++]='0';
                }
                else if( buf[j]=='a' && buf[j+1]=='n' && buf[j+2]=='d') { 
                      out[count++]='&'; j+=2; 
                }  
		else if((buf[j]=='i' || buf[j]=='I')&&(rand()%5>=2)) {
                      out[count++]='1';
                }
		else if( buf[j]=='l' && (rand()%3==1)) {
                    out[count++]='|';
                }
                else if(buf[j]=='s'&&(buf[j+1]=='\0'||ispunct(buf[j+1]))){ 
                  out[count++]='z'; out[count++]='z';
                }  
                else if( (buf[j]=='e' || buf[j]=='E') &&(rand()%5 >= 3) ) {
                  out[count++]='3';
                } 	
                else if( rand()%5==1 ) out[count++]=toupper(buf[j]);
                else out[count++]=buf[j];
             }
             out[count]='\0';
             printf("%s ",out); 
     }
     printf("\n"); 
}


