#include <stdio.h>
/*
main()
{
char buffer[200];

        gets(buffer);
        wrap_puts(buffer);
}
*/
#define endcol 75 

wrap_puts(string)
char *string;
{
char *ps,*psp;
int counter; 

        ps = psp = string;
        counter = 0;
        for(;;)
        {
                while( (*psp != ' ') && (*psp != '\0') )
                {
                        psp++;
                        counter++;
                }
                counter++;

                if(counter > endcol)
                {
                        putchar('\n');
                        ps++;
                        counter = 0;
                }
                else
                        counter++;

                while(ps != psp)
                        putchar(*ps++);
                
                if(*psp == '\0')
                        break;

                psp++;
        }
        putchar('\n');
}
