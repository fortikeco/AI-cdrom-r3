#include <stdio.h>
#include <ctype.h>
#include <string.h>

extern long time();
extern char *index();
extern void srand();

#define first 1
#define second 2

char *_article[]={
        "the ",
        "a ",
        "this ",
        "that ",
        "each "
};

char *_connect[]={
        "and ",
        "if it ",
        "or ",
        "unless it ",
        "until it ",
        "before it "
};

char *_join[]= {
        "while ",
        "because ",
        "although ",
        "even though ",
        "despite the fact that ",
        "for the simple reason that ",
        "because ",
        "due to the fact that ",
        "since ",
        "whether or not ",
        "inasmuch as ",
        "as "
};

char *_pronoun[]={
        "alternate ",
        "first ",
        "large ",
        "limited ",
        "long ",
        "second ",
        "serious ",
        "simple ",
        "subsequent ",
        "third ",
        "unusable ",
        "one-time ",
        "add-back ",
        "city, state or local ",
        "minimum ",
        "maximum ",
        "qualified ",
        "exempt ",
        "appropriate ",
        "real ",
        "authorized ",
        "requested ",
        "nonresident "
};

char *_noun[]={
        "deduction ",
        "accumulation distribution credit ",
        "addition ",
        "adjustment ",
        "amended return ",
        "amortization ",
        "amount owed ",
        "basis ",
        "beneficiary ",
        "business income ",
        "deduction ",
        "dependant ",
        "depletion ",
        "depreciation ",
        "education expense ",
        "estate ",
        "trust ",
        "estimated tax ",
        "exemption ",
        "family adjustment ",
        "gift for wildlife ",
        "house-hold credit ",
        "investment credit ",
        "retail enterprise credit ",
        "refund ",
        "lump sum distribution ",
        "maximum tax on personal service income ",
        "minimum income tax ",
        "new business investment ",
        "deferral ",
        "exclusion ",
        "overpayment ",
        "partner ",
        "payment ",
        "penalty and interest ",
        "pension and annuity income ",
        "real property tax credit ",
        "research and development credit ",
        "resident credit ",
        "retail enterprise credit ",
        "seperate tax ",
        "tuition deduction ",
        "group term life insurance policy ",
        "package ",
        "solar and wind energy credit "
};

char *_prep[]={
        "across ",
        "by ",
        "in ",
        "near ",
        "under ",
        "over ",
        "in back of ",
        "below ",
        "behind ",
        "connected with ",
        "centered around ",
        "centered about ",
        "in close proximity to ",
        "following after ",
        "in between ",
        "in conflict with ",
        "in conjunction with ",
        "in the area of ",
        "in the neighborhood of ",
        "in the proximity of ",
        "in the field of ",
        "for the purpose of ",
        "giving rise to ",
        "based upon ",
        "being caused by ",
        "being used with ",
        "being collected together with ",
        "being combined together with ",
        "connected up to ",
        "exhibiting a tendency towards ",
        "being facilitated by ",
        "being employed with ",
        "having a deleterious effect upon ",
        "impacting ",
        "being joined together with ",
        "being merged together with ",
        "in the vicinity of ",
        "above ",
        "across from ",
        "along ",
        "among ",
        "beneath ",
        "between ",
        "beyond ",
        "by ",
        "covering ",
        "enclosing ",
        "for ",
        "from ",
        "in ",
        "inside ",
        "inbetween ",
        "joining ",
        "opposite ",
        "outside ",
        "over ",
        "under ",
        "with " };

char *_adverb[]= {
        "that ",
        "which "
};

char *_verb[]={
        "applies ",
        "collects ",
        "deducts ",
        "distributes ",
        "enters ",
        "exempts ",
        "figures ",
        "files ",
        "has ",
        "keeps ",
        "refunds ",
        "receives ",
        "subtracts ",
        "signs ",
        "states ",
        "with-holds ",
        "multiplies ",
        "adds ",
        "subtracts ",
        "divides ",
        "pays ",
        "enjoins ",
        "makes ",
        "obtains ",
        "recovers ",
        "exempts ",
        "expects ",
        "computes ",
        "changes ",
        "debits ",
        "credits ",
        "produces ",
        "develops ",
        "invents ",
        "claims ",
        "checks ",
        "qualifies ",
        "removed ",
        "ends ",
        "retires ",
        "chooses ",
        "seperates ",
        "trusts ",
        "invests ",
        "looses ",
        "buys ",
        "sells "
};

char buffer[3000];
int _rflag = first;
int connectflag = 0;


taxlaw()
{
        char *pb = buffer;
        _taxlaw();
        *(pb + strlen(buffer)-1) = '\0';
        strcat(buffer, ".\n");
        *pb = _toupper(*pb);
        wrap_puts(buffer);
        _rflag = first;
        connectflag = 0;
}

_taxlaw()
{
        static int _time = first;
        char *pick();
        int whichflag = 0;
        char bullbuf[80];

        if(strlen(buffer) > 2998)
        {
#ifdef EBUG
                printf("buffer overflow");
#endif
                return;
        }

        if(_rflag == first)
        {
                buffer[0] = '\0';
                _rflag = second;
                setbuf(stdout, NULL);
        }

        if(_time == first)
        {
                srand( (unsigned)time( (long *)0 ) );
                _time = second;
        }

        for(;;)
        {
                while(rnd(10) > 4)
                {
                        strcat(buffer, pick(_article,sizeof(_article),1));
                        while(rnd(3) == 1)
                                strcat(buffer, pick(_pronoun,sizeof(_pronoun),0));
                        strcat(buffer, pick(_noun,sizeof(_noun),0));
                        strcat(buffer, pick(_prep,sizeof(_prep),0));
                }
                strcat(buffer, pick(_article,sizeof(_article),1));
                while(rnd(3) == 1)
                        strcat(buffer, pick(_pronoun,sizeof(_pronoun),0));
                strcat(buffer, pick(_noun,sizeof(_noun),0));
                if(rnd(8)==1)
                {
                        strcat(buffer, pick(_adverb,sizeof(_adverb),1));
                        whichflag = 1;
                }
                strcat(buffer, pick(_verb,sizeof(_verb),0));
                strcat(buffer, pick(_article,sizeof(_article),1));
                while(rnd(3) == 1)
                        strcat(buffer, pick(_pronoun,sizeof(_pronoun),0));
                strcat(buffer, pick(_noun,sizeof(_noun),0));
                if(rnd(10) > 4)
                {
                        sprintf(bullbuf,"(See sect. &%d, para. %d) ",rnd(80),rnd(999));
                        strcat(buffer,bullbuf);
                }

                if(rnd(10) >= 7)
                {
                        strcat(buffer,pick(_join,sizeof(_join),0));
#ifdef EBUG
                        puts("beginning recursion");
#endif
                        _taxlaw();
#ifdef EBUG
                        puts("ending recursion");
#endif
                        strcat(buffer,pick(_join,sizeof(_join),0));
                        connectflag = 1;
                }
                else
                        break;
        }
        if(whichflag)
        {
                if(connectflag)
                        strcat(buffer, pick(_connect,sizeof(_connect),1));
                else
                        connectflag = 1;
                strcat(buffer, pick(_verb,sizeof(_verb),0));
                strcat(buffer, pick(_article,sizeof(_article),1));
                while(rnd(3) == 1)
                        strcat(buffer, pick(_pronoun,sizeof(_pronoun),0));
                strcat(buffer, pick(_noun,sizeof(_noun),0));
                whichflag = 0;
        }

}

char *pick(tokenbuf,size,flag)
char *tokenbuf[];
int size;
int flag;
{
        static char inter[80];
        int j = 0;
        static int a_flag = 0;
        int u_flag;
        int offset;

        for(;;)
        {
                offset = size/sizeof(char *);
                strcpy(inter, tokenbuf[rnd(offset)]);
                if( index(buffer,inter) == (char *)NULL)
                        break;
                else if(flag)
                        break;
                else if(j++ > 10)
                {
#ifdef EBUG
                        puts("unique word overflow");
#endif
                        break;
                }
        }
        if(a_flag)
        {
                u_flag = 0;
                switch(inter[0])
                {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                        u_flag = 1;
                        break;
                case 'u':
                        if(inter[1] == 'n')
                                u_flag = 1;
                        break;
                }

                if(u_flag)
                        strcpy(
                            (buffer + (strlen(buffer)) - strlen("a ")),
                            "an ");
        }
        if( ! (strcmp(inter,"a ")))
                a_flag = 1;
        else
                a_flag = 0;
        return(inter);
}
