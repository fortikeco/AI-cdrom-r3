/***************************************************************************
NAME:           index.c

PURPOSE:        return the position of the token in a string
                        K&R, converted to use pointers
****************************************************************************/
#include <stdio.h>

char *index(source, token)
char *source, *token;
{
char *ptsource, *pttoken, *ptmatch;

        for(ptsource = source; *ptsource != '\0'; ptsource++)
        {
                for(ptmatch = ptsource, pttoken = token;

                        *pttoken != '\0' &&
                        *ptmatch == *pttoken;

                        ptmatch++, pttoken++)

                        ;
                
                if(*pttoken == '\0')
                        return ptsource;
        }
        return (char *)NULL;
}
