/*=========================================================================
sepapc.h
							1991.	7.5.
�i�ύX���j
91.7.5.		���߂č쐬
=========================================================================*/
/*/////////////////////////////////////////////////////////////////////////
  �C���N���[�h�t�@�C��
/////////////////////////////////////////////////////////////////////////*/
#include <stdio.h>
#include <stdlib.h>

/*/////////////////////////////////////////////////////////////////////////
  ������̒u������
/////////////////////////////////////////////////////////////////////////*/
#define MAXLEN        40   /* ��̍ő咷 */
#define MAXIN        160   /* ���͕��̍ő咷 */
#define MAXOUT       320   /* �o�͕��̍ő咷 */
#define MAXNODE      100   /* �m�[�h�̍ő��     [0 ... MAXNODE-1] */
#define MAXMORP    0x1FF   /* �`�ԑf�R�[�h�̍ő�l [0 ... MAXMORP] */
#define MAXSUPPL     100   /* �ǉ��P��̍ő��   [0 ... MAXWORDATA-1] */

/* �`�ԑf�R�[�h *//* 91.2.25 */
#define BUNTOU         1   /* ���� */
#define KUTEN          2   /* ��_ */
#define TOUTEN         3   /* �Ǔ_ */
#define BUNMATU        6   /* ���� */
#define MEIFU         10   /* ������� */
#define MEIKE         11   /* �㖼�� */
#define SUUSI         13   /* ���� */
#define MEIJI         14   /* �l�� */
#define MEIKO         15   /* �ŗL�����i�l���ȊO�j*/
#define MEISA         16   /* �T�ϐ����� */


/*/////////////////////////////////////////////////////////////////////////
  ���[�U��`�f�[�^�^
/////////////////////////////////////////////////////////////////////////*/
struct ilist                 /* list of integer */
                             /* used for node, headtabl */
    { int          node_id;
      struct ilist *next;
    };

struct node
    { char         word[MAXLEN];
      int          head, tail, code;
      struct ilist *nodelist;
    };

struct worddata
    { char word[MAXLEN];
      int code;
    };

struct slist   /* list of solution strings */
    { char   str[MAXOUT];
      int    magic;   /* ��͌��ʂ̓K�؂��������w�W�l */
      struct slist *next;
    };


/*/////////////////////////////////////////////////////////////////////////
  �֐��̃v���g�^�C�v�錾
/////////////////////////////////////////////////////////////////////////*/
void set_suppldata();
void substring(char str[], int pos1, int leng, char substr[]);
void reverse(char s[]);
int str_head_cmp(char astr[], char bstr[]);
int isjdigit(char cc[2]);
int isjkansuuji(char cc[2]);
int isjalpha(char cc[2]);
int isjkatakana(char cc[2]);
int jbreak(char str[],int (*isj)());
int jspan(char str[],int (*isj)());
void jextract(char str[],int (*isj)(), char extstr[], int *head, int *spanlen,
         char remstr[]);
void find_isj(char initstr[], int (*isj)(), int isjcode, int *node_id,
         struct node xn[MAXNODE]);
void init_conjtabl(int val);
void entry_conj(int p, int q, int val);
void set_conjtabl();
int check_conj(int p, int q);
void init_xnode();
struct ilist *new_ilist(int id);
void join_ilist(int x,int y);
struct slist *new_slist(char str[MAXOUT], int n);
void join_slist(char str[MAXOUT], int n);
void wait_return();
void new_line();
void bell();
void print_ilist(struct ilist *x);
void print_suppldata();
void print_xnode(struct node x[MAXNODE]);
void init_headtabl();
void join_headtabl(int head, int id);
void print_ilist2(struct ilist *x);
void print_headtabl(int imax);
void print_all_solutions();
void print_best_solutions();
void trace_net(struct node x, char s[], int magic);
void find_solutions(struct node x[MAXNODE]);
void entry_node(int *node_id, char word[MAXLEN], int head, int tail,
                int code, struct node xn[MAXNODE]);
void make_nodes(char str[MAXIN], struct node xn[MAXNODE]);
void check_and_make_net(struct node x[MAXNODE]);
int check_disjunction(char initstr[MAXIN], struct node x[MAXNODE]);

