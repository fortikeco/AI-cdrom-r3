/*=========================================================================
sepapc_s.c
							1991.	7.5.
�i�ύX���j
91.7.5.		���߂č쐬
91.8.13.	conjtabl�܂��̕ύX�A�v�����v�g�̓���A�t�@�C���̓Ǎ�
=========================================================================*/
/*/////////////////////////////////////////////////////////////////////////
  �C���N���[�h�t�@�C��
/////////////////////////////////////////////////////////////////////////*/
#include "sepapc.h"
#include "sepapc_g.h"

/*/////////////////////////////////////////////////////////////////////////
  �T�u���[�e�B�� SUBROUTINES
/////////////////////////////////////////////////////////////////////////*/
/**************************************************************************
  �ǉ������̓ǂݍ���  SUBROUTINE for SETTING DATA
**************************************************************************/
void set_suppldata()		/* Set data of supplement words */
				/* Read data from "suppl.dat" */
{
    int code, n;
    char sign;
    char word[MAXLEN];
    char name[80]; /* �t�@�C������80�����܂ŉ� */
    FILE *fp;

    num_plus = 0;  num_minus = 0;

    /* �ǉ������̓ǂݍ��� */
    printf("-? �ǉ������t�@�C����(���s�̂�=SUPPLPC.DAT) >");
    gets(name);
    if ( NULL == (fp = fopen(name,"r"))) {
       printf("- I'll read SUPPLPC.DAT\n");
       if ( NULL == (fp = fopen("SUPPLPC.DAT","r"))) {
          printf("-! ERROR fopen !\n");
          bell(); exit(0);
       }
    }
    else {
       printf("- I'll read %s\n",name);
    }

    for (n=0; n<MAXSUPPL; n++) {
       if (feof(fp)) break;
       fscanf(fp,"%c%s\t%d\n",&sign,&word,&code);
	   /* �t�@�C���̌`��: +�ǉ���(tab)010(return) */
	   /*                 -�폜��(tab)016(return) */
	   /* wait_return(); printf("%d:%c_%s_%03x\n",n,sign,word,code); */
       if (sign == '*') {
	  n--;
       }
       else if (sign == '-') {
          strcpy(minusdata[num_minus].word,word);
          minusdata[num_minus].code = code;
          num_minus++;
       }
       else {
	  strcpy(plusdata[num_plus].word,word);
	  plusdata[num_plus].code = code;
          num_plus++;
       }
    }
    fclose(fp);
}
/**************************************************************************
  �����񏈗�  SUBROUTINE for STRING PROCESSING
**************************************************************************/
void substring( str, pos1, leng, substr ) /* extract 'substr' from 'str'
                                             ('leng' chars from 'pos1')  */
    char  str[], substr[];
    int   pos1, leng;
{
    int  pos2;

    pos2 = 0;
    while( pos2 < leng && str[pos1] != '\0' )  substr[pos2++] = str[pos1++];
    substr[pos2] = '\0' ;
}
/*-----------------------------------------------------------------------*/
void reverse(s)    /* reverse string */
    char s[];
{
    int c, i, j;

    for (i=0, j=strlen(s)-1; i<j; i++, j--) {
      c = s[i];
      s[i] = s[j];
      s[j] = c;
    }
}
/*-----------------------------------------------------------------------*/
int str_head_cmp( astr, bstr )  /* compare Head parts of two Strings */
				/* 0: bstr is head part of astr */
    char astr[], bstr[];
{
    char substr[MAXIN];
    int  bleng;

    if ((bleng=strlen(bstr)) > strlen(astr)) {
        return(-1);
	}
    else {
	substring( astr, 0, bleng, substr );
	/*    printf("  bleng = %d\n",bleng); */
	return(strcmp(substr, bstr));
	}
}
/**************************************************************************
  ������̌��o  SUBROUTINE for Pattern Matching
**************************************************************************/
int isjdigit(cc)	/* �S�p�Z�p�����̌��o */
    char cc[2];
{
    if ( (strcmp(cc,"�O")>=0 && strcmp(cc,"�X")<=0)
         || (strcmp(cc,"�D")==0) )
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int isjkansuuji(cc)	/* �S�p������������̐����̌��o */
    char cc[2];
{
    if ( (strcmp(cc,"�O")>=0 && strcmp(cc,"�X")<=0)
         || strcmp(cc,"��")==0 || strcmp(cc,"��")==0 || strcmp(cc,"�O")==0
         || strcmp(cc,"�l")==0 || strcmp(cc,"��")==0 || strcmp(cc,"�Z")==0
         || strcmp(cc,"��")==0 || strcmp(cc,"��")==0 || strcmp(cc,"��")==0
         || strcmp(cc,"�\")==0 || strcmp(cc,"�S")==0 || strcmp(cc,"��")==0
         || strcmp(cc,"��")==0 || strcmp(cc,"��")==0 || strcmp(cc,"��")==0
         || strcmp(cc,"��")==0
       )
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int isjalpha(cc)	/* �S�p�A���t�@�x�b�g�̌��o */
    char cc[2];
{
    if ( (strcmp(cc,"�`")>=0 && strcmp(cc,"��")<=0)
         || (strcmp(cc,"��")>=0 && strcmp(cc,"��")<=0)
         || (strcmp(cc,"�@")>=0 && strcmp(cc,"��")<=0) )
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int isjkatakana(cc)	/* �S�p�J�^�J�i�̌��o */
    char cc[2];
{
    if ( (strcmp(cc,"�@")>=0 && strcmp(cc,"��")<=0)
         || (strcmp(cc,"�[")==0)
         || (strcmp(cc,"�E")==0) )
	/* ^ �i�J�O�������ł���Ƃ��Č��o���Ă��܂� */
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int jbreak(str,isj)	/* �w�蕶����̐擪��Ԃ� */
    char str[];
    int (*isj)();
{
    int  pos, leng;
    char cc[3];      /** 90/9/5 cc[2] caused a fatal error ! **/

    leng = strlen(str);

    pos = 0;
    while ( pos < leng ) {
       cc[0] = str[pos]; cc[1] = str[pos+1]; cc[2] = '\0';
       /* printf("--cc = %s, pos = %d\n",cc,pos); */
       if ( (*isj)(cc)==1 ) break;
       pos = pos+2;
    }

    if ( pos >= leng )
       return(-1);      /* not found */
    else
       return(pos);     /* found anything */
}
/*-----------------------------------------------------------------------*/
int jspan(str,isj)	/* �w�蕶����̘A������Ԃ� */
    char str[];
    int (*isj)();
{
    int  pos, leng;
    char cc[3];

    leng = strlen(str);

    pos = 0;
    while ( pos < leng ) {
       cc[0] = str[pos]; cc[1] = str[pos+1]; cc[2] = '\0';
       /* printf("--cc = %s, pos = %d\n",cc,pos); */
       if ( (*isj)(cc) != 1 ) break;
       pos = pos+2;
    }

    return(pos);  /* if 0, not found */
}

/*-----------------------------------------------------------------------*/
void jextract(str,isj,extstr,head,spanlen,remstr)
					/* �w�蕶����̕��т�Ԃ� */
    char str[], extstr[], remstr[];
    int (*isj)();
    int *head, *spanlen;
{
   int  initlen;
   char substr[MAXIN];

	 /* printf("## now, in jextract\n"); */

   strcpy(extstr,"");
   initlen = strlen(str);
   /* printf("-initstr = %s\n",str); */
   /* printf("-initleng = %d\n",initlen); */

   *head = jbreak(str,isj);
   if ( *head >= 0 ) {
      /* printf("-head is %d\n",*head); */
      substring(str,*head,initlen-*head,substr);
      /* printf("-break remain is %s\n",substr); */

      *spanlen = jspan(substr,isj);
      if ( *spanlen > 0 ) {
         /* printf("-span is %d\n",*spanlen); */
         substring(str,*head,*spanlen,extstr);

         substring(str,*head+*spanlen,initlen-*head-*spanlen,remstr);
         /* printf("-span remain is %s\n",remstr); */
      }
   }
   else {
      /* printf("-not found\n"); */
      remstr[0] = '\0';
   }
   /* if (strcmp(remstr,"")==0) printf("-remstr is empty\n"); */
}

/*-----------------------------------------------------------------------*/
void find_isj(initstr,isj,isjcode,node_id,xn)
    char        initstr[];
    int         (*isj)();
    struct node xn[MAXNODE];
    int         isjcode, *node_id;
{
   char remstr[MAXIN], extstr[MAXIN], str[MAXIN];
   int  lasthead, head, leng, xhead, xtail;
   int         temp;

   strcpy(str,initstr);  /* initstr�����������Ȃ��悤�ɃR�s�[ */

   lasthead = 0;
   while(1) {
	 /* printf("# now, in find_ijs\n"); */
      jextract( str, isj, extstr, &head, &leng, remstr );

      xhead = (lasthead+head)/2;
      xtail = (lasthead+head+leng)/2;
      lasthead = lasthead + head + leng;
      /* printf("# xhead=%d, xtail=%d, ",xhead,xtail); */
      /* printf("# node_id=%d\n",*node_id); */

      if (strcmp(extstr,"") != 0) {
         entry_node(node_id,extstr,xhead,xtail,isjcode,xn);
         /* ^ entry_node(&node_id,...)�ł͂��߁I */
         /* printf("# extstr=%s, isjcode=%d, ",extstr,isjcode); */
      }

      if (*node_id>MAXNODE-1) {
         /* printf("node_id=%d��MAXNODE�𒴂���!\n",*node_id); */
         goto exit_find_isj;
      }

      if (strcmp(remstr,"")==0) {
         /* printf("-remstr is empty\n"); */
         break;
      }
      else {
         strcpy(str,remstr);
      }
   }
  exit_find_isj:;
}

/**************************************************************************
  �ڑ��̏���  SUBROUTINE for CONJTABL
**************************************************************************/
void init_conjtabl(val)   /* Initialize conjunction data with val */
    int val;
{
    int i, j;

    for (i=0; i<=MAXMORP; i++) {
       for (j=0; j<(MAXMORP+1)/8; j++) {
          if (val==0) {
             conjtabl[i][j] = 0x00;
          }
          else {
             conjtabl[i][j] = 0xFF;
          }
       }
    }
}

/*-----------------------------------------------------------------------*/
void entry_conj(p,q,val)   /* Entry conjunction data to conjtabl */
    int p, q, val;    /* p: code of pre-morph,  q: code of post-morph */
                      /* val: binary value 0/1 */
{
    int  qx, qy;
    char old, tmp;

    /* printf("��:%03d, �E:%03d, �l %d\n",p,q,val); */

    qx = q/8;
    qy = q%8;

    old = conjtabl[p][qx];
    tmp = 0x01;
    if (val==1)
       { tmp = tmp<<qy;
         conjtabl[p][qx] = old | tmp;
       }
    else
       { tmp = ~(tmp<<qy);
         conjtabl[p][qx] = old & tmp;
       }
}

/*-----------------------------------------------------------------------*/
void set_conjtabl()   /* Setting conjunction data */
{
   int i, j;
   char cc;
   char name[80]; /* �t�@�C������80�����܂ŉ� */
   FILE *fp_in;

   /* �ڑ��\�̓ǂݍ��� */
   printf("-? �ڑ��\�t�@�C����(���s�̂�=CONJTABL.DAT) >");
   gets(name);
   if ( NULL == (fp_in = fopen(name,"r"))) {
      printf("- I'll read CONJTABL.DAT\n");
      if ( NULL == (fp_in = fopen("CONJTABL.DAT","r"))) {
         printf("-! ERROR fopen !\n");
         bell(); exit(0);
      }
   }
   else {
      printf("- I'll read %s\n",name);
   }

   for (i=0; i<=MAXMORP; i++) {
      for (j=0; j<(MAXMORP+1)/8; j++) {
	 cc=fgetc(fp_in);
	 conjtabl[i][j] = cc;
         /* �����ł́A�t�@�C��name�̐擪����512*512/8=32768 byte�� */
         /* eof������悤������܂����A�����ēǂݍ��ށB���������āA*/
         /* 32768 byte���t�@�C�����������ƁA�ʂ̃t�@�C���̈��   */
         /* �ǂ�ł��܂����Ƃ����肤��̂Œ��ӁBeof�̌��o�����Ȃ�  */
         /* �̂́A�ڑ��e�[�u���f�[�^����eof�Ɠ����R�[�h��������  */
         /* �\�������邽�� */
      }
   }

   fclose(fp_in);
   printf("\a\a\a");
}

/*-----------------------------------------------------------------------*/
/* �ڑ��e�[�u���̃`�F�b�N */
int check_conj(p,q)   /* Check conjunction according to conjtabl */
    int p, q;
{
    int  qx, qy, val;
    char tmp;

    qx = q/8;
    qy = q%8;
    tmp = 0x01;

    if ((conjtabl[p][qx] & tmp<<qy)==0)
       return(0);
    else
       return(1);
}

/**************************************************************************
  ���X�g�̐���  SUBROUTINE for MAKING LIST or NODE
**************************************************************************/
void init_xnode()   /* Initialize xnode */
{
    int i;

    for (i=0; i<MAXNODE; i++) {
       strcpy(xnode[i].word,"");
       xnode[i].head = 0;
       xnode[i].tail = 0;
       xnode[i].code = 0;
       xnode[i].nodelist = NULL;
    }

    num_nodes = 0; /* ������ */
}

/*-----------------------------------------------------------------------*/
struct ilist *new_ilist(id)        /* Used in 'join_ilist' & 'join_headtabl' */
                                   /* Make new ilist with id & NULL */
    int  id;
{
    struct ilist *xlist;

    xlist = (struct ilist *)malloc(sizeof(struct ilist *));
    xlist->node_id = id;
    xlist->next  = NULL;
    return(xlist);
}

/*-----------------------------------------------------------------------*/
void join_ilist(x,y)                      /* Used in 'check_and...' */
     int x,y;
{
     struct ilist *l;

     if (xnode[x].nodelist == NULL) {
	xnode[x].nodelist = new_ilist(y);
     }
     else {
	for (l=xnode[x].nodelist; l->next != NULL; l=l->next);
				    /* ^ 'list' wo Matubi made Tadoru. */
	l->next = new_ilist(y);
     }
}

/*-----------------------------------------------------------------------*/
struct slist *new_slist(str,n)     /* Used in 'join_slist' */
                                   /* Make new slist with str & NULL */
    char str[MAXOUT];
    int  n;  /* number of nodes */
{
    struct slist *xlist;

    xlist = (struct slist *)malloc(sizeof(struct slist));
    strcpy(xlist->str,str);
    xlist->magic = n;
    xlist->next  = NULL;
    return(xlist);
}

/*-----------------------------------------------------------------------*/
void join_slist(str,n)                      /* according to value of magic */
    char str[MAXOUT];
    int  n;   /* number of nodes */
{
    struct slist *l, *ll;

    for (l=solutions; n > l->next->magic; l=l->next);
                                      /* ^ 'list' wo Tadoru. */
	/* printf("---n=%d,l->next->magic=%d\n",n,l->next->magic); */
    ll = l->next;
    l->next = new_slist(str,n);
    l->next->next = ll;

    /* ex.   0:  MAXNODE -> 0 (=initial list in 'find_solutions')
	     1:  MAXNODE -> 5 -> 0
	     2:  MAXNODE -> 5 -> 10 -> 0
	     3:  MAXNODE -> 5 -> 7  -> 10 -> 0 */
}

/**************************************************************************
  �o�͂̃g�D�[��  SUBROUTINE for PRINTING/OUTPUT
**************************************************************************/
void wait_return()                                    /* Waiting Routine */
{
	char dummy;

	printf("... please return >");
	dummy = getchar();
	printf("%c",dummy);
}

/*-----------------------------------------------------------------------*/
void new_line()                                    /* Kaigyou suru. */
{
	printf( "\n" );
        fprintf( fp_suc,"\n" );
}

/*-----------------------------------------------------------------------*/
void bell()                                    /* Kaigyou suru. */
{
	printf( "\07" );
}

/**************************************************************************
  ���X�g�̏o��  SUBROUTINE for PRINTING/OUTPUT
**************************************************************************/
void print_ilist(x)                                 /* Used in 'print_xnode' */
    struct ilist *x;
{
  if (x == NULL) {
        printf("NIL");
        /* fprintf(fp_fai,"NIL"); */
  }
  else {
	printf("%s(#%d),  ",xnode[x->node_id].word,x->node_id);
	/* fprintf(fp_fai,"%s(#%d),  ",
			     xnode[x->node_id].word,x->node_id); */
	print_ilist(x->next);
  }
}

/*-----------------------------------------------------------------------*/
void print_suppldata()         /* 'Worddata' no 'Data' wo Shuturyoku suru. */
{
    int i;

    printf("-plusdata\n");
    for (i=0; i<num_plus; i++) {
	printf("? %d:%s (%d)\n",
		i,plusdata[i].word,plusdata[i].code);
    }

    printf("-minusdata\n");
    for (i=0; i<num_minus; i++) {
	printf("? %d:%s (%d)\n",
		i,minusdata[i].word,minusdata[i].code);
    }
}

/*-----------------------------------------------------------------------*/
void print_xnode(x)            /* �`�ԑf�m�[�h���o�͂��� */
    struct node x[MAXNODE];
{
    int i;

    printf("\n- print_xnode\n");
    /* fprintf(fp_fai,"\n- print_xnode\n"); */

    for (i=0; i<num_nodes; i++) {
	printf(">#%d:%s (%d, %d-%d)  { ",
		i,x[i].word,x[i].code,x[i].head,x[i].tail);
	/* fprintf(fp_fai,"#%d:%s (%d, %d-%d)  { ",
		i,x[i].word,x[i].code,x[i].head,x[i].tail); */
	print_ilist(x[i].nodelist);
        printf(" }\n");
         /* fprintf(fp_fai," }\n"); */
    }
}

/**************************************************************************
  �擪�����ʒu�e�[�u���̏���  SUBROUTINE for HEADTABL
**************************************************************************/
void init_headtabl()   /* Initialize headtabl */
{
    int i;

    for (i=0; i<MAXIN; i++) {
       headtabl[i] = NULL;
    }
}

/*-----------------------------------------------------------------------*/
void join_headtabl(head,id)
    int  head, id;
{
    struct ilist *l;

    if (headtabl[head] == NULL) {
       headtabl[head] = new_ilist(id);
    }
    else {
       for (l=headtabl[head]; l->next != NULL; l=l->next);
				/* ^ ���X�g�𖖔��܂ł��ǂ� */
       l->next = new_ilist(id);
    }
}

/*-----------------------------------------------------------------------*/
void print_ilist2(x)                         /* Used in 'print_headtabl' */
    struct ilist *x;
{
  printf("- headtabl[0-]\n");

  if (x == NULL) printf("NILL");
  else {
	printf("%d, ",x->node_id);
	print_ilist2(x->next);
  }
}

/*-----------------------------------------------------------------------*/
void print_headtabl(imax)        /* headtabl[0-imax] wo Shuturyoku suru. */
    int imax;
{
    int i;

    for (i=0; i<imax; i++) {
	printf(">%3d { ",i);
	print_ilist2(headtabl[i]);
        printf(" }\n");
    }
}

/**************************************************************************
  ���̏o��
**************************************************************************/
void print_all_solutions()
{
    struct slist *l;

    printf("- print_all_solutions\n");

    for (l=solutions->next; l->next != NULL; l=l->next) {
        printf("%3d: %s\n",l->magic,l->str);
        fprintf(fp_suc,"%3d: %s\n",l->magic,l->str);
    }
}

/*-----------------------------------------------------------------------*/
void print_best_solutions()
{
    struct slist *l;
    int n, nbest, nprint;

    printf("- print_best_solutions\n");
    /* fprintf(fp_suc,"- print_best_solutions\n"); */ /* 91.2.22 */

    new_line();
    n = solutions->next->magic;
    nbest = 0; /* �w�W�l���ŏ��̉��̌� *//* 91.2.26 */
    nprint = 0; /* �o�͂������̌� */

    for ( l=solutions->next;(l->next != NULL)&&(n == l->magic); l=l->next ) {
       nbest++;
       if (nbest<=max_nbest) { /* 91.2.8 */
          printf("%s\n",l->str);
          fprintf(fp_suc,"%s\n",l->str);
          nprint++;
       }
    }
    /* new_line(); */
    printf("- print_best_solutions %d / %d\n",nprint,nbest);
    fprintf(fp_suc,"- print_best_solutions %d / %d\n",nprint,nbest);
    /* 91.2.26 */
}

/**************************************************************************
  ���̒T��
**************************************************************************/
void trace_net(x,s,magic) /* find_solutions����Ăяo�� */
    struct node x;
    char s[]; /* 91.7.5 */
    int magic;
{
    struct ilist *l;
    char punc[] = "-", ss[MAXOUT], codestr[8];

    pass_time++; /* trace_net�̒ʉ߉� */

    itoa(x.code,codestr,10); /* <- TURBO C�̕W�����C�u���� */

    /* 91.1.29-vax */
    if (x.head<cutting_point && num_solutions==0) {
       /* */printf("-- break!!\n");
       goto exit_trace_net; /* �}���� */
    }
    else if (num_solutions>0) {
       cutting_point=0;
    }

    /* ��͌��ʂ̓K�؂��������w�W�l          */
    /* magic = ������̌�*100 + �t����or�ڎ�or�Ǔ_�̌� */
    /*         ���p����͐����Ȃ�                          */
    if (x.code>=10 && x.code<100) {		/* ������ */
          magic = magic + 100;
    }
    else if (x.code>=260 || x.code==3)  {	/* �t����or�ڎ�or�Ǔ_ */
          magic = magic + 1;
    }

    /* �K���ߖڂɂȂ�m�[�h���A�}����ɗp���� */
    if ( (x.code==TOUTEN || strcmp(x.word,"��")==0)
         && cutting_point<x.tail ) {
       cutting_point = x.tail; /* 91.1.29-vax */
       /* */ printf("-- cutting_point = %d!\n",cutting_point);
    }

    if ( x.tail==len_initstr && check_conj(x.code,BUNMATU)==1) {
          /* �����ɓ��B�����ꍇ */
          num_solutions++;
          if (num_solutions%10 == 0) printf(".");
          /* printf("---%d: %s%s\n",magic,s,codestr); */

          if (magic <= min_magic) {
          /* magic�����܂܂ł̍ŏ��l�ȉ��Ȃ�Ή��Ƃ݂Ȃ��ă��X�g�֓o�^ */
             min_magic = magic;	/* �ŏ��l�̍X�V */
             strcpy(ss,"");
	     strcat(ss,s);
	     strcat(ss,codestr);
             if (strlen(ss)>MAXOUT) {
                printf("-! over MAXOUT\n");
                return;
             }
	     else { 
                join_slist(ss,magic);
             }
          }
    }

    for (l=x.nodelist;
         (pass_time<max_pass_time)	/* �I������:1.trace_net�̒ʉ߉� */
         &&(magic<=min_magic)		/*          2.magic�̒l */
         &&(l!=NULL)			/*          3.nodelist���� */
         /* &&(num_solutions<max_solu)*/ /*          4.�������̌� */
         ;l=l->next
        )
    {
       strcpy(ss,"");
       strcat(ss,s);
       strcat(ss,codestr);
       strcat(ss,punc);
          /* "�v���O����10-��421-��48-��188 */
          /*   "[{�v���O����,10},{��,421},{��,48},{��,188}] */
          /*    ^ �ŏI�`�� */
       strcat(ss,xnode[l->node_id].word);
       if (strlen(ss)>MAXOUT) { /* 91.2.28 */
          printf("-! over MAXOUT\n");
          return;
       }
       else { 
          trace_net(xnode[l->node_id],ss,magic);
       }
    }
  exit_trace_net:;
}

/*-----------------------------------------------------------------------*/
void find_solutions(x)
    struct node x[MAXNODE];
{
    int i;

    num_solutions = 0;
    /* 91.1.29-vax */
    cutting_point = 0;    /* �}���̂��߂̐��l use in trace_net */

    solutions = new_slist("head_guard",0);
    solutions->next = new_slist("tail_guard",MAXNODE*100);

    min_magic = MAXNODE*100; /* min_magic�̏����� */

    pass_time = 0; /* trace_net�̒ʉ߉񐔂̏����� */

    for (i=0; i<num_nodes; i++) {
       if ( x[i].head==0 && check_conj(BUNTOU,x[i].code)==1 ) {
               /* �����ɐڑ��Ȃ�΃l�b�g�����ǂ� */
          if (cutting_point>0) {
             /* printf(">break!\n"); */
             break; /* �}���� */
          }
          else {
             trace_net(x[i],x[i].word,0);
          }
       }
    }
    if (pass_time>max_pass_time) {
       /*  */printf("-- pass_time > %d\n",max_pass_time);
       fprintf(fp_suc,"-- pass_time > %d\n",max_pass_time);
    }
    else {
       /*  */printf("-- pass_time = %d\n",pass_time);
       fprintf(fp_suc,"-- pass_time = %d\n",pass_time);
    }
}

/**************************************************************************
  �m�[�h�̐���  MAKING NODES
**************************************************************************/
void entry_node(node_id,word,head,tail,code,xn)
    /* �V�����m�[�h��xn�ɓo�^���� */
    /* node_id, xn ��call by reference */
    char   word[MAXLEN];
    int    *node_id; /* �J�����g�̃m�[�h�ԍ� */
    int    head, tail, code; 
    struct node xn[MAXNODE];
{
    int    i, id;
    int    key;

    /* printf("%s:%d-%d,%3d\n",word,head,tail,code); */

    /* �폜�f�[�^�Ƃ̏ƍ� */
    for (i=0; i<num_minus; i++) {
       if(strcmp(minusdata[i].word,word)==0
          && minusdata[i].code==code) return;
    }

    /* �o�^�ς݃m�[�h�Əd�����Ă��Ȃ����Ƃ𒲂ׂ�			*/
    /* ���������������̃R�[�h�œo�^����Ă��邱�Ƃւ̑Ώ��Ö@		*/
    /* �D�揇�ʁ������T��16�A�������10�A�l���ȊO�̌ŗL15�A�l��14	*/
    /* key = 0 : �����l							*/
    /*       1 : ���ʂ��Ⴂ -> �o�^���Ȃ�				*/
    /*       2 : ���ʂ����� -> ���łɂ���m�[�h�̃R�[�h��ύX����	*/
    id = 0;
    key = 0;
    while (id<*node_id) {
       if ( (strcmp(xn[id].word,word) == 0) && (xn[id].head == head) ) {
          if ( xn[id].code == code ) {
             break;
          }
          else if ( (xn[id].code == MEISA && code == MEIFU)
                   || (xn[id].code == MEISA && code == MEIKO)
                   || (xn[id].code == MEISA && code == MEIJI)
                   || (xn[id].code == MEIFU && code == MEIKO)
                   || (xn[id].code == MEIFU && code == MEIJI)
                   || (xn[id].code == MEIKO && code == MEIJI)
                   || (xn[id].code == MEIFU && code == MEIKE)
                  )
          {
            key = 1;  break;
          }
          else if ( (xn[id].code == MEIJI && code == MEIKO)
                   || (xn[id].code == MEIJI && code == MEIFU)
                   || (xn[id].code == MEIJI && code == MEISA)
                   || (xn[id].code == MEIKO && code == MEIFU)
                   || (xn[id].code == MEIKO && code == MEISA)
                   || (xn[id].code == MEIFU && code == MEISA)
                   || (xn[id].code == MEIKE && code == MEIFU)
                  )
          {
             key = 2;  break;
          }
       } /* end of if */
       id++;
    } /* end of while */

    if ( ( id>=*node_id )	/* xn�ɖ��o�^�̏ꍇ */
         && !( ( tail-head==1 )
               && ( code==10 )
	       && ( (strcmp(word,"��")>=0) && (strcmp(word,"��")<=0) )
             )
         /* word���Ђ炪�ȂP�����̖����łȂ� */
       )
    {
       strcpy(xn[*node_id].word,word);
       xn[*node_id].code = code;
       xn[*node_id].head = head;
       xn[*node_id].tail = tail;
       join_headtabl(head,*node_id);  /* make headtabl */
       *node_id = *node_id + 1;
       /* ������ (*node_id)++ �ł��悢�H */
       /*        *node_id++   �ł̓_��   */
       /* */ printf("|%s:%d-%d,%3d\n",word,head,tail,code);
    }
    else if (key == 2) {
    /* ���łɂ���m�[�h��code��ύX���� */
       xn[id].code = code;
    }
}

/*-----------------------------------------------------------------------*/
void make_nodes(str,xn)
    char str[MAXIN];
    struct node xn[MAXNODE];
{
    char substr[MAXIN], subword[MAXLEN];
    int    i, j, node_id, leng, subleng, head, tail;
    int    sresult, c, p;
    int    k;
/*--for TRIE dictionary--*/
/*    char   yomi[10][15][31]; */
/*    int    bytes[10], inn[10], count; */
/*    short  poses[10][15]; */
/*    int    morpcode; */

    for (i=0; i<MAXNODE; i++) {
       xn[i].nodelist = NULL;
    }

    node_id = 0;
    leng = strlen(str);

/*** (1+2) search dictionaris ***/

    for (i=0; i<=leng-2; i=i+2) {
       substring(str,i,leng-i,substr);
			/* printf(">substr=%s\n",substr); */

/*** (1) search TRIE dictionary ***/

/*       SEPAPC.C�ɂ͂Ȃ� */

/*** (2) search supplDATA ***/

       for (j=0; j<num_plus; j++) {
	 if (str_head_cmp(substr,plusdata[j].word)==0) {
		 /* printf(">>match j=%d, word=%s\n",j,plusdata[j].word); */

            head = i/2;
	    subleng = strlen(plusdata[j].word);
            tail = (i+subleng)/2;

            entry_node(&node_id,plusdata[j].word, /* node_id��call by ref. */
                               head,tail,plusdata[j].code,xn);

           if (node_id>MAXNODE-1) { 
              /* printf("node_id=%d��MAXNODE�𒴂���!\n",node_id); */
              goto exit_make_nodes; /* 91.1.18 */
           }
	 }
       }
    }

/*** (3) search ISJ ***/
    /* �����̒��o */
    find_isj(str,isjdigit,   SUUSI,&node_id,xn);
    find_isj(str,isjkansuuji,SUUSI,&node_id,xn);

    /* �A���t�@�x�b�g�̕��т̒��o */
    find_isj(str,isjalpha,   MEIFU,&node_id,xn);

    /* �J�^�J�i�̕��т̒��o */
    find_isj(str,isjkatakana,MEIFU,&node_id,xn);

  exit_make_nodes:;
    num_nodes = node_id;

    printf("-= num_nodes = %d\n",num_nodes);
    fprintf(fp_suc,"-= num_nodes = %d\n",num_nodes);
}

/**************************************************************************
  �ڑ��̃`�F�b�N  SUBROUTINE for CHECK
**************************************************************************/
void check_and_make_net(x)	/* �`�ԑf�Ԃ̐ڑ��𒲂ׁA�Ԃ���� */
    struct node x[MAXNODE];
{
    struct ilist *l;
    int i, j;

    for (i=0; i<num_nodes; i++) {
       if (headtabl[x[i].tail] != NULL) {
	  l = headtabl[x[i].tail];
	  do {
	     j = l->node_id;
	     if ( check_conj(x[i].code,x[j].code) == 1 ) {
		join_ilist(i,j);
	     }
	     l = l->next;
	  } while (l != NULL);
       }
    }
}

/*-----------------------------------------------------------------------*/
int check_disjunction(initstr,x)	/* xnode�̕s�A�������o���� */
    char   initstr[MAXIN];
    struct node x[MAXNODE];
{
    int i;
    int pos, posmax;

    posmax = strlen(initstr) / 2;
    /* printf(">initstr = %s\n",initstr); */
    /* printf(">posmax  = %d\n",posmax); */

    pos = 0;
    for (i=0; i<num_nodes; i++) {
       if ((x[i].head == 0)&&(check_conj(BUNTOU,x[i].code) == 1)) {
          /* �����ɐڑ��� */
          break;
       }
    }
    if (i == num_nodes) {
       /* printf(">goto exit 0\n"); */
       goto exit_check_disjunction;
    }

    pos = 1;
    while (pos < posmax) {
       /* printf(">pos = %d\n",pos); */
       for (i=0; i<num_nodes; i++) {
	  if (  ( (x[i].tail == pos) && (x[i].nodelist != NULL) )
                 /* ��������̐؂�ڂ̏ꍇ */
		|| ( (pos > x[i].head) && (pos < x[i].tail) )
                 /* ��������̓r���̏ꍇ */
	     ) {
             /* printf(">%d:%s\n",pos,x[i].word); */
             break;
          }
       }
       if (i == num_nodes) {
          /* printf(">goto exit +\n"); */
          goto exit_check_disjunction;
       }
       pos++;
    }

  exit_check_disjunction:;

    if(pos == posmax) {
       return(MAXIN);	/* �s�A�����Ȃ���΁AMAXIN��Ԃ� */
       /* printf(">success.\n"); */
    }
    else {
       return(pos);	/* �s�A��������΁A���̈ʒu��Ԃ� */
       /* printf(">fail.\n"); */
    }
}

/*-----------------------------------------------------------------------*/

