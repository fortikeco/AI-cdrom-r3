/*=========================================================================
  bunri.c
�@�����̃\�[�X�t�@�C������A���o����ɓ��蕶����̊܂܂�Ă���s�ƁA
�@����ȊO�̍s�𕪗����ăt�@�C���ɕۑ�����v���O����
=========================================================================*/
#include <stdio.h>

#define MAX_STR    160
#define beep()     putchar(7)

FILE    *fi, *fo1, *fo2, *fo3;

/**************************************************************************
  MAINROUTINE
**************************************************************************/
main(int argc, char *argv[])
{
   if(argc>3){
      help();
      exit(1);
   }
   else{
      set_files(argc,argv);	/* ���̓t�@�C����ݒ� */
      read_data();		/* �t�@�C������f�[�^��Ǎ� */
   }

   fclose(fi);
   fclose(fo1);
   fclose(fo2);
   fclose(fo3);

   beep();
   beep();
   beep();
   beep();
}

/**************************************************************************
  SUBROUTINE
**************************************************************************/
/**************************************************************************
  ������̌��o  SUBROUTINE for Pattern Matching
**************************************************************************/
int isjspace(cc)	/* �S�p�X�y�[�X�̌��o */
    char cc[2];
{
    if( strcmp(cc,"�@")==0 )
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int isjkigou(cc)	/* �S�p�L���̌��o */
    char cc[2];
{
    if( strcmp(cc,"�A")>=0 && strcmp(cc,"��")<=0
          && strcmp(cc,"�X")!=0
          && strcmp(cc,"�[")!=0 )
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int isjdigit(cc)	/* �S�p�Z�p�����̌��o */
    char cc[2];
{
    if ( (strcmp(cc,"�O")>=0 && strcmp(cc,"�X")<=0) )
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int isjalpha(cc)	/* �S�p�A���t�@�x�b�g�̌��o */
    char cc[2];
{
    if ( (strcmp(cc,"�`")>=0 && strcmp(cc,"��")<=0)
         || (strcmp(cc,"��")>=0 && strcmp(cc,"��")<=0)
         || (strcmp(cc,"�@")>=0 && strcmp(cc,"��")<=0) )
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int isjkatakana(cc)	/* �S�p�J�^�J�i�̌��o */
    char cc[2];
{
    if ( (strcmp(cc,"�@")>=0 && strcmp(cc,"��")<=0) )
       return(1);
    else
       return(0);
}

/*-----------------------------------------------------------------------*/
int jbreak(str,isj)	/* �w�蕶����̐擪��Ԃ� */
    char str[];
    int (*isj)();
{
    int  pos, leng;
    char cc[3];      /** 90/9/5 cc[2] caused a fatal error ! **/

    leng = strlen(str);

    pos = 0;
    while ( pos < leng ) {
       cc[0] = str[pos]; cc[1] = str[pos+1]; cc[2] = '\0';
       /* printf("--cc = %s, pos = %d\n",cc,pos); */
       if ( (*isj)(cc)==1 ) break;
       pos = pos+2;
    }

    if ( pos >= leng )
       return(-1);      /* not found */
    else
       return(pos);     /* found anything */
}
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
set_files(int argc, char *argv[])
{
   char inname[13], outname[13];

   /* printf("argc=%d\n",argc); */
   if(argc==1){
      do{
         printf("Write input-file name >");
         scanf("%s",inname);
      }while((fi=fopen(inname,"rt"))==NULL);
      do{
         printf("Write output-file1 name >");
         scanf("%s",outname);
      }while((fo1=fopen(outname,"wt"))==NULL);
   }
   else if(argc==2){
      if((fi=fopen(argv[1],"rt"))==NULL){
         do{
            printf("Write input-file name >");
            scanf("%s",inname);
         }while((fi=fopen(inname,"rt"))==NULL);
      }
      do{
         printf("Write output-file1 name >");
         scanf("%s",outname);
      }while((fo1=fopen(outname,"wt"))==NULL);
   }
   else if(argc==3){
      if((fi=fopen(argv[1],"rt"))==NULL){
         do{
            printf("Write input-file name >");
            scanf("%s",inname);
         }while((fi=fopen(inname,"rt"))==NULL);
      }
      if((fo1=fopen(argv[2],"wt"))==NULL){
         do{
            printf("Write output-file1 name >");
            scanf("%s",outname);
         }while((fo1=fopen(outname,"wt"))==NULL);
      }
   }
   else{
      help();
      exit(1);
   }

   do{
      printf("Write output-file2 name >");
      scanf("%s",outname);
   }while((fo2=fopen(outname,"wt"))==NULL);

   do{
      printf("Write output-file3 name >");
      scanf("%s",outname);
   }while((fo3=fopen(outname,"wt"))==NULL);
}

/*-----------------------------------------------------------------------*/
wait_return()                      /* Waiting Routine */
{
	char dummy;

        rewind(stdin);
	printf("...please return>");
	dummy = getchar();  printf("%c",dummy);
}
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
read_data()	/* �t�@�C������f�[�^��Ǎ� */
{
   char cc;
   char str[MAX_STR];
   /* �����ŁAchar str[]=""�Ƃ������߂ɁA�����Ԃނ��ɂ����B91.5.15.
      ���̐錾�ł́Astr�ɂ�1byte�����m�ۂ��ꂸ�A
      str[2]=cc�̂悤�ȑ��������ƁAcc�͂���ʂƂ���ɒu�����B*/

   char midasigo[MAX_STR];
   int  i, j, posofspace;
   long  line;	/* current line number of input_flie */

   line = 1; i = 0;

   while( ( cc=fgetc(fi) ) != EOF ){
      if(line%1000==0){
         printf("\n\33Mat line %d",line); /* ���s�ڂ����������\�� */
      }

      if(cc!='\n' && i<MAX_STR-2){
         str[i++] = cc;
      }
      else if(i==MAX_STR-2){
         str[i++] = '#';
      }
      else if(cc==0x0a){
	 str[i] = '\0';

         /* str���猩�o����̕����̂݃R�s�[ */
         posofspace = jbreak(str,isjspace);
         for(j=0;j<posofspace;j++){
            midasigo[j] = str[j];
         }
         midasigo[j] = '\0';

         if( jbreak(midasigo,isjkigou)>=0
             || jbreak(midasigo,isjdigit)>=0 ){
            fprintf(fo3,"%s\n",str);
         }
         else if( jbreak(midasigo,isjkatakana)>=0
             || jbreak(midasigo,isjalpha)>=0 ){
            fprintf(fo2,"%s\n",str);
         }
         else{
            fprintf(fo1,"%s\n",str);
         }

         i = 0;
         line++;
      }
      else{
         /* MAX�𒴂��������͖������� */
      }
   }
}

/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
help()
{
   puts("useage: nodupl INFILE OUTFILE");
}
/*-----------------------------------------------------------------------*/

