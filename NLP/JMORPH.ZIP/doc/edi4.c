/*=========================================================================
  �`�ԑf�ڑ��e�[�u���E�G�f�B�^ for �P�ʐ؂�v���O����
�@��S�ŁFsymmetry���cc�ŃR���p�C���ł���悤�ɏC��

							1991.	11.1.

�i�ύX���j
91.10.1.	printf�̏����w�蕶���񂩂�S�p������r��
91.10.4.	scanf�̓�������S�ɂ���
		�֐��̃v���g�^�C�v�錾�������̌^�錾�ɕύX
91.10.18.	�����u���v�u�A�v�́Asymmetry��ł͕�����Ƃ���printf�ŏo��
		�ł��Ȃ��̂ŁA�폜
		\a -> \7
		RSIZE�ɒ��ӁAHEADTOP�ACRLEN�𓱓�
		EDI_HEAD.IN -> edihead.txt
		CONJTABL.DOC -> conjtabl.txt
91.11.1.	edihead.txt�́Ajis�R�[�h�ɕϊ�����Ƃ��ɁA�S�p�Ɣ��p�����݂�
		�Ă����KI�AKO�̕����������Ȃ��Ă��܂��̂Œ��Ӂiedihead.txt
		��jis�ɕϊ����Ă������悤�ɏC�������j
=========================================================================*/
/**************************************************************************
  �t�@�C���̓ǂݍ���
**************************************************************************/
#include <stdio.h>

/**************************************************************************
  ������̒u������
**************************************************************************/
#define MAXSENT  400	/* �P�s�̍ő咷 */
#define MAXMORP  0x1FF	/* MAX number of MORPhemes [0 ... MAXMORP] */
#define RSIZE    65	/* edihead.txt�̂P�s�̒���	MS-DOS:65  UNIX:76 */
#define HEADTOP	 33	/* edihead.txt�̌��̊J�n�ʒu	MS-DOS:33  UNIX:39 */
#define CRLEN    2	/* ���s�R�[�h�̒���		MS-DOS:2   UNIX:1 */
#define MAXDATA  20	/* conjtabl.txt�P�s���̃f�[�^�̍ő�l */

#define bell()   putchar('\007')
/**************************************************************************
  �֐��̌^�錾
**************************************************************************/
void substring();
void init_conjtabl();
void entry_conj();
int check_conj();
void wait_return();
void give_data();
void read_file();
void read_docu();
void show_data();
void show_data0();
void show_data1();
void show_data2();
void edit_data();
void edit_data0();
void edit_data1();
void edit_data2();
void edit_data3();
void edit_data4();
void edit_data5();
void edit_data6();
void make_file();

/**************************************************************************
  ���ϐ��̒�`
**************************************************************************/
FILE *fopen();

int num_nodes, num_worddata, num_solutions;
char conjtabl[MAXMORP+1][(MAXMORP+1)/8]; /* �`�ԑf�e�[�u�� 512x512 */

/**************************************************************************
  ���C�����[�`��
**************************************************************************/
main()
{
   char sel, dmystr[80];

      printf("-Editor for Conjunction Table\n");
      printf("%s\n","-��Ƃ̊J�n !");

   init_conjtabl();

   while(1){
      /* �g�b�v���j���[�\�� */
      printf("\n%s\n","**TOP MENU**");
      printf("%s\n", "0 : �f�[�^�̓Ǎ�   1 : �����^�̓Ǎ�   2 : �f�[�^�̕\��");
      printf("%s\n>","3 : �f�[�^�̕ύX   4 : �f�[�^�̍쐬   Q : �I��");

      scanf("%c",&sel);  gets(dmystr);
      switch(sel){
         case '0': read_file(); break;  /* �f�[�^�t�@�C���̓ǂݍ��� */
         case '1': read_docu(); break;  /* �����^�t�@�C���̓ǂݍ��� */
         case '2': show_data(); break;  /* �ڑ����̕\�� */
         case '3': edit_data(); break;  /* �ڑ����̕ҏW���ύX */
         case '4': make_file(); break;  /* �f�[�^�t�@�C���̍쐬 */
         default : break;
      }
      if(sel=='q' || sel=='Q') break;
   }
   printf("\n%s\n\n","-��Ƃ̏I��.");
}

/**************************************************************************
  ���ʂ̃T�u���[�`��
**************************************************************************/
/*-------------------------------------------------------------------------
  ������̏���
-------------------------------------------------------------------------*/
/* ������̒��o */
void substring( str, pos1, leng, substr ) /* extract 'substr' from 'str'
                                      ('leng' chars from 'pos1') */
   char  str[], substr[];
   int   pos1, leng;
{
   int  pos2;

   pos2 = 0;
   while( pos2 < leng && str[pos1] != '\0' )  substr[pos2++] = str[pos1++];
   substr[pos2] = '\0' ;
}
/*-------------------------------------------------------------------------
  �ڑ��e�[�u���̏���
-------------------------------------------------------------------------*/
/* �ڑ��e�[�u���̏����� */
void init_conjtabl()   /* Initialize conjunction data */
{
   int i, j;

   for(i=0; i<=MAXMORP; i++){
      for(j=0; j<(MAXMORP+1)/8; j++){
         conjtabl[i][j] = 0x00; /* 0xFF���� */
      }
   }
}

/*-----------------------------------------------------------------------*/
/* �ڑ��e�[�u���ւ̃G���g�� */
void entry_conj(p,q,val)   /* Entry conjunction data to conjtabl */
   int p, q, val;    /* p: code of pre-morph,  q: code of post-morph */
                      /* val: binary value 0/1 */
{
   int  qx, qy;
   char old, tmp;

   /* printf("left:%03d, right:%03d, value %d\n",p,q,val); */

   qx = q/8;
   qy = q%8;

   old = conjtabl[p][qx];
   tmp = 0x01;
   if(val==1){
      tmp = tmp<<qy;
      conjtabl[p][qx] = old | tmp;
   }
   else{
      tmp = ~(tmp<<qy);
      conjtabl[p][qx] = old & tmp;
   }
}

/*-----------------------------------------------------------------------*/
/* �ڑ��e�[�u���̃`�F�b�N */
int check_conj(p,q)   /* Check conjunction according to conjtabl */
   int p, q;
{
   int  qx, qy, val;
   char tmp;

   qx = q/8;
   qy = q%8;
   tmp = 0x01;

   if((conjtabl[p][qx] & tmp<<qy)==0)
      return(0);
   else
      return(1);
}

/*-------------------------------------------------------------------------
  �o�͂̏���
-------------------------------------------------------------------------*/
/* ���s�҂� */
void wait_return()                                    /* Waiting Routine */
{
   char dmystr[80];

   printf("... please return >");
   gets(dmystr);
}

/**************************************************************************
  �ڑ��e�[�u���𑀍삷��T�u���[�`��
**************************************************************************/
/*-------------------------------------------------------------------------
  �f�[�^�t�@�C���̓ǂݍ��� (0)
-------------------------------------------------------------------------*/
void read_file()
{
   int i, j;
   char cc;
   char name[80]; /* �t�@�C������80�����܂ŉ� */
   FILE *fp_in;

   printf("\n%s\n","�f�[�^�t�@�C���̓ǂݍ���");
   top:;
   printf("%s","�t�@�C���� >");
   gets(name);
   

   if( NULL == (fp_in = fopen( name, "r" ))){
      printf("error: fopen !\n");
      goto top;
   }

   for(i=0; i<=MAXMORP; i++){
      for(j=0; j<(MAXMORP+1)/8; j++){
         cc=fgetc(fp_in);
         conjtabl[i][j] = cc;
         /* �����ł́A�t�@�C��name�̐擪����512*512/8=32768 byte�� */
         /* eof������悤������܂����A�����ēǂݍ��ށB���������āA*/
         /* 32768 byte���t�@�C�����������ƁA�ʂ̃t�@�C���̈��   */
         /* �ǂ�ł��܂����Ƃ����肤��̂Œ��ӁBeof�̌��o�����Ȃ�  */
         /* �̂́A�ڑ��e�[�u���f�[�^����eof�Ɠ����R�[�h��������  */
         /* �\�������邽�� */
      }
   }

   fclose(fp_in);
   bell();
}

/*-------------------------------------------------------------------------
  �����^�f�[�^�t�@�C���̓ǂݍ��� (1)
-------------------------------------------------------------------------*/
void give_data(left,right,type)
   int left[MAXDATA], right[MAXDATA], type;
{
   int i, j;

   if(type == 0){			/* axp, bxq, cxr, ... */
      for(i=0;left[i]<512;i++){
         for(j=0;right[j]<512;j++){
            entry_conj(left[i],right[j],1);
         }
      }
   }
   else if(type == 1){		/* a,b,c,... x p-q */
      for(i=0;left[i]<512;i++){
         for(j=right[0];j<=right[1];j++){
            entry_conj(left[i],j,1);
         }
      }
   }
   else if(type == 2){		/* a-b x p,q,r,... */
      for(i=left[0];i<=left[1];i++){
         for(j=0;right[j]<512;j++){
            entry_conj(i,right[j],1);
         }
      }
   }
   else if(type == 3){		/* a-b x p-q */
      for(i=left[0];i<=left[1];i++){
         for(j=right[0];j<=right[1];j++){
            entry_conj(i,j,1);
         }
      }
   }
   else{
      printf("error: type >= 4\n");
   }
}

/*-----------------------------------------------------------------------*/
void read_docu()
{
   int i, code, line;
   int type, left[MAXDATA], right[MAXDATA];
   int index; /* left,right��index */
   char whereis; /* t:��̐擪�Al:���̃R�[�h��Ax:x�Ar:�E�̃R�[�h�� */
   char name[80], cc, str[MAXSENT];
   FILE *fp_in;

   printf("\n%s\n","�����^�f�[�^�t�@�C���̓ǂݍ���");
   top:;
   printf("%s","�t�@�C���� >");
   gets(name);

   if( NULL == (fp_in = fopen( name, "r" ))){
      printf("error: fopen !\n");
      goto top;
   }

   /* �f�[�^�̌`�� */
   /* type 0: left[0],left[1], ... x right[0],right[1], ... */
   /*      1: left[0],left[1], ... x right[0]-right[1]      */
   /*      2: left[0]-left[1]      x right[0],right[1], ... */
   /*      3: left[0]-left[1]      x right[0]-right[1]      */
   /* '*'�ł͂��܂�s�̓R�����g�s�A�f�[�^�s�Ƃ̍��݂͕s�� */

   whereis = 't';  type = 0;  index = 0;	/* �����l�ݒ� */
   line = 0;
   for(i=0;i<MAXDATA;i++){
      left[i] = 999;  right[i] = 999;	/* ������ */
   }

   cc = fgetc(fp_in);	/* �t�@�C���̐擪�P������Ǎ� */
   while(feof(fp_in)==0){
      if(cc == '-'){			/* (0)'-' -> type��ύX */
         if(whereis == 'l') type = type + 2;
         if(whereis == 'r') type = type + 1;
         if(type < 1 || type > 3){
            printf("error: type=%d is wrong. line=%d\n",type,line);
         }
         cc = fgetc(fp_in);
      }
      if(cc == 'x'){			/* (1)'x' -> �E���̗�ɐi */
         whereis = 'x'; index = 0;
         cc = fgetc(fp_in);
      }
      else if(cc == '*'){		/* (2)'*' -> LF�܂œǔ� */
         while(cc != 0x0A) cc = fgetc(fp_in);
         if(whereis == 'l' || whereis == 'x'){
            printf("error: whereis=%c is wrong. line=%d\n",whereis,line);
         }
         cc = fgetc(fp_in);	/* ���s���P���Ǎ� */
         whereis = 't'; type = 0; index = 0; line++;
      }
      else if(cc == 0x0A){		/* (3)LF -> edit_data�A���s�Ǎ� */
         /* printf("type=%d\n",type); */
         give_data(left,right,type);
         if(whereis == 'l' || whereis == 'x'){
            printf("error: whereis=%c is wrong. line=%d\n",whereis,line);
         }
         cc = fgetc(fp_in);	/* ���s���P���Ǎ� */
         whereis = 't'; type = 0; index = 0; line++;
         for(i=0;i<MAXDATA;i++){
            left[i] = 999;  right[i] = 999; /* ������ */
         }
      }
      else if(cc >= '0' && cc <= '9'){	/* (4)���� -> ������̒��o */
         i = 0; code = 0;
         if(whereis == 't') whereis = 'l';
         else if(whereis == 'x') whereis = 'r';
         while(cc >= '0' && cc <= '9'){
            code = code * 10 + (cc - '0');
            str[i] = cc;
            i++;
            cc = fgetc(fp_in);
         }
         if(code < 0 || code > MAXMORP){
            printf("error: code=%03d is out of range. line=%d",code,line);
         }
         else{
            if(whereis == 'l') left[index] = code;
            else if(whereis == 'r') right[index] = code;
            str[i] = '\0';
            /* printf("%c%03d:code=%s=%03d\n",whereis,index,str,code); */
            index++; /* ���̐������index */
         }
      }
      else{				/* (5)���̑� -> ����ǂ� */
         cc = fgetc(fp_in);
      }
   }

   fclose(fp_in);
}

/*-------------------------------------------------------------------------
  �ڑ����̕\�� (2)
-------------------------------------------------------------------------*/
/* �ڑ����̕\���A���j���[ */
void show_data()
{
   char sel, dmystr[80];

   while(1){
      printf("\n--Show Data Menu--\n");
      printf("%s\n>","0 : �͈͎w��   1 : ���w��   2 : �E�w��   Q : TOP MENU");

      scanf("%c",&sel);
      gets(dmystr);
      switch(sel){
         case '0': show_data0(); break;
         case '1': show_data1(); break;
         case '2': show_data2(); break;
         default : break;
      }
      if(sel=='q' || sel=='Q') break;
   }
}
/*-----------------------------------------------------------------------*/
/* �ڑ����̕\���A�͈͎w�� */
void show_data0()
{
   int i, j, rbegin, rend, lbegin, lend;
   long lli, llj;
   char buffi[RSIZE+1], buffj[RSIZE+1];
   char substri[RSIZE+1], substrj[RSIZE+1];
   char sel, dmystr[80];
   FILE *fp_in;

   if(NULL ==(fp_in  = fopen( "edihead.txt", "rb" ))){
      printf("can't find edihead.txt !\n");
      return;
   }

   printf("\nI'll show data.");
   while(1){
      printf("\n%s (rbegin-rend,lbegin-lend) >","�͈͂�?");
      scanf("%d - %d , %d - %d",&rbegin,&rend,&lbegin,&lend);
      gets(dmystr);
      if(rbegin>rend || rbegin<0 || rend>MAXMORP
          || lbegin>lend || lbegin<0 || lend>MAXMORP){
         printf("range error !\n");
      }
      else{
         for(i=rbegin;i<=rend;i++){
            lli = (long)i * (long)RSIZE;
            if(0 != fseek(fp_in, lli, 0)){
               printf("error fseek !\n");
               return;
            }
            if(1 > fread(buffi, RSIZE-CRLEN, 1, fp_in)){
               printf("error fread !\n");
               return;
            }
            buffi[RSIZE-CRLEN] = 0;
            substring(buffi,HEADTOP,RSIZE-CRLEN,substri);
   
            for(j=lbegin;j<=lend;j++){
               llj = (long)j * (long)RSIZE;
               if(0 != fseek(fp_in, llj, 0)){
                  printf("error fseek !\n");
                  return;
               }
               if(1 > fread(buffj, RSIZE-CRLEN, 1, fp_in)){
                  printf("error fread !\n");
                  return;
               }
               buffj[RSIZE-CRLEN] = 0;
               substring(buffj,HEADTOP,RSIZE-CRLEN,substrj);
   
               printf("%s%s  (%3d,%3d)%3d\n",
                                  substri,substrj,i,j,check_conj(i,j));
            /* printf("(%3d,%3d)%3d\n",
                                  i,j,check_conj(i,j)); */
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
   fclose(fp_in);
}

/*-----------------------------------------------------------------------*/
/* �ڑ����̕\���A���w�� */
void show_data1()
{
   int i, j, code, c;
   long lli, llj;
   char buffi[RSIZE+1], buffj[RSIZE+1];
   char substri[RSIZE+1], substrj[RSIZE+1];
   char sel, dmystr[80];
   FILE *fp_in;

   if(NULL ==(fp_in  = fopen( "edihead.txt", "rb" ))){
      printf("can't find edihead.txt !\n");
      return;
   }

   printf("\nI'll show data.");

   while(1){
      printf("\n%s 0..511 >","���̃R�[�h��?");
      scanf("%d",&code);  gets(dmystr);

      if(code<0 || code>MAXMORP){
         break;
         /* printf("error !\n"); */
      }
      else{
         i=code;
         lli = (long)i * (long)RSIZE;
         if(0 != fseek(fp_in, lli, 0)){
            printf("error fseek !\n");
            break;
         }
         if(1 > fread(buffi, RSIZE-CRLEN, 1, fp_in)){
            printf("error fread !\n");
            break;
         }
         buffi[RSIZE-CRLEN] = 0;
         substring(buffi,HEADTOP,RSIZE-CRLEN,substri);

         for(j=0;j<=MAXMORP;j++){
            llj = (long)j * (long)RSIZE;
            if(0 != fseek(fp_in, llj, 0)){
               printf("error fseek !\n");
               break;
            }
            if(1 > fread(buffj, RSIZE-CRLEN, 1, fp_in)){
               printf("error fread !\n");
               break;
            }
            buffj[RSIZE-CRLEN] = 0;
            substring(buffj,HEADTOP,RSIZE-CRLEN,substrj);

            c = check_conj(i,j);
            if(c == 1){
               printf("%s%s  (%3d,%3d)%3d\n",
                               substri,substrj,i,j,check_conj(i,j));
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
   fclose(fp_in);
}

/*-----------------------------------------------------------------------*/
/* �ڑ����̕\���A�E�w�� */
void show_data2()
{
   int i, j, code, c;
   long lli, llj;
   char buffi[RSIZE+1], buffj[RSIZE+1];
   char substri[RSIZE+1], substrj[RSIZE+1];
   char sel, dmystr[80];
   FILE *fp_in;

   if(NULL ==(fp_in  = fopen( "edihead.txt", "rb" ))){
      printf("can't find edihead.txt !\n");
      return;
   }

   printf("\nI'll show data.");

   while(1){
      printf("\n%s 0..511 >","�E�̃R�[�h��?");
      scanf("%d",&code);  gets(dmystr);

      if(code<0 || code>MAXMORP){
         break;
         /* printf("error !\n"); */
      }
      else{
         for(i=0;i<=MAXMORP;i++){
            lli = (long)i * (long)RSIZE;
            if(0 != fseek(fp_in, lli, 0)){
               printf("error fseek !\n");
               break;
            }
            if(1 > fread(buffi, RSIZE-CRLEN, 1, fp_in)){
               printf("error fread !\n");
               break;
            }
            buffi[RSIZE-CRLEN] = 0;
            substring(buffi,HEADTOP,RSIZE-CRLEN,substri);

            j=code;
            llj = (long)j * (long)RSIZE;
            if(0 != fseek(fp_in, llj, 0)){
               printf("error fseek !\n");
               break;
            }
            if(1 > fread(buffj, RSIZE-CRLEN, 1, fp_in)){
               printf("error fread !\n");
               break;
            }
            buffj[RSIZE-CRLEN] = 0;
            substring(buffj,HEADTOP,RSIZE-CRLEN,substrj);

            c = check_conj(i,j);
            if(c == 1){
               printf("%s%s  (%3d,%3d)%3d\n",
                       substri,substrj,i,j,check_conj(i,j));
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
   fclose(fp_in);
}

/*-------------------------------------------------------------------------
  �ڑ����̓��� (3)
-------------------------------------------------------------------------*/
/* �ڑ����̓��́A���j���[ */
void edit_data()
{
   char sel, dmystr[80];

   while(1){
      printf("\n--Give Data Menu--\n");
      printf("%s\n", "0 :�͈͎w��   1 :���w��    2 :�E�w��   3 :�g�w��");
      printf("%s\n>","4 :�E�𕡎�   5 :���𕡎�  6 :������   Q :TOP MENU");

      scanf("%c",&sel);  gets(dmystr);
      switch(sel){
         case '0': edit_data0(); break;
         case '1': edit_data1(); break;
         case '2': edit_data2(); break;
         case '3': edit_data3(); break;
         case '4': edit_data4(); break;
         case '5': edit_data5(); break;
         case '6': edit_data6(); break;
         default : break;
      }
      if(sel=='q' || sel=='Q') break;
   }
}
/*-----------------------------------------------------------------------*/
/* �ڑ����̓��́A�͈͎w�� */
void edit_data0()
{
   int i, j, lbegin, lend, rbegin, rend, val;
   char sel, dmystr[80];

   printf("\n%s \n","�͈͂ƒl��?");

   while(1){
      printf("(lbegin-lend,rbegin-rend,0/1) >");
      scanf("%d - %d , %d - %d , %d",&lbegin,&lend,&rbegin,&rend,&val);
      gets(dmystr);

      if(lbegin>lend || lbegin<0 || lend>MAXMORP
          || rbegin>rend || rbegin<0 || rend>MAXMORP
          || (val!=0 && val!=1) ){
         printf("range error !\n");
         break;
      }
      else{
         for(i=lbegin;i<=lend;i++){
            for(j=rbegin;j<=rend;j++){
               entry_conj(i,j,val);
               /* printf("(left,right,0/1) = (%3d,%3d,%2d )\n",
                                      i,j,val); */
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
}

/*-----------------------------------------------------------------------*/
/* �ڑ����̓��́A���w�� */
void edit_data1()
{
   int  left, right, lend, rend, i, j;
   long lll, llr;
   char buffl[RSIZE+1], buffr[RSIZE+1];
   char substrl[RSIZE+1], substrr[RSIZE+1];
   char sel, dmystr[80];
   FILE *fp_in;

   if(NULL ==(fp_in  = fopen( "edihead.txt", "rb" ))){
      printf("edihead.txt���Ȃ� !\n");
      return;
   }

   printf("\n%s (lbegin-lend) >","���̃R�[�h��?");
   scanf("%d - %d",&left,&lend);
   gets(dmystr);
   if(left<0 || left>MAXMORP
       || lend<0 || lend>MAXMORP || left>lend){
      printf("error !\n");
      return;
   }

   lll = (long)left * (long)RSIZE;
   if(0 != fseek(fp_in, lll, 0)){
      printf("error !\n");
      return;
   }
   if(1 > fread(buffl, RSIZE-CRLEN, 1, fp_in)){
      printf("error fread !\n");
      return;
   }
   buffl[RSIZE-CRLEN] = 0;
   substring(buffl,HEADTOP,RSIZE-CRLEN,substrl);
   printf("  left = %s\n",substrl);

   while(1){
      printf("%s (rbegin-rend) >","�E�̃R�[�h��?");
      scanf("%d - %d",&right,&rend);
      gets(dmystr);
      if(right<0 || right>MAXMORP
          || rend<0 || rend>MAXMORP || right>rend ){
         printf("range error !\n");
         break;
      }
      else{
         llr = (long)right * (long)RSIZE;
         if(0 != fseek(fp_in, llr, 0)){
            printf("error fseek !\n");
            break;
         }
         if(1 > fread(buffr, RSIZE-CRLEN, 1, fp_in)){
            printf("error fread !\n");
            break;
         }
         buffr[RSIZE-CRLEN] = 0;
         substring(buffr,HEADTOP,RSIZE-CRLEN,substrr);
         /* printf("  right = %s\n",substrr); */
         printf("%s%s  (%3d,%3d)\n",
                 substrl,substrr,left,right);

         for(i=left;i<=lend;i++){
            for(j=right;j<=rend;j++){
               entry_conj(i,j,1);
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
}

/*-----------------------------------------------------------------------*/
/* �ڑ����̓��́A�E�w�� */
void edit_data2()
{
   int  left, right, lend, rend, i, j;
   long lll, llr;
   char buffl[RSIZE+1], buffr[RSIZE+1];
   char substrl[RSIZE+1], substrr[RSIZE+1];
   char sel, dmystr[80];
   FILE *fp_in;

   if(NULL ==(fp_in  = fopen( "edihead.txt", "rb" ))){
      printf("can't find edihead.txt !\n");
      return;
   }

   printf("\n%s (rbegin-rend) >","�E�̃R�[�h��?");
   scanf("%d - %d",&right,&rend);
   gets(dmystr);
   if(right<0 || right>MAXMORP
       || rend<0 || rend>MAXMORP || right>rend){
      printf("error !\n");
      return;
   }

   llr = (long)right * (long)RSIZE;
   if(0 != fseek(fp_in, llr, 0)){
      printf("error fseek !\n");
      return;
   }
   if(1 > fread(buffr, RSIZE-CRLEN, 1, fp_in)){
      printf("error fread !\n");
      return;
   }
   buffr[RSIZE-CRLEN] = 0;
   substring(buffr,HEADTOP,RSIZE-CRLEN,substrr);
   printf("  right = %s\n",substrr);

   while(1){
      printf("%s (lbegin-lend) >","���̃R�[�h��?");
      scanf("%d - %d",&left,&lend);
      gets(dmystr);
      if(left<0 || left>MAXMORP
          || lend<0 || lend>MAXMORP || left>lend ){
         printf("range error !\n");
         break;
      }
      else{
         lll = (long)left * (long)RSIZE;
         if(0 != fseek(fp_in, lll, 0)){
            printf("error fseek !\n");
            break;
         }
         if(1 > fread(buffl, RSIZE-CRLEN, 1, fp_in)){
            printf("error fread !\n");
            break;
         }
         buffl[RSIZE-CRLEN] = 0;
         substring(buffl,HEADTOP,RSIZE-CRLEN,substrl);
         /* printf("  left = %s\n",substrl); */
         printf("%s%s  (%3d,%3d)\n",
                 substrl,substrr,left,right);

         for(i=left;i<=lend;i++){
            for(j=right;j<=rend;j++){
               entry_conj(i,j,1);
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
}

/*-----------------------------------------------------------------------*/
/* �ڑ����̓��́A�g�w�� */
void edit_data3()
{
   int i, j, left, right, val;
   char sel, dmystr[80];

   printf("\n%s \n","�͈͂ƒl��?");

   while(1){
      printf("(left,right,0/1) >");
      scanf("%d , %d , %d",&left,&right,&val);
      gets(dmystr);

      if(left<0 || left>MAXMORP
          || right<0 || right>MAXMORP
          || (val!=0 && val!=1) ){
         printf("range error !\n");
         break;
      }
      else{
               entry_conj(left,right,val);
               /* printf("(left,right,0/1) = (%3d,%3d,%2d )\n",
                                      i,j,val); */
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
}

/*-----------------------------------------------------------------------*/
/* �ڑ����̓��́A�E�ڑ��̃R�s�[ */
void edit_data4()
{
   int i, orig, targ;
   char sel, dmystr[80];

   printf("\n%s","�E�ڑ��̃R�s�[");
   printf("\ncopy from orig to targ\n");

   while(1){
      printf("(orig,targ) >");
      scanf("%d , %d",&orig,&targ);
      gets(dmystr);

      if(orig<0 || orig>MAXMORP
          || targ<0 || targ>MAXMORP){
         printf("range error !\n");
         break;
      }
      else{
         for(i=0;i<=MAXMORP;i++){
            if(check_conj(orig,i)==1){
               entry_conj(targ,i,1);
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
}

/*-----------------------------------------------------------------------*/
/* �ڑ����̓��́A���ڑ��̃R�s�[ */
void edit_data5()
{
   int i, orig, targ;
   char sel, dmystr[80];

   printf("\n%s","���ڑ��̃R�s�[");
   printf("\ncopy from orig to targ\n");

   while(1){
      printf("(orig,targ) >");
      scanf("%d , %d",&orig,&targ);
      gets(dmystr);

      if(orig<0 || orig>MAXMORP
          || targ<0 || targ>MAXMORP){
         printf("range error !\n");
         break;
      }
      else{
         for(i=0;i<=MAXMORP;i++){
            if(check_conj(i,orig)==1){
               entry_conj(i,targ,1);
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
}

/*-----------------------------------------------------------------------*/
/* �ڑ����̓��́A�ڑ��̏����� */
void edit_data6()
{
   int i, j, side, begin, end;
   char sel, dmystr[80];

   printf("\n%s \n","��������������?");
   printf("%s","(����=0, �E�̂�=1, ���̂�=2) >");
      scanf("%d",&side);  gets(dmystr);

   printf("\n%s \n","�������������R�[�h?");

   while(1){
      printf("(begin-end) >");
      scanf("%d - %d",&begin,&end);
      gets(dmystr);

      if(begin>end || begin<0 || end>MAXMORP){
         printf("range error !\n");
         break;
      }
      else{
         for(i=begin;i<=end;i++){
            for(j=0;j<=MAXMORP;j++){
               if(side==0 || side==1) entry_conj(i,j,0);
               if(side==0 || side==2) entry_conj(j,i,0);
               if(side<0  || side>2) printf("\nerror !");
            }
         }
      }
      printf("continue? (y/n)>");
      scanf("%c",&sel);  gets(dmystr);
      if(sel=='n' || sel=='N') break;
   }
}

/*-------------------------------------------------------------------------
  �f�[�^�t�@�C���̍쐬 (4)
-------------------------------------------------------------------------*/
/* �f�[�^�t�@�C���̍쐬 */
void make_file()
{
   int i, j;
   char name[80];
   FILE *fp_out;

   printf("\n%s\n","�f�[�^�t�@�C���̍쐬");
   top:;
   printf("%s","�t�@�C���� >");
   gets(name);

   if( NULL == (fp_out = fopen( name, "w" ))){
      printf("error: fopen !\n");
      goto top;
   }

   for(i=0; i<=MAXMORP; i++){
      for(j=0; j<(MAXMORP+1)/8; j++){
         fprintf(fp_out,"%c",conjtabl[i][j]);
         /* �����ł́A512*512/8=32768 byte�������o���̂ŁA */
         /* �t�@�C��name�̑傫���͕K��32768 byte�ɂȂ�     */
      }
   }

   fclose(fp_out);
   bell();
}

