/*=========================================================================
sepapc_g.h
							1991.	7.5.
�i�ύX���j
91.7.5.		���߂č쐬
91.8.13.	conjtabl��ύX
=========================================================================*/
/*/////////////////////////////////////////////////////////////////////////
  ���ϐ��̋L���N���X�̒�`
/////////////////////////////////////////////////////////////////////////*/
extern FILE *fp1, *fp2, *fp3, *fpp, *fp_suc, *fp_fai, *fp_kiji, *fopen();

extern struct node xnode[MAXNODE];

extern struct ilist *headtabl[MAXIN]; /* this is a table according to */
                                      /*   position of 'head' */

extern int    num_nodes, num_plus, num_minus, num_solutions;
extern int    min_magic;
extern int    cutting_point;
extern int    max_nbest, max_pass_time;
extern int    pass_time;
extern int    len_initstr;

extern char   conjtabl[MAXMORP+1][(MAXMORP+1)/8]; /* �`�ԑf�e�[�u�� 512x512 */

extern struct slist *solutions;
extern struct worddata plusdata[MAXSUPPL];  /* �ǉ��P�� */
extern struct worddata minusdata[MAXSUPPL]; /* �폜�P�� */

