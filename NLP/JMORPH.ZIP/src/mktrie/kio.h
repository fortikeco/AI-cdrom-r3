/*
 *	kio.h
 *			(C) Copyright 1991, All rights reserved by ICOT
 */

#ifndef	_KIO_H_
#define	_KIO_H_

int read_line();
void write_line();

extern char kanji_shift_in[];
extern char kanji_shift_out[];

#endif	_KIO_H_
