/*
 *	define.h
 *			(C) Copyright 1991, All rights reserved by ICOT
 */

#ifndef _DEFINE_H_
#define _DEFINE_H_

typedef int bool;

#ifndef TRUE
#define	TRUE	1
#endif
#ifndef FALSE
#define	FALSE	0
#endif

#ifndef	NULL
#define NULL	0
#endif

#endif _DEFINE_H_
