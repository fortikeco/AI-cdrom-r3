/*
 *	config.h
 *			(C) Copyright 1991, All rights reserved by ICOT
 */

#ifndef _CONFIG_H_
#define _CONFIG_H_

#define FILE_NAME_SIZE		64
#define	MAX_LINE		1024

#define MAX_YOMI		64
#define	MAX_MIDASIGO		32
#define	NUM_MIDASIGO		2048
#define	MAX_PATH_RECORDS	(MAX_MIDASIGO * NUM_MIDASIGO)

#define FILE_OFFSET_SIZE	4
#define CHAR_SIZE		2

#define PATH_HEAD_SIZE		4
#define PATH_REC_SIZE		(FILE_OFFSET_SIZE + CHAR_SIZE)
#define	MAX_PATH_TBL\
    (PATH_HEAD_SIZE + PATH_REC_SIZE * NUM_MIDASIGO)

#define INFO_HEAD_SIZE		2
#define INFO_HINSI_SIZE		2
#define INFO_YOMI_SIZE		2

#define INFO_SYNONYM		32

#define	MAX_INFO_TBL\
    (INFO_HEAD_SIZE + (INFO_HINSI_SIZE + CHAR_SIZE * MAX_YOMI) * INFO_SYNONYM)

#define ROOT_BASE		0x2121
#define PATH_BASE		0x4

#define S_DEPTH			16
#define	S_WIDTH			INFO_SYNONYM
#define	S_STRL			MAX_YOMI

#endif _CONFIG_H_
