/*
 *	wchar.h
 *			(C) Copyright 1991, All rights reserved by ICOT
 */

#ifndef	_W_CHAR_H_
#define	_W_CHAR_H_

typedef unsigned short w_char_t;

#define KANJI_SPACE	((w_char_t)0x2121)
#define	ISspace(bp)\
  (((bp) & (w_char_t)0xFF00) ? (bp) == KANJI_SPACE: isspace((char)(bp)))

#endif	_W_CHAR_H_
