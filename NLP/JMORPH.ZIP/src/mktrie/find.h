/*
 *	find.h
 *			(C) Copyright 1991, All rights reserved by ICOT
 */

#ifndef	_FIND_H_
#define	_FIND_H_

extern FILE *root_fp, *path_fp, *info_fp;

void searchw();

#endif	_FIND_H_
