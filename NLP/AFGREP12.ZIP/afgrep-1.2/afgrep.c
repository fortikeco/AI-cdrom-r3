/*
 * $Id: afgrep.c,v 1.2 1992/12/06 00:11:56 mleisher Exp mleisher $
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

typedef enum {false = 0, true = 1} boolean;

typedef struct _patnode {
    int idx;
    struct _patnode *next;
} patnode;

static patnode *hashtable[8192];

static boolean patshort = false;

static unsigned char *buf;
static unsigned char *bufend;
static unsigned long bufsize = 0L;

static unsigned char *pats[30000];
static unsigned long num_pats = 0L;
static unsigned char shifts[4096];

static char *program;

static unsigned long good_size = 256L;

static boolean initialized = false;

static boolean matched = false;

static unsigned char tr[256];
static unsigned char trmasked[256];

static int begin_offset = 0;

/*
 * User specifiable flags.
 */
static boolean must_match_begin = false;
static boolean count_matched_lines = false;
static boolean no_filenames = false;
static boolean display_filenames = false;
static boolean case_insensitive = false;
static boolean only_filenames = false;
static boolean line_numbers = false;
static boolean silent = false;
static boolean invert = false;
static boolean exact = false;

static unsigned long matched_lines = 0L;
static unsigned long lineno = 0L;
static char *current_file = (char *) NULL;

#ifndef MIN
#define MIN(l, o) ((l) < (o) ? (l) : (o))
#endif

static void
initialize()
{
    if (initialized == true)
      return;

    (void) memset((char *) shifts, good_size - 2, 4096);
    (void) memset((char *) hashtable, 0, sizeof(patnode *) * 8192);

    initialized = true;
}

static void
cleanup()
{
    int i;
    patnode *ppn, *pn;

    if (bufsize > 0)
      free((char *) buf);

    for (i = 0; i < 8192; i++) {
        if (hashtable[i] != (patnode *) NULL) {
            pn = ppn = hashtable[i];
            pn = ppn->next;
            while (ppn != (patnode *) NULL) {
                free((char *) ppn);
                ppn = pn;
                if (ppn != (patnode *) NULL)
                  pn = ppn->next;
            }
        }
    }
}

static int
prep_patterns()
{
    register unsigned char *bp = buf, *pp;
    unsigned long len, hashcode, mask = 0xf;
    int i, j, lo;
    patnode *pn;

    /*
     * Build the pattern list.
     */
    bp = buf;
    pats[num_pats++] = bp;
    while (bp < bufend) {
        if (num_pats == 30000) {
            /*
             * Too many patterns.
             */
            free((char *) buf);
            return -4;
        }
        while (bp < bufend && *bp != '\n')
          bp++;
        *bp = '\0';
        len = bp - pats[num_pats - 1];
        if (len > 0) {
            good_size = MIN(good_size, len);
            if ((bp + 1) < bufend) {
                bp++;
                pats[num_pats++] = bp;
            }
        }
    }

    if (num_pats == 1 && buf[0] == '\0') {
        /*
         * No patterns.
         */
        free((char *) buf);
        return -5;
    }

    if (good_size == 1)
      patshort = true;

    if (initialized == false)
      initialize();

    /*
     * This routine assumes an ISO8859-1 codeset but doesn't handle the
     * German es-zed lower/upper forms, only an exact match on es-zed.
     */
    for (i = 0; i < 256; i++) {
        tr[i] = i;
        if (case_insensitive == true &&
            (('A' <= i && i <= 'Z') ||
             (192 <= i && i <= 214) ||
             (216 <= i && i <= 222)))
          tr[i] += 32;
        trmasked[i] = tr[i] & mask;
    }

    if (patshort == true)
      mask = 0xff;

    lo = (patshort == false) ? 2 : 1;
    for (i = 0; i < num_pats; i++) {
        pp = pats[i];
        for (j = good_size - 1; j >= lo; j--) {
            hashcode = ((pp[j] & mask) << 4) + (pp[j - 1] & mask);
            if (patshort == false)
              hashcode = (hashcode << 4) + (pp[j - 2] & mask);
            if (shifts[hashcode] >= good_size - 1 - j)
              shifts[hashcode] = good_size - 1 - j;
        }
        for (hashcode = 0L, j = good_size - 1; j >= 0; j--)
          hashcode = (hashcode << 4) + (tr[pp[j]] & mask);
        hashcode &= 8191;

        pn = (patnode *) malloc(sizeof(patnode));
        pn->idx = i;
        pn->next = hashtable[hashcode];
        hashtable[hashcode] = pn;
    }
}

static int
prepfile(int fd)
{
    struct stat st;

    if (fstat(fd, &st) < 0)
      return -1;

    if (st.st_size <= 0)
      return -2;

    bufsize = (unsigned long) st.st_size;
    buf = (unsigned char *) malloc(bufsize);
    if (read(fd, (char *) buf, bufsize) != bufsize) {
        free((char *) buf);
        return -3;
    }
    bufend = buf + bufsize;

    return prep_patterns();
}

static void
add_cmd_line_pattern(unsigned char *pattern)
{
    register unsigned char *dp;
    unsigned int plen;

    if (num_pats == 30000) {
        fprintf(stderr, "%s: too many patterns on command line.\n", program);
        return;
    }
    plen = strlen(pattern);

    if (bufsize == 0)
      buf = (unsigned char *) malloc(sizeof(unsigned char) * (plen + 1));
    else
      buf = (unsigned char *) realloc((char *) buf,
                                      sizeof(unsigned char) *
                                      (bufsize + plen + 1));
    dp = buf + bufsize;
    (void) memcpy((char *) dp, (char *) pattern, plen);
    *(dp + plen) = '\n';
    bufsize += plen + 1;
    bufend = buf + bufsize;
}

#ifdef __GNUC__
inline boolean
#else
static boolean
#endif
cmp(unsigned char *s1, unsigned char *s2, int len)
{
    while (len-- > 0 && *s1++ == *s2++) ;
    return (len < 0) ? true : false;
}

static boolean
monkeyshort(unsigned char *l, unsigned int llen)
{
    register unsigned char *lp, *le, *ps, *txt;
    int i, pslen;
    patnode *pn;

    if (must_match_begin == true && (int) llen - begin_offset < 0)
      return false;

    le = l + llen;
    lp = (l - 1) + begin_offset;

    while (++lp <= le) {
        pn = hashtable[*lp];

        /*
         * If the string doesn't hash to something, and the
         * 'exact' or 'must_match_begin' flag was set, then we already know
         * a match hasn't occured.
         */
        if (pn == (patnode *) NULL &&
            (exact == true || must_match_begin == true))
          return false;
        else if (pn != (patnode *) NULL) {
            /*
             * Now we have to match against all of the
             * patterns that fit this hash code to find out if we
             * really have a match.  Terminate the search on the
             * first match.
             */
            while (pn != (patnode *) NULL) {
                ps = pats[pn->idx];
                pslen = (pn->idx == num_pats - 1) ?
                  ((bufend - 1) - ps) : (pats[pn->idx + 1] - ps);
                pslen--;
                pn = pn->next;
                txt = lp - (good_size - 1);
                if (exact == true) {
                    if (pslen == llen && cmp(txt, ps, llen) == true)
                      return true;
                    continue;
                }
                i = 0;
                while (txt < le && tr[*ps++] == tr[*txt++]) i++;
                if (i > (good_size - 1)) {
                    /*
                     * Return true on the first match.
                     */
                    if (pslen <= i)
                      return true;
                }
            }
        }
    }
    return false;
}

static boolean
monkeylong(unsigned char *l, unsigned int llen)
{
    register unsigned char *lp, *le, *ps, *txt;
    register unsigned long hashcode;
    unsigned char shift;
    int i, pslen;
    patnode *pn;

    if (must_match_begin == true && (int) llen - begin_offset < 0)
      return false;

    le = l + llen;
    lp = l + (good_size - 1) + begin_offset;

    while (lp <= le) {
        hashcode = (trmasked[*lp] << 4) + trmasked[*(lp - 1)];
        if (good_size > 1)
          hashcode = (hashcode << 4) + trmasked[*(lp - 2)];
        shift = shifts[hashcode];

        /*
         * If a shift value is found and the 'exact' or
         * 'must_match_begin' flag was set, then we know already that
         * a match has not occured.
         */
        if (shift != 0 && (exact == true || must_match_begin == true))
          return false;
        else if (shift == 0) {

            for (hashcode = 0L, i = 0; i <= good_size - 1; i++)
              hashcode = (hashcode << 4) + trmasked[*(lp - i)];
            hashcode &= 8191;
            pn = hashtable[hashcode];

            /*
             * If the string doesn't hash to something, and the 'exact' or
             * 'must_match_begin' flag was set, then we already know
             * a match hasn't occured.
             */
            if (pn == (patnode *) NULL &&
                (exact == true || must_match_begin == true))
              return false;
            else if (pn != (patnode *) NULL) {
                /*
                 * Now we have to match against all of the
                 * patterns that fit this hash code to find out if we
                 * really have a match.  Terminate the search on the
                 * first match.
                 */
                while (pn != (patnode *) NULL) {
                    ps = pats[pn->idx];
                    pslen = (pn->idx == num_pats - 1) ?
                      ((bufend - 1) - ps) : (pats[pn->idx + 1] - ps);
                    pslen--;
                    pn = pn->next;
                    txt = lp - (good_size - 1);
                    if (exact == true) {
                        if (pslen == llen && cmp(txt, ps, llen) == true)
                          return true;
                        continue;
                    }
                    i = 0;
                    while (txt < le && tr[*ps++] == tr[*txt++]) i++;
                    if (i > (good_size - 1)) {
                        /*
                         * Return true on the first match.
                         */
                        if (pslen <= i)
                          return true;
                    }
                }
            }
            shift = 1;
        }
        lp += shift;
    }
    return false;
}

static unsigned char chunk[8192];
static int chunklen = 0;

static unsigned char line[8192];
static int linelen = 0;

static void
afgrep(int fd)
{
    /*
     * Chew up a line and call the appropriate matcher.
     */
    register unsigned char *cp, *ls, *le;
    boolean (*mfunc)(unsigned char *, unsigned int);

    chunklen = linelen = 0;
    mfunc = (patshort == false) ? monkeylong : monkeyshort;

    ls = le = (unsigned char *) line;
    while (1) {
        if (chunklen <= 0) {
            chunklen = read(fd, (char *) chunk, 8192);
            if (chunklen <= 0)
              break;
            cp = (unsigned char *) chunk;
        }
        while (chunklen-- > 0 && *cp != '\n')
          *le++ = *cp++;

        if (chunklen < 0 && *(cp - 1) != '\n')
          continue;

        *le = '\0';

        lineno++;
        if (le - ls > 0 && (*mfunc)(ls, le - ls) != invert) {
            matched = true;
            matched_lines++;

            /*
             * If we're running silent, then we can simply return
             * on the first match.
             */
            if (silent == true)
              return;

            /*
             * If all they want are the file names that matched something,
             * speed things up by simply returning after the first match.
             */
            if (only_filenames == true) {
                printf("%s\n", current_file);
                return;
            }

            if (display_filenames == true)
              printf("%s: ", current_file);
            if (line_numbers == true)
              printf("%d: ", lineno);
            if (count_matched_lines == false)
              printf("%.*s\n", le - ls, ls);
        }

        if (chunklen > 0 && *cp == '\n')
          cp++;
        le = ls;
    }
    if (count_matched_lines == true)
      printf("%s: %d\n", current_file, matched_lines);
}

static void
usage()
{
    fprintf(stderr, "Usage: %s [-cehilnsvx] [-m[n]] string ", program);
    fprintf(stderr, "[-f string-file] [filename] ...\n");
    fprintf(stderr, "-c\t\tCount the lines that matched.\n");
    fprintf(stderr, "-e string\tA string to look for.\n");
    fprintf(stderr, "-f string-file\tA list of strings to search for.\n");
    fprintf(stderr, "-h\t\tDon't print filenames with line numbers.\n");
    fprintf(stderr, "-i\t\tSearch in a case insensitive way.\n");
    fprintf(stderr, "-l\t\tOnly print filenames that have matches.\n");
    fprintf(stderr, "-m[n]\t\tThe string(s) must (not) match starting 'n' ");
    fprintf(stderr, "from line start.\n");
    fprintf(stderr, "-n\t\tPrint the line numbers.\n");
    fprintf(stderr, "-s\t\tOperate silently with no output.\n");
    fprintf(stderr, "-v\t\tThe string(s) must not match.\n");
    fprintf(stderr, "-x\t\tThe string(s) must match exactly.\n");
    exit(2);
}

#define isdig(c) ((c) >= '0' && (c) <= '9')

static boolean
get_offset(char *param)
{
    int res = 0;

    param += 2;
    while (*param != '\0') {
        if (!isdig(*param))
          return false;
        res = (res * 10) + (*param - '0');
        param++;
    }
    begin_offset = res;
    return true;
}

int
main(int argc, char **argv)
{
    int in = fileno(stdin);
    unsigned char *pat;
    boolean have_pattern_file = false;
    boolean have_cmd_line_pattern = false;
    boolean cmd_line_patterns_prepped = false;
    boolean first = true;
    boolean found_file = false;
    boolean doing_files = false;

    program = argv[0];

    argc--;
    *argv++;

    if (argc == 0)
      usage();

    while (argc > 0) {
        if (doing_files == false && argv[0][0] == '-') {
            switch (argv[0][1]) {
              case 'c':
                count_matched_lines = true;
                break;
              case 'e':
                if (have_pattern_file == true) {
                    cleanup();
                    fprintf(stderr, "%s: strings already loaded from file.\n",
                            program);
                    return 2;
                }
                argc--;
                *argv++;
                add_cmd_line_pattern((unsigned char *) argv[0]);
                have_cmd_line_pattern = true;
                break;
              case 'f':
                if (have_cmd_line_pattern == true) {
                    cleanup();
                    fprintf(stderr,
                            "%s: strings already specified on command line.\n",
                            program);
                    return 2;
                }
                argc--;
                *argv++;
                in = open(argv[0], O_RDONLY);
                if (in < 0) {
                    fprintf(stderr, "%s: problem opening pattern file '%s'\n",
                            program, argv[0]);
                    return 2;
                }
                if (prepfile(in) < 0) {
                    fprintf(stderr, "%s: problem loading pattern file '%s'\n",
                            program, argv[0]);
                    close(in);
                    return 2;
                }
                have_pattern_file = true;
                in = fileno(stdin);
                break;
              case 'h':
                /*
                 * Don't print filenames if some other option
                 * turns them on.
                 */
                no_filenames = true;
                break;
              case 'i':
                /*
                 * Do the search in a case insensitive way.
                 */
                case_insensitive = true;
                break;
              case 'l':
                /*
                 * Only print the filenames, not the matching lines and
                 * not the line numbers.
                 */
                only_filenames = true;
                break;
              case 'm':
                /*
                 * This means that the pattern(s) must match at the beginning
                 * of the line to succeed.  If the 'm' is followed by a
                 * number, use that number as a line beginning offset.
                 */
                must_match_begin = true;
                if (argv[0][2] != '\0') {
                    if (get_offset(argv[0]) == false) {
                        fprintf(stderr, "%s: invalid number in option '%s'\n",
                                program, argv[0]);
                        return 2;
                    }
                }
                break;
              case 'n':
                /*
                 * Turn on line numbering.  Also turn on filename printing,
                 * but turn off filename printing if there is only one
                 * file to be searched.
                 */
                line_numbers = display_filenames = true;
                break;
              case 's':
                /*
                 * This option turns off output.
                 */
                silent = true;
                break;
              case 'v':
                /*
                 * This means that the pattern(s) must not match to
                 * succeed.
                 */
                invert = true;
                break;
              case 'x':
                /*
                 * This means that the whole line must match exactly.
                 */
                exact = true;
                break;
              default:
                if (in != fileno(stdin))
                  close(in);
                fprintf(stderr, "%s: invalid option '%s'\n", program, argv[0]);
                usage();
                break;
            }
        } else {
            /*
             * If we have finished getting all of the command line
             * parameters, make sure to turn off filenames if there
             * is only one file to search.
             */
            if (doing_files == false && argc == 1)
              display_filenames = false;

            /*
             * If the -l option was specified, make sure that
             * it overrides -n.
             */
            if (doing_files == false && only_filenames == true)
              display_filenames = line_numbers = false;

            /*
             * If the -h option was given, make sure that file names
             * are not printed if some other option happened to turn
             * them on.
             */
            if (doing_files == false && no_filenames == true)
              display_filenames = false;

            /*
             * If the -c option was given, do the right thing.
             */
            if (doing_files == false && count_matched_lines == true) {
                only_filenames = line_numbers = no_filenames = false;
                silent = false;
            }

            /*
             * Make sure the 'must_match_begin' flag and its offset
             * are unset if an exact match was specified.
             */
            if (doing_files == false && exact == true) {
                must_match_begin = false;
                begin_offset = 0;
            }

            doing_files = true;

            /*
             * At this point, if a pattern file hasn't been loaded,
             * and this is the first thing encountered that isn't
             * prefixed with a switch, we assume it is the pattern.
             */
            if (have_pattern_file == false &&
                have_cmd_line_pattern == false && first == true) {
                add_cmd_line_pattern((unsigned char *) argv[0]);
                first = false;
                have_cmd_line_pattern = true;
            } else {
                /*
                 * If we reach the stage of opening input files for
                 * searching, make sure that the patterns have been
                 * prepped if they came from the command line.
                 */
                if (have_cmd_line_pattern == true &&
                    cmd_line_patterns_prepped == false) {
                    if (prep_patterns() < 0) {
                        cleanup();
                        fprintf(stderr, "%s: problem prepping the patterns.\n",
                                program);
                        return 2;
                    }
                    cmd_line_patterns_prepped = true;
                }

                in = open(argv[0], O_RDONLY);
                if (in < 0)
                  fprintf(stderr, "%s: problem opening input file '%s'\n",
                          program, argv[0]);
                else {
                    found_file = true;
                    current_file = argv[0];
                    afgrep(in);
                    close(in);
                }
                in = fileno(stdin);
                lineno = 0L;
                matched_lines = 0L;
                current_file = (char *) NULL;
            }
        }
        argc--;
        *argv++;
    }

    /*
     * If the text to search is expected on stdin,
     * make sure the patterns are prepped in case they came
     * from the command line.  Also make sure that filename
     * printing is turned off and make sure the lineno variable is
     * zero'ed out just in case its getting used elsewhere.
     */
    if (found_file == false) {
        if (have_pattern_file == false && have_cmd_line_pattern == false) {
            fprintf(stderr, "%s: no strings specified.\n", program);
            cleanup();
            return 2;
        }

        if (only_filenames == true) {
            fprintf(stderr, "%s: -l option not usable with (stdin).\n",
                    program);
            cleanup();
            return 2;
        }

        lineno = 0L;
        display_filenames = false;
        if (have_cmd_line_pattern == true &&
            cmd_line_patterns_prepped == false) {
            if (prep_patterns() < 0) {
                cleanup();
                fprintf(stderr, "%s: problem prepping the patterns.\n",
                        program);
                return 2;
            }
            cmd_line_patterns_prepped = true;
        }
        afgrep(in);
    }

    cleanup();
    return (matched == true) ? 0 : 1;
}
