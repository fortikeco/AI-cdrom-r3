%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (C)1992 Institute for New Generation Computer Technology %
% $BG[I[$=$NB>$O(B COPYRIGHT $B%U%!%$%k$r;2>H$7$F2<$5$$(B          %
% ( Read COPYRIGHT for detailed information. )             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% file --> dic.pl 

subst(_,[],_,[]) :- !.
subst(X,[X|L],A,[A|M]) :- !, subst(X,L,A,M).
subst(X,[Y|L],A,[Y|M]) :- subst(X,L,A,M).
	
%append([],X,X) :- !.
%append([H|T],L,[H|U]) :- !, append(T,L,U).

%%% file --> parser.pl

% tail %    
tail(T,Dat) :- var(T),!,T=[Dat|_].
tail([_|T],Dat) :- !,tail(T,Dat).

% get %
get_last_element([C|CL],C) :- var(CL) ,!.
get_last_element([_|CL],C) :- !,
	get_last_element(CL,C).

% get element %
get_element(N,X,P,P) :- var(X),!.
get_element(N,[H|T],TTT,TT) :- !, arg(N,H,HH),get_element(N,T,[HH|TTT],TT).

	
% search fail 2 %
search([],_):- !,fail.
search([A|_],A):-!.
search([_|T],A) :- !,
      search(T,A).

% search non fail %
search_no_fail([],A):- !.
search_no_fail([A|_],A):-!.
search_no_fail([_|T],A) :- !,
      search_no_fail(T,A).


%%% file --> rdg_gram.pl & rdg_gram_sem.pl

bound(A) :- nonvar(A).
unbound(A) :- var(A).

% get last data %
last([],[]) :-!.
last([A],A):- !.
last([_|B],C) :- last(B,C).

% get first data %
first1([],[]) :-!.
first1([A|_],A):- !.

% search fail 4 %
search([],_,_,_) :-!,fail.
search([A|_],B,mcand,E) :-
     functor(A,B,2),
     arg(1,A,EE),
     arg(1,EE,E).
search([A|_],B,mer,E) :-
     functor(A,B,2),
     arg(2,A,EE),
     arg(1,EE,E).    
search([_|T],B,C,D) :-!,
    search(T,B,C,D).

% search fail 2 %
search([],_):- !,fail.
search([A|_],A):-!.
search([_|T],A) :- !,
      search(T,A).



