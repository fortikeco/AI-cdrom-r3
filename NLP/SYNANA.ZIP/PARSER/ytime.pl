%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (C)1992 Institute for New Generation Computer Technology %
% $BG[I[$=$NB>$O(B COPYRIGHT $B%U%!%$%k$r;2>H$7$F2<$5$$(B          %
% ( Read COPYRIGHT for detailed information. )             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- public time/1.
time(Proc) :-
	statistics(garbage_collection,GCt1),
	GCt1 = [_,_,Gc_base],
	statistics(stack_shifts,[_,_,SFB]),
	statistics(runtime,_),
      (	call(Proc) ;
	write(failed) ),
	statistics(runtime,[_,Time]),
	statistics(garbage_collection,GCt2),
	GCt2 = [_,_,Gc_end],
	Gc_time is Gc_end - Gc_base,
	statistics(stack_shifts,[_,_,SFT]),
	SFTR is SFT - SFB,
	Ex_time1 is Time - Gc_time,
	Ex_time is Ex_time1 - SFTR,
	nl,write('execution time = '),
	write(Ex_time),
	write(msec),nl,
	write('gc time = '),
	write(Gc_time),
	write(msec),nl,
	write('ss time = '),
	write(SFTR),
	write(msec),nl,
	statistics(program,[Use,_]),
	write('heap = '),
	write(Use),
	write(' bytes'),!.
