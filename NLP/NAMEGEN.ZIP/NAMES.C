#include	<stdio.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<dos.h>

void randname (char *s)
{
	int i,j,k;
	static char vowels[] = "aeiou";
	static char consonants[] = "bcdfghjklmnpqrstvwxyz";

	i = 3 + rand () % 3;
	j = 0;
	if (rand () % 2)
	{
		for (k=1 + rand () % 2; k; k--)
			s[j++] = vowels[rand () % 5];
		i--;
	}
	do
	{
		s[j++] = consonants[rand () % 5];
		if (i != 1 && rand () % 4 == 0)
		{
			if (rand () % 3 == 0)
				s[j++] = (rand () % 2 ? '\'' : '-');
			s[j++] = consonants[rand () % 21];
		}
		if (--i == 0)
			break;
		for (k=1 + rand () % 2; k; k--)
			s[j++] = vowels[rand () % 5];
	}
	while (--i);
	s[j] = 0;
	s[0] = toupper (s[0]);
}

cdecl main (int argc,char **argv)
{
	char buf[256];
	int i;
	struct dos_time_t dostime;

	dos_gettime (&dostime);
	srand (dostime.hsecond + dostime.second*100);
	if (argc != 2)
	{
		printf (	"names v2.0 by Russell Wallace  " __DATE__ "\n"
					"Generates random names for use in games\n"
					"\n"
					"Usage: names n\n"
					"\n"
					"where n is the number of names to generate.\n"
					"\n"
					"This program is in the public domain.\n");
		return 1;
	}
	for (i=atoi (argv[1]); i; i--)
	{
		randname (buf);
		printf ("%s\n",buf);
	}
	return 0;
}
