
              INSTRUCTIONS FOR HEBREW QUIZ PROGRAM

  I. How to unpack this disk
 II. How to start the program
III. How to stop the program
 IV. What to do at the "Opening Screen"
  V. Customizing the program for GRAPHICS, Demonstration Mode, etc.

Appendices:
  A. Examples of Frequency Lists
  B. Examples of Verbal Paradigms

  I. How to unpack this disk
     A. If you have a hard disk,
        1. Go to the directory you want the Hebrew program to reside in.
        2. Insert this disk in drive A:
        3. Type  COPY A:*.*
        4. Your Hard disk now has the program HEBREW.EXE and files.
     B. If you have two floppy drives,
        1. Insert this disk in drive A:
        2. Insert a blank disk in drive B:
        3. Type COPY A:*.* B: then the ENTER key
        4. You now have a working copy of the program.

 II. How to start the program
     A. If you have a hard disk,
        1. Go to the directory that has the program.
        2. Type HEBREW then the ENTER key.
     B. If you have two floppy disks,
        1. Insert your copied HEBREW disk in Drive A:
        2. Type A: then the ENTER key
        3. Type HEBREW then the ENTER key

III. How to stop the program.
     Continue to press the * key until you are out of the program.

 IV. How to use the program.
     The Hebrew program is divided up into the following areas.
     A. Choosing what words you wish to be drilled on.
        1. selections from vocabulary lists
        2. grammatical or verbal paradigms given in a chapter
        3. selections from frequency and verbal root lists

     B. Choosing what about these words you wish to be drilled on.
        1. Hebrew to English
        2. Hebrew to parsing (verbs only)
        3. English to Hebrew consonants
        4. English to Hebrew
     C. The quiz itself.
        1. Get a word right and it is removed from the current list
        2. Get it wrong and it will reappear twice on the current list
        3. All quizzes are graded and timed for added incentive

A. What words do you want to be drilled on?
   From the opening screen you have six ways of choosing.
   1 -- Learn the order of the Hebrew Alphabet.
        Two letters appear.  You must decide whether the one on the
        left comes BEFORE or AFTER the one on the right.  Every
        possible combination is tested until you run out of time.
   2 -- Choose from the Lambdin vocabulary lists.
        You can designate what range of chapters you want and
        what kinds of words you want on your vocabulary list.
        Words are divided into Nouns (1), Pronouns (2), Verbs (3),
        Adjectives (4), Prepositions (5), Adverbs (6), Conjunctions
        (7), Names (8), Particles (9) and Numbers (0).
   3 -- Choose from Lambdin's grammatical paradigms.
        You can designate what range of chapters you want and 
        what kinds of paradigms you want on your vocabulary list.
        Paradigms are divided into Names of Symbols (1), use of
        the Definite Article (2), Duals and Plurals (3), the
        Construct form (4), Prepositions and Suffixes (5), 
        Pronominal Suffixes (6), Adjectives (7), Numbers (8),
        and Pronouns (9).
   4 -- Choose from Landes Frequency and Cognate lists.
        You can make vocabulary lists based on cognate groups,
        frequency of words, types of words, or a combination.
        This section contains most of the vocabulary of the
        Hebrew Scriptures.  See Appendix A for examples of how
        to use this Section.
   5 -- Choose from Lambdin's verbal paradigms.
        You can choose verbs based on chapter of occurrance,
        characteristics of the verbal root, tense, person, gender,
        and several other characteristics.  See Appendix B for
        examples of how to use this Section.
   6 -- Progress through Lambdin or Landes in an orderly manner.
        1 -- Go to the "next" section of Lambdin.
        2 -- Review the sections you've already learned.
        3 -- Choose from a list from the current lesson in Lambdin.
        4 -- Choose all words associated with verbs that appear a
             certain number of times.
        5 -- Choose all words that appear a certain number of times.
        ENTER -- Let the computer decide what you need to do.

B. Choosing what about these words you wish to be drilled on.
   Once your vocabulary list is chosen and loaded you will see
   the question "Quiz or Review?"  Press R to Review your list.
   1 -- Hebrew to English.  This is the way the program normally
        drills.
   2 -- English to Hebrew.  To switch between the one and the other,
        from the REVIEW menu press the / key.  If you have just
        chosen English to Hebrew, you are given the choice of
        including vowel points.  If you say Y (Yes), you must
        always include vowel points.  If you say N (No), you don't
        have to include vowel points but if you do, you can be
        marked wrong for them.
   Other options from the REVIEW menu are set up like a tape recorder.
   ENTER -- See the next word      P -- See previous word
   F -- Fast forward               B -- Fast reverse
   R -- Rewind to beginning        ? -- Search for an English word
   * -- Return to Opening Screen   X -- Exit program
   Q -- Quiz on these words

C. The quiz itself.
   At any time in the quiz you can return to the REVIEW screen by
   pressing the * key.


  V. Customizing the program.
     From the Opening Screen type 7 then RETURN.  You have five
options given here.
1. Press 1 to toggle between graphics and non-graphics adaptations
   of this program.  The graphics version uses a beautiful Hebrew
   font, and in-color screens.  The nongraphics version (default)
   is much rougher but should work on any computer.
2. Resets all "bookmarks" within the program to the first section
   of Chapter 1 of Lambdin's grammar.
3. Store owners, if you wish to show this program off, it has a
   "demo" mode in which it will quiz itself AND allow for user
   experimentation.  The demo mode allows only Hebrew-to-English
   quizzing.
4. Before copying and shipping this program, use this option to
   reset all values to their default.
*  will return you to the Opening Screen.

     Questions, Comments, Complaints, Payments?
David Rapier, 80 Island Creek Road, Duxbury, MA  02332 is the maker.  
I'll be glad to hear from you.

APPENDICES

  A. Examples of Frequency Lists

     From the "Opening Screen," press 4.  Read the next screen,
and press RETURN.  Based on your answers, you will see various
parts of an extended outline.  The outline has two major sections
-- Cognates and Vocabulary.  Section I chooses what groups of 
cognates your vocabulary list will be chosen from.  Section II 
chooses what specifications each word on the list must live up to.

1. You want all the numbers in the list.  [Numbers are type 0]
    I. Limit by Cognate?       N
   II. Limit by Vocabulary?    Y
       A. Limit by Frequency?  N
       B. Limit by Type?       Y
          What type?           0 ENTER

2. You want all words appearing 50 times.
    I. Limit by Cognate?       N
   II. Limit by Vocabulary?    Y
       A. Limit by Frequency?  Y
          1. Minimum?          50 ENTER
          2. Maximum?          50 ENTER
       B. Limit by Type?       N

3. You want all words based on verbs appearing 200-250 times, 
unless they are names or unless they appear less than 25 times.
[Names are type 8]
    I. Limit by Cognate?               Y 
       A. Limit by Frequency of Root?  Y
          1. Minimum?                  200 ENTER
          2. Maximum?                  250 ENTER
       B. Limit by Nonverbal cognate?  N
   II. Limit by Vocabulary?            Y
       A. Limit by Frequency?          Y
          1. Minimum?                  25 ENTER
          2. Maximum?                  ENTER
       B. Limit by Type?               Y
          What type?                   123456790 ENTER

4. You want a list of all names appearing 50 or more times, 
together with the verbs they come from.
    I. Limit by Cognate?               Y
       A. Limit by Frequency of Root?  N
       B. Limit by Nonverbal cognate?  Y
          1. Minimum?                  50 ENTER
          2. Maximum?                  ENTER
          3. Type?                     8 ENTER
   II. Limit by Vocabulary?            Y
       A. Limit by Frequency?          N
       B. Limit by Type?               Y
          What type?                   38 ENTER {verbs, names}

B. Examples of Verbal Paradigms.
   From the "Opening Screen" press 5.  Read the next screen.  
Press RETURN.  EVERY QUESTION IN THIS SECTION IS EXPECTING A  
SERIES OF NUMBERS AS AN ANSWER!

     There are two steps to making a list of verbs to be quizzed 
on:  what Hebrew words are to be included {1,2,3,4,5,6,7,8} and 
what kind of English answer is wanted {9}.

     For the first step, you have 8 choices for how to limit what 
Hebrew verbs are used -- by chapter, by root type, by 
conjugation, and so on.  If you don't limit by chapter, all 
chapters are used; if you don't limit by root type, all kinds of 
verbs are used; if you don't limit by suffixal ending, all kinds 
of suffixal endings are used -- be specific!  If you want to limit 
the choice of verbs by chapter (1), by root type (2) and by 
suffixal ending (8), then for the first question type 128 ENTER

     If you include a 9 in the first question (1289 ENTER), you
can designate what kind of English response you wish to give.
See the examples.

EXAMPLES 
1. You want all Qal Perfect 3rd Masculine Singular No-Suffix verbs,
   and you want to identify what type of root they are.
      Options? 3456789 ENTER  {3=Conjugation, 4=Tense etc.}
   3. Conjugation? 1   ENTER  {1=Qal}
   4. Tense?       1   ENTER  {1=Perfect}
   5. Person?      3   ENTER  {3=3rd Person}
   6. Gender?      1   ENTER  {1=Masculine}
   7. Number?      1   ENTER  {1=Singular}
   8. Suffix?      -   ENTER  {-=No suffix}
   9. English?     1   ENTER  {1=Verb type}

Result:  For the Hebrew word KATAV you type STRONG.
         For the Hebrew word HAYAH you type HOLLOW III-HE.

2. You want the verbs in chapter 10, and you want to identify
   them by person, gender and number.
      Options?       19 ENTER  {1=by Chapter, 9=English def.}
   1. Chapter start? 10
      Chapter end?   10
   9. English?      456 ENTER  {4=person, 5=gender, 6=number}

Result:  For the Hebrew word NATAN you type 3RD MASCULINE SINGULAR
         For the Hebrew word AMADNU you type 1ST COMMON PLURAL
