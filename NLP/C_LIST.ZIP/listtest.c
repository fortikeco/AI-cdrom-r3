/* ListTest.c */

#include "stdio.h"
#include "clist.q"

int  idx;
List TestList1;
List TestList2;
List NewList,A,B,C;

main ()
{
	InitializeList_(ON);
	NewList   = nil;
	TestList1 = DefList_(Q_("TEST1.LST"));
	TestList2 = DefList_(Q_("TEST2.LST"));
	PrintList_(TestList1);
	PrintList_(TestList2);
	TestList1 = Cons_(Q_("Q "),TestList1);
	SaveList_(TestList1,Q_("TEST1.LST "));
	TestList1 = UnDefList_(TestList1);
	TestList1 = DefList_(Q_("TEST1.LST"));
	PrintList_(TestList1);
	printf ("%d ",CollectGarbage_(2,TestList1,TestList2));


}



