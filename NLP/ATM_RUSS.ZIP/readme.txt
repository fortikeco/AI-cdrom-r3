
The font files contained (Russbas.pfb and Russbas.pfm) will suffice for
any ordinary sort of Windows text usage requiring Russian characters.
The Adobe type manager (ATM) is required;  this is available from
various sources and, in particular, comes as a standard part of Ami Pro,
which is what I recommend for Windows word processing generally.  ATM
eliminates the need for keeping lots of disk space tied up with copies
of the same fonts in numerous different sizes.

The fonts included are keyed to behave like a soviet type 0
keyboard which is similar to the Dvorak keyboard for Roman characters;
letters which frequently fall together in the language also fall
together on the keyboard.  Two hours spent playing around with the
keyboard using these fonts will give you a fairly good feel for the
nature of the Russian keyboard and you will forever afterwards type faster
and better in Russian than you ever would with a keyboard which tried to
match Russian letters to English near equivalents.  Two hours isn't
much;  think of it as missing one movie which you didn't really need to
see.

If you want to do a really superior job of printing in Russian, Send $40
to:

     HT Enterprises
     1947 Storm Dr.
     Falls Church, Va. 22043

and request a copy of our entire Russian font set which contains not
only standard Cyrillic (Russbas), but a good Russian Cloister font, a
Russian fairytale font, good Russian capital letters Z, D, and Y for
beginning correspondence, and a small sample of firebirds etc. for
letterheads.

The standard Russian font Russbas (HTE Standard Cyrillic) is free to the
public, and I would appreciate users posting this file (Russbase.zip),
unaltered of course, to other BBS systems.

Ted Holden
HT Enterprises





  




