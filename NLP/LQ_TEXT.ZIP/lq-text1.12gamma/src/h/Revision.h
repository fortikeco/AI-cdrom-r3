/* This header file gets updated with every distributed change to any source
 * file anywhere in the lq-text package.
 * A short description of the change is added to the Log here, too.
 * Lee.
 */

#define LQTEXTREVISION "Release 1.12-gamma"

/* the index version: */

#define LQ_MAJOR_VERSION 1
#define LQ_MINOR_VERSION 12

#ifdef WIDINBLOCK
# define LQ_FLAG_VALUE 3
#else
# define LQ_FLAG_VALUE 1
#endif

/* $Revision: 1.12 $
 *
 * $Id: Revision.c 1.12 lee Exp
 *
 * $Log$
 *
 * Revision 1.6  90/10/04  17:12:45  lee
 * lqtext now compiles and mostly works under BSD.
 * Fixes bug in phrase matching -- PhraseMatchLevel now works on one-word
 * phrases.
 * 
 * Revision 1.5  90/09/28  22:19:36  lee
 * Made GetChar() a macro in lqaddfile -- speed improvement...
 * 
 * Revision 1.4  90/09/20  16:37:35  lee
 * Fixed Mail and News filters so that they throw away the unwanted header
 * parts correctly.
 * 
 * Revision 1.3  90/09/20  12:51:24  lee
 * Major sdbm initialisation bug fixed.
 * 
 * Revision 1.2  90/09/20  11:52:35  lee
 * Fixed the filters so that lqshow highlights the right word (the qxx fix)
 * 
 * Revision 1.1  90/09/20  11:52:18  lee
 * Initial revision
 * 
 *
 */
