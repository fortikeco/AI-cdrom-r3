/* blkheader.h -- Copyright 1989,1992 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 *
 * (was called blockheader.h, but this was too long on SysV for RCS)
 */

/* descibe the physical WOrdPlace database...
 *
 * $Id: blkheader.h,v 1.4 92/08/24 00:26:09 lee Exp $
 */

/* The header of each block -- I can't use sReadNumber, because I don't know
 * the size of NextOffset until I get to the end, and it's too late by then!
 *
 * I should really store the block offset, and not the byte offset.  This
 * would save a whole byte -- I could use 3 bytes for the NextBlock!
 */
typedef struct {
    unsigned long NextOffset; /* a byte offset */
#ifdef WIDINBLOCK
    unsigned long WID;
#endif
    unsigned char NumberOfBlocks;
    char Data[1]; /* the address of this is where the number start... */
} t_BlockHeader;
