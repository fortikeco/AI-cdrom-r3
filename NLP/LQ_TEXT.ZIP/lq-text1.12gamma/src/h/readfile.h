/* readfile.h -- Copyright 1992 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 */
 
/* $Id: readfile.h,v 1.2 92/08/23 01:13:59 lee Exp $ */
 
/* Flags for fReadFile */

#define UF_IGNBLANKS	001 /* throw away blank lines */
#define UF_IGNSPACES	002 /* discard leading and trailing spaces */
#define UF_IGNHASH  	004 /* discard LEADING comments (# with a hash-sign) */
#define UF_ESCAPEOK 	010 /* accept \# and \\ as # and \ */
#define UF_IGNALLHASH   020 /* discard ALL comments (# with a hash-sign) */
#define UF_NORMAL (UF_IGNBLANKS|UF_IGNSPACES|UF_IGNHASH|UF_ESCAPEOK)
