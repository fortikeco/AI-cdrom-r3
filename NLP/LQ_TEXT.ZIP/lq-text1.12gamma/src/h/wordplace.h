/* WordPlace -- a structure for a single occurrence of a single word.
 * Used mainly in pblock.c and lqsort.c, and also in lqaddfile, for which
 * it was designed.
 *
 * $Id: wordplace.h,v 1.2 92/03/08 18:52:56 lee Exp $
 *
 */
#ifndef WORDPLACE_H

# define WORDPLACE_H 1


typedef struct {
    t_FID FID;
    unsigned long BlockInFile;
    unsigned short WordInBlock; /* actually this can be a u_char */
    unsigned char Flags;
    unsigned char StuffBefore; /* preceding ignored garbage */
} t_WordPlace;

/*
 * $Log:	wordplace.h,v $
 * Revision 1.2  92/03/08  18:52:56  lee
 * Deleted WordPlaceList, and made Flags unsigned char (not short).
 * 
 * Revision 1.1  91/06/16  18:17:52  lee
 * Initial revision
 * 
 */

#endif
