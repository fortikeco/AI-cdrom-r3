/* MaxWid.c -- Copyright 1989 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 */

#include "globals.h" /* defines and declarations for database filenames */

#include <stdio.h>
extern void SetDefaults();
extern void exit();

int
main(argc, argv)
    int argc;
    char *argv[];
{
    extern unsigned long GetMaxWID();

    SetDefaults(argc, argv);

    printf("Max Word Identifier (MaxWID) is %lu\n", GetMaxWID());
    return 0;
}
