/* trywid.c -- Copyright 1989 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 *
 * $Header: /usr/src/cmd/lq-text/src/test/RCS/trywid.c,v 1.1 90/08/09 19:17:51 lee Rel1-10 $
 *
 * $Log:	trywid.c,v $
 * Revision 1.1  90/08/09  19:17:51  lee
 * Initial revision
 * 
 *
 */

#include "globals.h" /* defines and declarations for database filenames */

#include <sys/types.h>
#include <stdio.h>
#include "fileinfo.h"
#include "wordinfo.h"

/** Unix Library Functions: **/
extern long atol();
/** liblqtext functions: **/
extern t_WID GetMaxWID();
extern t_WID GetNextWID();
/** **/

int
main(argc, argv)
    int argc;
    char *argv[];
{
    t_WID W, Max;

    Max = atol(argv[1]);

    for (W = GetMaxWID(); W <= Max; ) {
	printf("%lu\n", W = GetNextWID(0));
    }
    return 0;
}
