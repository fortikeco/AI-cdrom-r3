/* LastNext.c -- Copyright 1989 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 */

/* LastNext.c -- a global variable that simply has to go...  Sorry!
 * 
 * $Id: lastnext.c,v 1.2 92/04/18 19:20:01 lee Exp $
 */

#include "globals.h" /* defines and declarations for database filenames */

#include <stdio.h>
#include <fcntl.h>

#include <sys/types.h>
#include "fileinfo.h"
#include "wordinfo.h"

t_WID LastNextWIDVal = 0;
