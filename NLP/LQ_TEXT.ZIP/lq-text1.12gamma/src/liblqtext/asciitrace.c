/* asciitrace.c -- Copyright 1989 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 * This file simply declares AsciiTrace, which is used for verbose (-v)
 * output (when set to 1), and for debugging/tracing at higher levels.
 */

int AsciiTrace = 0;

/* $Id: asciitrace.c,v 1.3 90/10/06 00:21:12 lee Rel1-10 $
 *
 */
