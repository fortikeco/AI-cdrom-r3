
			WinGreek Version 1.6

     WinGreek - Greek and Hebrew Package for Windows 3.0 and 3.1


Shareware Package for using Greek and Hebrew in Windows. 

Includes:

-Screen Fonts for Hercules, EGA, VGA & 8514
-Printer fonts for 9pin & 24pin Printers, HP LaserJets & Greek Postscript.
-Utilities for Entering Accents (European Languages & Greek) and 
	Converting between File Formats (WinGreek <=> CCAT).



NEW: Greek TrueType Font for Windows 3.1! Greek For All Printers
	Supported by Windows 3.1.

