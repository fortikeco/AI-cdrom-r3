This is the "hum" concordance and textual analysis package done by
Bill Tuthill when he was at Berkeley (1981).  A package of programs
for literary and linguistic computing, emphasizing the preparation of
concordances and supporting documents.  Both keyword in context and
keyword and line generators are provided, as well as exclusion
routines, a reverse concordance module, formatting programs, a
dictionary maker, and lemmatization facilities.  There are also word,
character, and digraph frequency counting programs, word length
tabulation routines, a cross reference generator, and other related
utilities.  The programs are written in the C programming language.
