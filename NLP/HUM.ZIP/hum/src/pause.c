# include <stdio.h>			/* pause.c (rev3.7) */

main(argc, argv)	/* stop IBM terminal to change ball */
int argc;
char *argv[];
{
	FILE *fp, *fopen();

	if (argc == 1)
		pawse(stdin);
	else
	{
		while (--argc > 0)
			if ((fp = fopen(*++argv, "r")) != NULL)
			{
				pawse(fp);
				fclose(fp);
			}
			else  /* attempt to open failed */
			{
				fprintf(stderr,
				"Pause cannot access the file: %s\t\t(rev3.7)\n",
				*argv);
				continue;
			}
		exit(0);
	}
}

pawse(fp)		/* pause when ctrl-p is read from file */
FILE *fp;
{
	register int c;

	while ((c = getc(fp)) != EOF)
	{
		if (c == '\020')	/* \020 is ctrl-p */
			patient();
		else
			putchar(c);
	}
}

patient()		/* wait for ctrl-d from terminal */
{
	FILE *termptr, *fopen();
	int sig;

	termptr = fopen("/dev/tty", "r");
	while ((sig = getc(termptr)) != EOF)
	{
		if (sig != '\004')	/* \004 is ctrl-d */
			;
		else
			return;
	}
	fclose(termptr);
	return;
}
