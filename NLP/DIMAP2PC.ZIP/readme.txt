                    DIMAP-2 DEMONSTRATION PROGRAM

1.   INSTALLATION

     To install the demonstration program, create a directory (for
example, MD C:\DMP) and simply copy all files from the demonstration
disk to that directory.  For example,
          COPY A:*.* C:\DMP\

2.   STARTING THE PROGRAM

     To start DIMAP-2, type DMP at the prompt.

3.   USING THE PROGRAM

     DIMAP-2 is menu-driven and is fairly intuitive.  However, the
creation and development of a natural language processing dictionary
is not.  The complete manual (without the figures) for DIMAP-2 is
included in the demonstration disk as the text file MANUAL.  This
file can be printed out using DOS commands or through your favorite
word processor.  Since you have received only a demonstration disk,
certain parts of the manual will not be applicable.  This includes
the chapter dealing with installation of the software, the chapter
dealing with the use of the machine-readable dictionary, and the
appendix describing the C library for DIMAP.

4.   CHANGES AND LIMITATIONS FOR THE DEMONSTRATION COPY

     We could not demonstrate the machine-readable dictionary in
this demo disk.  However, we have downloaded all the definitions for
the words "horse," "cause," and "good" from the machine-readable
dictionary into a demonstration DIMAP-2 dictionary.  These entries
were created by using option C on the main menu for DIMAP-2 by
entering the three words and converting the machine-readable
definitions into DIMAP-2 format.

     Two executable programs were not included on the demo disk: 
REW.EXE and PRTBTR.EXE.  The latter is a minor utility, but REW.EXE
is an important utility for combining several DIMAP-2 dictionaries. 
See the manual for a complete description.

     The DIMAP-2 demonstration disk is fully functional except for
the limitations noted above and a limitation for creating DIMAP-2
dictionaries to 100 words.

     We have included a flyer and order form for DIMAP-2 for your
convenience.

     Good wording!

     Ken Litkowski
     CL Research
     20239 Lea Pond Place
     Gaithersburg, MD 20879-1270 USA
     (Telephone: 1-301-926-5904)
     (Email: INTERNET> 71520.307@compuserve.com)

