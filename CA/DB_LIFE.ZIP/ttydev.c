/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include <fcntl.h>
#include <curses.h>
#include "life.h"


static	int	ttyopen();
static	void	ttyclose();
static	void	ttyupdate();
static	void	ttyrefresh();
static	int	ttyinputready();
static	int	ttyreadchar();
static	void	ttymovecursor();
static	void	ttyshowview();
static	void	ttyshowstatus();
static	void	ttyaddstatus();
static	void	ttyshowhelp();
static	void	ttyaddhelp();
static	int	ttyassign();

static	void	viewnormal();
static	void	viewscale();


DEV	ttydev = {
	ttyopen, ttyclose, ttyupdate, ttyrefresh, ttyinputready, ttyreadchar,
	ttymovecursor, ttyshowview, ttyshowstatus, ttyaddstatus,
	ttyshowhelp, ttyaddhelp, ttyassign, 0, 0, 0, 0, 1, MAXSCALE, 1
};


static	WINDOW	*statwin;
static	WINDOW	*viewwin;

static	BOOL	havesavedchar;
static	int	savedchar;
static	int	ttyfd;


static int
ttyopen(dev)
	DEV	*dev;
{
#ifdef	O_NONBLOCK
	ttyfd = open("/dev/tty", O_RDONLY | O_NONBLOCK);
	if (ttyfd < 0) {
		fprintf(stderr, "Cannot set tty mode\n");
		return -1;
	}
#endif
	initscr();
	cbreak();
	noecho();
	statwin = newwin(1, COLS, 0, 0);
	viewwin = newwin(LINES - 1, COLS, 1, 0);

	dev->rows = LINES - 1;
	dev->cols = COLS - 1;
	dev->textrows = LINES - 1;
	dev->textcols = COLS - 1;

	return 0;
}


static void
ttyclose(dev)
	DEV	*dev;
{
	refresh();
	endwin();
}


static void
ttyupdate(dev, inputflag)
	DEV	*dev;
	BOOL	inputflag;
{
	if (inputflag) {
		wrefresh(viewwin);
		wrefresh(statwin);
	} else {
		wrefresh(statwin);
		wrefresh(viewwin);
	}
}


static void
ttyrefresh(dev)
	DEV	*dev;
{
	wrefresh(curscr);
}


/*
 * Read the next character from the terminal, waiting if requested.
 * If not waiting and no character is ready, then EOF is returned.
 * When waiting and the read is interrupted, then also returns EOF.
 */
static int
ttyreadchar(dev, wait)
	DEV	*dev;
{
	UCHAR	ch;
	int	n;

	if (!wait && !ttyinputready(dev))
		return EOF;

	if (havesavedchar) {
		havesavedchar = FALSE;
		return savedchar;
	}

	n = read(STDIN, &ch, 1);
	if (n <= 0)
		return EOF;

	if (ch == '\r')
		ch = '\n';

	return ch;
}


/*
 * See if input is ready from the terminal.
 */
static BOOL
ttyinputready(dev)
	DEV	*dev;
{
	int	n;
	UCHAR	ch;

#ifdef O_NONBLOCK
	n = read(ttyfd, &ch, 1);
	if (n <= 0)
		return FALSE;

	if (ch == '\r')
		ch = '\n';

	savedchar = ch;
	havesavedchar = TRUE;

	return TRUE;
#endif

#ifdef FIONREAD
	return ((ioctl(STDIN, FIONREAD, &n) == 0) && (n > 0));
#endif

#ifdef FIORDCHK
	return (ioctl(STDIN, FIORDCHK, &n) > 0);
#endif

	error("Cannot do non-blocking reads!!!!");
}


static int
ttyassign(dev, button, macro)
	DEV	*dev;
	VALUE	button;
	UCHAR	macro;
{
	return -1;
}


static void
ttymovecursor(dev, sf, row, col)
	DEV	*dev;
	SCALE	sf;
	COORD	row;
	COORD	col;
{
	if (sf < 1)
		sf = 1;
	wmove(viewwin, row / sf, col / sf);
}


/*
 * Show the view around the current window location.
 */
static void
ttyshowview(dev)
	DEV	*dev;
{
	wmove(viewwin, 0, 0);
	if (curobj->o_scale <= 1)
		viewnormal();
	else
		viewscale(curobj->o_scale);
	wclrtobot(viewwin);
}


/*
 * Show the specified status line.
 */
static void
ttyshowstatus(dev, str)
	DEV	*dev;
	char	*str;
{
	wmove(statwin, 0, 0);
	wclrtobot(statwin);
	wmove(statwin, 0, 0);
	waddstr(statwin, str);
}


/*
 * Add the specified status to the status line.
 */
static void
ttyaddstatus(dev, str)
	DEV	*dev;
	char	*str;
{
	waddstr(statwin, str);
}


/*
 * Setup to show help.
 */
static void
ttyshowhelp(dev)
	DEV	*dev;
{
	wmove(viewwin, 0, 0);
	wclrtobot(viewwin);
	wmove(viewwin, 0, 0);
}


/*
 * Add the specified information to the help display.
 */
static void
ttyaddhelp(dev, str)
	DEV	*dev;
	char	*str;
{
	waddstr(viewwin, str);
}


/*
 * Show the cells around the cursor normally (scale factor of 1).
 */
static void
viewnormal()
{
	register ROW	*rp;		/* current row */
	register CELL	*cp;		/* current cell */
	OBJECT	*obj;			/* current object */
	COORD	row;			/* current row number */
	COORD	col;			/* current column number */
	char	*str;			/* characters for line */
	char	*endstr;		/* end of characters for line */

	obj = curobj;
	rp = obj->o_firstrow;
	row = obj->o_minrow;
	seecount = 0;
	while (row > rp->r_row)
		rp = rp->r_next;

	for (; row <= obj->o_maxrow; row++) {
		if (row != rp->r_row) {			/* blank row */
			if (gridchar == ' ') {
				waddch(viewwin, '\n');
				continue;
			}
			str = stringbuf;
			for (col = obj->o_mincol; col <= obj->o_maxcol; col++) {
				*str++ = gridchar;
			}
			*str++ = '\n';
			*str = '\0';
			waddstr(viewwin, stringbuf);
			continue;
		}

		str = stringbuf;
		endstr = str;
		cp = rp->r_firstcell;
		col = obj->o_mincol;
		while (col > cp->c_col)
			cp = cp->c_next;

		for (; col <= obj->o_maxcol; col++) {
			if (col != cp->c_col) {		/* blank cell */
				*str++ = gridchar;
				if (gridchar != ' ')
					endstr = str;
				continue;
			}
			*str = 'o';
			if ((cp->c_marks & MARK_SEE) == 0)
				*str = 'O';
			endstr = ++str;
			seecount++;
			cp = cp->c_next;
		}

		*endstr++ = '\n';
		*endstr = '\0';
		waddstr(viewwin, stringbuf);
		rp = rp->r_next;
	}
}


/*
 * Show the view around the cursor with an arbitrary scale factor.
 * When in this mode, characters from 1 to 9 (or * if 10 or more)
 * are used to indicate how many cells are in each n by n square.
 */
static void
viewscale(sf)
	register SCALE	sf;
{
	register ROW	*rp;		/* row pointer */
	register CELL	*cp;		/* current cell structure */
	OBJECT	*obj;			/* current object */
	COORD	row;			/* current row number */
	COORD	col;			/* current column number */
	COUNT	sum;			/* number of cells in square */
	CELL	**cpp;			/* pointer into cell table */
	CELL	**endcpp;		/* end of cell table */
	char	*str;			/* buffer pointer */
	char	*endstr;		/* end of buffer */
	CELL	*cptab[MAXSCALE];	/* table of rows */

	obj = curobj;
	row = obj->o_minrow;
	col = obj->o_mincol;
	endcpp = &cptab[sf];
	seecount = 0;

	for (rp = curobj->o_firstrow; (rp->r_row < row); rp = rp->r_next)
		;

	while (row <= obj->o_maxrow) {
		/*
		 * If there is a large gap to the next row number then
		 * the terminal line is empty.
		 */
		if (rp->r_row >= (row + sf)) {	/* no rows here */
			if (gridchar == ' ') {
				waddch(viewwin, '\n');
				row += sf;
				continue;
			}
			str = stringbuf;
			for (col=obj->o_mincol; col<=obj->o_maxcol; col+=sf) {
				*str++ = gridchar;
			}
			*str++ = '\n';
			*str = '\0';
			waddstr(viewwin, stringbuf);
			row += sf;
			continue;
		}

		/*
		 * Collect the rows to be searched for one terminal line.
		 * Dummy up empty rows if necessary.
		 */
		for (cpp = cptab; cpp < endcpp; cpp++) {
			*cpp = termcell;
			if (rp->r_row > row++)
				continue;
			*cpp = rp->r_firstcell;
			rp = rp->r_next;
		}
		str = stringbuf;
		endstr = str;

		/*
		 * Advance along each row to the next range of columns,
		 * adding cells found to get the result for each square.
		 */
		for (col = obj->o_mincol; col <= obj->o_maxcol; col += sf) {
			sum = 0;
			for (cpp = cptab; cpp < endcpp; cpp++) {
				cp = *cpp;
				while (col > cp->c_col)
					cp = cp->c_next;
				while ((col + sf) >= cp->c_col) {
					sum++;
					cp = cp->c_next;
				}
				*cpp = cp;
			}

			if (sum == 0) {		/* no cells in square */
				*str++ = gridchar;
				if (gridchar != ' ')
					endstr = str;
				continue;
			}

			*str = '*';		/* show number of cells */
			if (sum <= 9)
				*str = '0' + sum;
			endstr = ++str;
			seecount += sum;
		}
		*endstr++ = '\n';
		*endstr = '\0';
		waddstr(viewwin, stringbuf);
	}
}

/* END CODE */
