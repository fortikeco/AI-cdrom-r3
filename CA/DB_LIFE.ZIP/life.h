/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 *
 * Program to play Conway's game of LIFE on an infinite board.
 */

#include <stdio.h>
#include <setjmp.h>
#include <signal.h>


#define	ESC	'\033'
#define	FF	'\014'

#define	isblank(ch)	(((ch) == ' ') || ((ch) == '\t'))
#define	isdigit(ch)	(((ch) >= '0') && ((ch) <= '9'))
#define	islower(ch)	(((ch) >= 'a') && ((ch) <= 'z'))
#define	isupper(ch)	(((ch) >= 'A') && ((ch) <= 'Z'))
#define	isletter(ch)	(islower(ch) || isupper(ch))


#ifndef	LIFELIB
#define	LIFELIB	"/usr/games/lib/life"	/* directory for general life library */
#endif

#define	LIFEOPTS	"LIFEOPTS"	/* environment name for options */
#define	LIFEEXT		".l"		/* extension for life files */
#define	MAXPATH		1024		/* maximum size of path names */
#define	MAXFILE		18		/* maximum size of file name for list */
#define	MAXLIST		5		/* maximum depth for listing files */
#define	ALLOCOBJ	10		/* how many new objects to allocate */
#define	ALLOCROW	50		/* how many new rows to allocate */
#define	ALLOCCELL	500		/* how many new cells to allocate */
#define	LISTARGSIZE	200		/* incremental arg size for lists */
#define	LISTBUFSIZE	2000		/* incremental buffer size for lists */
#define	STRINGSIZE	(1024*4)	/* temp string buffer size */
#define	LOOPSIZE	5000		/* characters in command loops */
#define	SCAN_SIZE	100		/* maximum command length */
#define	MAXARGS		10		/* maximum command line arguments */
#define	MAXINPUT	20		/* maximum nesting of command inputs */
#define	MAXNAME		32		/* maximum object name size */
#define	MAXSCALE	1000		/* maximum scale factor */
#define	WRITEROWS	100		/* default maximum rows for writing */
#define	WRITECOLS	79		/* default maximum cols for writing */
#define	INFINITY	0x7fffffff	/* infinite value */
#define	LIFE		9		/* value for live cell */

#define	STDIN		0		/* standard input */
#define	STDOUT		1		/* standard output */
#define	STDERR		2		/* standard error */

#define	RELATIVE	0		/* do object additions relatively */
#define	ABSOLUTE	1		/* do object additions absolutely */

#define	M_MOVE		0		/* movement mode */
#define	M_INSERT	1		/* insertion mode */
#define	M_DELETE	2		/* deletion mode */

#define	MARK_ANY	0x1		/* mark always set */
#define	MARK_USR	0x2		/* marked due to user specification */
#define	MARK_CMD	0x4		/* marked only for current command */
#define	MARK_SRC	0x8		/* marked by searching */
#define	MARK_SEE	(MARK_USR)	/* marks seen by user */
#define	MARK_ALL	(MARK_ANY|MARK_USR|MARK_CMD|MARK_SRC)	/* all non-null marks */

#define	INP_TTY		0		/* input is terminal */
#define	INP_FILE	1		/* input is file */
#define	INP_LOOP	2		/* input is command loop */
#define	INP_MACRO	3		/* input is command macro */

#define	SCAN_ABORT	1		/* setjmp value for aborted command */
#define	SCAN_EDIT	2		/* setjmp value for edited command */
#define	SCAN_EOF	3		/* setjmp value for no command data */

#define	NULL_CMD	0xff		/* null command character */

#define	U_POS		0x01		/* update cursor position */
#define	U_STAT		0x02		/* update status line */
#define	U_VIEW		0x04		/* update view of cells */
#define	U_ALL		(U_POS | U_STAT | U_VIEW)	/* any updating */

#ifndef	TRUE
#define	TRUE		((BOOL) 1)	/* booleans */
#define	FALSE		((BOOL) 0)
#endif

#define	crow		curobj->o_currow	/* current row of current object */
#define	ccol		curobj->o_curcol	/* current column of current object */
#define	cmark		curobj->o_mark	/* current mark being applied */
#define	cscale		curobj->o_scale	/* current scale of current object */
#define	prow		curobj->o_prow	/* current pointer row */
#define	pcol		curobj->o_pcol	/* current pointer column */


/* macro to detect reserved names */
#define	BADNAME(s)	((s[0] == '.') && ((s[1] == '\0') || (s[1] == '.')))


/*
 * Basic typedefs
 */
typedef	long		COORD;		/* coordinate of a cell */
typedef	long		COUNT;		/* counts of things */
typedef	long		VALUE;		/* value of an expression */
typedef	int		MARK;		/* mark value */
typedef	int		BOOL;		/* boolean value */
typedef	int		SCALE;		/* scale factor */
typedef	unsigned char	UCHAR;		/* for character handling */


/*
 * Structure for each cell.
 */
typedef	struct	cell	CELL;
struct	cell	{
	CELL	*c_next;		/* link to next cell */
	COORD	c_col;			/* column number */
	MARK	c_marks;		/* marking values for cell */
};


/*
 * Structure for each row of cells.
 */
typedef	struct	row	ROW;
struct	row	{
	ROW	*r_next;		/* link to next row */
	CELL	*r_firstcell;		/* link to first cell */
	CELL	*r_lastcell;		/* link to last real cell */
	COORD	r_row;			/* row number */
	COUNT	r_count;		/* number of cells in this row */
};


/*
 * Structure for each object.
 */
typedef	struct	object	OBJECT;
struct	object	{
	OBJECT	*o_next;		/* next object */
	ROW	*o_firstrow;		/* first row */
	ROW	*o_lastrow;		/* last row */
	COUNT	o_count;		/* number of live cells */
	COUNT	o_born;			/* number of cells born */
	COUNT	o_died;			/* number of cells died */
	COORD	o_currow;		/* current row */
	COORD	o_curcol;		/* current column */
	COORD	o_minrow;		/* minimum row seen in window */
	COORD	o_maxrow;		/* maximum row seen in window */
	COORD	o_mincol;		/* minimum column seen in window */
	COORD	o_maxcol;		/* maximum column seen in window */
	COORD	o_prow;			/* currently pointed at row */
	COORD	o_pcol;			/* currently pointed at column */
	MARK	o_mark;			/* mark value for new cells */
	COUNT	o_gen;			/* current generation */
	SCALE	o_scale;		/* current scaling factor for view */
	COUNT	o_frequency;		/* frequency of output for object */
	BOOL	o_autoscale;		/* doing autoscaling */
	BOOL	o_reserved;		/* reserved object */
	char	o_name[MAXNAME+1];	/* name of object */
};


/*
 * The following structure holds all data necessary for processing
 * characters from some source.
 */
typedef	struct	input	INPUT;
struct	input	{
	int	(*i_getchar)();	/* routine to read next character */
	void	(*i_term)();	/* routine to terminate reading */
	int	i_type;		/* type of input */

				/* following for file reading only */
	FILE	*i_file;	/* file handle */
	OBJECT	*i_obj;		/* object to restore on reentry */
	COORD	i_row;		/* row to restore */
	COORD	i_col;		/* column to restore */
	COORD	i_prow;		/* pointer row to restore */
	COORD	i_pcol;		/* pointer column to restore */

				/* following for loop or macro reading only */
	UCHAR	*i_begptr;	/* beginning of command data */
	UCHAR	*i_endptr;	/* end of command data */
	UCHAR	*i_curptr;	/* current character */
	COUNT	i_curval;	/* current iteration value */
	COUNT	i_endval;	/* ending iteration value */
	BOOL	i_first;	/* processing new chars */
	char	i_macro;	/* macro being defined */
};


/*
 * Structure for command macros.
 */
typedef	struct	{
	UCHAR	*m_begptr;	/* beginning of data (NULL if none) */
	UCHAR	*m_endptr;	/* end of data */
} MACRO;


/*
 * Structure to interface to various input/output devices.
 * This supports both normal terminals and graphics output.
 */
typedef	struct {
	int	(*open)();		/* open device */
	void	(*close)();		/* close device */
	void	(*update)();		/* make sure display is up to date */
	void	(*refresh)();		/* redraw whole display from scratch */
	BOOL	(*inputready)();	/* check whether input is ready */
	int	(*readchar)();		/* read character with optional wait */
	void	(*movecursor)();	/* move position of cursor */
	void	(*showview)();		/* show view of life cells */
	void	(*showstatus)();	/* show status line */
	void	(*addstatus)();		/* add to status line */
	void	(*showhelp)();		/* show help information */
	void	(*addhelp)();		/* add information to help */
	int	(*assign)();		/* assign button to macro */

	COUNT	rows;			/* rows available for life cells */
	COUNT	cols;			/* columns available for life cells */
	COUNT	textrows;		/* rows of text available for help */
	COUNT	textcols;		/* columns of text available for help */
	SCALE	minscale;		/* minimum legal scale value */
	SCALE	maxscale;		/* maximum legal scale value */
	SCALE	defaultscale;		/* desirable default scale */
} DEV;


/*
 * Structure to hold a list of strings allocated from a common buffer.
 * This is used for collecting file names for listing.
 */
typedef	struct	{
	char	**argv;			/* pointer to list of pointers */
	char	*buf;			/* pointer to string storage */
	int	argc;			/* number of pointers */
	int	maxargc;		/* maximum number of pointers */
	int	used;			/* chars used in string storage */
	int	maxused;		/* maximum chars in string storage */
} LIST;


/*
 * Extern definitions for non-initialized data.
 * These are defined externally in all modules, except in main.
 */
#ifdef	DEFINE_GLOBALS
#define	EXTERN
#else
#define	EXTERN	extern
#endif


EXTERN	DEV	*dev;		/* device being used */
EXTERN	OBJECT	*objects;	/* list of active objects */
EXTERN	OBJECT	*curobj;	/* currently selected object */
EXTERN	OBJECT	*prevobj;	/* previously selected object */
EXTERN	OBJECT	*mainobject;	/* the main object */
EXTERN	OBJECT	*deleteobject;	/* object last deleted */
EXTERN	OBJECT	*backupobject;	/* backup object */
EXTERN	OBJECT	*tempobject;	/* temporary object */
EXTERN	OBJECT	*freeobjects;	/* list of free objects */
EXTERN	OBJECT	*newobjects;	/* top of new object allocation */
EXTERN	OBJECT	*endobjects;	/* end of new objects */

EXTERN	ROW	*freerows;	/* list of free row structures */
EXTERN	ROW	*newrows;	/* top of new row allocation */
EXTERN	ROW	*endrows;	/* end of new rows */
EXTERN	ROW	*termrow;	/* terminus row */
EXTERN	ROW	initrow;	/* row to initialize list */

EXTERN	CELL	*freecells;	/* list of free cell structures */
EXTERN	CELL	*newcells;	/* top of new cell allocation */
EXTERN	CELL	*endcells;	/* end of new cells */
EXTERN	CELL	*termcell;	/* terminus cell */
EXTERN	CELL	initcell;	/* cell to initialize list */

EXTERN	INPUT	*curinput;	/* current input being read from */
EXTERN	COUNT	seecount;	/* number of cells we can see */
EXTERN	COUNT	freqcount;	/* current count */
EXTERN	COUNT	genleft;	/* generations left before stopping */
EXTERN	COUNT	viewrows;	/* how many rows of cells can be seen */
EXTERN	COUNT	viewcols;	/* how many columns of cells can be seen */
EXTERN	BOOL	reserve;	/* reserved object names allowed */
EXTERN	BOOL	dowait;		/* must wait for input */
EXTERN	BOOL	interact;	/* still being interactive */
EXTERN	BOOL	stop;		/* user wants to stop current action */
EXTERN	BOOL	intjmpok;	/* ok to use interrupt jump buffer */
EXTERN	SCALE	defaultscale;	/* default scale value for new objects */
EXTERN	COUNT	defaultfrequency;	/* default frequency for new objects */
EXTERN	int	update;		/* flags for what needs updating */
EXTERN	int	mode;		/* mode of movement */
EXTERN	char	gridchar;	/* character to use for grid */
EXTERN	char	*errorstring;	/* error string to type */
EXTERN	char	*userlib;	/* user's life library if any */
EXTERN	jmp_buf	ttyjmp;		/* jump buffer for terminal input */
EXTERN	jmp_buf	intjmp;		/* jump buffer for interrupts */
EXTERN	INPUT	inputs[MAXINPUT];	/* list of input environments */
EXTERN	MACRO	macros[26];	/* list of macros */
EXTERN	char	stringbuf[STRINGSIZE];	/* characters for string value */
EXTERN	char	rulestring[20];	/* string describing rules */

EXTERN	char	vkill;		/* line kill character */
EXTERN	char	verase;		/* erase character */
EXTERN	char	vwerase;	/* word erase character */
EXTERN	char	veol;		/* end of line character */
EXTERN	char	veof;		/* EOF character */
EXTERN	char	vlnext;		/* literal next character */


/*
 * Externs for data which is initialized.
 */
extern	char	rules[];	/* life rules */
extern	DEV	ttydev;		/* tty device */

#if	defined(X11)
extern	DEV	x11dev;		/* graphics device */
#endif


/*
 * Procedures
 */
extern	OBJECT	*allocobject();		/* allocate new object */
extern	OBJECT	*findobject();		/* find object with certain name */
extern	OBJECT	*getobject();		/* get new object with certain name */
extern	ROW	*allocrow();		/* allocate new row */
extern	ROW	*findrow();		/* find a row */
extern	ROW	*getrow();		/* get a new row */
extern	CELL	*alloccell();		/* allocate new cell */
extern	CELL	*findcell();		/* find a cell */
extern	BOOL	addcell();		/* add a cell */
extern	BOOL	delcell();		/* delete a cell */
extern	char	*readstring();		/* read input line from user */
extern	void	listvariables();	/* list variables */
extern	VALUE	getvariable();		/* get value of variable */
extern	VALUE	getvariable1();		/* get value of single char variable */
extern	void	setvariable();		/* set value of variable */
extern	void	setvariable1();		/* set a single char variable */
extern	void	scaninit();		/* initialize for reading chars */
extern	void	scanabort();		/* abort reading current command */
extern	void	scaneof();		/* indicate no more chars ready */
extern	void	scanreset();		/* reset scanning pointers */
extern	void	setobject();		/* set object as current one */
extern	void	zeroobject();		/* delete all cells in object */
extern	void	destroyobject();	/* destroy object */
extern	void	moveobject();		/* move object to another */
extern	void	addobject();		/* add one object to another */
extern	void	copyobject();		/* copy object to another */
extern	void	listobjects();		/* list all objects */
extern	BOOL	minmax();		/* find min and max of object */
extern	BOOL	searchobject();		/* scan for next part of object */
extern	BOOL	markobject();		/* mark cells of an object */
extern	void	setmarks();		/* mark whole object */
extern	BOOL	copymarks();		/* copy marks in an object */
extern	void	clearmarks();		/* clear marks in an object */
extern	COUNT	markregion();		/* mark cells in a region */
extern	BOOL	markminmax();		/* find range of marked cells */
extern	COUNT	countmarks();		/* count marked cells */
extern	void	movemarkedobject();	/* move marked cells to object */
extern	void	copymarkedobject();	/* copy marked cells to object */
extern	void	rotatemarkedobject();	/* rotate marked cells */
extern	void	fliprowmarkedobject();	/* flip marked cells around a row */
extern	void	flipcolmarkedobject();	/* flip marked cells around a column */
extern	void	error();		/* error routine */
extern	int	readchar();		/* read next char from input */
extern	BOOL	abbrev();		/* check for abbreviation */
extern	BOOL	ttyisinput();		/* see if input is terminal */
extern	BOOL	settty();		/* setup to get input from tty */
extern	BOOL	setfile();		/* setup to get input from file */
extern	BOOL	setloop();		/* setup for execution of loop */
extern	void	endloop();		/* end the range of loop */
extern	BOOL	setmacro();		/* setup to define a macro */
extern	int	readline();		/* read line of input into buffer */
extern	BOOL	showhelp();		/* add some text to the help display */
extern	void	endhelp();		/* terminate the help display */
extern	void	readrle();		/* read rle format object */
extern	void	readxlife();		/* read xlife format object */
extern	void	readpicture();		/* read picture of object */
extern	void	writeobject();		/* write object to a file */
extern	void	writemacros();		/* write macros to file */
extern	void	dogeneration();		/* calculate one generation */
extern	void	dolinecommand();	/* read and execute line command */
extern	void	docommand();		/* read and execute command */
extern	void	backup();		/* backup state of object */
extern	void	checkrun();		/* see if doing generations */
extern	void	getfiles();		/* collect file names in a directory */
extern	void	listfiles();		/* list collected file names */
extern	void	setscale();		/* set scale for display */
extern	SCALE	autoscale();		/* do autoscale of object */
extern	void	positionview();		/* position view of object */
extern	void	updateview();		/* show view of object */
extern	void	viewstatus();		/* show status of object */
extern	void	beep();			/* ring terminal bell */

extern	char	*malloc();		/* allocate memory */
extern	char	*realloc();		/* reallocate memory */
extern	char	*getenv();		/* get environment variable */
extern	char	*strchr();		/* find character in string */

/* END CODE */
