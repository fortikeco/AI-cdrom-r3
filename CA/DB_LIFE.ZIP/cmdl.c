/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include "life.h"


/*
 * List of line command routines.
 */
static	void	c_destroy(), c_edit(), c_dumpmacros(), c_quit();
static	void	c_advance(), c_frequency(), c_objects(), c_zero();
static	void	c_read(), c_write(), c_ttyinput(), c_grid(), c_nogrid();
static	void	c_insert(), c_copy(), c_copymarked(), c_move(), c_movemarked();
static	void	c_help(), c_rules(), c_endinputlevel(), c_undo(), c_rename();
static	void	c_set(), c_variables(), c_type(), c_update(), c_wait();
static	void	c_mode(), c_unmark(), c_assign(), c_list(), c_default();


/*
 * Flags for line commands.
 */
#define	F_NONE		0x00	/* no special condition */
#define	F_NOARG		0x01	/* must not have an argument */
#define	F_ARG1		0x02	/* must have at least one argument */
#define	F_NORUN		0x04	/* illegal if running generations */
#define	F_UPDATE	0x08	/* update status if command completes */
#define	F_REDRAW	0x10	/* redraw screen if command completes */
#define	F_ABBR		0x20	/* abbreviation works even if ambiguous */


/*
 * Dispatch table for line commands.  Those commands which are ambiguous
 * must be defined so as to be contiguous in the table.  A spaces delimits
 * the command itself from the help string for the command.
 */
static	struct	cmdtab {
	char	*c_name;	/* command name */
	void	(*c_func)();	/* function to call */
	int	c_flags;	/* flags for command */
} cmdtab[] = {
	"advance (marked cells) expr (gens)", c_advance, F_NORUN|F_REDRAW|F_ABBR,
	"assign (button) num (to macro) ch", c_assign, F_ARG1|F_NORUN,
	"copy (current object to) obj", c_copy, F_ARG1|F_NORUN|F_ABBR,
	"copymarked (cells to) obj", c_copymarked, F_ARG1|F_NORUN,
	"destroy (object named) obj", c_destroy, F_ARG1|F_NORUN,
	"default param (to) expr", c_default, F_ARG1|F_ABBR,
	"dump (macros to) file", c_dumpmacros, F_ARG1|F_NORUN,
	"edit (object named) obj", c_edit, F_NORUN|F_REDRAW|F_ABBR,
	"endinputlevel", c_endinputlevel, F_NOARG|F_UPDATE,
	"frequency (of typeout is) expr", c_frequency, F_UPDATE,
	"grid (character is) char", c_grid, F_REDRAW,
	"help", c_help, F_NONE|F_ABBR,
	"insert (object from) obj", c_insert, F_ARG1|F_NORUN|F_REDRAW|F_ABBR,
	"list (readable *.l files)", c_list, F_REDRAW|F_ABBR,
	"mode (for movement)", c_mode, F_NORUN|F_UPDATE,
	"move (current object to) obj", c_move, F_ARG1|F_NORUN|F_REDRAW|F_ABBR,
	"movemarked (cells to) obj", c_movemarked, F_ARG1|F_NORUN|F_REDRAW,
	"nogrid", c_nogrid, F_NOARG|F_REDRAW,
	"objects (are listed)", c_objects, F_ABBR,
	"quit (program)", c_quit, F_NOARG|F_ABBR,
	"read (commands from) file", c_read, F_ARG1|F_NORUN|F_REDRAW|F_ABBR,
	"rename (current object to) obj", c_rename, F_ARG1|F_UPDATE,
	"rules (for life are) born live", c_rules, F_NORUN|F_UPDATE,
	"set (variable) name (to) expr", c_set, F_ARG1|F_ABBR,
	"ttyinput", c_ttyinput, F_REDRAW,
	"type (value of expression) expr", c_type, F_ARG1|F_UPDATE|F_ABBR,
	"undo (last change)", c_undo, F_NOARG|F_NORUN|F_REDRAW|F_ABBR,
	"unmark (all cells)", c_unmark, F_NOARG|F_NORUN|F_REDRAW,
	"update (view to be current)", c_update, F_NOARG,
	"variables (are listed)", c_variables, F_NOARG|F_REDRAW|F_ABBR,
	"wait (for computations)", c_wait, F_NOARG,
	"write (current object to) file", c_write, F_ARG1|F_NORUN|F_ABBR,
	"zero (current object)", c_zero, F_NOARG|F_NORUN|F_REDRAW|F_ABBR,
	0, 0, 0				/* ends the table */
};


/*
 * Read and execute a line mode command.  This kind of command echoes,
 * and is terminated by an end of line.  Numeric arguments are available.
 */
void
dolinecommand(arg1, arg2, got1, got2)
	VALUE	arg1;
	VALUE	arg2;
	BOOL	got1;
	BOOL	got2;
{
	register struct	cmdtab *cmd;	/* command structure */
	char		*name;		/* command name */
	char		*args;		/* arguments for command */
	int		flag;		/* flags for command */

	name = readstring("command: ");

	while (isblank(*name))
		name++;
	if (*name == '\0')
		return;

	args = name + strlen(name);
	while (isblank(args[-1]))
		args--;
	*args = '\0';

	for (args = name; *args && !isblank(*args); args++)
		;

	while (isblank(*args))
		*args++ = '\0';

	for (cmd = cmdtab; ; cmd++) {
		if (cmd->c_name == NULL)
			error("Unknown line command");

		if (abbrev(name, cmd[0].c_name) == 0)
			continue;

		if (cmd->c_flags & F_ABBR)
			break;

		if (abbrev(name, cmd[1].c_name) == 0)
			break;

		if (strcmp(name, cmd[0].c_name) == 0)
			break;

		if (cmd[1].c_flags & F_ABBR)
			continue;

		error("Ambiguous line command");
	}

	flag = cmd->c_flags;
	if (flag & F_NORUN)
		checkrun();
	if ((flag & F_ARG1) && (*args == '\0'))
		error("Missing argument");
	if ((flag & F_NOARG) && *args)
		error("Argument not allowed");

	(*cmd->c_func)(args, arg1, arg2, got1, got2);

	if (flag & F_UPDATE)
		update |= U_STAT;
	if (flag & F_REDRAW)
		update |= U_ALL;
}


/*
 * Advance marked cells by the specified number of generations.
 */
static void
c_advance(cp)
	char	*cp;
{
	COUNT	count;

	count = 1;
	if (*cp) {
		count = getexpression(cp);
		if (count <= 0)
			return;
	}
	backup();

	copymarkedobject(curobj, tempobject, MARK_USR);
	movemarkedobject(curobj, deleteobject, MARK_USR);

	genleft = count;
	while ((genleft > 0) && !stop)
		dogeneration(tempobject);

	cmark = MARK_USR;
	addobject(tempobject, curobj, RELATIVE);
	cmark = MARK_ANY;
}


/*
 * Assign a button to a macro.
 */
static void
c_assign(cp)
	char	*cp;
{
	VALUE	button;
	UCHAR	macro;

	button = 0;
	while (isdigit(*cp))
		button = button * 10 + *cp++ - '0';
	if (*cp && !isblank(*cp))
		error("Illegal button value");
	while (isblank(*cp))
		cp++;
	macro = *cp;
	if (macro)
		cp++;
	while (isblank(*cp))
		cp++;
	if (*cp || (macro && !islower(macro) && !isupper(macro)))
		error("Illegal macro name");
	if ((*dev->assign)(dev, button, macro))
		error("Button is not assignable");
}


/*
 * Copy the current object into another object.
 */
static void
c_copy(cp)
	char	*cp;
{
	copyobject(curobj, getobject(cp));
}


/*
 * Copy the currently marked cells into another object.
 */
static void
c_copymarked(cp)
	char	*cp;
{
	copymarkedobject(curobj, getobject(cp), MARK_USR);
}


/*
 * Set a default value for new objects.
 */
static void
c_default(cp)
	char	*cp;
{
	char	*param;
	VALUE	val;

	param = cp;
	while (*cp && !isblank(*cp))
		cp++;
	while (isblank(*cp))
		*cp++ = '\0';
	if (*cp == '\0')
		cp = "1";

	if (abbrev(param, "scale")) {
		val = getexpression(cp);
		if ((val == 0) || (val > MAXSCALE))
			error("Bad scale value");
		if (val == -1)
			val = 1;
		defaultscale = val;
		return;
	}

	if (abbrev(param, "frequency")) {
		val = getexpression(cp);
		if (val <= 0)
			error("Illegal frequency value");
		defaultfrequency = val;
		return;
	}

	error("Illegal parameter for defaulting");
}

/*
 * Destroy an existing object.
 */
static void
c_destroy(cp)
	char	*cp;
{
	register OBJECT	*obj;

	obj = findobject(cp);
	if (obj == NULL)
		error("No such object");
	destroyobject(obj);
}


/*
 * Dump list of macros to file.
 */
static void
c_dumpmacros(cp)
	char	*cp;
{
	writemacros(cp);
}


/*
 * Edit an object.  A null argument implies the previous object.
 */
static void
c_edit(cp)
	char	*cp;
{
	register OBJECT	*obj;

	obj = prevobj;
	if (*cp) {
		obj = findobject(cp);
		if (obj == NULL)
			obj = getobject(cp);
	}
	if (obj == NULL)
		error("No such object");
	setobject(obj);
}


/*
 * Undo the last change made to the current object.
 */
static void
c_undo()
{
	moveobject(curobj, tempobject);
	moveobject(backupobject, curobj);
	moveobject(tempobject, backupobject);
}


/*
 * End current input level.
 */
static void
c_endinputlevel()
{
	if (curinput <= inputs)
		error("Cannot end top level input");
	(*curinput->i_term)(curinput);
}


/*
 * Update the view even if inside of a loop or macro.
 */
static void
c_update()
{
	update |= U_ALL;
	updateview();
}


/*
 * Wait until all outstanding generation computations are finished.
 */
static void
c_wait()
{
	while (!stop && (genleft > 0)) {
		dogeneration(curobj);
		updateview();
	}
}


/*
 * Set output frequency for object.
 */
static void
c_frequency(cp)
	char	*cp;
{
	COUNT	freq;

	freq = 1;
	if (*cp)
		freq = getexpression(cp);
	if (freq <= 0)
		error("Illegal frequency value");
	curobj->o_frequency = freq;
	freqcount = freq;
}


/*
 * Set the mode associated with movement.
 */
static void
c_mode(cp)
	register char	*cp;
{
	if ((*cp == '\0') || abbrev(cp, "move")) {
		mode = M_MOVE;
		return;
	}

	if (abbrev(cp, "insert")) {
		mode = M_INSERT;
		return;
	}

	if (abbrev(cp, "delete")) {
		mode = M_DELETE;
		return;
	}

	error("Illegal movement mode");
}


/*
 * Unmark all cells.
 */
static void
c_unmark()
{
	clearmarks(curobj, MARK_SEE);
}


/*
 * Select the character used for the background of the screen.
 */
static void
c_grid(cp)
	char	*cp;
{
	if (*cp == '\0')
		cp = ".";
	if ((*cp < ' ') || (cp[1] != '\0'))
		error("Bad grid character");
	gridchar = *cp;
}


/*
 * Set so we don`t see a grid on the screen.
 */
static void
c_nogrid()
{
	gridchar = ' ';
}


/*
 * Type list of line commands.
 */
static void
c_help()
{
	struct cmdtab	*cmd;
	int		count;
	char		buf[80];

	showhelp("\
The following table lists all line mode commands.  Unique abbreviations are\n\
allowed.  Commands shown with '*' can be abbreviated even when ambiguous.\n");

	count = 0;
	for (cmd = cmdtab; cmd->c_name; cmd++) {
		if ((count++ % 2) == 0)
			showhelp("\n");
		sprintf(buf, "%c %-35s", ((cmd->c_flags & F_ABBR) ? '*' : ' '),
			cmd->c_name);
		showhelp(buf);
	}

	showhelp("\n");
	endhelp();
}


/*
 * Display a list of the *.l files that can be read.
 * If a pattern is given, only list files matching that pattern.
 */
static void
c_list(cp)
	char	*cp;
{
	LIST	names;

	names.argc = 0;
	names.maxargc = 0;
	names.used = 0;
	names.maxused = 0;

	getfiles(&names, ".", cp, 2, 1);

	if (userlib)
		getfiles(&names, userlib, cp, strlen(userlib) + 1, MAXLIST);

	getfiles(&names, LIFELIB, cp, strlen(LIFELIB) + 1, MAXLIST);

	if (names.argc == 0)
		error("No files found");

	listfiles(&names);

	free(names.buf);
	free((char *) names.argv);
}


/*
 * Insert another object into this one.
 */
static void
c_insert(cp)
	char	*cp;
{
	register OBJECT	*obj;

	obj = findobject(cp);
	if (obj == NULL)
		error("No such object");
	cmark = MARK_USR;
	backup();
	addobject(obj, curobj, RELATIVE);
	cmark = MARK_ANY;
}


/*
 * Show list of objects.
 */
static void
c_objects(cp)
	char	*cp;
{
	BOOL	all;

	all = ((*cp == '-') || (*cp == 'a'));
	listobjects(all);
}


/*
 * Rename the current object to something else.
 */
static void
c_rename(cp)
	char	*cp;
{
	if (curobj->o_reserved)
		error("Cannot rename reserved object");
	if (strlen(cp) > MAXNAME)
		error("Name too long");
	if (findobject(cp))
		error("Name already exists");
	if (BADNAME(cp))
		error("Cannot create reserved name");
	strcpy(curobj->o_name, cp);
}


/*
 * Move current object into another object.
 */
static void
c_move(cp)
	char	*cp;
{
	moveobject(curobj, getobject(cp));
}


/*
 * Move currently markeded cells into another object.
 */
static void
c_movemarked(cp)
	char	*cp;
{
	movemarkedobject(curobj, getobject(cp), MARK_USR);
}


/*
 * Set the value of a variable.
 */
static void
c_set(cp)
	char	*cp;
{
	char	*exp;

	for (exp = cp; *exp && !isblank(*exp) && (*exp != '='); exp++)
		;

	if (isblank(*exp)) {		/* skip spaces */
		*exp++ = '\0';
		while (isblank(*exp))
			exp++;
	}

	if (*exp == '\0') {		/* no expression, set to zero */
		setvariable(cp, 0);
		return;
	}

	if (*exp == '=')
		*exp++ = '\0';

	setvariable(cp, getexpression(exp));
}


/*
 * Type the value of an expression.
 */
static void
c_type(cp)
	char	*cp;
{
	static	char	buf[30];

	sprintf(buf, "Value = %ld", getexpression(cp));
	errorstring = buf;
}


/*
 * Display the values of all the variables.
 */
static void
c_variables()
{
	listvariables();
}


/*
 * Quit program
 */
static void
c_quit()
{
	(*dev->close)(dev);
	exit(0);
}


/*
 * Read commands or object from file, defaulting extension if needed.
 */
static void
c_read(cp)
	char	*cp;
{
	backup();
	if (setfile(cp))
		error("Cannot open input file");
}


/*
 * Set new life rules.
 */
static void
c_rules(cp)
	register char	*cp;
{
	register char	*bp;	/* born string */
	register char	*lp;	/* live string */

	if (*cp == '\0')
		cp = "3,23";

	bp = cp;
	while (((*cp >= '0') && (*cp <= '8')) || (*cp == '-'))
		cp++;

	if (*cp == '\0')
		error("Missing rule string");

	if ((*cp != ',') && !isblank(*cp))
		error("Bad born string");

	*cp++ = '\0';
	while ((*cp == ',') || isblank(*cp))
		cp++;

	lp = cp;
	while (((*cp >= '0') && (*cp <= '8')) || (*cp == '-'))
		cp++;

	if (*cp != '\0')
		error("Bad live string");

	for (cp = rules; cp < &rules[18]; cp++)
		*cp = 0;

	for (; *bp; bp++)
		if (*bp != '-')
			rules[*bp - '0'] = 1;

	for (; *lp; lp++)
		if (*lp != '-')
			rules[*lp - '0' + LIFE] = 1;

	bp = rulestring;
	for (cp = rules; cp < &rules[LIFE]; cp++) {
		if (*cp)
			*bp++ = '0' + (cp - rules);
	}

	if (bp == rulestring)
		*bp++ = '-';

	*bp++ = ',';
	for (cp = &rules[LIFE]; cp < &rules[18]; cp++) {
		if (*cp)
			*bp++ = ('0' - LIFE) + (cp - rules);
	}

	if (bp[-1] == ',')
		*bp++ = '-';
	*bp = '\0';
}


/*
 * Read commands from the terminal.  Useful in loops or command files.
 * If the -c argument is given, we don't do it if no input is ready.
 */
static void
c_ttyinput(cp)
	register char	*cp;
{
	if ((*cp == '-') || (*cp == 'c')) {	/* check for input */
		if (!(*dev->inputready)(dev))
			return;
	}

	if (settty())
		error("Nesting too deep");
}


/*
 * Write object to file.
 */
static void
c_write(cp, arg1, arg2, got1, got2)
	register char	*cp;
	VALUE	arg1;
	VALUE	arg2;
	BOOL	got1;
	BOOL	got2;
{
	char	*method;

	if (!got1)
		arg1 = WRITECOLS;
	method = "picture";
	if (*cp == '-') {
		method = cp + 1;
		while (*cp && !isblank(*cp))
			cp++;
		while (isblank(*cp))
			*cp++ = '\0';
	}
	writeobject(curobj, method, cp, arg1 ? WRITEROWS : 0, arg1);
}


/*
 * Zero out current object.
 */
static void
c_zero()
{
	register OBJECT	*obj;

	obj = curobj;

	backup();

	zeroobject(obj);

	obj->o_gen = 0;
	obj->o_born = 0;
	obj->o_died = 0;
	obj->o_currow = 0;
	obj->o_curcol = 0;
	obj->o_prow = 0;
	obj->o_pcol = 0;
	obj->o_autoscale = FALSE;

	setscale(obj, defaultscale);
	mode = M_MOVE;
	obj->o_frequency = defaultfrequency;
	freqcount = defaultfrequency;
}


/*
 * See if one string is an abbreviation of another.
 * Returns nonzero if first string is an abbreviation.
 */
BOOL
abbrev(str1, str2)
	register char	*str1;
	register char	*str2;
{
	if ((str1 == NULL) || (str2 == NULL))
		return FALSE;
	while (*str1) {
		if (*str1++ != *str2++)
			return FALSE;
	}
	return TRUE;
}

/* END CODE */
