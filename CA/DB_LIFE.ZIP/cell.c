/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include "life.h"


/*
 * Return a row structure for a given row number, returning NULL if not there.
 */
ROW *
findrow(obj, row)
	OBJECT	*obj;
	COORD	row;
{
	register ROW	*rp;

	for (rp = obj->o_firstrow; (row > rp->r_row); rp = rp->r_next)
		;

	if (rp->r_row != row)
		return NULL;

	return rp;
}


/*
 * Return a row structure for a given row number, creating it if needed.
 */
ROW *
getrow(obj, row)
	OBJECT	*obj;
	COORD	row;
{
	register ROW	*rp;	/* current row */
	register ROW	*nrp;	/* next row */
	register ROW	*prp;	/* previous row */

	rp = obj->o_firstrow;
	if (row < rp->r_row) {		/* at front */
		nrp = allocrow();
		nrp->r_row = row;
		nrp->r_next = obj->o_firstrow;
		obj->o_firstrow = nrp;
		if (nrp->r_next == termrow)
			obj->o_lastrow = nrp;
		return nrp;
	}

	if (row >= obj->o_lastrow->r_row)
		rp = obj->o_lastrow;

	while (row > rp->r_row) {
		prp = rp;
		rp = rp->r_next;
	}

	if (row == rp->r_row) {
		return rp;
	}

	nrp = allocrow();
	nrp->r_row = row;
	nrp->r_next = rp;
	prp->r_next = nrp;

	if (nrp->r_next == termrow)
		obj->o_lastrow = nrp;

	return nrp;
}


/*
 * Find a cell given its coordinates, returning NULL if not found.
 */
CELL *
findcell(obj, row, col)
	OBJECT	*obj;
	COORD	row;
	COORD	col;
{
	register CELL	*cp;
	ROW	*rp;

	rp = findrow(obj, row);
	if (rp == NULL)
		return NULL;

	for (cp = rp->r_firstcell; col > cp->c_col; cp = cp->c_next)
		;

	if (col != cp->c_col)
		return NULL;

	return cp;
}


/*
 * Create a cell at a given row and column.  Returns nonzero if the cell
 * already existed.  If the cell is new, it is marked with the current
 * mark value of the object.
 */
BOOL
addcell(obj, row, col)
	OBJECT	*obj;
	COORD	row;
	COORD	col;
{
	register CELL	*cp;	/* current cell */
	register CELL	*ncp;	/* next cell */
	register CELL	*pcp;	/* previous cell */
	ROW		*rp;

	rp = getrow(obj, row);
	cp = rp->r_firstcell;

	if ((cp != termcell) && (col >= rp->r_lastcell->c_col)) {
		pcp = rp->r_lastcell;		/* at end */
		if (col == pcp->c_col)
			return TRUE;

		ncp = alloccell();
		ncp->c_col = col;
		ncp->c_marks |= obj->o_mark;
		ncp->c_next = termcell;
		pcp->c_next = ncp;
		rp->r_lastcell = ncp;
		rp->r_count++;
		obj->o_count++;
		return FALSE;
	}

	if (col < cp->c_col) {
		ncp = alloccell();		/* at front */
		ncp->c_col = col;
		ncp->c_marks |= obj->o_mark;
		ncp->c_next = cp;
		rp->r_firstcell = ncp;
		if (cp == termcell)
			rp->r_lastcell = ncp;
		rp->r_count++;
		obj->o_count++;
		return FALSE;
	}

	while (col > cp->c_col) {		/* in middle */
		pcp = cp;
		cp = pcp->c_next;
	}

	if (col == cp->c_col)
		return TRUE;

	ncp = alloccell();
	ncp->c_col = col;
	ncp->c_marks |= obj->o_mark;
	ncp->c_next = cp;
	pcp->c_next = ncp;
	if (cp == termcell)
		rp->r_lastcell = ncp;
	rp->r_count++;
	obj->o_count++;

	return FALSE;
}


/*
 * Delete a cell at a given coordinate.  Returns nonzero if it did not exist.
 */
BOOL
delcell(obj, row, col)
	OBJECT	*obj;
	COORD	row;
	COORD	col;
{
	register ROW	*rp;
	register CELL	*pcp;	/* previous cell */
	register CELL	*cp;	/* current cell */

	rp = findrow(obj, row);
	if (rp == NULL)
		return TRUE;

	pcp = NULL;
	cp = rp->r_firstcell;

	while (col > cp->c_col) {
		pcp = cp;
		cp = cp->c_next;
	}

	if (col != cp->c_col)
		return TRUE;

	if (pcp)
		pcp->c_next = cp->c_next;
	else
		rp->r_firstcell = cp->c_next;

	if (cp->c_next == termcell)
		rp->r_lastcell = pcp;

	cp->c_next = freecells;
	freecells = cp;
	rp->r_count--;
	obj->o_count--;

	return FALSE;
}

/* END CODE */
