/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include <sys/types.h>
#include <dirent.h>
#include "life.h"


static	int	tty_char();		/* terminal routines */
static	void	tty_term();

static	int	file_char();		/* file routines */
static	void	file_term();

static	int	loop_char();		/* loop routines */
static	void	loop_term();

static	int	macro_char();		/* macro routines */
static	void	macro_term();

static	FILE	*openlibfile();
static	BOOL	matchfile();
static	BOOL	spacewait();
static	int	sortfunc();
static	void	addfile();

static	int	helprow;		/* current row of help text */
static	BOOL	helpbusy;		/* true if doing help display */
static	BOOL	helpabort;		/* true if help is aborted */


/*
 * Read the next character from the appropriate input source.
 * EOF is never returned by this routine (longjmps are done instead).
 * This routine is usually called indirectly by scanchar.
 */
int
readchar()
{
	register INPUT	*ip;
	int	ch;

	while (TRUE) {
		ip = curinput;
		ch = (*ip->i_getchar)(ip);
		if (ch != EOF)
			break;
		(*ip->i_term)(ip);
	}

	return ch;
}


/*
 * Determine if the next input character to be read is from the terminal.
 * Returns TRUE if so.
 */
BOOL
ttyisinput()
{
	register INPUT	*ip;

	ip = curinput;
	while ((ip->i_type == INP_LOOP) && (ip->i_first))
		ip--;

	return ip->i_type == INP_TTY;
}


/*
 * Set up to read commands from the terminal.  The lowest level of input
 * never quits, and is unusual in that it doesn't usually block waiting for
 * input.  Returns nonzero if failed.
 */
BOOL
settty()
{
	register INPUT	*ip;

	ip = curinput + 1;
	if (ip >= &inputs[MAXINPUT])
		return TRUE;

	ip->i_getchar = tty_char;
	ip->i_term = tty_term;
	ip->i_type = INP_TTY;
	update |= U_STAT;
	curinput = ip;
	return FALSE;
}


/*
 * Read next character from the terminal if it is ready.  If nothing is
 * going on we will wait for it anyway, to prevent excessive runtimes.
 * If something is going on, we will longjmp away if input is not ready.
 * We set the interactive flag to indicate we are talking to the user.
 */
static int
tty_char(ip)
	INPUT	*ip;
{
	int	ch;
	int	wait;

	interact = TRUE;

	wait = dowait || !(update || (genleft > 0));

	if (wait) {
		if (setjmp(intjmp)) {
			intjmpok = FALSE;
			return '\0';
		}

		intjmpok = TRUE;
	}

	ch = (*dev->readchar)(dev, wait);

	intjmpok = FALSE;

	if ((ch == EOF) && !wait)
		scaneof();

	if (errorstring) {	/* disable error message */
		errorstring = NULL;
		update |= U_STAT;
	}

	return ch;
}


/*
 * Terminate reading from the terminal.  If we are reading from the lowest
 * level of terminal input, this is a no-op, since that level can never return.
 */
static void
tty_term(ip)
	INPUT	*ip;
{
	if (ip > inputs)
		ip--;
	curinput = ip;
	update |= U_STAT;
}


/*
 * Set up to read commands from a given file name.  When the file is complete,
 * some parameters (like the current cursor position) will be restored to their
 * original value.  Returns nonzero if cannot set up to read the file.
 */
BOOL
setfile(name)
	char	*name;
{
	register INPUT	*ip;
	FILE		*fp;
	int		ch;

	ip = curinput + 1;
	if (ip >= &inputs[MAXINPUT])
		return TRUE;

	fp = openlibfile(name, "r");
	if (fp == NULL)
		return TRUE;

	ip->i_file = fp;
	ip->i_getchar = file_char;
	ip->i_term = file_term;
	ip->i_type = INP_FILE;
	ip->i_obj = curobj;
	ip->i_row = crow;
	ip->i_col = ccol;
	ip->i_prow = prow;
	ip->i_pcol = pcol;
	prow = crow;
	pcol = ccol;
	update |= U_STAT;
	curinput = ip;

	/*
	 * Now peek at the first character of the file to determine what type of
	 * format it is.  It can be either our own format, or else rle format,
	 * or else xlife format.  For our format, the contents will be read
	 * after we return.  But for the other formats, we must read in the
	 * complete file here.
	 */
	ch = fgetc(fp);
	if (ch != EOF)
		ungetc(ch, fp);

	switch (ch) {
		case 'x':
			readrle(fp);
			(*ip->i_term)(ip);
			break;

		case '#':
			readxlife(fp);
			(*ip->i_term)(ip);
			break;

		case '!':
			break;

		default:
			error("Unknown file format");
	}

	return FALSE;
}


/*
 * Open a life library file, trying various transformed names if necessary.
 * The order of the transformations which are tried is:
 *	1.  Name exactly as given.
 *	2.  Name with LIFEEXT appended to it.
 *	3.  Name in the user's library directory.
 *	4.  Name with LIFEEXT appended to it in the user's library.
 *	5	Name in the system's library directory.
 *	6.  Name with LIFEEXT appended to it in the system library.
 * Returns the file handle if the open is successful, or NULL if all the
 * open attempts failed.
 */
static FILE *
openlibfile(name, mode)
	char	*name;
	char	*mode;
{
	FILE	*fp;
	char	buf[MAXPATH];

	fp = fopen(name, mode);
	if (fp)
		return fp;

	strcpy(buf, name);
	strcat(buf, LIFEEXT);
	fp = fopen(buf, mode);
	if (fp)
		return fp;

	if (*name == '/')
		return NULL;

	if (userlib) {
		strcpy(buf, userlib);
		strcat(buf, "/");
		strcat(buf, name);
		fp = fopen(buf, mode);
		if (fp)
			return fp;

		strcat(buf, LIFEEXT);
		fp = fopen(buf, mode);
		if (fp)
			return fp;
	}

	strcpy(buf, LIFELIB);
	strcat(buf, "/");
	strcat(buf, name);
	fp = fopen(buf, mode);
	if (fp)
		return fp;

	strcat(buf, LIFEEXT);
	return fopen(buf, mode);
}


/*
 * Here to read next character from a file.  Called by readchar when
 * input source is a file.  Returns EOF on end of file.
 */
static int
file_char(ip)
	register INPUT	*ip;
{
	return fgetc(ip->i_file);
}


/*
 * Here on end of file or error to close the input file and restore some
 * of the previous state such as the cursor location.
 */
static void
file_term(ip)
	register INPUT	*ip;
{
	fclose(ip->i_file);
	curobj = ip->i_obj;
	crow = ip->i_row;
	ccol = ip->i_col;
	prow = ip->i_prow;
	pcol = ip->i_pcol;
	update |= U_STAT;
	curinput = (ip - 1);
}


/*
 * Set up for execution of a loop.  This remembers the initial and final
 * loop values, and sets up to remember commands as they are given.
 * This is also used for defining a macro command.  The given character
 * will be assigned the string defined by the loop.
 * Returns nonzero if failed.
 */
BOOL
setloop(begval, endval, ch)
	VALUE	begval;
	VALUE	endval;
	int	ch;
{
	register INPUT	*ip;

	ip = curinput + 1;
	if (ip >= &inputs[MAXINPUT])
		return TRUE;

	ip->i_begptr = malloc(LOOPSIZE);
	if (ip->i_begptr == NULL)
		return TRUE;

	ip->i_endptr = ip->i_begptr + LOOPSIZE;
	ip->i_curptr = ip->i_begptr;
	ip->i_first = TRUE;
	ip->i_getchar = loop_char;
	ip->i_term = loop_term;
	ip->i_type = INP_LOOP;
	ip->i_curval = begval;
	ip->i_endval = endval;
	ip->i_macro = ch;
	update |= U_STAT;
	curinput = ip;
	return FALSE;
}


/*
 * End the range of the currently defined loop.  At this point, all of
 * the characters of the loop have been read in and saved, and we can
 * just proceed to iterate over them.  The next read will find out that
 * the first iteration of the loop is over.
 */
void
endloop()
{
	register INPUT	*ip;

	ip = curinput;
	if (ip->i_type != INP_LOOP)
		error("Loop not being defined");

	ip->i_endptr = ip->i_curptr - 1;	/* end before loop term cmd */
	ip->i_first = FALSE;
}


/*
 * Read one character from a loop buffer.  If at the end of the buffer, the
 * pointer is reset so that the buffer is reread.  When enough iterations
 * have been processed, EOF is returned.  A special case exists the first time
 * through the loop at the first nesting level, in that we don't yet have
 * the characters necessary for the loop, and so we have to read them by
 * ourself.
 */
static int
loop_char(ip)
	register INPUT	*ip;
{
	int	ch;

	if (ip->i_first) {	/* collecting input chars */
		if (ip->i_curptr >= ip->i_endptr)
			error("Loop too long");
		ch = (*ip[-1].i_getchar)(ip - 1);	/* char from previous level */
		if (ch == EOF)
			error("End of file in loop");
		*ip->i_curptr++ = ch;
		return ch;
	}

	if (ip->i_curptr >= ip->i_endptr) {	/* done with one iteration */
		if (ip->i_curval == ip->i_endval)
			return EOF;

		ip->i_curval += ((ip->i_curval < ip->i_endval) ? 1 : -1);
		ip->i_curptr = ip->i_begptr;
	}

	return *ip->i_curptr++;
}


/*
 * Terminate reading from a loop buffer.  If this was the definition of
 * a macro character, remember it for later.
 */
static void
loop_term(ip)
	INPUT	*ip;
{
	register MACRO	*mp;

	mp = &macros[ip->i_macro - 'a'];
	if ((mp >= macros) && (mp < &macros[26])) {
		if (mp->m_begptr)
			free(mp->m_begptr);
		mp->m_begptr = ip->i_begptr;
		mp->m_endptr = ip->i_endptr;
	} else
		free(ip->i_begptr);	/* or free buffer */

	update |= U_STAT;
	curinput = (ip - 1);
}


/*
 * Set up to read a defined macro command.  Returns nonzero if failed.
 */
BOOL
setmacro(arg1, arg2, ch)
	VALUE	arg1;
	VALUE	arg2;
	int	ch;
{
	register INPUT	*ip;		/* current input */
	register MACRO	*mp;		/* macro command */

	mp = &macros[ch - 'a'];
	if ((mp < macros) || (mp >= &macros[26]) || (mp->m_begptr == NULL))
		return TRUE;

	ip = curinput + 1;
	if (ip >= &inputs[MAXINPUT])
		return TRUE;

	ip->i_getchar = macro_char;
	ip->i_term = macro_term;
	ip->i_begptr = mp->m_begptr;
	ip->i_curptr = mp->m_begptr;
	ip->i_endptr = mp->m_endptr;
	ip->i_type = INP_MACRO;
	ip->i_macro = ch;
	ip->i_curval = arg1;
	ip->i_endval = arg2;
	update |= U_STAT;
	curinput = ip;
	return FALSE;
}


/*
 * Read next character from macro definition.
 * Returns EOF when the macro is finished.
 */
static int
macro_char(ip)
	register INPUT	*ip;
{
	if (ip->i_curptr >= ip->i_endptr)
		return EOF;

	return *ip->i_curptr++;
}


/*
 * Terminate reading from a macro definition.
 */
static void
macro_term(ip)
	INPUT	*ip;
{
	curinput = (ip - 1);
	update |= U_STAT;
}


/*
 * Read a line from the user terminated by a newline (which is removed).
 * Editing of the input line is fully handled.  The prompt string and the
 * input line are only visible if the current input is from the terminal.
 * Returns a pointer to the null-terminated string.
 */
char *
readstring(prompt)
	char	*prompt;
{
	scanreset();			/* no more scan interference */

	if (prompt == NULL)
		prompt = "";		/* set prompt if given NULL */

	if (!ttyisinput())
		prompt = NULL;		/* no window stuff if not tty */

	dowait = TRUE;			/* must wait for tty chars */
	readline(prompt, stringbuf, STRINGSIZE, 0);
	dowait = FALSE;

	if (prompt)
		update |= U_STAT;

	if (stop)
		error("Command aborted");

	return stringbuf;
}


/*
 * Read some input while possibly showing it on the status line.
 * If the prompt string is NULL, then editing is performed without
 * any display activity (useful when reading commands from scripts).
 * Otherwise, the prompt is shown in the window along with any input.
 * A trailing null character is inserted in the buffer.  The buffer may
 * contain initial data which will initially appear in the window, and
 * which can be edited by the user.  Initcount specifies the number of
 * initial characters in the buffer, so that a value of zero indicates
 * that there is no such data.  Editing of the input is handled.  If the
 * buffer fills up, the user is warned with beeps and further input is
 * ignored.  Returns number of bytes of data read.
 */
int
readline(prompt, buf, count, initcount)
	char	*prompt;		/* prompt string (if any) */
	char	*buf;			/* address of the storage buffer */
	int	count;			/* maximum number of bytes allowed */
	int	initcount;		/* number of bytes already in buffer */
{
	register int	ch;		/* character which was read */
	register char	*bp;		/* current buffer pointer location */
	char	*endbp;			/* end of buffer */
	BOOL	redraw;			/* need to redisplay input */

	redraw = TRUE;
	bp = buf;
	endbp = bp + count - 1;
	if (initcount > 0) {
		if (initcount >= count)
			initcount = count - 1;
		bp = &buf[initcount];
	}

	while (TRUE) {
		if (prompt) {
			if (redraw) {
				*bp = '\0';
				(*dev->showstatus)(dev, prompt);
				(*dev->addstatus)(dev, buf);
				redraw = FALSE;
			}
			(*dev->update)(dev, 1);
		}

		ch = readchar();

		if (stop) {			/* interrupted */
			buf[0] = '\0';
			return 0;
		}

		if (ch == '\0')			/* ignore nulls */
			continue;

		if (ch == vlnext) {		/* literal input */
			ch = readchar();
			if (stop) {
				buf[0] = '\0';
				return 0;
			}
			goto store;
		}

		if (ch == '\n') {		/* end of line */
			*bp = '\0';
			return bp - buf;
		}

		if (ch == verase) {		/* character erase */
			if (bp <= buf)
				continue;
			bp--;
			redraw = TRUE;
			continue;
		}

		if (ch == vkill) {		/* line erase */
			bp = buf;
			redraw = TRUE;
			continue;
		}

		if (ch == vwerase) {		/* word erase */
			if (bp <= buf)
				continue;
			while ((bp > buf) && ((bp[-1] == '\n')
				|| isblank(bp[-1])))
					bp--;
			while ((bp > buf) && (bp[-1] != '\n')
				&& !isblank(bp[-1]))
			       		bp--;
			redraw = TRUE;
			continue;
		}

store:		if (bp >= endbp) {		/* buffer is full */
			beep();
			continue;
		}

		*bp = ch;
		bp[1] = '\0';

		if (prompt) {
			(*dev->addstatus)(dev, bp);
			(*dev->update)(dev, 1);
		}

		bp++;
	}
}


/*
 * Routine called to wait until a space, newline, or escape character
 * is typed.  It is assumed that the screen contains a help display
 * that we can append our message to.  If the more flag is used, and
 * the user types escape instead of a space, then we return nonzero.
 */
static BOOL
spacewait(more)
	BOOL	more;
{
	int	ch;

	scanreset();			/* throw out stored chars */

	if (more)
		(*dev->addhelp)(dev, "\n[Type <space> to continue or <esc> to return]");
	else
		(*dev->addhelp)(dev, "\n[Type <space> to return]");
	(*dev->update)(dev);

	update |= U_ALL;
	dowait = TRUE;			/* must wait for chars */

	do {
		if (stop) {
			ch = ESC;
			break;
		}
		ch = readchar();
	} while ((ch != ' ') && (ch != ESC) && (ch != '\n'));

	dowait = FALSE;

	return (more && (ch == ESC));
}


/*
 * Write all defined macros to a file so they can be read back in later.
 */
void
writemacros(name)
	char	*name;			/* file name to write to */
{
	MACRO	*mp;
	FILE	*fp;
	UCHAR	*cp;

	fp = fopen(name, "w");
	if (fp == NULL)
		error("Cannot create file");

	fputs("! macros\n", fp);

	for (mp = macros; mp < &macros[26]; mp++) {
		if ((mp->m_begptr == NULL) || (mp->m_begptr >= mp->m_endptr))
			continue;

		fprintf(fp, "<%c", 'a' + (mp - macros));

		for (cp = mp->m_begptr; cp < mp->m_endptr; cp++)
			fputc(*cp, fp);

		fputs(">!\n", fp);
	}

	fflush(fp);
	if (ferror(fp)) {
		fclose(fp);
		error("Write failed");
	}
	if (fclose(fp))
		error("Close failed");
}


/*
 * Collect all *.l files under a directory which contain the specified pattern.
 * The names are appended to the given list of strings.  If desired, the
 * list can have uninitialized pointers (indicated by max counts of zero).
 * For speed, the assumption is made that *.l files are valid life files,
 * and so are not directories.  The skip length is how many characters of
 * the given directory name are not to be displayed in the list of files.
 * The depth is how deep to allow the search to go.
 */
void
getfiles(list, dirname, pattern, skiplen, depth)
	LIST	*list;
	char	*dirname;
	char	*pattern;
{
	DIR		*dirp;
	struct	dirent	*dp;
	char		*name;
	char		*nameappend;
	int		len;
	char		fullname[MAXPATH];

	dirp = opendir(dirname);
	if (dirp == NULL)
		return;

	depth--;
	strcpy(fullname, dirname);
	strcat(fullname, "/");
	nameappend = fullname + strlen(fullname);

	while ((dp = readdir(dirp)) != NULL) {
		name = dp->d_name;
		len = strlen(name) - sizeof(LIFEEXT) + 1;
		strcpy(nameappend, name);

		if ((len <= 0) || strcmp(name + len, LIFEEXT)) {
			if (depth && strcmp(name, ".") && strcmp(name, ".."))
				getfiles(list, fullname, pattern, skiplen, depth);
			fflush(stdout);
			continue;
		}

		nameappend[len] = '\0';

		if (!(*pattern) || matchfile(fullname + skiplen, pattern))
			addfile(list, fullname + skiplen);
	}

	closedir(dirp);
}


/*
 * Add a file name to the specified list.
 */
static void
addfile(list, name)
	LIST	*list;
	char	*name;
{
	int	len;
	int	size;
	char	*mem;

	len = strlen(name);

	if (list->argc >= list->maxargc) {
		size = (list->maxargc + LISTARGSIZE) * sizeof(char *);
		if (list->maxargc)
			mem = realloc((char *) list->argv, size);
		else
			mem = malloc(size);
		if (mem == NULL)
			return;
		list->argv = (char **) mem;
		list->maxargc += LISTARGSIZE;
	}

	if (list->used + len >= list->maxused) {
		size = list->maxused + len + LISTBUFSIZE;
		if (list->maxused)
			mem = realloc(list->buf, size);
		else
			mem = malloc(size);
		if (mem == NULL)
			return;
		for (size = 0; size < list->argc; size++)
			list->argv[size] = mem +
				(list->argv[size] - list->buf);
		list->buf = mem;
		list->maxused += len + LISTBUFSIZE;
	}

	list->argv[list->argc] = &list->buf[list->used];
	strcpy(&list->buf[list->used], name);
	list->used += (len + 1);
	list->argc++;
}


/*
 * Sort and display a list of file names in the help window.
 * If many files are displayed, the user is asked to page through them all.
 */
void
listfiles(list)
	LIST	*list;
{
	int	col;
	int	colwidth;
	int	argc;
	char	**argv;
	char	*cp;

	if (list->argc <= 0)
		return;

	qsort((char *) list->argv, list->argc, sizeof(char *), sortfunc);

	colwidth = MAXFILE - sizeof(LIFEEXT) + 2;
	col = 0;

	argv = list->argv;
	argc = list->argc;
	while (argc-- > 0) {
		cp = *argv++;
		showhelp(cp);
		showhelp(" ");
		col += strlen(cp) + 1;

		while (col % colwidth) {
			showhelp(" ");
			col++;
		}

		if (col + colwidth > dev->textcols) {
			showhelp("\n");
			col = 0;
		}
	}

	if (col)
		showhelp("\n");

	endhelp();
}


/*
 * Sort function for files.
 * This is a alphabetic-numeric sort, so numbers appear in a natural order.
 */
static int
sortfunc(cp1, cp2)
	char	**cp1;
	char	**cp2;
{
	char	*s1;
	char	*s2;
	int	c1;
	int	c2;
	long	n1;
	long	n2;

	s1 = *cp1;
	s2 = *cp2;

	while (TRUE) {
		c1 = *s1++;
		c2 = *s2++;

		if ((c1 == '\0') && (c2 == '\0'))
			return 0;

		if (!isdigit(c1) || !isdigit(c2)) {
			if (c1 == c2)
				continue;
			return c1 - c2;
		}

		n1 = c1 - '0';
		n2 = c2 - '0';
		while (isdigit(*s1))
			n1 = n1 * 10 + *s1++ - '0';
		while (isdigit(*s2))
			n2 = n2 * 10 + *s2++ - '0';

		if (n1 == n2)
			continue;
		return n1 - n2;
	}
}


/*
 * Add some text to the help screen.  The text may contain newlines,
 * but line wrapping is not done.  If the text goes to the bottom of
 * the screen, the output is stopped and the user is requested to type
 * a space to proceed, or escape to abort.  If the user aborts, then
 * all further help output is suppressed until the endhelp call is made,
 * and this routine returns nonzero.  If this routine is called, then
 * endhelp MUST also be called before non-help output occurs.
 */
BOOL
showhelp(str)
	char	*str;
{
	int	len;
	char	*cp;
	char	buf[80];

	if (helpbusy && helpabort)
		return TRUE;

	if (!helpbusy) {
		(*dev->showhelp)(dev);
		helprow = 0;
		helpabort = FALSE;
		helpbusy = TRUE;
	}

	while (*str) {
		if (helprow > dev->textrows - 3) {
			if (spacewait(TRUE)) {
				helpabort = TRUE;
				return TRUE;
			}
			(*dev->showhelp)(dev);
			helprow = 0;
		}

		cp = strchr(str, '\n');
		if ((cp == NULL) || (cp[1] == '\0')) {
			(*dev->addhelp)(dev, str);
			if (cp)
				helprow++;
			return FALSE;
		}

		/*
		 * Copy the line and null terminate it in order to display it.
		 */
		cp++;
		while (str != cp) {
			len = (cp - str);
			if (len >= sizeof(buf))
				len = sizeof(buf) - 1;
			memcpy(buf, str, len);
			buf[len] = '\0';
			(*dev->addhelp)(dev, buf);
			str += len;
		}
		helprow++;
	}

	return FALSE;
}


/*
 * End the help display, by waiting for the user to type a space.
 */
void
endhelp()
{
	if (helpbusy && !helpabort)
		spacewait(FALSE);
	helpbusy = FALSE;
	helpabort = FALSE;
	helprow = 0;
}


/*
 * See if the specified file name is matched by the specified pattern.
 * For our purposes, matching means the pattern is contain somewhere
 * within the name.
 */
static BOOL
matchfile(name, pattern)
	char	*name;
	char	*pattern;
{
	int	patlen;
	int	namelen;

	if (*pattern == '\0')
		return TRUE;
	namelen = strlen(name);
	patlen = strlen(pattern);

	while (namelen >= patlen) {
		if (memcmp(name, pattern, patlen) == 0)
			return TRUE;
		name++;
		namelen--;
	}

	return FALSE;
}

/* END CODE */
