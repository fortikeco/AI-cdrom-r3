/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include "life.h"


/*
 * Allocate a new object structure.  It contains one row element, the termrow.
 */
OBJECT *
allocobject()
{
	register OBJECT	*obj;

	obj = freeobjects;
	if (obj)
		freeobjects = obj->o_next;
	else {
		obj = newobjects;
		if (obj >= endobjects) {	/* allocate new storage */
			obj = (OBJECT *) malloc(sizeof(OBJECT) * ALLOCOBJ);
			if (obj == NULL) {
				perror("malloc");
				exit(1);
			}
			newobjects = obj;
			endobjects = obj + ALLOCOBJ;
		}
		newobjects++;
	}

	obj->o_next = NULL;
	obj->o_firstrow = termrow;
	obj->o_lastrow = NULL;
	obj->o_reserved = reserve;
	obj->o_name[0] = '\0';
	obj->o_count = 0;
	obj->o_gen = 0;
	obj->o_currow = 0;
	obj->o_curcol = 0;
	obj->o_prow = 0;
	obj->o_pcol = 0;
	obj->o_mark = 0;
	obj->o_autoscale = FALSE;
	obj->o_frequency = defaultfrequency;
	setscale(obj, defaultscale);

	return obj;
}


/*
 * Allocate a new row structure.  It contains one row element, the termcell.
 */
ROW *
allocrow()
{
	register ROW	*rp;

	rp = freerows;
	if (rp)
		freerows = rp->r_next;
	else {
		rp = newrows;
		if (rp >= endrows) {	/* allocate new storage */
			rp = (ROW *) malloc(sizeof(ROW) * ALLOCROW);
			if (rp == NULL) {
				perror("malloc");
				exit(1);
			}
			newrows = rp;
			endrows = rp + ALLOCROW;
		}
		newrows++;
	}

	rp->r_next = NULL;
	rp->r_firstcell = termcell;
	rp->r_lastcell = NULL;
	rp->r_count = 0;

	return rp;
}


/*
 * Allocate a new cell structure.
 */
CELL *
alloccell()
{
	register CELL	*cp;

	cp = freecells;
	if (cp) {
		freecells = cp->c_next;
		cp->c_next = NULL;
		cp->c_marks = MARK_ANY;
		return cp;
	}

	cp = newcells;
	if (cp >= endcells) {	/* allocate new storage */
		cp = (CELL *) malloc(sizeof(CELL) * ALLOCCELL);
		if (cp == NULL) {
			perror("malloc");
			exit(1);
		}
		newcells = cp;
		endcells = cp + ALLOCCELL;
	}

	newcells++;
	cp->c_next = NULL;
	cp->c_marks = MARK_ANY;

	return cp;
}

/* END CODE */
