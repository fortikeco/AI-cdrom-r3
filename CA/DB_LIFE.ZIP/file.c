/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include "life.h"

#define	RLEMAX	75		/* maximum width of a line in rle format */


static	BOOL	readcoords();
static	void	writepicture();
static	void	writexlife();
static	void	writerle();
static	void	rleitem();


/*
 * Read in a run-length encoded description from an opened file.
 */
void
readrle(fp)
	FILE	*fp;
{
	COORD	mincol;
	VALUE	width;
	VALUE	height;
	VALUE	val;
	int	ch;
	char	*cp;
	char	buf[40];

	val = 0;
	do {
		ch = fgetc(fp);
		if ((ch == EOF) || (val >= sizeof(buf)))
			goto badhead;
		buf[val++] = ch;
	} while (ch != '\n');

	cp = buf;
	if ((*cp++ != 'x') || (*cp++ != ' ') || (*cp++ != '=') ||
		(*cp++ != ' ') || !isdigit(*cp))
			goto badhead;
	width = 0;
	while (isdigit(*cp))
		width = width * 10 + *cp++ - '0';

	if ((*cp++ != ',') || (*cp++ != ' ') || (*cp++ != 'y') ||
		(*cp++ != ' ') || (*cp++ != '=') || (*cp++ != ' ') ||
		!isdigit(*cp))
			goto badhead;

	height = 0;
	while (isdigit(*cp))
		height = height * 10 + *cp++ - '0';

	if ((*cp != '\n') || (width <= 0) || (height <= 0)) {
badhead:	error("Bad header line in rle file");
	}

	crow -= height / 2;
	ccol -= width / 2;
	mincol = ccol;

	while (TRUE) {
		val = 1;
		ch = fgetc(fp);
		if (isdigit(ch)) {
			val = 0;
			while (isdigit(ch)) {
				val = val * 10 + ch - '0';
				ch = fgetc(fp);
			}
		}

		switch (ch) {
			case 'b':
			case 'B':
				ccol += val;
				break;

			case 'o':
			case 'O':
				while (val-- > 0)
					addcell(curobj, crow, ccol++);
				update |= U_ALL;
				break;

			case '$':
				crow += val;
				ccol = mincol;
				break;

			case ' ':
			case '\t':
			case '\n':
				break;

			case '!':
				return;

			case EOF:
				error("Unexpected end of file in rle file");

			default:
				error("Illegal character in rle file");
		}
	}
}


/*
 * Read in an object in xlife format from an opened file.
 * Absolute coordinates are converted to relative ones.
 * However, we don't handle indirect files.
 */
void
readxlife(fp)
	FILE	*fp;
{
	VALUE	row;
	VALUE	col;
	BOOL	inheader;
	int	ch;

	inheader = TRUE;
	while (inheader) {
		ch = fgetc(fp);
		if (ch != '#')
			error("Directive expected in xlife file");

		ch = fgetc(fp);

		switch (ch) {
			case 'C':
			case 'N':
			case 'O':
				while ((ch != EOF) && (ch != '\n'))
					ch = fgetc(fp);
				break;

			case 'I':
				error("Indirect files not supported for xlife files");

			case 'A':
			case 'R':
				while ((ch != EOF) && (ch != '\n'))
					ch = fgetc(fp);

				while (readcoords(fp, &col, &row)) {
					addcell(curobj, crow + row, ccol + col);
					update |= U_ALL;
				}

				return;

			case 'P':
				if (!readcoords(fp, &col, &row))
					error("Unexpected EOF in xlife file");

				crow += row;
				ccol += col;

				readpicture(fp);

				return;

			default:
				error("Unknown directive in xlife file");
		}
	}
}


/*
 * Read in a picture of a life object from an opened file.
 */
void
readpicture(fp)
	FILE	*fp;
{
	COORD	mincol;
	int	ch;

	mincol = ccol;

	while (TRUE)
	{
		ch = fgetc(fp);

		switch (ch) {
			case '.':
			case ' ':
				ccol++;
				break;

			case '*':
			case 'O':
			case 'o':
				addcell(curobj, crow, ccol++);
				update |= U_ALL;
				break;

			case '\t':
				do {
					ccol++;
				} while ((ccol - mincol) % 8);
				break;

			case '\n':
				ccol = mincol;
				crow++;
				break;

			case EOF:
				return;

			default:
				error("Illegal pictorial character in file");
		}
	}
}


/*
 * Read a pair of coordinates and the following end of line from a file.
 * The pair of values are returned indirectly through pointers.  Extra
 * blanks are allowed.  Returns TRUE if coordinates were read, or FALSE
 * if EOF was found.
 */
static BOOL
readcoords(fp, num1, num2)
	FILE	*fp;
	VALUE	*num1;
	VALUE	*num2;
{
	VALUE	val;
	BOOL	isneg;
	int	ch;
	char	*cp;
	char	buf[80];

	*num1 = 0;
	*num2 = 0;

	val = 0;
	do {
		ch = fgetc(fp);

		if (ch == EOF) {
			if (val == 0)
				return FALSE;
			goto badline;
		}

		if (val >= sizeof(buf))
			goto badline;

		buf[val++] = ch;
	} while (ch != '\n');

	cp = buf;
	while (isblank(*cp))
		cp++;

	isneg = (*cp == '-');
	if (isneg)
		cp++;
	val = 0;
	if (!isdigit(*cp))
		goto badline;
	while (isdigit(*cp))
		val = val * 10 + *cp++ - '0';
	if (isneg)
		val = -val;
	*num1 = val;

	if (!isblank(*cp))
		goto badline;
	while (isblank(*cp))
		cp++;

	isneg = (*cp == '-');
	if (isneg)
		cp++;
	val = 0;
	if (!isdigit(*cp))
		goto badline;
	while (isdigit(*cp))
		val = val * 10 + *cp++ - '0';
	if (isneg)
		val = -val;
	*num2 = val;

	while (isblank(*cp))
		cp++;

	if (*cp != '\n') {
badline:	error("Invalid coordinate value in file");
	}

	return TRUE;
}


/*
 * Write an object out to a file in one of several different methods, which
 * is one of picture, xlife, or rle.  The maxrows and maxcols arguments are
 * used for limiting picture sizes.
 */
void
writeobject(obj, method, name, maxrows, maxcols)
	OBJECT	*obj;
	char	*method;
	char	*name;
	VALUE	maxrows;
	VALUE	maxcols;
{
	FILE	*fp;
	COORD	minrow;
	COORD	maxrow;
	COORD	mincol;
	COORD	maxcol;

	if (!abbrev(method, "picture") && !abbrev(method, "rle") &&
		!abbrev(method, "xlife"))
			error("Unknown file format specified");

	if (*name == '\0')
		error("No filename specified");

	minmax(obj, &minrow, &maxrow, &mincol, &maxcol);
	if (minrow > maxrow)
		error("Null object");

	fp = fopen(name, "w");
	if (fp == NULL)
		error("Cannot open output file");

	switch (*method) {
		case 'p':
			writepicture(fp, obj, minrow, maxrow, mincol, maxcol,
				maxrows, maxcols);
			break;

		case 'x':
			writexlife(fp, obj, minrow, maxrow, mincol, maxcol);
			break;

		case 'r':
			writerle(fp, obj, minrow, maxrow, mincol, maxcol);
			break;
	}

	fflush(fp);
	if (ferror(fp)) {
		fclose(fp);
		error("Write failed");
	}

	if (fclose(fp))
		error("Close failed");

	if (stop)
		error("Writing aborted");
}


/*
 * Write the current object out to the named file as a picture, with the
 * given maximum sizes for "pretty" output.  If the size is exceeded, the
 * output is compressed.  The file as written can be read in as commands
 * which will regenerate the object.
 */
static void
writepicture(fp, obj, minrow, maxrow, mincol, maxcol, maxrows, maxcols)
	FILE	*fp;
	OBJECT	*obj;
	COORD	minrow;
	COORD	maxrow;
	COORD	mincol;
	COORD	maxcol;
	VALUE	maxrows;
	VALUE	maxcols;
{
	register ROW	*rp;		/* current row structure */
	register CELL	*cp;		/* current cell */
	COORD	row;			/* current row value */
	COORD	col;			/* current column value */
	ROW	*trp;			/* temporary row structure */
	COORD	curmin;			/* current minimum column */
	COORD	curmax;			/* current maximum column */
	COORD	testmin;		/* test minimum column of rows */
	COORD	testmax;		/* test maximum column of rows */

	minmax(obj, &minrow, &maxrow, &mincol, &maxcol);
	if (minrow > maxrow) {
		fclose(fp);
		error("Null object");
	}

	fprintf(fp, "! \"%s\" (cells %ld length %ld width %ld generation %ld)\n",
		obj->o_name, obj->o_count, maxrow - minrow + 1,
		maxcol - mincol + 1, obj->o_gen);

	if (obj->o_currow > minrow)
		fprintf(fp, "%ldk", obj->o_currow - minrow);
	if (obj->o_currow < minrow)
		fprintf(fp, "%ldj", minrow - obj->o_currow);
	if (obj->o_curcol > mincol)
		fprintf(fp, "%ldh", obj->o_curcol - mincol);
	if (obj->o_curcol < mincol)
		fprintf(fp, "%ldl", mincol - obj->o_curcol);
	fprintf(fp, "@!\n");

	curmin = INFINITY;
	curmax = -INFINITY;
	rp = obj->o_firstrow;
	row = minrow;

	for (; rp != termrow; rp = rp->r_next) {
		if (stop)
			return;

		/*
		 * Skip down to the next row with something in it.
		 */
		if (rp->r_firstcell == termcell)
			continue;
		if (rp->r_row > (row + maxrows)) {	/* skip to right row */
			fprintf(fp, "%ld\n", rp->r_row - row);
			row = rp->r_row;
		}
		while (rp->r_row > row) {
			fputs(".\n", fp);
			row++;
		}

		/*
		 * Output the current row, compressing if it is too wide.
		 */
		col = mincol;
		cp = rp->r_firstcell;
		if ((cp->c_col + maxcols) < rp->r_lastcell->c_col) {
			while (cp != termcell) {
				/*
				 * Write all adjacent blanks.
				 */
				if (cp->c_col > col + 2) {
					fprintf(fp, "%ld.", cp->c_col - col);
					col = cp->c_col;
				}
				while (cp->c_col > col) {
					fputc('.', fp);
					col++;
				}

				/*
				 * Write all adjacent cells.
				 */
				while ((cp->c_col + 1) == cp->c_next->c_col) {
					cp = cp->c_next;
				}
				if (cp->c_col >= col + 2) {
					fprintf(fp, "%ldO", cp->c_col - col + 1);
					col = cp->c_col + 1;
				}
				while (col <= cp->c_col) {
					fputc('O', fp);
					col++;
				}
				cp = cp->c_next;
			}

			fputc('\n', fp);
			row++;
			curmin = INFINITY;
			curmax = -INFINITY;
			continue;
		}

		/*
		 * Here if the row doesn't need compressing.  See if several
		 * rows from this one on can all fit in the same range.  If
		 * so, set things up so they will align themselves nicely.
		 */
		if ((cp->c_col < curmin) || (rp->r_lastcell->c_col > curmax)) {
			curmin = cp->c_col;
			curmax = rp->r_lastcell->c_col;
			trp = rp;
			for (; rp != termrow; rp = rp->r_next) {
				if (rp->r_firstcell == termcell)
					continue;
				testmin = rp->r_firstcell->c_col;
				if (testmin > curmin)
					testmin = curmin;
				testmax = rp->r_lastcell->c_col;
				if (testmax < curmax)
					testmax = curmax;
				if ((testmax - testmin) >= maxcols)
					break;
				curmin = testmin;
				curmax = testmax;
			}
			rp = trp;
		}

		/*
 		 * Type the row, with the initial shift if necessary.
		 */
		if (curmin != mincol) {
			fprintf(fp, "%ld.", curmin - mincol);
			col = curmin;
		}
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			while (cp->c_col > col) {
				fputc('.', fp);
				col++;
			}
			fputc('O', fp);
			col++;
		}
		fputc('\n', fp);
		row++;
	}
}


/*
 * Write an object out to a file in xlife format.
 * This is just a list of coordinates.
 */
static void
writexlife(fp, obj, minrow, maxrow, mincol, maxcol)
	FILE	*fp;
	OBJECT	*obj;
	COORD	minrow;
	COORD	maxrow;
	COORD	mincol;
	COORD	maxcol;
{
	register ROW	*rp;
	register CELL	*cp;

	fprintf(fp, "#C \"%s\" (cells %ld width %ld height %ld generation %ld)\n",
		obj->o_name, obj->o_count, maxcol - mincol + 1,
		maxrow - minrow + 1, obj->o_gen);

	fputs("#R\n", fp);

	for (rp = obj->o_firstrow; rp != termrow; rp = rp->r_next) {
		if (stop)
			return;

		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next)
			fprintf(fp, "%ld %ld\n", cp->c_col - ccol,
				rp->r_row - crow);
	}
}


/*
 * Write an object out to a file in rle format.
 */
static void
writerle(fp, obj, minrow, maxrow, mincol, maxcol)
	FILE	*fp;
	OBJECT	*obj;
	COORD	minrow;
	COORD	maxrow;
	COORD	mincol;
	COORD	maxcol;
{
	register ROW	*rp;
	register CELL	*cp;
	COORD	row;
	COORD	col;
	VALUE	count;
	int	pos;

	fprintf(fp, "x = %ld, y = %ld\n", maxcol - mincol + 1,
		maxrow - minrow + 1);

	row = minrow;
	col = mincol;
	pos = 0;

	for (rp = obj->o_firstrow; rp != termrow; rp = rp->r_next) {
		if (stop)
			return;

		if (rp->r_firstcell == termcell)
			continue;

		if (row != rp->r_row)
			rleitem(fp, &pos, rp->r_row - row, '$');
		row = rp->r_row;

		col = mincol;

		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			if (cp->c_col != col) {
				rleitem(fp, &pos, cp->c_col - col, 'b');
				col = cp->c_col;
			}
			count = 1;
			while (cp->c_next->c_col == cp->c_col + 1) {
				cp = cp->c_next;
				count++;
			}
			rleitem(fp, &pos, count, 'o');
			col = cp->c_col + 1;
		}
	}

	rleitem(fp, &pos, (VALUE) 1, '!');
	fputc('\n', fp);
}


/*
 * Convert the specified count and action character to an rle string,
 * and write it to the specified file.  This adds the character count to
 * the specified line position, and if it would exceed RLEMAX, then inserts
 * a newline first.  The character position for the line is updated.
 */
static void
rleitem(fp, pos, count, action)
	FILE	*fp;
	int	*pos;
	VALUE	count;
{
	int	len;
	char	buf[16];

	if (count == 0)
		return;

	if (count == 1) {
		buf[0] = action;
		buf[1] = '\0';
		len = 1;
	} else if (count == 2) {
		buf[0] = action;
		buf[1] = action;
		buf[2] = '\0';
		len = 2;
	} else if ((count < 0) || (count > 99)) {
		sprintf(buf, "%ld%c", count, action);
		len = strlen(buf);
	} else if (count < 10) {
		buf[0] = count + '0';
		buf[1] = action;
		buf[2] = '\0';
		len = 2;
	} else {
		buf[0] = (count / 10) + '0';
		buf[1] = (count % 10) + '0';
		buf[2] = action;
		buf[3] = '\0';
		len = 3;
	}

	if (*pos + len > RLEMAX) {
		fputc('\n', fp);
		*pos = 0;
	}

	fputs(buf, fp);
	*pos += len;
}

/* END CODE */
