/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include "life.h"


/*
 * Set the scaling factor for the specified object.  This also centers
 * the view around the current cursor location.  Positive scale factors
 * mean compress the view so that each displayed item represents multiple
 * cells.  Negative scale factors mean use multiple displayed items to
 * represent individual cells.
 */
void
setscale(obj, sf)
	register OBJECT	*obj;
	SCALE		sf;
{
	COUNT	newrows;
	COUNT	newcols;

	if (sf < dev->minscale)
		sf = dev->minscale;
	if (sf > dev->maxscale)
		sf = dev->maxscale;
	if ((sf == 0) || (sf == -1))
		sf = 1;

	if (sf > 0) {
		newrows = dev->rows * sf;
		newcols = dev->cols * sf;
	} else {
		newrows = dev->rows / (-sf);
		newcols = dev->cols / (-sf);
		if (newrows <= 0)
			newrows = 1;
		if (newcols <= 0)
			newcols = 1;
	}

	obj->o_scale = sf;
	obj->o_minrow = obj->o_currow - (newrows / 2);
	obj->o_maxrow = obj->o_minrow + newrows - 1;
	obj->o_mincol = obj->o_curcol - (newcols / 2);
	obj->o_maxcol = obj->o_mincol + newcols - 1;

	if (obj == curobj) {
		viewrows = newrows;
		viewcols = newcols;
		update |= U_ALL;
	}
}


/*
 * Perform auto-scaling of the current object.  This implies picking a
 * scaling factor such that the whole object fits in the screen.  The
 * scale factor is never decreased.  When the scale factor is large,
 * convenient ones are picked.  Returns the new scale factor.
 */
SCALE
autoscale()
{
	register OBJECT	*obj;
	SCALE		sf;
	COORD		minrow;
	COORD		maxrow;
	COORD		mincol;
	COORD		maxcol;

	obj = curobj;
	minmax(obj, &minrow, &maxrow, &mincol, &maxcol);
	sf = obj->o_scale;

	if (mincol > maxcol)
		return sf;

	while ((sf <= dev->maxscale) &&
		((minrow < obj->o_minrow) || (maxrow > obj->o_maxrow) ||
		(mincol < obj->o_mincol) || (maxcol > obj->o_maxcol)))
	{
		sf++;
		if ((sf == -1) || (sf == 0))
			sf = 1;
		if (sf > 20)
			sf += (5 - (sf % 5));
		if (sf > 50)
			sf += (10 - (sf % 10));
		if (sf > 200)
			sf += (100 - (sf % 100));
		setscale(obj, sf);
	}

	return obj->o_scale;
}


/*
 * Position the view of the current object to show both the given region and
 * the current cursor location.  If this is impossible, just the cursor
 * location will be positioned.
 */
void
positionview(minrow, maxrow, mincol, maxcol)
	COORD	minrow;
	COORD	maxrow;
	COORD	mincol;
	COORD	maxcol;
{
	register OBJECT	*obj;

	obj = curobj;

	if (minrow > obj->o_currow)
		minrow = obj->o_currow;
	if (maxrow < obj->o_currow)
		maxrow = obj->o_currow;
	if (mincol > obj->o_curcol)
		mincol = obj->o_curcol;
	if (maxcol < obj->o_curcol)
		maxcol = obj->o_curcol;

	if ((maxrow - minrow) >= viewrows) {	/* too many rows */
		minrow = obj->o_currow;
		maxrow = obj->o_currow;
	}
	if ((maxcol - mincol) >= viewcols) {	/* too many columns */
		mincol = obj->o_curcol;
		maxcol = obj->o_curcol;
	}

	if (minrow < obj->o_minrow) {
		obj->o_minrow = minrow;
		obj->o_maxrow = minrow + viewrows - 1;
		update |= U_ALL;
	}
	if (maxrow > obj->o_maxrow) {
		obj->o_maxrow = maxrow;
		obj->o_minrow = maxrow - viewrows + 1;
		update |= U_ALL;
	}
	if (mincol < obj->o_mincol) {
		obj->o_mincol = mincol;
		obj->o_maxcol = mincol + viewcols - 1;
		update |= U_ALL;
	}
	if (maxcol > obj->o_maxcol) {
		obj->o_maxcol = maxcol;
		obj->o_mincol = maxcol - viewcols + 1;
		update |= U_ALL;
	}
}


/*
 * Show the view around the current window location if the view has changed.
 * The update flag indicates what parts of the display needs updating.
 * This is any of U_POS, U_STAT, and U_VIEW.
 */
void
updateview()
{
	register OBJECT	*obj;

	if ((interact | update) == 0)
		return;

	obj = curobj;
	positionview(obj->o_currow,obj->o_currow,obj->o_curcol,obj->o_curcol);
	if (obj->o_autoscale)
		autoscale();

	if (update & U_VIEW) {
		freqcount = obj->o_frequency;
		(*dev->showview)(dev);
	}

	if (update & (U_STAT | U_VIEW))
		viewstatus();

	if (update & (U_STAT | U_VIEW | U_POS)) {
		(*dev->movecursor)(dev, obj->o_scale,
			obj->o_currow - obj->o_minrow,
			obj->o_curcol - obj->o_mincol);
		(*dev->update)(dev, 0);
	}

	update = FALSE;			/* no more updates until prodded */
	interact = FALSE;
}


/*
 * Update the status line for the object.
 */
void
viewstatus()
{
	register OBJECT	*obj;
	char		*cp;
	char		buf[132];

	if (errorstring) {
		(*dev->showstatus)(dev, errorstring);
		return;
	}

	obj = curobj;
	cp = buf;
	sprintf(cp, "Gen:%ld cells:%ld", obj->o_gen, obj->o_count);
	cp += strlen(cp);

	if (obj->o_count > seecount) {
		sprintf(cp, "(%ldu)", obj->o_count - seecount);
		cp += strlen(cp);
	}
	if (obj->o_born) {
		sprintf(cp, " born:%ld", obj->o_born);
		cp += strlen(cp);
	}
	if (obj->o_died) {
		sprintf(cp, " died:%ld", obj->o_died);
		cp += strlen(cp);
	}
	if (obj->o_frequency > 1) {
		sprintf(cp, " freq:%ld", obj->o_frequency);
		cp += strlen(cp);
	}
	if ((obj->o_scale != 1) || (obj->o_autoscale)) {
		sprintf(cp, " %scale:%d",
			(obj->o_autoscale ? "autos" : "s") , obj->o_scale);
		cp += strlen(cp);
	}
	if (strcmp(rulestring, "3,23")) {
		sprintf(cp, " rules:%s", rulestring);
		cp += strlen(cp);
	}
	if (curinput > inputs) {
		sprintf(cp, " cmd-nest:%d", curinput - inputs);
		cp += strlen(cp);
	}

	switch (curinput->i_type) {
		case INP_TTY:			/* reading from terminal */
			if (curinput != inputs)
				strcpy(cp, " tty-wait");
			break;

		case INP_FILE:			/* reading from file */
			strcpy(cp, " cmd-file");
			break;

		case INP_LOOP:			/* reading from loop */
			if (curinput->i_macro) {
				sprintf(cp, " macro-define-%c",
					curinput->i_macro);
				break;
			}
			sprintf(cp, " loop%s (curval:%ld end:%ld)",
				curinput->i_first ? "-define" : "",
				curinput->i_curval, curinput->i_endval);
			break;

		case INP_MACRO:			/* reading from macro */
			sprintf(cp, " macro-%c", curinput->i_macro);
			break;
	}
	cp += strlen(cp);

	if (mode == M_INSERT)
		strcpy(cp, " inserting");
	if (mode == M_DELETE)
		strcpy(cp, " deleting");
	cp += strlen(cp);

	if (curobj != mainobject) {
		sprintf(cp, " \"%s\"", curobj->o_name);
		cp += strlen(cp);
	}

	(*dev->showstatus)(dev, buf);
}

/* END CODE */
