/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include "life.h"

#ifdef	TERMIOS
#include <termios.h>
#endif

#ifdef	SGTTY
#include <sgtty.h>
#endif

static	int	(*scanroutine)();	/* routine to read characters */
static	jmp_buf	*scanjumpbuf;		/* jump buffer to use in scanchar */
static	UCHAR	*scanreadptr;		/* current read pointer */
static	UCHAR	*scanwriteptr;		/* current write pointer */
static	UCHAR	scanbuffer[SCAN_SIZE+1];/* storage for characters */


/*
 * Initialize for later calls to scanchar.
 */
void
scaninit(routine, jumpbuf)
	int	(*routine)();		/* routine to get characters */
	jmp_buf	*jumpbuf;		/* jump buffer to use later */
{
#ifdef	TERMIOS
	struct	termio	term;
#endif

#ifdef	SGTTY
	struct	sgttyb	sgbuf;
	struct	ltchars	ltbuf;
#endif

	scanroutine = routine;		/* init static variables */
	scanjumpbuf = jumpbuf;
	scanwriteptr = scanbuffer;
	scanreadptr = scanbuffer;

	/*
	 * Ask the system for the settings of the editing characters.
	 */
#ifdef	TERMIOS
	if (ioctl(STDIN, TCGETA, &term) == 0) {
		vkill = term.c_cc[VKILL];
		verase = term.c_cc[VERASE];
		veof = term.c_cc[VEOF];
#ifdef	VWERASE
		vwerase = term.c_cc[VWERASE];
#endif
#ifdef	VLNEXT
		vlnext = term.c_cc[VLNEXT];
#endif
	}
#endif

#ifdef	SGTTY
	if (ioctl(STDIN, TIOCGETP, &sgbuf) == 0) {
		verase = sgbuf.sg_erase;
		vkill = sgbuf.sg_kill;
	}

	if (ioctl(STDIN, TIOCGLTC, &ltbuf) == 0) {
		vwerase = ltbuf.t_werasc;
		vlnext = ltbuf.t_lnextc;
	}
#endif
	/*
	 * Now set some defaults if they weren't defined by the system.
	 */
	if (!verase)
		verase = '\b';
	if (!vkill)
		vkill = 'U'-'@';
	if (!vwerase)
		vwerase = 'W'-'@';
	if (!vlnext)
		vlnext = 'V'-'@';
	if (!veof)
		veof = 'D'-'@';
}


/*
 * Read the next input character.  If it is an editing character,
 * abort the current context and longjmp back to the last setjmp.
 * NOTE: for proper results, the caller should not alter the global
 * state until the full command has been read in.  This includes such
 * things as prompting for input or saving values.  Otherwise, improper
 * results will occur if the user edits the command.
 */
scanchar()
{
	register int	ch;		/* current character */

loop:	
	if (scanreadptr < scanwriteptr)	/* get saved char if have any */
		return *scanreadptr++;

	ch = (*scanroutine)();		/* get new character */

	if (ch == EOF)			/* no character means eof */
		scaneof();

	if (ch == vlnext) {		/* literal input */
		ch = (*scanroutine)();
		goto store;
	}

	if (ch == verase) {		/* character erase */
		if (scanwriteptr <= scanbuffer) {
			beep();
			goto loop;
		}
		scanwriteptr--;
		scanreadptr = scanbuffer;
		longjmp(scanjumpbuf[0], SCAN_EDIT);
	}

	if (ch == vwerase) {		/* word erase */
		if (scanwriteptr <= scanbuffer)
			goto loop;
		while ((--scanwriteptr >= scanbuffer) &&
			isblank(*scanwriteptr))
		    		;
		scanwriteptr++;
		while ((--scanwriteptr >= scanbuffer) &&
			!isblank(*scanwriteptr))
			    	;
		scanwriteptr++;
		scanreadptr = scanbuffer;
		longjmp(scanjumpbuf[0], SCAN_EDIT);
	}

	if (ch == vkill) {		/* line erase */
		if (scanwriteptr <= scanbuffer)
			goto loop;
		scanwriteptr = scanbuffer;
		scanreadptr = scanbuffer;
		longjmp(scanjumpbuf[0], SCAN_EDIT);
	}

store:	
	if (scanwriteptr >= scanbuffer + SCAN_SIZE) {
		beep();
		goto loop;
	}
	*scanwriteptr++ = ch;
	return *scanreadptr++;
}


/* Abort reading of the current command */
void
scanabort()
{
	scanreadptr = scanbuffer;
	scanwriteptr = scanbuffer;
	longjmp(scanjumpbuf[0], SCAN_ABORT);
}


/* Indicate no more characters ready yet */
void
scaneof()
{
	scanreadptr = scanbuffer;
	longjmp(scanjumpbuf[0], SCAN_EOF);
}


/* Simply reset input and output pointers without longjmping */
void
scanreset()
{
	scanreadptr = scanbuffer;
	scanwriteptr = scanbuffer;
}

void
beep()
{
	fputc('\007', stderr);
	fflush(stderr);
}

/* END CODE */
