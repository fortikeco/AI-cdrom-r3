/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include "life.h"


/*
 * Variable enum.
 */
enum	vars	{
	v_minx, v_miny, v_maxx, v_maxy, v_cells, v_cx, v_cy, v_px, v_py,
	v_vminx, v_vmaxx, v_vminy, v_vmaxy, v_vcells, v_vx, v_vy,
	v_sminx, v_smaxx, v_sminy, v_smaxy, v_scells, v_gen, v_scale,
	v_freq, v_born, v_died, v_defscale, v_deffreq, v_endlist
};


/*
 * Table of multi-character variables.
 * This is arranged in listing order (three items per line).
 */
static struct vartab	{
	char	*v_name;	/* name of variable */
	enum	vars v_type;	/* variable id */
} vartab[] = {
	"cx",		v_cx,
	"vx",		v_vx,
	"px",		v_px,

	"cy",		v_cy,
	"vy",		v_vy,
	"py",		v_py,

	"minx",		v_minx,
	"vminx",	v_vminx,
	"sminx",	v_sminx,

	"maxx",		v_maxx,
	"vmaxx",	v_vmaxx,
	"smaxx",	v_smaxx,

	"maxy",		v_maxy,
	"vmaxy",	v_vmaxy,
	"smaxy",	v_smaxy,

	"miny",		v_miny,
	"vminy",	v_vminy,
	"sminy",	v_sminy,

	"cells",	v_cells,
	"vcells",	v_vcells,
	"scells",	v_scells,

	"gen",		v_gen,
	"born",		v_born,
	"died",		v_died,

	"scale",	v_scale,
	"freq",		v_freq,
	"dscale",	v_defscale,

	"dfreq",	v_deffreq,
	NULL,		v_endlist
};


static	char	*curcp;		/* current character to parse */
static	VALUE	lowervars[26];	/* lower case single-char variable values */
static	VALUE	uppervars[26];	/* upper case single-char variable values */


static	VALUE	getvariablebytype();
static	VALUE	parsesum();
static	VALUE	parseproduct();
static	VALUE	parseterm();
static	VALUE	parsename();


/*
 * Return the value of a multiple character variable name.  This can be
 * either a single character name, or else one of a fixed set of multi-
 * character names.  All variable names must start with either a letter
 * or a dollar sign followed by a letter.
 */
VALUE
getvariable(cp)
	register char	*cp;
{
	register struct	vartab	*vp;

	if (*cp == '$')
		cp++;

	if (cp[1] == '\0')
		return getvariable1(*cp);

	if (!islower(*cp) && !isupper(*cp))
		error("Bad variable name");

	for (vp = vartab; ; vp++) {
		if (vp->v_name == NULL)
			error("Unknown variable");
		if (strcmp(vp->v_name, cp) == 0)
			break;
	}

	return getvariablebytype(vp->v_type);
}


/*
 * Return the value of a variable given its enum value.
 */
static VALUE
getvariablebytype(type)
	enum	vars	type;
{
	register OBJECT	*obj;
	VALUE		value;
	COORD		*ptr;
	COORD		*sptr;
	int		sign;
	COORD		minrow;
	COORD		maxrow;
	COORD		mincol;
	COORD		maxcol;

	obj = curobj;
	value = 0;
	sign = 1;
	ptr = NULL;
	sptr = NULL;

	switch (type) {
		case v_cx:
			value = obj->o_curcol;
			break;

		case v_cy:
			value = -obj->o_currow;
			break;

		case v_px:
			value = obj->o_pcol;
			break;

		case v_py:
			value = -obj->o_prow;
			break;

		case v_vx:
			value = (obj->o_mincol + obj->o_maxcol) / 2;
			break;

		case v_vy:
			value = -(obj->o_minrow + obj->o_maxrow) / 2;
			break;

		case v_vminx:
			value = obj->o_mincol;
			break;

		case v_vmaxx:
			value = obj->o_maxcol;
			break;

		case v_vminy:
			value = -obj->o_maxrow;
			break;

		case v_vmaxy:
			value = -obj->o_minrow;
			break;

		case v_vcells:
			value = markregion(obj, MARK_ANY, obj->o_minrow,
			    obj->o_maxrow, obj->o_mincol, obj->o_maxcol);
			break;

		case v_cells:
			value = obj->o_count;
			break;

		case v_gen:
			value = obj->o_gen;
			break;

		case v_born:
			value = obj->o_born;
			break;

		case v_died:
			value = obj->o_died;
			break;

		case v_freq:
			value = obj->o_frequency;
			break;

		case v_scale:
			value = obj->o_scale;
			break;

		case v_deffreq:
			value = defaultfrequency;
			break;

		case v_defscale:
			value = defaultscale;
			break;

		case v_minx:
			ptr = &mincol;
			break;

		case v_maxx:
			ptr = &maxcol;
			break;

		case v_miny:
			ptr = &maxrow;
			sign = -1;
			break;

		case v_maxy:
			ptr = &minrow;
			sign = -1;
			break;

		case v_scells:
			value = countmarks(obj, MARK_SEE);
			break;

		case v_sminx:
			sptr = &mincol;
			break;

		case v_smaxx:
			sptr = &maxcol;
			break;

		case v_sminy:
			sptr = &maxrow;
			sign = -1;
			break;

		case v_smaxy:
			sptr = &minrow;
			sign = -1;
			break;
	}

	/*
	 * Call proper minmax routines if we need to
	 */
	if (ptr && (minmax(obj, &minrow, &maxrow, &mincol, &maxcol) == 0))
		value = *ptr;

	if (sptr&&(markminmax(obj,MARK_SEE,&minrow,&maxrow,&mincol,&maxcol)==0))
		value = *sptr;

	return (sign * value);
}


/*
 * Return the value of a single character variable name (a-z or A-Z).
 */
VALUE
getvariable1(ch)
	register int	ch;
{
	if (islower(ch))
		return lowervars[ch - 'a'];

	if (isupper(ch))
		return lowervars[ch - 'A'];

	error("Bad variable name");
}


/*
 * Set the value of a variable name.  Multi-character names cannot be set.
 */
void
setvariable(cp, value)
	register char	*cp;
	VALUE		value;
{
	if (*cp == '$')
		cp++;

	if (cp[1] != '\0')
		error("Cannot set multi-character variables");

	setvariable1(*cp, value);
}


/*
 * Set the value of a single-character variable (a-z or A-Z).
 */
void
setvariable1(ch, value)
	int	ch;
	VALUE	value;
{
	if (islower(ch)) {
		lowervars[ch - 'a'] = value;
		return;
	}

	if (isupper(ch)) {
		lowervars[ch - 'A'] = value;
		return;
	}

	error("Bad variable name");
}


/*
 * Display the current values of the variables.  Show all multi-character
 * variable values, and those single character variables which have a
 * nonzero value.  The output is given three variables per line.
 */
void
listvariables()
{
	struct	vartab	*vp;
	VALUE		*var;
	int		count;
	char		buf[80];

	showhelp("Variable names and values:");

	count = 0;
	for (vp = vartab; vp->v_name; vp++) {
		sprintf(buf, "%s%s\t%ld", (count++ % 3) ? "\t\t" : "\n",
			vp->v_name, getvariablebytype(vp->v_type));

		showhelp(buf);
	}

	count = 0;
	for (var = uppervars; var < &uppervars[26]; var++) {
		if (*var == 0)
			continue;

		if (count == 0)
			showhelp("\n");

		sprintf(buf, "%s%c\t%ld", (count++ % 3) ? "\t\t" : "\n",
			'A' + (var - uppervars), *var);

		showhelp(buf);
	}

	for (var = lowervars; var < &lowervars[26]; var++) {
		if (*var == 0)
			continue;

		if (count == 0)
			showhelp("\n");

		sprintf(buf, "%s%c\t%ld", (count++ % 3) ? "\t\t" : "\n",
			'a' + (var - lowervars), *var);

		showhelp(buf);
	}

	showhelp("\n\nMany names starting with 'v' refer to visible cells\n");
	showhelp("Many names starting with 's' refer to selected cells\n");

	endhelp();
}


/*
 * Evaluate an expression and return its value.  The expression can contain
 * numbers, variables, the normal arithmetic operators, and parenthesized
 * expressions.  The usual precedence rules are used.  The string must be
 * writable.
 */
VALUE
getexpression(str)
	register char	*str;
{
	VALUE	value;

	while isblank(*str)
		str++;

	if (*str == '\0')
		error("Null expression");

	curcp = str;
	value = parsesum();
	if (*curcp != '\0')
		error("Bad expression");

	return value;
}


/*
 * Parse the sum of products
 */
static VALUE
parsesum()
{
	VALUE	value;

	while (isblank(*curcp))
		curcp++;

	switch (*curcp) {
		case '-':
			curcp++;
			value = -parseproduct();
			break;

		case '+':
			curcp++;
			/* proceed into default case */

		default:
			value = parseproduct();
	}

	while (TRUE) switch (*curcp++) {
		case '+':		/* sum of products */
			value += parseproduct();
			continue;

		case '-':		/* difference of products */
			value -= parseproduct();
			continue;

		case ' ':		/* space */
		case '\t':
			continue;

		default:		/* end of sum */
			curcp--;
			return value;
	}
}


/* 
 * Parse the product of terms
 */
static VALUE
parseproduct()
{
	VALUE	value;
	VALUE	value2;

	value = parseterm();

	while (TRUE) switch (*curcp++) {
		case '*':			/* product of terms */
			value *= parseterm();
			continue;

		case '/':			/* division of terms */
			value2 = parseterm();
			if (value2 == 0)
				error("division by zero");
			value /= value2;
			continue;

		case '%':			/* modulo of terms */
			value2 = parseterm();
			if (value2 == 0)
				error("division by zero");
			value %= value2;
			continue;

		case ' ':			/* space */
		case '\t':
			continue;

		default:			/* end of product */
			curcp--;
			return value;
	}
}


/*
 * Parse a single term
 */
static VALUE
parseterm()
{
	VALUE	value;
	int	ch;

	while (isblank(*curcp))
		curcp++;

	ch = *curcp;
	if (isdigit(ch)) {		/* number */
		value = 0;
		do {
			value = (value * 10) + *curcp++ - '0';
		} while (isdigit(*curcp));

		return value;
	}

	if (ch == '(') {		/* parenthesized expression */
		curcp++;
		while (isblank(*curcp))
			curcp++;

		if (*curcp == ')')
			error("Null expression");

		value = parsesum();

		while (isblank(*curcp))
			curcp++;

		if (*curcp != ')')
			error("Unmatched parenthesis");
		curcp++;

		return value;
	}

	if (ch == ')')
		error("Unmatched parenthesis");

	return parsename();
}


/*
 * Parse a variable name and return its value.
 */
static VALUE
parsename()
{
	register char	*cp;
	VALUE		value;
	int		oldch;

	cp = curcp;
	if (*cp == '$')
		cp++;

	while (islower(*cp) || isupper(*cp) || isdigit(*cp))
    		cp++;

	oldch = *cp;
	*cp = '\0';			/* this requires writable strings */
	value = getvariable(curcp);
	*cp = oldch;
	curcp = cp;

	return value;
}

/* END CODE */
