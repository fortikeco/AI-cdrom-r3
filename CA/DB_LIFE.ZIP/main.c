/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 *
 * Program to play Conway's Game of LIFE on an infinite board.
 */

#define	DEFINE_GLOBALS

#include "life.h"


static	void	defaults();
static	void	options();
static	void	intint();

static	BOOL	scaleset;
static	BOOL	inited;


main(argc, argv)
	char	**argv;
{
	strcpy(rulestring, "3,23");
	termcell = alloccell();
	termcell->c_next = termcell;
	termcell->c_col = INFINITY;
	termrow = allocrow();
	termrow->r_next = termrow;
	termrow->r_firstcell = termcell;
	termrow->r_row = INFINITY;
	mode = M_MOVE;
	gridchar = ' ';
	defaultscale = 1;
	defaultfrequency = 1;
	freqcount = 1;
	viewrows = 1;
	viewcols = 1;

	reserve = TRUE;			/* creating special objects */
	deleteobject = getobject("..delete");
	tempobject = getobject("..temp");
	backupobject = getobject("..backup");
	mainobject = getobject("main");
	curobj = mainobject;
	prevobj = mainobject;
	reserve = FALSE;		/* no more special objects */

	curinput = &inputs[-1];		/* initialize for tty input */
	settty();
	dev = &ttydev;

	defaults();
	options(argc - 1, argv + 1);

	if ((*dev->open)(dev) < 0)
		exit(1);

	viewrows = dev->rows;
	viewcols = dev->cols;
	if (!scaleset)
		defaultscale = dev->defaultscale;

	setscale(deleteobject, defaultscale);	/* fix scale factors now */
	setscale(tempobject, defaultscale);
	setscale(backupobject, defaultscale);
	setscale(mainobject, defaultscale);

	signal(SIGINT, intint);
	scaninit(readchar, ttyjmp);

	inited = TRUE;

	while (TRUE) {
		docommand();
		dogeneration(curobj);
		updateview();
	}
}


/*
 * Parse the optional LIFEOPTS environment variable to define defaults.
 */
static void
defaults()
{
	char	*env;
	char	*cp;
	int	argc;
	char	**argv;
	char	*argtable[MAXARGS];

	env = getenv(LIFEOPTS);
	if (env == NULL)
		return;

	cp = malloc(strlen(env) + 1);
	if (cp == NULL) {
		fprintf(stderr, "No memory\n");
		exit(1);
	}
	strcpy(cp, env);

	argc = 0;
	argv = argtable;

	while (*cp) {
		while (isblank(*cp))
			cp++;
		if (*cp == '\0')
			break;
		if (++argc > MAXARGS) { 
			fprintf(stderr, "Too many arguments in LIFEOPTS\n");
			exit(1);
		} 
		*argv++ = cp;
		while (*cp && !isblank(*cp))
			cp++;
		if (*cp)
			*cp++ = '\0';
	}

	options(argc, argtable);
}


/*
 * Handle command line options.  Note: The first argument argv[0] is NOT
 * the usual program name, so that must have been removed if necessary.
 */
static void
options(argc, argv)
	char	**argv;
{
	char	*str;
	char	*cp;
	VALUE	arg;
	BOOL	neg;

	while (argc-- > 0) {
		str = *argv++;

		/*
		 * If no option letter is used, then this means
		 * read from the specified file.
		 */
		if (*str != '-') {
			if (setfile(str)) {
				perror(str);
				exit(1);
			}
			continue;
		}

		/*
		 * This is an option argument.  Parse each character of
		 * it, so that multiple options can be given at once.
		 */
		str++;
		while (*str) switch (*str++) {
			case 't':			/* use terminal */
				dev = &ttydev;
				break;

			case 'g':			/* use graphics */
#if defined(X11)
				dev = &x11dev;
#else
				fprintf(stderr, "Graphics is not available\n");
				exit(1);
#endif
				break;

			case 'l':			/* set library path */
				if ((argc <= 0) || (**argv == '-')) {
					fprintf(stderr, "Missing library path\n");
					exit(1);
				}
				userlib = *argv++;
				argc--;
				break;

			case 's':			/* set default scale */
				if (argc <= 0) {
					fprintf(stderr, "Missing scale\n");
					exit(1);
				}
				cp = *argv++;
				argc--;
				neg = FALSE;
				if (*cp == '-') {
					neg = TRUE;
					cp++;
				}
				arg = 0;
				while (isdigit(*cp))
					arg = arg * 10 + *cp++ - '0';
				if (*cp || (arg == 0)) {
					fprintf(stderr, "Bad scale factor\n");
					exit(1);
				}
				if (neg)
					arg = -arg;
				defaultscale = arg;
				scaleset = TRUE;
				break;

			default:
				fprintf(stderr, "Unknown option -%c\n", str[-1]);
				exit(1);
		}
	}
}


/*
 * Here on an interrupt character.  Remember to stop what we are doing soon.
 * We cannot usually just longjmp away since things may be in an inconsistent
 * state.  The longjmp is only allowed if we are sitting in a terminal read.
 */
static void
intint()
{
	signal(SIGINT, intint);
	genleft = 0;
	stop = TRUE;
	update |= U_ALL;

	if (intjmpok) {			/* do longjmp only if set up */
		intjmpok = FALSE;
		longjmp(intjmp, 1);
	}
}


/*
 * Here on an error.  Close all but the top input level, cancel the
 * current command, beep, and set up to display the indicated message.
 * The message will remain until the next command is typed by the user.
 */
void
error(str)
	char	*str;		/* message to type */
{
	if (!inited) {
		fprintf(stderr, "%s\n", str);
		exit(1);
	}
	while (curinput > inputs)
		(*curinput->i_term)(curinput);
	errorstring = str;
	update |= U_ALL;
	stop = FALSE;
	dowait = FALSE;
	write(STDERR, "\007", 1);
	scanabort();
}

/* END CODE */
