/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#include "life.h"


/*
 * Structure to hold row and column pairs
 */
typedef struct	{
	COORD	l_row;
	COORD	l_col;
} LOC;


/*
 * Row deltas to walk a cell
 */
static	COUNT	rowwalk[24] = {
	-1, 0, 1, 1, 0, 0, -1, -1,
	-1, 0, 0, 0, 1, 1, 1, 1,
	0, 0, 0, 0, -1, -1, -1, -1
};


/*
 * Col deltas to walk a cell
 */
static	COUNT	colwalk[24] = {
	0, 1, 0, 0, -1, -1, 0, 0,
	0, 1, 1, 1, 0, 0, 0, 0,
	-1, -1, -1, -1, 0, 0, 0, 0
};

static	void	markloop();


/*
 * Mark the object at a given location as specified.  Returns nonzero if
 * no object exists there.  An object for this purpose is considered as a
 * king-wise connected set of live cells, or a set of cells separated by
 * gaps of only one squares.
 */
BOOL
markobject(obj, row, col, gap, mark)
	OBJECT	*obj;
	COORD	row;
	COORD	col;
	VALUE	gap;
	MARK	mark;
{
	CELL	*cp;

	cp = findcell(obj, row, col);
	if (cp == NULL)
		return TRUE;
	cp->c_marks |= mark;
	markloop(obj, row, col, gap, mark);
	return FALSE;
}


/*
 * Recursive subroutine called from markobject.
 */
static void
markloop(obj, row, col, gap, mark)
	OBJECT	*obj;		/* object begin marked */
	COORD	row;		/* current row */
	COORD	col;		/* current column */
	VALUE	gap;		/* gap for marking (0 or 1) */
	MARK	mark;		/* marking value */
{
	register CELL	*cp;	/* current cell */
	register LOC	*rp;	/* pointer into list table */
	int	i;		/* to iterate over directions */
	int	steps;		/* number of steps */
	LOC	rclist[24];	/* row and column list */

	if (gap)
		steps = 24;
	else
		steps = 8;

	while (TRUE) {
		if (stop)
			return;

		rp = rclist;

		for (i = 0; i < steps; i++) {	/* find neighbors */
			row += rowwalk[i];
			col += colwalk[i];
			cp = findcell(obj, row, col);
			if (cp == NULL)
				continue;
			if (cp->c_marks & mark)
				continue;
			cp->c_marks |= mark;
			rp->l_row = row;
			rp->l_col = col;
			rp++;
		}

		if (--rp != rclist) {		/* recurse if more than one */
			for (; rp >= rclist; rp--) {
				markloop(obj, rp->l_row, rp->l_col, gap, mark);
			}
			return;
		}

		row = rp->l_row;		/* else follow single cell */
		col = rp->l_col;
	}
}


/*
 * Mark a whole object as specified.
 */
void
setmarks(obj, mark)
	OBJECT	*obj;
	MARK	mark;
{
	register ROW	*rp;
	register CELL	*cp;

	mark |= MARK_ANY;
	for (rp = obj->o_firstrow; rp != termrow; rp = rp->r_next) {
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			cp->c_marks |= mark;
		}
	}
}


/*
 * Copy the marks from one type to another for an object.
 * Returns nonzero if there were no cells with the given mark.
 */
BOOL
copymarks(obj, srcmark, destmark)
	OBJECT	*obj;
	MARK	srcmark;
	MARK	destmark;
{
	register ROW	*rp;
	register CELL	*cp;
	BOOL		failed;

	failed = TRUE;
	for (rp = obj->o_firstrow; rp != termrow; rp = rp->r_next) {
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			if ((cp->c_marks & srcmark) == 0)
				continue;
			cp->c_marks |= destmark;
			failed = FALSE;
		}
	}
	return failed;
}


/*
 * Clear marks for a whole object as specified.
 */
void
clearmarks(obj, mark)
	OBJECT	*obj;
	MARK	mark;
{
	register ROW	*rp;
	register CELL	*cp;

	mark = ~mark;
	mark |= MARK_ANY;
	for (rp = obj->o_firstrow; rp != termrow; rp = rp->r_next) {
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			cp->c_marks &= mark;
		}
	}
}


/*
 * Mark the cells in a specified rectangular region as desired.
 * Returns the number of cells which were marked.
 */
COUNT
markregion(obj, mark, minrow, maxrow, mincol, maxcol)
	OBJECT	*obj;
	MARK	mark;
	COORD	minrow;
	COORD	maxrow;
	COORD	mincol;
	COORD	maxcol;
{
	register ROW	*rp;
	register CELL	*cp;
	COUNT		count;

	count = 0;
	for (rp = obj->o_firstrow; rp != termrow; rp = rp->r_next) {
		if (rp->r_row < minrow)
			continue;
		if (rp->r_row > maxrow)
			break;
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			if (cp->c_col < mincol)
				continue;
			if (cp->c_col > maxcol)
				break;
			cp->c_marks |= mark;
			count++;
		}
	}
	return count;
}


/*
 * Find the range of all marked cells for an object.  Returns nonzero if
 * no cells were marked.
 */
BOOL
markminmax(obj, mark, minrow, maxrow, mincol, maxcol)
	OBJECT	*obj;
	MARK	mark;
	COORD	*minrow;
	COORD	*maxrow;
	COORD	*mincol;
	COORD	*maxcol;
{
	register ROW	*rp;
	register CELL	*cp;
	COORD		row;
	COORD		minr;
	COORD		maxr;
	COORD		minc;
	COORD		maxc;

	minr = INFINITY;
	maxr = -INFINITY;
	minc = INFINITY;
	maxc = -INFINITY;

	for (rp = obj->o_firstrow; rp != termrow; rp = rp->r_next) {
		row = rp->r_row;

		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			if ((cp->c_marks & mark) == 0)
				continue;
			if (row < minr)
				minr = row;
			if (row > maxr)
				maxr = row;
			if (cp->c_col < minc)
				minc = cp->c_col;
			if (cp->c_col > maxc)
				maxc = cp->c_col;
		}
	}

	if (minr > maxr)
		return TRUE;

	*minrow = minr;
	*maxrow = maxr;
	*mincol = minc;
	*maxcol = maxc;

	return FALSE;
}


/*
 * Count the number of marked cells in an object
 */
COUNT
countmarks(obj, mark)
	OBJECT	*obj;
	MARK	mark;
{
	register ROW	*rp;
	register CELL	*cp;
	COUNT		count;

	count = 0;
	for (rp = obj->o_firstrow; rp != termrow; rp = rp->r_next) {
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			if (cp->c_marks & mark)
				count++;
		}
	}
	return count;
}


/*
 * Move marked cells to another object.  If the destination object is NULL
 * the cells are just deleted.  The previous cells of the destination object
 * are deleted.
 */
void
movemarkedobject(sobj, dobj, mark)
	OBJECT	*sobj;
	OBJECT	*dobj;
	MARK	mark;
{
	ROW		*rp;
	register CELL	*cp;		/* current cell pointer */
	register CELL	*pcp;		/* previous cell pointer */
	register CELL	*ncp;		/* next cell pointer */

	if (sobj == dobj)
		error("Moving object to itself");

	if (dobj) {
		zeroobject(dobj);
		dobj->o_currow = sobj->o_currow;
		dobj->o_curcol = sobj->o_curcol;
	}

	for (rp = sobj->o_firstrow; rp != termrow; rp = rp->r_next) {
		pcp = NULL;
		cp = rp->r_firstcell;
		while (cp != termcell) {
			if ((cp->c_marks & mark) == 0) {
				pcp = cp;
				cp = cp->c_next;
				continue;
			}
			if (dobj)
				addcell(dobj, rp->r_row, cp->c_col);
			ncp = cp->c_next;
			if (pcp == NULL)
				rp->r_firstcell = ncp;
			else
				pcp->c_next = ncp;
			if (ncp == termcell)
				rp->r_lastcell = pcp;
			cp->c_next = freecells;
			freecells = cp;
			cp = ncp;
			rp->r_count--;
			sobj->o_count--;
		}
	}
}


/*
 * Copy marked cells to another object. The previous cells of the destination
 * object are deleted.  The source object is unaffected.
 */
void
copymarkedobject(sobj, dobj, mark)
	OBJECT	*sobj;
	OBJECT	*dobj;
	MARK	mark;
{
	register ROW	*rp;
	register CELL	*cp;

	if (sobj == dobj)
		error("Copying object to itself");

	zeroobject(dobj);

	dobj->o_currow = sobj->o_currow;
	dobj->o_curcol = sobj->o_curcol;

	for (rp = sobj->o_firstrow; rp != termrow; rp = rp->r_next) {
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			if ((cp->c_marks & mark) == 0)
				continue;
			addcell(dobj, rp->r_row, cp->c_col);
		}
	}
}


/*
 * Rotate the marked cells in the given object around the current cursor
 * location.  This deletes the marked cells, and reinserts them after
 * their position has been rotated by 90 degrees clockwise.
 */
void
rotatemarkedobject(obj, mark)
	OBJECT	*obj;
	MARK	mark;
{
	register ROW	*rp;
	register CELL	*cp;
	COORD		row;
	COORD		col;

	if (obj == tempobject)
		error("Using temp object");

	movemarkedobject(obj, tempobject, mark);

	for (rp = tempobject->o_firstrow; rp != termrow; rp = rp->r_next) {
		row = rp->r_row - obj->o_currow;
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			col = cp->c_col - obj->o_curcol;
			addcell(obj, obj->o_currow + col, obj->o_curcol - row);
		}
	}
}


/*
 * Flip the marked cells in the given object around the column of the current
 * cursor location.  This deletes the marked cells, and reinserts them after
 * their position has been flipped around the vertical axis.
 */
void
flipcolmarkedobject(obj, mark)
	OBJECT	*obj;
	MARK	mark;
{
	register ROW	*rp;
	register CELL	*cp;
	COORD		row;
	COORD		col;

	if (obj == tempobject)
		error("Using temp object");

	movemarkedobject(obj, tempobject, mark);

	for (rp = tempobject->o_firstrow; rp != termrow; rp = rp->r_next) {
		row = rp->r_row;
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next) {
			col = cp->c_col - obj->o_curcol;
			addcell(obj, row, obj->o_curcol - col);
		}
	}
}


/*
 * Flip the marked cells in the given object around the row of the current
 * cursor location.  This deletes the marked cells, and reinserts them after
 * their position has been flipped around the horizontal axis.
 */
void
fliprowmarkedobject(obj, mark)
	OBJECT	*obj;
	MARK	mark;
{
	register ROW	*rp;
	register CELL	*cp;
	COORD		row;

	if (obj == tempobject)
		error("Using temp object");

	movemarkedobject(obj, tempobject, mark);

	for (rp = tempobject->o_firstrow; rp != termrow; rp = rp->r_next) {
		row = 2 * obj->o_currow - rp->r_row;
		for (cp = rp->r_firstcell; cp != termcell; cp = cp->c_next)
			addcell(obj, row, cp->c_col);
	}
}

/* END CODE */
