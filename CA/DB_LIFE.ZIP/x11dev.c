/*
 * Copyright (c) 1993 David I. Bell
 * Permission is granted to use, distribute, or modify this source,
 * provided that this copyright notice remains intact.
 */

#ifdef	X11

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/StringDefs.h>

#include "life.h"


#define	WMRESX		20	/* X pixels to reserve for window manager */
#define	WMRESY		30	/* Y pixels to reserve for window manager */
#define	MINSCALE	-30	/* minimum scale */
#define	DEFAULTSCALE	-8	/* default scale */
#define	GRIDMAG		4	/* magnification when grid can be shown */
#define	TEXTOFF		2	/* pixels for offsetting text from edges */


static	int	gropen();
static	void	grclose();
static	void	grupdate();
static	void	grrefresh();
static	int	grinputready();
static	int	grreadchar();
static	void	grmovecursor();
static	void	grshowview();
static	void	grshowstatus();
static	void	graddstatus();
static	void	grshowhelp();
static	void	graddhelp();
static	int	grassign();


DEV	x11dev = {
	gropen, grclose, grupdate, grrefresh, grinputready, grreadchar,
	grmovecursor, grshowview, grshowstatus, graddstatus, grshowhelp,
	graddhelp, grassign, 0, 0, 0, 0, MINSCALE, MAXSCALE, DEFAULTSCALE
};


/*
 * Other variables.
 */
static	Display		*display;	/* display for X */
static	int		screen;		/* screen number */
static	Window		rootwid;	/* top level window id */
static	Window		mainwid;	/* main window id */
static	Window		viewwid;	/* window id for view of cells */
static	Window		statwid;	/* window id for status line */
static	GC		statgc;		/* GC used for status line */
static	GC		viewgc;		/* GC used for view of cells */
static	GC		viewselectgc;	/* GC used for view of selected cells */
static	GC		viewgridgc;	/* GC used for view of grid */
static	GC		cursorgc;	/* GC used for cursor */
static	XFontStruct	*font;		/* font for text */
static	Colormap	cmap;		/* default color map */
static	long		black;		/* black pixel value */
static	long		white;		/* white pixel value */
static	long		red;		/* red pixel value */
static	long		blue;		/* blue pixel value */
static	long		grey;		/* grey pixel value */
static	int		charheight;	/* height of characters */
static	int		charascent;	/* ascent of characters */
static	int		spacewidth;	/* width of a space */
static	int		statwidth;	/* width of status window */
static	int		statheight;	/* height of status window */
static	int		viewwidth;	/* width of view window */
static	int		viewheight;	/* height of view window */
static	int		usedstatus;	/* space used in status line so far */
static	int		cursorx;	/* current cursor x location */
static	int		cursory;	/* current cursor y location */
static	int		helpx;		/* x position for new help text */
static	int		helpy;		/* y position for new help text */
static	int		helpcol;	/* column number for new help text */
static	BOOL		cursorshown;	/* TRUE if cursor is being shown */
static	BOOL		mapped;		/* TRUE if main window is mapped */
static	UCHAR		*genstr;	/* current char of generated string */
static	UCHAR		genstrbuf[32];	/* generated string to return */
static	UCHAR		assigns[4];	/* macro assignments for buttons */


static	int	doevent();
static	int	dokeydown();
static	void	doexposure();
static	int	dobuttondown();
static	void	viewnormal();
static	void	viewscale();
static	void	drawcursor();
static	void	clearrows();


/*
 * Open the graphics device.
 */
static int
gropen(dev)
	DEV	*dev;
{
	XColor		cellcolor;
	XColor		namecolor;
	XSizeHints	sizehints;
	XWMHints	wmhints;

	display = XOpenDisplay(NULL);
	if (display == NULL) {
		fprintf(stderr, "Cannot open graphics\n");
		return -1;
	}
	screen = DefaultScreen(display);

	font = XLoadQueryFont(display, "fixed");
	if (font == NULL) {
		fprintf(stderr, "Cannot load \"fixed\" font\n");
		return -1;
	}
	charascent = font->ascent;
	charheight = charascent + font->descent;
	spacewidth = font->max_bounds.width;

	/*
	 * Allocate colors, defaulting them if they are not available.
	 */
	black = BlackPixel(display, screen);
	white = WhitePixel(display, screen);
	cmap = DefaultColormap(display, screen);

	red = white;
	blue = black;
	grey = black;

	if (XAllocNamedColor(display, cmap, "red", &cellcolor, &namecolor)) {
		if (cellcolor.pixel != black)
			red = cellcolor.pixel;
	}

	if (XAllocNamedColor(display, cmap, "blue", &cellcolor, &namecolor)) {
		if (cellcolor.pixel != white)
			blue = cellcolor.pixel;
	}

	if (XAllocNamedColor(display, cmap, "grey", &cellcolor, &namecolor)) {
		if (cellcolor.pixel != white)
			grey = cellcolor.pixel;
	}

	viewwidth = DisplayWidth(display, screen) - WMRESX;
	statwidth = viewwidth;
	statheight = charheight + TEXTOFF * 2;
	viewheight = DisplayHeight(display, screen) - statheight - WMRESY;

	rootwid = RootWindow(display, screen);

	mainwid = XCreateSimpleWindow(display, rootwid,
		0, 0, viewwidth, viewheight + statheight,
		0, 0, 0);

	statwid = XCreateSimpleWindow(display, mainwid,
		0, 0, viewwidth, statheight,
		0, 0, grey);

	viewwid = XCreateSimpleWindow(display, mainwid,
		0, statheight, viewwidth, viewheight,
		0, 0, blue);

	XSelectInput(display, mainwid, KeyPressMask | StructureNotifyMask);

	XSelectInput(display, statwid, ExposureMask | KeyPressMask);

	XSelectInput(display, viewwid, ExposureMask | KeyPressMask |
		ButtonPressMask);

	sizehints.flags = PSize | PMinSize | PMaxSize;
	sizehints.width = viewwidth;
	sizehints.min_width = sizehints.width;
	sizehints.max_width = sizehints.width;
	sizehints.height = viewheight + statheight;
	sizehints.min_height = sizehints.height;
	sizehints.max_height = sizehints.height;

	XSetStandardProperties(display, mainwid, "life", "life", None,
		(char **) "", 0, &sizehints);

	wmhints.flags = InputHint;
	wmhints.input = True;

	XSetWMHints(display, mainwid, &wmhints);

	XMapWindow(display, mainwid);
	XMapWindow(display, statwid);
	XMapWindow(display, viewwid);

	statgc = XCreateGC(display, statwid, 0, NULL);
	viewgc = XCreateGC(display, viewwid, 0, NULL);
	viewgridgc = XCreateGC(display, viewwid, 0, NULL);
	viewselectgc = XCreateGC(display, viewwid, 0, NULL);
	cursorgc = XCreateGC(display, viewwid, 0, NULL);

	XSetForeground(display, viewgc, white);
	XSetForeground(display, statgc, blue);
	XSetForeground(display, viewgridgc, (grey != black) ? grey : white);
	XSetForeground(display, viewselectgc, red);
	XSetForeground(display, cursorgc, white ^ blue);
	XSetFunction(display, cursorgc, GXxor);
	XSetFont(display, statgc, font->fid);

	dev->rows = viewheight;
	dev->cols = viewwidth;
	dev->textrows = (viewheight - TEXTOFF * 2) / charheight;
	dev->textcols = (viewwidth - TEXTOFF * 2) / spacewidth;

	genstr = genstrbuf;
	mapped = FALSE;

	return 0;
}


static void
grclose(dev)
	DEV	*dev;
{
	if (display)
		XCloseDisplay(display);
}


static void
grupdate(dev, inputflag)
	DEV	*dev;
{
	XSync(display, False);
}


static void
grrefresh(dev)
	DEV	*dev;
{
	XSync(display, False);
}


/*
 * Read the next character from the terminal, waiting if requested.
 * If not waiting and no character is ready, then EOF is returned.
 * Returns characters from a generated string first, if present.
 */
static int
grreadchar(dev, wait)
	DEV	*dev;
{
	XEvent	event;
	int	ch;

	if (*genstr)
		return *genstr++;

	do {
		if (!wait && (XEventsQueued(display, QueuedAfterFlush) <= 0))
			return EOF;
		XNextEvent(display, &event);
		ch = doevent(&event);
	} while (ch == EOF);

	return ch;
}


/*
 * See if input is ready from the terminal.
 */
static BOOL
grinputready(dev)
	DEV	*dev;
{
	XEvent	event;

	if (*genstr)
		return TRUE;

	while (TRUE) {
		if (XEventsQueued(display, QueuedAfterFlush) <= 0)
			return FALSE;
		XPeekEvent(display, &event);
		if (event.type == KeyPress)
			return TRUE;
		if (event.type == ButtonPress)
			return TRUE;
		XNextEvent(display, &event);
		doevent(&event);
	}
}


/*
 * Assign a macro to be automatically executed by a mouse button.
 * Returns nonzero if the button is illegal.
 */
static int
grassign(dev, button, macro)
	DEV	*dev;
	VALUE	button;
	UCHAR	macro;
{
	if ((button <= 0) || (button > 3))
		return -1;
	assigns[button] = macro;
	return 0;
}


/*
 * Move the cursor to the specified location using the specified scale factor.
 * This is easy to do because we use XOR to draw it.
 */
static void
grmovecursor(dev, sf, row, col)
	DEV	*dev;
	SCALE	sf;
	COORD	row;
	COORD	col;
{
	if (!mapped)
		return;
	if (cursorshown) {
		drawcursor(sf, cursorx, cursory);
		cursorshown = FALSE;
	}
	if ((sf == 0) || (sf == -1))
		sf = 1;
	if (sf < 0) {
		sf = -sf;
		row = row * sf + ((sf - 1) / 2);
		col = col * sf + ((sf - 1) / 2);
		sf = -sf;
	} else {
		row /= sf;
		col /= sf;
	}

	cursorx = col;
	cursory = row;
	drawcursor(sf, cursorx, cursory);
	cursorshown = TRUE;
}


/*
 * Draw the cursor at the specified location.  If the scale factor is
 * large enough, then the cursor is made larger.
 */
static void
drawcursor(sf, x, y)
	SCALE	sf;
	COORD	x;
	COORD	y;
{
	if (sf > -GRIDMAG) {
		XDrawPoint(display, viewwid, cursorgc, x, y);
		return;
	}

	XDrawPoint(display, viewwid, cursorgc, x, y);
	XDrawPoint(display, viewwid, cursorgc, x - 1, y);
	XDrawPoint(display, viewwid, cursorgc, x + 1, y);
	XDrawPoint(display, viewwid, cursorgc, x, y - 1);
	XDrawPoint(display, viewwid, cursorgc, x, y + 1);
}


/*
 * Show the view around the current window location.
 */
static void
grshowview(dev)
	DEV	*dev;
{
	if (!mapped)
		return;
	if (curobj->o_scale > 1)
		viewscale(curobj->o_scale);
	else if (curobj->o_scale >= -1)
		viewnormal(1);
	else
		viewnormal(-curobj->o_scale);
}


/*
 * Update the status line.
 */
static void
grshowstatus(dev, str)
	DEV	*dev;
	char	*str;
{
	int	len;
	int	width;

	if (!mapped)
		return;
	len = strlen(str);
	XClearWindow(display, statwid);
	width = XTextWidth(font, str, len);
	XDrawString(display, statwid, statgc, TEXTOFF, charascent + TEXTOFF, str, len);
	usedstatus = width + TEXTOFF;
}


/*
 * Add to the status line.
 * The assumption is made that this routine is used only for input,
 * and thus the text is ended with an underscore as a prompt.
 */
static void
graddstatus(dev, str)
	DEV	*dev;
	char	*str;
{
	int		len;
	static	int	uswidth;

	len = strlen(str);
	if (uswidth == 0)
		uswidth = XTextWidth(font, "_", 1);

	XClearArea(display, statwid, usedstatus, 0, uswidth, 0, False);
	XDrawString(display, statwid, statgc, usedstatus, charascent + TEXTOFF,
		str, len);
	usedstatus += XTextWidth(font, str, len);
	XDrawString(display, statwid, statgc, usedstatus, charascent + TEXTOFF,
		"_", 1);
}


/*
 * Begin to show help information.
 * We use the view window for this.
 */
static void
grshowhelp(dev)
	DEV	*dev;
{
	XClearWindow(display, viewwid);
	helpcol = 0;
	helpx = TEXTOFF;
	helpy = charascent + TEXTOFF;
}


/*
 * Add information to the help display.
 * We must interpret certain control codes.
 */
static void
graddhelp(dev, str)
	DEV	*dev;
	char	*str;
{
	char	*cp;
	int	len;

	cp = str;
	for (;;) {
		while (*cp >= ' ')
			cp++;

		len = cp - str;
		if (len > 0) {
			XDrawString(display, viewwid, viewgc, helpx, helpy,
				str, len);
			helpcol += len;
			helpx += XTextWidth(font, str, len);
		}

		switch (*cp++) {
			case '\0':
				return;

			case '\n':
				helpcol = 0;
				helpx = TEXTOFF;
				helpy += charheight;
				break;

			case '\t':
				len = 8 - (helpcol + 1) % 8;
				XDrawString(display, viewwid, viewgc,
					helpx, helpy, "        ", len);
				helpcol += len;
				helpx += spacewidth * len;
				break;
		}
		str = cp;
	}
}


/*
 * Handle the specified event.
 * Returns a character generated by the event, or else EOF if
 * the event does not produce a character.
 */
static int
doevent(event)
	XEvent	*event;
{
	switch (event->type) {
		case Expose:
			mapped = TRUE;
			doexposure(&event->xexpose);
			return NULL_CMD;
		case ButtonPress:
			return dobuttondown(&event->xbutton);
			break;
		case KeyPress:
			return dokeydown(&event->xkey);
		case MapNotify:
			mapped = TRUE;
			break;
		case UnmapNotify:
			mapped = FALSE;
			break;
	}
	return EOF;
}


static void
doexposure(ep)
	XExposeEvent	*ep;
{
	if (ep->window == statwid)
		update |= U_STAT;

	if (ep->window == viewwid)
		update |= U_ALL;
}


/*
 * Handle a button down event.
 * This fakes up a string which moves the pointer to the mouse position,
 * and possibly executes a macro.
 */
static int
dobuttondown(bp)
	XButtonEvent	*bp;
{
	char	*cp;
	SCALE	sf;
	COORD	buttonrow;
	COORD	buttoncol;
	COUNT	deltarow;
	COUNT	deltacol;

	if (bp->window != viewwid)
		return -1;

	sf = curobj->o_scale;
	if (sf >= 0) {
		buttonrow = bp->y * sf;
		buttoncol = bp->x * sf;
	} else {
		buttonrow = bp->y / (-sf);
		buttoncol = bp->x / (-sf);
	}

	deltarow = buttonrow - (curobj->o_currow - curobj->o_minrow);
	deltacol = buttoncol - (curobj->o_curcol - curobj->o_mincol);

	if (sf > 1) {
		deltarow /= sf;
		deltacol /= sf;
	}

	sprintf(genstrbuf, "%ldj%ldl", deltarow, deltacol);

	/*
	 * If a macro has been assigned to the button, then add the
	 * sequence to execute the macro.
	 */
	cp = genstrbuf + strlen(genstrbuf);
	if ((bp->button == Button1) && assigns[1]) {
		*cp++ = ESC;
		*cp++ = assigns[1];
	}
	if ((bp->button == Button2) && assigns[2]) {
		*cp++ = ESC;
		*cp++ = assigns[2];
	}
	if ((bp->button == Button3) && assigns[3]) {
		*cp++ = ESC;
		*cp++ = assigns[3];
	}
	*cp = '\0';

	genstr = genstrbuf;

	return NULL_CMD;
}


/*
 * Return a key typed in our window, or EOF if no such key was typed.
 */
static int
dokeydown(kp)
	XKeyEvent	*kp;
{
	KeySym	keysym;
	int	len;
	int	ch;
	UCHAR	buf[12];

	len = XLookupString(kp, buf, sizeof(buf), &keysym, NULL);
	if ((len != 1) || IsModifierKey(keysym))
		return EOF;

	ch = buf[0];
	if (ch == '\r')
		ch = '\n';

	return ch;
}


/*
 * Show the cells around the cursor normally (showing each cell).
 * The specified magnification factor is applied.
 */
static void
viewnormal(mag)
{
	register ROW	*rp;		/* current row */
	register CELL	*cp;		/* current cell */
	COORD		row;		/* current row number */
	COORD		col;		/* current column number */
	OBJECT		*obj;		/* current object */
	COUNT		blankrows;	/* number of blank rows */
	COORD		screenrow;	/* row on screen */
	COORD		screencol;	/* column on screen */
	BOOL		cleared;	/* TRUE is line has been cleared */
	GC		gc;		/* GC for points */

	obj = curobj;
	rp = obj->o_firstrow;
	row = obj->o_minrow;
	while (row > rp->r_row)
		rp = rp->r_next;

	screenrow = 0;
	blankrows = 0;
	seecount = 0;

	for (; row <= obj->o_maxrow; row++) {
		if (row != rp->r_row) {			/* blank row */
			blankrows++;
			screenrow++;
			continue;
		}

		cp = rp->r_firstcell;
		col = obj->o_mincol;
		while (col > cp->c_col)
			cp = cp->c_next;

		screencol = 0;
		cleared = FALSE;

		for (; col <= obj->o_maxcol; col++) {
			if (col != cp->c_col) {		/* blank cell */
				screencol++;
				continue;
			}

			if (!cleared) {
				clearrows((screenrow - blankrows) * mag,
					(blankrows + 1) * mag, mag);
				blankrows = 0;
				cleared = TRUE;
			}

			gc = viewgc;
			if (cp->c_marks & MARK_SEE)
				gc = viewselectgc;

			if (mag == 1) {
				XDrawPoint(display, viewwid, gc, screencol, screenrow);
			} else if (mag == 2) {
				XDrawPoint(display, viewwid, gc, screencol*2, screenrow*2);
				XDrawPoint(display, viewwid, gc, screencol*2+1, screenrow*2);
				XDrawPoint(display, viewwid, gc, screencol*2, screenrow*2+1);
				XDrawPoint(display, viewwid, gc, screencol*2+1, screenrow*2+1);
			} else {
				XFillRectangle(display, viewwid, gc,
					screencol * mag, screenrow * mag,
					mag - 1, mag - 1);
			}

			seecount++;
			screencol++;
			cp = cp->c_next;
		}

		if (!cleared)
			blankrows++;
		screenrow++;
		rp = rp->r_next;
	}

	clearrows((screenrow - blankrows) * mag,
		dev->rows - (screenrow - blankrows) * mag, mag);

	cursorshown = FALSE;
}


/*
 * Show the view around the cursor with an arbitrary scale factor.
 * Each pixel then represents one or more live cells in an N by N area.
 * If any of those cells are marked, then the pixel will show it.
 */
static void
viewscale(sf)
	SCALE	sf;
{
	register CELL	*cp;		/* current cell structure */
	COORD		row;		/* current row number */
	COORD		col;		/* current column number */
	int		sum;		/* number of cells in square */
	OBJECT		*obj;		/* current object */
	CELL		**cpp;		/* pointer into cell table */
	CELL		**endcpp;	/* end of cell table */
	ROW		*rp;		/* row pointer */
	COUNT		blankrows;	/* number of blank rows */
	COORD		screenrow;	/* row on screen */
	COORD		screencol;	/* column on screen */
	BOOL		cleared;	/* TRUE is line has been cleared */
	GC		gc;		/* GC for points */
	CELL		*cptab[MAXSCALE];	/* table of rows */

	obj = curobj;
	row = obj->o_minrow;
	col = obj->o_mincol;
	endcpp = &cptab[sf];
	seecount = 0;
	screenrow = 0;
	blankrows = 0;

	for (rp = curobj->o_firstrow; (rp->r_row < row); rp = rp->r_next)
		;

	while (row <= obj->o_maxrow) {
		/*
		 * If there is a large gap to the next row number then
		 * the graphics line is empty.
		 */
		if (rp->r_row >= (row + sf)) {	/* no rows here */
			row += sf;
			blankrows++;
			screenrow++;
			continue;
		}

		/*
		 * Collect the rows to be searched for one graphics line.
		 * Dummy up empty rows if necessary.
		 */
		for (cpp = cptab; cpp < endcpp; cpp++) {
			*cpp = termcell;
			if (rp->r_row > row++)
				continue;
			*cpp = rp->r_firstcell;
			rp = rp->r_next;
		}

		/*
		 * Advance along each row to the next range of columns,
		 * adding cells found to get the result for each square.
		 */
		screencol = 0;
		cleared = FALSE;

		for (col = obj->o_mincol; col <= obj->o_maxcol; col += sf) {
			gc = viewgc;
			sum = 0;

			for (cpp = cptab; cpp < endcpp; cpp++) {
				cp = *cpp;
				while (col > cp->c_col)
					cp = cp->c_next;

				while ((col + sf) >= cp->c_col) {
					sum++;
					if (cp->c_marks & MARK_SEE)
						gc = viewselectgc;
					cp = cp->c_next;
				}
				*cpp = cp;
			}

			if (sum == 0) {		/* no cells in square */
				screencol++;
				continue;
			}

			if (!cleared) {
				XClearArea(display, viewwid, 0,
					screenrow - blankrows, viewwidth,
					blankrows + 1, False);
				blankrows = 0;
				cleared = TRUE;
			}

			XDrawPoint(display, viewwid, gc, screencol, screenrow);

			seecount += sum;
			screencol++;
		}

		if (!cleared)
			blankrows++;
		screenrow++;
	}

	XClearArea(display, viewwid, 0, screenrow - blankrows, 
		viewwidth, dev->rows - (screenrow - blankrows), False);

	cursorshown = FALSE;
}


/*
 * Clear the specified number of rows on the screen, taking into account
 * the specified magnification factor.  If the magnification is large
 * enough and a grid has been specified, then some dots will be drawn
 * in the cleared rows to indicate the position of each cell.  The row
 * number and row counts are in pixels.
 */
static void
clearrows(row, rowcount, mag)
	COORD	row;
	COUNT	rowcount;
	SCALE	mag;
{
	COUNT	colcount;
	COORD	col;
	COUNT	offset;

	if ((mag < GRIDMAG) || (gridchar == ' ')) {
		XClearArea(display, viewwid, 0,  row,
			viewwidth, rowcount, False);
		return;
	}

	/*
	 * For each row, clear it and then draw one pixel in the center of
	 * each cell of the row.  The whole area isn't cleared at once for
	 * this case so as to make the graphics look nicer as it is drawn.
	 */
	offset = (mag - 1) / 2;
	rowcount /= mag;

	while (rowcount-- > 0) {
		XClearArea(display, viewwid, 0,  row,
			viewwidth, mag, False);
		col = offset;
		colcount = viewwidth / mag;
		while (colcount-- > 0) {
			XDrawPoint(display, viewwid, viewgridgc, col, row + offset);
			col += mag;
		}
		row += mag;
	}
}

#endif

/* END CODE */
