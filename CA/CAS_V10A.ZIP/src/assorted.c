#include "auto.h"


char *my_colors[] =
{

  "grey",

  "black",
  "blue",
  "green",
  "brown",
  "red",
  "orange",
  "yellow",
  "white",

  "darkslategrey",
  "dimgrey",
  "slategrey",
  "lightslategrey",

  "blueviolet",
  "slateblue",
  "lightslateblue",
  "mediumslateblue",

  "steelblue",
  "mediumblue",
  "blue",
  "dodgerblue",
  "cornflowerblue",
  "deepskyblue",
  "lightskyblue",
  "lightblue",
  "lightsteelblue",

  "darkgreen",
  "forestgreen",
  "mediumseagreen",
  "limegreen",
  "lightseagreen",
  "lawngreen",
  "mediumspringgreen",
  "greenyellow",

  "indianred",
  "mediumvioletred",
  "violetred",
  "palevioletred",
  "red",

  "orangered",
  "darkorange",
  "orange",
  "navajowhite",
  "antiquewhite",

  "yellow",
  "lightgoldenrodyellow",
  "lightyellow",

  "floralwhite",
  "white",
  "ghostwhite",

  "black",
  "aquamarine",
  "brown",
  "burlywood",
  "chartreuse",
  "chocolate",
  "coral",
  "cornsilk",
  "cyan",
  "darkgoldenrod",
  "darkkhaki",
  "darkorchid",
  "darksalmon",
  "darkturquoise",
  "darkviolet",
  "deeppink",
  "firebrick",
  "gainsboro",
  "gold",
  "goldenrod",
  "honeydew",
  "hotpink",
  "ivory",
  "khaki",
  "lavender",
  "lavenderblush",
  "lemonchiffon",
  "lightcoral",
  "lightcyan",
  "lightgoldenrod",
  "lightpink",
  "lightsalmon",
  "linen",
  "magenta",
  "maroon",
  "mediumaquamarine",
  "mediumorchid",
  "mediumpurple",
  "mediumturquoise",
  "mintcream",
  "mistyrose",
  "moccasin",
  "navy",
  "oldlace",
  "olivedrab",
  "orchid",
  "palegoldenrod",
  "paleturquoise",
  "papayawhip",
  "peachpuff",
  "pink",
  "plum",
  "purple",
  "rosybrown",
  "saddlebrown",
  "salmon",
  "sandybrown",
  "seashell",
  "sienna",
  "snow",
  "tan",
  "thistle",
  "tomato",
  "turquoise",
  "violet",
  "wheat",
  "beige",
  "bisque",
  "blanchedalmond"

};

color_entry color_table[] =
{
  {"gray", 190, 190, 190},

  {"black", 0, 0, 0},
  {"blue", 0, 0, 255},
  {"green", 0, 255, 0},
  {"brown", 165, 42, 42},
  {"red", 255, 0, 0},
  {"orange", 255, 165, 0},
  {"yellow", 255, 255, 0},
  {"white", 255, 255, 255},

  {"AliceBlue", 240, 248, 255},
  {"AntiqueWhite", 250, 235, 215},
  {"BlanchedAlmond", 255, 235, 205},
  {"BlueViolet", 138, 43, 226},
  {"CadetBlue", 95, 158, 160},
  {"CornflowerBlue", 100, 149, 237},
  {"DarkGoldenrod", 184, 134, 11},
  {"DarkGreen", 0, 100, 0},
  {"DarkKhaki", 189, 183, 107},
  {"DarkOliveGreen", 85, 107, 47},
  {"DarkOrange", 255, 140, 0},
  {"DarkOrchid", 153, 50, 204},
  {"DarkSalmon", 233, 150, 122},
  {"DarkSeaGreen", 143, 188, 143},
  {"DarkSlateBlue", 72, 61, 139},
  {"DarkSlateGray", 47, 79, 79},
  {"DarkTurquoise", 0, 206, 209},
  {"DarkViolet", 148, 0, 211},
  {"DeepPink", 255, 20, 147},
  {"DeepSkyBlue", 0, 191, 255},
  {"DimGray", 105, 105, 105},
  {"DodgerBlue", 30, 144, 255},
  {"FloralWhite", 255, 250, 240},
  {"ForestGreen", 34, 139, 34},
  {"GhostWhite", 248, 248, 255},
  {"GreenYellow", 173, 255, 47},
  {"HotPink", 255, 105, 180},
  {"IndianRed", 205, 92, 92},
  {"LavenderBlush", 255, 240, 245},
  {"LawnGreen", 124, 252, 0},
  {"LemonChiffon", 255, 250, 205},
  {"LightBlue", 173, 216, 230},
  {"LightCoral", 240, 128, 128},
  {"LightCyan", 224, 255, 255},
  {"LightGoldenrod", 238, 221, 130},
  {"LightGoldenrodYellow", 250, 250, 210},
  {"LightGray", 211, 211, 211},
  {"LightPink", 255, 182, 193},
  {"LightSalmon", 255, 160, 122},
  {"LightSeaGreen", 32, 178, 170},
  {"LightSkyBlue", 135, 206, 250},
  {"LightSlateBlue", 132, 112, 255},
  {"LightSlateGray", 119, 136, 153},
  {"LightSteelBlue", 176, 196, 222},
  {"LightYellow", 255, 255, 224},
  {"LimeGreen", 50, 205, 50},
  {"MediumAquamarine", 102, 205, 170},
  {"MediumBlue", 0, 0, 205},
  {"MediumOrchid", 186, 85, 211},
  {"MediumPurple", 147, 112, 219},
  {"MediumSeaGreen", 60, 179, 113},
  {"MediumSlateBlue", 123, 104, 238},
  {"MediumSpringGreen", 0, 250, 154},
  {"MediumTurquoise", 72, 209, 204},
  {"MediumVioletRed", 199, 21, 133},
  {"MidnightBlue", 25, 25, 112},
  {"MintCream", 245, 255, 250},
  {"MistyRose", 255, 228, 225},
  {"NavajoWhite", 255, 222, 173},
  {"NavyBlue", 0, 0, 128},
  {"OldLace", 253, 245, 230},
  {"OliveDrab", 107, 142, 35},
  {"OrangeRed", 255, 69, 0},
  {"PaleGoldenrod", 238, 232, 170},
  {"PaleGreen", 152, 251, 152},
  {"PaleTurquoise", 175, 238, 238},
  {"PaleVioletRed", 219, 112, 147},
  {"PapayaWhip", 255, 239, 213},
  {"PeachPuff", 255, 218, 185},
  {"PowderBlue", 176, 224, 230},
  {"RosyBrown", 188, 143, 143},
  {"RoyalBlue", 65, 105, 225},
  {"SaddleBrown", 139, 69, 19},
  {"SandyBrown", 244, 164, 96},
  {"SeaGreen", 46, 139, 87},
  {"SkyBlue", 135, 206, 235},
  {"SlateBlue", 106, 90, 205},
  {"SlateGray", 112, 128, 144},
  {"SpringGreen", 0, 255, 127},
  {"SteelBlue", 70, 130, 180},
  {"VioletRed", 208, 32, 144},
  {"WhiteSmoke", 245, 245, 245},
  {"YellowGreen", 154, 205, 50},
  {"alice blue", 240, 248, 255},
  {"antique white", 250, 235, 215},
  {"aquamarine", 127, 255, 212},
  {"azure", 240, 255, 255},
  {"beige", 245, 245, 220},
  {"bisque", 255, 228, 196},
  {"blanched almond", 255, 235, 205},
  {"blue violet", 138, 43, 226},
  {"burlywood", 222, 184, 135},
  {"cadet blue", 95, 158, 160},
  {"chartreuse", 127, 255, 0},
  {"chocolate", 210, 105, 30},
  {"coral", 255, 127, 80},
  {"cornflower blue", 100, 149, 237},
  {"cornsilk", 255, 248, 220},
  {"cyan", 0, 255, 255},
  {"dark goldenrod", 184, 134, 11},
  {"dark green", 0, 100, 0},
  {"dark khaki", 189, 183, 107},
  {"dark olive green", 85, 107, 47},
  {"dark orange", 255, 140, 0},
  {"dark orchid", 153, 50, 204},
  {"dark salmon", 233, 150, 122},
  {"dark sea green", 143, 188, 143},
  {"dark slate blue", 72, 61, 139},
  {"dark slate gray", 47, 79, 79},
  {"dark turquoise", 0, 206, 209},
  {"dark violet", 148, 0, 211},
  {"deep pink", 255, 20, 147},
  {"deep sky blue", 0, 191, 255},
  {"dim gray", 105, 105, 105},
  {"dodger blue", 30, 144, 255},
  {"firebrick", 178, 34, 34},
  {"floral white", 255, 250, 240},
  {"forest green", 34, 139, 34},
  {"gainsboro", 220, 220, 220},
  {"ghost white", 248, 248, 255},
  {"gold", 255, 215, 0},
  {"goldenrod", 218, 165, 32},
  {"green yellow", 173, 255, 47},
  {"honeydew", 240, 255, 240},
  {"hot pink", 255, 105, 180},
  {"indian red", 205, 92, 92},
  {"ivory", 255, 255, 240},
  {"khaki", 240, 230, 140},
  {"lavender", 230, 230, 250},
  {"lavender blush", 255, 240, 245},
  {"lawn green", 124, 252, 0},
  {"lemon chiffon", 255, 250, 205},
  {"light blue", 173, 216, 230},
  {"light coral", 240, 128, 128},
  {"light cyan", 224, 255, 255},
  {"light goldenrod", 238, 221, 130},
  {"light goldenrod yellow", 250, 250, 210},
  {"light gray", 211, 211, 211},
  {"light pink", 255, 182, 193},
  {"light salmon", 255, 160, 122},
  {"light sea green", 32, 178, 170},
  {"light sky blue", 135, 206, 250},
  {"light slate blue", 132, 112, 255},
  {"light slate gray", 119, 136, 153},
  {"light steel blue", 176, 196, 222},
  {"light yellow", 255, 255, 224},
  {"lime green", 50, 205, 50},
  {"linen", 250, 240, 230},
  {"magenta", 255, 0, 255},
  {"maroon", 176, 48, 96},
  {"medium aquamarine", 102, 205, 170},
  {"medium blue", 0, 0, 205},
  {"medium orchid", 186, 85, 211},
  {"medium purple", 147, 112, 219},
  {"medium sea green", 60, 179, 113},
  {"medium slate blue", 123, 104, 238},
  {"medium spring green", 0, 250, 154},
  {"medium turquoise", 72, 209, 204},
  {"medium violet red", 199, 21, 133},
  {"midnight blue", 25, 25, 112},
  {"mint cream", 245, 255, 250},
  {"misty rose", 255, 228, 225},
  {"moccasin", 255, 228, 181},
  {"navajo white", 255, 222, 173},
  {"navy", 0, 0, 128},
  {"navy blue", 0, 0, 128},
  {"old lace", 253, 245, 230},
  {"olive drab", 107, 142, 35},
  {"orange red", 255, 69, 0},
  {"orchid", 218, 112, 214},
  {"pale goldenrod", 238, 232, 170},
  {"pale green", 152, 251, 152},
  {"pale turquoise", 175, 238, 238},
  {"pale violet red", 219, 112, 147},
  {"papaya whip", 255, 239, 213},
  {"peach puff", 255, 218, 185},
  {"peru", 205, 133, 63},
  {"pink", 255, 192, 203},
  {"plum", 221, 160, 221},
  {"powder blue", 176, 224, 230},
  {"purple", 160, 32, 240},
  {"rosy brown", 188, 143, 143},
  {"royal blue", 65, 105, 225},
  {"saddle brown", 139, 69, 19},
  {"salmon", 250, 128, 114},
  {"sandy brown", 244, 164, 96},
  {"sea green", 46, 139, 87},
  {"seashell", 255, 245, 238},
  {"sienna", 160, 82, 45},
  {"sky blue", 135, 206, 235},
  {"slate blue", 106, 90, 205},
  {"slate gray", 112, 128, 144},
  {"snow", 255, 250, 250},
  {"spring green", 0, 255, 127},
  {"steel blue", 70, 130, 180},
  {"tan", 210, 180, 140},
  {"thistle", 216, 191, 216},
  {"tomato", 255, 99, 71},
  {"turquoise", 64, 224, 208},
  {"violet", 238, 130, 238},
  {"violet red", 208, 32, 144},
  {"wheat", 245, 222, 179},
  {"white smoke", 245, 245, 245},
  {"yellow green", 154, 205, 50},
  {"", 0, 0, 0}
};

/************************************************************************/
/*			PRIVATE FUNCTIONS				*/
/************************************************************************/
int isnt_space (char ch);


/************************************************************************/
/*			THE FUNCTIONS					*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void set_colour (char *colour)
{
  GP_setColor (GP_defColor (colour, FALSE));
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void set_gray (int level)
{
  if (level > MAX_COLORS)
    level = MAX_COLORS;
  if (level < 0)
    level = 0;


  /*
  col = color_table[level];
  printf ("r %d, g %d, b %d\n", col.r, col.g, col.b);
  GP_setColor(GP_defColorRGB(col.r, col.b,col.g, FALSE));
  */
  set_colour(my_colors[level]);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void GNU_thing ()
{
  puts ("automata version 1.0A, Copyright (C) 1993 Sunil Gupta");
  puts ("automata comes with ABSOLUTELY NO WARRANTY ");
  puts ("This is free software, and you are welcome to redistribute it");
  puts ("under certain conditions");
  puts ("See the file LICENSE for more details");
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void
  reset_RowCol (SUIT_object auto_obj, int new_rows, int new_cols)
{
  int number;
  automaton *automata;

  number = SUIT_getInteger (auto_obj, NUMBER);
  automata = auto_arr[number];
  free (automata);

  rows = new_rows;
  cols = new_cols;

  automata = (automaton *) malloc ((rows * cols) * sizeof (automaton));

  InitAutomaton (automata);
  auto_arr[number] = automata;

  SUIT_setInteger (auto_obj, ROWS, rows);
  SUIT_setInteger (auto_obj, COLUMNS, cols);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:		returns index of element in array so as to 	*/
/*			appear to be an infinite plane			*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int
  get_item (int row, int col)
{
  int r, c;
  int retval;


  c = col % cols;
  r = row % rows;

  while (c < 0)
    c += cols;
  while (r < 0)
    r += rows;

  retval = (r * cols) + c;

  return (retval);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void trim (char *str, char **start)
{
  char *end, *first;

  *start = str;

  if (*str)
  {
    /* -------------------------------------------------------- */
    /* locate first non space character                         */
    /* -------------------------------------------------------- */
    first = str;
    while (*first == ' ')
      first++;

    /* -------------------------------------------------------- */
    /* find end of string                                       */
    /* -------------------------------------------------------- */
    end = first;
    while (*end)
      end++;

    /* -------------------------------------------------------- */
    /* locate last non space character                          */
    /* -------------------------------------------------------- */
    while (!isnt_space (*end) && (end > first))
      end--;

    if (isnt_space (*end))
      end++;

    *end = 0;

    *start = first;

  }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int isnt_space (char ch)
{
  return ((ch > 32) && (ch < 127));
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
char *skiptonum (char *ch)
{
  while (*ch && isdigit (*ch))
    ch++;

  while (*ch && !isdigit (*ch))
    ch++;

  return (ch);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void setfont (SUIT_object obj, char *name, char *style, double size)
{
  SUIT_setFont (obj, FONT, GP_defFont (name, style, size));
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void do_state_typein (SUIT_object auto_obj)
{
  char buffer[200];
  int rows, cols, states;
  SUIT_object state_obj, rows_obj, cols_obj, color_obj;

  rows = SUIT_getInteger (auto_obj, ROWS);
  cols = SUIT_getInteger (auto_obj, COLUMNS);
  states = SUIT_getInteger (auto_obj, STATES);

  state_obj = SUIT_getObject (auto_obj, STATEOBJ);
  rows_obj = SUIT_getObject (auto_obj, ROWSOBJ);
  cols_obj = SUIT_getObject (auto_obj, COLSOBJ);
  color_obj = SUIT_getObject (state_obj, COLOROBJ);

  SUIT_setInteger (color_obj, CSTATES, states);

  sprintf (buffer, "%d", states);
  SUIT_setText (state_obj, CURRENT_VALUE, buffer);

  sprintf (buffer, "%d", rows);
  SUIT_setText (rows_obj, CURRENT_VALUE, buffer);

  sprintf (buffer, "%d", cols);
  SUIT_setText (cols_obj, CURRENT_VALUE, buffer);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
DynArray set_object_to_check (SUIT_object abort_obj)
{
  DynArray dyn_list;

  dyn_list = DynCreate (sizeof (SUIT_object), 1);
  DynAdd (dyn_list, (void *) &abort_obj);

  return (dyn_list);
}
