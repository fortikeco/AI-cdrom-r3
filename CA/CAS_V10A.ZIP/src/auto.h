#ifndef __AUTOMATA_AUTO
#  define __AUTOMATA_AUTO

#  include <suit.h>
#  include <stdio.h>
#  include <math.h>

#  include "colorbar.h"
#  include "abort.h"

#  include "automata.h"

#  include "assorted.h"
#  include "callback.h"
#  include "files.h"
#  include "main.h"
#  include "methods.h"
#  include "neighbours.h"
#  include "rules.h"

#  define BUFFER_SIZE 900
#  define ELEGANT

#endif
