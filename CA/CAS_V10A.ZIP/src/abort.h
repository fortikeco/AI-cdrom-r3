#ifndef _ABORT_WIDGET
#  define _ABORT_WIDGET

#  include <suit.h>


SUIT_object CreateAbortWidget (char *name);
void do_until_abort( char *label, int (callback)());

#  define ABORTED "hit abort button"
#  define PARENT "parent object"

#endif
