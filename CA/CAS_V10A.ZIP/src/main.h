#ifndef _AUTOMATA_MAIN
#  define _AUTOMATA_MAIN

extern SUIT_object auto_obj;

#define nint(x) floor((x)+ 0.5)

#endif
