#include "auto.h"

/************************************************************************/
/*			PRIVATE FUNCTIONS				*/
/************************************************************************/
void PaintAbortWidget (SUIT_object obj);
void HitAbortWidget (SUIT_object obj, SUIT_event ev);
void HitAbortButton (SUIT_object obj, SUIT_event ev);


/************************************************************************/
/* User defined  SUIT objects						*/
/************************************************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name: 	CreateAbortWidget				*/
/* 									*/
/* Description:		create a new instance of the graphics widget	*/
/*			for displaying Abort-nets			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	name of widget					*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	pointer to new SUIT object			*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

SUIT_object CreateAbortWidget (char *name)
{
  SUIT_object obj, label_obj, button_obj;
  char buffer[200];

  /* ------------------------------------------------------------------	*/
  /* 		basic setup of Abort object				*/
  /* ------------------------------------------------------------------	*/
  obj = SUIT_createObject (name, "Abort class");
  SUIT_addDisplayToObject
    (
      obj,
      "standard",
      HitAbortWidget,
      PaintAbortWidget
    );

  SUIT_setBoolean (obj, ABORTED, FALSE);
  SUIT_makePropertyTemporary (obj, ABORTED, OBJECT);

  /* ---------------------------------------------------------------- */
  SUIT_setEnumString (obj, BORDER_TYPE, "fancy motif");

  sprintf (buffer, "%s button", name);
  button_obj = SUIT_createButton (buffer, HitAbortWidget);
  SUIT_setText (button_obj, LABEL, "Stop");
  SUIT_makePropertyTemporary (button_obj, LABEL, OBJECT);

  sprintf (buffer, "%s label", name);
  label_obj = SUIT_createLabel (buffer);
  SUIT_setText (label_obj, LABEL, name);
  SUIT_makePropertyTemporary (label_obj, LABEL, OBJECT);

  /* ---------------------------------------------------------------- */

  SUIT_addChildToObject (obj, button_obj);
  SUIT_addChildToObject (obj, label_obj);
  SUIT_bringToFront (button_obj);

  /* ---------------------------------------------------------------- */
  setchildsize (obj, 0.0, 0.05, 0.09, 0.2);
  setchildsize (button_obj, 0.0, 0.1, 1.0, 0.4);
  setchildsize (label_obj, 0.0, 0.5, 1.0, 1.0);

  /* ---------------------------------------------------------------- */
  return (obj);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void PaintAbortWidget (SUIT_object obj)
{
  SUIT_paintChildren (obj);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void HitAbortWidget (SUIT_object obj, SUIT_event ev)
{
  SUIT_setBoolean (obj, ABORTED, TRUE);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void HitAbortButton (SUIT_object obj, SUIT_event ev)
{
  SUIT_object parent;

  parent = SUIT_getParent (obj);
  SUIT_setBoolean (parent, ABORTED, TRUE);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void do_until_abort (char *label, int (callback) ())
{
  SUIT_object abort_obj;
  DynArray objs;

  int aborted = FALSE;

  abort_obj = CreateAbortWidget ("Abort");
  SUIT_setText (abort_obj, LABEL, label);
  SUIT_paintObject (abort_obj);

  objs = set_object_to_check (abort_obj);

  while (!aborted)
  {
    aborted = callback ();

    if (!aborted)
    {
      SUIT_limitedCheckAndProcessInput (2, objs);
      aborted = SUIT_getBoolean (abort_obj, ABORTED);
    }
  }

  SUIT_paintObject (abort_obj);
  SUIT_destroyObject (abort_obj);
  DynDestroy (objs);
}
