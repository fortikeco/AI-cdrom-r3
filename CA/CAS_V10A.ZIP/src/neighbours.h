#ifndef _AUTOMATA_NEIGHBOURS
#  define _AUTOMATA_NEIGHBOURS

int neighbours (automaton * automata, int row, int col);

int north (automaton *automata, int row, int col);
int north_east (automaton *automata, int row, int col);
int east (automaton *automata, int row, int col);
int south_east (automaton *automata, int row, int col);
int south (automaton *automata, int row, int col);
int south_west (automaton *automata, int row, int col);
int west (automaton *automata, int row, int col);
int north_west (automaton *automata, int row, int col);


#endif
