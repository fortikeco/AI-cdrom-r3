#ifndef __CALLBACK_AUTO
#  define __CALLBACK_AUTO

void adjust_cols (SUIT_object obj);
void adjust_rows (SUIT_object obj);
void adjust_states (SUIT_object obj);
void change_grid (SUIT_object obj);
void change_step (SUIT_object obj);

void clear_auto (SUIT_object obj);
void load_auto (SUIT_object obj);
void save_auto (SUIT_object obj);
void exit_auto (SUIT_object obj);

void do_method (SUIT_object obj);

#endif
