#ifndef _AUTOMATA_FILES
#  define _AUTOMATA_FILES

int exists (char *fname);
void save_auto_data (FILE * fp, SUIT_object auto_obj);
int load_auto_data (FILE * fp, SUIT_object auto_obj);

#endif
