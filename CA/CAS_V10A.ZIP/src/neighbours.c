#include "auto.h"

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int neighbours (automaton * automata, int row, int col)
{
  int my_row, my_col;
  int my_item;
  int touching = 0;

  for (my_row = -1; my_row <= 1; my_row++)
    for (my_col = -1; my_col <= 1; my_col++)
      if ((my_col != 0) || (my_row != 0))
      {
	my_item = get_item (row + my_row, col + my_col);
	if (automata[my_item].state > 0)
	  touching++;
      }
  return (touching);
}


int north (automaton * automata, int row, int col)
{
  int item;
  int retval = 0;

  item = get_item (row + 1, col);
  retval = automata[item].state;
  return (retval);
}

int north_east (automaton * automata, int row, int col)
{
  int item;
  int retval = 0;

  item = get_item (row + 1, col-1);
  retval = automata[item].state;
  return (retval);
}

int east (automaton * automata, int row, int col)
{
  int item;
  int retval = 0;

  item = get_item (row, col - 1);
  retval = automata[item].state;
  return (retval);
}

int south_east (automaton * automata, int row, int col)
{
  int item;
  int retval = 0;

  item = get_item (row-1, col - 1);
  retval = automata[item].state;
  return (retval);
}

int south (automaton * automata, int row, int col)
{
  int item;
  int retval = 0;

  item = get_item (row - 1, col);
  retval = automata[item].state;
  return (retval);
}

int south_west (automaton * automata, int row, int col)
{
  int item;
  int retval = 0;

  item = get_item (row - 1, col+1);
  retval = automata[item].state;
  return (retval);
}

int west (automaton * automata, int row, int col)
{
  int item;
  int retval = 0;

  item = get_item (row, col + 1);
  retval = automata[item].state;
  return (retval);
}

int north_west (automaton * automata, int row, int col)
{
  int item;
  int retval = 0;

  item = get_item (row + 1, col+1);
  retval = automata[item].state;
  return (retval);
}


