#ifndef _AUTOMATA_ASSORTED
#  define _AUTOMATA_ASSORTED

#  define MAX_COLORS 118


typedef struct _color_entry
{
  char *name;
  short int r;
  short int g;
  short int b;
} color_entry;


void set_colour (char *colour);
void set_gray (int level);

void GNU_thing (void);

void reset_RowCol (SUIT_object auto_obj, int rows, int cols);
int get_item (int row, int col);
void trim (char *str, char **start);
char *skiptonum (char *ch);
void setfont (SUIT_object obj, char *name, char *style, double size);
void do_state_typein (SUIT_object auto_obj);
DynArray set_object_to_check (SUIT_object abort_obj);

#endif
