#include "auto.h"



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void
  adjust_cols (SUIT_object obj)
{
  SUIT_object auto_obj;
  int cols;
  int actual_rows, actual_cols;
  char buffer[200];

  auto_obj = SUIT_getObject (obj, AUTOMATON);

  cols = atoi (SUIT_getText (obj, CURRENT_VALUE));
  actual_rows = SUIT_getInteger (auto_obj, ROWS);
  actual_cols = SUIT_getInteger (auto_obj, COLUMNS);

  if ((cols > 0) && (cols <= MAX_COLS))
  {
    if (cols != actual_cols)
      reset_RowCol (auto_obj, actual_rows, cols);
  }
  else
  {
    sprintf
      (
	buffer,
	"Invalid number of columns\nMust be in range 1<->%d",
	MAX_COLS
      );
    SUIT_inform (buffer);
  }

  do_state_typein (auto_obj);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void
  adjust_rows (SUIT_object obj)
{
  SUIT_object auto_obj;
  int rows;
  int actual_rows, actual_cols;
  char buffer[200];

  auto_obj = SUIT_getObject (obj, AUTOMATON);

  rows = atoi (SUIT_getText (obj, CURRENT_VALUE));
  actual_rows = SUIT_getInteger (auto_obj, ROWS);
  actual_cols = SUIT_getInteger (auto_obj, COLUMNS);

  if ((rows > 0) && (rows <= MAX_ROWS))
  {
    if (rows != actual_rows)
      reset_RowCol (auto_obj, rows, actual_cols);
  }
  else
  {
    sprintf
      (
	buffer,
	"Invalid number of rows\nMust be in range 1<->%d",
	MAX_ROWS
      );
    SUIT_inform (buffer);
  }

  do_state_typein (auto_obj);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void
  adjust_states (SUIT_object obj)
{
  int states, rows, cols, number;
  int row, col, item;
  SUIT_object auto_obj;
  automaton *automata;
  char buffer[200];


  states = atoi (SUIT_getText (obj, CURRENT_VALUE));
  auto_obj = SUIT_getObject (obj, AUTOMATON);

  if ((states > 0) && (states <= MAX_STATES))
  {

    rows = SUIT_getInteger (auto_obj, ROWS);
    cols = SUIT_getInteger (auto_obj, COLUMNS);
    number = SUIT_getInteger (auto_obj, NUMBER);
    automata = auto_arr[number];

    SUIT_setInteger (auto_obj, STATES, states);

    for (row = 0; row < rows; row++)
      for (col = 0; col < cols; col++)
      {
	item = get_item (row, col);

	if (automata[item].state > states)
	{
	  automata[item].state = states;
	  automata[item].changed = TRUE;
	}
	else if (automata[item].state > 0)
	  automata[item].changed = TRUE;
      }
  }
  else
  {
    sprintf
      (
	buffer,
	"Invalid number of states\nMust be in range 1<->%d",
	MAX_STATES
      );
    SUIT_inform (buffer);
  }

  do_state_typein (auto_obj);

  SUIT_paintObject (obj);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void
  change_grid (SUIT_object obj)
{
  SUIT_object auto_obj;
  int grid;

  auto_obj = SUIT_getObject (obj, AUTOMATON);

  grid = SUIT_getBoolean (obj, CURRENT_VALUE);
  SUIT_setBoolean (auto_obj, GRID, grid);
  SUIT_setBoolean (auto_obj, GRID_CHANGED, TRUE);

  SUIT_paintObject (obj);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void
  change_step (SUIT_object obj)
{
  SUIT_object auto_obj;
  int grid;

  auto_obj = SUIT_getObject (obj, AUTOMATON);

  grid = SUIT_getBoolean (obj, CURRENT_VALUE);
  SUIT_setBoolean (auto_obj, STEP, grid);

  SUIT_paintObject (obj);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void load_auto (SUIT_object obj)
{
  char *fname;
  FILE *fp;
  SUIT_object auto_obj;

  fname = SUIT_askForFileName (".", "LOAD", "Select filename");
  if (fname)
  {
    fp = fopen (fname, "r");
    if (fp)
    {
      auto_obj = SUIT_getObject (obj, AUTOMATON);
      if (load_auto_data (fp, auto_obj))
      {
	do_state_typein (auto_obj);
	SUIT_paintObject (auto_obj);
      }
      else
	SUIT_inform ("error loading automaton data");
      fclose (fp);
    }
    else
      SUIT_inform ("File does not exist");
  }
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void clear_auto (SUIT_object obj)
{
  SUIT_object auto_obj;
  int number;
  automaton *automata;

  auto_obj = SUIT_getObject (obj, AUTOMATON);

  number = SUIT_getInteger (auto_obj, NUMBER);
  automata = auto_arr[number];

  InitAutomaton(automata);
  SUIT_paintObject (auto_obj);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void save_auto (SUIT_object obj)
{
  char *fname, *SUIT_fname;
  char buffer[BUFFER_SIZE];
  int go_ahead = TRUE;
  SUIT_object auto_obj;
  FILE *fp;

  SUIT_fname = SUIT_askForFileName (".", "SAVE", "select filename");

  if (SUIT_fname)
  {
    fname = strdup (SUIT_fname);

    if (exists (fname))
    {
      sprintf (buffer, "Overwrite file @b(%s) ?", fname);
      if (SUIT_askYesNo (buffer) == REPLY_NO)
      {
	SUIT_inform ("Save Aborted");
	go_ahead = FALSE;
      }
    }

    if (go_ahead)
    {
      fp = fopen (fname, "w");
      if (fp)
      {
	auto_obj = SUIT_getObject (obj, AUTOMATON);
	save_auto_data (fp, auto_obj);
	fclose (fp);
      }
      else
	SUIT_inform ("Error opening file");
    }

    free (fname);
  }
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void do_method (SUIT_object obj)
{
  SUIT_object abort_obj, auto_obj;
  int number, rows, cols, grid;
  DynArray objs;
  char *label;
  rule *current_rule;
  fn_ptr callback;

  int changed = 99999;
  int aborted = FALSE;
  int step;
  int found = FALSE;

  /* ------------------------------------------------------------------	*/
  /* get some properties for use later on				*/
  /* ------------------------------------------------------------------	*/
  auto_obj = SUIT_getObject (obj, AUTOMATON);
  number = SUIT_getInteger (auto_obj, NUMBER);
  rows = SUIT_getInteger (auto_obj, ROWS);
  cols = SUIT_getInteger (auto_obj, COLUMNS);
  grid = SUIT_getBoolean (auto_obj, GRID);
  step = SUIT_getBoolean (auto_obj, STEP);

  SUIT_setBoolean (auto_obj, GRID, FALSE);

  /* ------------------------------------------------------------------	*/
  /* put an abort widget on the screen					*/
  /* ------------------------------------------------------------------	*/

  label = SUIT_getText (obj, CURRENT_VALUE);
  abort_obj = CreateAbortWidget (label);
  setchildsize (abort_obj, 0.0, 0.40, 0.10, 0.60);

  SUIT_paintObject (abort_obj);

  objs = set_object_to_check (abort_obj);

  /* ------------------------------------------------------------------	*/

  while (*label == ' ')
    label++;			/* trim leading spaces */


  /* ------------------------------------------------------------------	*/
  /* determine which method to use.. its in the form of a string at the */
  /* moment and I dont want to have to do a strcmp everytime 		*/
  /* ------------------------------------------------------------------	*/

  current_rule = rule_array;
  while ((!found) && current_rule)
  {
    if (strcmp (label, current_rule->name) == 0)
    {
      found = TRUE;
      callback = current_rule->callback;
    }
    else
      current_rule++;
  }

  /* ------------------------------------------------------------------	*/
  /* this is the loop which does the biz				*/
  /* ------------------------------------------------------------------	*/
  while ((changed > 0) && !aborted && found)
  {
    changed = step_method (callback, auto_arr[number], rows, cols);
    SUIT_paintObject (auto_obj);

    if (step)
      aborted = TRUE;
    else if (changed > 0)
    {
      SUIT_limitedCheckAndProcessInput (2, objs);
      aborted = SUIT_getBoolean (abort_obj, ABORTED);
    }
  }

  /* ------------------------------------------------------------------	*/
  /* if there was an error, let the user know (nothing they can do)	*/
  /* ------------------------------------------------------------------	*/
  /*                   redundant
  if (changed == METHOD_NOTIMPL)
    SUIT_inform ("sorry, that rule is not yet implemented");
  else if (changed < 0)
    SUIT_inform ("The last method returned an error condition");
  */

  /* ------------------------------------------------------------------	*/
  /* abort widget isnt needed,  grid should be restored 		*/
  /* ------------------------------------------------------------------	*/
  SUIT_destroyObject (abort_obj);
  SUIT_setBoolean (auto_obj, GRID, grid);

  DynDestroy (objs);
}
