#include "auto.h"


void check_neighbours (automaton * automata, int row, int col, fn_ptr callback);


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int step_method (fn_ptr callback, automaton * automata, int rows, int cols)
{
  int row, col, item;
  int retval;

  for (row = 0; row < rows; row++)
    for (col = 0; col < cols; col++)
    {
      item = get_item (row, col);
      if (automata[item].state > 0)
	check_neighbours (automata, row, col, callback);
    }

  retval = update_changed (automata);

  return (retval);
}



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int update_changed (automaton * automata)
{
  int row, col, index;
  int changed = 0;

  for (row = 0; row < rows; row++)
    for (col = 0; col < cols; col++)
    {
      index = get_item (row, col);
      if (automata[index].changed)
      {
	automata[index].state = automata[index].tmp;
	changed++;
      }

      automata[index].checked = FALSE;
    }

  return (changed);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void check_neighbours (
		    automaton * automata, int row, int col, fn_ptr callback)
{
  int my_row, my_col, item;

  for (my_row = row - 1; my_row <= row + 1; my_row++)
    for (my_col = col - 1; my_col <= col + 1; my_col++)
    {
      item = get_item (my_row, my_col);
      if (!automata[item].checked)
      {
	callback (automata, my_row, my_col, item);
	if (automata[item].state != automata[item].tmp)
	{
	  automata[item].changed = TRUE;
	}
	automata[item].checked = TRUE;
      }
    }
}
