#include "auto.h"

/************************************************************************/
/* 				GLOBALS					*/
/************************************************************************/
int n_autos = 0;
automaton *auto_arr[MAX_AUTOMATA];
double x_step, y_step;
int rows, cols;

/************************************************************************/
/*			PRIVATE FUNCTIONS				*/
/************************************************************************/
void PaintAutomataWidget (SUIT_object obj);
void HitAutomataWidget (SUIT_object obj, SUIT_event ev);
void PaintAutomatonSquare
  (automaton * automata, int row, int col, int grid);
void PaintAutomatonGrid (SUIT_object auto_obj);


/************************************************************************/
/* User defined  SUIT objects						*/
/************************************************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name: 	CreateAutomataWidget				*/
/* 									*/
/* Description:		create a new instance of the graphics widget	*/
/*			for displaying Automata-nets			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	name of widget					*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	pointer to new SUIT object			*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

SUIT_object
CreateAutomataWidget (char *name)
{
  SUIT_object obj;
  SUIT_object board, rows_label, cols_label, states_label;
  SUIT_object rows_obj, cols_obj, states_obj;
  SUIT_object step_obj, grid_obj, clear_obj, file_obj, color_obj;
  SUIT_object save_obj, load_obj;
  SUIT_object method_obj;
  SUIT_textList method_list;
  rule *current_rule;

  int states;
  automaton *automata;
  char buffer[BUFFER_SIZE];


  if (n_autos > MAX_AUTOMATA)
  {
    SUIT_inform ("Maximum automata limit reached");
    exit (1);
  }

  rows = DEFAULT_ROWS;
  cols = DEFAULT_COLS;
  states = DEFAULT_STATES;


  /* ----------------------------------------------------------------	*/
  /* 		basic setup of automaton object				*/
  /* ----------------------------------------------------------------	*/
  obj = SUIT_createObject (name, "Automata class");
  SUIT_addDisplayToObject
    (
      obj,
      "standard",
      HitAutomataWidget,
      PaintAutomataWidget
    );

  /* ----------------------------------------------------------------	*/
  /* allocate space for cellular automaton				*/
  /* ----------------------------------------------------------------	*/
  automata = (automaton *) malloc ((rows * cols) * sizeof (automaton));
  InitAutomaton (automata);

  /* ----------------------------------------------------------------	*/
  /*			set automaton properties			*/
  /* ----------------------------------------------------------------	*/
  SUIT_setInteger (obj, ROWS, rows);
  SUIT_setInteger (obj, COLUMNS, cols);
  SUIT_setInteger (obj, STATES, states);
  SUIT_setInteger (obj, NUMBER, n_autos);
  SUIT_setBoolean (obj, GRID, TRUE);
  SUIT_setBoolean (obj, HAS_BACKGROUND, FALSE);

  SUIT_makePropertyTemporary (obj, ROWS, OBJECT);
  SUIT_makePropertyTemporary (obj, COLUMNS, OBJECT);
  SUIT_makePropertyTemporary (obj, STATES, OBJECT);
  SUIT_makePropertyTemporary (obj, NUMBER, OBJECT);
  SUIT_makePropertyTemporary (obj, GRID, OBJECT);

  SUIT_lockProperty (obj, ROWS, OBJECT);
  SUIT_lockProperty (obj, COLUMNS, OBJECT);
  SUIT_lockProperty (obj, STATES, OBJECT);
  SUIT_lockProperty (obj, NUMBER, OBJECT);
  SUIT_lockProperty (obj, GRID, OBJECT);

  auto_arr[n_autos] = automata;

  /* ---------------------------------------------------------------- */
  /* 				create the bulletin board		*/
  /* ---------------------------------------------------------------- */
  sprintf (buffer, "%s board", name);
  board = SUIT_createBulletinBoard (buffer);

  /* ---------------------------------------------------------------- */
  /* 			create the labels				*/
  /* ---------------------------------------------------------------- */
  sprintf (buffer, "%s rlabel", name);
  rows_label = SUIT_createLabel (buffer);
  SUIT_setText (rows_label, LABEL, "rows");

  sprintf (buffer, "%s clabel", name);
  cols_label = SUIT_createLabel (buffer);
  SUIT_setText (cols_label, LABEL, "cols");

  sprintf (buffer, "%s slabel", name);
  states_label = SUIT_createLabel (buffer);
  SUIT_setText (states_label, LABEL, "states");

  /* ---------------------------------------------------------------- */
  /*			create type in boxes				*/
  /* ---------------------------------------------------------------- */
  sprintf (buffer, "%s stype", name);
  states_obj = SUIT_createTypeInBox (buffer, adjust_states);
  SUIT_makePropertyTemporary (states_obj, CURRENT_VALUE, OBJECT);

  sprintf (buffer, "%d", states);
  SUIT_setText (states_obj, CURRENT_VALUE, buffer);

  SUIT_setObject (states_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (states_obj, AUTOMATON, OBJECT);

  /*  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

  sprintf (buffer, "%s rtype", name);
  rows_obj = SUIT_createTypeInBox (buffer, adjust_rows);
  SUIT_makePropertyTemporary (rows_obj, CURRENT_VALUE, OBJECT);

  sprintf (buffer, "%d", rows);
  SUIT_setText (rows_obj, CURRENT_VALUE, buffer);

  SUIT_setObject (rows_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (rows_obj, AUTOMATON, OBJECT);

  /*  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

  sprintf (buffer, "%s ctype", name);
  cols_obj = SUIT_createTypeInBox (buffer, adjust_cols);
  SUIT_makePropertyTemporary (cols_obj, CURRENT_VALUE, OBJECT);

  sprintf (buffer, "%d", cols);
  SUIT_setText (cols_obj, CURRENT_VALUE, buffer);

  SUIT_setObject (cols_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (cols_obj, AUTOMATON, OBJECT);

  /* ----------------------------------------------------------------	*/
  /*                    add a  grid toggle switch			*/
  /* ----------------------------------------------------------------	*/
  sprintf (buffer, "%s grid", name);
  grid_obj = SUIT_createOnOffSwitch (buffer, change_grid);
  SUIT_setBoolean (grid_obj, SHRINK_TO_FIT, FALSE);
  SUIT_setText (grid_obj, LABEL, "Grid");
  SUIT_setEnumString (grid_obj, BORDER_TYPE, "fancy motif");

  SUIT_setObject (grid_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (grid_obj, AUTOMATON, OBJECT);

  SUIT_setBoolean (grid_obj, CURRENT_VALUE, TRUE);
  SUIT_makePropertyTemporary (grid_obj, CURRENT_VALUE, OBJECT);

  /* ----------------------------------------------------------------	*/
  /*                    add a  step toggle switch			*/
  /* ----------------------------------------------------------------	*/
  sprintf (buffer, "%s step", name);
  step_obj = SUIT_createOnOffSwitch (buffer, change_step);
  SUIT_setBoolean (step_obj, SHRINK_TO_FIT, FALSE);
  SUIT_setText (step_obj, LABEL, "Step");
  SUIT_setEnumString (step_obj, BORDER_TYPE, "fancy motif");

  SUIT_setObject (step_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (step_obj, AUTOMATON, OBJECT);

  SUIT_setBoolean (step_obj, CURRENT_VALUE, FALSE);
  SUIT_makePropertyTemporary (step_obj, CURRENT_VALUE, OBJECT);

  /* ----------------------------------------------------------------	*/
  /*			add save and load buttons			*/
  /* ----------------------------------------------------------------	*/
  sprintf (buffer, "%s menu", name);
  file_obj = SUIT_createPullDownMenu (buffer);
  SUIT_setText (file_obj, LABEL, "File..");
  SUIT_setBoolean (file_obj, SHRINK_TO_FIT, FALSE);
  SUIT_setEnumString (file_obj, BORDER_TYPE, "fancy motif");

  sprintf (buffer, "%s load", name);
  load_obj = SUIT_addToMenu (file_obj, buffer, load_auto);
  SUIT_setText (load_obj, LABEL, "LOAD");
  SUIT_setEnumString (load_obj, BORDER_TYPE, "fancy motif");
  SUIT_setObject (load_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (load_obj, AUTOMATON, OBJECT);

  sprintf (buffer, "%s save", name);
  save_obj = SUIT_addToMenu (file_obj, buffer, save_auto);
  SUIT_setText (save_obj, LABEL, "SAVE");
  SUIT_setEnumString (save_obj, BORDER_TYPE, "fancy motif");
  SUIT_setObject (save_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (save_obj, AUTOMATON, OBJECT);

  /* ----------------------------------------------------------------	*/
  /*			add a clear button				*/
  /* ----------------------------------------------------------------	*/
  sprintf (buffer, "%s clear", name);
  clear_obj = SUIT_createButton (buffer, clear_auto);
  SUIT_setText (clear_obj, LABEL, "clear");
  SUIT_setBoolean (clear_obj, SHRINK_TO_FIT, FALSE);
  SUIT_setEnumString (clear_obj, BORDER_TYPE, "fancy motif");

  SUIT_setObject (clear_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (clear_obj, AUTOMATON, OBJECT);


  /* ----------------------------------------------------------------	*/
  /*   		 	add a colorbar widget				*/
  /* ----------------------------------------------------------------	*/
  color_obj = CreateColorbarWidget ("colorbar");
  SUIT_setInteger (color_obj, CSTATES, states);
  SUIT_makePropertyTemporary (color_obj, CSTATES, OBJECT);

  /* ----------------------------------------------------------------	*/
  /* 			add a method widget				*/
  /* ----------------------------------------------------------------	*/
  sprintf (buffer, "%s method", name);
  method_obj = SUIT_createScrollableList (buffer, do_method);

  method_list = SUIT_getTextList (method_obj, "LIST");

  /*
     spaces are placed infromt of the names as there seems to be a bug in
     SUIT with bulletin boards . remember to trim the name when using
  */

  current_rule = rule_array;
  while (current_rule->name)
  {
    char buffer[30];

    sprintf (buffer, "    %s", current_rule->name);
    printf("Adding method %s\n",buffer);

    SUIT_appendToTextList (method_list, buffer);
    current_rule++;
  }

  SUIT_setTextList (method_obj, "LIST", method_list);

  SUIT_setObject (method_obj, AUTOMATON, obj);
  SUIT_makePropertyTemporary (method_obj, AUTOMATON, OBJECT);
  SUIT_setBoolean (method_obj, HAS_BACKGROUND, TRUE);
  SUIT_setText (method_obj, LABEL, "Rules");
  SUIT_makePropertyTemporary (method_obj, LIST, OBJECT);

  /* ---------------------------------------------------------------- */
  /* 		keep a track of type-in, colorbar object              */
  /* ---------------------------------------------------------------- */
  SUIT_setObject (obj, STATEOBJ, states_obj);
  SUIT_makePropertyTemporary (obj, STATEOBJ, OBJECT);

  SUIT_setObject (obj, ROWSOBJ, rows_obj);
  SUIT_makePropertyTemporary (obj, ROWSOBJ, OBJECT);

  SUIT_setObject (obj, COLSOBJ, cols_obj);
  SUIT_makePropertyTemporary (obj, COLSOBJ, OBJECT);

  SUIT_setObject (states_obj, COLOROBJ, color_obj);
  SUIT_makePropertyTemporary (states_obj, COLOROBJ, OBJECT);

  /* ----------------------------------------------------------------	*/
  /* 			stick objects together				*/
  /* ----------------------------------------------------------------	*/
  SUIT_addChildToObject (board, obj);
  SUIT_addChildToObject (board, rows_label);
  SUIT_addChildToObject (board, cols_label);
  SUIT_addChildToObject (board, states_label);
  SUIT_addChildToObject (board, rows_obj);
  SUIT_addChildToObject (board, cols_obj);
  SUIT_addChildToObject (board, states_obj);
  SUIT_addChildToObject (board, grid_obj);
  SUIT_addChildToObject (board, step_obj);
  SUIT_addChildToObject (board, file_obj);
  SUIT_addChildToObject (board, color_obj);
  SUIT_addChildToObject (board, clear_obj);
  SUIT_addChildToObject (board, method_obj);

  /* ----------------------------------------------------------------	*/
  /*  		position the objects				*/
  /* ----------------------------------------------------------------	*/

  setchildsize (obj, 0.15, 0.11, 1.0, 1.0);

  setchildsize (step_obj,  0.0, 0.91, 0.14, 0.96);
  setchildsize (grid_obj,  0.0, 0.85, 0.14, 0.9);
  setchildsize (clear_obj, 0.0, 0.77, 0.14, 0.82);
  setchildsize (file_obj,  0.0, 0.69, 0.14, 0.74);

  setchildsize (method_obj, 0.0, 0.11, 0.14, 0.65);

#define BOX_BOTTOM 0.00
#define BOX_TOP    0.075

  setchildsize (rows_label, 0.15, BOX_BOTTOM, 0.20, BOX_TOP);
  setchildsize (rows_obj, 0.21, BOX_BOTTOM, 0.26, BOX_TOP);

  setchildsize (cols_label, 0.28, BOX_BOTTOM, 0.33, BOX_TOP);
  setchildsize (cols_obj, 0.34, BOX_BOTTOM, 0.39, BOX_TOP);

  setchildsize (states_label, 0.41, BOX_BOTTOM, 0.47, BOX_TOP);
  setchildsize (states_obj, 0.48, BOX_BOTTOM, 0.53, BOX_TOP);

  setchildsize (color_obj, 0.55, BOX_BOTTOM, 1.0, BOX_TOP);

  n_autos++;
  return (board);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	HitAutomataWidget				*/
/* 									*/
/* Description:		This determines what happens when a mouse event */
/*			on the graphics window				*/
/* 									*/
/* Date of creation:	29-01-93					*/
/* 									*/
/* input arguments:	obj		the object which was hit	*/
/*			ev		the mouse event			*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void
  HitAutomataWidget (SUIT_object obj, SUIT_event ev)
{
  int number, grid;
  double x, y;
  int row, col, states, item;
  automaton *automata;

  /* ----------------------------------------------------------------	*/
  /*		always update the x/y/coordinates			*/
  /* ----------------------------------------------------------------	*/

  x = ev.worldLocation.x;
  y = ev.worldLocation.y;
  rows = SUIT_getInteger (obj, ROWS);
  cols = SUIT_getInteger (obj, COLUMNS);
  states = SUIT_getInteger (obj, STATES);
  number = SUIT_getInteger (obj, NUMBER);
  grid = SUIT_getBoolean (obj, GRID);

  automata = auto_arr[number];

  GP_setWindow (SUIT_getWindow (obj, WINDOW));

  /* ----------------------------------------------------------------	*/
  /* ----------------------------------------------------------------	*/
  row = floor (y * rows);
  col = floor (x * cols);

  if (col < 0)
    col = 0;
  if (col >= cols)
    col = cols - 1;

  if (row < 0)
    row = 0;
  if (row >= rows)
    row = rows - 1;

  item = get_item (row, col);

  switch (ev.type)
  {
  case CLICK:
  case MOUSE_DOWN:
  case MOUSE_MOTION:
  case MOUSE_UP:
    if (automata[item].state < states)
    {
      automata[item].state++;
      automata[item].changed = TRUE;
    }
    PaintAutomatonSquare (automata, row, col, grid);
    PaintAutomatonGrid (obj);
    break;

  case KEYSTROKE:
    if (automata[item].state > 0)
    {
      automata[item].state--;
      automata[item].changed = TRUE;
    }
    PaintAutomatonSquare (automata, row, col, grid);
    PaintAutomatonGrid (obj);
    break;

  default:
    break;
  }
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void PaintAutomatonSquare
  (automaton * automata, int row, int col, int grid)
{
  int item;
  GP_point bottom_left, top_right;


  item = get_item (row, col);

  /* if ((automata[item].state > 0) || (automata[item].changed == TRUE)) */
  if (automata[item].changed == TRUE)
  {

    bottom_left.x = (double) col *x_step;
    bottom_left.y = (double) row *y_step;

    top_right.x = bottom_left.x + x_step;
    top_right.y = bottom_left.y + y_step;

    set_gray (automata[item].state);
    GP_fillRectanglePt (bottom_left, top_right);

    automata[item].changed = FALSE;
  }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name: 	PaintAutomataWidget				*/
/* 									*/
/* Description:		draw the contents of widget			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	obj	object to redraw			*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void
  PaintAutomataWidget (SUIT_object obj)
{
  int row, col, number, grid;
  automaton *automata;

  GP_setWindow (SUIT_getWindow (obj, WINDOW));

  rows = SUIT_getInteger (obj, ROWS);
  cols = SUIT_getInteger (obj, COLUMNS);
  number = SUIT_getInteger (obj, NUMBER);
  grid = SUIT_getBoolean (obj, GRID);

  automata = auto_arr[number];

  y_step = 1.0 / (double) rows;
  x_step = 1.0 / (double) cols;


  /* ----------------------------------------------------------------	*/
  /* ----------------------------------------------------------------	*/

  for (row = 0; row < rows; row++)
    for (col = 0; col < cols; col++)
      PaintAutomatonSquare (automata, row, col, grid);

  PaintAutomatonGrid (obj);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void
  InitAutomaton (automaton * automata)
{
  int row, col, item;

  for (row = 0; row < rows; row++)
    for (col = 0; col < cols; col++)
    {
      item = get_item (row, col);

      automata[item].timer = 0;
      automata[item].state = 0;
      automata[item].tmp = 0;
      automata[item].changed = TRUE;
      automata[item].checked = FALSE;
    }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void
  PaintAutomatonGrid (SUIT_object auto_obj)
{
  int row, col;
  int grid, changed;
  double x_step, y_step, x, y;

  grid = SUIT_getBoolean (auto_obj, GRID);
  changed = SUIT_getBoolean (auto_obj, GRID_CHANGED);

  set_colour ("yellow");

  if (changed || grid)
  {
    if (changed)
    {
      if (!grid)
	set_colour ("gray");
      SUIT_setBoolean (auto_obj, GRID_CHANGED, FALSE);
    }

    rows = SUIT_getInteger (auto_obj, ROWS);
    cols = SUIT_getInteger (auto_obj, COLUMNS);

    y_step = 1.0 / (double) rows;
    x_step = 1.0 / (double) cols;

    y = y_step;
    for (row = 0; row < rows; row++)
    {
      GP_lineCoord (0.0, y, 1.0, y);
      y += y_step;
    }

    x = x_step;
    for (col = 0; col < cols; col++)
    {
      GP_lineCoord (x, 0.0, x, 1.0);
      x += x_step;
    }
  }
}
