#ifndef _AUTOMATA_COLORBAR
#  define _AUTOMATA_COLORBAR

SUIT_object CreateColorbarWidget (char *name);

#  define CSTATES "color_states"

#endif
