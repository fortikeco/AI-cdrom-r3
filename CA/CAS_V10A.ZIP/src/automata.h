#ifndef _AUTOMATA_AUTOMATA
#  define _AUTOMATA_AUTOMATA

SUIT_object CreateAutomataWidget (char *name);

#  define ROWS	 "auto_rows"
#  define COLUMNS "auto_cols"
#  define STATES "auto_states"
#  define ARRAY "auto_array"
#  define NUMBER "auto_number"
#  define GRID "auto_grid"
#  define GRID_CHANGED "auto_grid_changed"
#  define STEP "auto_step"

#  define STATEOBJ "auto_state_obj"
#  define ROWSOBJ "auto_rows_obj"
#  define COLSOBJ "auto_cols_obj"
#  define COLOROBJ "auto_color_obj"

#  define AUTOMATON "automaton"

#  define DEFAULT_ROWS	 30
#  define DEFAULT_COLS	 30
#  define DEFAULT_STATES 2

#  define MAX_AUTOMATA   12
#  define MAX_ROWS	 100
#  define MAX_COLS	 100
#  define MAX_STATES     MAX_COLORS

#define setchildsize(obj, x1,y1,x2,y2) \
   SUIT_setViewport(obj,VIEWPORT,SUIT_mapToParent(obj,x1,y1,x2,y2))

typedef struct _automaton
{
  int timer;
  int state;
  int tmp;
  int changed;
  int checked;
}

automaton;

extern int n_autos;
extern automaton *auto_arr[MAX_AUTOMATA];
extern int rows;
extern int cols;


void InitAutomaton (automaton * automata);


#endif
