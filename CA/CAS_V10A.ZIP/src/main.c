#include "auto.h"


/************************************************************************/
/*				GLOBALS					*/
/************************************************************************/
SUIT_object auto_obj;



/************************************************************************/
/*			PRIVATE FUNCTIONS				*/
/************************************************************************/

void main (int argc, char *argv[]);
void setup_interface (void);



/************************************************************************/
/*			THE FUNCTIONS					*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	main						*/
/*									*/
/* Description:		starts the whole process			*/
/*									*/
/* Date of creation:	29-01-93					*/
/*									*/
/* input arguments:	None						*/
/*									*/
/* output:		None						*/
/*									*/
/* function return:	void						*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void main (int argc, char *argv[])
{
#  ifdef INSTALL
  SUIT_initFromCode (argv[0]);
#  else
  SUIT_init (argv[0]);
#  endif

  setup_interface ();
  GNU_thing ();
  SUIT_beginStandardApplication ();
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:	setup_interface					*/
/*									*/
/* Description:		creates SUIT objects needed for application	*/
/*									*/
/* Date of creation:	29-01-93					*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void setup_interface ()
{
  SUIT_object title, automat, done_obj;

  /* ----------------------------------------------------------------- */

  title = SUIT_createLabel ("Cellular Automata Simulator");
  setfont (title, "new century schoolbook", "bolditalic", 24.0);
  setchildsize (title, 0.0, 0.92, 0.8, 1.0);

  /* ----------------------------------------------------------------- */
  automat = auto_obj = CreateAutomataWidget ("graphics");
  setchildsize (automat, 0.12, 0.0, 1.0, 0.90);

  /* ----------------------------------------------------------------- */
  done_obj = SUIT_createDoneButton(NULL);
  SUIT_setText (done_obj, LABEL, "EXIT");
  SUIT_setBoolean (done_obj, SHRINK_TO_FIT, FALSE);
  setchildsize (done_obj, 0.0, 0.00, 0.10, 0.10);


}
