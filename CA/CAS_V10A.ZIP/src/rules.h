#ifndef _AUTOMATA_RULES
#define _AUTOMATA_RULES


typedef struct _rule
{
  char *name;
  void (*callback) (automaton *, int, int, int); 
} rule;

typedef union _bits
{
  struct field
  {
    int n:1;
    int ne:1;
    int e:1;
    int se:1;
    int s:1;
    int sw:1;
    int w:1;
    int nw:1;
  };
  int result;
}bit;

#  define BIRTH 1
#  define DEAD 0
#  define SURVIVE 2
#  define SEED 2
#  define ALERT 5

#  define WORM_THRESHHOLD 4

void anneal (automaton * automata, int row, int col, int item);
void brian_brain (automaton * automata, int row, int col, int item);
void codd (automaton * automata, int row, int col, int item);
void diamonds (automaton * automata, int row, int col, int item);
void fill4 (automaton * automata, int row, int col, int item);
void fill8 (automaton * automata, int row, int col, int item);
void gravity (automaton * automata, int row, int col, int item);
void growth (automaton * automata, int row, int col, int item);
void hglass (automaton * automata, int row, int col, int item);
void lichens (automaton * automata, int row, int col, int item);
void life (automaton * automata, int row, int col, int item);
void majority (automaton * automata, int row, int col, int item);
void parity (automaton * automata, int row, int col, int item);
void squares (automaton * automata, int row, int col, int item);
void triangles (automaton * automata, int row, int col, int item);
void tube_worm (automaton * automata, int row, int col, int item);
void tube_worm2 (automaton * automata, int row, int col, int item);

extern rule rule_array[];

#endif
