#ifndef __AUTOMATA_METHODS
#  define __AUTOMATA_METHODS


# define METHOD_NOTIMPL -999
# define IMPLEMENTED 0

typedef enum
{
  ANNEAL, BRIANS_BRAIN, CODD, DIAMONDS_2, DIAMONDS, GRAVITY, GROWTH, HGLASS, \
  LICHENS, LIFE, MAJORITY, PARITY, SQUARES, TRIANGLES, TUBE_WORM, VON_NEUMANN
} methods;

typedef void(*fn_ptr)();

int step_method (fn_ptr callback, automaton * automata, int rows, int cols);
int update_changed (automaton * automata);


#endif
