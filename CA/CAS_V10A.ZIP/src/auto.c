/* SUIT version 2.3 */

#define THE_SCREEN_WIDTH 960
#define THE_SCREEN_HEIGHT 600
#define THE_SCREEN_DEPTH 7

#include "suit.h"


/*--------------------------------------------------------------------------------*/
/*                                                                                */
/*                                  NOTE:                                         */
/*                                                                                */
/*    This file contains all the permanent properties of this application's       */
/*    objects and is read in as a data file.  Compiling this file as part of      */
/*    your application "hard codes" your interface.  Please see "shipping"        */
/*    in the SUIT reference manual for further information.                       */
/*                                                                                */
/*                                                                                */
/*                              !! DANGER !!                                      */
/*                                                                                */
/*      This file is machine-generated, and its contents are very important.      */
/*                                                                                */
/*          If you must edit this file, do so with extreme caution!               */
/*                                                                                */
/*                              !! DANGER !!                                      */
/*                                                                                */
/*--------------------------------------------------------------------------------*/


extern void SUIT_interiorInitFromCode (char *programName, SUIT_functionPointer suiRoutine,
                                       int width, int height, int depth);

extern SUIT_type *si_getType(char *typeName);

extern void si_addChildToObject(SUIT_object, SUIT_object, boolean);

static void MAKE (char *name, char *class, char *parent, boolean interactive) 
{ 
    SUIT_object o = SUIT_name(name); 
    SUIT_object p = SUIT_name(parent); 
    if (p != NULL) {
        if (o == NULL) 
            o = SUIT_createObjectByClass(name, class); 
    	if (interactive) {
    	    SUIT_setBoolean (o, INTERACTIVELY_CREATED, TRUE);
    	    SUIT_makePropertyTemporary (o, INTERACTIVELY_CREATED, OBJECT);
    	}
        si_addChildToObject(SUIT_name(parent), o, FALSE); 
    }
} 
 


static void SET (char *objOrClass, char *propertyName, char *propertyType, boolean atClass,
                 boolean locked, char *stringValue) 
{ 
    SUIT_type	*type; 
    boolean	errorStatus; 
    Pointer	retval; 
    SUIT_level level = OBJECT; 
    SUIT_object o; 
     
    if (atClass) 
        level = CLASS; 
    if (level == CLASS) 
        o = SUIT_dummyObjectInClass(objOrClass); 
    else 
        o = SUIT_name(objOrClass); 
    type = si_getType(propertyType); 
    retval = type->convertFromAscii(stringValue, &errorStatus); 
    if (errorStatus == FALSE) 
	SUIT_setProperty(o, propertyName, propertyType, retval, level); 

    if (locked) 
        SUIT_lockProperty(o, propertyName, level); 
}


static void INIT_suiRoutine(void)
{
/* This line is for parsing simplicity -- do NOT remove it!  @ */
MAKE("Done","button","ROOT",0);
MAKE("graphics menu: menu","menu","ROOT",0);
MAKE("graphics load","button","graphics menu: menu",0);
MAKE("graphics save","button","graphics menu: menu",0);
MAKE("graphics board","bulletin board","ROOT",0);
MAKE("graphics","Automata class","graphics board",0);
MAKE("graphics rlabel","label","graphics board",0);
MAKE("graphics clabel","label","graphics board",0);
MAKE("graphics slabel","label","graphics board",0);
MAKE("graphics rtype","type in box","graphics board",0);
MAKE("graphics ctype","type in box","graphics board",0);
MAKE("graphics stype","type in box","graphics board",0);
MAKE("graphics grid","on/off switch","graphics board",0);
MAKE("graphics step","on/off switch","graphics board",0);
MAKE("graphics menu","pulldown menu","graphics board",0);
MAKE("colorbar","Colorbar class","graphics board",0);
MAKE("graphics clear","button","graphics board",0);
MAKE("graphics method","scrollable list","graphics board",0);
MAKE("graphics method: scrollbar","bounded value","graphics method",0);
MAKE("graphics method: list","list","graphics method",0);
MAKE("Cellular Automata Simulator","label","ROOT",0);
SET("arrow button","border raised","boolean",1,0,"no");
SET("arrow button","changed class","boolean",1,0,"no");
SET("arrow button","darken background","boolean",1,0,"yes");
SET("arrow button","direction","SUIT_enum",1,0,"\"up\" of {\"up\" \"down\" \"left\" \"right\"}");
SET("arrow button","draw filled","boolean",1,0,"no");
SET("arrow button","has background","boolean",1,0,"no");
SET("arrow button","intermediate feedback","boolean",1,0,"no");
SET("arrow button","shadow thickness","int",1,0,"3");
SET("Automata class","auto_grid_changed","boolean",1,0,"no");
SET("Automata class","auto_step","boolean",1,0,"no");
SET("Automata class","changed class","boolean",1,0,"no");
SET("Automata class","interactively created","boolean",1,0,"no");
SET("bounded value","arrowhead angle","int",1,0,"10");
SET("bounded value","arrowhead length","double",1,0,"0.200000");
SET("bounded value","button background color","GP_color",1,0,"black, black");
SET("bounded value","button foreground color","GP_color",1,0,"grey, white");
SET("bounded value","changed class","boolean",1,0,"no");
SET("bounded value","current value","double",1,0,"0.000000");
SET("bounded value","granularity","double",1,0,"0.000000");
SET("bounded value","has arrow","boolean",1,0,"yes");
SET("bounded value","has tick marks","boolean",1,0,"yes");
SET("bounded value","increase clockwise","boolean",1,0,"yes");
SET("bounded value","interactively created","boolean",1,0,"no");
SET("bounded value","minimum value","double",1,0,"0.000000");
SET("bounded value","needle color","GP_color",1,0,"black, black");
SET("bounded value","start angle","double",1,0,"0.000000");
SET("bulletin board","border raised","boolean",1,0,"no");
SET("bulletin board","changed class","boolean",1,0,"no");
SET("bulletin board","interactively created","boolean",1,0,"no");
SET("button","changed class","boolean",1,0,"no");
SET("button","disabled color","GP_color",1,0,"white, white");
SET("button","hotkey","text",1,0,"");
SET("button","interactively created","boolean",1,0,"no");
SET("button","justification","SUIT_enum",1,0,"\"center\" of {\"left\" \"center\" \"right\"}");
SET("button","shrink to fit","boolean",1,0,"yes");
SET("Colorbar class","changed class","boolean",1,0,"no");
SET("Colorbar class","interactively created","boolean",1,0,"no");
SET("elevator","border raised","boolean",1,0,"no");
SET("elevator","changed class","boolean",1,0,"no");
SET("elevator","has background","boolean",1,0,"no");
SET("elevator","offset","double",1,0,"0.000000");
SET("label","changed class","boolean",1,0,"no");
SET("label","has border","boolean",1,0,"no");
SET("label","interactively created","boolean",1,0,"no");
SET("label","justification","SUIT_enum",1,0,"\"center\" of {\"left\" \"center\" \"right\"}");
SET("label","shrink to fit","boolean",1,0,"yes");
SET("list","border raised","boolean",1,0,"no");
SET("list","changed class","boolean",1,0,"no");
SET("list","interactively created","boolean",1,0,"no");
SET("list","text spacing","double",1,0,"1.200000");
SET("menu","cache using canvas","boolean",1,0,"yes");
SET("menu","changed class","boolean",1,0,"no");
SET("menu","interactively created","boolean",1,0,"no");
SET("on/off switch","changed class","boolean",1,0,"no");
SET("on/off switch","disabled color","GP_color",1,0,"white, white");
SET("on/off switch","interactively created","boolean",1,0,"no");
SET("on/off switch","shrink to fit","boolean",1,0,"yes");
SET("pulldown menu","changed class","boolean",1,0,"no");
SET("pulldown menu","interactively created","boolean",1,0,"no");
SET("scrollable list","border raised","boolean",1,0,"no");
SET("scrollable list","changed class","boolean",1,0,"no");
SET("scrollable list","has background","boolean",1,0,"no");
SET("scrollable list","has border","boolean",1,0,"no");
SET("scrollable list","interactively created","boolean",1,0,"no");
SET("type in box","any keystroke triggers","boolean",1,0,"no");
SET("type in box","backward char key","text",1,0,"C-b");
SET("type in box","beginning of line key","text",1,0,"C-a");
SET("type in box","beginning of text key","text",1,0,"M-<");
SET("type in box","border raised","boolean",1,0,"no");
SET("type in box","changed class","boolean",1,0,"no");
SET("type in box","cursor color","GP_color",1,0,"black, black");
SET("type in box","cursor index","int",1,0,"0");
SET("type in box","cursor style","SUIT_enum",1,0,"\"vertical bar\" of {\"i-beam\" \"vertical bar\"}");
SET("type in box","delete char key","text",1,0,"C-d");
SET("type in box","delete entire line key","text",1,0,"C-u");
SET("type in box","done editing key","text",1,0,"C-x");
SET("type in box","double click time","double",1,0,"400000.000000");
SET("type in box","end of line key","text",1,0,"C-e");
SET("type in box","end of text key","text",1,0,"M->");
SET("type in box","forward char key","text",1,0,"C-f");
SET("type in box","has a tab","boolean",1,0,"no");
SET("type in box","interactively created","boolean",1,0,"no");
SET("type in box","kill line key","text",1,0,"C-k");
SET("type in box","last mark index","int",1,0,"0");
SET("type in box","mark end index","int",1,0,"0");
SET("type in box","mark index","int",1,0,"0");
SET("type in box","newline key","text",1,0,"C-m");
SET("type in box","next line key","text",1,0,"C-n");
SET("type in box","open line key","text",1,0,"C-o");
SET("type in box","pre cursor index","int",1,0,"0");
SET("type in box","previous line key","text",1,0,"C-p");
SET("type in box","repaint key","text",1,0,"C-l");
SET("type in box","scroll down key","text",1,0,"M-v");
SET("type in box","scroll up key","text",1,0,"C-v");
SET("type in box","set mark key","text",1,0,"C-`");
SET("type in box","shrink to fit","boolean",1,0,"yes");
SET("type in box","spacing gap","int",1,0,"3");
SET("type in box","start x","int",1,0,"0");
SET("type in box","start y","double",1,0,"0.000000");
SET("type in box","tab key","text",1,0,"C-i");
SET("type in box","tab length","int",1,0,"5");
SET("type in box","wipe block key","text",1,0,"C-w");
SET("type in box","yank key","text",1,0,"C-y");
SET("ROOT","animated","boolean",0,0,"no");
SET("ROOT","background color","GP_color",0,0,"grey, white");
SET("ROOT","border color","GP_color",0,0,"grey, black");
SET("ROOT","border raised","boolean",0,0,"yes");
SET("ROOT","border type","SUIT_enum",0,0,"\"motif\" of {\"simple\" \"motif\" \"fancy motif\"}");
SET("ROOT","border width","int",0,0,"2");
SET("ROOT","changed class","boolean",0,0,"no");
SET("ROOT","clip to viewport","boolean",0,0,"yes");
SET("ROOT","default object height","int",0,0,"80");
SET("ROOT","default object width","int",0,0,"80");
SET("ROOT","draw border on inside","boolean",0,0,"no");
SET("ROOT","font","GP_font",0,0,"times,,12.000000");
SET("ROOT","foreground color","GP_color",0,0,"black, black");
SET("ROOT","has background","boolean",0,0,"yes");
SET("ROOT","has border","boolean",0,0,"yes");
SET("ROOT","margin","int",0,0,"5");
SET("ROOT","show temporary properties","boolean",0,0,"no");
SET("ROOT","shrink to fit","boolean",0,0,"no");
SET("ROOT","springiness","SUIT_springiness",0,0,"63");
SET("ROOT","SUIT system font","GP_font",0,0,"helvetica,,14.000000");
SET("ROOT","viewport","viewport",0,1,"0 0 959 599");
SET("ROOT","visible","boolean",0,0,"yes");
SET("ROOT","window","window",0,1,"0.000000 0.000000 1.000000 1.000000");
SET("Done","active display","SUIT_enum",0,0,"\"standard\" of {\"button with hotkey\" \"standard\"}");
SET("Done","border raised","boolean",0,0,"yes");
SET("Done","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("Done","disabled","boolean",0,0,"no");
SET("Done","done callback function","SUIT_functionPointer",0,0,"function ptr");
SET("Done","has background","boolean",0,0,"yes");
SET("Done","label","text",0,0,"EXIT");
SET("Done","shrink to fit","boolean",0,0,"no");
SET("Done","viewport","viewport",0,0,"2 2 97 61");
SET("graphics menu: menu","active display","SUIT_enum",0,0,"\"vertical\" of {\"vertical\"}");
SET("graphics menu: menu","stuck down","boolean",0,0,"no");
SET("graphics menu: menu","viewport","viewport",0,0,"471 344 524 401");
SET("graphics menu: menu","visible","boolean",0,0,"no");
SET("graphics load","active display","SUIT_enum",0,0,"\"standard\" of {\"button with hotkey\" \"standard\"}");
SET("graphics load","border type","SUIT_enum",0,0,"\"fancy motif\" of {\"simple\" \"motif\" \"fancy motif\"}");
SET("graphics load","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics load","disabled","boolean",0,0,"no");
SET("graphics load","has border","boolean",0,0,"no");
SET("graphics load","label","text",0,0,"LOAD");
SET("graphics load","shrink to fit","boolean",0,0,"no");
SET("graphics load","viewport","viewport",0,0,"4 30 49 55");
SET("graphics save","active display","SUIT_enum",0,0,"\"standard\" of {\"button with hotkey\" \"standard\"}");
SET("graphics save","border type","SUIT_enum",0,0,"\"fancy motif\" of {\"simple\" \"motif\" \"fancy motif\"}");
SET("graphics save","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics save","disabled","boolean",0,0,"no");
SET("graphics save","has border","boolean",0,0,"no");
SET("graphics save","label","text",0,0,"SAVE");
SET("graphics save","shrink to fit","boolean",0,0,"no");
SET("graphics save","viewport","viewport",0,0,"4 2 49 26");
SET("graphics board","active display","SUIT_enum",0,0,"\"bulletin board\" of {\"bulletin board\"}");
SET("graphics board","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics board","viewport","viewport",0,0,"116 2 957 537");
SET("graphics","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics","auto_grid_changed","boolean",0,0,"no");
SET("graphics","has background","boolean",0,0,"no");
SET("graphics","viewport","viewport",0,0,"137 67 820 522");
SET("graphics rlabel","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics rlabel","label","text",0,0,"rows");
SET("graphics rlabel","viewport","viewport",0,0,"145 21 180 45");
SET("graphics clabel","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics clabel","label","text",0,0,"cols");
SET("graphics clabel","viewport","viewport",0,0,"248 21 278 45");
SET("graphics slabel","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics slabel","label","text",0,0,"states");
SET("graphics slabel","viewport","viewport",0,0,"347 21 389 45");
SET("graphics rtype","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics rtype","altered","boolean",0,0,"no");
SET("graphics rtype","calculate lines","boolean",0,0,"no");
SET("graphics rtype","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics rtype","cursor x","int",0,0,"5");
SET("graphics rtype","cursor y","int",0,0,"8");
SET("graphics rtype","has a tab","boolean",0,0,"no");
SET("graphics rtype","highlight block","boolean",0,0,"no");
SET("graphics rtype","last mark index","int",0,0,"0");
SET("graphics rtype","number of lines","int",0,0,"1");
SET("graphics rtype","paint block only","boolean",0,0,"no");
SET("graphics rtype","pre cursor index","int",0,0,"-1");
SET("graphics rtype","read only","boolean",0,0,"no");
SET("graphics rtype","start x","int",0,0,"5");
SET("graphics rtype","start y","double",0,0,"19.000000");
SET("graphics rtype","viewport","viewport",0,0,"179 21 221 45");
SET("graphics ctype","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics ctype","altered","boolean",0,0,"no");
SET("graphics ctype","calculate lines","boolean",0,0,"no");
SET("graphics ctype","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics ctype","cursor x","int",0,0,"5");
SET("graphics ctype","cursor y","int",0,0,"8");
SET("graphics ctype","has a tab","boolean",0,0,"no");
SET("graphics ctype","highlight block","boolean",0,0,"no");
SET("graphics ctype","last mark index","int",0,0,"0");
SET("graphics ctype","number of lines","int",0,0,"1");
SET("graphics ctype","paint block only","boolean",0,0,"no");
SET("graphics ctype","read only","boolean",0,0,"no");
SET("graphics ctype","start x","int",0,0,"5");
SET("graphics ctype","start y","double",0,0,"19.000000");
SET("graphics ctype","viewport","viewport",0,0,"284 21 326 45");
SET("graphics stype","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics stype","altered","boolean",0,0,"no");
SET("graphics stype","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics stype","cut buffer","text",0,0,"");
SET("graphics stype","has a tab","boolean",0,0,"no");
SET("graphics stype","number of lines","int",0,0,"1");
SET("graphics stype","paint block only","boolean",0,0,"no");
SET("graphics stype","read only","boolean",0,0,"no");
SET("graphics stype","viewport","viewport",0,0,"400 21 441 45");
SET("graphics grid","active display","SUIT_enum",0,0,"\"motif square\" of {\"dot in circle\" \"check box\" \"motif diamond\" \"motif square\"}");
SET("graphics grid","border type","SUIT_enum",0,0,"\"fancy motif\" of {\"simple\" \"motif\" \"fancy motif\"}");
SET("graphics grid","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics grid","disabled","boolean",0,0,"no");
SET("graphics grid","label","text",0,0,"Grid");
SET("graphics grid","shrink to fit","boolean",0,0,"no");
SET("graphics grid","viewport","viewport",0,0,"21 441 126 468");
SET("graphics step","active display","SUIT_enum",0,0,"\"motif square\" of {\"dot in circle\" \"check box\" \"motif diamond\" \"motif square\"}");
SET("graphics step","border type","SUIT_enum",0,0,"\"fancy motif\" of {\"simple\" \"motif\" \"fancy motif\"}");
SET("graphics step","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics step","disabled","boolean",0,0,"no");
SET("graphics step","label","text",0,0,"Step");
SET("graphics step","shrink to fit","boolean",0,0,"no");
SET("graphics step","viewport","viewport",0,0,"21 475 126 495");
SET("graphics menu","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics menu","border type","SUIT_enum",0,0,"\"fancy motif\" of {\"simple\" \"motif\" \"fancy motif\"}");
SET("graphics menu","has border","boolean",0,0,"yes");
SET("graphics menu","label","text",0,0,"File..");
SET("graphics menu","shrink to fit","boolean",0,0,"no");
SET("graphics menu","viewport","viewport",0,0,"21 361 126 388");
SET("colorbar","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("colorbar","viewport","viewport",0,0,"452 13 820 47");
SET("graphics clear","active display","SUIT_enum",0,0,"\"standard\" of {\"button with hotkey\" \"standard\"}");
SET("graphics clear","border raised","boolean",0,0,"yes");
SET("graphics clear","border type","SUIT_enum",0,0,"\"fancy motif\" of {\"simple\" \"motif\" \"fancy motif\"}");
SET("graphics clear","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics clear","disabled","boolean",0,0,"no");
SET("graphics clear","has background","boolean",0,0,"yes");
SET("graphics clear","label","text",0,0,"clear");
SET("graphics clear","shrink to fit","boolean",0,0,"no");
SET("graphics clear","viewport","viewport",0,0,"21 408 126 435");
SET("graphics method","active display","SUIT_enum",0,0,"\"bulletin board\" of {\"bulletin board\"}");
SET("graphics method","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics method","current row","int",0,0,"3");
SET("graphics method","current value","text",0,0,"    Diamonds");
SET("graphics method","has background","boolean",0,0,"yes");
SET("graphics method","label","text",0,0,"Rules");
SET("graphics method","viewport","viewport",0,0,"21 67 126 341");
SET("graphics method: scrollbar","active display","SUIT_enum",0,0,"\"scroll bar\" of {\"scroll bar\" \"vertical thermometer\" \"horizontal thermometer\" \"pie slice\" \"speedometer\"}");
SET("graphics method: scrollbar","border raised","boolean",0,0,"no");
SET("graphics method: scrollbar","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics method: scrollbar","current value","double",0,0,"2.000000");
SET("graphics method: scrollbar","granularity","double",0,0,"1.000000");
SET("graphics method: scrollbar","maximum value","double",0,0,"2.000000");
SET("graphics method: scrollbar","minimum value","double",0,0,"0.000000");
SET("graphics method: scrollbar","percent full","double",0,0,"0.882353");
SET("graphics method: scrollbar","springiness","SUIT_springiness",0,0,"17");
SET("graphics method: scrollbar","viewport","viewport",0,0,"91 2 103 272");
SET("graphics method: scrollbar: first arrow","active display","SUIT_enum",0,0,"\"motif\" of {\"simple arrow\" \"motif\"}");
SET("graphics method: scrollbar: first arrow","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics method: scrollbar: first arrow","direction","SUIT_enum",0,0,"\"up\" of {\"up\" \"down\" \"left\" \"right\"}");
SET("graphics method: scrollbar: first arrow","has border","boolean",0,0,"no");
SET("graphics method: scrollbar: first arrow","viewport","viewport",0,0,"0 258 12 270");
SET("graphics method: scrollbar: elevator","active display","SUIT_enum",0,0,"\"motif\" of {\"motif\"}");
SET("graphics method: scrollbar: elevator","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics method: scrollbar: elevator","current value","double",0,0,"1.000000");
SET("graphics method: scrollbar: elevator","has border","boolean",0,0,"no");
SET("graphics method: scrollbar: elevator","percent full","double",0,0,"0.882353");
SET("graphics method: scrollbar: elevator","viewport","viewport",0,0,"0 12 12 258");
SET("graphics method: scrollbar: second arrow","active display","SUIT_enum",0,0,"\"motif\" of {\"simple arrow\" \"motif\"}");
SET("graphics method: scrollbar: second arrow","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics method: scrollbar: second arrow","direction","SUIT_enum",0,0,"\"down\" of {\"up\" \"down\" \"left\" \"right\"}");
SET("graphics method: scrollbar: second arrow","has border","boolean",0,0,"no");
SET("graphics method: scrollbar: second arrow","viewport","viewport",0,0,"0 0 12 12");
SET("graphics method: list","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("graphics method: list","callback function","SUIT_functionPointer",0,0,"function ptr");
SET("graphics method: list","drawing viewport","viewport",0,0,"-14 2 81 256");
SET("graphics method: list","springiness","SUIT_springiness",0,0,"3");
SET("graphics method: list","viewport","viewport",0,0,"-14 2 81 272");
SET("Cellular Automata Simulator","active display","SUIT_enum",0,0,"\"standard\" of {\"standard\"}");
SET("Cellular Automata Simulator","font","GP_font",0,0,"new century schoolbook,bolditalic,24.000000");
SET("Cellular Automata Simulator","label","text",0,0,"Cellular Automata Simulator");
SET("Cellular Automata Simulator","viewport","viewport",0,0,"195 555 573 591");


} /* end of INIT_suiRoutine */



void SUIT_initFromCode (char *programName)
{
    SUIT_interiorInitFromCode (programName, INIT_suiRoutine, THE_SCREEN_WIDTH,
                               THE_SCREEN_HEIGHT, THE_SCREEN_DEPTH);
}
