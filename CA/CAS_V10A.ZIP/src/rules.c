#include "auto.h"

rule rule_array[] =
{
  {"Anneal", anneal},
  {"Brians_brain", brian_brain},
  {"Codd", codd},
  {"Diamonds", diamonds},
  {"4 way Fill", fill4},
  {"8 way Fill", fill8},
  {"Gravity", gravity},
  {"Growth", growth},
  {"Hglass", hglass},
  {"Lichens", lichens},
  {"Life", life},
  {"Majority", majority},
  {"Parity", parity},
  {"Squares", squares},
  {"Triangles", triangles},
  {"Tube_worm", tube_worm},
  {"Tube_worm_2", tube_worm2},
  {0, 0}
};

/******************************************************************/

void anneal (automaton * automata, int row, int col, int item)
{
  int touching, state;

  /* ------------------------------------------------------------ */

  state = automata[item].state;
  touching = neighbours (automata, row, col);
  if (state > 0)
    touching++;

  /* ------------------------------------------------------------ */

  switch (touching)
  {
  case 0:
  case 1:
  case 2:
  case 3:
  case 5:
    automata[item].tmp = DEAD;
    break;
  case 4:
  case 6:
  case 7:
  case 8:
  case 9:
    if (state == 0)
      automata[item].tmp = BIRTH;
    else
      automata[item].tmp = SURVIVE;
    break;
  default:
    automata[item].tmp = state;
  }
}

/******************************************************************/

void brian_brain (automaton * automata, int row, int col, int item)
{
  int state, touching;
  int neig[8];
  int count;

  state = automata[item].state;

  automata[item].tmp = state;
  if (state == 0)
  {
    neig[0] = north (automata, row, col);
    neig[1] = north_east (automata, row, col);
    neig[2] = east (automata, row, col);
    neig[3] = south_east (automata, row, col);
    neig[4] = south (automata, row, col);
    neig[5] = south_west (automata, row, col);
    neig[6] = west (automata, row, col);
    neig[7] = north_west (automata, row, col);

    touching = 0;
    for (count = 0; count < 8; count++)
    {
      if (neig[count] == 1)
	touching++;
    }

    if (touching == 2)
      automata[item].tmp = 1;

  }
  else if (state == 1)
    automata[item].tmp = 2;
  else if (state == 2)
    automata[item].tmp = 0;
}

/******************************************************************/

void codd (automaton * automata, int row, int col, int item)
{
  int n, s, e, w, sum;

  n = north (automata, row, col);
  e = east (automata, row, col);
  s = south (automata, row, col);
  w = west (automata, row, col);

  sum = n + e + s + w;
  switch (sum)
  {
  case 3:
  case 4:
    automata[item].tmp = 1;
    break;
  case 2:
    if (n != s)
    {
      automata[item].tmp = 0;
      break;
    }
  default:
    automata[item].tmp = automata[item].state;
  }
}

/******************************************************************/

void diamonds (automaton * automata, int row, int col, int item)
{
  int state, n, e, s, w;

  state = automata[item].state;
  n = north (automata, row, col);
  e = east (automata, row, col);
  s = south (automata, row, col);
  w = west (automata, row, col);

  automata[item].tmp = (state || n || e || s || w);
}

/******************************************************************/

void fill4 (automaton * automata, int row, int col, int item)
{
  int neig[4];
  int state,count,touching;

  state = automata[item].state;
  automata[item].tmp = state;

  if (state == 0)
  {
    neig[0] = north (automata, row, col);
    neig[1] = east (automata, row, col);
    neig[2] = south (automata, row, col);
    neig[3] = west (automata, row, col);

    touching = 0;
    for (count = 0; count < 4; count++)
    {
      if (neig[count] ==SEED )
	touching++;
    }
    if (touching>0)
      automata[item].tmp=SEED;
  }

}

/******************************************************************/
void fill8 (automaton * automata, int row, int col, int item)
{
  int neig[8];
  int state,count,touching;

  state = automata[item].state;
  automata[item].tmp = state;

  if (state == 0)
  {
    neig[0] = north (automata, row, col);
    neig[1] = north_east (automata, row, col);
    neig[2] = east (automata, row, col);
    neig[3] = south_east (automata, row, col);
    neig[4] = south (automata, row, col);
    neig[5] = south_west (automata, row, col);
    neig[6] = west (automata, row, col);
    neig[7] = north_west (automata, row, col);

    touching = 0;
    for (count = 0; count < 8; count++)
    {
      if (neig[count] ==SEED )
	touching++;
    }
    if (touching >0)
      automata[item].tmp=SEED;
  }

}

/******************************************************************/

void gravity (automaton * automata, int row, int col, int item)
{
  int state, s, n;

  state = automata[item].state;
  s = south (automata, row, col);
  n = north (automata, row, col);


  if ((state == 0) && (n > 0))
    automata[item].tmp = n;
  else if ((state > 0) && (s == 0))
    automata[item].tmp = 0;
  else
    automata[item].tmp = state;
}

/******************************************************************/

void growth (automaton * automata, int row, int col, int item)
{
  int touching, state;

  touching = neighbours (automata, row, col);
  state = automata[item].state;

  if (touching == 1)
    automata[item].tmp = 1;
  else
  {
    if (state > 0)
      automata[item].tmp = SURVIVE;
    else
      automata[item].tmp = 0;
  }
}

/******************************************************************/

void hglass (automaton * automata, int row, int col, int item)
{
  int n, s, e, w, state;
  int index;
  static int table[32]=
  {
  0,1,1,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,1,0,0,0,0,0,1,0,0,1,0,1,0,1
  };

  n = north (automata, row, col)>0;
  e = east (automata, row, col)>0;
  s = south (automata, row, col)>0;
  w = west (automata, row, col)>0;
  state = automata[item].state>0;

  index = n*16 + e*8 + w*4 + s*2 + state;

  automata[item].tmp = table[index];

}

/******************************************************************/

void lichens (automaton * automata, int row, int col, int item)
{
  int touching, state;

  /* ------------------------------------------------------------ */

  state = automata[item].state;
  touching = neighbours (automata, row, col);

  /* ------------------------------------------------------------ */

  switch (touching)
  {
  case 3:
  case 7:
  case 8:
    automata[item].tmp = BIRTH;
    break;
  case 4:
    automata[item].tmp = DEAD;
    break;
  default:
    automata[item].tmp = state;
  }
}

/******************************************************************/

void life (automaton * automata, int row, int col, int item)
{
  int touching, state;

  touching = neighbours (automata, row, col);

  /* ------------------------------------------------------------ */
  state = automata[item].state;
  if ((state == 0) && (touching == 3))
    automata[item].tmp = BIRTH;
  else if ((state > 0) && ((touching == 3) || (touching == 2)))
    automata[item].tmp = SURVIVE;
  else
    automata[item].tmp = DEAD;
}

/******************************************************************/

void majority (automaton * automata, int row, int col, int item)
{
  int touching;

  touching = neighbours (automata, row, col);
  if (automata[item].state > 0)
    touching++;

  /* ------------------------------------------------------------ */
  if (touching < 5)
    automata[item].tmp = 0;
  else
    automata[item].tmp = 1;
}

/******************************************************************/

void parity (automaton * automata, int row, int col, int item)
{
  int centre, n, e, s, w;

  centre = automata[item].state > 0;
  n = north (automata, row, col);
  e = east (automata, row, col);
  s = south (automata, row, col);
  w = west (automata, row, col);

  automata[item].tmp = centre ^ n ^ e ^ s ^ w;
}

/******************************************************************/

void squares (automaton * automata, int row, int col, int item)
{
  int state, n, ne, e, se, s, sw, w, nw;

  state = automata[item].state;
  n = north (automata, row, col);
  ne = north_east (automata, row, col);
  e = east (automata, row, col);
  se = south_east (automata, row, col);
  s = south (automata, row, col);
  sw = south_west (automata, row, col);
  w = west (automata, row, col);
  nw = north_west (automata, row, col);

  automata[item].tmp = (state | n | ne | e | se | s | sw | w | nw);
}

/******************************************************************/

void triangles (automaton * automata, int row, int col, int item)
{
  int state, n, e, w;

  state = automata[item].state;
  n = north (automata, row, col);
  e = east (automata, row, col);
  w = west (automata, row, col);
  automata[item].tmp = (state | n | e | w);
}

/******************************************************************/

void tube_worm (automaton * automata, int row, int col, int item)
{
  int state, touching, alert;
  int neig[8], count;

  state = automata[item].state;
  automata[item].tmp = state;

  if (state > 1)
  {
    state--;
    automata[item].tmp = state;
  }
  else if (state > 0)
  {
    neig[0] = north (automata, row, col);
    neig[1] = north_east (automata, row, col);
    neig[2] = east (automata, row, col);
    neig[3] = south_east (automata, row, col);
    neig[4] = south (automata, row, col);
    neig[5] = south_west (automata, row, col);
    neig[6] = west (automata, row, col);
    neig[7] = north_west (automata, row, col);

    touching = 0;
    alert = 0;
    for (count = 0; count < 8; count++)
    {
      if (neig[count] > 1)
	touching++;
      if (neig[count] == ALERT)
	alert++;
    }
    if ((touching > WORM_THRESHHOLD)|| (alert >0))
    {
      automata[item].timer = 4;
      automata[item].tmp = ALERT;
    }
  }
}

/******************************************************************/

void tube_worm2 (automaton * automata, int row, int col, int item)
{
  int state, alert;
  int neig[8], count;

  state = automata[item].state;
  automata[item].tmp = state;

  if (state > 1)
  {
    state--;
    automata[item].tmp = state;
  }
  else if (state > 0)
  {
    neig[0] = north (automata, row, col);
    neig[1] = north_east (automata, row, col);
    neig[2] = east (automata, row, col);
    neig[3] = south_east (automata, row, col);
    neig[4] = south (automata, row, col);
    neig[5] = south_west (automata, row, col);
    neig[6] = west (automata, row, col);
    neig[7] = north_west (automata, row, col);

    alert = 0;
    for (count = 0; count < 8; count++)
      if (neig[count] == ALERT)
	alert++;

    if (alert >0)
    {
      automata[item].tmp = ALERT+alert-1;
    }
  }
}
