#include "auto.h"

#define SIG "Cellular automata file"
#define COMMENT ';'


void save_header (FILE * fp);
int load_header (FILE * fp);

void load_dimensions (FILE * fp, int *new_rows, int *new_cols, int *new_states);
void save_dimensions (FILE * fp, int states);

void load_data (FILE * fp, SUIT_object auto_obj);
void save_data (FILE * fp, SUIT_object auto_obj);

void get_string (FILE * fp, char *buffer);
int check_dimensions (int rows, int cols, int states);

/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int exists (char *fname)
{
  FILE *fp;
  int retval = FALSE;

  if (fname)
  {
    fp = fopen (fname, "r");
    if (fp)
    {
      retval = TRUE;
      fclose (fp);
    }
  }
  return (retval);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void save_auto_data (FILE * fp, SUIT_object auto_obj)
{
  int save_states;

  save_states = SUIT_getInteger (auto_obj, STATES);

  save_header (fp);
  save_dimensions (fp, save_states);
  save_data (fp, auto_obj);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
int load_auto_data (FILE * fp, SUIT_object auto_obj)
{
  int retval = FALSE;
  int new_rows, new_cols, states;

  if (load_header (fp))
  {
    load_dimensions (fp, &new_rows, &new_cols, &states);

    if (check_dimensions (new_rows, new_cols, states))
    {
      reset_RowCol (auto_obj, new_rows, new_cols);
      SUIT_setInteger (auto_obj, STATES, states);

      load_data (fp, auto_obj);
      retval = TRUE;
    }
  }

  return (retval);
}

/************************************************************************/
/* 		header ops						*/
/************************************************************************/

void save_header (FILE * fp)
{
  fprintf (fp, "%s\n", SIG);
}

int load_header (FILE * fp)
{
  char buffer[BUFFER_SIZE];
  char *cp = buffer;

  get_string (fp, buffer);
  trim(buffer,&cp);
  return (strcmp (buffer, SIG) == 0);
}


/************************************************************************/
/*									*/
/************************************************************************/

void save_dimensions (FILE * fp, int states)
{
  fprintf (fp, "%d rows\n", rows);
  fprintf (fp, "%d cols\n", cols);
  fprintf (fp, "%d states\n", states);
}


void load_dimensions (FILE * fp, int *new_rows, int *new_cols, int *new_states)
{
  char buffer[BUFFER_SIZE];

  get_string (fp, buffer);
  sscanf (buffer, "%d rows", new_rows);

  get_string (fp, buffer);
  sscanf (buffer, "%d cols", new_cols);

  get_string (fp, buffer);
  sscanf (buffer, "%d states\n", new_states);
}

/************************************************************************/
/*									*/
/************************************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void load_data (FILE * fp, SUIT_object auto_obj)
{
  int row, col, item, number, value;
  automaton *automata;
  char buffer[BUFFER_SIZE];
  char *sub_str;

  number = SUIT_getInteger (auto_obj, NUMBER);
  automata = auto_arr[number];

  for (row = 0; row < rows; row++)
  {
    get_string (fp, buffer);
    sub_str = buffer;

    for (col = 0; col < cols; col++)
    {
      item = get_item (row, col);

      sscanf (sub_str, "%d", &value);
      automata[item].state = value;
      automata[item].changed = TRUE;
      sub_str = skiptonum (sub_str);
    }
  }

}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name:							*/
/*									*/
/* Description:								*/
/*									*/
/* Date of creation:							*/
/*									*/
/* input arguments:							*/
/*									*/
/* output:								*/
/*									*/
/* function return:							*/
/*									*/
/* Modifications:							*/
/*									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
void save_data (FILE * fp, SUIT_object auto_obj)
{
  int row, col, item, number;
  automaton *automata;

  number = SUIT_getInteger (auto_obj, NUMBER);
  automata = auto_arr[number];

  for (row = 0; row < rows; row++)
  {
    for (col = 0; col < cols; col++)
    {
      item = get_item (row, col);
      fprintf (fp, " %3d", automata[item].state);
    }
    fprintf (fp, "\n");
  }

}

/************************************************************************/
/*									*/
/************************************************************************/


void get_string (FILE * fp, char *buffer)
{
  char buff[BUFFER_SIZE];
  char *start;
  int done = 0;

  *buff = 0;

  while (!feof (fp) && !done)
  {
    fgets (buff, BUFFER_SIZE - 1, fp);

    trim (buff, &start);

    if (*start == COMMENT)
      *start = 0;

    if (*start)
    {
      strcpy (buffer, start);
      done = 1;
    }
  }
}


int check_dimensions (int rows, int cols, int states)
{
  int retval;

  retval = (rows > 0) && (rows <= MAX_ROWS);
  retval = retval && (cols > 0) && (cols <= MAX_COLS);
  retval = retval && (states > 0) && (states <= MAX_STATES);

  return (retval);
}
