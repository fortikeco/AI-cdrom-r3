#include "auto.h"

/************************************************************************/
/*			PRIVATE FUNCTIONS				*/
/************************************************************************/
void PaintColorbarWidget (SUIT_object obj);


/************************************************************************/
/* User defined  SUIT objects						*/
/************************************************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name: 	CreateColorbarWidget				*/
/* 									*/
/* Description:		create a new instance of the graphics widget	*/
/*			for displaying Colorbar-nets			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	name of widget					*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	pointer to new SUIT object			*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

SUIT_object
CreateColorbarWidget (char *name)
{
  int states;
  SUIT_object obj;

  states = DEFAULT_STATES;

  /* ----------------------------------------------------------------	*/
  /* 		basic setup of Colorbar object				*/
  /* ----------------------------------------------------------------	*/
  obj = SUIT_createObject (name, "Colorbar class");
  SUIT_addDisplayToObject
    (
      obj,
      "standard",
      NULL,
      PaintColorbarWidget
    );

  SUIT_setInteger (obj, CSTATES, states);
  SUIT_makePropertyTemporary (obj, CSTATES, OBJECT);

  /* ---------------------------------------------------------------- */
  /* 				create the bulletin board		*/
  /* ---------------------------------------------------------------- */
  return (obj);
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Function name: 	PaintColorbarWidget				*/
/* 									*/
/* Description:		draw the contents of widget			*/
/* 									*/
/* Date of creation:	16-10-92					*/
/* 									*/
/* input arguments:	obj	object to redraw			*/
/* 									*/
/* output:		None						*/
/* 									*/
/* function return:	void						*/
/* 									*/
/* Modifications:							*/
/* 									*/
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void
  PaintColorbarWidget (SUIT_object obj)
{
  int states, state;
  double x_step;
  GP_point bottom_left, top_right;


  states = SUIT_getInteger (obj, CSTATES);

  /* ----------------------------------------------------------------	*/

  x_step = 1.0 / (double) (states + 1);

  bottom_left.x = 0.0;
  bottom_left.y = 0.0;
  top_right.x = x_step;
  top_right.y = 1.0;

  /* ----------------------------------------------------------------	*/

  for (state = 0; state <= states; state++)
  {
    set_gray (state);

    GP_fillRectangle (bottom_left, top_right);

    bottom_left.x = top_right.x;
    top_right.x += x_step;
  }

}
