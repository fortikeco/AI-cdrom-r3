
/* HODGE-C -- A C implementation of Gerhard & Schuster's hodge-podge machine */

/* hodge.c -- main program

   Copyright (C) 1993 Joerg Heitkoetter

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#ifndef lint
static char *rcsid = "$Id: hodge.c,v 1.2 1993/03/19 11:28:28 heitkoet Exp heitkoet $";
#endif

#include "hodge.h"
#include "getopt.h"
#include "version.h"

/* flags */
bool moore = FALSE;			/* von-Neumann default */
bool torus = FALSE;			/* bounded by default */
bool film = TRUE;			/* generate a film by default */
bool moni = FALSE;			/* generate online visualisation */
bool batch = FALSE;			/* generate no user feedback */
bool dump = TRUE;			/* generate any dump file */
bool idl = FALSE;			/* generate IDL data file */
bool gnuplot = TRUE;			/* generated Gnuplot data file */

int n = 100;				/* number of states from SANE to ILL */
int ncells = 128;			/* number of each side of grid */
int nticks = 1000;			/* timer ticks to computer */

int random_seed = 12345678;		/* seed for random number generator */

int nsane;				/* number of sane cells */
int ninfected;				/* number of infected cells */
int nill;				/* number of ill cells */

int nframes = 1;			/* number of frames to write */
int startoffilm = 0;			/* time step to start film */
int skipbetweentakes = 1;		/* take every new state */
int framestotake;			/* frames left to take (= nframes) */

int ndumps = 1;				/* number of dumps to write */
int startofdump = 0;			/* time step to start dump */
int skipbetweendumps = 1;		/* dump every new state */
int dumpstomake;			/* dumps left to make (= ndumps) */

int k1 = 2;				/* G&S's default */
int k2 = 3;				/* G&S's default */
int g = 25;				/* some nice waves */

char *afilename = "hodge-%0003d.ppm";	/* default frame prefix file */
char *cfilename = "hodge.col";		/* default color map file */
char *dfilename = "hodge-%0003d.dmp";	/* default dump data file */
char *pfilename = "hodge.plt";		/* default plot data file */

					/* default monitor process */
char *mfilename = "pixmon -dx 128 -dy 128 -scale 4 -cmap hodge.col";


/* global stuff */
char *program_name;			/* who am i? */

FILE *rep;				/* pointer to report file */
FILE *mon;				/* pointer to monitor process */

grid_t cell, ncell;			/* the CA storage */

cmap_t cmap;				/* color map */


/* program options */
static struct option opts[] =
{
    {
	"animation-file-name", 1, 0, 'A'
    },
    {
	"color-map-file-name", 1, 0, 'C'
    },
    {
	"dump-data-file-name", 1, 0, 'D'
    },
    {
	"number-of-frames", 1, 0, 'F'
    },
    {
	"groth-rate", 1, 0, 'G'
    },
    {
	"ill-cells-denominator", 1, 0, 'J'
    },
    {
	"infected-cells-denominator", 1, 0, 'K'
    },
    {
	"number-of-cell-states", 1, 0, 'N'
    },
    {
	"monitor-process", 1, 0, 'M'
    },
    {
	"plot-file-name", 1, 0, 'P'
    },
    {
	"size-of-grid", 1, 0, 'S'
    },
    {
	"time-steps", 1, 0, 'T'
    },
    {
	"start-of-film", 1, 0, 'X'
    },
    {
	"skip-between-takes", 1, 0, 'Y'
    },
    {
	"batch", 0, 0, 'b'
    },
    {
	"no-dump", 0, 0, 'd'
    },
    {
	"number-of-dumps", 1, 0, 'f'
    },
    {
	"gnuplot-data-format", 0, 0, 'g'
    },
    {
	"help", 0, 0, 'h'
    },
    {
	"idl-data-format", 0, 0, 'i'
    },
    {
	"moore-neighbourhood", 0, 0, 'm'
    },
    {
	"no-film", 0, 0, 'n'
    },
    {
	"on-line-visualization", 0, 0, 'o'
    },
    {
	"seed-for-random", 1, 0, 's'
    },
    {
	"torus", 0, 0, 't'
    },
    {
	"version", 0, 0, 'v'
    },
    {
	"warranty", 0, 0, 'w'
    },
    {
	"start-of-dump", 1, 0, 'x'
    },
    {
	"skip-between-dumps", 1, 0, 'y'
    },
    {
	0, 0, 0, 0
    }
};

main (argc, argv)
    int argc;
    char **argv;
{
    int c, index;

   /* whoami? */
    program_name = *argv;

   /* parse args */
    while ((c = getopt_long (argc, argv, "A:C:D:F:G:J:K:M:N:P:S:T:X:Y:bdghimnos:tvwx:y:", opts, &index)) != EOF) {

       /* long option? */
	if (c == 0) {
	    c = opts[index].val;
	}

       /* setup program parameters */
	switch (c) {

	    /* set animation data name format */
	 case 'A':
	     afilename = optarg;
	     break;

	    /* set color map file name */
	 case 'C':
	     cfilename = optarg;
	     break;

	    /* set dump data file name format */
	 case 'D':
	     dfilename = optarg;
	     break;

	    /* set number of frames included in the film */
	 case 'F':
	     nframes = atoi (optarg);
	     break;

	    /* set groth rate of INFECTion */
	 case 'G':
	     g = atoi (optarg);
	     break;

	    /* set ILL cells denominator */
	 case 'J':
	     k1 = atoi (optarg);
	     break;

	    /* set INFECTED cells denominator */
	 case 'K':
	     k2 = atoi (optarg);
	     break;

	    /* set monitor process for online visualization */
	 case 'M':
	     mfilename = optarg;
	     moni = TRUE;
	     break;

	    /* set number of states from SANE to ILL */
	 case 'N':
	     n = atoi (optarg);
	     break;

	    /* set plot file name format */
	 case 'P':
	     pfilename = optarg;
	     break;

	    /* set size of grid */
	 case 'S':
	     ncells = atoi (optarg);
	     break;

	    /* set time steps to compute */
	 case 'T':
	     nticks = atoi (optarg);
	     break;

	    /* when shall the film begin? */
	 case 'X':
	     startoffilm = atoi (optarg);
	     break;

	    /* how many time steps to skip for next frame? */
	 case 'Y':
	     skipbetweentakes = atoi (optarg);
	     break;

	    /* set mode to batch */
	 case 'b':
	     batch = TRUE;
	     break;

	    /* turn off data logging */
	 case 'd':
	     dump = FALSE;
	     break;

	    /* set number of dumps */
	 case 'f':
	     ndumps = atoi (optarg);
	     break;

	    /* set data logging attribute to Gnuplot */
	 case 'g':
	     gnuplot = TRUE;
	     idl = FALSE;
	     break;

	    /* print help info */
	 case 'h':
	     usage (0);
	     break;

	    /* set data logging attribute to IDL(TM) */
	 case 'i':
	     idl = TRUE;
	     gnuplot = FALSE;
	     break;

	    /* set computation attribute */
	 case 'm':
	     moore = TRUE;
	     break;

	    /* generate a film? */
	 case 'n':
	     film = FALSE;
	     break;

	    /* generate an online-visualization? */
	 case 'o':
	     moni = TRUE;
	     break;

	    /* set seed for random number generator */
	 case 's':
	     random_seed = atoi (optarg);
	     break;

	    /* set grid attribute */
	 case 't':
	     torus = TRUE;
	     break;

	    /* print version info */
	 case 'v':
	     version (0);
	     break;

	    /* print version info */
	 case 'w':
	     warranty (0);
	     break;

	    /* when shall the dump begin? */
	 case 'x':
	     startofdump = atoi (optarg);
	     break;

	    /* how many time steps to skip for next dump? */
	 case 'y':
	     skipbetweendumps = atoi (optarg);
	     break;

	    /* print usage info */
	 default:
	     usage (1);
	}
    }

   /* open output(s) */
    if ((rep = fopen (pfilename, "w")) == NULL)
	panic (E_FATAL, "hodge", "can't open file %s", pfilename);

    if (moni)
	if ((mon = popen (mfilename, "w")) == NULL)
	    panic (E_FATAL, "hodge", "can't open pipe %s", mfilename);

   /* open color map, etc. */
    if (film) {
	loadcmap (cfilename);
        framestotake = nframes;
    }

   /* init dumping, etc. */
    if (dump) {
        dumpstomake = ndumps;
    }

   /* hodge-podge */
    hodge (rep);

   /* clean-up*/
    fclose (rep);
    fclose (mon);

    return 0;
}

/*
 *	usage -- print usage information
 */
void
usage (code)
    int code;
{
    fprintf (stderr, "usage: %s [options]\n\
	[-A, --animation-file-name <name>]\n\
	[-C, --color-map-file-name <name>]\n\
	[-D, --dump-data-file-name <name>]\n\
	[-F, --number-of-frames <number>]\n\
	[-G, --groth-rate <number>]\n\
	[-J, --ill-cells-denominator <number>]\n\
	[-K, --infected-cells-denominator <number>]\n\
	[-M, --monitor-process <process>]\n\
	[-N, --number-of-cell-states <number>]\n\
	[-P, --plot-file-name <name>]\n\
	[-S, --size-of-grid <size>]\n\
	[-T, --time-steps <number>]\n\
	[-X, --start-of-film <time step>]\n\
	[-Y, --skip-between-takes <number>]\n\
	[-b, --batch]\n\
	[-d, --no-dump]\n\
	[-f, --number-of-dumps <number>]\n\
	[-g, --gnuplot-data-format]\n\
	[-h, --help]\n\
	[-i, --idl-data-format]\n\
	[-m, --moore-neighbourhood]\n\
	[-n, --no-film]\n\
	[-o, --on-line-visualization]\n\
	[-s, --seed-for-random <seed value>]\n\
	[-t, --torus]\n\
	[-v, --version]\n\
	[-w, --warranty]\n\
	[-x, --start-of-dump <timestep>]\n\
	[-y, --skip-between-dumps <number>]\n\
	\n", program_name);

    exit (code);
}

/*
 *	version -- print version information
 */
void
version (code)
    int code;
{
    fprintf (stderr, "This is %s %s version %d.%d%c (%003d)\n",
	     V_NAME, V_OSTYPE, V_MAJOR, V_MINOR, V_MAGIC, V_MODF);

    fprintf (stderr, "Copyright (C) 1993 by Joerg Heitkoetter.");
    fprintf (stderr, "Type `%s -w' for WARRANTY.\n", program_name);

#ifndef LOCAL_MAINTAINER
    fprintf (stderr, "Send bugs, comments, etc., to %s.\n", V_EMAIL);
#else
    fprintf (stderr, "Last modification by %s, on %s\n", V_MAINTAINER, V_DATE);
    fprintf (stderr, "Send bugs, comments, etc., to %s.\n", V_EMAIL);
#endif

    exit (code);
}

/*
 *	warranty -- print warranty information
 */
void
warranty (code)
    int code;
{
    fprintf (stderr, "\
    HODGE-C  --  Copyright (C) 1993 by Joerg Heitkoetter\n\
\n\
    Gerhard & Schuster's Hodge-Podge machine in C\n\
    See also Computer Recreations in Scientific American, October 1988.\n\
\n\
    This program is free software; you can redistribute it and/or modify\n\
    it under the terms of the GNU General Public License as published by\n\
    the Free Software Foundation; either version 2 of the License, or\n\
    (at your option) any later version.\n\
\n\
    This program is distributed in the hope that it will be useful,\n\
    but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n\
    GNU General Public License for more details.\n\
\n\
    You should have received a copy of the GNU General Public License\n\
    along with this program; if not, write to the Free Software\n\
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n");

    exit (code);
}

/*
 *	hodge -- main loop
 */
void
hodge (rep)
    FILE *rep;
{
    int A, B, S;
    int i, j;
    int t = 0;
    int nval;				/* range: [0..8*n + n] */

    initialize (random_seed);

    while (t++ < nticks) {
	nsane = ninfected = nill = 0;

	for (i = 0; i < ncells; i++)
	    for (j = 0; j < ncells; j++) {
		A = scount (i, j, ILL);
		B = scount (i, j, INFECTED);
		S = vsum (i, j) + cell[i][j].value;

		switch (cell[i][j].state) {
		 case SANE:
		     nsane++;
		     nval = (cell_v) (A / k1 + B / k2);
		     break;

		 case INFECTED:
		     ninfected++;
		     B++;		/* add self to INFECTED */
		     nval = (cell_v) (S / B + g);
		     break;

		 case ILL:
		     nill++;
		     nval = V_SANE;
		     break;
		}

	       /* set state & value */
		ncell[i][j].state = get_state (&nval);
		ncell[i][j].value = (cell_v) nval;
	    }

       /* report statistics, etc. */
	report (rep, t);

       /* write animation data, etc. */
	if (film && t >= startoffilm && framestotake > 0)
	    grid2ppm (t, cell);

       /* dumping data file, etc. */
	if (dump && t >= startofdump && dumpstomake > 0)
	    grid2dump (t, cell);

       /* online visualization, etc. */
	if (moni)
	    pixmon (cell);

       /* copy new cells to old */
	memcpy (cell, ncell, sizeof (grid_t));
    }
}

/*
 *	initialize -- init the global data structures
 */
void
initialize (seed)
    int seed;
{
    int i, j;

    srand (seed);

    for (i = 0; i < ncells; i++)
	for (j = 0; j < ncells; j++) {
	    cell[i][j].state = (cell_s) (random () % MAXSTATES);

	    if (cell[i][j].state == SANE)
		cell[i][j].value = V_SANE;
	    else if (cell[i][j].state == INFECTED)
		cell[i][j].value = (cell_v) (rand () % (n - 1) + 1);
	    else
		cell[i][j].value = V_ILL;

	    ncell[i][j].state = SANE;
	    ncell[i][j].value = V_SANE;
	}
}

/*
 *	get_state -- compute the state from a cell's value
 */
cell_s
get_state (val)
    int *val;
{
    if (*val <= V_SANE) {
	*val = V_SANE;
	return (SANE);
    } else {
	if (*val >= V_ILL) {
	    *val = V_ILL;
	    return (ILL);
	} else {
	    return (INFECTED);
	}
    }
}

/*
 *	report -- report statistics
 */
void
report (rep, t)
    FILE *rep;
    int t;
{
    fprintf (rep, "%d\t%d\t%d\t%d\t%lf\n",
	     t, nsane, ninfected, nill, (double) ninfected / (double) (ncells * ncells));
}

/*
 *	map -- map index to grid structure
 */
int
map (i)
    int i;
{
    if (!torus) {
	if (i < 0)
	    return (0);
	else if (i == ncells)
	    return (ncells - 1);
	else
	    return (i);
    } else {
	if (i < 0)
	    return (ncells - 1);
	else if (i == ncells)
	    return (0);
	else
	    return (i);
    }
}

/*
 *	scount -- count cells in specified state
 */
int
scount (i, j, state)
    int i, j;
    cell_s state;
{
    int count = 0;

   /* always count von-Neumann cells */
    if (cell[map (i - 1)][j].state == state)
	++count;
    if (cell[i][map (j - 1)].state == state)
	++count;
    if (cell[i][map (j + 1)].state == state)
	++count;
    if (cell[map (i + 1)][j].state == state)
	++count;

   /* sometimes count Moore cells */
    if (moore) {
	if (cell[map (i - 1)][map (j - 1)].state == state)
	    ++count;
	if (cell[map (i + 1)][map (j - 1)].state == state)
	    ++count;
	if (cell[map (i - 1)][map (j + 1)].state == state)
	    ++count;
	if (cell[map (i + 1)][map (j + 1)].state == state)
	    ++count;
    }
    return (count);
}

/*
 *	vsum -- sum up all neighbour cells' values
 */
int
vsum (i, j)
    int i, j;
{
    int sum = 0;

   /* always sum von-Neumann cells */
    sum = cell[map (i - 1)][j].value
	+ cell[i][map (j - 1)].value
	+ cell[i][map (j + 1)].value
	+ cell[map (i + 1)][j].value;

   /* sometimes sum Moore cells */
    if (moore) {
	sum += cell[map (i - 1)][map (j - 1)].value
	     + cell[map (i + 1)][map (j - 1)].value
	     + cell[map (i - 1)][map (j + 1)].value
	     + cell[map (i + 1)][map (j + 1)].value;
    }
    return (sum);
}

/*
 *	rgb_color -- turn value into an RGB string
 */
color_t *
rgb_color (val)
    int val;
{
    color_t rgb;

    rgb[0] = cmap[val].red;
    rgb[1] = cmap[val].green;
    rgb[2] = cmap[val].blue;

    return ((color_t *) rgb);
}

/*
 *	grid2ppm -- write out the grid converted to a color portable pixmap
 */
void
grid2ppm (t, grid)
    int t;
    grid_t grid;
{
    FILE *fp;
    int i, j;
    static fcount = 0;
    char s[MAXFILELEN];

    if ((t - startoffilm) % skipbetweentakes == 0) {

       /* generate the frame's file name */
	sprintf (s, afilename, fcount++);
	if ((fp = fopen (s, "w")) == NULL)
	    panic (E_FATAL, "grid2ppm", "can't open file %s", s);

       /* write raw ppm(5) header */
	fprintf (fp, "P6\n");
	fprintf (fp, "# File:    %s\n", s);
	fprintf (fp, "# Creator: %s %s version %d.%d%c (%003d) (C) 1993 by Joerg Heitkoetter\n",
	     V_NAME, V_OSTYPE, V_MAJOR, V_MINOR, V_MAGIC, V_MODF);
	fprintf (fp, "%d %d\n", ncells, ncells);
	fprintf (fp, "%d\n", n);

       /* turn bitimage into RGB colors */
	for (i = 0; i < ncells; i++)
	    for (j = 0; j < ncells; j++)
		fwrite (rgb_color (cell[i][j].value), sizeof (color_t), 1, fp);

       /* clean up */
	fclose (fp);

       /* give some feedback */
	if (!batch)
	    fprintf (stderr, "%s: successfully wrote (%dx%d) file `%s' (%d colors)\n",
		     program_name, ncells, ncells, s, n+1);

       /* adjust frame counter */
	--framestotake;
    }
}

/*
 *	grid2dump -- write out the grid converted to an IDL(TM) 3D/Gnuplot 3D data file
 */
void
grid2dump (t, grid)
    int t;
    grid_t grid;
{
    FILE *fp;
    int i, j;
    char s[MAXFILELEN];

    if ((t - startofdump) % skipbetweendumps == 0) {

       /* generate the frame's file name */
	sprintf (s, dfilename, t);
	if ((fp = fopen (s, "w")) == NULL)
	    panic (E_FATAL, "grid2dump", "can't open file %s", s);

       /* write dump header */
	fprintf (fp, "# File:    %s\n", s);
	fprintf (fp, "# Creator: %s %s version %d.%d%c (%003d) (C) 1993 by Joerg Heitkoetter\n",
	     V_NAME, V_OSTYPE, V_MAJOR, V_MINOR, V_MAGIC, V_MODF);
	fprintf (fp, "# Grid:    %dx%d\n", ncells, ncells);
	fprintf (fp, "# Colors:  %d\n", n);

	if (idl) {
	   /* write X axis */
	    for (i = 0; i < ncells; i++)
		fprintf (fp, "%d\n", i+1);

	   /* write Y axis */
	    for (i = 0; i < ncells; i++)
		fprintf (fp, "%d\n", i+1);

	   /* write Z axis */
	    for (i = 0; i < ncells; i++)
		for (j = 0; j < ncells; j++)
		    fprintf (fp, "%d\n", cell[i][j].value);
	}

	if (gnuplot) {
	   /* write X, Y, Z axis */
	    for (i = 0; i < ncells; i++) {
		for (j = 0; j < ncells; j++)
		    fprintf (fp, "%d\t%d\t%d\n", i+1, j+1, cell[i][j].value);
		fprintf (fp, "\n");
	    }
	}
       /* clean up */
	fclose (fp);

       /* give some feedback */
	if (!batch)
	    fprintf (stderr, "%s: successfully wrote (%dx%d) dump file `%s' (%d colors)\n",
		     program_name, ncells, ncells, s, n+1);

       /* adjust dump counter */
	--dumpstomake;
    }
}

/*
 *	loadcmap -- load a color map
 */
void
loadcmap (s)
    char *s;
{
    FILE *fp;
    char line[MAXLINELEN];
    int i, r, g, b;

    if ((fp = fopen (s, "r")) == NULL)
	panic (E_FATAL, "loadcmap", "can't load color map `%s'", s);

    for (i = 0; i < MAXCOLORS; i++) {
	if (fgets (line, MAXLINELEN, fp) == NULL)
	    panic (E_FATAL, "loadcmap", "not enough colors in color map file `%s'", s);

	/* comment line? */
	if (*line == COMMENTCHAR)
		continue;

	sscanf (line, " %d %d %d", &r, &g, &b);
	cmap[i].red = r & 0xff;
	cmap[i].green = g & 0xff;
	cmap[i].blue = b & 0xff;
    }
    if (!batch)
	fprintf (stderr, "%s: successfully read in color map `%s'\n",
		 program_name, cfilename);
}

/*
 *	pixmon -- online visualization using pixmon(1)
 */
void
pixmon (grid)
    grid_t grid;
{
    ImgHdr head;
    int i, j, bytes;

    INIT_IMGHDR (head);

    head.dx = ncells;
    head.dy = ncells;
    head.sizelo = PIX_LO (ncells * ncells);
    head.sizehi = PIX_HI (ncells * ncells);

    if ((bytes = fwrite (head, 1, sizeof (ImgHdr), mon)) != sizeof (ImgHdr))
	panic (E_FATAL, "pixmon", "failed to write header (%d out of %d)", bytes, sizeof (ImgHdr));

    for (i = 0; i < ncells; i++)
	for (j = 0; j < ncells; j++)
	    if ((bytes = fwrite (&grid[i][j].value, sizeof (cell_v), 1, mon)) != 1)
		    panic (E_FATAL, "pixmon", "failed to write grid point (%d, %d)", i, j);

    EXIT_IMGHDR (head);
    if ((bytes = fwrite (head, 1, sizeof (ImgHdr), mon)) != sizeof (ImgHdr))
	panic (E_FATAL, "pixmon", "failed to write kill package (%d out of %d)", bytes, sizeof (ImgHdr));
}
