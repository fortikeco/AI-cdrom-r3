/****************************************************************/
/*                                                              */
/*             C-Textfile zum  INFEKTIONSMODELL                 */
/*                   von Martin Gerhardt                        */
/*                                                              */
/*  Version 2.0                                   31. 8. 1986   */
/*                                                              */
/*                                                              */
/*  Bemerkungen zur Art der Simulation:                         */
/*                                                              */
/*  - Rand des Feldes nicht geschlossen                         */
/*  - Moore-Nachbarschaft                                       */
/*  - einzulesende Feldgroesse sollte nicht groesser als 179 sein   */
/*  - als Auswertung ist das Spielfeld dargestellt:             */
/*        - Tastaturbelegungen:                                 */
/*             'm' : Darstellung des Spielfeldes                */
/*             'B' : Beendigung der Simulation                  */
/*             'w' : Halt bis neuer Tastendruck erfolgt         */
/*             'E' : Neues Einlesen der Konstanten              */
/*                                                              */
/****************************************************************/

/*
 *  $Id: infekt2.c,v 1.1 1993/03/11 12:10:52 joke Exp $
 */
 
#ifdef __STDC__			/* ATARI ST Turbo-C */
#include <aes.h>
#include <vdi.h>
#include <tos.h>
#include <stdio.h>
#else /* Megamax-C */
#include <osbind.h>
#endif

int contrl[12], intin[128], ptsin[128], intout[128], ptsout[128];

int handle;

int work_out[57], work_in[12];

int set_mode, set_perimeter, set_color, set_interior, set_style, set_effect;

int Feldgr, Umschlagsgrenze, Infgeschw, k1, k2, Bgrad;


long Zufallszahl, Zeitpunkt, Umschlaege;

int *Feld, *Hfeld, *Krank, *Inf;

/*************************************************/
/*    open_work                                  */
/*************************************************/

open_work ()
{
    int i;

    appl_init ();
    for (i = 0; i < 10; work_in[i++] = 1);
    work_in[10] = 2;
    v_opnvwk (work_in, &handle, work_out);
}

/*************************************************/
/*    close_work                                 */
/*************************************************/

close_work ()
{
    gemdos (0x1);
    v_clsvwk (handle);
    appl_exit ();
}

/*************************************************/
/*   hide_mouse                                  */
/*************************************************/
static int hidden;

hide_mouse ()
{
    if (!hidden) {
	graf_mouse (256, 0x0L);
	hidden = 1;
    }
}

/**************************************************/
/*   show_mouse                                   */
/**************************************************/
show_mouse ()
{
    if (hidden) {
	graf_mouse (257, 0x0L);
	hidden = 0;
    }
}

/*************************************************/
/*    Speicherplatzreservierung                  */
/*************************************************/
Speicherplatz ()
{
    if ((Feld = (int *) Malloc (2l * (long) Feldgr * (long) Feldgr)) == 0) {
	form_alert (1, "[3][Speicherplatzmangel][Abbruch]");
	return (1);
    }
    if ((Hfeld = (int *) Malloc (2l * (long) Feldgr * (long) Feldgr)) == 0) {
	form_alert (1, "[3][Speicherplatzmangel][Abbruch]");
	return (1);
    }
    if ((Inf = (int *) Malloc (2l * (long) Feldgr * (long) Feldgr)) == 0) {
	form_alert (1, "[3][Speicherplatzmangel][Abbruch]");
	return (1);
    }
    if ((Krank = (int *) Malloc (2l * (long) Feldgr * (long) Feldgr)) == 0) {
	form_alert (1, "[3][Speicherplatzmangel][Abbruch]");
	return (1);
    }
    return (0);
}

/*************************************************/
/*    Speicherplatzfreigabe                      */
/*************************************************/
Spfrei ()
{
    Mfree (Feld);
    Mfree (Hfeld);
    Mfree (Krank);
    Mfree (Inf);
}

/*************************************************/
/*    Zufallszahl                                */
/*************************************************/

#define M 100000000
#define m1  10000L
#define b 31415821

long
Multiply (p, q)
    long p, q;

{
    long p0, p1, q0, q1;

    p1 = p / m1;
    p0 = p % m1;
    q1 = q / m1;
    q0 = q % m1;

    return ((((p0 * q1 + p1 * q0) % m1) * m1 + p0 * q0) % M);
}


rnd (maxvalue)
    long maxvalue;

{
    long Multiply ();

    Zufallszahl = (Multiply (Zufallszahl, b) + 1L) % M;
    return ((((Zufallszahl / m1) * maxvalue) / m1) % 65536);
}


/*************************************************/
/*  Einlesen                                     */
/*************************************************/

Einlesen ()
{
    do {

	v_clrwk (handle);
	printf ("\033H\033e");
	printf ("Feldgroesse = ");
	scanf ("%d", &Feldgr);
	Feldgr = Feldgr + 2;
	printf ("Umschlagsgrenze = ");
	scanf ("%d", &Umschlagsgrenze);
	printf ("Infektionsgeschw. = ");
	scanf ("%d", &Infgeschw);
	printf ("k1 = ");
	scanf ("%d", &k1);
	printf ("k2 = ");
	scanf ("%d", &k2);
	printf ("Bedeckungsgrad = ");
	scanf ("%d", &Bgrad);
	printf ("Zufallszahl = ");
	scanf ("%ld", &Zufallszahl);
	printf ("\033f");

	printf ("\n\n\n    continue   (y/n)\n");
    }
    while ((char) evnt_keybd () != 'y');
}

/********************************************/
/*   Anfangsbelegung                        */
/********************************************/

Anfangsbelegung ()
{
    register int i, j;

    for (i = 1; i <= Feldgr - 2; i++)
	for (j = 1; j <= Feldgr - 2; j++) {

	    if (rnd (100L) >= Bgrad)
		*(Feld + i * Feldgr + j) = 0;
	    else
		*(Feld + i * Feldgr + j) = rnd ((long) Umschlagsgrenze);
	    *(Hfeld + i * Feldgr + j) = 0;
	}

    for (i = 0; i <= Feldgr - 1; i++) {
	*(Feld + i) = -1;
	*(Feld + i * Feldgr) = -1;
	*(Feld + (i + 1) * Feldgr - 1) = -1;
	*(Feld + Feldgr * (Feldgr - 1) + i) = -1;

	*(Hfeld + i) = -1;
	*(Hfeld + i * Feldgr) = -1;
	*(Hfeld + (i + 1) * Feldgr - 1) = -1;
	*(Hfeld + Feldgr * (Feldgr - 1) + i) = -1;
    }
}

/*****************************/
/* Hilfsfeldneu              */
/*****************************/
Hfeldneu ()
{
    register int i, j;

    for (i = 1; i <= Feldgr - 2; i++)
	for (j = 1; j <= Feldgr - 2; j++)
	    *(Hfeld + i * Feldgr + j) = 0;
}

/********************************************/
/*   grafische Auswertung                   */
/********************************************/

/*****************************/
/* Grafiktext                */
/*****************************/
Text ()
{
    char string[50];

    v_gtext (handle, 410, 20, "************************");
    v_gtext (handle, 410, 40, "*   Infektionsmodell   *");
    v_gtext (handle, 410, 60, "************************");
    v_gtext (handle, 410, 80, " - Moore Nachbarschaft ");
    v_gtext (handle, 410, 100, " - Feld mit Rand        ");
    set_effect = vst_effects (handle, 8);
    v_gtext (handle, 410, 130, "Konstanten :");
    v_gtext (handle, 410, 300, "Berechnung :");
    set_effect = vst_effects (handle, 0);
    sprintf (string, "  Feldgroesse       : %d", Feldgr - 2);
    v_gtext (handle, 410, 150, string);
    sprintf (string, "  Umschlagsgrenze   : %d", Umschlagsgrenze);
    v_gtext (handle, 410, 170, string);
    sprintf (string, "  Infektionsgeschw. : %d", Infgeschw);
    v_gtext (handle, 410, 190, string);
    sprintf (string, "  k1 (krank)        : %d", k1);
    v_gtext (handle, 410, 210, string);
    sprintf (string, "  k2 (infiziert)    : %d", k2);
    v_gtext (handle, 410, 230, string);
    sprintf (string, "  Bedeckungsgrad    : %d", Bgrad);
    v_gtext (handle, 410, 250, string);
    sprintf (string, "  Zufallszahl       : %ld", Zufallszahl);
    v_gtext (handle, 410, 270, string);
    v_gtext (handle, 410, 320, "  Zeitpunkt  : ");
    v_gtext (handle, 410, 340, "  Umschlaege : ");
}

/*****************************/
/* Setze Attribute           */
/*****************************/

Setze_Attribute ()
{
    set_mode = vswr_mode (handle, 1);
    set_perimeter = vsf_perimeter (handle, 0);
    set_color = vsf_color (handle, 1);
}

/*****************************/
/* Hintergrund : schwarz     */
/*****************************/

Hintergrund ()
{
    int pxyarray[4];

    pxyarray[0] = 0;
    pxyarray[1] = 0;
    pxyarray[2] = (400 / (Feldgr - 2)) * (Feldgr - 2);
    pxyarray[3] = (400 / (Feldgr - 2)) * (Feldgr - 2);

    set_interior = vsf_interior (handle, 1);

    vr_recfl (handle, pxyarray);
}

/*****************************/
/* welcher Farbwert ?        */
/*****************************/

Farbe (z)
    int z;

{
    switch (z) {

     case -1:
     case 0:
	 return (8);
	 break;
     default:
	 if (z >= Umschlagsgrenze)
	     return (0);
	 else
	     return (7 - ((7 * z) / Umschlagsgrenze));
	 break;
    }
}

/*****************************/
/* Zeichne Rechteck          */
/*****************************/

Fill_Rectangle (x, y, Schritt, style)
    int x, y, Schritt, style;

{
    int pxyarray[4];

    pxyarray[0] = (y - 1) * Schritt;
    pxyarray[1] = (x - 1) * Schritt;
    pxyarray[2] = y * Schritt;
    pxyarray[3] = x * Schritt;

    switch (style) {

     case 0:
	 set_interior = vsf_interior (handle, 0);
	 vr_recfl (handle, pxyarray);
	 break;
     default:
	 set_interior = vsf_interior (handle, 2);
	 set_style = vsf_style (handle, style);
	 vr_recfl (handle, pxyarray);
	 break;
    }
}

/************************/
/* Auswertfunktion      */
/************************/

Auswertung ()
{
    register int i, j;
    int style, Schritt;

    Schritt = 400 / (Feldgr - 2);

    for (i = 1; i <= Feldgr - 2; i++)
	for (j = 1; j <= Feldgr - 2; j++)
	    if ((style = Farbe (*(Feld + i * Feldgr + j))) != Farbe (*(Hfeld + i * Feldgr + j)))
		Fill_Rectangle (i, j, Schritt, style);
}

/********************************************/
/*    Rekursionsgleichung                   */
/********************************************/

Hilfsfelder ()
{
    register int i, j;

    for (i = 0; i < Feldgr; i++)
	for (j = 0; j < Feldgr; j++) {

	    *(Krank + i * Feldgr + j) = 0;
	    *(Inf + i * Feldgr + j) = 0;

	    if (*(Feld + i * Feldgr + j) >= Umschlagsgrenze)
		*(Krank + i * Feldgr + j) = 1;
	    else if (*(Feld + i * Feldgr + j) > 0)
		*(Inf + i * Feldgr + j) = 1;
	}
}

Rekursion ()
{
    register int i, j, ni, nj;
    int krank, infiziert, infsumme;
    int *ptr;
    char string[50];

    Zeitpunkt = Zeitpunkt + 1l;
    Umschlaege = 0;

    Hilfsfelder ();

    for (i = 1; i <= Feldgr - 2; i++)
	for (j = 1; j <= Feldgr - 2; j++) {

	    switch (*(Feld + i * Feldgr + j)) {

	     case 0:
		 krank = 0;
		 infiziert = 0;

		 for (ni = -1; ni <= 1; ni++)
		     for (nj = -1; nj <= 1; nj++) {
			 krank = krank + *(Krank + (i + ni) * Feldgr + j + nj);
			 infiziert = infiziert + *(Inf + (i + ni) * Feldgr + j + nj);
		     }
		 *(Hfeld + i * Feldgr + j) = krank / k1 + infiziert / k2;
		 break;

	     default:
		 if (*(Feld + i * Feldgr + j) >= Umschlagsgrenze) {
		     *(Hfeld + i * Feldgr + j) = 0;
		     Umschlaege = Umschlaege + 1;
		 } else {
		     infsumme = 0;
		     infiziert = 0;

		     for (ni = -1; ni <= 1; ni++)
			 for (nj = -1; nj <= 1; nj++) {
			     infsumme = infsumme + (*(Inf + (i + ni) * Feldgr + j + nj)
						    * *(Feld + (i + ni) * Feldgr + j + nj));

			     infiziert = infiziert + *(Inf + (i + ni) * Feldgr + j + nj);
			 }
		     *(Hfeld + i * Feldgr + j) = infsumme / infiziert + Infgeschw;
		 }
		 break;
	    }
	}				/* rekursive Schleife */

   /* Kopie */
    ptr = Hfeld;
    Hfeld = Feld;
    Feld = ptr;

}					/* Ende */

/*******************************************************/
main ()
{
    char ch;
    char string[50];

    open_work ();
    hide_mouse ();
    Einlesen ();
    if (Speicherplatz () == 1)
	goto ENDE;
    Setze_Attribute ();
    v_clrwk (handle);
    Hintergrund ();
    Text ();
    Anfangsbelegung ();
    Auswertung ();
    ch = (char) evnt_keybd ();
    Zeitpunkt = 0l;

    while (ch != 'B') {
	Rekursion ();
	if (Cconis () != 0) {
	    ch = Crawcin ();
	    if (ch == 'm') {
		Hintergrund ();
		Hfeldneu ();
	    }
	}

	if (ch == 'w')
	    ch = (char) evnt_keybd ();

	sprintf (string, "%ld", Zeitpunkt);
	v_gtext (handle, 530, 320, string);
	sprintf (string, "%ld    ", Umschlaege);
	v_gtext (handle, 530, 340, string);

	if (ch == 'm')
	    Auswertung ();

	if (ch == 'E') {
	    v_clrwk (handle);
	    Einlesen ();
	    Hintergrund ();
	    Text ();
	    Hfeldneu ();
	    ch = 'm';
	    Zeitpunkt = 0;
	}
    }

    v_clrwk (handle);
    Spfrei ();
    show_mouse ();

  ENDE:
    close_work ();
    return 0;
}
