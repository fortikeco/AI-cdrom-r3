
/* HODGE-C -- A C implementation of Gerhard & Schuster's hodge-podge machine */

/* hodge.h -- program rountine interfaces

   Copyright (C) 1993 Joerg Heitkoetter

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

/* $Id: hodge.h,v 1.2 1993/03/19 11:28:30 heitkoet Exp heitkoet $ */

#ifndef __HODGE_H__
#define __HODGE_H__

#define MAXCELLS	500
#define MAXCOLORS	256
#define MAXTICKS	10000
#define MAXSTATES	3
#define MAXFILELEN	256
#define MAXLINELEN	1024

#define S_SANE		0
#define S_INFECTED	1
#define S_ILL		2

#define V_SANE		0
#define V_ILL		n

#define bool		int
#define TRUE		1
#define FALSE		0

#define COMMENTCHAR	'#'


typedef enum {
      SANE = S_SANE, INFECTED = S_INFECTED, ILL = S_ILL
} cell_s;

typedef unsigned char cell_v;

typedef struct {
      cell_s state;
      cell_v value;
} cell_t, CELL;

typedef cell_t grid_t[MAXCELLS][MAXCELLS];

/* color stuff: RGB 255 colors */
typedef unsigned char color_t[3];

typedef struct {
	unsigned char red;
	unsigned char green;
	unsigned char blue;
} rgb_t, RGB;

typedef rgb_t cmap_t[MAXCOLORS];

/* prototyping */
#include "config.h"
#include "panic.h"
#include "pixmon.h"
#include "proto.h"

#endif /* __HODGE_H__ */
