#if defined(__STDC__) || defined(__cplusplus)
# define PRO(s) s
#else
# define PRO(s) ()
#endif


/* ./hodge.c */
int main PRO((int argc, char **argv));
void usage PRO((int code));
void version PRO((int code));
void warranty PRO((int code));
void hodge PRO((FILE *rep));
void initialize PRO((int seed));
cell_s get_state PRO((int *val));
void report PRO((FILE *rep, int t));
int map PRO((int i));
int scount PRO((int i, int j, cell_s state));
int vsum PRO((int i, int j));
color_t *rgb_color PRO((int val));
void grid2ppm PRO((int t, grid_t grid));
void grid2dump PRO((int t, grid_t grid));
void loadcmap PRO((char *s));
void pixmon PRO((grid_t grid));

#undef PRO
