(-Au diskacc.c {diskacc.h})
diskacc.dll
diskacc.def
llibcdll.lib
doscalls.lib
-AL -LP -X
