(-Zl -DDOSBUG diskapi.c {diskacc.h})
diskint.asm
diskapi.lib
-AS -LL
