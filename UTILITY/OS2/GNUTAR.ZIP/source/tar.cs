(-W1 -Za
tar.c create.c diffarch.c extract.c list.c update.c
port.c buffer.c names.c wildmat.c getoldop.c gnu.c
version.c getopt.c getopt1.c
)
(-W1 -Za getdate.y)
(-W1 -Idiskacc glob.c cwild.c dir_os2.c isfat.c dosname.c disktape.c)
setargv.obj
diskacc.lib
diskapi.lib!
tar.def
tar.bad
tar.exe
-AS -LB -S0x4000
