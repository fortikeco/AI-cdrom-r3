/*  Copyright (C) 1993, 1994, Russell Lang.  All rights reserved.

 This file is part of GSview.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GSVIEW General Public License for more details.

 Everyone is granted permission to copy, modify and redistribute
 this program, but only under the conditions described in the GSVIEW
 General Public License.  A copy of this license is supposed to have been
 given to you along with this program so you can know your rights and
 responsibilities.  It should be in a file named COPYING.  Among other
 things, the copyright notice and this notice must be preserved on all
 copies. */

/* gvcrc.h */
/* Common Resource header file */

#define GSVIEW_VERSION "1994-05-10  1.08 beta"
#define EMX_NEEDED "0.8h"

#define ID_GSVIEW 42

#define IDD_ABOUT 	50
#define IDD_INPUT 	51
#define ID_ANSWER	52
#define ID_PROMPT	53
#define ID_HELP		54

#define IDM_FILEMENU	100
#define IDM_OPEN	101
#define IDM_CLOSE	102
#define IDM_NEXT	103
#define IDM_NEXTSKIP	104
#define IDM_REDISPLAY   105
#define IDM_PREV	106
#define IDM_PREVSKIP	107
#define IDM_GOTO	108
#define IDM_INFO	109
#define IDM_SELECT	110
#define IDM_PRINT	111
#define IDM_PRINTTOFILE 112
#define IDM_SPOOL	113
#define IDM_EXTRACT	114
#define IDM_PSTOEPS	115
#define IDM_EXIT	117
#define IDM_DROP	118
#define IDM_SKIP	119

#define IDM_EDITMENU	150
#define IDM_COPYCLIP	151
#define IDM_PASTETO	152
#define IDM_CONVERT	153
#define IDM_ADDEPSMENU	154
#define IDM_MAKEEPSI	155
#define IDM_MAKEEPST4	156
#define IDM_MAKEEPST	157
#define IDM_MAKEEPSW	158
#define IDM_EXTEPSMENU	159
#define IDM_EXTRACTPS	160
#define IDM_EXTRACTPRE	161
#define IDM_TEXTEXTRACT	162
#define IDM_TEXTFIND	163
#define IDM_TEXTFINDNEXT 164

#define IDM_OPTIONMENU	  174
#define IDM_GSCOMMAND	  175
#define IDM_SOUNDS	  176
#define IDM_SETTINGS	  177
#define IDM_SAVESETTINGS  178
#define IDM_SAFER         179  
#define IDM_SAVEDIR	  180
#define IDM_BUTTONSHOW	  181
#define IDM_QUICK	  182
#define IDM_AUTOREDISPLAY 183
#define IDM_EPSFCLIP	  184
#define IDM_EPSFWARN	  185
#define IDM_IGNOREDSC	  186

#define IDM_ORIENTMENU	200
#define IDM_PORTRAIT	201
#define IDM_LANDSCAPE   202
#define IDM_UPSIDEDOWN  203
#define IDM_SEASCAPE	204
#define IDM_SWAPLANDSCAPE 205

#define IDM_MEDIAMENU	250
#define IDM_RESOLUTION  251
#define IDM_MAGPLUS	252
#define IDM_MAGMINUS	253

#define IDM_DEPTHMENU	260
#define IDM_DEPTHDEF	261
#define IDM_DEPTH1	262
#define IDM_DEPTH4	263
#define IDM_DEPTH8	264
#define IDM_DEPTH16	265
#define IDM_DEPTH24	266

#define IDM_LETTER	301
#define IDM_LETTERSMALL	302
#define IDM_TABLOID	303
#define IDM_LEDGER	304
#define IDM_LEGAL	305
#define IDM_STATEMENT	306
#define IDM_EXECUTIVE	307
#define IDM_A3		308
#define IDM_A4		309
#define IDM_A4SMALL	310
#define IDM_A5		311
#define IDM_B4		312
#define IDM_B5		313
#define IDM_FOLIO	314
#define IDM_QUARTO	315
#define IDM_10X14	316
#define IDM_USERSIZE	317
#define IDM_MEDIALAST	318

#define IDM_HELPMENU	350
#define IDM_HELPCONTENT 351
#define IDM_HELPSEARCH	352
#define IDM_ABOUT	353
#define IDM_MISC	354

/* info dialog box */
#define IDD_INFO	400
#define INFO_FILE	401
#define INFO_TYPE	402
#define INFO_TITLE	403
#define INFO_DATE	404
#define INFO_BBOX	405
#define INFO_ORIENT	406
#define INFO_ORDER	407
#define INFO_DEFMEDIA	408
#define INFO_NUMPAGES	409
#define INFO_PAGE	410
#define INFO_BITMAP	411
#define INFO_ICON	412

#define ABOUT_ICON	451
#define ABOUT_VERSION	452

#define IDD_SOUND	500
#define SOUND_EVENT	501
#define SOUND_FILE	502
#define SOUND_PATH	503
#define SOUND_TEST	504

#define IDD_SPOOL	524
#define SPOOL_PORT	525

#define CANCEL_PCDONE	541

#define IDD_PAGE	550
#define IDD_MULTIPAGE	551
#define PAGE_LIST	552
#define PAGE_ALL	553
#define PAGE_ODD	554
#define PAGE_EVEN	555

#define IDD_DEVICE	560
#define DEVICE_NAME	561
#define DEVICE_RES	562
#define DEVICE_RESTEXT	563
#define DEVICE_PROP	564

#define IDD_PROP	570
#define PROP_NAME	571
#define PROP_VALUE	572

#define IDD_BBOX	590
#define BB_PROMPT	591
#define BB_CLICK	592

/* file filters */
#define FILTER_PS	1
#define FILTER_EPS	2
#define FILTER_EPI	3
#define FILTER_ALL	4
#define FILTER_BMP	5
#define FILTER_TIFF	6
#define FILTER_WMF	7
#define FILTER_TXT	8

/* string constants */
#define IDS_FILTER	601
#define IDS_TITLE	602
#define IDS_HELPFILE	603
#define IDS_WRONGGS	604
#define IDS_BUSY	605
#define IDS_FILENOTFOUND 606
#define IDS_PRINTBUSY	607

#define IDS_FILE	610
#define IDS_NOFILE	611
#define IDS_PAGE	612
#define IDS_NOPAGE	613
#define IDS_LANDSCAPE	614
#define IDS_PORTRAIT	615
#define IDS_ASCEND	616
#define IDS_DESCEND	617
#define IDS_SPECIAL	618
#define IDS_EPSF	619
#define IDS_EPSI	620
#define IDS_EPST	621
#define IDS_EPSW	622
#define IDS_DSC		623
#define IDS_NOTDSC	624
#define IDS_IGNOREDSC   625
#define IDS_PAGEINFO	626

#define IDS_OUTPUTFILE	630
#define IDS_PRINTINGALL	631
#define IDS_PRINTFILE	632
#define IDS_NOSPOOL	633
#define IDS_SELECTPAGE	634
#define IDS_SELECTPAGES	635
#define IDS_TIMEOUT	636
#define IDS_NOTIMER	637
#define IDS_NOTOPEN	638
#define IDS_CANNOTRUN	639
#define IDS_TOOLONG	640
#define IDS_NOMORE	642
#define IDS_GSCOMMAND	643
#define IDS_RES		644
#define	IDS_USERWIDTH	645
#define	IDS_USERHEIGHT	646
#define IDS_BADEPS	647
#define IDS_NOPREVIEW	648
#define IDS_NOTDFNAME   649
#define IDS_PIPEERR	650
#define IDS_CANCELDONE	651
#define IDS_BADCLI      652
#define IDS_TEXTFIND	653
#define IDS_TEXTNOTFIND	654

#define IDS_SOUNDNAME	670
#define IDS_SNDPAGE	671
#define IDS_SNDNOPAGE	672
#define IDS_SNDNONUMBER 673
#define IDS_SNDNOTOPEN	674
#define IDS_SNDERROR	675
#define IDS_SNDTIMEOUT	676
#define IDS_SNDSTART	677
#define IDS_SNDEXIT	678
#define IDS_SOUNDNOMM	679
#define IDS_NONE	680
#define IDS_SPKR	681

/* help topics */
#define IDS_TOPICROOT	701
#define IDS_TOPICOPEN	702
#define IDS_TOPICPRINT	703
#define IDS_TOPICEDIT	704
#define IDS_TOPICGSCMD	705
#define IDS_TOPICSOUND	706
#define IDS_TOPICMEDIA  707
#define IDS_TOPICPSTOEPS 708
#define	IDS_TOPICGOTO    709
#define IDS_TOPICINSTALL 710
#define IDS_TOPICTEXT    711

/* ps_to_eps */
#define IDS_BBPROMPT	750
#define IDS_BBPROMPT1	751
#define IDS_BBPROMPT2	752
#define IDS_BBPROMPT3	753
#define IDS_EPSONEPAGE	754
#define IDS_EPSQPAGES	755
#define IDS_EPSNOBBOX	756
#define IDS_EPSREAD     757

/* wait messages */
#define IDS_WAIT	770
#define IDS_WAITREAD	771
#define IDS_WAITWRITE	772
#define IDS_WAITDRAW	773
#define IDS_WAITGSOPEN	774
#define IDS_WAITGSCLOSE	775
#define IDS_WAITPRINT	776
#define IDS_WAITSEARCH	777

/* filter strings */
#define IDS_FILTER_BASE	800
#define IDS_FILTER_PS	IDS_FILTER_BASE+1
#define IDS_FILTER_EPS	IDS_FILTER_BASE+2
#define IDS_FILTER_EPI	IDS_FILTER_BASE+3
#define IDS_FILTER_ALL	IDS_FILTER_BASE+4
#define IDS_FILTER_BMP	IDS_FILTER_BASE+5
#define IDS_FILTER_TIFF	IDS_FILTER_BASE+6
#define IDS_FILTER_WMF	IDS_FILTER_BASE+7


/* RCDATA resources */
#define IDR_ORIENT	900
#define IDR_EPSFWARN	901
#define IDR_DEVICES	902
#define IDR_PORTS	903
#define IDR_BUTTON	904

/* cursors */
#define IDP_CROSSHAIR  910
