#define	UNTESTED	/* Know about the untested algorithms */
#define	BIN		/* Know about BinHex 5.0 etc. */
#define	JDW		/* Know about Compress It */
#define	STF		/* Know about ShrinkToFit */
#define	LZC		/* Know about MacCompress */
#undef	ASQ		/* Know about AutoSqueeze */
#undef	ARC		/* Know about ArcMac */
#define	PIT		/* Know about PackIt */
#define	SIT		/* Know about StuffIt */
#define	DIA		/* Know about Diamond */
#define	CPT		/* Know about Compactor */
#define	ZMA		/* Know about Zoom */
#define	LZH		/* Know about LHa */
#define	DD		/* Know about DiskDoubler */

