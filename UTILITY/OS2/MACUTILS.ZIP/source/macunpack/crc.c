unsigned long crcinit;

unsigned long (*updcrc)();

