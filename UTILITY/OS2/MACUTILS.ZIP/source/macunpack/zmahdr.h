#define ZMAHDR	"\005\237\032"
#define ZMAHDRS	3
#define ZMAHDRS2	7

