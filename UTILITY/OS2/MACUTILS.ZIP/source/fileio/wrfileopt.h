extern int wrfileopt();
extern void give_wrfileopt();
extern void set_wrfileopt();
extern void set_s_wrfileopt();
extern char *get_wrfileopt();

