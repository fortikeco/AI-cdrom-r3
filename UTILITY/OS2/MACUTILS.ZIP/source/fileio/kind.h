#ifdef SCAN
#define UNIX_NAME	0
#define PACK_NAME	1
#define ARCH_NAME	2
#define	UNKNOWN		16
#define	PROTECTED	17
#define	ERROR		32
#define COPY		33
#endif /* SCAN */

