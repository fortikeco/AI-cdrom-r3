extern char *data_fork, *rsrc_fork;
extern int data_size, rsrc_size;
extern void put_byte();
extern void set_put();
extern void end_put();

