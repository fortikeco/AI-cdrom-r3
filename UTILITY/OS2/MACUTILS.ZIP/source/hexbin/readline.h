extern char line[];

