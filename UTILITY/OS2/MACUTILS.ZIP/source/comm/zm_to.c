#include "comm.h"
#ifdef ZM
#else /* ZM */
int zm_to; /* Keep lint and some compilers happy */
#endif /* ZM */
