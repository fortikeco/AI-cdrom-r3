#define	XM	/* Know about XMODEM */
#undef	YM	/* Know about YMODEM */
#undef	ZM	/* Know about ZMODEM */

