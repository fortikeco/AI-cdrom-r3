#define XMODEM	0
#define YMODEM	1
#define ZMODEM	2

extern int xfertype;
extern int pre_beta;
extern int time_out;

