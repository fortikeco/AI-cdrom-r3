#include "comm.h"
#ifdef YM
#else /* YM */
int ym_from; /* Keep lint and some compilers happy */
#endif /* YM */
