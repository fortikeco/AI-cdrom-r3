/****************************************************************************/
/*																			*/
/*	Make_Draw.c														 		*/
/*	Creates the population window.											*/
/*																			*/
/****************************************************************************/


/*--------------------------------------------------------------------------*/
/*			INCLUDE FILES 													*/
/*--------------------------------------------------------------------------*/

#include "Control.h"
#include "GA.h"
/*#include "Curves.h"*/

/*--------------------------------------------------------------------------*/
/*			EXTERNAL FUNCTIONS 												*/
/*--------------------------------------------------------------------------*/

extern	Repaint();
extern	Resize();

/*--------------------------------------------------------------------------*/
/*			GLOBALS DECLARED HERE											*/
/*--------------------------------------------------------------------------*/

int		G_current_width,	/*current height and width of population window */
		G_current_height;

/*--------------------------------------------------------------------------*/
/*																			*/
/*	MakeDrawWindow															*/
/*	Creates a population window; First it launches a Frame (population_frame)*/
/*	which is a sub-Frame of control_frame.  Each frame holds a Canvas called*/
/*	G_organism_window with a Pixwin called G_organism_pw, and a Panel called*/
/*	G_organism_panel which holds a single toggle.							*/
/*																			*/
/*--------------------------------------------------------------------------*/

MakeDrawWindow ()
{
	Panel pop_label;	/*used to create the label for the population window*/


	/* Create population frame */
	G_population_frame =
		window_create(G_control_frame,FRAME,
			FRAME_LABEL,"Population",
			WIN_SHOW,			TRUE,
			WIN_X,				DRAW_X,
			WIN_Y,				DRAW_Y,
			WIN_WIDTH,			DRAW_WID,
			WIN_HEIGHT,			DRAW_LEN,
			0
		);


	/* Create a panel in the population frame to hold messages */
	pop_label = window_create(G_population_frame,PANEL,0);
	panel_create_item(pop_label,PANEL_MESSAGE,
		PANEL_LABEL_STRING,"Population Window",
		0);
	window_fit_height(pop_label);

	/* Create the canvas */
	G_population_window =
		window_create(G_population_frame, CANVAS,
			CANVAS_AUTO_EXPAND, 		TRUE,
			CANVAS_AUTO_SHRINK, 		TRUE,
			CANVAS_RETAINED,    		TRUE,
			CANVAS_REPAINT_PROC,		Repaint,
			CANVAS_RESIZE_PROC,			Resize,
			0
		);

	/* Get canvas pixwins */
	G_population_pw = canvas_pixwin(G_population_window);

	/* Get canvas font */
	G_population_font = pf_open("usr/lib/fonts/fixedwidthfonts/screen.b.12");


}
