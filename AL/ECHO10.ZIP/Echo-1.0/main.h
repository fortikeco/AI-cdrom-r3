/* $Header: /tmp_mnt/vida/disks/disk5/Users/terry/r/echo/RCS/main.h,v 1.2 1992/09/15 13:35:53 terry Exp $ */

extern char *set_name();
extern void version();
