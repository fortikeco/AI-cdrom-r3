/* $Header: /tmp_mnt/vida/disks/disk5/Users/terry/r/echo/RCS/regmagic.h,v 1.1 1992/10/28 23:45:08 terry Exp $ */
/*
 * The first byte of the regexp internal "program" is actually this magic
 * number; the start node begins in the second byte.
 */
#define	MAGIC	0234
