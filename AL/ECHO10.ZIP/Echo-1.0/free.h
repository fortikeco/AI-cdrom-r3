/* $Header: /tmp_mnt/vida/disks/disk5/Users/terry/r/echo/RCS/free.h,v 1.4 1992/10/22 04:14:17 terry Exp $ */
extern void free_agent_edit();
extern void free_agent();
extern void free_chromosome();
extern void free_site_edit();
extern void free_site();
extern void free_world_edit();
extern void free_world();
