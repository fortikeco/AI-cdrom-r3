extern BOOLEAN legal_schema();
