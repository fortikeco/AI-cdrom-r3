/* $Header: /tmp_mnt/vida/disks/disk5/Users/terry/r/echo/RCS/running.h,v 1.4 1992/11/16 07:05:45 terry Exp terry $ */
extern void continue_world();
extern void pause_world();
extern void run_world();
extern void run_for_x_generations();
extern void run_world_indefinitely();
extern void set_halt_generation();
extern int assign_species_levels();
