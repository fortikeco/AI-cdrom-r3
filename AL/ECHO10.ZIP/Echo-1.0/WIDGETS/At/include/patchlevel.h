/*
 *      patchlevel.h
 *
 *      The AthenaTools Plotter Widget Set - Version 6.0
 *
 *      klin, Sun Jul 19 20:03:23 1992, V6-beta patchlevel 1
 *      klin, Mon Jul 27 14:45:49 1992, V6-beta patchlevel 2
 *      klin, Sun Aug  2 18:25:06 1992, V6-beta patchlevel 3
 *      klin, Fri Aug  7 10:44:41 1992, V6.0
 *      klin, Sat Aug 15 14:21:19 1992, patchlevel 4
 *
 *      SCCSid[] = "@(#) Plotter V6.0  92/08/15  patchlevel.h"
 */

#define VERSION     6.0
#define PATCHLEVEL  4
