/*  VERY_SIMPLE_BUG.PL  */


/*
This is a very simple bug. It heads towards the food until it's in the
same square, then grabs it, and then uses it. To do this, it relies on
the fact that if the food is not being carried, and not in the same
square, smell() returns a direction which has the same name as an action
- forward, back, left, or right. Performing this action will, as it
happens, get the bug either nearer the food, or facing in a more
appropriate direction.
*/


start_thinking.


think( use ) :-
    inventory(+),
    !.

think( grab ) :-
    smell( here ),
    !.

think( Action ) :-
    smell( Action ).


bugdead( _, rerun ).
