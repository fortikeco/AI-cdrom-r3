/*  GB_LEX.PL  */


/*
This is the lexicon used with GB.PL, for PLANNING_BUG.PL. It doesn't
handle the parts of 'be' properly, and (of course) this form of
representation is no use for highly inflected languages.
*/


/*  lexdet( Word+, Syn+, Number+ ):
*/
lexdet(the,the,_).
lexdet(a,a,sing).
lexdet(an,a,sing).


/*  lexadjective( Word+ ):
*/
lexadjective(big).
lexadjective(small).


/*  lexnoun( WordSing+, WordPlur+ ):
*/
lexnoun(boulder,boulders).
lexnoun(bug,bugs).
lexnoun(door,doors).
lexnoun(food,food).
lexnoun(hammer,hammers).
lexnoun(key,keys).
lexnoun(quicksand,quicksands).
lexnoun(rock,rocks).


/*  lexmodal( Word+ ):
*/
lexmodal(can).
lexmodal(could).
lexmodal(do).
lexmodal(does).
lexmodal(shall).
lexmodal(should).
lexmodal(will).
lexmodal(would).


/*  lexverb( Trans-, Pres, Pres3, Past ):
*/
lexverb(tv,drop,drops,dropped).
lexverb(tv,eat,eats,ate).
lexverb(dt,give,gives,gave).
lexverb(iv,go,goes,went).
lexverb(tv,grab,grabs,grabbed).
lexverb(tv,have,has,had).
lexverb(tv,zzzz,is,was).
lexverb(tv,open,opens,opened).
lexverb(tv,see,sees,saw).
lexverb(tv,smash,smashes,smashed).
lexverb(tv,use,uses,used).
lexverb(tv,want,wants,wanted).


/*  lexprep( Word+ ):
*/
lexprep(by).
lexprep(for).
lexprep(from).
lexprep(in).
lexprep(near).
lexprep(of).
lexprep(on).
lexprep(to).
lexprep(with).


/*  lexconj( Word+, Number ):
*/
lexconj(and,plur).
lexconj(or,sing).
