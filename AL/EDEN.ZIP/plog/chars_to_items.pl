/*  CHARS_TO_ITEMS.PL  */


chars_to_items( Chars, Items ) :-
    prolog_eval( chars_to_items(Chars), Items ).
