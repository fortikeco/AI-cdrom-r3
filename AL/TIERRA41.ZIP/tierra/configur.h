/* configur.h  5-8-94  configurable parameters at compile time */
/* Tierra Simulator V4.1: Copyright (c) 1991, 1992, 1993, 1994 */
/* Tom Ray & Virtual Life */
/*
#ifndef lint
static char     sccsid[] = "@(#)configur.h	1.5     7/21/92";
#endif
*/

#include "license.h"

#ifndef CONFIGUR_H
#define CONFIGUR_H
#define VER 4.1

#ifndef PLOIDY
#define PLOIDY 1
#endif /* PLOIDY */

#define MICRO        /* define for micro step debugging */
#define I/O          /* define for buffered input-output */
#define SHADOW
/* #define READPROT  */ /* define to implement read protection of soup */ 
#define WRITEPROT    /* define to implement write protection of soup */
/* #define EXECPROT  */ /* define to implement execute protection of soup */
/* #define ERROR     */ /* use to include error checking code */
/* #define ALCOMM    */ /* define for socket communications */
/* #define MEM_PROF  */ /* profile dynamic memory usage */
/* #define HSEX      */ /* define for haploid, crossover sex */
/* #define KURT      */ /* define for counting executions of only first cpu */

#ifdef I/O
#define GETBUFSIZ 3
#define PUTBUFSIZ 3
#define COMDATBUFSIZ 3
#endif

#define STACK_SIZE 10
#ifdef SHADOW
#define ALOC_REG 8
#define NUMREG 4         /* NUMREG = ALOC_REG / 2 */
#else /* SHADOW */
#define ALOC_REG 4
#define NUMREG 4         /* NUMREG = ALOC_REG */
#endif /* SHADOW */

#define STDIO     0
#define BASIC     1

#ifndef FRONTEND
#define FRONTEND BASIC  /* BASIC or STDIO */
#endif /* FRONTEND */

#ifdef __TURBOC__
#define FRONTEND BASIC
/* #define MEM_CHK */   /* define for DOS external bounds checker */
#endif /* __TURBOC__ */

/* #define CM5node_files */
  /* if defined, each tierra node uses it's own soup_in and td/brea filesk*/
#ifdef CM5node_files
#ifndef CM5
#undef CM5node_files
   /* NOTE: CM5node_files can only be defined if CM5 is also defined */
#endif /* CM5 */
#endif /* CM5node_files */

#ifndef SHELL
#ifdef unix
/* DAN #define SHELL "xterm" */
#define SHELL "csh"
#else /* unix */
#define SHELL "command"
#endif /* unix */
#endif /* SHELL */

/* the following definitions should be provided by the compilers,
   except for IBM3090 which must be manually defined */

/* __TURBOC__  = Turbo C for DOS */
/* OS2_MC      = Microsoft C for OS/2 */
/* IBM3090     = IBM 3090 the compiler will not define this, do it manually */
/* unix        = for unix systems */
/* __GNUC__    = gcc unix compiler */
/* ANSI        = for ANSI environment */

#endif /* CONFIGUR_H */
