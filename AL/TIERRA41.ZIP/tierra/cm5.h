#include <cm/cmmd.h>
 
/* ALLIGN returns the number of bytes necessary to store x as 32-bit words */

#define ALLIGN(x) (((sizeof(x) + 3) >> 2) << 2)

#define GB_TAG(x) ((x >> 29) << 29)


#define CMMD_CheckGenotype_TAG 0

#define CMMD_DivGenBook_CE_TAG (1 << 29)

#define CMMD_DivGenBook_NC_TAG (2 << 29)

#define CMMD_ReapGenBook_TAG (3 << 29)


/* these are the tags for messages coming into the host */

#define TN_data_tag 1
#define GB_data_tag 2

#define add_size_tag 3 
#define delete_size_tag 4 

#define ERROR_MSG_exit_tag 5
#define ERROR_MSG_noexit_tag 6

#define EXTRACT_tag 7

#define ADD_GEN_tag 8

/* end of list of host tags */


#define EJECT_TAG 1000


#define GB_NODE 0 

#define TIERRA_NODE 1 

#define HOST_NODE 2

#define EXP2(a) (1 << (a))

extern NumGBPN ;
extern NumGBPNBits ;
extern GBPNMask ;


typedef struct {
  char           ExtrG[20] ;
  char           Buff[120] ;
  int            size ;
  struct g_list  g ;
} ExtractMsg ;

