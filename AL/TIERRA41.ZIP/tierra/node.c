
/* this entire file is defined only for the CM5 */

#ifdef CM5 

#include "tierra.h"
#include <stdio.h>

int   NumGBPNBits ;
int   GBPNMask ;
int   NumGBPN ;

int   message_flag ;

main(argc,argv)
  int argc ;
  char *argv[] ;

{
  
  extern int   NumGBPNBits ;
  extern int   GBPNMask ;
  extern int   NumGBPN ;

  extern int   message_flag ;

  CMMD_enable_host() ;

  CMMD_fset_io_mode(stdout, CMMD_independent) ;

  if (argc >=  2)
    NumGBPN = atoi(argv[1]) ;
  else
    return ;

  NumGBPNBits = LOG2(NumGBPN) ;
  GBPNMask = NumGBPN - 1 ;

  message_flag = 0 ;

  if (node_type(CMMD_self_address(),NumGBPN) == TIERRA_NODE)
    {
/*      printf("PN %d:i'm a tierra node\n",CMMD_self_address()) ; fflush(stdout) ;  */

      tierra_main(argc-1,argv++) ; 
    }
  else
    {
/*      printf("PN %d: i'm a GB node\n",CMMD_self_address()) ; fflush(stdout) ;  */

      run_genebank_on_nodes(argc-1,argv++) ;
    }

}

#endif /* CM5 */


