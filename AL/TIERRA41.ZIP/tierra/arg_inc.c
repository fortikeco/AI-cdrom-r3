/* ------------------------------------------------------------------------*/
/* arg_inc.c  9-9-92                                                      */
/* Tierra Simulator V4.0: Copyright (c) 1991, 1992 Tom Ray & Virtual Life */
/* this file is a "nice" way to make the arg binary easier to make         */
/* by Daniel Pirone March 1, 1992                                          */
/* ------------------------------------------------------------------------*/
#include "license.h"
#define ARG
#include "portable.c"
#include "genio.c"

/* ------------------------------------------------------------------------*/
