
/* this entire file is defined only for the CM5 */

#ifdef CM5 

#include "tierra.h"
#include <stdio.h>

int LOG2(n) 
int n;
{
  int bits=0;
  while (n >>= 1) bits++;
  return(bits);
}


int hashGB(hash) 
     
     I32s hash ;

{
  extern NumGBPNBits ;
  extern NumGBPN ;
  extern GBPNMask ;

  I32u GBPN, gbpn_hash ;
  int  i ;

  gbpn_hash = 0 ; 

  for(i = 0 ; i < 32 ; i += NumGBPNBits)
    gbpn_hash ^= (hash >> i) ;

  gbpn_hash &= GBPNMask ;   

  GBPN = gbpn_hash * (CMMD_partition_size() / NumGBPN) ;

/* printf("HASHING GB with NumGBPN = %d, NumGBPNBits = %d, GBPNMask = %d, num PNs = %d, hash = %d, and GBPN = %d\n",NumGBPN,NumGBPNBits,GBPNMask,CMMD_partition_size(),hash,GBPN) ; */

  return GBPN ;

}

int node_type(pn,num_genebanks)
     int pn ;
     int num_genebanks ;
{

  if (pn == CMMD_host_node())
    return HOST_NODE ; 

  if (pn % (CMMD_partition_size() / num_genebanks))
    return TIERRA_NODE ;
  else
    return GB_NODE ;
}

#endif /* CM5 */
