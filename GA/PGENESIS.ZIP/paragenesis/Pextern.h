#include "extern.h"
#include <cscomm.h>

extern STRUCTURE:physical ParallelNew;
extern STRUCTURE:physical ParallelOld;
extern int:physical Index;
extern unsigned long:physical PSeed;
extern char:physical PBitstring[];
extern double:physical PVector[];
