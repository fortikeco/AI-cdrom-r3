STRUCTURE:physical ParallelNew;
STRUCTURE:physical ParallelOld;
int:physical Index;
unsigned long:physical PSeed;
char:physical PBitstring[Length+1];
double:physical PVector[Genes];



