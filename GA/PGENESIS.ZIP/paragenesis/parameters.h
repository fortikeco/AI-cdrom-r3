#define Popsize 8192
#define Genes 78
#define Length 30
#define Windowsize 5
#define Savesize 10
