#define TEST 0
#define TEST1 0
# include "genet.h"
/* ver 2 21 Jan 89 */
double random_fr();

select_dead()
{
	int no_of_dead, i;
	int selected[POP];
	double prob1[POP];
	int p;
	double q;

#if TEST
	printf("prob:\n");
	print_darray(prob);
#endif
	
	for (p=0; p<pop; ++p)
	   prob1[pop - p-1] = prob[p];
	  
#if TEST
	printf("prob1:\n");
	print_darray(prob1);
#endif


	for (p=0; p< pop; ++p) dead[p] = 0;

	no_of_dead = 0;
	while (no_of_dead < reprod)		/* mod 1 Jan 89 to use same array as for parents */
	{

		q = random_fr();
		p = 0;
		while (q > prob[p] && p < pop) p++;

#if TEST
		printf("chosen prob = %f: p = %d: dead[pop - p-1] = %d\n",q,pop - p-1,dead[pop - p-1]);
#endif
        	   
	   if ((dead[pop - p-1] == 0)&&(p < pop-1)) {dead[pop - p-1] = 1; no_of_dead++;}   
	}
#if TEST1
for (i = 0; i < pop; ++i) printf("dead array[%d] = %d\n", i, dead[i]);
#endif
}
