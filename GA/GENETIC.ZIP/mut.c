#define TEST 0
#include "genet.h"

mutate()

{
	int taken_col[N], taken_row[K], taken_row1[K], taken_col1[N]; 
	double row_tab[K], col_tab[N], sum;
	int counter, counter_r, counter_c, i,j,v;
	int r,c, r1, c1;
	
	for (i=0; i<k; ++i)
	for (j=0; j<n; ++j)
	   chd[i][j] = par[i][j];
	
	/*-- choose a random number of rows and columns (2 <= r <= k) (etc) --*/
	r = 0;
	while (r < 2) r = random0(k);
	c = 0;
	while (c < 2) c = random0(n);
	
	
	for (i = 0; i < k; ++i) {taken_row[i] = 0;}
	for (j = 0; j < n; ++j) {taken_col[j] = 0;}
	
#if TEST
	printf("select rows r = :%d\n",r);
#endif
	/*-- select r rows at random --*/
	counter = 0;
	while (counter < r)
	{
	   r1 = random0(k); 
	   if (taken_row[r1] == 0) {counter++; taken_row[r1] = 1;}
	}
	
#if TEST
	printf("select cols c = :%d\n",c);
#endif

	/*-- select c columns at random --*/
	counter = 0;
	while (counter < c)
	{
	   c1 = random0(n); 
	   if (taken_col[c1] == 0) {counter++; taken_col[c1] = 1;}
	}


	counter = -1;
	for (r1 = 0; r1 < k; ++r1)
	{ 
	   sum = 0.0;
	   if (taken_row[r1] == 1)
	   { 
		    counter = counter + 1;
		    for (v=0; v<n; ++v) {if (taken_col[v] == 1) sum = sum + par[r1][v];}
		                        
		    row_tab[counter] = sum;
	    }
	  } 
	

	counter = -1;
	for (c1 = 0; c1 < n; ++c1)
	{
		sum = 0;
		if (taken_col[c1] == 1)
		{ 
			counter = counter + 1;
			for (v=0; v<k; ++v){ if (taken_row[v] == 1) sum = sum + par[v][c1];}
	                          
	    	col_tab[counter] = sum;
		}
	} 
#if TEST
     printf("parent: \n");	
	 for (i=0; i<k; ++i){                                               
	 for (j=0; j<n; ++j) {printf("%f   ", par[i][j]);} printf("\n");}   
	 printf("\n\n\n"); 
	
	 printf("taken rows\n"); 
	 for (i=0; i<k; ++i) printf("%d   ", taken_row[i]); 
	 printf("\n"); 
	 printf("taken columns\n"); 
	 for (i=0; i<k; ++i) printf("%d   ", taken_col[i]); 
	 printf("\n\n\n"); 
	
	 printf("row sums\n"); 
	 for (i=0; i<r; ++i) printf("%f   ", row_tab[i]); 
	 printf("\n\n\n"); 
	
	 printf("col sums\n"); 
	 for (i=0; i<c; ++i) printf("%f   ", col_tab[i]); 
	 printf("\n\n\n"); 
#endif
	
#if TEST
	printf("enter init population\n");
#endif

	init_one_population1(r,c, row_tab, col_tab);

#if TEST
	printf("leave init population\n");
#endif

#if TEST	
	 printf("\n i n i t i a l \n"); 
	 for (i=0; i<r; ++i){ 
	 for (j=0; j<c; ++j) printf("%f   ", initial[i][j]); printf("\n");}
	 printf("\n\n\n"); 
#endif	    
	
#if TEST
	printf("enter copy back\n");
#endif
	counter_r = -1;   
	for (i =0; i<k; ++i)
	   {
		    counter_c = -1;
		    if (taken_row[i] == 1) 
		       {
			        counter_r = counter_r +1;
			        for (v=0; v<n; ++v)
			           {
				            if (taken_col[v] == 1) 
				               {
					                counter_c = counter_c +1;
					                chd[i][v] = initial[counter_r][counter_c];
				                }
			            }
		        }
	    }
#if TEST
	 for (i=0; i<k; ++i){ 
	 for (j=0; j<n; ++j) printf("%f   ", chd[i][j]); printf("\n");} 
#endif
}
                                 






