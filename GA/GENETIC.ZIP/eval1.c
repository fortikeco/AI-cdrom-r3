#include "genet.h"

evaluate_population1()
{
int p,i,j,q;
double sum;

for (p=0;p<pop;++p){
   sum=0.0;
   for (i=0; i<k; ++i)
       for (j=0;j<n;++j)
           
          sum = sum + cost[i][j]*(pp[p]->sol[i][j]);
                            
   pp[p]->eval = sum;}
}

