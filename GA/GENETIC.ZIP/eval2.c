#include "genet.h"

evaluate_population2()
{
int p,i,j,q;
double sum;

for (p=0;p<pop;++p){
   sum=0.0;
   for (i=0; i<k; ++i)
       for (j=0;j<n;++j){
           if ((pp[p]->sol[i][j]) > epsilon)
       {sum = sum + fixed + cost[i][j]*(pp[p]->sol[i][j])*(pp[p]->sol[i][j]);}}
                            
   pp[p]->eval = sum;}
}

