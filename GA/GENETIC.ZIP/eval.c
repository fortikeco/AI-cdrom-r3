#include "genet.h"

evaluate_population()
{
int p,i,j,q;
double sum;

for (p=0;p<pop;++p){
   sum=0.0;
   for (i=0; i<k; ++i)
       for (j=0;j<n;++j){
           if ((pp[p]->sol[i][j]) > epsilon)
           {sum = sum + fixed + cost[i][j]*sqrt(pp[p]->sol[i][j]);}}
                            
   pp[p]->eval = sum;}
}

print_values()
{
	int p;
	
	for ( p=0; p < pop; p++) printf("%d:  %f\n",p,pp[p]->eval);
}
