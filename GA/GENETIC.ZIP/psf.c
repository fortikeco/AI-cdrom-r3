#include "genet.h"

print_so_far()
{
	int p;

	printf("value  %f\n", pp[0]->eval);
	
}