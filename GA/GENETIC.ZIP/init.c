#define TEST1 0
#define TEST2 0
#include "genet.h"
double random_fr();
/* version 3 */
/* the procedure takes the sizes (sour_size and dest_size) of a table	*/
/* to be initialized; sour_tab and dest_tab are rows' and columns'		*/
/* constraints to be satisfied */

init_one_population(sour_size, dest_size, sour_tab, dest_tab)
int sour_size, dest_size;
double sour_tab[];
double dest_tab[];
{
    double val, val1, sum;
	int a, z, v, p, i, j;
	int counter, temp_i, temp_j, res_i, res_j, pos, pos_r, pos_c;
	int taken_row[K];
	int taken_col[N];
	double s_tab[K], d_tab[N];
	int taken[K][N];
	double initial1[K][N], initial2[K][N];
	int vtaken[MAXIM];
	int count,r,c,total,W;
	int row = 0;
	int col = 0;
	
#if TEST1	
	 printf("sour_size = %d\n", sour_size); 
	 printf("dest_size = %d\n", dest_size); 
	 for (i=0; i< sour_size; ++i) printf("row %d = %f\n", i, sour_tab[i]); 
	 for (j=0; j< dest_size; ++j) printf("col %d = %f\n", j, dest_tab[j]); 
#endif	
	
	for (i=0; i< sour_size; ++i) s_tab[i] = sour_tab[i];
	for (j=0; j< dest_size; ++j) d_tab[j] = dest_tab[j];
	
	for (i=0; i < sour_size; ++i){
	   for (j=0; j < dest_size; ++j) {initial1[i][j] = taken[i][j]= 0; }}
	
	for (i = 0; i < sour_size; ++i) {taken_row[i] = 0;}
	for (j = 0; j < dest_size; ++j) {taken_col[j] = 0;}
	
	
	for (i = 0; i < sour_size; ++i)
	   if ((sour_tab[i] - 0.0) > epsilon) row = row +1; else 
	       taken_row[i] = 1;
	       
	for (i = 0; i < sour_size; ++i)
	   if (taken_row[i] == 1)      
	       for (j = 0; j < dest_size; ++j)
	            taken[i][j] = 1;
	
	for (i = 0; i < dest_size; ++i)
	   if ((dest_tab[i] - 0.0) > epsilon) col = col +1; else 
	       taken_col[i] = 1;
	   
	for (j = 0; j < dest_size; ++j)
	   if (taken_col[j] == 1)      
	       for (i = 0; i < sour_size; ++i)
	            taken[i][j] = 1;


   
    for (i=0; i < sour_size; ++i)
    for (j=0; j < dest_size; ++j)
       {v = i*dest_size + j; vtaken[v] = taken[i][j];}
       
    W = row*col;
	
    z = 0;

#if TEST2
printf("entering while loop\n");
#endif

    while (z < W) {
       a = random0(W - z);
       r = c = 0;
  
       pos = -10;
       counter = -1;
       i = 0;
       while (pos < i-1) {
          if (vtaken[i] == 0) counter++;
          if (counter == a) pos = i;
          i++;            }
       
       vtaken[pos] = 1;
       pos_r = pos/dest_size;
       pos_c = pos - pos_r * dest_size;
       taken[pos_r][pos_c] = 1;
       
       total = 0;
	   for (j = 0; j < dest_size; ++j)
	      total = total + taken[pos_r][j];
	   if (total == dest_size) r = 1;
	
       total = 0;
	   for (i = 0; i < sour_size; ++i)
	      total = total + taken[i][pos_c];
	   if (total == sour_size) c = 1;
	   
	   	    z++;      


#if TEST1
printf("\n\n");	 
for (i=0; i < sour_size; ++i)                                       
	     {  printf("%d: ",i);
	     	for (j=0; j < dest_size; ++j)                                     
	      		printf("  %d",taken[i][j]);
	      	printf("\n");
	      }
	    printf("\n");   
#endif
       
       res_i = pos_r;
       res_j = pos_c;
       
       if (sour_tab[res_i] < dest_tab[res_j]) val1 = sour_tab[res_i];
       else val1 = dest_tab[res_j];   
       
       if ((r == 0) && (c == 0)) val =  random_fr()*val1;
	   if ((r == 1) || (c == 1)) val = val1;
	   
	   
	   initial1[res_i][res_j] = val;
	   sour_tab[res_i] = sour_tab[res_i] - val;
	   dest_tab[res_j] = dest_tab[res_j] - val;
	   
#if TEST1
printf("r = %d\n", r); 
printf("c = %d\n", c); 
printf("old sour = %f\n", sour_tab[res_i]); 
printf("old dest = %f\n", dest_tab[res_j]);
printf("value1 = %f\n", val1);
printf("value = %f\n", val);

	  
printf("new sour = %f\n", sour_tab[res_i]); 
printf("new dest = %f\n", dest_tab[res_j]);
#endif 
	    
	     }
#if TEST2
printf("leaving while loop\n");
#endif	     
	     
#if TEST1
printf("\n\n");	 
for (i=0; i < sour_size; ++i)                                       
	     {  printf("%d: ",i);
	     	for (j=0; j < dest_size; ++j)                                     
	      		printf("  %f",initial1[i][j]);
	      	printf("\n");
	      }
	    printf("\n");   
#endif
	     
for (i=0; i < sour_size; ++i)                                       
{
   sum = 0.0;
   for (j=0; j < dest_size; ++j)                                     
	  sum = sum + initial1[i][j];
   val = s_tab[i] - sum;
   if (val < epsilon) sour_tab[i] = 0.0; else
   sour_tab[i] = val;
   
   }

for (j=0; j < n; ++j)                                       
{
   sum = 0.0;
   for (i=0; i < sour_size; ++i)                                     
	  sum = sum + initial1[i][j];
   val = d_tab[j] - sum;
   if (val < epsilon) dest_tab[j] = 0.0; else 
   dest_tab[j] = val;
  
   }   
#if TEST2   
   sum = 0.0;
   for (i=0; i < sour_size; ++i)                                     
	  {sum = sum + sour_tab[i]; printf("sour_tab[%d] = %f\n", i, sour_tab[i]);}
	  printf("sum of sour tab = %f\n", sum);
	  
   sum = 0.0;
   for (j=0; j < dest_size; ++j)                                     
	  {sum = sum + dest_tab[j]; printf("dest_tab[%d] = %f\n", j, dest_tab[j]);}
	  printf("sum of dest tab = %f\n", sum);
#endif

for (i=0; i < sour_size; ++i){
	   for (j=0; j < dest_size; ++j) {initial2[i][j] = 0.0;}}
	
	for (i = 0; i < sour_size; ++i) {taken_row[i] = 0;}
	for (j = 0; j < dest_size; ++j) {taken_col[j] = 0;}
	
	row = col = 0;
	
	for (i = 0; i < sour_size; ++i)
	   if (sour_tab[i] > epsilon) row = row +1; else taken_row[i] = 1;
	
	for (i = 0; i < dest_size; ++i)
	   if (dest_tab[i] > epsilon) col = col +1; else taken_col[i] = 1;
	   
#if TEST2
printf("row = %d  col = %d   \n", row, col);
#endif	
	
	while ((row != 0) || (col != 0)){
	   temp_i = random0(row);
	   temp_j = random0(col);
	
	   p = -1; count = -1;
		while (count < temp_i)
		{
			++p;
			if (taken_row[p] == 0) count++;
		}
	   res_i = p;
	
	   p = -1; count = -1;
	   while (count < temp_j){++p;
	      if (taken_col[p] == 0) count++;
	      }
	   res_j = p;   
	   
	   if (sour_tab[res_i] < dest_tab[res_j]) val = sour_tab[res_i];
       else val = dest_tab[res_j];  
	  
	   initial2[res_i][res_j] = val;
	   sour_tab[res_i] = sour_tab[res_i] - val;
	   dest_tab[res_j] = dest_tab[res_j] - val;
	   if (sour_tab[res_i] < epsilon) {taken_row[res_i] = 1; row = row - 1;}
	   if (dest_tab[res_j] < epsilon) {taken_col[res_j] = 1; col = col - 1;}
	   
	   }


 for (i=0; i < sour_size; ++i)                                       
 for (j=0; j < dest_size; ++j)           
      	initial[i][j] = initial1[i][j] + initial2[i][j];	

#if TEST2
	   for (i=0; i < k; ++i)                                       
	     {  printf("%d: ",i);
	     	for (j=0; j < n; ++j)                                     
	      		printf("  %f",initial[i][j]);
	      	printf("\n");
	      }
	    printf("\n");   
#endif




}
/*
double select(x)
double x;
{
double q,p;

q = random_fr();
printf("random = %f\n", q);
p = q*x;
return(p);
}

double min (x,y)
double x,y;
{
	if (x < y) return (x); else return (y);
}

double max (x,y)
double x,y;
{
	if (x < y) return (y); else return (x);
}

*/
random0(p)
int p;
{
	int r;
	
	if (p ==0) return (0); else {r = rand()%p; return(r);}
}

random1(p)
int p;
{
int r;

	if (p ==0) return (0); else {r = rand()%p; return(r+1);}
}

