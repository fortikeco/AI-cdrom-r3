#define TEST 0
#include "genet.h"

crossover()

{
	int i, j;
	
	
	
	
	for (i=0; i<k; ++i)
	for (j=0; j<n; ++j)
	{
	   chd_a[i][j] = cross_1*par_a[i][j] + cross_2*par_b[i][j];
	   chd_b[i][j] = cross_2*par_a[i][j] + cross_1*par_b[i][j];	
	   
	}
}