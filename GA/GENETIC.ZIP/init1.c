#define TEST1 0
#define TEST2 0
#include "genet.h"
double random_fr();
/* version 3 */
/* the procedure takes the sizes (sour_size and dest_size) of a table	*/
/* to be initialized; sour_tab and dest_tab are rows' and columns'		*/
/* constraints to be satisfied */

init_one_population1(sour_size, dest_size, sour_tab, dest_tab)
int sour_size, dest_size;
double sour_tab[];
double dest_tab[];
{
    double val, val1, sum;
	int a, z, v, p, i, j;
	int counter, temp_i, temp_j, res_i, res_j, pos, pos_r, pos_c;
	int taken_row[K];
	int taken_col[N];
	double s_tab[K], d_tab[N];
	int taken[K][N];
	
	int vtaken[MAXIM];
	int count,r,c,total,W;
	int row = 0;
	int col = 0;
	

for (i=0; i < sour_size; ++i){
	   for (j=0; j < dest_size; ++j) {initial[i][j] = 0.0;}}
	
	for (i = 0; i < sour_size; ++i) {taken_row[i] = 0;}
	for (j = 0; j < dest_size; ++j) {taken_col[j] = 0;}
	
	row = col = 0;
	
	for (i = 0; i < sour_size; ++i)
	   if (sour_tab[i] > epsilon) row = row +1; else taken_row[i] = 1;
	
	for (i = 0; i < dest_size; ++i)
	   if (dest_tab[i] > epsilon) col = col +1; else taken_col[i] = 1;
	   
#if TEST2
printf("row = %d  col = %d   \n", row, col);
#endif	
	
	while ((row != 0) || (col != 0)){
	   temp_i = random0(row);
	   temp_j = random0(col);
	
	   p = -1; count = -1;
		while (count < temp_i)
		{
			++p;
			if (taken_row[p] == 0) count++;
		}
	   res_i = p;
	
	   p = -1; count = -1;
	   while (count < temp_j){++p;
	      if (taken_col[p] == 0) count++;
	      }
	   res_j = p;   
	   
	   if (sour_tab[res_i] < dest_tab[res_j]) val = sour_tab[res_i];
       else val = dest_tab[res_j];  
	  
	   initial[res_i][res_j] = val;
	   sour_tab[res_i] = sour_tab[res_i] - val;
	   dest_tab[res_j] = dest_tab[res_j] - val;
	   if (sour_tab[res_i] < epsilon) {taken_row[res_i] = 1; row = row - 1;}
	   if (dest_tab[res_j] < epsilon) {taken_col[res_j] = 1; col = col - 1;}
	   
	   }


#if TEST2
	   for (i=0; i < k; ++i)                                       
	     {  printf("%d: ",i);
	     	for (j=0; j < n; ++j)                                     
	      		printf("  %f",initial[i][j]);
	      	printf("\n");
	      }
	    printf("\n");   
#endif
}

