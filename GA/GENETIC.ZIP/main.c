#define EXTERN
#define TEST 0
#define TEST1  0
#define TEST2  1
#include "genet.h"
#define VERSION 	"version 4.3,  26 Jan 1989"
/* 4.3 - add tab output to loop:  change to _main and psf*/
#define BIG 999999.0

main()
{
	int	v = 0;
	int z;
	double best = BIG;
	double LastBest = BIG;
	
	seed0 = 1;
	k = 0;
	n = 0;
	optimum = MINUSINF;
	
        alpha = 0;

	printf("%s\n", VERSION);

	while ( read_data() != EOF){ 
	    v = 0;
	    best=LastBest=BIG;
		reprod = cross + inver + mutat;

		initialize_population();

		while ((v++ < it) &&  ((best - optimum) > epsilon)) {


                        evaluate_population();
		
			sort_population();
	
			assign_probabilities();
		
			select_parents();

			select_dead();

			replace_population();

			best = pp[0]->eval;
			if (best < LastBest || v == it) {
				printf("loop\t%6d\t", v);
				print_so_far();
				LastBest = best;
			}


		      }

		print_results();
	
	}
	return(0);
}


