#define TEST 0
#include "genet.h"

print_results()

{
int i,j,p;

   printf("\nfinal evaluation %3f\n\n", pp[0]->eval);
   
   
   printf("best population:\n");
   
   for (i = 0; i<k; ++i) {printf("\n");
   for (j = 0; j<n; ++j)
      printf("   %f", pp[0]->sol[i][j]);
      } 
      
   printf("\n\n\n");
#if TEST
   printf("other populations:\n");
   for (p = 1; p < pop; ++p)
   {printf("population %d\n", p);
   for (i = 0; i<k; ++i) {printf("\n");
   for (j = 0; j<n; ++j)
      printf("   %f", pp[p]->sol[i][j]);
      } 
   printf("\n\n\n"); */
   }
#endif
}