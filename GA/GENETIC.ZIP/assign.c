#define TEST 0
#include "genet.h"

assign_probabilities()
{
    double sum;
	int p;
	
	sum = 0.0;
	
	for (p = 0; p < pop; ++p)
	   sum = sum + (pp[p]->eval);
	   
	
	for (p = 0; p < pop; ++p)
	   prob[p] = (sum - (pp[p]->eval))/((pop - 1)*sum);          
	                          
	                          
	for (p = 1; p < pop; ++p)
	   prob[p] = prob[p] + prob[p-1];
	   
#if TEST
	printf("prob:\n");
	print_darray(prob);
#endif

	}

