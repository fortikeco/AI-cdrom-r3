#include "genet.h"

report()
{
int i,j,p;

for (p=0; p<pop; ++p){
   printf("Population = %d", p);
   for (i=0; i < k; ++i){printf("\n");                                       
     for (j=0; j < n; ++j)                                     
      printf("population[%d].sol[%d][%d] = %d\n",p, i, j, population[p].sol[i][j]);   
                         }
   printf("\n\n");
   printf("eval = %ld\n", pp[p]->eval);
   printf("prob = %f\n", prob[p]);
   printf("parents = %d\n", parents[p]);
   printf("dead = %d\n", dead[p]);
   printf("\n\n\n");
                      }
}