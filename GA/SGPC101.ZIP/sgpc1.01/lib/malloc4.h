/*******************************************
	Header file for malloc4
*******************************************/
#ifndef _MALLOC4_H_
#define _MALLOC4_H_

#if __STDC__ || defined(__cplusplus)
#define P_(s) s
#define ANSI_FUNC
#else
#define P_(s) ()
#undef ANSI_FUNC
#endif

/* malloc4.c */
extern unsigned char *malloc1 P_((
  unsigned int size
  ));
extern void free2 P_((
  unsigned char **temp2
  ));
extern unsigned char **malloc2 P_((
  int n2,
  int n1
  ));
extern unsigned char **malloc2c P_((
  int n2,
  int n1
  ));
extern void free3 P_((
  unsigned char ***temp3
  ));
extern unsigned char ***malloc3 P_((
  int n3,
  int n2,
  int n1
  ));
extern unsigned char ***malloc3c P_((
  int n3,
  int n2,
  int n1
  ));
extern void free4 P_((
  unsigned char ****temp4
  ));
extern unsigned char ****malloc4c P_((
  int n4,
  int n3,
  int n2,
  int n1
  ));
extern unsigned char ****malloc4 P_((
  int n4,
  int n3,
  int n2,
  int n1
  ));
extern void getsize2 P_((
  unsigned char **buf,
  int *y_siz,
  int *x_siz
  ));
extern void getsize3 P_((
  unsigned char ***buf,
  int *z_siz,
  int *y_siz,
  int *x_siz
  ));
extern void getsize4 P_((
  unsigned char ****buf,
  int *z_siz,
  int *y_siz,
  int *x_siz,
  int *w_siz
  ));


#endif 
