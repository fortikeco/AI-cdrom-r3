#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<malloc.h>
#include<time.h>

#define flip() rand()%2
#define MIN -32768
#define MAX 32768
#define BIGINT 100000000
#define TRUE 1
#define FALSE 0
#define HEAD 1
#define TAIL 0
#define TRIES 100

typedef float **MATRIX;
typedef float *VECTOR;
typedef int **IMATRIX;
typedef int *IVECTOR;
typedef int FLAG;
typedef int TOSS;
typedef struct {int r; int c;}INDEX;

FILE *input,*output;

float **matrix();
float *vector();

float det();
float evaluate();
float frange_ran();
float get_F();
float x_pow_y();

void oper1();
void oper2();
void oper3();
void oper4();
void oper5();
void oper6();

int **imatrix();
int *ivector();

unsigned long factorial();
int find_sum();
int irange_ran();
int p_equalities();
int x_power_y();

FLAG initialize_x2();
FLAG satis_con();

void assign_probab();
void bi_deci();
void change_coeff();
void copy_matrix();

void find_X();
void find_ac1_ac2();
void find_cum_probab();
void find_final_mat1();
void find_final_mat2();
void find_final_mat3();
void find_limits();
void find_lu1_lu2();
void find_live_die();
void find_new_in_eq();
void find_org_in_eq();
void find_probability();
void find_range();
void find_x1_x2();

void free_vector();
void free_ivector();
void free_matrix();
void free_imatrix();

void get_var_order();
void inverse();
void initialize();
void main();
void mmprod();
void mvprod();
void nrerror();

void optimization();
void print_domains();
void print_equalities();
void print_inequalities();
void print_ivector();
void print_matrix();
void print_population();
void print_vector();

void read_file();
void seed();
void sort();
void swap();
void write_file();




