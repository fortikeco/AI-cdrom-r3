#include "thesis.h"


unsigned long factorial(n)
int n;
{
  unsigned long  tot = 1;

  if(n < 0)
    {  
      printf("\n\n  Negative factorial in routine FACTORIAL \n\n");
      exit(0);
    }

  while(n > 1)
    tot = tot * n--;

  return(tot);
}




