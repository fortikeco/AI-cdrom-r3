#include "thesis.h"

float evaluate(X)
VECTOR X;
{

 return(X[1]*sin(X[2]) + X[3]*X[3] -12.7*X[4]);

}


