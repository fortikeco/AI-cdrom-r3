#include "thesis.h"


void find_probability(p,tot,cart,prob)
int p,              
    tot,            
    cart;           
IMATRIX prob;     
{
  int i,j,        
      mask,ans,v,
      pow2,       
      arr_tot = 1,
      t1,t2;      

IVECTOR arr;      

IMATRIX crossprod;

  crossprod = imatrix(1,cart,1,tot);
  pow2 = x_power_y(2,tot); 
  arr = ivector(1,tot+1);  

  t1 = tot-1;
  t2 = tot;

  for(j=0; j < pow2; j++)
    {
      v = j;
      mask = 1;
      mask <<= t1;
      
      for(i=1; i<=t2; ++i)
	{
	  ans = (((v & mask) == 0) ? '0' : '1');
	  arr[i] = ans - 48;
	  v <<= 1;
	}
      if(find_sum(arr,t2) == p)
	{
	  for(i=1; i<=t2; ++i)
	    crossprod[arr_tot][i] = arr[i];
	  arr_tot++;
	}
    }
  bi_deci(crossprod,prob,cart,tot);
  free_imatrix(crossprod,1,cart,1,tot);
  free_ivector(arr,1,tot+1);

}


int x_power_y(x,y)
int x,y;
{
  int tot = 1,i;
  
  for(i=0; i < y; i++)
    tot = tot * x;
  return(tot);
}


int find_sum(arr,tot)
int tot;
IVECTOR arr;
{
  int i,sum = 0;

  for(i=1; i<=tot; i++)
    sum = sum + arr[i];

  return(sum);
}
