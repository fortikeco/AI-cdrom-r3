#include "thesis.h"

void copy_matrix(mat1,mat2,lr,ur,lc,uc)
int lr,ur,lc,uc;
MATRIX mat1,mat2;
{
  int i,j;

  for(i=lr; i<=ur; i++)
    for(j=lc; j<=uc; j++)
      mat2[i][j] = mat1[i][j];
}


void print_matrix(lr,ur,lc,uc,mat)
int lr,ur,lc,uc;
MATRIX mat;
{
  int i,j;

  for(i=lr; i<=ur; i++)
    {
      fprintf(output,"\n");
      for(j=lc; j<=uc; j++)
	fprintf(output,"%5.2f\t",mat[i][j]);
    }
  fprintf(output,"\n\n");
}


void print_population(r,c,mat)
int r,c;
MATRIX mat;
{
  int i,j;

  fprintf(output,"\tThe Final Population:\n\n");
  for(i = 1; i <= r; i++)
    {
      for(j = 1; j <= c; j++)
	{
	  if(j == c/2+1)
	    fprintf(output,"\t");
	  fprintf(output,"%5.6f\t",mat[i][j]);
	}
      fprintf(output,"\n");
    }
}


void print_vector(arr,l,u)
VECTOR arr;
int l,u;
{
  int i;

  for(i=l; i<=u; i++)
    fprintf(output,"%5.2f\t",arr[i]);
}


void print_ivector(arr,l,u)
int l,u;
IVECTOR arr;
{
  int i;

  for(i=l; i<=u; i++)
    fprintf(output,"%d\t",arr[i]);
  fprintf(output,"\n\n");
}

