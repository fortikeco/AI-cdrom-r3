Genetic Evolution through Combination of Objects (GECO)

GECO is a toolbox for constructing genetic algorithms. It provides a set
of extensible classes and methods designed for generality. Some simple
examples are also provided to illustrate the intended use.

Copyright (C) 1992  George P. W. Williams, Jr.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Author:
    George P. W. Williams, Jr.
    1334 Columbus City Rd.
    Scottsboro, AL 35768
    george@hsvaic.boeing.com

The DEFSYSTEM used is available from Mark Kantrowitz <mkant@CS.CMU.EDU>
It is available for anonymous ftp at a.gp.cs.cmu.edu:/usr/mkant/Public

The DEFRESOURCE used is by Bradford W. Miller <miller@cs.rochester.edu>
and is also available for anonymous ftp from mkant's archive.

Bug reports, improvements, and feature requests should be sent to
george@hsvaic.boeing.com. I will try to respond to them. Ports to other
lisps are also welcome.

GECO should be completely portable among CLtL2 compliant Common Lisps,
though it has presently been tested only with the following lisp
implementations:
 - MCL 2.0 (Apple's Macintosh Common Lisp)

TO USE THIS SOFTWARE
 - Look at the system definition file GECO.system.
   It uses Mark Kantrowitz's portable defsystem, and expects the
   (require :DEFSYSTEM) form to load it.
   It must also be customized so that the logical host GECO: is
   properly defined to point to the directory containing GECO.
 - Evaluate or load GECO.system.  This will define the GECO package
   and system, and define one or two utility functions (depending on
   which Lisp implementation you are using).
 - Evaluate the form (geco:compile-geco).  GECO is now compiled and
   loaded into your environment.  However, this doesn't actually give
   you anything that you can execute.  GECO is a library; you must define
   your own algorithm.
 - An example is provided to illustrate GECO's intended use in the file
   sb-test.lisp.

Version History:
1.0 16-Nov-92	GPW	Initial public release.
