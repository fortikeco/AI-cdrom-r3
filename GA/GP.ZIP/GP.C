/*
	This code was written by 
   		Gary McIntire
		Loral Aerospace
		F8H4A
		Houston, TX. 77258
		713-335-6967 0r 713-335-6000
*/

/*
   This program demonstrates genetic programming, which is like a
genetic algorithm but instead of using the 0's, 1's, and don't cares of
John Holland, the data structures are the lists of LISP.  Since this is
written in C, much of the code is concerned with contructing and
printing the trees that form a function in the LISP language.  A call to
a LISP function is a list whose first element is the name of the function and all remaining elements are arguments. These arguments may be a name representing a variable, or a number, or another list which is interpreted as a function. This recursive structure forms a tree that has numbers and variable names as the terminals of the tree. In this program, the variable names are IN0, IN1, IN2... representing the different analog inputs to this function. The genetic recombination of these trees form different LISP functions of the input variables. These LISP functions are graded by the assign_fitness "C" function and the fittest ones are kept. assign_fitness is the function that you may modify in this code to call a fitness function of your own. Note that xor, parity and sine are given as examples of this.

You can run out of memory quite fast with this program since the
size of a tree is variable. Note that assign_fitness penalizes
a LISP function for having a large number of nodes. If you 
run out of memory, run again with a reduced value for NUM_IND.

There are only 5 functional operators used in this version, plus,
minus, mult, divide, and iflte(if less than or equal). These are
defined with the MAKE_N_OP macros. You can make your own set if
you like. Note that "divide" is a protected divide since the
C "/" would cause a crash in the event of divide by zero.

*/

/* This code runs on a PC but the only PC specific stuff is the 
   keyboard handling. To compile on something else, just make
   the function last_key_equal return a zero. Your program
   will not stop the display but you can figure out how to make it
   do that on your system.
*/



#include <stdlib.h>
#include <stdio.h>
#include <alloc.h>
#include <math.h>



#define NUM_IND 200     /* Number of individuals to have at any one time */
#define NUM_ARGS 4      /* This must be 4 or more since iflte takes 4 args */
#define NUM_INPUTS 4    /* This is the number of inputs. Note xor uses 2.
                           parity uses 4. sine uses 1.                     */

/* This macro calls the function associated with a node */
#define call(_ptr) (*((_ptr)->op))(_ptr) 


struct ind *ind_array[NUM_IND];
float inputs[NUM_INPUTS];
struct ind *new_list;
static int generation = 0;

struct node {
   float (*op)();	/* pointer to the function */
   int terminal;	/* flag 0 means nont a terminal. 1 means constant or variable */
   int numargs;		/* number of arguments for the function */
   struct node *arg[NUM_ARGS]; 	/* pointers to nodes that are the arguments of this function */
   };

struct ind {
   float fitness;	/* each individual has a fitness */
   struct node *tree;	/* each has its function or tree. This points to the root */
   struct ind *next; 	/* Keep them on a list so we can sort them */
   };

void *my_calloc(int num, int siz){
   void *mem = calloc(num, siz);
   if(!mem){ printf("\n Out of memory allocating num %d   size %d", num, siz); exit(0); }
   return(mem);
   }



static int escape_flag = 0;
int last_key = 0;
static int last_key_flag = 0;

int key_press(){
   unsigned char key;
   int stat;
   stat = bioskey(1);
   if(stat){
      key = (0xff & bioskey(0));
      last_key = key;
      last_key_flag = key;
      if(key==0x1b) escape_flag = key;
      if(0x03 == key ){ exit(0); }
      return(key);
      }
   return(0);
   }

/*This checks to see is the last key hit at the keyboard was the argument */
int last_key_equal(char key){
   key_press();
   if(key != last_key_flag) return(0);
   else{
      last_key_flag = 0;
      return(1);
      }
   }

/*  Use this on non-IBM-PC systems 
int last_key_equal(char key){
	return(0);
}
*/

float random_float(float min, float max){
   return(rand() * (max - min) / 32767.0 + min);
   }

static struct node *free_list = 0;
struct node *get_node(){
   struct node *n;
   if(free_list){ 
      n = free_list;
      free_list = *((struct node **)(&(free_list->op)));
      return(n);
      }
   return(my_calloc(1, sizeof(struct node)));
   }

void free_node(struct node *n){
   *((struct node **)(&(n->op))) = free_list;
   free_list = n;
   }


#define op0 (*(n->arg[0]->op))( n->arg[0] )
#define op1 (*(n->arg[1]->op))( n->arg[1] )
#define op2 (*(n->arg[2]->op))( n->arg[2] )
#define op3 (*(n->arg[3]->op))( n->arg[3] )

/* This is the action code of an input node. Just get the value out
   of the input array. Cast it since it since the index is in a pointer
   array. I hate unions. */
float input(struct node *n){ 
   long *index = (long *)&(n->arg[0]);
   return(inputs[*index]);
   }

/* Creator of a node that represents an input variable */
struct node *make_input(long index){ 
   struct node *n = get_node(); 
   long *i = (long *)&(n->arg[0]);
   n->op = &input;
   n->numargs = 1; 
   n->terminal = 1;
   *i = index;
   return(n); 
   } 


/* The action code for a constant node. Get the constant from its
   argument array. Cast again because we all hate unions. */
float constant(struct node *n){ 
   float *f = (float *)&(n->arg[0]);
   return(*f);
   }

/* Code to create a node to represent a constant. Note that the 
   terminal flag is set. */
struct node *make_constant(float value){ 
   struct node *n = get_node();
   float *f = (float *)&(n->arg[0]);
   n-> op = &constant;
   n->numargs = 1; 
   n->terminal = 1;
   *f = value;
   return(n); 
   } 

#define MAKE_1_OP(_name, _make_name, _code) \
float _name(struct node *n){ \
   _code \
   } \
 \
struct node *_make_name(){ \
   struct node *n = get_node(); \
   n->op = &_name; \
   n->numargs = 1; \
   n->terminal = 0; \
   return(n); \
   } 


#define MAKE_2_OP(_name, _make_name, _code) \
float _name(struct node *n){ \
   _code \
   } \
 \
struct node *_make_name(){ \
   struct node *n = get_node(); \
   n->op = & _name; \
   n->numargs = 2; \
   n->terminal = 0; \
   return(n); \
   } 

#define MAKE_4_OP(_name, _make_name, _code) \
float _name(struct node *n){ \
   _code \
   } \
 \
struct node *_make_name(){ \
   struct node *n = get_node(); \
   n->op = &_name; \
   n->numargs = 4; \
   n->terminal = 0; \
   return(n); \
   } 
 
/* Operator definitions below ***************************/


MAKE_2_OP(plus, make_plus, 
    return(op0 + op1); 
    )

MAKE_2_OP(minus, make_minus, 
    return(op0 - op1); 
    )

MAKE_2_OP(mult, make_mult, 
    return(op0 * op1); 
    )

MAKE_2_OP(divide, make_divide, 
    {float opp1 = op1;
    if(opp1 == 0) return(1.0);
     else return(op0 / opp1); 
     }
    )

MAKE_4_OP(iflte, make_iflte, 
   if(op0 <= op1) return(op2); 
   else return(op3);
   )

/*  This makes a random tree of a given depth, linking all the nodes together
    and putting random constants and input variables at the terminals. */
struct node *make_tree(int depth){
   struct node *n;
   depth--;
   if(depth <= 0){
      switch(rand() % 2){
       case 0: return(make_constant(random_float(-1.0, 1.0)));
       case 1: return(make_input(rand() % NUM_INPUTS));
       }}
   switch(rand() % 5) {
       case 0: n = make_plus();
               n->arg[0] = make_tree(depth);
	       n->arg[1] = make_tree(depth);
	       return(n);
       case 1: n = make_minus();
               n->arg[0] = make_tree(depth);
	       n->arg[1] = make_tree(depth);
	       return(n);
       case 2: n = make_mult();
               n->arg[0] = make_tree(depth);
	       n->arg[1] = make_tree(depth);
	       return(n);
       case 3: n = make_divide();
               n->arg[0] = make_tree(depth);
	       n->arg[1] = make_tree(depth);
	       return(n);
       case 4: n = make_iflte();
               n->arg[0] = make_tree(depth);
	       n->arg[1] = make_tree(depth);
	       n->arg[2] = make_tree(depth);
	       n->arg[3] = make_tree(depth);
	       return(n);
       default: printf("\n switch error"); exit(0);
       }
   return(n);
   }
    

struct node *copy_tree(struct node *tree){
   struct node *n= get_node();
   int i;
   if(!n){ printf("\n out of memory in copy_tree"); exit(0); }
   *n = *tree;
   if(!tree->terminal){
      for(i=0; i<tree->numargs; i++) 
         n->arg[i] = copy_tree(tree->arg[i]);
     }
   return(n);
   }
    

/* This is for printing out the tree in a LISP list format so LISPers will
   feel at home. You could rewrite this to be graphical if you like */
void print_tree(struct node *n){
       if(n->op == &plus) {
          printf("(+ ");
          print_tree(n->arg[0]);
          print_tree(n->arg[1]);
          printf(")");
          }
       if(n->op == &minus) {
          printf("(- ");
          print_tree(n->arg[0]);
          print_tree(n->arg[1]);
          printf(")");
          }
       if(n->op == &mult) {
          printf("(* ");
          print_tree(n->arg[0]);
          print_tree(n->arg[1]);
          printf(")");
          }
       if(n->op == &divide) {
          printf("(/ ");
          print_tree(n->arg[0]);
          print_tree(n->arg[1]);
          printf(")");
          }
       if(n->op == &iflte) {
          printf("(iflte ");
          print_tree(n->arg[0]);
          print_tree(n->arg[1]);
          print_tree(n->arg[2]);
          print_tree(n->arg[3]);
          printf(")");
          }
       if(n->op == &constant){
          float *f = (float *)&n->arg[0];
          printf("%f ", *f);
          }
       if(n->op == &input){
          long *l = (long *)&n->arg[0];
          printf("IN%1ld ", *l);
          }
   }

float xor(struct node *tree){
   static float in[] = { .1, .1,
                      .1, .9,
		      .9, .1,
		      .9, .9 };
   static float out[] = {.1, .9, .9, .1 };
   int i;
   float err=0, diff, ans;
   char ch;
static int flag = 0;
if(last_key_equal(' ')){ flag = 1; printf("\n"); }

   for(i=0; i<4; i++){
      inputs[0] = in[2 * i];
      inputs[1] = in[2*i+1];
      ans = call(tree);
if(flag) printf("\n ans %f", ans);
      diff = out[i] - ans;
      err  += diff * diff;
      }
if(flag) getch();
flag = 0;
   return(-err);
   }
      
float parity(struct node *tree){
   static float in[] = { .1, .1, .1, .1,
                         .1, .1, .1, .9,
   		         .1, .1, .9, .1,
		         .1, .1, .9, .9,
			 .1, .9, .1, .1,
                         .1, .9, .1, .9,
   		         .1, .9, .9, .1,
		         .1, .9, .9, .9,
			 .9, .1, .1, .1,
                         .9, .1, .1, .9,
   		         .9, .1, .9, .1,
		         .9, .1, .9, .9,
			 .9, .9, .1, .1,
                         .9, .9, .1, .9,
   		         .9, .9, .9, .1,
		         .9, .9, .9, .9
			  };
   static float out[] = {.1, .9, .9, .1,
   			 .9, .1, .1, .9,
   			 .9, .1, .1, .9,
   			 .1, .9, .9, .1,
			  };
   int i;
   float err=0, diff, ans;
   char ch;
static int flag = 0;
if(last_key_equal(' ')){ flag = 1; printf("\n"); }

   for(i=0; i<16; i++){
      inputs[0] = in[2 * i];
      inputs[1] = in[2*i+1];
      inputs[2] = in[2*i+2];
      inputs[3] = in[2*i+3];
      ans = call(tree);
      diff = out[i] - ans;
if(flag) printf("\n ans %7.5f  expect %7.5f  diff %7.5f", ans, out[i], fabs(diff));
      err  += diff * diff;
      }
if(flag) getch();
flag = 0;
   return(-err);
   }
      
float sine(struct node *tree, int in){
   int i;
   float err=0, diff, ans;
   char ch;
static int flag = 0;
if(in == 0 && last_key_equal(' ')){ flag = 1; printf("\n"); }

   for(i=0; i<25; i++){
      inputs[0] = i;
      ans = call(tree);
if(flag) printf("\n ans %f", ans);
      diff = sin(i * .04 * 2 * 3.14159) - ans;
      err  += diff * diff;
      }
if(flag) getch();
flag = 0;
   return(-err);
   }
      
   

void assign_fitness(){
   int i;
   float x;
   for(i=0; i<NUM_IND; i++){
/*      ind_array[i]->fitness = sine(ind_array[i]->tree, i) 
                            - .01 * count_nodes(ind_array[i]->tree); */
      ind_array[i]->fitness = parity(ind_array[i]->tree) 
                            - .01 * count_nodes(ind_array[i]->tree);  
      }
   }


void sort_trees(){
   int i;
   struct ind *o, *n, *last;
   new_list = ind_array[0];
   new_list->next = 0;
   for(i=1; i<NUM_IND; i++){
      o = ind_array[i];
      last = 0;
      for(n=new_list; n; n=n->next){
         if(o->fitness >= n->fitness) break;
	 last = n;
	 }
      if(last == 0){ o->next = new_list; new_list = o; }
       else { o->next = last->next; last->next = o; }
      }
   for(i=0,n=new_list; n;n=n->next,i++)
      ind_array[i] = n;
   }

int count_operators(struct node *tree){
   int i, cnt = 0;
   if(tree->terminal) return(0);
   for(i=0; i<tree->numargs; i++){
      cnt += count_nodes(tree->arg[i]);
      }
   return(cnt+1);
   }

int count_nodes(struct node *tree){
   int i, cnt = 0;
   if(tree->terminal) return(1);
   for(i=0; i<tree->numargs; i++){
      cnt += count_nodes(tree->arg[i]);
      }
   return(cnt+1);
   }

long count_all_nodes(){
   int i;
   long num = 0;
   for(i=0; i<NUM_IND; i++){
     num += count_nodes(ind_array[i]->tree);
     }
   return(num);
   }
   

static int node_count;
void *node_adr(struct node *tree){
   int i;
   void *ans;
   if(node_count==0) return((void *)-1);
   node_count--;
   if(tree->terminal) return(0);
   for(i=0; i<tree->numargs; i++){
      ans = node_adr(tree->arg[i]);
      if(ans == (void *)-1) return((void *)&(tree->arg[i]));
      if(ans) return(ans);      
      }
   return(0);
   }



void crossover(struct ind *x, struct ind *y){
   int xcnt = count_nodes(x->tree);
   int xcross = rand() % xcnt;
   int ycnt = count_nodes(y->tree);
   int ycross = rand() % ycnt;
   int xarg, yarg;
   void **xx, **yy, **temp;
/*printf("\n node count %3d %3d  cross %3d %3d", xcnt, ycnt, xcross, ycross); */
/*printf("\n    x: "); print_tree(x->tree);
printf("\n    y: "); print_tree(y->tree);
*/
   node_count = xcross;
   xx = xcross ? node_adr(x->tree) : (void *)&(x->tree);
   node_count = ycross;
   yy = ycross ? node_adr(y->tree) : (void *)&(y->tree);
   temp = *xx;
   *xx = *yy;
   *yy = temp;
/*printf("\n newx: "); print_tree(x->tree);
printf("\n newy: "); print_tree(y->tree);
*/
   }

void remove_tree(struct node *tree){
   int i;
   if(!tree->terminal){
      for(i=0; i<tree->numargs; i++){
         remove_tree(tree->arg[i]);
         }
      }
   free_node(tree);
   }
   
   
void crossover_all(){
   int x,y;
   int i, j, cnt = .3 * NUM_IND;
   for(i=0,j=NUM_IND-1; i<cnt; i++, j-=2){
      x = i;
      if(x < 0) x = -x;
      if(x > j-2) x = j-2;
      y = rand() % NUM_IND;
      if(y < 0) y = -y;
      if(y > j-2) y = j-2;
/*printf("\n crossing over %d and %d", (int)x, (int)y); */
      remove_tree(ind_array[j]->tree);
      remove_tree(ind_array[j-1]->tree);
      ind_array[j]->tree = copy_tree(ind_array[x]->tree);
      ind_array[j-1]->tree = copy_tree(ind_array[y]->tree);
      crossover(ind_array[j], ind_array[j-1]);
      }
   }

void mutate_constants(struct node *tree){
   int i;
   if(tree->op == &constant){
      if(rand() & 1) *((float *)(&tree->arg[0])) *= 1.1;
                else *((float *)(&tree->arg[0])) *= .9;
      }
   if(tree->terminal) return;
   for(i=0; i<tree->numargs; i++){
      mutate_constants(tree->arg[i]);
      }
   }

void mutate_all(){
   int i, j, cnt = .3 * NUM_IND;
printf("\nMutating all");
   for(i=0,j=NUM_IND-1; i<cnt; i++, j--){
      remove_tree(ind_array[j]->tree);
      ind_array[j]->tree = copy_tree(ind_array[i]->tree);
      mutate_constants(ind_array[j]->tree);
      }
   }

void init_ind_array(){
   int i;
   int depth = 4;
   struct ind *ind;
   for(i=0; i<NUM_IND; i++){
      ind = my_calloc(1, sizeof(struct ind));
      ind->tree = make_tree(depth);
      ind_array[i] = ind;
      }
   }
      
void print_all_fitness(){
   int i;
   for(i=0; i<NUM_IND; i++){
      printf("\n num_ind %d   fitness %f\n", NUM_IND, ind_array[i]->fitness);
/*      print_tree(ind_array[i]->tree);      */
      }
   }

void print_fitness(){
   int i;
   float avg = 0;
   for(i=0; i<.6*NUM_IND; i++) avg += ind_array[i]->fitness;
   avg = avg / NUM_IND;
   printf("\n %d Avg fitness %9f best %9f\n", i, avg, ind_array[0]->fitness);
   print_tree(ind_array[0]->tree);      
   if(last_key_equal('a')) print_all_fitness();
   }

void run(){
   int i;
   init_ind_array();
   for(i=0; i<NUM_INPUTS; i++) inputs[i] = i;
   for(;;){
      assign_fitness();
      sort_trees();
printf("\n generation %d", generation);
print_fitness();
/*      if(rand() %10 == 0) mutate_all();
        else  */
	crossover_all();
      generation++;
printf("\n num_nodes %ld", count_all_nodes());
}
   }


void main(){
	run();
}


