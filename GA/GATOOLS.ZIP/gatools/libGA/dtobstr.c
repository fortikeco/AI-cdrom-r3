#include <stdio.h>
#include <math.h>

char *
dtobstr (d)				/* dtobstr: double to {0|1}* string (see strtod(3)) */
    double d;
{
    double v;
    char s[BUFSIZ];
    int i, len;

    for (i = BUFSIZ; i > 0; i--)
	s[i] = '\0';
    s[0] = '0';

    len = 0;
    while (pow (2.0, (double) len) <= d)
	len++;

    for (i = 0; i < len; i++) {
	v = pow (2.0, (double) (len - i - 1));

#ifdef DEBUG
	fprintf (stderr, "d=%lg v=%lg d>v=%s (%d bit)\n", d, v, (d > v ? "yes" : "no"), len - i - 1);
#endif

	if (d >= v) {
	    s[i] = '1';
	    d -= v;
	} else
	    s[i] = '0';
    }

    return (s);
}
