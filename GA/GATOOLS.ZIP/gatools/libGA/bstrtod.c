#include <stdio.h>
#include <string.h>
#include <math.h>

double
bstrtod (s)				/* bstrtod: {0|1}* to double (see strtod(3)) */
	char *s;
{
    int i, l;
    double v = 0.0;

    l = strlen (s);
    for (i = 0; i < l; i++) {
	v += (s[i] - '0') * pow (2.0, (double) (l - i - 1));

#ifdef DEBUG
	fprintf (stderr, "bstrtod: %lg\n", v);
#endif

    }
    return (v);
}
