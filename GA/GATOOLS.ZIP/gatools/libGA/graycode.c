Gray (inbuf, outbuf, length)
	char *inbuf, *outbuf;
	register int length;
{
   /* inbuf contains the fixed point integer, one bit per char.
      outbuf gets the Gray coded version, one bit per char. */
    register int i;
    register int last;

    last = 0;
    for (i = 0; i < length; i++) {
	inbuf[i] -= '0';
	outbuf[i] = (inbuf[i] != last);
	last = inbuf[i];
	outbuf[i] += '0';
    }
}

Degray (inbuf, outbuf, length)
	char *inbuf, *outbuf;
	register int length;
{
   /* inbuf contains the Gray code integer, one bit per char.
      outbuf gets the corresponding fixed point integer. */
    register int i;
    register int last;

    last = 0;
    for (i = 0; i < length; i++) {
	inbuf[i] -= '0';
	if (inbuf[i])
	    outbuf[i] = !last;
	else
	    outbuf[i] = last;
	last = outbuf[i];
	outbuf[i] += '0';
    }
}

/*** end of file ***/
