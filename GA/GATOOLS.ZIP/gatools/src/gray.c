#ifndef lint
static char *rcsid = "$Id: gray.c,v 1.1 1992/06/23 08:41:48 joke Exp $";
#endif

/*
 *  gray(1j) -- Copyright (C) 1992 by Joerg Heitkoetter
 *
 *  Systems Analysis Group, LSXI
 *  Department of Computer Science
 *  University of Dortmund, Germany
 *  (joke@ls11.informatik.uni-dortmund.de).
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 1, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/*
 *  gray -- compute Gray-coded bit strings
 */

#include <stdio.h>
#include <string.h>
#include <math.h>


/*** keep ANSI-C happy */
typedef int bool;
int true = 1;
int false = 0;

#include "defs.h"
#include "getopt.h"
#include "stdga.h"


main (argc, argv)
	int argc;
	char **argv;
{
    FILE *fp;
    int c;

    int l;				/* length of bit string */
    int skip = 0;			/* bit strings to skip */
    char *s;				/* the string itself */
    bool degray = false;

    while ((c = getopt (argc, argv, "do:s:")) != EOF)
	switch (c) {
	 case 'd':
	     degray = true;
	     break;

	 case 'o':
	     if (freopen (optarg, "w", stdout) == NULL) {
		 fprintf (stderr, "Cannot open: %s\n", optarg);
		 return (-1);
	     }
	     break;

	 case 's':
	     skip = atoi (optarg);
	     break;

	 default:
	     fprintf (stderr, "usage: %s [-d<egray>] [-o <output>] [-s<kip> <patterns>] file(s)\n", argv[0]);
	     return (-42);
	     break;
	}

    if (!(argc - optind))		/* nothing left */
	gray (stdin, degray, skip);
    else
	for (; optind < argc; optind++) {
	    if ((fp = fopen (argv[optind], "r")) == NULL) {
		fprintf (stderr, "No such file: %s\n", argv[optind]);
		continue;
	    }
	    gray (fp, degray, skip);
	    fclose (fp);
	}
    return (0);
}

void
gray (fp, degray, skip)
	FILE *fp;
	bool degray;
{
    char iline[BUFSIZ];
    char oline[BUFSIZ];
    int l;

    while (skip--) {
	fgets (iline, BUFSIZ,fp);
	printf ("%s", iline);
    }
    while (fgets (iline, BUFSIZ, fp) != NULL) {
	iline[(l = strlen (iline)) - 1] = '\0';
	if (degray) {
		Degray (iline, oline, l);
	} else {
		Gray (iline, oline, l);
	}
	oline [l - 1] = '\0';
	printf ("%s\n", oline);
    }
}
