#ifndef lint
static char *rcsid = "$Id: gap.c,v 1.1 1992/06/23 08:41:48 joke Exp $";
#endif

/*
 *  gap(1) -- Copyright (C) 1992 by Joerg Heitkoetter
 *
 *  Systems Analysis Group, LSXI
 *  Department of Computer Science
 *  University of Dortmund, Germany
 *  (joke@ls11.informatik.uni-dortmund.de).
 *
 *  This program is freeware from the MAGPIE folks; you can redistribute
 *  it and/or modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/*
 *  gap -- compute GA probability distributions
 */

#include <stdio.h>
#include <string.h>
#include <math.h>


/*** keep ANSI-C happy */
typedef int bool;
int true = 1;
int false = 0;

#include "defs.h"
#include "getopt.h"
#include "stdga.h"


main (argc, argv)
    int argc;
    char **argv;
{
    FILE *fp;
    int c;

    int l;				/* length of bit string */
    char *s;				/* the string itself */
    double p = 0.5;			/* probability */
    bool degray = false;		/* true if input is graycoded */

    while ((c = getopt (argc, argv, "do:p:")) != EOF)
	switch (c) {
	 case 'd':
	     degray = true;
	     break;

	 case 'o':
	     if (freopen (optarg, "w", stdout) == NULL) {
		 fprintf (stderr, "Cannot open: %s\n", optarg);
		 return (-1);
	     }
	     break;

	 case 'p':
	     p = atof (optarg);
	     break;

	 default:
	     fprintf (stderr, "usage: %s [-d] [-o <output>] [-p <probability>] file(s)\n", argv[0]);
	     return (-42);
	     break;
	}

    if (!(argc - optind))		/* nothing left */
	gap (stdin, p, degray);
    else
	for (; optind < argc; optind++) {
	    if ((fp = fopen (argv[optind], "r")) == NULL) {
		fprintf (stderr, "No such file: %s\n", argv[optind]);
		continue;
	    }
	    gap (fp, p, degray);
	    fclose (fp);
	}
    return (0);
}

void
gap (fp, p, degray)
    FILE *fp;
    double p;
    bool degray;
{
    char line[BUFSIZ];
    char start[BUFSIZ];
    char dummy[BUFSIZ];

    double x, dx, q, y, v;
    int i, l, n, qp, pp;

    if (fgets (start, BUFSIZ, fp) != NULL) {
	l = strlen (start) - 1;
	start[l] = dummy[l] = '\0';
	q = 1.0 - p;

	if (degray) {
	    Degray (start, dummy, l);
	    x = bstrtod (dummy);
	    Gray (dummy, start, l);
	} else
	    x = bstrtod (start);

#ifdef DEBUG
	printf ("x=%lg s=%s dx=%lg q^%d p^%d q*p=%lg\n", bstrtod (start), start, 0.0, l, 0, pow (q, (double) l));
#else
	printf ("%lg %lg\n", 0.0, pow (q, (double) l));
#endif

	while (fgets (line, BUFSIZ, fp) != NULL) {
	    line[strlen (line) - 1] = '\0';
	    v = bstrtod (line);

	   /* count the bit flips */
	    qp = pp = 0;
	    for (i = 0; i < l; i++) {
		if (start[i] == line[i])
		    qp++;		/* same */
		else
		    pp++;		/* flip */
	    }

	    if (degray) {
		Degray (line, dummy, l);
		v = bstrtod (dummy);
		Gray (dummy, line, l);
	    }

#ifdef DEBUG
	    printf ("x=%lg s=%s dx=%lg q^%d p^%d q*p=%lg\n", v, line, v - x, qp, pp, pow (p, (double) pp) * pow (q, (double) qp));
#else
	    printf ("%lg %lg\n", v - x, pow (p, (double) pp) * pow (q, (double) qp));
#endif

	}
    }
}
