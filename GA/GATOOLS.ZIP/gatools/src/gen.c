#ifndef lint
static char *rcsid = "$Id: gen.c,v 1.1 1992/06/23 08:41:48 joke Exp $";
#endif

/*
 *  gen(1j) -- Copyright (C) 1992 by Joerg Heitkoetter
 *
 *  Systems Analysis Group, LSXI
 *  Department of Computer Science
 *  University of Dortmund, Germany
 *  (joke@ls11.informatik.uni-dortmund.de).
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 1, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/*
 *  gen -- generate bit strings of arbitrary length
 */

#include <stdio.h>
#include <string.h>
#include <math.h>


/*** keep ANSI-C happy */
typedef int bool;
int true = 1;
int false = 0;

#include "defs.h"
#include "getopt.h"
#include "stdga.h"


/***************************************************************/
/*  Rand computes a psuedo-random                              */
/*  double value between 0 and 1, excluding 1.  Randint        */
/*  gives an integer value between l[ow] and h[igh] inclusive. */
/*  (from John Grefenstette's Genesis)                         */
/***************************************************************/

#define INTSIZE		32
#define MASK		~(~0<<(INTSIZE-1))
#define PRIME		65539
#define SCALE		0.4656612875e-9

unsigned int Seed = 12345678;
#define Rand()		((Seed = ((Seed * PRIME) & MASK)) * SCALE)
#define Randint(l,h)	((int) (l + (h - l + 1) * Rand()))


main (argc, argv)
	int argc;
	char **argv;
{
    FILE *fp;
    int c, i;

    bool permute = true;
    bool ascending = false;
    bool descending = false;
    bool random = false;
    bool ngiven = false;

    int n = 1;				/* number of strings to generate */
    int l = 1;				/* length of bit string */
    char *s;				/* the bit string to start from */
    double start = 0.0;			/* the value to start from */

    while ((c = getopt (argc, argv, "adl:n:o:prs:")) != EOF)
	switch (c) {
	 case 'a':
	     ascending = true;
	     permute = descending = random = false;
	     break;

	 case 'd':
	     descending = true;
	     permute = ascending = random = false;
	     break;

	 case 'l':
	     l = atoi (optarg);
	     break;

	 case 'n':
	     n = atoi (optarg);
	     ngiven = true;
	     break;

	 case 'o':
	     if (freopen (optarg, "w", stdout) == NULL) {
		 fprintf (stderr, "Cannot open: %s\n", optarg);
		 return (-1);
	     }
	     break;

	 case 'p':
	     permute = true;
	     random = descending = ascending = false;
	     break;

	 case 'r':
	     random = true;
	     permute = descending = ascending = false;
	     break;

	 case 's':
	     s = optarg;
	     for (i = 0; i < strlen (s); i++) {
		 if (s[i] != '0' && s[i] != '1')
		     break;
	     }
	     if (i < strlen (s)) {
		 start = atof (s);	/* float number */
		 l = strlen (dtobstr (start));
	     } else {
		 start = bstrtod (s);	/* bit pattern */
		 l = strlen (s);
	     }
	     break;

	 default:
	     fprintf (stderr, "usage: %s [-a<scending> | -d<escending> | -p<permute> | -r<andom> ] \
			[-l <length>] [-n <count>] [-s <start>] [-o <output>]\n", argv[0]);
	     return (-42);
	     break;
	}

    if (!(argc - optind))		/* nothing left */
	gen (stdin, permute, ascending, descending, random, ngiven, l, n, start);
    else
	for (; optind < argc; optind++) {
	    if ((fp = fopen (argv[optind], "r")) == NULL) {
		fprintf (stderr, "No such file: %s\n", argv[optind]);
		continue;
	    }
	    gen (fp, permute, ascending, descending, random, ngiven, l, n, start);
	    fclose (fp);
	}
    return (0);
}

void
gen (fp, permute, ascending, descending, random, ngiven, l, n, s)
	FILE *fp;
	bool permute;
	bool ascending;
	bool descending;
	bool random;
	bool ngiven;
	int l;
	int n;
	double s;
{
    int i, j;
    double v;
    char *bits;

    if (permute) {
	bits = dtobstr (s);
	for (j = l - strlen (bits); j > 0; j--)
	    putc ('0', stdout);
	printf ("%s\n", bits);
	if (strlen (bits) > l)
	    l = strlen (bits);
	for (v = 0.0; v < pow (2.0, (double) l); v += 1.0) {
	    if (v != s) {
		bits = dtobstr (v);
		for (j = l - strlen (bits); j > 0; j--)
		    putc ('0', stdout);
		printf ("%s\n", bits);
	    }
	}
    } else if (ascending) {
	if (strlen (dtobstr (s + (double) n)) > l)
	    l = strlen (dtobstr (s + (double) n));
	for (i = 0; i < n; i++, s += 1.0) {
	    bits = dtobstr (s);
	    for (j = l - strlen (bits); j > 0; j--)
		putc ('0', stdout);
	    printf ("%s\n", bits);
	}
    } else if (descending) {
	if (!ngiven) {
	    for (i = (int) s; i >= 0; i--, s -= 1.0) {
		bits = dtobstr (s);
		for (j = l - strlen (bits); j > 0; j--)
		    putc ('0', stdout);
		printf ("%s\n", bits);
	    }
	} else {
	    if (strlen (dtobstr (s + (double) (n - 1))) > l)
		l = strlen (dtobstr (s + (double) (n - 1)));
	    s += (double) (n - 1);
	    for (i = n; i > 0; i--, s -= 1.0) {
		bits = dtobstr (s);
		for (j = l - strlen (bits); j > 0; j--)
		    putc ('0', stdout);
		printf ("%s\n", bits);
	    }
	}
    } else if (random) {
	bits = dtobstr (s);
	for (j = l - strlen (bits); j > 0; j--)
	    putc ('0', stdout);
	printf ("%s\n", bits);
	for (i = n; i > 0; i--) {
	    for (j = 0; j < l; j++)
		printf ("%d", Randint (0, 1));
	    printf ("\n");
	}
    }
}
