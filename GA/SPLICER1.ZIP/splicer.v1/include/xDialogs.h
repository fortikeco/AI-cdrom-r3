/*
 ========================================
 xDialogs.h
 ========================================
*/
#define _H_xDialogs

extern void setParameter(
#   if useFunctionPrototypes
    void
#   endif
);

extern void crossoverProbabilityCB(
#   if useFunctionPrototypes
 	Widget, 
	caddr_t, 
	caddr_t
#   endif
);

extern void mutationProbabilityCB(
#   if useFunctionPrototypes
 	Widget, 
	caddr_t, 
	caddr_t
#   endif
);

extern void updateParamDialog(
#   if useFunctionPrototypes
    void
#   endif
);

extern void okAlert(
#   if useFunctionPrototypes
 	char *
#   endif
);

extern bool yesNoDialog(
#   if useFunctionPrototypes
 	char *
#   endif
);

extern bool okCancelDialog(
#   if useFunctionPrototypes
 	char *
#   endif
);

extern void singleIntEntryDialog(
#   if useFunctionPrototypes
 	int *, 
	char *, 
	char *, 
	int, 
	int
#   endif
);

extern void singleFloatEntryDialog(
#   if useFunctionPrototypes
 	float *, 
	char *, 
	char *, 
	float, 
	float
#   endif
);

extern bool getStringDialog(
#   if useFunctionPrototypes
 	char *, 
	char *, 
	char *
#   endif
);

extern void setUpDialogs(
#   if useFunctionPrototypes
    void
#   endif
);

extern void nameDialogs(
#   if useFunctionPrototypes
    void
#   endif
);

extern void createParamCharDialog(
#   if useFunctionPrototypes
	Widget, 
	Widget
#   endif
);

