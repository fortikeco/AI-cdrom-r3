/*
 ========================================
 gaPopulation.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define	_H_gaPopulation	/* don't include more than once */
#endif

#define ascending 1
#define descending -1

/* data structures */

typedef memberType **populationType;

/* functions */

extern void initPopulation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitPopulation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitPopulation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitPopulation(
#   if useFunctionPrototypes
    int
#   endif
);

extern void savePopulationParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadPopulationParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void createPopulation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void newPopulation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void printPopulation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void sortPopulation(
#   if useFunctionPrototypes
	int
#   endif
);

extern bool checkPopulationStatus(
#   if useFunctionPrototypes
    void
#   endif
);

extern void freePopulation(
#   if useFunctionPrototypes
    void
#   endif
);

extern memberType *binarySearchPop(
#   if useFunctionPrototypes
	fitnessType
#   endif
);

extern unsigned getPopulationSize(
#   if useFunctionPrototypes
    void
#   endif
);

extern void enterPopulationSize(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setPopulationSize(
#   if useFunctionPrototypes
	int
#   endif
);

extern populationType getThePopulation(
#   if useFunctionPrototypes
    void
#   endif
);

extern populationType getTheParentList(
#   if useFunctionPrototypes
    void
#   endif
);

extern populationType getTheLoserList(
#   if useFunctionPrototypes
    void
#   endif
);

