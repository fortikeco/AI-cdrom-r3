/*
 ========================================
 gaFileio.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaFileio		/* don't include more than once */
#endif

#ifndef SAVE
#	define SAVE 0
#endif
#define LOAD 1

/* data structures */

/* functions */

extern void saveParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern void loadParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern void saveState(
#   if useFunctionPrototypes
    void
#   endif
);

extern void loadState(
#   if useFunctionPrototypes
    void
#   endif
);

extern void saveBest(
#   if useFunctionPrototypes
    void
#   endif
);

extern int fgetInt(
#   if useFunctionPrototypes
	FILE *
#   endif
);

extern float fgetFloat(
#   if useFunctionPrototypes
	FILE *
#   endif
);

