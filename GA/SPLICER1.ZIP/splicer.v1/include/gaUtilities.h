/*
 ========================================
 gaUtilities.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC 
#	define _H_gaUtilities		/* don't include more than once */
#endif

/* data structures */

/* functions */

extern unsigned long getBits(
#   if useFunctionPrototypes
	unsigned long, 
	unsigned, 
	unsigned
#   endif
);

extern void die(
#   if useFunctionPrototypes
	char *
#   endif
);

extern void printTime(
#   if useFunctionPrototypes
	short
#   endif
);

