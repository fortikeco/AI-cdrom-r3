/*
 ========================================
 gaSharing.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaSharing /* don't include more than once */
#endif

#define NUMBER_OF_SHARING_OPERATORS 1

#define NO_SHARING		1

/* data structures */

typedef voidFunctionType sharingOperatorType;

typedef operatorStructType sharingOperatorStructType;

/* functions */

extern void initSharing(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitSharing(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitSharing(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitSharing(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveSharingParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadSharingParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern sharingOperatorType getSharingOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern char *getSharingOperatorName(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getSharingOperatorId(
#   if useFunctionPrototypes
    void
#   endif
);

extern sharingOperatorStructType *getSharingOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getNumberOfSharingOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern void chooseSharingOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setSharingOperator(
#   if useFunctionPrototypes
	int
#   endif
);

