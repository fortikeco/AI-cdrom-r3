/*
 ========================================
 tty.interface.h
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_tty.interface		/* don't include more than once */
#endif

#define sufferUserInterface()

/* data structures */

/* functions */

extern void	ttyLoop(
#   if useFunctionPrototypes
    void
#   endif
);


