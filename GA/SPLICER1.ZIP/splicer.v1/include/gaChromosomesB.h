/*
 ========================================
 gaChromosomesB.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaChromosomesB		/* don't include more than once */
#endif

/* data structures */

/* functions */


