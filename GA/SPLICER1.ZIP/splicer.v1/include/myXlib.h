#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>

#define	bool char

/*
    what widget set are we using?
    only one of these should be set true
*/
#define MOTIF   FALSE
#define HPW     TRUE

#if MOTIF
#   include <Xm/Xm.h>
#endif

#if HPW
#   include <Xw/Xw.h>
#endif

/****************************************************************************/
typedef struct _menuStruct {
	char *				name;			/* name of the button */
	void				(*func)();		/* callback to be invoked */
	caddr_t				data;			/* data for the callback */
	struct _menuStruct 	*subMenu;		/* data for submenu of this button */
	int					nSubItems;		/* how many items in the submenu */
	char				*subMenuTitle;	/* title of submenu */
} myMenuStruct;

/****************************************************************************/
/*
    macro for computing the font height
*/
#define fontHeight(f)   ((f)->max_bounds.ascent + \
                         (f)->max_bounds.descent)


/****************************************************************************/
/*
	function headerss
*/
void	beep();
char	*makeClassName(); 
Widget	createOneLineTextEditWidget();
void	checkMenuItem();

#if MOTIF
	void createMenuButtons(); 
#endif

#if HPW
	Widget		createMenuManager();
	WidgetList		createMenuPane();
	void		setTextField();
	void		nameWindow();
#endif
