/*
 ========================================
 gaParametersB.h

	header file for binary string parameters
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaParametersB		/* don't include more than once */
#endif

/* data structures */
 
typedef unsigned long parameterType;

struct parameterStruct {
	unsigned		size;
	parameterType	normalizeFactor;
	parameterType	value;
	float			normalizedValue;
};

/* functions */

extern void initParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitParameters(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveParametersParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadParametersParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void freeParameterArray(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setParameterSizes(
#   if useFunctionPrototypes
	short sizeArray[]
#   endif
);

extern void enterParameterSizes(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setParameterSize(
#   if useFunctionPrototypes
	unsigned,
	unsigned
#   endif
);

extern unsigned getParameterSize(
#   if useFunctionPrototypes
	unsigned
#   endif
);

extern unsigned sumParameterSizes(
#   if useFunctionPrototypes
    void
#   endif
);

extern struct parameterStruct *getParameterArray(
#   if useFunctionPrototypes
    void
#   endif
);

extern parameterType getParameterValue(
#   if useFunctionPrototypes
	int
#   endif
);

extern float getNormalizedParameterValue(
#   if useFunctionPrototypes
	int
#   endif
);

extern void setSameSizeParameters(
#   if useFunctionPrototypes
	bool
#   endif
);

extern void enterSameSizeParametersFlag(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setNormalize(
#   if useFunctionPrototypes
	bool
#   endif
);

extern void enterNormalizeFlag(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setNormalizationFactors(
#   if useFunctionPrototypes
    void
#   endif
);


