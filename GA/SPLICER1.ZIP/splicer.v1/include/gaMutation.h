/*
 ========================================
 gaMutation.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaMutation		/* don't include more than once */
#endif

/* data structures */

typedef voidFunctionType mutationOperatorType;

typedef operatorStructType mutationOperatorStructType;

/* functions */

extern void initMutation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitMutation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitMutation(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitMutation(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveMutationParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadMutationParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern mutationOperatorType getMutationOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern char *getMutationOperatorName(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getMutationOperatorId(
#   if useFunctionPrototypes
    void
#   endif
);

extern mutationOperatorStructType *getMutationOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getNumberOfMutationOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern void chooseMutationOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setMutationOperator(
#   if useFunctionPrototypes
	int
#   endif
);

extern float getMutationProbability(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setMutationProbability(
#   if useFunctionPrototypes
	float
#   endif
);

extern void enterMutationProbability(
#   if useFunctionPrototypes
    void
#   endif
);

