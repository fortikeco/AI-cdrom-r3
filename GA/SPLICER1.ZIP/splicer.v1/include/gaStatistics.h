/*
 ========================================
 gaStatistics.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define	_H_gaStatistics	/* don't include more than once */
#endif

/* data structures */

#define MAX_STAT 400
#define MAX_BEST 10

typedef struct statStruct {
	float	bestEver; 			/* best objective value ever seen */
	float	best;				/* best in current generation     */
	float	average;			/* mean in current generation     */
	float	worst;				/* worst in current generation    */
} statsStructType;

typedef struct {
	long firstGenerationPtr;	/* first generation in current stats array */
	long movingPtr;				/* next slot to add to stats array         */
	long staticPtr;				/* limit slot for adding to stats array    */
	statsStructType data[MAX_STAT]; /* the actual statistics */
} mainStatsStructType;

typedef struct bestStruct {
	fitnessType			fitness[MAX_BEST];
	float  				objectiveValue[MAX_BEST];
	chromosomeType	   *chromosome[MAX_BEST];
} bestStructType;

/* functions */

extern void initStatistics(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitStatistics(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitStatistics(
#   if useFunctionPrototypes
    void
#   endif
);

extern void generateStatistics(
#   if useFunctionPrototypes
    void
#   endif
);

extern void printStatistics(
#   if useFunctionPrototypes
    void
#   endif
);

extern fitnessType getSummedFitness(
#   if useFunctionPrototypes
    void
#   endif
);

extern fitnessType getAverageFitness(
#   if useFunctionPrototypes
    void
#   endif
);

extern float getMaximumValue(
#   if useFunctionPrototypes
    void
#   endif
);

extern float getMinimumValue(
#   if useFunctionPrototypes
    void
#   endif
);

extern float getAverageValue(
#   if useFunctionPrototypes
    void
#   endif
);

extern float getBestValue(
#   if useFunctionPrototypes
    void
#   endif
);

extern float getWorstValue(
#   if useFunctionPrototypes
    void
#   endif
);

extern unsigned getGenerationNumber(
#   if useFunctionPrototypes
    void
#   endif
);

extern chromosomeType *getBestChromosome(
#   if useFunctionPrototypes
    void
#   endif
);

extern float *getBins(
#   if useFunctionPrototypes
    void
#   endif
);

extern mainStatsStructType *getStats(
#   if useFunctionPrototypes
    void
#   endif
);

extern struct bestStruct *getBest(
#   if useFunctionPrototypes
    void
#   endif
);

