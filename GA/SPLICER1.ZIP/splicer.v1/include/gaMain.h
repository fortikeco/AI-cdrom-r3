/*
 ========================================
 gaMain.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#define _H_gaMain					/* only include once */

#define TRUE			1
#define	FALSE			0

	/* which compiler are we using?     */
	/* only one of these should be TRUE */
	
#define THINKC			FALSE	
#define SUN				TRUE
#define RS6000			FALSE
#define TURBOC			FALSE

	/* is the compiler ANSI compatible? */

#define	ANSI			FALSE

	/* set the following flag if the compiler  */ 
	/* is ANSI C compatible and, therefore, if */
	/* function prototypes are required 	   */
	
#define useFunctionPrototypes FALSE

	/* which interface are we building  */
	/* only one of these should be TRUE */

#define MACINTOSH		FALSE
#define X_WINDOWS		TRUE
#define TTY				FALSE

#if THINKC
#	define NUMLONGBITS		32			/* size of Macintosh word (long) */
#	define MAXRAND			RAND_MAX	/* maximum random number */
#	define MAXRANDBITS		15
#endif

#if SUN
#define NUMLONGBITS		32
#define MAXRAND			2147483647
#define MAXRANDBITS		31
#endif

#if RS6000
#define NUMLONGBITS     32
#define MAXRAND         RAND_MAX
#define MAXRANDBITS     15
#endif

#if TURBOC
#	define NUMLONGBITS		32
#	define MAXRAND         32767
#	define MAXRANDBITS		15
#endif

#define FOREVER			for(;;)
#define ESC				27
#define bool			char
#define ON				TRUE
#define OFF				FALSE
#define YES				TRUE
#define NO				FALSE
#define	SAVE			0
#define RESTORE			1
#define NO_ALIAS		-1

#define CURRENT_VALUES  0
#define USER_VALUES     1
#define LOAD_VALUES     2
#define DEFAULT_VALUES  3

/* data structures */

typedef struct {
	unsigned populationChanged	: 1;	/* populationSize has changed		*/
	unsigned populationCreated	: 1;	/* do we have a population?			*/
	unsigned runningGA			: 1;	/* are we in the middle of a run?	*/
	unsigned stop				: 1;	/* stop a run?						*/
} flagsType;

typedef void    (*voidFunctionType)();		/* pointer to void function       */
typedef void   *(*voidPFunctionType)();		/* pointer to void ptr function   */
typedef int     (*intFunctionType)();		/* pointer to int function        */
typedef int    *(*intPFunctionType)();		/* pointer to int ptr function    */
typedef float  (*floatFunctionType)();	/* pointer to float function      */
typedef float *(*floatPFunctionType)();	/* pointer to float ptr function  */

typedef struct {
	voidFunctionType	ptr;
	char				*name;
	bool				available;
	int					alias;
} operatorStructType;

/* functions */

extern void initGA(
#	if useFunctionPrototypes
	void
#	endif
);

extern void preCreateInitGA(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitialize(
#   if useFunctionPrototypes
    char
#   endif
);

extern bool checkRunGA(
#   if useFunctionPrototypes
    void
#   endif
);

extern void runGA(
#   if useFunctionPrototypes
    void
#   endif
);

/* include files */

#if ANSI
#	include <stdio.h>
#	include <stdlib.h>
#	include <math.h>
#	include <time.h>
#else
#	include <stdio.h>
#	include <math.h>
#endif
	
#include "gaUtilities.h"
#include "gaRandom.h"
#include "gaFitness.h"
#include "gaScaling.h"
#include "gaSharing.h"
#include "gaParameters.h"
#include "gaChromosomes.h"
#include "gaMembers.h"
#include "gaPopulation.h"
#include "gaMutation.h"
#include "gaCrossover.h"
#include "gaSelection.h"
#include "gaSampling.h"
#include "gaStatistics.h"
#include "gaFileio.h"

#if MACINTOSH
#	include "macInterface.h"
#	include "macWindow.h"
#	include "macEvent.h"
#	include "macDialog.h"
#	include "macList.h"
#	include "macMenu.h"
#endif

#if X_WINDOWS
#	include "xEvent.h"
#	include "xMenus.h"
#	include "xWindows.h"
#	include "xDialogs.h"
#endif

#if TTY
#	include "ttyInterface.h"
#endif

