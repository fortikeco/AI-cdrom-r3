/*
 ========================================
 gaMembers.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define	_H_gaMembers	/* don't include more than once */
#endif

/* data structures */

typedef unsigned idType;

typedef struct memberStruct {
	chromosomeType	*chromosome;	/* pointer to encoded chromosome */
	float			objectiveValue;	/* value of objective function   */
	fitnessType		fitness;		/* fitness of this chromosome	 */
	fitnessType		cummFitness;	/* cummulative fitness			 */
	float			targetSamplingRate;	/* expected mating count	 */
	float			cummTSR;		/* cummulative tsr 				 */
	unsigned		numberOfMatings;/* actual mating count			 */
} memberType;

typedef memberType *(*memberPFunctionType)();

/* functions */

extern void initMembers(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitMembers(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitMembers(
#   if useFunctionPrototypes
    void
#   endif
);

extern memberType *createMember(
#   if useFunctionPrototypes
    void
#   endif
);

extern int compareMembers(
#   if useFunctionPrototypes
	memberType **,
	memberType **
#   endif
);

extern int inverseCompareMembers(
#   if useFunctionPrototypes
	memberType **,
	memberType **
#   endif
);

