/*
 ========================================
 gaCrossover.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaCrossover					  /* don't include more than once */
#endif

/* data structures */

typedef voidFunctionType crossoverOperatorType;

typedef operatorStructType crossoverOperatorStructType;

/* functions */

extern void initCrossover(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitCrossover(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitCrossover(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitCrossover(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveCrossoverParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadCrossoverParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern crossoverOperatorType getCrossoverOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern char *getCrossoverOperatorName(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getCrossoverOperatorId(
#   if useFunctionPrototypes
    void
#   endif
);

extern crossoverOperatorStructType *getCrossoverOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getNumberOfCrossoverOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern void chooseCrossoverOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setCrossoverOperator(
#   if useFunctionPrototypes
	int
#   endif
);

extern bool weShouldCrossover(
#   if useFunctionPrototypes
    void
#   endif
);

extern float getCrossoverProbability(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setCrossoverProbability(
#   if useFunctionPrototypes
	float
#   endif
);

extern void enterCrossoverProbability(
#   if useFunctionPrototypes
    void
#   endif
);

