/*
 ========================================
 macEvent.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
/*	#define _H_macEvent */		/* don't include more than once */
#endif

#define sufferUserInterface() doEvent();

/* data structures */

/* functions */

/* general functions */

extern void doEvent(void);

extern FILE *openFile(
#   if useFunctionPrototypes
	short type,
	char *prompt,
	char *title
#   endif
);

/* application-specific functions */
