/*
 ========================================
 xMenus.h
 ========================================
*/
#define _H_xMenus

/* file menu */

#define NUMBER_OF_FILE_MENU_OPTIONS	9

#define SAVE_PARAM      0
#define LOAD_PARAM      1
#define SAVE_STATE      3
#define LOAD_STATE      4
#define SAVE_BEST       6
#define QUIT            8

/* control menu */

#define NUMBER_OF_CONTROL_MENU_OPTIONS 5

#define SET_PARAMETERS  0
#define CREATEPOPUL     1
#define RUN             2
#define REINITIALIZE    4

/* windows menu */

#define NUMBER_OF_WINDOWS_MENU_OPTIONS 8

#define STATISTICS_W    0
#define OBJECTIVE_W     1
#define NORM_FIT_W      2
#define USER_W          3
#define TRACE_W         4
#define OPEN_ALL_W      6
#define CLOSE_ALL_W     7

extern void setItem(
#   if useFunctionPrototypes
	WidgetList, 
	int, 
	char *
#   endif
);

extern void enableItem(
#   if useFunctionPrototypes
 	WidgetList, 
	int
#   endif
);

extern void disableItem(
#   if useFunctionPrototypes
 	WidgetList, 
	int
#   endif
);

extern void setUpMenus(
#   if useFunctionPrototypes
    void
#   endif
);

extern void nameMainMenu(
#   if useFunctionPrototypes
    void
#   endif
);

extern void checkWindowsMenu(
#   if useFunctionPrototypes
    void
#   endif
);

extern void updateScalingMenu(
#   if useFunctionPrototypes
 	int
#   endif
);

extern void updateSharingMenu(
#   if useFunctionPrototypes
    int
#   endif
);

extern void updateSelectionMenu(
#   if useFunctionPrototypes
	int
#   endif
);

extern void updateSamplingMenu(
#   if useFunctionPrototypes
 	int
#   endif
);

extern void updateCrossoverMenu(
#   if useFunctionPrototypes
 	int
#   endif
);

extern void updateMutationMenu(
#   if useFunctionPrototypes
 	int
#   endif
);

extern void initGAMenus(
#   if useFunctionPrototypes
    void
#   endif
);

