/*
 ========================================
 gaMainP.h

    main header file for permutations

    written by steven e. bayer
    the mitre corporation
 ========================================
 */

/* constants and macros */

#define _H_gaMainP                  /* only include once */

/* include files */

#include "gaParametersP.h"
#include "gaChromosomesP.h"
#include "gaMutationP.h"
#include "gaCrossoverP.h"

