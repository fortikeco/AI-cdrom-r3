/*
 ========================================
 gaMutationP.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaMutationP		/* don't include more than once */
#endif

#define NUMBER_OF_MUTATION_OPERATORS 2

#   define PERMUT_MUTAT     0
#   define NO_MUTATION      1

/* data structures */

/* functions */


