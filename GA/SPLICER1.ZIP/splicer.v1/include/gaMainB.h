/*
 ========================================
 gaMainB.h

	main header file for binary strings
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#define _H_gaMainB					/* only include once */

/* include files */

#include "gaParametersB.h"
#include "gaChromosomesB.h"
#include "gaMutationB.h"
#include "gaCrossoverB.h"
