/*
 ========================================
 gaFitness.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaFitness		/* don't include more than once */
#endif

/* data structures */

typedef float fitnessType;

/* functions */


extern char *getUserAboutString(
#	if useFunctionPrototypes
	void
#	endif
);

extern void initUser(
#   if useFunctionPrototypes
    void
#   endif
);

extern void onBestDo(
#   if useFunctionPrototypes
    void
#   endif
);

extern fitnessType calcFitness(
#   if useFunctionPrototypes
	float *
#   endif
);


