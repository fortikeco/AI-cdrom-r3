/*
 ========================================
 gaChromosomes.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaChromosomes		/* don't include more than once */
#endif

/* data structures */

typedef unsigned long	chromosomeType;		/* encoded chromosome */

/* functions */

extern void initChromosomes(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitChromosomes(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitChromosomes(
#   if useFunctionPrototypes
    void
#   endif
);

extern void defineChromosomes(
#   if useFunctionPrototypes
    void
#   endif
);

extern chromosomeType *createChromosome(
#   if useFunctionPrototypes
    void
#   endif
);

extern void decodeChromosome(
#   if useFunctionPrototypes
	chromosomeType *
#   endif
);

extern void copyChromosome(
#   if useFunctionPrototypes
	chromosomeType *,
	chromosomeType *
#   endif
);

extern void saveChromosome(
#   if useFunctionPrototypes
	FILE *fp
#   endif
);

extern void printChromosome(
#   if useFunctionPrototypes
	char *,
	chromosomeType *,
	char
#   endif
);

