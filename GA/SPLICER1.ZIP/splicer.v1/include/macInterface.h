/*
 ========================================
 macInterface.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
	#define _H_macInterface		/* don't include more than once */
#endif

#define arrowCursor() InitCursor()
#define watchCursor() SetCursor(*GetCursor(4))

/* data structures */

/* functions */
