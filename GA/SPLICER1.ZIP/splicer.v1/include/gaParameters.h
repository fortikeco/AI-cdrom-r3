/*
 ========================================
 gaParameters.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaParameters		/* don't include more than once */
#endif

/* data structures */

/* functions */

extern void setNumberOfParameters(
#if useFunctionPrototypes
	int
#   endif
);

extern void enterNumberOfParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern unsigned getNumberOfParameters(
#   if useFunctionPrototypes
    void
#   endif
);

#if MACINTOSH
extern void openParamCharDialog(
#   if useFunctionPrototypes
    void
#   endif
);

extern void closeParamCharDialog(
#   if useFunctionPrototypes
    void
#   endif
);

extern void updateParamCharDialog(
#   if useFunctionPrototypes
    void
#   endif
);

extern void doParamCharDialog(
#   if useFunctionPrototypes
    short
#   endif
);

extern void paramCharDialogContentAreaEvent(
#   if useFunctionPrototypes
    EventRecord *theEvent
#   endif
);

extern void activateParamCharDialog(
#   if useFunctionPrototypes
    EventRecord *theEvent
#   endif
);

#endif
