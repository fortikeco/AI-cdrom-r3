/*
 ========================================
 gaCrossoverP.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaCrossoverP					  /* don't include more than once */
#endif

#define NUMBER_OF_CROSSOVER_OPERATORS 4

#define PMX              0
#define CYCLE            1
#define ORDER            2
#define NO_CROSSOVER     3

/* data structures */

/* functions */


