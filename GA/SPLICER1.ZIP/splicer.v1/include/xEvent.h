/*
 ========================================
 xEvent.h
 ========================================
*/

#define _H_xEvent

extern void sufferUserInterface(
#   if useFunctionPrototypes
    void
#   endif
);

extern FILE *openFile(
#   if useFunctionPrototypes
 	int, 
	char *, 
	char *
#   endif
);


