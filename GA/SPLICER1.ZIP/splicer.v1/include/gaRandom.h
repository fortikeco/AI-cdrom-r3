/*
 ========================================
 gaRandom.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaRandom		/* don't include more than once */
#endif

#define frand()		((float)rand() / (float)MAXRAND)

/* data structures */

/* functions */

extern void initRandom(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitRandom(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitRandom(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitRandom(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveRandomParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadRandomParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void seedRandomGen(
#   if useFunctionPrototypes
    void
#   endif
);

extern void enterRandomSeed(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getRandomSeed(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setRandomSeed(
#   if useFunctionPrototypes
	int
#   endif
);

extern bool coinFlip(
#   if useFunctionPrototypes
	float
#   endif
);

extern int rangeRandom(
#   if useFunctionPrototypes
	int,
	int
#   endif
);

extern unsigned long getRandomLong(
#   if useFunctionPrototypes
    void
#   endif
);

