/*
 ========================================
 gaScaling.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaScaling /* don't include more than once */
#endif

#define NUMBER_OF_SCALING_OPERATORS 2

#define LINEAR_SCALING	0
#define NO_SCALING		1

/* data structures */

typedef voidFunctionType scalingOperatorType;

typedef operatorStructType scalingOperatorStructType;

/* functions */

extern void initScaling(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitScaling(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitScaling(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitScaling(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveScalingParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadScalingParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void linearScaling(
#   if useFunctionPrototypes
	unsigned,
	populationType,
	fitnessType,
	fitnessType *,
	fitnessType,
	fitnessType *
#   endif
);

extern fitnessType scale(
#	if useFunctionPrototypes
	fitnessType
#	endif
);

extern scalingOperatorType getScalingOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern char *getScalingOperatorName(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getScalingOperatorId(
#   if useFunctionPrototypes
    void
#   endif
);

extern scalingOperatorStructType *getScalingOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getNumberOfScalingOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern void chooseScalingOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setScalingOperator(
#   if useFunctionPrototypes
	int
#   endif
);

