/*
 ========================================
 macWindow.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
/*	#define _H_macWindow */	/* don't include more than once */
#endif

#define UserWindow		300		/* window ids */
#define FitnessWindow	310
#define ObjectiveWindow	320
#define TraceWindow		330

/* trace windows stuff */

/* define constants for the trace window */

#define EVALUATE	0
#define FITNESS		1
#define SCALE		2
#define SHARE		3
#define REPRODUCE	4
#define SELECT		5
#define SAMPLE		6
#define CROSSOVER	7
#define MUTATION	8

/* functions */

/* general functions */

extern void setUpWindows(void);
extern void doAboutWindow(void);
extern void doAboutApplicationWindow(void);
extern void openAllWindows(void);
extern void closeAllWindows(void);

/* application-specific functions */

extern void openTraceWindow(void);
extern void closeTraceWindow(void);
extern void updateTraceWindow(void);
extern void trace(int);

extern void openFitnessWindow(void);
extern void closeFitnessWindow(void);
extern void updateFitnessWindow(void);

extern void openObjectiveWindow(void);
extern void closeObjectiveWindow(void);
extern void updateObjectiveWindow(void);

extern void openUserWindow(void);
extern void closeUserWindow(void);
extern void updateUserWindow(void);

/* user winodw functions */

extern void initDraw(void);
extern void titleWindow(char *);
extern void eraseWindow(void);
extern void drawLine(int, int, int, int);
extern void drawCircle(int, int, int, bool);
extern void printString(int, int, char *);
extern void printChar(int, int, char);
