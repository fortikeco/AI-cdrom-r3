/*
 ========================================
 gaSampling.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaSampling	/* don't include more than once */
#endif

#define NUMBER_OF_SAMPLING_OPERATORS 11

#define DETERMINISTIC    0
#define EXPECTED_VALUE   1
#define RANKING_METHOD   2
#define ROULETTE         3
#define STOCH_WITH_REP   4
#define STOCH_WOUT_REP   5
#define REM_STOCH_WITH   6
#define REM_STOCH_WOUT   7
#define STOCH_TOURNAMENT 8
#define TOURNAMENT       9
#define UNIVERSAL        10

/* data structures */

typedef voidFunctionType samplingOperatorType;

typedef operatorStructType samplingOperatorStructType;

/* functions */

extern void initSampling(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitSampling(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitSampling(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitSampling(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveSamplingParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadSamplingParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void determistic(
#   if useFunctionPrototypes
    void
#   endif
);

extern void expectedValue(
#   if useFunctionPrototypes
    void
#   endif
);

extern void rankingMethod(
#   if useFunctionPrototypes
    void
#   endif
);

extern void roulette(
#   if useFunctionPrototypes
    void
#   endif
);

extern void remainderStochWithReplacement(
#   if useFunctionPrototypes
    void
#   endif
);

extern void remainderStochWithoutReplacement(
#   if useFunctionPrototypes
    void
#   endif
);

extern void tournament(
#   if useFunctionPrototypes
    void
#   endif
);

extern void universal(
#   if useFunctionPrototypes
    void
#   endif
);

extern samplingOperatorType getSamplingOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern char *getSamplingOperatorName(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getSamplingOperatorId(
#   if useFunctionPrototypes
    void
#   endif
);

extern samplingOperatorStructType *getSamplingOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getNumberOfSamplingOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern void chooseSamplingOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setSamplingOperator(
#   if useFunctionPrototypes
	int
#   endif
);

