/*
 ========================================
 macDialog.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
/*	#define _H_macDialog */	/* don't include more than once */
#endif

/*
#define OK				1
#define CANCEL			2
*/

#define SingleNumberDialog		320		/* dialogs and alerts */
#define YesNoDialog				330
#define BinaryParamCharDialog	340
#define StatisticsDialog 		350
#define OkCancelDialog			360
#define OkAlert					370
#define MessageDialog			380
#define ControlParametersDialog 400
#define ReinitializationDialog	410
#define CreatePopulationDialog	420

#define NumberOfParametersSText			1	/* control dialog items */
#define NumberOfParametersButton		2
#define ParameterCharacteristicsButton	3
#define PopulationSizeSText				4
#define PopulationSizeButton			5
#define ScalingOperatorSText			6
#define ScalingOperatorUItem			7
#define SharingOperatorSText			8
#define SharingOperatorUItem			9
#define SelectionOperatorSText			10
#define	SelectionOperatorUItem			11
#define	SamplingOperatorSText			12
#define SamplingOperatorUItem			13
#define CrossoverOperatorSText			14
#define CrossoverOperatorUItem			15
#define MutationOperatorSText			16
#define MutationOperatorUItem			17
#define CrossoverProbabilitySText		18
#define CrossoverProbabilityButton		19
#define MutationProbabilitySText		20
#define MutationProbabilityButton		21
#define RandomSeedSText					22
#define RandomSeedButton				23

#define ReinitCancelButton				1	/* reinitialize dialog */
#define ReinitOkButton					2
#define ReinitCurrentValuesButton		3
#define ReinitUserValuesButton			4
#define ReinitStoredValuesButton		5
#define ReinitDefaultValuesButton		6

#define StatsGenerationSText			1	/* statistics dialog */
#define StatsGenerationTEdit			2
#define StatsBestEverSText				3
#define StatsBestEverTEdit				4
#define StatsBestSText					5
#define StatsBestTEdit					6
#define	StatsAverageSText				7
#define StatsAverageTEdit				8
#define StatsWorstSText					9
#define StatsWorstTEdit					10

#define OkCancelOkButton				1	/* okCancel dialog */
#define OkCancelCancelButton			2

#define YesNoYesButton					1	/* yesNo dialog */
#define YesNoNoButton					2

#define SingleNumberOkButton			1	/* singleNumber entry dialog */
#define SingleNumberCancelButton		2
#define SingleNumberEText				3




/* functions */

/* general functions */

extern void messageDialog(char *, bool);
extern bool okCancelDialog(char *);
extern bool yesNoDialog(char *);
extern void singleIntEntryDialog(int *, char *, char *, int, int);
extern void singleFloatEntryDialog(float *, char *, char *, float, float);
extern void okAlert(char *);
extern void outlineButton(DialogPtr, short);

/* application-specific functions */

extern int macReinit(void);

extern void openParametersDialog(void);
extern void closeParametersDialog(void);
extern void updateParamDialog(void);

extern void openStatisticsDialog(void);
extern void closeStatisticsDialog(void);
extern void updateStatsDialog(void);

extern void createPopDialog(char *, bool, int, int);

