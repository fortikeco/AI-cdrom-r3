/*
 ========================================
 macMenu.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
/* 	#define _H_macMenu */		/* don't include more than once */
#endif

#define AppleMenu			128		/* menu resource id's */
#define FileMenu			129
#define EditMenu			130
#define ControlMenu			310			/* control menu */
#define OperatorsMenu		320			/* operators menu */
	#define ScalingMenu		21		/* hierarchical menus */
	#define SharingMenu		22
	#define SelectionMenu	23
	#define SamplingMenu	24
	#define CrossoverMenu	25
	#define MutationMenu	26
#define WindowMenu			330			/* window menu */

#define NumberOfAppleMenuOptions	2	/* apple menu items */

#define	AboutSplicerM		1
#define AboutApplicationM	2

#define NumberOfFileMenuOptions	9		/* file menu item numbers */

#define SaveParametersM		1
#define	LoadParametersM		2
#define SaveStateM			4
#define LoadStateM			5
#define SaveSolutionsM		7
#define QuitM				9

#define NumberOfEditMenuOptions 	6	/* edit menu item numbers */

#define UndoM				1		
#define CutM				3
#define	CopyM				4
#define PasteM				5
#define ClearM				6

#define NumberOfControlMenuOptions	5	/* control menu item numbers */

#define SetParametersM		1
#define CreatePopulationM	2
#define RunM				3
#define ReinitializeM		5

#define NumberOfOperatorsMenuOptions 6	/* operators menu item numbers */

#define FitnessScalingM	1
#define FitnessSharingM	2
#define SelectionM		3
#define SamplingM		4
#define	CrossoverM		5
#define MutationM		6

#define NumberOfWindowsMenuOptions	8	/* windows menu item numbers */

#define StatisticsWindowM	1
#define ObjectiveWindowM	2
#define FitnessWindowM		3
#define UserWindowM			4
#define TraceWindowM		5
#define	OpenAllWindowsM		7
#define CloseAllWindowsM	8

/* functions */

/* general functions */

extern void setUpMenus(void);
extern void checkMenuItems(MenuHandle, int, int, int);
extern void popUpOperatorMenu(MenuHandle theMenu, 
								voidFunctionType setOperatorFunction,
								int numberOfOperators,
								int dialogItem,
								int theItem);
extern void drawOperatorPopupMenu(MenuHandle theMenu, int theDialogItem, 
														char *operatorName);

/* application-specific functions */

extern void initGAMenus(void);
extern void setGAMenus(int);
extern void updateScalingMenu(int);
extern void updateSharingMenu(int);
extern void updateSelectionMenu(int);
extern void updateSamplingMenu(int);
extern void updateCrossoverMenu(int);
extern void updateMutationMenu(int);
extern void initScalingMenu(void);
extern void initSharingMenu(void);
extern void initSelectionMenu(void);
extern void initSamplingMenu(void);
extern void initCrossoverMenu(void);
extern void initMutationMenu(void);
