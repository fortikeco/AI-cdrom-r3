/*
 ========================================
 xWindows.h
 ========================================
*/
#define _H_xWindows

/* define constants for the trace window */

#define FITNESS		1
#define SCALE		2
#define SHARE		3
#define SELECT		4
#define SAMPLE		5
#define CROSSOVER	6
#define MUTATION	7

extern void setUpWindows(
#   if useFunctionPrototypes
    void
#   endif
);

extern void createFitnessWindowGC(
#   if useFunctionPrototypes
    void
#   endif
);

extern void addFitnessWindowCallbacks(
#   if useFunctionPrototypes
    void
#   endif
);

extern void updateFitnessWindow(
#   if useFunctionPrototypes
    void
#   endif
);

extern void createObjectiveWindowGC(
#   if useFunctionPrototypes
    void
#   endif
);

extern void addObjectiveWindowCallbacks(
#   if useFunctionPrototypes
    void
#   endif
);

extern void updateObjectiveWindow(
#   if useFunctionPrototypes
    void
#   endif
);

extern void updateStatsDialog(
#   if useFunctionPrototypes
    void
#   endif
);

extern void trace(
#   if useFunctionPrototypes
 	char *
#   endif
);

extern void addUserWindowCallbacks(
#   if useFunctionPrototypes
    void
#   endif
);

extern void updateUserWindow(
#   if useFunctionPrototypes
    void
#   endif
);

extern void eraseWindow(
#   if useFunctionPrototypes
    void
#   endif
);

extern void initDraw(
#   if useFunctionPrototypes
    void
#   endif
);

extern void titleWindow(
#   if useFunctionPrototypes
 	char *
#   endif
);

extern void drawLine(
#   if useFunctionPrototypes
 	int, 
	int, 
	int, 
	int
#   endif
);

extern void drawCircle(
#   if useFunctionPrototypes
 	int, 
	int, 
	int, 
	bool
#   endif
);

extern void printString(
#   if useFunctionPrototypes
 	int, 
	int, 
	char *
#   endif
);

extern void printChar(
#   if useFunctionPrototypes
 	int, 
	int, 
	char
#   endif
);

extern void toggleWindowCB(
#   if useFunctionPrototypes
 	Widget, 
	Widget *, 
	caddr_t
#   endif
);

extern bool isWindowOpen(
#   if useFunctionPrototypes
	Widget w;
#   endif
);

extern void openAllWindowsCB(
#   if useFunctionPrototypes
 	Widget, 
	caddr_t, 
	caddr_t
#   endif
);

extern void closeAllWindowsCB(
#   if useFunctionPrototypes
 	Widget, 
	caddr_t, 
	caddr_t
#   endif
);

extern void nameWindows(
#   if useFunctionPrototypes
    void
#   endif
);

