/*
 ========================================
 gaSelection.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaSelection /* don't include more than once */
#endif

#define NUMBER_OF_SELECTION_OPERATORS 2

#   define PROPORTIONAL     0
#   define LINEAR_RANK      1

/* data structures */

typedef voidFunctionType selectionOperatorType;

typedef operatorStructType selectionOperatorStructType;

/* functions */

extern void initSelection(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitSelection(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitSelection(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitSelection(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveSelectionParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadSelectionParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void proportionalSelection(
#   if useFunctionPrototypes
    void
#   endif
);

extern void linearRankSelection(
#   if useFunctionPrototypes
    void
#   endif
);

extern selectionOperatorType getSelectionOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern char *getSelectionOperatorName(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getSelectionOperatorId(
#   if useFunctionPrototypes
    void
#   endif
);

extern selectionOperatorStructType *getSelectionOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern int getNumberOfSelectionOperators(
#   if useFunctionPrototypes
    void
#   endif
);

extern void chooseSelectionOperator(
#   if useFunctionPrototypes
    void
#   endif
);

extern void setSelectionOperator(
#   if useFunctionPrototypes
	int
#   endif
);

