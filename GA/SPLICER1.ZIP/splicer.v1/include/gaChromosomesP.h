/*
 ========================================
 gaChromosomesP.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaChromosomesP		/* don't include more than once */
#endif

#define permutationType				chromosomeType
#define initPermutations			initChromosomes
#define preCreateInitPermutations	preCreateInitChromosomes 
#define preRunInitPermutations		preRunInitChromosomes
#define definePermutations			defineChromosomes
#define createPermutation			createChromosome
#define decodePermutation			decodeChromosome
#define copyPermutation				copyChromosome
#define savePermutation				saveChromosome
#define printPermutation			printChromosome
#define getPermutationSize			getChromosomeSize

/* data structures */

/* functions */


