/*
 ========================================
 paramSizeList.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
	#define _H_paramSizeList		/* don't include more than once */
#endif

/* data structures */

/* functions */

/* general functions */

/* application-specific functions */

extern void initParamatersSizeList(void);
extern void createParameterSizeList(DialogPtr);
extern void deleteParameterSizeList(DialogPtr);
extern pascal void updateParameterSizeList(WindowPtr, int);
extern void activateParameterSizeList(EventRecord *);
extern void clickParameterSizeList(DialogPtr, EventRecord *);
extern void setParameterSizeListItem(DialogPtr);
extern void resizeParameterSizeList(unsigned);
extern void setParameterSizeListValues(unsigned);

