/*
 ========================================
 gaCrossoverB.h
 
	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaCrossoverB					  /* don't include more than once */
#endif

#define NUMBER_OF_CROSSOVER_OPERATORS 3

#define SINGLEPOINT      0
#define MULTIPOINT       1
#define NO_CROSSOVER     2

/* data structures */

/* functions */


