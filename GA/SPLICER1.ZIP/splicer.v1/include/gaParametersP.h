/*
 ========================================
 gaParametersP.h

	header file for permutation parameters 

	written by steven e. bayer
	the mitre corporation
 ========================================
 */

/* constants and macros */

#if THINKC
#	define _H_gaParametersP		/* don't include more than once */
#endif

/* data structures */
 
typedef unsigned long parameterType;

struct parameterStruct {
	parameterType	value;
};

/* functions */

extern void initParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preCreateInitParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern void preRunInitParameters(
#   if useFunctionPrototypes
    void
#   endif
);

extern void reinitParameters(
#   if useFunctionPrototypes
    int
#   endif
);

extern void saveParametersParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void loadParametersParams(
#   if useFunctionPrototypes
    FILE *fp
#   endif
);

extern void freeParameterArray(
#   if useFunctionPrototypes
    void
#   endif
);

extern struct parameterStruct *getParameterArray(
#   if useFunctionPrototypes
    void
#   endif
);

extern parameterType getParameterValue(
#   if useFunctionPrototypes
	int
#   endif
);

