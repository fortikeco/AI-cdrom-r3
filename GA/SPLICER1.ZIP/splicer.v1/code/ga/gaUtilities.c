/*
 ==============================================================================
 gaUtilities.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module contains various utility functions for the GA tool
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include <ctype.h>

#if	THINKC
#	include <time.h>
#endif

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaUtilities.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */
 
/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

/*
 ========================================
 functions
 ========================================
 */
 
unsigned long getBits(bits, position, nbits)
	/*
	========================================
	:purpose
		return some bits from an unsigned 
		long variable
	:parameters
		bits is the collection of bits from 
		which to steal; position is the bit 
		position at which to start; nbits is 
		the number of bits to steal
	========================================
	*/
 unsigned long bits;
 unsigned position, nbits;
{
	return((bits >> (position+1-nbits)) & ~(~(unsigned long)0 << nbits));
}



void die(msg)
	/*
	========================================
	:purpose
		catastrophic error message and 
		program exit
	========================================
	*/
 char *msg;
{
#	if MACINTOSH
  	SysBeep(1);
  	okAlert(msg);
  	ExitToShell();
#	endif
 
#	if X_WINDOWS | TTY
  	okAlert(msg);
  	exit(-1);
#	endif
}



#if THINKC
void printTime(what)
	/*
	========================================
	:purpose
		start the timer or turn it off and 
		print the number of seconds
	========================================
	*/
 short what;
{
	static clock_t ticks = 0l;
	switch (what) {
		case (ON) :
			ticks = clock();
			break;
		case (OFF) :
			printf("%f seconds\n", (float)(clock()-ticks)/CLOCKS_PER_SEC);
			break;
	}
}
#endif

