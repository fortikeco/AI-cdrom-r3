/*
 ==============================================================================
 gaCrossoverP.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module implements the many crossover operators for permutations
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/
 
/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainP.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaCrossoverP.h; the primary crossover
 header file, gaCrossover.h, externs all
 functions that are common to any
 crossover module
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void pmx(
#   if useFunctionPrototypes
	permutationType *, 
	permutationType *, 
	permutationType *, 
	permutationType *
#   endif
);

void order(
#   if useFunctionPrototypes
	permutationType *, 
	permutationType *, 
	permutationType *, 
	permutationType * 
#   endif
);

void cycle(
#   if useFunctionPrototypes
	permutationType *, 
	permutationType *, 
	permutationType *, 
	permutationType *
#   endif
);

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

static crossoverOperatorStructType crossoverOperators[] = {
    { pmx,	 "Partially Matched", YES, NO_ALIAS },
    { cycle, "Cycle",			  YES, NO_ALIAS },
    { order, "Order",			  YES, NO_ALIAS },
    { NULL,  "None",			  YES, NO_ALIAS }
};

static int currentCrossoverOperator;

static float crossoverProbability;

/*
 ========================================
 functions
 ========================================
 */

void pmx(parent1, parent2, child1, child2)
	/*
	========================================
	:purpose
		implements partially matched 
		crossover for permutation problems
	========================================
	*/
 permutationType *parent1, *parent2, *child1, *child2;
{
	register int i;
	register unsigned 
		permutationSize,
		lowCrossoverPoint,
		highCrossoverPoint,
		highTest;
	
	permutationSize    = getPermutationSize();
	lowCrossoverPoint  = rangeRandom(0, permutationSize-1);
	highCrossoverPoint = rangeRandom(0, permutationSize-1);
	
	copyPermutation(parent1, child1);	
	copyPermutation(parent2, child2);
		
	if ((highTest = highCrossoverPoint + 1) == permutationSize)
		highTest = 0;
	
	if ((lowCrossoverPoint != highCrossoverPoint) &&
		(lowCrossoverPoint != highTest)) {
		i = lowCrossoverPoint;
		while(i != highTest) {
			swapParameter(i, findParameter(parent1[i], child2), child2);
			swapParameter(i, findParameter(parent2[i], child1), child1);
			if (++i >= permutationSize)
				i = 0;
		}
	}
}


	
void order(parent1, parent2, child1, child2)
	/*
	========================================
	:purpose
		implements order crossover for 
		permutation problems
	========================================
	*/
 permutationType *parent1, *parent2, *child1,  *child2;
{
	register int i, j, sum;
	register unsigned 
		permutationSize,
		lowCrossoverPoint,
		highCrossoverPoint,
		highTest;
	
	permutationSize    = getPermutationSize();
	lowCrossoverPoint  = rangeRandom(0, permutationSize-1);
	highCrossoverPoint = rangeRandom(0, permutationSize-1);
	highTest = (highCrossoverPoint > 0) ? highCrossoverPoint-1 
										       : permutationSize-1;
	copyPermutation(parent1, child1);	
	copyPermutation(parent2, child2);
	
	if (lowCrossoverPoint != highCrossoverPoint) {
	
		/* create the holes (hole = -1) */
			
		for (i = j = lowCrossoverPoint; j != highTest; i++) {
			j = i % permutationSize;
			child2[findParameter(parent1[j], child2)] = -1;
			child1[findParameter(parent2[j], child1)] = -1;
		}
			
		/* slide the holes over */

		for (i = highCrossoverPoint;
			 i != lowCrossoverPoint; 
			 i = ((i < permutationSize-1) ? i+1 : 0)) {
			while (child1[i] == -1)
				slideParameter(i, highTest, child1);
			while (child2[i] == -1)
				slideParameter(i, highTest, child2);
		}
			
		/* replace the holes with respective parameters */
					
		for(i = 0; i < permutationSize; i++) {
			if (child1[i] == -1)
				child1[i] = parent2[i];
			if (child2[i] == -1)
				child2[i] = parent1[i];
		}
	}
}


	
void cycle(parent1, parent2, child1, child2)
	/*
	========================================
	:purpose
		implements cycle crossover for 
		permutation problems
	========================================
	*/
 permutationType *parent1, *parent2, *child1, *child2;
{
	register int		i;
	register unsigned	permutationSize;
	
	copyPermutation(parent1, child2);	
	copyPermutation(parent2, child1);
	
	permutationSize    = getPermutationSize();

	child1[i = 0] = parent1[0];					/* cycle for child 1 */
	do {
		i = findParameter(parent2[i], parent1);
		child1[i] = parent1[i];
	} while(parent2[i] != parent1[0]);

	child2[i = 0] = parent2[0];					/* cycle for child 2 */
	do {
		i = findParameter(parent1[i], parent2);
		child2[i] = parent2[i];
	} while(parent1[i] != parent2[0]);
}



/*
 ========================================
 the following functions are common to 
 all crossover modules; the only things
 that might need to change from one
 module to the next would be the following
 initialization functions; all others 
 should work as is
 ========================================
*/

void initCrossover()
    /*
    ========================================
    :purpose
        initialize the crossover module;
        called at program startup and during
        reinitialization; sets up global
        variable initial values
    ========================================
    */
{
    setCrossoverOperator(PMX);
    setCrossoverProbability(0.6);
}



void preCreateInitCrossover()
    /*
    ========================================
    :purpose
        initialize the crossover module;
        called just prior to creating the
        population
    ========================================
    */
{
}



void preRunInitCrossover()
    /*
    ========================================
    :purpose
        initialize the crossover module;
        called just prior to running the GAs
    ========================================
    */
{
}



void reinitCrossover(how)
    /*
    ========================================
    :purpose
        either save or restore all crossover
		global variables; this is called 
		during global reinitialization
    ========================================
    */
 int how;
{
    static int oldCrossoverOperator;
	static float oldCrossoverProbability;

    switch (how) {
        case (SAVE) :
            oldCrossoverOperator = currentCrossoverOperator;
			oldCrossoverProbability = crossoverProbability;
            break;

        case (RESTORE) :
            setCrossoverOperator(oldCrossoverOperator);
			setCrossoverProbability(oldCrossoverProbability);
            break;

        default :
            die("reinitCrossover(): bad how");
            break;
    }
}



void saveCrossoverParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all crossover module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save current crossover operator */

    fprintf(fp, "%d\t\t\tcrossover operator: %s\n", currentCrossoverOperator,
						crossoverOperators[currentCrossoverOperator].name);

	/* save the crossover probability */

	fprintf(fp, "%f\t\t\tcrossover probability\n", crossoverProbability);
}



void loadCrossoverParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all crossover module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the crossover operator */

    setCrossoverOperator(fgetInt(fp));

	/* load the crossover probability */

	setCrossoverProbability(fgetFloat(fp));
}



crossoverOperatorType getCrossoverOperator()
	/*
	========================================
	:purpose
		return a pointer to the current 
		crossover operator
	========================================
	*/
{
    return(crossoverOperators[currentCrossoverOperator].ptr);
}



char *getCrossoverOperatorName()
	/*
	========================================
	:purpose
		return a pointer to the name of the 
		crossover operator
	========================================
	*/
{	
    return(crossoverOperators[currentCrossoverOperator].name);
}



int getCrossoverOperatorId()
	/*
	========================================
	:purpose
		return the id number of the 
		crossover operator
	========================================
	*/
{
    return(currentCrossoverOperator);
}



crossoverOperatorStructType *getCrossoverOperators()
    /*
    ========================================
    :purpose
        return a pointer to the crossover
        operator array
    ========================================
    */
{
    return(crossoverOperators);
}



int getNumberOfCrossoverOperators()
    /*
    ========================================
    :purpose
        return the number of crossover
        operators defined in gaCrossover.h
    ========================================
    */
{
    return(NUMBER_OF_CROSSOVER_OPERATORS);
}



#if TTY
void chooseCrossoverOperator()
	/*
	========================================
	:purpose
		allow the user to choose the 
		crossover operator from the
		keyboard
	========================================
	*/
{
    int i, number;
    bool okChoice = FALSE;

    putchar('\n');
    for (i = 0; i < NUMBER_OF_CROSSOVER_OPERATORS; i++) {
        printf("   %d.  %s\n", i, crossoverOperator[i].name);
    }
    while (!okChoice) {
        printf("\n   Enter number: ");
        scanf("%d", &number);
        if ((number < 1) || (number > NUMBER_OF_CROSSOVER_OPERATORS))
            putchar('\7');
        else
            okChoice = TRUE;
    }
    setCrossoverOperator(number);
}
#endif



void setCrossoverOperator(operatorId)
	/*
	========================================
	:purpose
		set the crossover operator based on 
		the input parameter
	========================================
	*/
 int operatorId;
{
    if ((operatorId >= 0) && (operatorId < NUMBER_OF_CROSSOVER_OPERATORS))
        currentCrossoverOperator = operatorId;
    else
        die("setCrossoverOperator(): bad operatorId");

#   if MACINTOSH | X_WINDOWS
    updateCrossoverMenu(operatorId);
    updateParamDialog();
#   endif
}



bool weShouldCrossover() {
    /*
    ========================================
    :purpose
        determine whether we should crossover
		based on a weighted coinflip
    ========================================
    */
	return (coinFlip(crossoverProbability));
}


	
float getCrossoverProbability() {
	/*
	========================================
	:purpose
		return the crossover probability
	========================================
	*/
	return(crossoverProbability);
}



void setCrossoverProbability(probability)
	/*
	========================================
	:purpose
		set the crossover probability 
		global variable
	========================================
	*/
 float probability;
{
	char string[80];
	char *format;
	
	if ((probability >= 0.0) && (probability <= 1.0)) {
		crossoverProbability = probability;
	}
	else {
		format = "crossover probability is invalid: %f";
		sprintf(string, format, probability);
		okAlert(string);
		enterCrossoverProbability();
	}
}



void enterCrossoverProbability()
	/*
	========================================
	:purpose
		allow the user to enter the 
		crossover probability at the
		keyboard
	========================================
	*/
{
	char *string = "crossover probability";

    singleFloatEntryDialog(&crossoverProbability, string,
                                            "[0.0 <= x <= 1.0]", 0.0, 1.0);
}


