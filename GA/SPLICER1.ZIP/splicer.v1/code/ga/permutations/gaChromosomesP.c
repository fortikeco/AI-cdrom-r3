/*
 ==============================================================================
 gaChromosomesP.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	the code in this module pertains to defining permutations 
	for reordering problems (e.g., traveling salesperson)
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainP.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaChromosomesP.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void scramblePermutation(
#   if useFunctionPrototypes
 	permutationType *
#   endif
);

void swapParameter(
#   if useFunctionPrototypes
 	int, 
	int, 
	permutationType *
#   endif
);


/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */
 
static unsigned permutationSize = 0;

/*
 ========================================
 functions
 ========================================
 */


void initPermutations()
	/*
	========================================
	:purpose
		initialize the permutations module;
		called at program startup and during
		reinitialization; sets up global 
		variable initial values
	========================================
	*/
{
	permutationSize = 0;
}



void preCreateInitPermutations()
	/*
	========================================
	:purpose
		initialize the permutations module;
		called just prior to creating the 
		population
	========================================
	*/
{
	definePermutations();
}



void preRunInitPermutations()
	/*
	========================================
	:purpose
		initialize the permutations module;
		called just prior to running the GAs
	========================================
	*/
{
}



void definePermutations()
	/*
	========================================
	:purpose
		this function is called after the 
		problem parameters have been set,
		and before creating the population 
		(i.e., at preCreateInit time, 
		to define the chromosome global 
		variables 
	========================================
	*/
{
	permutationSize = getNumberOfParameters();
}



permutationType	*createPermutation()
	/*
	========================================
	:purpose
		dynamically create a permutation on 
		request and return a pointer to it
	========================================
	*/
{
	register int i;
	register permutationType *permutationPtr;
	
	/* allocate the memory */
	
	permutationPtr = (permutationType *)malloc(permutationSize * 
												sizeof(permutationType));
	if (permutationPtr == NULL)
		die("createPermutation(): can't allocate permutation");

	/* set up initial sequential values */
	
	for (i = 0; i < permutationSize; i++)
		permutationPtr[i] = i;
	 
	/* now make the permutation random */
		
	scramblePermutation(permutationPtr);
	
	return(permutationPtr);
}



unsigned getPermutationSize()
    /*
    ========================================
    :purpose
        return the permutation size
    ========================================
    */
{
	return(permutationSize);
}


void scramblePermutation(permutationPtr)
	/*
	========================================
	:purpose
		scramble the values of a permutation; 
		for each position within the 
		permutation, select a (different) 
		random position, and swap the values 
		at the two positions 
	======================================== 
	*/
 permutationType *permutationPtr;
{
	register int pos1, pos2;
	
	for (pos1 = 0; pos1 < permutationSize; pos1++) {
		while ((pos2 = rangeRandom(0, permutationSize-1)) == pos1);
		swapParameter(pos1, pos2, permutationPtr);
	}
}



void decodePermutation(permutationPtr)
	/*
	========================================
	:purpose
		convert a permutation into separate parameters and 
		stuff them into the parameter array
	========================================
	*/
 permutationType *permutationPtr;
{
	register int i;
	register struct parameterStruct *parameterPtr;
	
    parameterPtr = getParameterArray();
    
 	for (i = 0; i < permutationSize; i++)
 		parameterPtr[i].value = (parameterType) permutationPtr[i];
}



void copyPermutation(from, to)
	/*
	========================================
	:purpose
		make a copy of a permutation 
	========================================
	*/
 permutationType *from, *to;
{
	register int i = permutationSize;
	
	while (i--)
		*to++ = *from++;
}





void savePermutation(fp)
    /*
    ========================================
    :purpose
        write a decoded permutation to disk
    ========================================
    */
 FILE *fp;
{
	int numberOfParameters = getNumberOfParameters(),
		i;

	for (i = 0; i < numberOfParameters; i++)
		fprintf(fp, "\t\t%d = %lu\n", i, getParameterValue(i));
}



void swapParameter(pos1, pos2, permutationPtr)
	/*
	========================================
	:purpose
		swap two parameters within a permutation
	========================================
	*/
 int pos1, pos2;
 permutationType *permutationPtr;
{
	register permutationType temp;
	
	temp = permutationPtr[pos1];
	permutationPtr[pos1] = permutationPtr[pos2];
	permutationPtr[pos2] = temp;
}



permutationType findParameter(theParameter, permutationPtr)
	/*
	========================================
	:purpose
		locate a parameter within a 
		permutation and return its index
	========================================
	*/
 permutationType theParameter, *permutationPtr;
{
	register int i;
	
	for (i = 0; i < permutationSize; i++)
		if (permutationPtr[i] == theParameter)
			return(i);
	die("findParameter(): parameter not found");
}


	
void slideParameter(theParameter, stopParameter, permutation)
	/*
	========================================
	:purpose
		slide a parameter to a desired 
		location within a permutation
	========================================
	*/
 int theParameter, stopParameter;
 permutationType *permutation;
{
	register int nextParameter;
	
	while (theParameter != stopParameter) {
		nextParameter = (theParameter+1) < permutationSize ? theParameter+1 : 0;
		swapParameter(theParameter, nextParameter, permutation);
		theParameter = nextParameter;
	}
}



void printPermutation(msg, permutation, format)
	/*
	========================================
	:purpose
		print a permutation to the screen
	========================================
	*/
 char *msg;
 permutationType *permutation;
 char format;
{
	register int i;
	
	printf("%s", msg);
	for (i = 0; i < permutationSize; i++)
		printf("%d ", permutation[i]);

}

