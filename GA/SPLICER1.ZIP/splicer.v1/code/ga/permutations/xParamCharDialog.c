/*
 ==============================================================================
 xParamCharDialog.c

 :written by

    steven e. bayer
    the mitre corporation

 :purpose

    this module contains code for the parameter characteristics dialog box
	(attached to the parameter characteristics button on the control
	parameters dialog box) for the X-Windows interface; for permutations
	this dialog box is not needed so we simply disable the appropriate
	button

 :version 1.0; release date 03/01/91

 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainP.h"

#include "myXlib.h"

#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#if MOTIF
#   include <Xm/Xm.h>
#   include <Xm/MainW.h>
#endif

#if HPW
#   include <Xw/Xw.h>
#   include <Xw/PButton.h>
#endif

/*
 ========================================
 global functions headers

 these functions are available to any
 other module
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to
 this module
 ========================================
 */

/*
 ========================================
 external variables

 variables from other modules
 ========================================
 */

/*
 ========================================
 global variables

 globals defined within this module
 ========================================
 */

/*
 ========================================
 functions
 ========================================
 */

void bogusFunction() {
}

void createParamCharDialog(theButton, theMenuMgr)
    /*
    ========================================
    :purpose
		for permutations we do not need this
		dialog box, so simply disable the
		button passed to us
    ========================================
    */
 Widget theButton;
 Widget theMenuMgr;
{
    Arg wargs[1];

    XtSetArg(wargs[0], XtNsensitive, FALSE);
    XtSetValues(theButton, wargs, 1);
}

