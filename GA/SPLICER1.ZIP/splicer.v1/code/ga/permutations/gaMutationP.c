/*
 ==============================================================================
 gaMutationP.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module implements various mutation operators for permutations
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainP.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaMutationP.h; the primary mutation
 header file, gaMutation.h, externs all
 functions that are common to any
 mutation module
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void perMutation(
#   if useFunctionPrototypes
 	permutationType *
#   endif
);


/*
 ========================================
 external functions
 
 functions from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals used defined within this module
 ========================================
 */

static mutationOperatorStructType mutationOperators[] = {
    { perMutation, "PerMutation", YES, NO_ALIAS },
    { NULL,		   "None",		  YES, NO_ALIAS }
};

static int currentMutationOperator;

static float mutationProbability;

/*
 ========================================
 functions
 ========================================
 */

void perMutation(permutation)
	/*
	========================================
	:purpose
		implements basic mutatation operator 
		for permutations; not in the 
		literature that I know of; I made 
		this up; simply walks through a 
		permutation and swaps (based on the
		mutation probability) the current
		cell with another randomly chosen
		cell
	 ========================================
	*/
 permutationType *permutation;
{
	register int city1, city2;
	register unsigned permutationSize;
	
	permutationSize = getPermutationSize();
	
	for (city1 = 0; city1 < permutationSize; city1++)
		if (coinFlip(mutationProbability)) {
			while(city1 == (city2 = rangeRandom(0, permutationSize-1)));
			swapParameter(city1, city2, permutation);
		}
}



void initMutation()
    /*
    ========================================
    :purpose
        initialize the mutation module;
        called at program startup and during
        reinitialization; sets up global
        variable initial values
    ========================================
    */
{
    setMutationOperator(PERMUT_MUTAT);
    setMutationProbability(0.0333);
}



void preCreateInitMutation()
    /*
    ========================================
    :purpose
        initialize the mutation module;
        called just prior to creating the
        population
    ========================================
    */
{
}



void preRunInitMutation()
    /*
    ========================================
    :purpose
        initialize the mutation module;
        called just prior to running the GAs
    ========================================
    */
{
}



void reinitMutation(how)
    /*
    ========================================
    :purpose
        either save or restore all mutation
		global variables; this is called 
		during global reinitialization
    ========================================
    */
 int how;
{
    static int	 oldMutationOperator;
	static float oldMutationProbability;

    switch (how) {
        case (SAVE) :
            oldMutationOperator = currentMutationOperator;
			oldMutationProbability = mutationProbability;
            break;

        case (RESTORE) :
            setMutationOperator(oldMutationOperator);
			setMutationProbability(oldMutationProbability);
            break;

        default :
            die("reinitMutation(): bad how");
            break;
    }
}



void saveMutationParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all mutation module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save current mutation operator */

    fprintf(fp, "%d\t\t\tmutation operator: %s\n", currentMutationOperator,
                        mutationOperators[currentMutationOperator].name);

    /* save the mutation probability */

    fprintf(fp, "%f\t\t\tmutation probability\n", mutationProbability);
}



void loadMutationParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all mutation module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the mutation operator */

    setMutationOperator(fgetInt(fp));

    /* load the mutation probability */

    setMutationProbability(fgetFloat(fp));
}



mutationOperatorType getMutationOperator()
    /*
    ========================================
    :purpose
        return a pointer to the selected
        mutation operator
    ========================================
    */
{
    return(mutationOperators[currentMutationOperator].ptr);
}



char *getMutationOperatorName()
    /*
    ========================================
    :purpose
        return a pointer to the selected
        mutation operator name
    ========================================
    */
{
    return(mutationOperators[currentMutationOperator].name);
}



int getMutationOperatorId()
    /*
    ========================================
    :purpose
        return the selected mutation
        operator's numeric index
    ========================================
    */
{
    return(currentMutationOperator);
}



mutationOperatorStructType *getMutationOperators()
    /*
    ========================================
    :purpose
        return a pointer to the mutation
        operator array

    ========================================
    */
{
    return(mutationOperators);
}



int getNumberOfMutationOperators()
    /*
    ========================================
    :purpose
        return the number of mutation
        operators defined in gaMutation.h

    ========================================
    */
{
    return(NUMBER_OF_MUTATION_OPERATORS);
}



#if TTY
void chooseMutationOperators()
    /*
    ========================================
    :purpose
        allow the user to choose the
        mutation operator
    ========================================
    */
{
    int i, number;
    bool okChoice = FALSE;

    putchar('\n');
    for (i = 0; i < NUMBER_OF_MUTATION_OPERATORS; i++) {
        printf("   %d.  %s\n", i, mutationOperators[i].name);
    }
    while (!okChoice) {
        printf("\n   Enter number: ");
        scanf("%d", &number);
        if ((number < 1) || (number > NUMBER_OF_MUTATION_OPERATORS))
            putchar('\7');
        else
            okChoice = TRUE;
    }
    setMutationOperator(number);
}
#endif



void setMutationOperator(operatorId)
    /*
    ========================================
    :purpose
        set the mutation operator according
        to the input parameter
    ========================================
    */
 int operatorId;
{
    if ((operatorId >= 0) && (operatorId < NUMBER_OF_MUTATION_OPERATORS))
        currentMutationOperator = operatorId;
    else
        die("setMutationOperator(): bad operatorId");

#   if MACINTOSH | X_WINDOWS
    updateMutationMenu(operatorId);
    updateParamDialog();
#   endif
}



float getMutationProbability()
	/*
	========================================
	:purpose
		return the mutation probability
	========================================
	*/
{
	return(mutationProbability);
}



void setMutationProbability(probability)
	/*
	========================================
	:purpose
		set the mutation probability based 
		on the input parameter
	========================================
	*/
 float probability;
{
	char string[80];
	char *format;
	
	if ((probability >= 0.0) && (probability <= 1.0)) {
		mutationProbability = probability;
	}
	else {
		format = "mutation probability is invalid: %f";
		sprintf(string, format, probability);
		okAlert(string);
		enterMutationProbability();
	}
}



void enterMutationProbability()
	/*
	========================================
	:purpose
		allow the user to enter the mutation 
		probability at the keyboard
	========================================
	*/
{
	char *string = "mutation probability";

  	singleFloatEntryDialog(&mutationProbability, string, 
						   "[0.0 <= x <= 1.0]", 0.0, 1.0);
}

