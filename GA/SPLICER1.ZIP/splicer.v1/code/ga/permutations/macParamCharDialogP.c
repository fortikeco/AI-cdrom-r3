/*
 ==============================================================================
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module is part of the macintosh interface for the GA tool; 
	it contains all functions that deal with the parameter characteristics
	dialog box
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/
 
/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainP.h"
#include <string.h>

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are also externed
 in macList.h
 ========================================
 */

/* general functions */

/* application-specific functions */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */


DialogPtr paramCharDialog = NULL;

/*
 ========================================
 functions
 ========================================
 */

void openParamCharDialog()
	/*
	========================================
	:purpose
		open the parameter characteristics
		dialog box
	========================================
	*/	
{
}



void doParamCharDialog(whichItem)
	/*
	========================================
	:purpose
		handle events in the parameter
		charactersitics dialog
	========================================
	*/	
 short whichItem;
{
}



void paramCharDialogContentAreaEvent(theEvent)
	/*
	========================================
	:purpose
		handle events in the content area of
		the paramChar dialog
	========================================
	*/
 EventRecord *theEvent;
{
}



void activateParamCharDialog(theEvent)
	/*
	========================================
	:purpose
		handle activate events in the 
		paramChar dialog box
	========================================
	*/
 EventRecord *theEvent;
{
}



