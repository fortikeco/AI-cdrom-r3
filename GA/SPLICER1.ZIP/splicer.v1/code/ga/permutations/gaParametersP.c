/*
 ==============================================================================
 gaParametersP.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	the code in this module pertains to the parameters of the problem the
	user is encoding; this module is for permutations
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainP.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaParametersP.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void createParameterArray(
#   if useFunctionPrototypes
 	unsigned
#   endif
);


/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;				/* control flags from gaMain.c */

/*
 ========================================
 global variables
 
 globals defined within this module 
 ========================================
 */

/* global array for holding parameter info */ 

static struct parameterStruct *parameterArray;

/* number of parameters in each chromosome */

static unsigned numberOfParameters = 0;

/*
 ========================================
 functions
 ========================================
 */

void initParameters()
	/*
	========================================
	:purpose
		initialize the parameters module;
		called at program startup and during 
		reinitialization
	========================================
	*/
{
	parameterArray = NULL;
	setNumberOfParameters(1);
}



void preCreateInitParameters()
	/*
	========================================
	:purpose
		initialize the paramaters module;
		called just prior to creating the
		population
	========================================
	*/
{
}



void preRunInitParameters()
	/*
	========================================
	:purpose
		initialize the parameters module;
		called just prior to running the GAs
	========================================
	*/
{
}



void reinitParameters(how)
    /*
    ========================================
    :purpose
        either save or restore (from memory) 
		all parameters module global 
		variables; this is called during 
		global reinitialization
    ========================================
    */
 int how;
{
    static int oldNumberOfParameters;

    switch (how) {
        case (SAVE) :
            oldNumberOfParameters = numberOfParameters;
            break;

        case (RESTORE) :
            setNumberOfParameters(oldNumberOfParameters);
            break;

        default :
            die("reinitParameters(): bad how");
            break;
    }
}



void saveParametersParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all parameters module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save number of parameters */

    fprintf(fp, "%d\t\t\tnumber of parameters\n", numberOfParameters);
}



void loadParametersParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all parameters module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
	/* load the number of parameters */

	setNumberOfParameters(fgetInt(fp));
}



void setNumberOfParameters(number)
	/*
	========================================
	:purpose
		set the number of parameters
	========================================
	*/
 int number;
{
	register char string[80];
	register char *format;
	unsigned oldNumber;
	
	if (number > 0) {
		if (numberOfParameters != number) {
			if (!checkPopulationStatus())
				return;
			oldNumber = numberOfParameters;
			numberOfParameters = number;
			createParameterArray(oldNumber);
		}
	}
	else {
		format = "number of parameters is invalid: %d";
		sprintf(string, format, number);
		okAlert(string);
		enterNumberOfParameters();
	}
}



void enterNumberOfParameters()
	/*
	========================================
	:purpose
		allow the user to enter the number 
		of parameters at the keyboard
	========================================
	*/
{
	bool okChoice = FALSE;
	int c;
	char *string = "number of parameters";
	unsigned number = numberOfParameters;
	
	if (!checkPopulationStatus())
		return;
		
	okChoice = FALSE;
	
	while (!okChoice) {
	  	singleIntEntryDialog((int *)&number, string, "[x >= 1]", 1, 30000);
		okChoice = TRUE;
	}
	setNumberOfParameters(number);
}



unsigned getNumberOfParameters()
	/*
	========================================
	:purpose
		return the number of parameters
	========================================
	*/
{
	return(numberOfParameters);
}



void createParameterArray(oldNumber)
	/*
	========================================
	:purpose
		dynamically create the parameter 
		array; the parameter array is used 
		each time a permutation needs to be 
		decoded and used to calculate the 
		fitness; there are many permutations 
		but only one parameter array; this 
		routine is also called if the number 
		of parameters changes: if the 
		parameter array exists, the old 
		values are saved and replaced in the 
		new parameter array
	========================================
	*/
 unsigned oldNumber;
{
	register int i;

	freeParameterArray();						/* delete the old array */
	
	/* create the new parameter array */

	parameterArray = (struct parameterStruct *)malloc(numberOfParameters 
										* sizeof(struct parameterStruct));
	if (parameterArray == NULL)
		die("createParameterArray(): can't allocate parameterArray");

	/* zero out all values */	

	for (i = 0; i < numberOfParameters; i++) {
		parameterArray[i].value = 0l;
	}
}


	
void freeParameterArray()
	/*
	========================================
	:purpose
		delete the parameter array from memory
	========================================
	*/
{
	if (parameterArray != NULL)
		free(parameterArray);
}



struct parameterStruct *getParameterArray()
	/*
	========================================
	:purpose
		return the address of the parameter 
		array
	========================================
	*/
{
	return(parameterArray);
}


	
parameterType getParameterValue(index)
	/*
	========================================
	:purpose
		return the specified parameter value 
		from the parameter array, indexed 
		by index
	========================================
	*/
 int index;
{
	if ((index < 0) || (index >= numberOfParameters))
		die("getParameterValue(): bad index");
	
	return(parameterArray[index].value);
}

