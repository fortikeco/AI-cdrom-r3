/*
 ==============================================================================
 gaMembers.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module contains all the code for creating and manipulating members
	of the population
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaMembers.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */
 
/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals used within this module only
 ========================================
 */
 
/*
 ========================================
 functions
 ========================================
 */

void initMembers()
	/*
	========================================
	:purpose
		initialize the members module;
		called at program startup and during
		reinitialization; sets up global 
		variable initial values
	========================================
	*/
{
}



void preCreateInitMembers()
	/*
	========================================
	:purpose
		initialize the members module;
		called just prior to creating the 
		population
	========================================
	*/
{
}



void preRunInitMembers()
	/*
	========================================
	:purpose
		initialize the members module;
		called just prior to running the GAs
	========================================
	*/
{
}



memberType *createMember()
	/*
	========================================
	:purpose
		dynamically create a new member on demand and 
		return a pointer to it
	========================================
	*/
{
	register memberType *memberPtr;
	
	/* allocate the memory */

	if ((memberPtr = (memberType *)malloc(sizeof(memberType))) == NULL)
		die("createMember(): can't allocate member");
	
	/* create the genetic string */

	memberPtr->chromosome = createChromosome();
	
	return(memberPtr);
}



int compareMembers(member1, member2)
	/*
	========================================
	:purpose
		compare two members for sorting the 
		population based on fitness
	========================================
	*/
 memberType **member1, **member2;
{
	register fitnessType diff;
	
	diff = (*member1)->fitness - (*member2)->fitness;
	
	if (diff < 0.0)
		return(-1);
	else if (diff == 0.0)
		return(0);
	else
		return(1);
}



int inverseCompareMembers(member1, member2)
	/*
	========================================
	:purpose
		compare two members for sorting the 
		population (inverse sort) based on
		fitness
	========================================
	*/
 memberType **member1, **member2;
{
	register fitnessType diff;
	
	diff = (*member1)->fitness - (*member2)->fitness;
	
	if (diff < 0.0)
		return(1);
	else if (diff == 0.0)
		return(0);
	else
		return(-1);
}

