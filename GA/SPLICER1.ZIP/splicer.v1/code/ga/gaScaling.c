/*
 ========================================
 gaScaling.c

 :written by

	steven e. bayer
	the mitre corporation

 :purpose
	this module contains code for fitness scaling

 :version 1.0; release date 03/01/91
 ========================================
 */

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaScaling.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

static scalingOperatorStructType scalingOperators[] = {
	{ linearScaling,	"Linear",	YES, NO_ALIAS },
	{ NULL,				"None",		YES, NO_ALIAS }
};

static int currentScalingOperator;

/*
 ========================================
 functions
 ========================================
 */

void initScaling()
    /*
    ========================================
    :purpose
        initialize the scaling module;
        called at program startup and during
        reinitialization; sets up global
        variable initial values
    ========================================
    */
{
    setScalingOperator(NO_SCALING);        /* default method */
}



void preCreateInitScaling()
    /*
    ========================================
    :purpose
        initialize the scaling module;
        called just prior to creating the
        population
    ========================================
    */
{
}



void preRunInitScaling()
    /*
    ========================================
    :purpose
        initialize the scaling module;
        called just prior to running the GAs
    ========================================
    */
{
}



void reinitScaling(how)
 int how;
{
    static int oldScalingOperator;

    switch (how) {
        case (SAVE) :
            oldScalingOperator = currentScalingOperator;
            break;

        case (RESTORE) :
            setScalingOperator(oldScalingOperator);
            break;

        default :
            die("reinitScaling(): bad how");
            break;
    }
}



void saveScalingParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all scaling module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save current scaling operator */

    fprintf(fp, "%d\t\t\tscaling operator: %s\n", currentScalingOperator,
                        scalingOperators[currentScalingOperator].name);
}



void loadScalingParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all scaling module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the scaling operator */

    setScalingOperator(fgetInt(fp));
}



#define fitnessMultiple 2.0

float aCoefficient, bCoefficient;

void preScale(maxFitness, avgFitness, minFitness)
	/*
	========================================
	:purpose
		this function sets up the fitness scaling coefficients for
		linear fitness scaling
	:reference
		ala Goldberg(1989)
	========================================
	*/
 fitnessType maxFitness, avgFitness, minFitness;
{
	float delta;

	if (minFitness > ((fitnessMultiple * avgFitness - maxFitness) /
					  (fitnessMultiple - 1.0))) {		/* non-zero test */
		delta = maxFitness - avgFitness;				/* normal scaling */
		aCoefficient = (fitnessMultiple - 1.0) * avgFitness / delta;
		bCoefficient = avgFitness * 
						(maxFitness - fitnessMultiple * avgFitness) / delta;
	}
	else {									/* scale as much as possible */
		delta = avgFitness - minFitness;
		aCoefficient = avgFitness / delta;
		bCoefficient = -minFitness * avgFitness / delta;
	}
}



fitnessType scale(fitnessValue)
    /*
    ========================================
    :purpose
        this function scales one fitness
		value according to the a and b
		coefficients previously set up
		in preScale() above
    ========================================
	*/
 fitnessType fitnessValue;
{
	fitnessType scaledValue;

	if ((scaledValue = aCoefficient * fitnessValue + bCoefficient) < 0.0)
		scaledValue = 0.0;
	return (scaledValue);
}



void linearScaling(populationSize, thePopulation, maxFitness, 
						  avgFitness, minFitness, summedFitness)
	/*
	========================================
	:purpose
		this function sets up the fitness scaling coefficients
	:reference
		ala Goldberg(1989)
	========================================
	*/
 unsigned populationSize;
 populationType thePopulation;
 fitnessType maxFitness, *avgFitness, minFitness, *summedFitness;
{
	register int i;
	register memberType *memberPtr;
	register populationType population;

	/* calculate a and b: get slope and intercept for function */

	preScale(maxFitness, *avgFitness, minFitness);

	/* walk through the population and scale the fitness values */
	/* also calculate new cummFitness values and summedFitness value */

	*summedFitness = 0.0;
	population = thePopulation;

	for (i = 0; i < populationSize; i++) {

		memberPtr = *population++;

		/* f' = af + b */

		if ((memberPtr->fitness = 
				aCoefficient * memberPtr->fitness + bCoefficient) < 0.0)
			memberPtr->fitness = 0.0;
		memberPtr->cummFitness = 
				(*summedFitness += memberPtr->fitness);
	}

	/* recalculate the average fitness */

	*avgFitness = *summedFitness / populationSize;
}



scalingOperatorType getScalingOperator()
    /*
    ========================================
    :purpose
        return a pointer to the selected
        fitness scaling operator
    ========================================
    */
{
    return(scalingOperators[currentScalingOperator].ptr);
}



char *getScalingOperatorName()
    /*
    ========================================
    :purpose
        return a pointer to the selected
		fitness scaling operator name
    ========================================
	*/
{
    return(scalingOperators[currentScalingOperator].name);
}



int getScalingOperatorId()
    /*
    ========================================
    :purpose
        return the number of the currently 
		selected scaling operator
    ========================================
    */
{
    return(currentScalingOperator);
}



scalingOperatorStructType *getScalingOperators()
    /*
    ========================================
    :purpose
        return a pointer to the scaling
        operator array
    ========================================
    */
{
    return(scalingOperators);
}



int getNumberOfScalingOperators()
    /*
    ========================================
    :purpose
        return the number of scaling operators 
        defined in gaScaling.h
    ========================================
    */
{
    return(NUMBER_OF_SCALING_OPERATORS);
}


#if TTY
void chooseScalingOperator()
    /*
    ========================================
    :purpose
        allow the user to choose the
        fitness scaling operator
    ========================================
    */
{
    int number;
    bool okChoice = FALSE;

    putchar('\n');
    for (i = 0; i < NUMBER_OF_SCALING_OPERATORS; i++) {
        printf("   %d.  %s\n", i, scalingOperators[i].name);
    }
    while (!okChoice) {
        printf("\n   Enter number: ");
        scanf("%d", &number);
        if ((number < 0) || (number >= NUMBER_OF_SCALING_OPERATORS))
            putchar('\7');
        else
            okChoice = TRUE;
    }
    setScalingOperator(number);
}
#endif


void setScalingOperator(operatorId)
    /*
    ========================================
    :purpose
        set the fitness scaling operator 
		according to the input parameter
    ========================================
    */
 int operatorId;
{
	if ((operatorId >= 0) && (operatorId < NUMBER_OF_SCALING_OPERATORS))
		currentScalingOperator = operatorId;
	else
		die("setScalingOperator(): bad operatorId");

#   if MACINTOSH | X_WINDOWS
    updateScalingMenu(operatorId);
    updateParamDialog();
#   endif
}


