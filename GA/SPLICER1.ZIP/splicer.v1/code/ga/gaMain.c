/*
 ==============================================================================
 gaMain.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module is the main code for the genetic algorithm tool
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/
 
/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaMain.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void initGAFlags();
void preRunInitGA();

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */
 
flagsType gaFlags;

/*
 ========================================
 functions
 ========================================
 */

void initGA()
	/*
	========================================
	:purpose
		initializes all of the ga modules
		at start of program or during
		reinitialization
	========================================
	*/
{
	initGAFlags();
	initRandom();
	initParameters();
	initChromosomes();
	initMembers();
	initPopulation();
	initMutation();
	initCrossover();
	initSelection();
	initSampling();
	initScaling();
	initStatistics();
}



void preCreateInitGA()
	/*
	========================================
	:purpose
		initializes all of the GA modules just
		prior to creating the population
	========================================
	*/
{
	preCreateInitRandom();
	preCreateInitParameters();
	preCreateInitChromosomes();
	preCreateInitMembers();
	preCreateInitPopulation();
	preCreateInitMutation();
	preCreateInitCrossover();
	preCreateInitSelection();
	preCreateInitSampling();
	preCreateInitScaling();
	preCreateInitStatistics();
}



void preRunInitGA()
	/*
	========================================
	:purpose
		initializes all of the GA modules
		just prior to running the GAs
	========================================
	*/
{
	preRunInitRandom();
	preRunInitParameters();
	preRunInitChromosomes();
	preRunInitMembers();
	preRunInitPopulation();
	preRunInitMutation();
	preRunInitCrossover();
	preRunInitSelection();
	preRunInitSampling();
	preRunInitScaling();
	preRunInitStatistics();
}



void initGAFlags()
	/*
	========================================
	:purpose
		initializes the ga flags
	========================================
	*/
{
	gaFlags.populationChanged	= FALSE;
	gaFlags.populationCreated	= FALSE;
	gaFlags.runningGA			= FALSE;
	gaFlags.stop				= FALSE;
}




void reinitialize(how)
	/*
	========================================
	:purpose
		reinitialize variables and allocated 
		memory based on the input parameter
	========================================
	*/
 char how;
{
	switch (how) {
		case CURRENT_VALUES:
			/* save the current parameter settings */

			reinitParameters(SAVE);
			reinitPopulation(SAVE);
			reinitSampling(SAVE);
			reinitScaling(SAVE);
			reinitSelection(SAVE);
			reinitCrossover(SAVE);
			reinitMutation(SAVE);
			reinitRandom(SAVE);

			/* reinitialize */

			initGA();				/* set default values */
			initUser();				/* set user values */

			/* restore the parameters */

			reinitParameters(RESTORE);
			reinitPopulation(RESTORE);
            reinitSampling(RESTORE);
            reinitScaling(RESTORE);
            reinitSelection(RESTORE);
            reinitCrossover(RESTORE);
            reinitMutation(RESTORE);
            reinitRandom(RESTORE);

			break;

		case USER_VALUES:
			initGA();
			initUser();

			break;

		case LOAD_VALUES:
			initGA();
			initUser();
			loadParameters();

			break;

		case DEFAULT_VALUES:
			initGA();

			break;

		default:
			die("reinitialize(): bad choice");
	}
#	if MACINTOSH | X_WINDOWS
	updateParamDialog();
#	endif
}



bool checkRunGA()
	/*
	========================================
	:purpose
		make sure we have a population before 
		we run the ga operators
	========================================
	*/
{
	register char *string;
	
	if (gaFlags.populationChanged && gaFlags.populationCreated) {
		string = "Population must be recreated first.";
		okAlert(string);
		return(FALSE);
	}
	if (!gaFlags.populationCreated) {
		string = "Population must be created first.";
		okAlert(string);
		return(FALSE);
	}
	return(TRUE);
}



void runGA()
	/*
	========================================
	:purpose
		run the genetic algoritms on the 
		extant population
	========================================
	*/
{
	register int i;

#	if TTY
	puts("\n   Press ESC to stop.\n");
#	endif

	preRunInitGA();					/* initialize all modules */
	
	FOREVER { 

		generateStatistics();
		
			sufferUserInterface();
		
		printStatistics();
		
			sufferUserInterface();

		newPopulation();
		
			sufferUserInterface();
		
#		if MACINTOSH | X_WINDOWS
		if (gaFlags.stop) {		/* good stopping point so we can resume */
			trace(0);
			return;
 		}
#		endif

#		if TTY						/* look for the escape character to quit */
#			if THINKC
 			csetmode(C_RAW, stdin);
			if (getchar() == ESC) {
				csetmode(C_ECHO, stdin);
				trace(NULL);
				return;
			}
			csetmode(C_ECHO, stdin);
#			endif
#		endif
	} 
}

