/*
 ==============================================================================
 gaSampling.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module contains all routines used to sampling parents for mating
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaSampling.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void	zeroAllMatingCounts();
int		createTheExpectedList();
void	shuffleParents();
void	createTheLoserList();

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

static populationType			population, parents, losers;
static unsigned					populationSize;
static float					*fractions = NULL;
static int						*sample = NULL;

/*
 ========================================
 global variables
 
 globals used within this module only
 ========================================
 */

static samplingOperatorStructType samplingOperators[] = {
	{ determistic,
		"Deterministic",
			YES, NO_ALIAS },
	{ expectedValue,
		"Expected Value",
			NO, STOCH_WOUT_REP },
	{ rankingMethod,
		"Ranking Method",
			YES, STOCH_TOURNAMENT },
	{ roulette,
		"Roulette Wheel",
			YES, STOCH_WITH_REP },
	{ roulette,
		"Stochastic with Replacement",
			YES, ROULETTE },
	{ expectedValue,
		"Stochastic without Replacement",
			NO, EXPECTED_VALUE },
	{ remainderStochWithReplacement,
		"Stochastic Remainder with Replacement",
			YES, NO_ALIAS },
	{ remainderStochWithoutReplacement, 
		"Stochastic Remainder without Replacement",
			YES, NO_ALIAS },
	{ rankingMethod, 
		"Stochastic Tournament",
			YES, RANKING_METHOD },
	{ tournament,
		"Tournament",
			YES, NO_ALIAS },
	{ universal,
		"Stochastic Universal",
			YES, NO_ALIAS }
};

static int currentSamplingOperator;

/*
 ========================================
 functions
 ========================================
 */



void initSampling()
	/*
	========================================
	:purpose
		initialize the sampling module;
		called at program startup and during
		reinitialization; sets up global 
		variable initial values
	========================================
	*/
{
	setSamplingOperator(RANKING_METHOD);		/* default method */
	if (fractions) {
		free(fractions);
		fractions = NULL;
	}
	if (sample) {
		free(sample);
		sample = NULL;
	}
}



void preCreateInitSampling()
	/*
	========================================
	:purpose
		initialize the sampling module;
		called just prior to creating the 
		population
	========================================
	*/
{
}



void preRunInitSampling()
	/*
	========================================
	:purpose
		initialize the sampling module;
		called just prior to running the GAs
	========================================
	*/
{
	population     = getThePopulation();
	parents        = getTheParentList();
	losers         = getTheLoserList();
	populationSize = getPopulationSize();
	
	if (!fractions)
		if ((fractions = 
				(float *)malloc(populationSize * sizeof(float))) == NULL)
			die("gs.sampling.c: can't allocate fractions");

	if (!sample)
		if ((sample = (int *)malloc(populationSize * sizeof(int))) == NULL)
			die("gs.sampling.c: can't allocate sample[]");
}



void reinitSampling(how)
 int how;
{
	static int oldSamplingOperator;

    switch (how) {
        case (SAVE) :
            oldSamplingOperator = currentSamplingOperator;
            break;

        case (RESTORE) :
            setSamplingOperator(oldSamplingOperator);
            break;

        default :
            die("reinitSampling(): bad how");
            break;
    }
}



void saveSamplingParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all sampling module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save current sampling operator */

    fprintf(fp, "%d\t\t\tsampling operator: %s\n", currentSamplingOperator,
                        samplingOperators[currentSamplingOperator].name);
}



void loadSamplingParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all sampling module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the sampling operator */

    setSamplingOperator(fgetInt(fp));
}



void determistic()
	/*
	========================================
	:purpose
		determistic sampling;
		creates list of parents for mating
	:reference
		Brindle	(1981) p. 85; Baker (1987)
	========================================
	*/
{
	register int i, j, max;
	
	zeroAllMatingCounts();

	/* sample according to the integer part of the expected value */

	j = createTheExpectedList();
	
	/* sample according to the fractional part of the expected value */

	for (; j < populationSize; j++) {
		max = 0;
		for (i = 1; i < populationSize; i++)
			if (fractions[i] > fractions[max])
				max = i;
		sample[j] = max;
		fractions[max] = 0.0;
	}
	
	shuffleParents();
	createTheLoserList();
}



void expectedValue()
	/*
	========================================
	:purpose
		expected value sampling;
		(a.k.a. stochastic sampling without 
		replacement) creates list of parents 
		for mating
	:reference
		Goldberg	(1989) p. 121
		Brindle		(1981) p.  90
	========================================
	*/
{
	die("expectedValue(): not implemented yet");
}



void rankingMethod()
	/*
	========================================
	:purpose
		ranking method sampling;
		creates list of parents for mating
	:reference
		Goldberg	(1989) p. 121
		Brindle		(1981) p. 93, 96
	========================================
	*/
{
	register int i, j;
	
	zeroAllMatingCounts();

	for(i = 0; i < populationSize; i++) {
		/* use two of the loser slots temporarily */
		/* choose two population members using roulette wheel */
		losers[0] = binarySearchPop((float)(frand() * populationSize));
		losers[1] = binarySearchPop((float)(frand() * populationSize));

		/* choose the one with greater fitness value */
		j = (losers[0]->fitness > losers[1]->fitness) ? 0 : 1;

		/* assign it as one of the parents */
		parents[i] = losers[j];
		parents[i]->numberOfMatings++;
	}
	
	createTheLoserList();
}



void roulette()
	/*
	========================================
	:purpose
		basic roulette wheel sampling using 
		binary search (a.k.a. stochastic 
		sampling with replacement);
		creates list of parents for mating
	:reference
		Goldberg	(1989) p. 63
		Brindle		(1981) p. 83
	========================================
	*/
{
	register int i, j;
	
	zeroAllMatingCounts();

	/* sample one member for mating from the roulette wheel */

	for(i = 0; i < populationSize; i++) {
		parents[i] = binarySearchPop((float)(frand() * populationSize));
		parents[i]->numberOfMatings++;
	}
	
	createTheLoserList();
}



void remainderStochWithReplacement()
	/*
	========================================
	:purpose
		stochastic remainder sampling with 
		replacement sampling; creates list 
		of parents for mating
	:reference
		Goldberg	(1989) p. 121
		Brindle		(1981) p.  88
	========================================
	*/
{
	register int i, j, r;
	
	zeroAllMatingCounts();

	/* sample according to the integer part of the expected value */

	j = createTheExpectedList();
	
	/* sample according to the fractional part of the expected value */
		
	r = (populationSize-1) - (j-1);
	if (r > 0) {
		for (i = 1; i < populationSize; i++)		/* cumm probability */
			fractions[i] = fractions[i-1] + fractions[i];
		for (; j < populationSize; j++) {
			for (i = 0; i < populationSize; i++) {
				if ((float)(r * frand()) < fractions[i]) {
					sample[j] = i;
					break;
				}
			}
		}
	}

	shuffleParents();
	createTheLoserList();
}



void remainderStochWithoutReplacement()
	/*
	========================================
	:purpose
		stochastic remainder sampling without 
		replacement; creates list of parents 
		for mating
	:reference
		Goldberg	(1989) p. 121
		Brindle		(1981) p.  91
	========================================
	*/
{
	register int i, j;

	zeroAllMatingCounts();

	/* sample according to the integer part of the expected value */
	j = createTheExpectedList();
	
	/* sample according to the fractional part of the expected value */
		
	i = 0;
	while (j < populationSize) {
		if (i >= populationSize)
			i = 0;
		if (fractions[i] > 0.0)	{
			if (coinFlip(fractions[i])) {
				sample[j++] = i;
				fractions[i] -= 1.0;
			}
		}
		i++;
	}
	
	shuffleParents();
	createTheLoserList();
}


#define tournamentSize 2

void tournament()
	/*
	========================================
	:purpose
		stochastic tournament sampling;
		creates list of parents for mating
	:reference
		Smith (private communication)
	========================================
	*/
{
	register int i, j, theOne, numberSampled = 0, popIndex = 0;
	register fitnessType fit;
		
	zeroAllMatingCounts();
	
	while (numberSampled < populationSize) {
		if (popIndex >= populationSize) {	/* shuffle the population */
			for(i = 0; i < populationSize; i++) {	
				losers[0] = population[i];  /* borrow a loser for a moment */
				j = rangeRandom(0, populationSize-1);
				if (j != i) {
					population[i] = population[j];
					population[j] = losers[0];
				}
			}
			popIndex = 0;	/* start over at the beginning */
		}
		
		/* hold a tournament and pick one parent */
	 	if ((populationSize - popIndex) >= tournamentSize) {
			for (i = theOne = popIndex, fit = 0.0; 
								i < popIndex+tournamentSize; i++) {
				if (population[i]->fitness > fit) {
					fit = population[i]->fitness;
					theOne = i;
				}
			}
			parents[numberSampled] = population[theOne];
			parents[numberSampled++]->numberOfMatings++;
		}
		popIndex += tournamentSize;
	}
	
	createTheLoserList();
}



void universal()
	/*
	========================================
	:purpose
		stochastic universal sampling;
		creates list of parents for mating
	:reference
		Baker (1987)
	========================================
	*/
{
	register int i, j;
	register float sum, marker; 
	
	zeroAllMatingCounts();

	/* get a random starting point */

	marker = frand();

	/* step through the population: i steps through the new parents; */
	/* j steps through the prospective parents */

	for(sum = 0.0, i = j = 0; i < populationSize; j++) {
		for(sum += population[j]->targetSamplingRate; sum > marker; marker++) {
			/* sample member j */
			sample[i++] = j;
		}
	}

	shuffleParents();
	createTheLoserList();
}



void zeroAllMatingCounts()
	/*
	========================================
	:purpose
		sets all mating counts, for the 
		entire population, to zero
	========================================
	*/
{
	int i;
	
	for(i = 0; i < populationSize; i++)
		population[i]->numberOfMatings = 0;
}



int createTheExpectedList()
	/*
	========================================
	:purpose
		sample members of the mating pool 
		according to the integer part of 
		their target sampling rate (i.e.,
		their expected value)
	:returns
		the index of the next member to be
		add to the list
	========================================
	*/
{
	register int			i, j;
	register int			intExpected;
	register float			expected;

	for (i = 0, j = 0; i < populationSize; i++) {
		expected = population[i]->targetSamplingRate;
		intExpected = (int)expected;
		fractions[i] = expected - intExpected;
		while (intExpected--)
			sample[j++] = i;
	}
	return(j);
}



void shuffleParents()
	/*
	========================================
	:purpose
		randomly create the parent list by 
		shuffling the sample[] list
	========================================
	*/
{
	register int i, j;
	register int remaining;

	remaining = populationSize-1;
	for (i = 0; i < populationSize; i++) {
		j = rangeRandom(0, remaining);
		parents[i] = population[sample[j]];
		parents[i]->numberOfMatings++;
		sample[j] = sample[remaining--];
	}
}



void createTheLoserList()
	/*
	========================================
	:purpose
		creates the list of members who were
		not chosen for mating; their member
		structures can be reused by the 
		children created for the new 
		population
	========================================
	*/
{
	int i, j;

	for(i = j = 0; i < populationSize; i++)
		if (!population[i]->numberOfMatings)
			losers[j++] = population[i];
}



samplingOperatorType getSamplingOperator()
	/*
	========================================
	:purpose
		return a pointer to the sampling
		operator
	========================================
	*/
{
	return(samplingOperators[currentSamplingOperator].ptr);
}



char *getSamplingOperatorName()
	/*
	========================================
	:purpose
		return a pointer to the sampling
		operator name
	========================================
	*/
{
	return(samplingOperators[currentSamplingOperator].name);
}



int getSamplingOperatorId()
	/*
	========================================
	:purpose
		return the numeric id of the
		sampling operator
	========================================
	*/
{
	return(currentSamplingOperator);
}



samplingOperatorStructType *getSamplingOperators()
    /*
    ========================================
    :purpose
        return a pointer to the sampling 
		operators array
    ========================================
    */
{
    return(samplingOperators);
}



int getNumberOfSamplingOperators()
    /*
    ========================================
    :purpose
        return the number of sampling 
		operators defined in gaSampling.h
    ========================================
    */
{
    return(NUMBER_OF_SAMPLING_OPERATORS);
}



void chooseSamplingOperator()
	/*
	========================================
	:purpose
		allow the user to choose a sampling
		operator from a menu 
	========================================
	*/
{
	int i, number;
	bool okChoice = FALSE;
	
	putchar('\n');
	for (i = 0; i < NUMBER_OF_SAMPLING_OPERATORS; i++) {
		printf("   %d.  %s\n", i, samplingOperators[i].name);
	}
	while (!okChoice) {
		printf("\n   Enter number: ");
		scanf("%d", &number);
		if ((number < 0) || (number >= NUMBER_OF_SAMPLING_OPERATORS))
			putchar('\7');
		else
			okChoice = TRUE;
	}
	setSamplingOperator(number);
}



void setSamplingOperator(operatorId)
	/*
	========================================
	:purpose
		set the sampling operator based on 
		the input parameter 
	========================================
	*/
 int operatorId;
{

    if ((operatorId >= 0) && (operatorId < NUMBER_OF_SAMPLING_OPERATORS))
        currentSamplingOperator = operatorId;
    else
        die("setSamplingOperator(): bad operatorId");

#	if MACINTOSH | X_WINDOWS
	updateSamplingMenu(operatorId);
	updateParamDialog();
#	endif
}

