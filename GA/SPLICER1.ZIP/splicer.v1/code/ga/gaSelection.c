/*
 ==============================================================================
 gaSelection.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module contains all routines used to calculate and assign
	target sampling rates or expected values using either proportional
	selection or linear rank selction
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaSelection.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

/*
 ========================================
 global variables
 
 globals used within this module only
 ========================================
 */

static selectionOperatorStructType selectionOperators[] = {
	{ proportionalSelection,	"Proportional",	YES, NO_ALIAS },
	{ linearRankSelection,		"Linear Rank",	YES, NO_ALIAS },
};

static int currentSelectionOperator;

static float maxTSR = 1.1;

static populationType			thePopulation;
static unsigned					populationSize;

/*
 ========================================
 functions
 ========================================
 */

void initSelection()
	/*
	========================================
	:purpose
		initialize the selection module;
		called at program startup and during
		reinitialization; sets up global 
		variable initial values
	========================================
	*/
{
	setSelectionOperator(PROPORTIONAL); 	/* default method */
	maxTSR = 1.1;							/* default value */
}



void preCreateInitSelection()
	/*
	========================================
	:purpose
		initialize the selection module;
		called just prior to creating the 
		population
	========================================
	*/
{
}



void preRunInitSelection()
	/*
	========================================
	:purpose
		initialize the selection module;
		called just prior to running the GAs
	========================================
	*/
{
	thePopulation  = getThePopulation();
	populationSize = getPopulationSize();
}



void reinitSelection(how)
 int how;
{
    static int oldSelectionOperator;

    switch (how) {
        case (SAVE) :
            oldSelectionOperator = currentSelectionOperator;
            break;

        case (RESTORE) :
            setSelectionOperator(oldSelectionOperator);
            break;

        default :
            die("reinitSelection(): bad how");
            break;
    }
}



void saveSelectionParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all selection module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save current selection operator */

    fprintf(fp, "%d\t\t\tselection operator: %s\n", currentSelectionOperator,
                        selectionOperators[currentSelectionOperator].name);
}



void loadSelectionParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all selection module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the selection operator */

    setSelectionOperator(fgetInt(fp));
}



void proportionalSelection() {
	/*
	========================================
	:purpose
		proportional selection; assigns
		target sampling rates or expected 
		values based on relative fitness
	:references
		De Jong (1975); Baker (1985; 1987); 
		Grefenstette and Baker (1989)
	========================================
	*/
	register fitnessType averageFitness = getAverageFitness();
	register populationType population;
    register memberType *memberPtr;
	register int ctr;
	register float sum;

    population = thePopulation;

	/* step through the population and assign the target sampling rate */

    for (ctr = 0, sum = 0.0; ctr < populationSize; ctr++) {

        /* get the next member of the population */

        memberPtr = *population++;

		/* calculate and assign the targetSamplingRate and cummulative */
		/* sampling rate */

        memberPtr->targetSamplingRate = memberPtr->fitness / averageFitness;
        memberPtr->cummTSR = (sum += memberPtr->targetSamplingRate);
    }
}



void linearRankSelection() {
	/*
	========================================
	:purpose
		linear rank selection; assigns
		target sampling rates or expected
		values based on ranking within the
		population
	:references
		Baker (1985; 1987); Grefenstette 
		and Baker (1989)
	========================================
	*/
    register populationType population;
    register memberType *memberPtr;
    register int ctr;
	register float minTSR, inc, theTSR, sum;

	minTSR = 2.0 - maxTSR;
	inc = 2.0 * (maxTSR - 1.0) / (populationSize - 1);
	theTSR = minTSR;

    population = thePopulation;

	/* sort the population in ascending order */

	sortPopulation(ascending);

	/* step through the population and assign the target sampling rate */

    for (ctr = 0, sum = 0.0; ctr < populationSize; ctr++) {

        /* get the next member of the population */

        memberPtr = *population++;

        /* calculate and assign the targetSamplingRate and cummulative */
        /* sampling rate */

        memberPtr->targetSamplingRate = theTSR;
		memberPtr->cummTSR = (sum += theTSR);
		theTSR += inc;
    }
}



selectionOperatorType getSelectionOperator()
	/*
	========================================
	:purpose
		return a pointer to the selection
		operator
	========================================
	*/
{
	return(selectionOperators[currentSelectionOperator].ptr);
}



char *getSelectionOperatorName()
	/*
	========================================
	:purpose
		return a pointer to the selection
		operator name
	========================================
	*/
{
	return(selectionOperators[currentSelectionOperator].name);
}



int getSelectionOperatorId()
	/*
	========================================
	:purpose
		return the numeric id of the
		selection operator
	========================================
	*/
{
	return(currentSelectionOperator);
}



selectionOperatorStructType *getSelectionOperators()
    /*
    ========================================
    :purpose
        return a pointer to the selection
		operators array
    ========================================
    */
{
    return(selectionOperators);
}



int getNumberOfSelectionOperators()
    /*
    ========================================
    :purpose
        return the numeric of selection 
		operators defined in gaSelection.h
    ========================================
    */
{
    return(NUMBER_OF_SELECTION_OPERATORS);
}



void chooseSelectionOperator()
	/*
	========================================
	:purpose
		allow the user to choose a selection
		operator from a menu 
	========================================
	*/
{
    int i, number;
    bool okChoice = FALSE;

    putchar('\n');
    for (i = 0; i < NUMBER_OF_SELECTION_OPERATORS; i++) {
        printf("   %d.  %s\n", i, selectionOperators[i].name);
    }
    while (!okChoice) {
        printf("\n   Enter number: ");
        scanf("%d", &number);
        if ((number < 0) || (number >= NUMBER_OF_SELECTION_OPERATORS))
            putchar('\7');
        else
            okChoice = TRUE;
    }
    setSelectionOperator(number);
}



void setSelectionOperator(operatorId)
	/*
	========================================
	:purpose
		set the selection operator based on 
		the input parameter 
	========================================
	*/
 int operatorId;
{
    if ((operatorId >= 0) && (operatorId < NUMBER_OF_SELECTION_OPERATORS))
        currentSelectionOperator = operatorId;
    else
        die("setSelectionOperator(): bad operatorId");

#	if MACINTOSH | X_WINDOWS
	updateSelectionMenu(operatorId);
	updateParamDialog();
#	endif
}

