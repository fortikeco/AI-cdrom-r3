/*
 ==============================================================================
 gaStatistics.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module contains all routines used to generate GA statistics
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaStatistics.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void saveBestList(
#   if useFunctionPrototypes
 	memberType *
#   endif
);

void shiftBestList(
#   if useFunctionPrototypes
 	short
#   endif
);

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;
static populationType thePopulation;
static unsigned populationSize;

/*
 ========================================
 global variables
 
 globals used defined within this module
 ========================================
 */

static unsigned			generationNumber;

static fitnessType		summedFitness;	/* sum of fitness this generation  */
static fitnessType		maximumFitness; /* best fitness this generation    */
static fitnessType		minimumFitness; /* worst fitness this generation   */
static fitnessType		averageFitness; /* mean fitness this generation    */
static fitnessType  	worstFitness;	/* worst fitness ever seen */

static float			summedValue;	/* sum of objective this generation */
static float			maximumValue;	/* best objective this generation   */
static float			minimumValue;	/* worst objective this generation  */
static float			averageValue;	/* mean objective this generation   */
static float  			worstValue;		/* worst objective ever seen */

/* the following structure and its code below maintain a list of the */
/* MAX_BEST best members ever seen, sorted best to worst, the 0th    */
/* member being best; for each member, the fitness and objective     */
/* values are kept, along with a copy of its chromosome */

static bestStructType	best = { 
			{ 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
			{ 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
			{ NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL } };

/* the following array contains statistical information for MAX_STAT */
/* generations; this info is displayed in the objective window */
 
static mainStatsStructType	stats;

/* this array contains ten bins for computing info to be displayed in the */
/* fitness window */

static float bins[10];

/*
 ========================================
 functions
 ========================================
 */

void initStatistics()
	/*
	========================================
	:purpose
		initialize the statistics module;
		called at program startup and during
		reinitialization; sets up global 
		variable initial values
	========================================
	*/
{
	register int i;
	
	generationNumber	= 0;

	stats.firstGenerationPtr = 0;
	stats.movingPtr = 0;
	stats.staticPtr = MAX_STAT;

	summedFitness		= 0.0;
	maximumFitness		= 0.0;
	minimumFitness		= 0.0;
	averageFitness		= 0.0;
	worstFitness		= 10000000.0;

	summedValue			= 0.0;
	maximumValue		= 0.0;
	minimumValue		= 0.0;
	averageValue		= 0.0;
	worstValue			= 0.0;

	for (i = 0; i < MAX_BEST; i++) {
		best.fitness[i] = 0.0;
		best.objectiveValue[i]	= 0.0;
		if (best.chromosome[i])
			free(best.chromosome[i]);
		best.chromosome[i] = NULL;
	}
	for (i = 0; i < 10; i++)
		bins[i] = 0.0;
}



void preCreateInitStatistics()
	/*
	========================================
	:purpose
		initialize the statistics module;
		called just prior to creating the 
		population
	========================================
	*/
{
}



void preRunInitStatistics()
	/*
	========================================
	:purpose
		initialize the statistics module;
		called just prior to running the GAs
	========================================
	*/
{
	int i;
	
	for (i = 0; i < MAX_BEST; i++)
		best.chromosome[i] = createChromosome();
	
	thePopulation  = getThePopulation();
	populationSize = getPopulationSize();
}



void generateStatistics()
	/*
	========================================
	:purpose
		compute statistics for the 
		current generation
	========================================
	*/
{
	register int ctr = 1;
	register memberType *memberPtr;
	register populationType population;
	register fitnessType fitness, objectiveValue;
	register int i;
	scalingOperatorType scalingOperator;

	/* start at the beginning of the population */

	population = thePopulation;

	/* get the first member */

	memberPtr = *population++;

	trace(FITNESS);

	/* decode the member string and calculate the fitness of */
	/* the first member and set up all other interesting variables */

	decodeChromosome(memberPtr->chromosome);

	if ((memberPtr->fitness =
			calcFitness(&memberPtr->objectiveValue)) < 0.0)
		die("generateStatistics(): fitness value cannot be negative");

	summedFitness 	= memberPtr->cummFitness = maximumFitness = 
					  minimumFitness = memberPtr->fitness;
		
	summedValue 	= maximumValue = minimumValue = 
					  memberPtr->objectiveValue;

	/* see if this member is a best ever */

	if (memberPtr->fitness > best.fitness[MAX_BEST-1])		/* best ever */
		saveBestList(memberPtr);
		
 	/* step through the rest of the population */

	for (ctr = 1; ctr < populationSize; ctr++) {

		/* get the next member */

		memberPtr = *population++;

		/* decode the member string and calculate the fitness */

		decodeChromosome(memberPtr->chromosome);

		if ((memberPtr->fitness =
			        calcFitness(&memberPtr->objectiveValue)) < 0.0)
	        die("generateStatistics(): fitness value cannot be negative");

		fitness = memberPtr->fitness;
		objectiveValue = memberPtr->objectiveValue;

		/* add to the summed variables */

		memberPtr->cummFitness = (summedFitness += fitness);
		summedValue += objectiveValue;

		/* see if we have a best ever string */

		if (fitness > best.fitness[MAX_BEST-1])	/* one of the ten best ever */
			saveBestList(memberPtr);	/* best.fitness[0] is the best ever */

		/* see if we have a worst ever string */

		if (fitness < worstFitness) {
			worstFitness = fitness;
			worstValue   = objectiveValue;
		}

		/* see if its the best in this generation */

		if (fitness > maximumFitness) {
			maximumFitness = fitness;
			maximumValue   = objectiveValue;
		}

		/* worst in this generation? */

		if (fitness < minimumFitness) {
			minimumFitness = fitness;
			minimumValue   = objectiveValue;
		}
			
	}

	/* calculate the average variables */

	averageFitness = summedFitness / populationSize;
	averageValue   = summedValue   / populationSize;

	/* if fitness scaling is turned on, scale the fitness values */

	if (scalingOperator = getScalingOperator()) {
		trace(SCALE);
		(*scalingOperator) (populationSize, thePopulation,	
								maximumFitness, &averageFitness,
								minimumFitness, &summedFitness);
	}

	/* step through the population again and set up the bins (these are */
	/* used for displaying info in the fitness window) */

	for (ctr = 0; ctr < 10; ctr++)			/* zero out all of the bins */
		bins[ctr] = 0.0;

	population = thePopulation;

	for (ctr = 0; ctr < populationSize; ctr++) {

		fitnessType bestFitness;

		/* if fitness scaling is turned on, scale the best ever 
		/* member's fitness value before normalizing to it */

		if (scalingOperator)
			bestFitness = scale(best.fitness[0]);
		else
			bestFitness = best.fitness[0];

		/* get the next member of the population */

		memberPtr = *population++;

		/* place this member in a bin; members' fitness is normalized */
		/* by dividing by the fitness of the best ever member; these  */
		/* normalized fitness values are used to determine which bin  */
		/* the member fits into; the bins are ten equal divisions of  */
		/* the range 0.0 to 1.0 */

		bins[(int)ceil((memberPtr->fitness/bestFitness)*10-1)]++;
	}

	/* for each bin divide the number of members in the bin by the size of */
	/* the population to get the percentage of the population in that bin  */

	for (ctr = 0; ctr < 10; ctr++)
		bins[ctr] /= populationSize;

	/* add the statistics information to the historical stats array   */
	/* (used to display info in the objective window); update the     */
	/* pointers if needed */

	if (stats.movingPtr == stats.staticPtr) {
		/* write MAX_STAT/2 items to disk */

		/* reset the static ptr */

		stats.staticPtr += MAX_STAT / 2;

		/* reset the generation ptr */

		stats.firstGenerationPtr += MAX_STAT / 2;
	}

	/* fill in this generation's numbers */

	stats.data[stats.movingPtr%MAX_STAT].bestEver = best.objectiveValue[0];
	stats.data[stats.movingPtr%MAX_STAT].best 	  = maximumValue;
	stats.data[stats.movingPtr%MAX_STAT].worst 	  = minimumValue;
	stats.data[stats.movingPtr%MAX_STAT].average  = averageValue;

	/* increment the moving pointer */

	++stats.movingPtr;

	/* increment the generation counter */

	generationNumber++;
}



void saveBestList(memberPtr)
	/*
	========================================
	:purpose
		saves ten best members ever found
		based on their fitness values; kind
		of kludgy, but after all we're only
		saving ten numbers; make this better
		later
	========================================
	*/
 memberType *memberPtr;
{
	short theCell = 0;
	
	/* find where to insert the new member */
		
	while (best.fitness[theCell++] > memberPtr->fitness);
	
	/* if it's already in the list, don't bother entering it */
	/* note: it's possible that two members with equal fitness */
	/* could have different solutions, but we are not worrying */
	/* about differentiating between these at this time */
		
	if (best.fitness[--theCell] == memberPtr->fitness)
		return;
	
	/* shift the list to make room */
	
	shiftBestList(theCell);
	
	/* insert the new member */
		
	best.fitness[theCell] = memberPtr->fitness;
	best.objectiveValue  [theCell] = memberPtr->objectiveValue;
	copyChromosome(memberPtr->chromosome, best.chromosome[theCell]);

	/* if this is a best ever, let the user know by updating the user window */
		
	if (theCell == 0) {
	
#		if MACINTOSH | X_WINDOWS
		updateUserWindow();
#		endif
	  
#		if TTY
		decodeChromosome(memberPtr->chromosome);
		onBestDo();
#		endif
	}
}


	
void shiftBestList(theCell)
	/*
	========================================
	:purpose
		shift the bestList arrays up one cell, 
		starting at theCell; the member that
		is currently in the last cell goes
		away
	========================================
	*/
 short theCell;
{
	int i;
	
	/* shift everything up one cell */
		
	for (i = MAX_BEST-1; i > theCell; i--) {
		best.fitness[i] = best.fitness[i-1];
		best.objectiveValue  [i] = best.objectiveValue  [i-1];
		copyChromosome(best.chromosome [i-1], best.chromosome[i]);
	}
}	/* end shiftBest() */



void printStatistics()
	/*
	========================================
	:purpose
		print the statistics at the terminal
	========================================
	*/
{
#	if MACINTOSH | X_WINDOWS
  	updateStatsDialog();
	updateFitnessWindow();
	updateObjectiveWindow();
#	endif

#	if TTY
    printf("Generation Number: %d\n", generationNumber);
	printf("  Best Ever = %g, ", best.objectiveValue[0]);
	printf("Best = %g, ", maximumValue);
	printf("Average = %g, ",   averageValue);
	printf("Worst = %g\n\n", minimumValue);
#	endif
}



unsigned getGenerationNumber()
	/*
	========================================
	:purpose
		return the generation number
	========================================
	*/
{
	return(generationNumber);
}



float getBestValue()
	/*
	========================================
	:purpose
		return the best objective value ever 
		found
	========================================
	*/
{
	return(best.objectiveValue[0]);
}



chromosomeType *getBestChromosome()
	/*
	========================================
	:purpose
		return a pointer to the best 
		chromosome found
	========================================
	*/
{
	return(best.chromosome[0]);
}



float getWorstValue()
	/*
	========================================
	:purpose
		return the worst objective value found
	========================================
	*/
{
	return(worstValue);
}



float getMaximumValue()
	/*
	========================================
	:purpose
		return the maximum objective value 
		from the current generation
	========================================
	*/
{
	return(maximumValue);
}



float getMinimumValue()
	/*
	========================================
	:purpose
		return the minimum objective value 
		from the current generation
	========================================
	*/
{
	return(minimumValue);
}



float getAverageValue()
	/*	
	========================================
	:purpose
		return the average objective value 
		from the current generation
	========================================
	*/
{
	return(averageValue);
}



fitnessType getSummedFitness()
	/*
	========================================
	:purpose
		return the summed fitness of the 
		current generation
	========================================
	*/
{
	return(summedFitness);
}



fitnessType getAverageFitness()
	/*
	========================================
	:purpose
		return the average fitness of the 
		current generation
	========================================
	*/
{
	return(averageFitness);
}



float *getBins()
	/*
	========================================
	:purpose
		return a pointer to the fitness bins
	========================================
	*/
{
	return(&bins[0]);
}



mainStatsStructType *getStats()
	/*
	========================================
	:purpose
		return a pointer to the objective 
		value stats history
	========================================
	*/
{
	return(&stats);
}



struct bestStruct *getBest()
	/*
	========================================
	:purpose
		return a pointer to the list of ten 
		best solutions
	========================================
	*/
{
	return(&best);
}

