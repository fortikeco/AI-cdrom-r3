/*
 ==============================================================================
 gaPopulation.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module contains all functions for creating and manipulating 
	populations of chromosomes and permuations
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaPopulation.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

 /*
 ========================================
 global variables
 
 globals used defined within this module 
 ========================================
 */
 
static unsigned				populationSize;		/* size of the population */
static populationType		thePopulation,		/* the population */
							theParentList,		/* members that will mate */
							theLoserList;		/* members that wont mate */
static chromosomeType  	   *child[2];			/* temp child chromosomes */

/*
 ========================================
 functions
 ========================================
 */


void initPopulation()
	/*
	========================================
	:purpose
		initialize the population module;
		called at program startup and during
		reinitialization; sets up global 
		variable initial values
	========================================
	*/
{
	setPopulationSize(100);		/* default size */
}



void preCreateInitPopulation()
	/*
	========================================
	:purpose
		initialize the population module;
		called just prior to creating the 
		population
	========================================
	*/
{
}



void preRunInitPopulation()
	/*
	========================================
	:purpose
		initialize the population module;
		called just prior to running the GAs
	========================================
	*/
{
}



void reinitPopulation(how)
 int how;
{
	static unsigned oldPopulationSize;

	switch (how) {
		case (SAVE) :
			oldPopulationSize = populationSize;
			if (gaFlags.populationCreated || gaFlags.populationChanged)
				freePopulation;
			break;

		case (RESTORE) :
			setPopulationSize(oldPopulationSize);
			break;

		default :
			die("reinitPopulation(): bad how");
			break;
	}
}



void savePopulationParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all population module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save population size */

    fprintf(fp, "%d\t\t\tpopulation size \n", populationSize);
}



void loadPopulationParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all population module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the population size */

    setPopulationSize(fgetInt(fp));
}


	
#define DRAW -1

void createPopulation()
	/*
	========================================
	:purpose
		create the population
	========================================
	*/
{
	register int i;
	register memberType *memberPtr;
	char *string = "Creating Population";
	
	/* ask user if we should delete the existing population */

	if (!checkPopulationStatus())
		return;

	/* turn on any displays used to status the user */

#	if MACINTOSH
    createPopDialog(string, ON, 0, 0);
#	endif
  
#	if TTY
	printf("   %s: ", string);
#	endif

	/* initialize all other modules before creating the population */

	preCreateInitGA();

	/* allocate space for a list of pointers for the population */

	thePopulation = (populationType)malloc(populationSize 
											* sizeof(memberType *));
	if (thePopulation == NULL)
		die("createPopulation(): can't allocate thePopulation");

	/* allocate space for a list of pointers for the parent list */
	/* (mating pool); these will be reused, when creating the    */
	/* new population, but only after the loser list is empty	 */

	theParentList = (populationType)malloc(populationSize 
											* sizeof(memberType *));
	if (theParentList == NULL)
		die("createPopulation(): can't allocate theParentList");

	/* allocate space for a list of pointers for the members not */
	/* chosen to mate these will be used first for children of   */
	/* the new population  */
	
	theLoserList  = (populationType)malloc(populationSize 
											* sizeof(memberType *));
	if (theLoserList == NULL)
		die("createPopulation(): can't allocate theLoserList");
	
	/* the following strings are used in newPopulation() to */
	/* create the two new children for the next generation  */

	child[0] = createChromosome();
	child[1] = createChromosome();

	/* create member structures for each member of the population */

	for(i = 0; i < populationSize; i++) {

		/* create a new member struct */

		thePopulation[i] = createMember();

		/* update any displays used to provide status to the user */

#		if MACINTOSH
		createPopDialog(string, DRAW, populationSize, i);
#		endif

#		if TTY
		if (!((i+1) % 10))
			printf("%d", i+1);
		else putchar('.');
		fflush(stdout);
#		endif
	}

	/* turn off any displays */

#	if MACINTOSH
	createPopDialog(string, OFF, 0, 0);
#	endif

	/* set flags saying we have a population created */

	gaFlags.populationCreated = TRUE;
	gaFlags.populationChanged = FALSE;
}



bool checkPopulationStatus()
	/*
	========================================
	:purpose
		see if a population exists and ask 
		the user if we should delete the 
		population before doing whatever 
		the user has requested; this is done 
		when changing a variable (e.g., the 
		population size or the number of 
		parameters) would make the population
		obsolete
	========================================
	*/
{
	if (!gaFlags.populationCreated)					/* no population exists */
		return(TRUE);
	else {
		if (yesNoDialog("Delete existing population")) {
			freePopulation();
			return(TRUE);
		}
		else
			return(FALSE);
	}
}



void freePopulation()
	/*
	========================================
	:purpose
		delete the population from memory
	========================================
	*/
{
	register int i;
	register memberType *memberPtr;
	char	*string = "Deleting population";
	
	for(i = 0; i < populationSize; i++) {
		memberPtr = thePopulation[i];
		free(memberPtr->chromosome);
		free(thePopulation[i]);
	}
  
	free(thePopulation);
	free(theParentList);
	free(theLoserList);
	free(child[0]);
	free(child[1]);
	
	gaFlags.populationCreated = FALSE;
}



void enterPopulationSize()
	/*
	========================================
	:purpose
		allow the user to enter the 
		population size at the keyboard
	========================================
	*/
{
	bool okChoice;
	char *errorString = "Population size must be an even number.";
	unsigned newSize;
	
	/* ask user if we should delete the population */

	if (!checkPopulationStatus())
		return;

	/* get the new population size */
		
	okChoice = FALSE;

	while (!okChoice) {
	  	newSize = populationSize;
	  	singleIntEntryDialog((int *)&newSize, "population size", 
	  											"[x >= 2]", 2, 30000);
	  	if (newSize % 2)
	  		okAlert(errorString);
	  	else {
			setPopulationSize(newSize);
			okChoice = TRUE;
		}
	}
	gaFlags.populationChanged = TRUE;
}


	
void setPopulationSize(size)
	/*
	========================================
	:purpose
		set the population size
	========================================
	*/
 int size;
{
	char string[80];
	char *format;

	if (populationSize == size)
		return;

	if (!checkPopulationStatus())
		return;

	if (size <= 0) {
		format = "population size is invalid: %d";
		sprintf(string, format, size);
		okAlert(string);
		enterPopulationSize();
	}
	else if (size % 2) {
	  	okAlert("Population size must be an even number.");
		enterPopulationSize();
	}
	else {
		populationSize = size;
	}
}


	
void newPopulation()
	/*
	========================================
	:purpose
		form a new population (i.e., a new 
		generation)
	========================================
	*/
{
	register int i, j, k;
	register populationType parents, losers;
	register memberType *newMember, *parent1, *parent2;
	register mutationOperatorType mutationOperator;
	register crossoverOperatorType crossoverOperator;

	/* call the sampling operator to select the parents */

	trace(SELECT);

	(*getSelectionOperator())();	/* calculate expected values */

	trace(SAMPLE);

	(*getSamplingOperator())();		/* sample the parents */

	/* create the new population */

	parents = theParentList;
	losers  = theLoserList;
	mutationOperator  = getMutationOperator();
	crossoverOperator = getCrossoverOperator();

	/* repeatedly use two of the parents to create two new children,  */
	/* depending upon crossover probability, until the new population */
	/* has been filled */

	trace(CROSSOVER);

	for (i = j = 0; i < populationSize; i += 2) {
	
			sufferUserInterface(); /* look for interface events */

		/* assume the parents are randomly shuffled and just walk */
		/* through the parent list by twos */

		parent1 = parents[i];				/* pick the next two parents */
		parent2 = parents[i+1];

		/* if some crossover operator has been selected (i.e., the    */
		/* function pointer is not NULL [NULL signifies the user has  */
		/* turned crossover off]), depending upon a weighted coin     */
		/* toss, cross the two parent strings and create two children */

		if (crossoverOperator) {

			/* flip a weighted coin to see if we should crossover; if */
			/* not, simply copy the parents to the children */

		    if (weShouldCrossover()) {

				/* crossover */

				(*crossoverOperator)(parent1->chromosome, 
						parent2->chromosome, child[0], child[1]);

    		} else {

				/* no crossover; copy the parents */

		       	copyChromosome(parent1->chromosome, child[0]);
       			copyChromosome(parent2->chromosome, child[1]);
			}
		}

		/* now that we have two children, for each of the two parents */
		/* decrement that parents' mating count; for each child, find */
		/* a member structure for it and copy the child to it */

		for (k = 0; k < 2; k++) {
		
				sufferUserInterface();
					
			/* decrement the parent's mating count */

			if (--parents[i+k]->numberOfMatings < 0)
				die("newPopulation(): negative mating number");

			/* find an unused member structure to use for the child        */
			/* in the new population and copy the child to this structure; */
			/* if the current parent has a positive mating count, use a    */
			/* member from the loser list, otherwise use the parent        */

			if (parents[i+k]->numberOfMatings > 0)	/* any more matings? */
				newMember = losers[j++];		 /* child is from losers */
			else
				newMember = parents[i+k];		 /* parent becomes child */
			
				sufferUserInterface();
			
			/* copy the temporary child to the newMember pointer */
			/* and decode the string for computing fitness */

			copyChromosome(child[0], newMember->chromosome);
			
				sufferUserInterface();
		} 
	sufferUserInterface();
	}

    /* if we have a mutation operator (i.e., the user hasn't  */
    /* turned mutation off), mutate the new population        */
	/* I've separated mutation from crossover in a separate   */
	/* loop for convenience, even though it may take slightly */
	/* longer */

	trace(MUTATION);

	for (i = 0; i < populationSize; i++) {
		if (mutationOperator) {
			(*mutationOperator) (thePopulation[i]->chromosome);
		}
	}
}


void printPopulation()
	/*
	========================================
	:purpose
		print the population to the terminal
	========================================
	*/
{
	register int ctr;
	register populationType population;
	register memberType *memberPtr;
	
	population = thePopulation;
	
	memberPtr = *population++;
	
	for (ctr = 0; ctr < populationSize; ctr++, memberPtr = *population++) {
		printf("%3d:", ctr);
		printChromosome("", memberPtr->chromosome, 'b');
		printf(" %g", memberPtr->objectiveValue);
		printf(" %g\n", memberPtr->fitness);
	}
}



void sortPopulation(direction)
	/*
	========================================
	:purpose
		sort the population, ascending or 
		descending, according to fitness
	========================================
	*/
 int direction;
{
	if (direction == ascending)
		qsort(thePopulation, populationSize, sizeof(memberType *), 
				compareMembers);
	else
		qsort(thePopulation, populationSize, sizeof(memberType *), 
				inverseCompareMembers);
}



memberType *binarySearchPop(key)
	/*
	========================================
	:purpose
		binary search the population; the 
		key is an expected value; we differ
		from ordinary binary search in that
		we look to match the key within some
		range (as in roullete wheel sampling)
		rather than exactly
	========================================
	*/
 float key;
{
	register float diff;
	register populationType low  = thePopulation;
	register populationType high = thePopulation+(populationSize-1);
	register populationType mid;
	
	FOREVER {
		mid = low + (high-low) / 2;
		diff =  key - (*mid)->cummTSR;
		if (diff == 0.0)
			return(*mid);
		else if (high <= low)	/* this is where we differ from ordinary */
			if (diff > 0.0)		/* binary search; we are looking for key */
				return(*(mid+1));	/* within some range */
			else
				return(*mid);
		else if (diff < 0.0)
			high = mid - 1;
		else if (diff > 0.0)
			low  = mid + 1;
	}
}



unsigned getPopulationSize()
	/*
	========================================
	:purpose
		return the population size
	========================================
	*/
{
	return(populationSize);
}


	
populationType getThePopulation()
	/*
	========================================
	:purpose
		return a pointer to the population
	========================================
	*/
{
	return(thePopulation);
}


	
populationType getTheParentList()
	/*
	========================================
	:purpose
		return a pointer to the parent list
	========================================
	*/
{
	return(theParentList);
}


	
populationType getTheLoserList()
	/*
	========================================
	:purpose
		return a pointer to the loser list
	========================================
	*/
{
	return(theLoserList);
}

