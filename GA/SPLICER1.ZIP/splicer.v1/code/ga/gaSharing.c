/*
 ========================================
 gaSharing.c

 :written by

	steven e. bayer
	the mitre corporation

 :purpose
	this module contains code for fitness 
	sharing for multimodal functions

 :version 1.0; release date 03/01/91
 ========================================
 */

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaSharing.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

static sharingOperatorStructType sharingOperators[] = {
	{ NULL, "None", YES, NO_ALIAS }
};

static int currentSharingOperator;

/*
 ========================================
 functions
 ========================================
 */

void initSharing()
    /*
    ========================================
    :purpose
        initialize the sharing module;
        called at program startup and during
        reinitialization; sets up global
        variable initial values
    ========================================
    */
{
    setSharingOperator(NO_SHARING);        /* default method */
}



void preCreateInitSharing()
    /*
    ========================================
    :purpose
        initialize the sharing module;
        called just prior to creating the
        population
    ========================================
    */
{
}



void preRunInitSharing()
    /*
    ========================================
    :purpose
        initialize the sharing module;
        called just prior to running the GAs
    ========================================
    */
{
}



void reinitSharing(how)
 int how;
{
    static int oldSharingOperator;

    switch (how) {
        case (SAVE) :
            oldSharingOperator = currentSharingOperator;
            break;

        case (RESTORE) :
            setSharingOperator(oldSharingOperator);
            break;

        default :
            die("reinitSharing(): bad how");
            break;
    }
}



void saveSharingParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all sharing module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save current sharing operator */

    fprintf(fp, "%d\t\t\tsharing operator: %s\n", currentSharingOperator,
                        sharingOperators[currentSharingOperator].name);
}



void loadSharingParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all sharing module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the sharing operator */

    setSharingOperator(fgetInt(fp));
}



sharingOperatorType getSharingOperator()
    /*
    ========================================
    :purpose
        return a pointer to the selected
        fitness sharing operator
    ========================================
    */
{
    return(sharingOperators[currentSharingOperator].ptr);
}



char *getSharingOperatorName()
    /*
    ========================================
    :purpose
        return a pointer to the selected
		fitness sharing operator name
    ========================================
	*/
{
    return(sharingOperators[currentSharingOperator].name);
}



int getSharingOperatorId()
    /*
    ========================================
    :purpose
        return the number of the currently 
		selected sharing operator
    ========================================
    */
{
    return(currentSharingOperator);
}



sharingOperatorStructType *getSharingOperators()
    /*
    ========================================
    :purpose
        return a pointer to the sharing
        operator array
    ========================================
    */
{
    return(sharingOperators);
}



int getNumberOfSharingOperators()
    /*
    ========================================
    :purpose
        return the number of sharing operators 
        defined in gaSharing.h
    ========================================
    */
{
    return(NUMBER_OF_SHARING_OPERATORS);
}


#if TTY
void chooseSharingOperator()
    /*
    ========================================
    :purpose
        allow the user to choose the
        fitness sharing operator
    ========================================
    */
{
    int number;
    bool okChoice = FALSE;

    putchar('\n');
    for (i = 0; i < NUMBER_OF_SHARING_OPERATORS; i++) {
        printf("   %d.  %s\n", i, sharingOperators[i].name);
    }
    while (!okChoice) {
        printf("\n   Enter number: ");
        scanf("%d", &number);
        if ((number < 0) || (number >= NUMBER_OF_SHARING_OPERATORS))
            putchar('\7');
        else
            okChoice = TRUE;
    }
    setSharingOperator(number);
}
#endif


void setSharingOperator(operatorId)
    /*
    ========================================
    :purpose
        set the fitness sharing operator 
		according to the input parameter
    ========================================
    */
 int operatorId;
{
	if ((operatorId >= 0) && (operatorId < NUMBER_OF_SHARING_OPERATORS))
		currentSharingOperator = operatorId;
	else
		die("setSharingOperator(): bad operatorId");

#   if MACINTOSH | X_WINDOWS
    updateSharingMenu(operatorId);
    updateParamDialog();
#   endif
}


