/*
 ==============================================================================
 gaRandom.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module contains code for generating random numbers

 :version 1.0; release date 03/01/91
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaRandom.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */
 
unsigned computeSeed();

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */
 
/*
 ========================================
 global variables
 
 globals defined within this module 
 ========================================
 */

static int seed;

/*
 ========================================
 functions
 ========================================
 */


void initRandom()
	/* 
	========================================
	:purpose
		initialize the random number generator
	========================================
	*/
{
	setRandomSeed(-1);	/* seed random generator using the clock */
}



void preCreateInitRandom()
	/* 
	========================================
	:purpose
		initialize the random module called 
		just before creating the population
	========================================
	*/
{
	seedRandomGen();	/* reset the random generator before creation */
}



void preRunInitRandom()
	/* 
	========================================
	:purpose
		initialize the random module
		called just before running the GAs
	========================================
	*/
{
}



void reinitRandom(how)
 int how;
{
    static int oldRandomSeed;

    switch (how) {
        case (SAVE) :
            oldRandomSeed = seed;
            break;

        case (RESTORE) :
            setRandomSeed(oldRandomSeed);
            break;

        default :
            die("reinitRandom(): bad how");
            break;
    }
}



void saveRandomParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all random module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save the random seed */

    fprintf(fp, "%d\t\t\trandom seed\n", seed);
}



void loadRandomParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all random module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the random seed */

    setRandomSeed(fgetInt(fp));
}



void seedRandomGen()
	/* 
	========================================
	:purpose
		seed the random number generator
	========================================
	*/
{
	if (seed < 0)				/* if seed is negative, compute the seed */
		srand(computeSeed());
	else						/* else use seed */
		srand((unsigned)seed);
}



unsigned computeSeed()
	/* 
	========================================
	:purpose
		compute new seed for the random 
		number generator using the clock
	========================================
	*/
{
#	if SUN
#	include <sys/types.h>
#	endif

#	if THINKC
#	include <time.h>
#	endif

	time_t timeOfDay;

	timeOfDay = time((time_t *)0) % 32767;
	return((unsigned)timeOfDay);
}



void enterRandomSeed()
	/* 
	========================================
	:purpose
		allow the user to enter the seed for 
		the random number generator at the 
		keyboard
	========================================
	*/
{
	int newSeed = seed;
	
  	singleIntEntryDialog(&newSeed, "random number seed", 
  				"[0 <= x <= 32767; or -1 to use clock]", -1, 32767);
	setRandomSeed(newSeed);
}



void setRandomSeed(newSeed)
	/* 
	========================================
	:purpose
		set the random generator seed to the 
		input parameter newSeed
	========================================
	*/
 int newSeed;
{
	char string[80];
	char *format;
	
	if (newSeed >= -1) {
		seed = newSeed;
		seedRandomGen();
	}
	else {
		format = "random seed is invalid: %d";
		sprintf(string, format, newSeed);
		okAlert(string);
		enterRandomSeed();
	}
}



int getRandomSeed()
	/* 
	========================================
	:purpose
		return the random number seed
	========================================
	*/
{
	return(seed);
}



bool coinFlip(probability)
	/* 
	========================================
	:purpose
		flip a coin, biased by some probability
	========================================
	*/
 float probability;
{
	if (probability == 1.0)
		return(TRUE);
	else {
		return(((float)rand() / MAXRAND) <= probability);
	}
}



int rangeRandom(low, high)
	/* 
	========================================
	:purpose
		return a random integer in some range 
		(between low and high)
	========================================
	*/
 int low, high;
{
	register int j;
	
	if (low >= high)
		j = low;
	else
		j = ((int) (((float) rand()/MAXRAND) * (high - low + 1) + low));
	if (j > high) j = high;
		
	return(j);
}



unsigned long getRandomLong()
	/* 
	========================================
	:purpose
		return a random unsigned long
	========================================
	*/
{
	register int j;
	register unsigned long randomNum = 0l;
	
	randomNum = (unsigned long)rand() 
						<< (NUMLONGBITS - (NUMLONGBITS % MAXRANDBITS));

	for (j = 0; j < NUMLONGBITS / MAXRANDBITS; j++)
		randomNum |= (unsigned long)rand() << (j * MAXRANDBITS);
 	return(randomNum);
}
	
