/*
 ==============================================================================
 gaFileio.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module contains all functions used to read from or write to disk
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/
 
/*
 ========================================
 #include files
 ========================================
 */
 
#include "gaMain.h"
#include <string.h>

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaFileio.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */
 
/*
 ========================================
 global variables
 
 globals define within this module
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 functions
 ========================================
 */

void saveParameters()
	/*
	========================================
	:purpose
		save parameter settings to disk
	========================================
	*/
{
	register FILE	*fp;
	register int	i;
	register struct parameterStruct	*parameterPtr;

	if ((fp = openFile(SAVE, "Save parameter file as:", 	
											"Save Parameters")) == NULL)
        return;

	fputs("parameter settings\n\n", fp);

	saveParametersParams(fp);
	savePopulationParams(fp);
	saveScalingParams(fp);
	saveSharingParams(fp);
	saveSelectionParams(fp);
	saveSamplingParams(fp);
	saveCrossoverParams(fp);
	saveMutationParams(fp);
	saveRandomParams(fp);

	fclose(fp);
}

	

void loadParameters()
	/*
	========================================
	:purpose
		load parameter settings from disk
	========================================
	*/
{
	char	theInput[80];
	char	*theString;
	FILE	*fp;
	int		i, temp;
    char	*string = "                                                       ";

	if (!checkPopulationStatus())
		return;

	if ((fp = openFile(LOAD, "Enter name of parameter file to load:", 
											"Load Parameters")) == NULL)
		return;

	fgets(theInput, 80, fp);	
	if (strcmp("parameter settings\n", theInput)) {
		fclose(fp);
		theString = "Bad parameter file.";
		okAlert(theString);
		return;
	}
	fgets(theInput, 80, fp);

	loadParametersParams(fp);
	loadPopulationParams(fp);
	loadScalingParams(fp);
	loadSharingParams(fp);
	loadSelectionParams(fp);
	loadSamplingParams(fp);
	loadCrossoverParams(fp);
	loadMutationParams(fp);
	loadRandomParams(fp);

	fclose(fp);	
}


	
void saveState()
	/*
	========================================
	:purpose
		save state information to disk (this 
		function is not implemented yet)
	 ========================================
	*/
{
}


	
void loadState()
	/*
	========================================
	:purpose
		load previously saved state 
		information from disk (this 
		function is not implemented yet)
	========================================
	*/
{
}


	
void saveBest()
	/*
	========================================
	:purpose
		save best solutions to disk
	========================================
	*/
{
	FILE	*fp;
	struct bestStruct *best;
	int		i, j;
	unsigned numberOfParameters;
	struct parameterStruct	*parameterPtr;

	if ((fp = openFile(SAVE, "Save solution file as:", 
												"Save Solutions")) == NULL)
		return;

	best = getBest();
	
	for (i = 0; i < MAX_BEST; i++) {
		fprintf(fp, "%d.0\n", i);
		fprintf(fp, "\tvalue = %f\n", best->objectiveValue[i]);
		decodeChromosome(best->chromosome[i]);
		fputs("\tparameters: \n", fp);
		saveChromosome(fp);
		fputs("\n", fp);
	}
	
	fclose(fp);
}



int fgetInt(fp)
	/*
	========================================
	:purpose
		read an integer from a file
	========================================
	*/
 FILE *fp;
{
	char theString[80];
	
	fgets(theString, 80, fp);
	return(atoi(theString));
}



float fgetFloat(fp)
	/*
	========================================
	:purpose
		read a real number from a file	
	========================================
	*/
 FILE *fp;
{
	char theString[80];
	
	fgets(theString, 80, fp);
	return(atof(theString));
}

