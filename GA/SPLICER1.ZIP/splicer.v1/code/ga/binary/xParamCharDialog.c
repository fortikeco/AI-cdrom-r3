/*
 ==============================================================================
 xParamCharDialog.c

 :written by

    steven e. bayer
    the mitre corporation

 :purpose

    this module contains code for the parameter characteristics dialog box
	(attached to the parameter characteristics button on the control
	parameters dialog box) for the X-Windows interface

 :version 1.0; release date 03/01/91

 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainB.h"
#include "myXlib.h"

#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#if MOTIF
#   include <Xm/Xm.h>
#   include <Xm/MainW.h>
#endif

#if HPW
#   include <Xw/Xw.h>
#   include <Xw/BBoard.h>
#   include <Xw/RCManager.h>
#   include <Xw/List.h>
#   include <Xw/PButton.h>
#   include <Xw/SText.h>
#   include <Xw/TextEdit.h>
#endif

/*
 ========================================
 global functions headers

 these functions are available to any
 other module
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to
 this module
 ========================================
 */

/*
 ========================================
 external variables

 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

extern bool sameSizeParameters; /* from gaParametersB.c */
extern bool normalize;			/* ditto */

/*
 ========================================
 global variables

 globals defined within this module
 ========================================
 */

/*
 ========================================
 functions
 ========================================
 */

/***************************************************************************
    parameter characteristics dialog box stuff
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
    bool            setFlag;
    char            *windowTitle;
    bool            ok;

    Widget          listWidget;
    Widget          textEditWidget;
    Widget          sameSizeButton;
    Widget          normalizeButton;
    WidgetList      theCells;
    int             numberOfCells;
} pcStruct;

pcStruct paramCharStruct;


void paramCharEnterCB(w, paramCharStruct, callData)
    /*
    ========================================
    :purpose
        handles the enter button for the 
		parameter characteristics dialog
		box
    ========================================
    */
 Widget         w;
 pcStruct       *paramCharStruct;
 caddr_t        callData;
{
    register    struct parameterStruct *parameterPtr;
    char        *string;
    char        text[10];
    short       size;
    long        temp;
    unsigned    numberOfParameters;
    int         i;
    bool        setFlag;
    WidgetList  *theCell;
    Arg         wargs[1];

    if (gaFlags.runningGA || gaFlags.stop) /* no changes while running */
        return;

    if (!checkPopulationStatus())
        return;

    parameterPtr = getParameterArray();

    string = (char *) XwTextCopyBuffer(paramCharStruct->textEditWidget);
    XtFree(string);

    size = atoi(string);
    if ((size < 1) || (size > 31)) {
        okAlert("Size must be: 1 <= size <= 31");
        return;
    }

    XtSetArg(wargs[0], XtNset, &setFlag);
    XtGetValues(paramCharStruct->sameSizeButton, wargs, 1);
    if (setFlag) {
        numberOfParameters = getNumberOfParameters();
        for (i = 0; i < numberOfParameters; i++) {
            /* set the appropriate static text widget */
            sprintf(text, "%3d:  %2d", i, size);
            setTextField(paramCharStruct->theCells[i], text);
            /* set the size in the parameter array */
            setParameterSize(i, size);
        }
    } else {
        /* see which cell is selected */
        XtSetArg(wargs[0], XtNselectedElements, &theCell);
        XtGetValues(paramCharStruct->listWidget, wargs, 1);
            /*
                for now, just look sequentially for the proper cell;
                later, make this faster, if necessary
            */
        for(i = 0; i < paramCharStruct->numberOfCells; i++)
            if (*theCell[0] == paramCharStruct->theCells[i])
                break;

        /* set the appropriate static text widget */
        sprintf(text, "%3d:  %2d", i, size);
        setTextField(*theCell[0], text);
        /* set the size in the parameter array */
        setParameterSize(i, size);
    }
}



void setParameterSizeListValues(numberOfParameters)
    /*
    ========================================
    :purpose
        initializes the values of the 
        widgets that make up the parameter
		size list; gets these values from
		the parameter array in gaParametersB.c
    ========================================
    */
 unsigned numberOfParameters;
{
    register struct parameterStruct *parameterPtr;
    unsigned    size;
    char        *theString[8];
    int         i;
    Arg         wargs[1];

    parameterPtr = getParameterArray();
    for (i = 0; i < numberOfParameters; i++) {
        size = parameterPtr->size;
        parameterPtr++;
        sprintf(theString, "%3d:  %2d", i, size);
        setTextField(paramCharStruct.theCells[i], theString);
    }
}



void paramSizeListSelectCB(w, clientData, callData)
    /*
    ========================================
    :purpose
    	this function is called when the 
		user selects a cell within the 
		parameter size list; it is attached 
		to the select callback list of every 
		static text field within the list 
		widget; it enters the size of the 
		associated parameter into the text 
		edit field of the parameter 
		characterstics dialog box
    ========================================
    */
 Widget         w;
 caddr_t        clientData;
 caddr_t        callData;
{
    register struct parameterStruct *parameterPtr;
    unsigned    size;
    char        *theString[8];
    int         i;
    Arg         wargs[1];

    /*
        for now, just look sequentially for the index of this widget;
        later make it faster by using some other means
    */
    for (i = 0; i < paramCharStruct.numberOfCells; i++) {
        if (w == paramCharStruct.theCells[i])
            break;
    }

    /*
        get the size of this parameter
    */
    parameterPtr = getParameterArray();
    size = parameterPtr[i].size;

    /*
        enter the size of this parameter into the text edit fieldd
    */
    sprintf(theString, "%d", size);
    XwTextClearBuffer(paramCharStruct.textEditWidget);
    XwTextInsert(paramCharStruct.textEditWidget, theString);
}



void resizeParameterSizeList(numberOfParameters)
    /*
    ========================================
    :purpose
        resize the parameter size list when
		the number of parameters changes
    ========================================
    */
 unsigned numberOfParameters;
{
    int i;
    WidgetList tempList;

    /* create a temporary widget list of the new size */
    tempList = (WidgetList) XtMalloc(numberOfParameters * sizeof(Widget));

    if (numberOfParameters < paramCharStruct.numberOfCells) {
        /* delete the unnecessary rows */
        for (i = 0; i < paramCharStruct.numberOfCells; i++) {
            if (i < numberOfParameters) {
                tempList[i] = paramCharStruct.theCells[i];
            }
            else {
                XtDestroyWidget(paramCharStruct.theCells[i]);
            }
        }
    }
    else {
        /* add the necessary rows */
        for (i = 0; i < numberOfParameters; i++) {
            if (i < paramCharStruct.numberOfCells) {
                tempList[i] = paramCharStruct.theCells[i];
            }
            else {
                tempList[i] = XtCreateManagedWidget("paramCharStaticText",
                                            XwstaticTextWidgetClass,
                                            paramCharStruct.listWidget,
                                            NULL, 0);
                XtAddCallback(tempList[i], XtNselect, paramSizeListSelectCB,
                                                        NULL);
            }
        }
    }

    /* delete the old widget list */
    if (paramCharStruct.theCells)
        XtFree(paramCharStruct.theCells);

    /* save the new widget list */
    paramCharStruct.theCells = tempList;

    /* save the new number of cells */
    paramCharStruct.numberOfCells = numberOfParameters;

    /* fill in the cell values */
    setParameterSizeListValues(numberOfParameters);
}




void paramCharOkCB(w, paramCharStruct, callData)
    /*
    ========================================
    :purpose
        handles the ok button in the 
		parameter characterists dialog box
    ========================================
    */
 Widget         w;
 pcStruct       *paramCharStruct;
 caddr_t        callData;
{
    Arg     wargs[1];
    bool    sameSizeFlag, normalizeFlag;

    if (!(gaFlags.runningGA || gaFlags.stop)) { /* no changes while running */
        XtSetArg(wargs[0], XtNset, &sameSizeFlag);
        XtGetValues(paramCharStruct->sameSizeButton, wargs, 1);
        setSameSizeParameters(sameSizeFlag);

        XtSetArg(wargs[0], XtNset, &normalizeFlag);
        XtGetValues(paramCharStruct->normalizeButton, wargs, 1);
        setNormalize(normalizeFlag);
    }

    XtPopdown(paramCharStruct->shellWidget);
    if (paramCharStruct->enableButton) {
        XtSetArg(wargs[0], XtNsensitive, TRUE);
        XtSetValues(paramCharStruct->enableButton, wargs, 1);
    }
}



void popupParamCharDialogCB(w, paramCharStruct, callData)
    /*
    ========================================
    :purpose
        pops up the parameter characteristics
		dialog box when the appropriate 
		button is selected on the control
		parameters dialog box
    ========================================
    */
 Widget         w;
 pcStruct       *paramCharStruct;
 caddr_t        callData;
{
    Arg wargs[1];

	setParameterSizeListValues(getNumberOfParameters());

    if (paramCharStruct->enableButton) {
        XtSetArg(wargs[0], XtNsensitive, FALSE);
        XtSetValues(paramCharStruct->enableButton, wargs, 1);
    }

    XtSetArg(wargs[0], XtNset, sameSizeParameters);
    XtSetValues(paramCharStruct->sameSizeButton, wargs, 1);

    XtSetArg(wargs[0], XtNset, normalize);
    XtSetValues(paramCharStruct->normalizeButton, wargs, 1);

    XtPopup(paramCharStruct->shellWidget, XtGrabNone);
    nameWindow(paramCharStruct->shellWidget, paramCharStruct->windowTitle);
}



Widget setUpParamCharDialog(paramCharStruct)
    /*
    ========================================
    :purpose
        creates the widgets for the 
		parameter characteristics dialog
		box
    ========================================
    */
 pcStruct *paramCharStruct;
{
    Widget  paramCharPopup, paramCharPane, enterButton,
            sameSizeST, normalizeST, okButton;
    Arg     wargs[10];
    int     n = 0;


    /*
        create a popup shell to hold the dialog box
    */
    n = 0;
    XtSetArg(wargs[n], XtNwidth,  320); n++;
    XtSetArg(wargs[n], XtNheight, 150); n++;
    paramCharStruct->shellWidget = paramCharPopup =
                        XtCreatePopupShell("paramCharPopup", shellWidgetClass,
                                            paramCharStruct->parent, wargs, n);

    /*
        create a BulletinBoard widget to hold the fields
    */
    paramCharPane  = XtCreateManagedWidget("paramCharPane",
                                            XwbulletinWidgetClass,
                                            paramCharPopup, NULL, 0);

    /*
        create the text edit field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      10);              n++;
    XtSetArg(wargs[n], XtNy,      10);              n++;
    XtSetArg(wargs[n], XtNwidth,  100);             n++;
    XtSetArg(wargs[n], XtNheight, 20);              n++;
    XtSetArg(wargs[n], XtNeditType, XwtextEdit);    n++;
    paramCharStruct->textEditWidget = createOneLineTextEditWidget(
                                                            "paramCharTEdit",
                                                            paramCharPane,
                                                            wargs, n);

    /*
        create the Enter button
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      120); n++;
    XtSetArg(wargs[n], XtNy,      10);  n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "Enter");  n++;
    enterButton = XtCreateManagedWidget("paramCharEnterButton",
                                XwpushButtonWidgetClass,
                                paramCharPane, wargs, n);


    XtAddCallback(enterButton, XtNrelease, paramCharEnterCB, paramCharStruct);

    /*
        create the same size button
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      10);    n++;
    XtSetArg(wargs[n], XtNy,      40);    n++;
    XtSetArg(wargs[n], XtNwidth,  20);    n++;
    XtSetArg(wargs[n], XtNheight, 20);    n++;
    XtSetArg(wargs[n], XtNlabel,  "");    n++;
    XtSetArg(wargs[n], XtNtoggle, TRUE);  n++;
    paramCharStruct->sameSizeButton = XtCreateManagedWidget(
                                                "sameSizeButton",
                                                XwpushButtonWidgetClass,
                                                paramCharPane, wargs, n);

    /*
        create the same size static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,           40);          n++;
    XtSetArg(wargs[n], XtNy,           40);          n++;
    XtSetArg(wargs[n], XtNheight,      22);          n++;
    XtSetArg(wargs[n], XtNstring,      "Same Size"); n++;
    XtSetArg(wargs[n], XtNgravity,     WestGravity); n++;
    XtSetArg(wargs[n], XtNborderWidth, 0);           n++;
    sameSizeST  = XtCreateManagedWidget("static text",
                                        XwstaticTextWidgetClass,
                                        paramCharPane, wargs, n);

    /*
        create the normalize button
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      10);    n++;
    XtSetArg(wargs[n], XtNy,      70);    n++;
    XtSetArg(wargs[n], XtNwidth,  20);    n++;
    XtSetArg(wargs[n], XtNheight, 20);    n++;
    XtSetArg(wargs[n], XtNlabel,  "");    n++;
    XtSetArg(wargs[n], XtNtoggle, TRUE);  n++;
    paramCharStruct->normalizeButton = XtCreateManagedWidget(
                                                "normalizeButton",
                                                XwpushButtonWidgetClass,
                                                paramCharPane, wargs, n);

    /*
        create the normalize static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,           40);          n++;
    XtSetArg(wargs[n], XtNy,           70);          n++;
    XtSetArg(wargs[n], XtNheight,      22);          n++;
    XtSetArg(wargs[n], XtNstring,      "Normalize"); n++;
    XtSetArg(wargs[n], XtNgravity,     WestGravity); n++;
    XtSetArg(wargs[n], XtNborderWidth, 0);           n++;
    normalizeST  = XtCreateManagedWidget("static text",
                                        XwstaticTextWidgetClass,
                                        paramCharPane, wargs, n);

    /*
        create the list widget
    */
    n = 0;
    XtSetArg(wargs[n], XtNx, 210);                  n++;
    XtSetArg(wargs[n], XtNy, 10);                   n++;
    XtSetArg(wargs[n], XtNwidth, 100);              n++;
    XtSetArg(wargs[n], XtNheight, 100);             n++;
    XtSetArg(wargs[n], XtNcolumnWidth, 80);         n++;
    XtSetArg(wargs[n], XtNforceVerticalSB, TRUE);   n++;
    XtSetArg(wargs[n], XtNelementHighlight, XwINVERT);n++;
    XtSetArg(wargs[n], XtNselectionStyle, XwSTICKY);  n++;
    paramCharStruct->listWidget = XtCreateManagedWidget("paramCharList",
                                        XwlistWidgetClass,
                                        paramCharPane, wargs, n);

    /*
        create a OK button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      230); n++;
    XtSetArg(wargs[n], XtNy,      120);  n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "OK");    n++;
    okButton = XtCreateManagedWidget("paramCharOkButton",
                                XwpushButtonWidgetClass,
                                paramCharPane, wargs, n);


    XtAddCallback(okButton, XtNrelease, paramCharOkCB, paramCharStruct);
}


void createParamCharDialog(theButton, theMenuMgr)
    /*
    ========================================
    :purpose
        initializes the paramCharStruct,
		calls the set up function to create
		the widgets and adds a callback to 
		the appropriate button
    ========================================
    */
 Widget theButton;
 Widget theMenuMgr;
{
    paramCharStruct.parent = theMenuMgr;
    paramCharStruct.enableButton = NULL;
    paramCharStruct.windowTitle = "Parameter Characteristics";
    paramCharStruct.theCells = NULL;
    paramCharStruct.numberOfCells = 0;
    setUpParamCharDialog(&paramCharStruct);
    XtAddCallback(theButton, XtNselect, popupParamCharDialogCB, 
													&paramCharStruct);
}

