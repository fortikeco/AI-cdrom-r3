/*
 ==============================================================================
 gaCrossoverB.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module implements the many crossover operators for bit
	strings (a.k.a. chromosomes)
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/
 
/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainB.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaCrossoverB.h; the primary crossover
 header file, gaCrossover.h, externs
 all functions that are common to any
 crossover module
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void crossover(
#   if useFunctionPrototypes
	chromosomeType *, 
	chromosomeType *, 
	chromosomeType *, 
	chromosomeType *
#   endif
);

void multiPointCrossover(
#   if useFunctionPrototypes
    void
#   endif
);

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

static crossoverOperatorStructType	crossoverOperators[] = {
	{ crossover,			"Single Point",	YES, NO_ALIAS },
	{ multiPointCrossover,	"Multi Point",	NO,  NO_ALIAS },
	{ NULL,					"None",			YES, NO_ALIAS }
};

static int currentCrossoverOperator;

static float crossoverProbability;

/*
 ========================================
 functions
 ========================================
 */

void crossover(parent1, parent2, child1, child2)
	/*
	========================================
	:purpose
		implements basic single point 
		crossover operator for bit strings; 
		takes pointers to two chromosomes 
		as parents and to two child 
		chromosomes and uses the child 
		chromosomes to create two children 
		from the parents
	========================================
	*/
 chromosomeType *parent1, *parent2, *child1, *child2;
{
	register int i;
	register unsigned 
		chromosomeSize,					/* total number of bits in chromosome */
		crossoverPoint,						 /* the bit at which to crossover */
		crossoverWord,			   /* the word containing the crossover point */
		crossoverLowBits,  				   /* the parts of the crossover word */
		crossoverHighBits,
		numberOfWords;					   /* number of words in a chromosome */
	
	chromosomeSize = getChromosomeSize();
	numberOfWords  = getNumberOfWords();
	
	/* first, find a random point within the chromosome */
	crossoverPoint     = rangeRandom(1, chromosomeSize);

	/* crossover word contains the crossover point */
	crossoverWord      = (((crossoverPoint / NUMLONGBITS) +
						  ((crossoverPoint % NUMLONGBITS) > 0)) - 1);

	/* get the first and second parts (bits) of the crossover word */
	crossoverHighBits  = (crossoverPoint % NUMLONGBITS);
	crossoverLowBits   = (NUMLONGBITS - crossoverHighBits);

	/* for each word in the chromosomes, copy to the appropriate child */
	for (i = 0; i < numberOfWords; i++) {
		if (i < crossoverWord) {	   /* if we haven't reached the crossover */
			*child1++ = *parent1++;	   /* word, simply copy the whole word    */
			*child2++ = *parent2++;
		}
		else if (i == crossoverWord) {	     /* else split the crossover word */
			*child1 = (getBits(*parent1, NUMLONGBITS-1, crossoverHighBits)
						<< crossoverLowBits);
			*child2 = (getBits(*parent2, NUMLONGBITS-1, crossoverHighBits)
					  	<< crossoverLowBits);
			*child1++ |= getBits(*parent2++, crossoverLowBits-1, 
									crossoverLowBits);
			*child2++ |= getBits(*parent1++, crossoverLowBits-1, 
									crossoverLowBits);
	    }
	    else {						/* we're beyond the crossover word so  */
            *child1++ = *parent2++;	/* simply copy each whole words, but   */
			*child2++ = *parent1++;	/* swap the words between the two      */
		}
	}
}


	
void multiPointCrossover()
	/* 
	========================================
	:purpose
		implements multipoint Crossover
	========================================
	*/
{

	die("multiPointCrossover(): not implemented yet");
}



/*
 ========================================
 the following functions are common to all
 crossover modules; the only things that
 might need to be changed from one module
 to another are the following three init
 functions; all others should work as is
 ========================================
*/

void initCrossover()
    /*
    ========================================
    :purpose
        initialize the crossover module;
        called at program startup and during
        reinitialization; sets up global
        variable initial values
    ========================================
    */
{
    setCrossoverOperator(SINGLEPOINT);
    setCrossoverProbability(0.6);
}



void preCreateInitCrossover()
    /*
    ========================================
    :purpose
        initialize the crossover module;
        called just prior to creating the
        population
    ========================================
    */
{
}



void preRunInitCrossover()
    /*
    ========================================
    :purpose
        initialize the crossover module;
        called just prior to running the GAs
    ========================================
    */
{
}



void reinitCrossover(how)
    /*
    ========================================
    :purpose
        either save or restore all crossover
		global variables; this is called 
		during global reinitialization
    ========================================
    */
 int how;
{
    static int		oldCrossoverOperator;
	static float	oldCrossoverProbability;

    switch (how) {
        case (SAVE) :
            oldCrossoverOperator = currentCrossoverOperator;
			oldCrossoverProbability = crossoverProbability;
            break;

        case (RESTORE) :
            setCrossoverOperator(oldCrossoverOperator);
			setCrossoverProbability(oldCrossoverProbability);
            break;

        default :
            die("reinitCrossover(): bad how");
            break;
    }
}



void saveCrossoverParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all crossover module
        global variables; this is called from
        saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

    /* save current crossover operator */

    fprintf(fp, "%d\t\t\tcrossover operator: %s\n", currentCrossoverOperator,
                        crossoverOperators[currentCrossoverOperator].name);

    /* save the crossover probability */

    fprintf(fp, "%f\t\t\tcrossover probability\n", crossoverProbability);
}



void loadCrossoverParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all crossover module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    /* load the crossover operator */

    setCrossoverOperator(fgetInt(fp));

    /* load the crossover probability */

    setCrossoverProbability(fgetFloat(fp));
}



crossoverOperatorType getCrossoverOperator()
	/*
	========================================
	:purpose
		return a pointer to the current 
		crossover operator
	========================================
	*/
{
	return(crossoverOperators[currentCrossoverOperator].ptr);
}



char *getCrossoverOperatorName()
	/*
	========================================
	:purpose
		return a pointer to the name of the 
		crossover operator
	========================================
	*/
{	
	return(crossoverOperators[currentCrossoverOperator].name);
}



int getCrossoverOperatorId()
	/*
	========================================
	:purpose
		return the id number of the 
		crossover operator
	========================================
	*/
{
	return(currentCrossoverOperator);
}



crossoverOperatorStructType *getCrossoverOperators()
    /*
    ========================================
    :purpose
        return a pointer to the crossover
		operator array
    ========================================
    */
{
    return(crossoverOperators);
}



int getNumberOfCrossoverOperators()
    /*
    ========================================
    :purpose
        return the number of crossover 
		operators defined in gaCrossover.h
    ========================================
    */
{
    return(NUMBER_OF_CROSSOVER_OPERATORS);
}



#if TTY
void chooseCrossoverOperator()

	/*
	========================================
	:purpose
		allow the user to choose the 
		crossover operator from the
		keyboard
	========================================
	*/
{
	int i, number;
	bool okChoice = FALSE;
	
	putchar('\n');
    for (i = 0; i < NUMBER_OF_CROSSOVER_OPERATORS; i++) {
        printf("   %d.  %s\n", i, crossoverOperator[i].name);
    }
	while (!okChoice) {
		printf("\n   Enter number: ");
		scanf("%d", &number);
		if ((number < 1) || (number > NUMBER_OF_CROSSOVER_OPERATORS))
			putchar('\7');
		else
			okChoice = TRUE;
	}
	setCrossoverOperator(number);
}
#endif



void setCrossoverOperator(operatorId)
	/*
	========================================
	:purpose
		set the crossover operator based on 
		the input parameter
	========================================
	*/
 int operatorId;
{
	if ((operatorId >= 0) && (operatorId < NUMBER_OF_CROSSOVER_OPERATORS))
        currentCrossoverOperator = operatorId;
    else
        die("setCrossoverOperator(): bad operatorId");

#	if MACINTOSH | X_WINDOWS
	updateCrossoverMenu(operatorId);
	updateParamDialog();
#	endif
}



bool weShouldCrossover() {
    /*
    ========================================
    :purpose
        determine whether we should crossover
		based on a weighted coinflip
    ========================================
    */
	return (coinFlip(crossoverProbability));
}


	
float getCrossoverProbability() {
	/*
	========================================
	:purpose
		return the crossover probability
	========================================
	*/
	return(crossoverProbability);
}



void setCrossoverProbability(probability)
	/*
	========================================
	:purpose
		set the crossover probability 
		global variable
	========================================
	*/
 float probability;
{
	char string[80];
	char *format;
	
	if ((probability >= 0.0) && (probability <= 1.0)) {
		crossoverProbability = probability;
	}
	else {
		format = "crossover probability is invalid: %f";
		sprintf(string, format, probability);
		okAlert(string);
		enterCrossoverProbability();
	}
}



void enterCrossoverProbability()
	/*
	========================================
	:purpose
		allow the user to enter the 
		crossover probability at the
		keyboard
	========================================
	*/
{
	char *string = "crossover probability";

    singleFloatEntryDialog(&crossoverProbability, string,
                                            "[0.0 <= x <= 1.0]", 0.0, 1.0);
}


