/*
 ==============================================================================
 gaChromosomesB.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	the code in this module pertains to defining bits strings (a.k.a. 
	chromosomes) for position-dependent GA problems
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainB.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaChromosomesB.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */
 
static unsigned chromosomeSize = 0;		/* size in bits of encoded chromosome */
static unsigned numberOfWords = 0;		/* number of words in a chromosome */
static unsigned extraBits = 0;			/* number of bits in the last word */

/*
 ========================================
 functions
 ========================================
 */


void initChromosomes()
	/*
	========================================
	:purpose
		initialize the chromosomes module;
		called at program startup and during
		reinitialization; sets up global 
		variable initial values
	========================================
	*/
{
	chromosomeSize = 0;
	numberOfWords = 0;
	extraBits = 0;
}



void preCreateInitChromosomes()
	/*
	========================================
	:purpose
		initialize the chromosomes module;
		called just prior to creating the 
		population
	========================================
	*/
{
	defineChromosomes();
}



void preRunInitChromosomes()
	/*
	========================================
	:purpose
		initialize the chromosomes module;
		called just prior to running the GAs
	========================================
	*/
{
}



void defineChromosomes()
	/*
	========================================
	:purpose
		this function is called after the problem parameters have been set,
		and before creating the population (i.e., at preCreateInit time, 
		to define the chromosome global variables 
	========================================
	*/
{
	chromosomeSize = sumParameterSizes();
	numberOfWords  = ((chromosomeSize / NUMLONGBITS) +
					 ((chromosomeSize % NUMLONGBITS) > 0));
	extraBits	   = (chromosomeSize % NUMLONGBITS);
}



chromosomeType	*createChromosome()
	/*
	========================================
	:purpose
		dynamically create a chromosome on request and  
		return a pointer to it
	========================================
	*/
{
	register int i;
	register chromosomeType *chromosomePtr;
	
	/* allocate the memory */

	chromosomePtr = (chromosomeType *)malloc(numberOfWords * 
													sizeof(chromosomeType));
	if (chromosomePtr == NULL)
		die("createChromosome(): can't allocate chromosome");

	/* set up initial random values */
	
	for (i = 0; i < numberOfWords; i++)
		chromosomePtr[i] = getRandomLong();

	return(chromosomePtr);
}



void decodeChromosome(chromosomePtr)
	/*
	========================================
	:purpose
		convert an encoded chromosome into separate parameters and 
		stuff them into the parameter array
	========================================
	*/
 chromosomeType *chromosomePtr;
{
	register struct parameterStruct *parameterPtr; 		/* parameter array ptr*/
	register unsigned position;		/* position counter within the chromosome */
	register int wordBit;				 /* position counter within each word */
	register int size;					  /* temp variables to save some time */
	register int diff;
	
    parameterPtr = getParameterArray();
    
    wordBit = NUMLONGBITS;						/* working from high to low */
    
    /* walk through each parameter and decode it */

	for (position = 0; position < chromosomeSize; position += 
													parameterPtr++->size){
		size = parameterPtr->size;							/* save some time */
		diff = wordBit - size;
		
		/* make sure we aren't stepping into the next word */
		if (diff >= 0) {
		
			/* get the bits for this parameter */
			parameterPtr->value = (unsigned)getBits(*chromosomePtr, 
															wordBit-1, size);

			/* if at the end of current word, move to the next word */
			if (diff == 0) {
				chromosomePtr++;						 /* move to next word */
				wordBit = NUMLONGBITS;				 /* reset the int counter */
			}
			else			  		   /* we're still within the current word */
				wordBit -= size;				  /* so decrement the counter */
		}
		else {			 		  /* we have a parameter that spans two words */
			diff = size - wordBit;							/* save some math */
			
			/* get the partial set of bits in the current unsigned long */
			parameterPtr->value = (unsigned)getBits(*chromosomePtr, 
														wordBit-1, wordBit);
						
			/* shift these bits to accomodate the remaining ones */
			parameterPtr->value <<= diff;
						
			chromosomePtr++;						 /* move to the next word */
			
			/* get the remaining bits and or them with the ones we have */
			parameterPtr->value |= (unsigned)getBits(*chromosomePtr, 
														NUMLONGBITS-1, diff);

			wordBit = NUMLONGBITS - diff;			/* reset the bit position */
		}

		/* normalize the value? */
		/* if (gaFlags.normalize)	*/	
			parameterPtr->normalizedValue = ((float) parameterPtr->value / 
										(float) parameterPtr->normalizeFactor);
	}
}



#if BOGUS
void encodeChromosome(chromosomePtr)
	/*
	========================================
	:purpose
		encode each parameter into a chromosome; I don't know why 
		this would ever be needed; I must have thought at some point 
		it would, so it's here if ever required
	========================================
	*/
 chromosomeType *chromosomePtr;
{
	register int i, diff;
	register int wordBit;				 /* position counter within each word */
	register unsigned size;							/* save some pointer math */
	register struct parameterStruct *parameterPtr;
	register unsigned numberOfParameters;

	parameterPtr = getParameterArray();
	numberOfParameters = getNumberOfParameters();
	
	for(i = 0; i < numberOfWords; i++)	   /* zero all bits in the chromosome */
		chromosomePtr[i] = 0l;
		
    wordBit = NUMLONGBITS;					/* working from highBit to lowBit */
	
	/* walk through each parameter and encode it into the array */

	for (i = 0; i < numberOfParameters; i++, parameterPtr++) {
		size = parameterPtr->size;		 /* save some pointer addressing time */
		diff = wordBit - size;						   /* save some math time */
		
		/* make sure we can fit this parameter in the current word */

		if (diff >= 0) {
			/* get the bits for the parameter and encode 'em in the */
			/* chromosome at the right place */
			*chromosomePtr |= (getBits((unsigned long)parameterPtr->value, 
									 					size-1, size) << diff);
									 					
			/* if we have a full unsigned long then move to the next one */
			if (diff == 0) {
				++chromosomePtr;					 /* move to the next word */
 				wordBit = NUMLONGBITS;					 /* reset the counter */
 			}
			else
				wordBit = diff;					 /* decrement the int counter */
		}
		else {		/* we have to split the parameter between words; get the */
					/* partial set of bits for this parameter and or them    */
					/* into the current word */
			*chromosomePtr |= getBits((unsigned long)parameterPtr->value, 
																size-1, wordBit);
			++chromosomePtr;						 /* move to the next word */
			diff = size - wordBit;					   /* save some math time */
			
				/* grab the remaining bits in the parameter and stuff them in */
			*chromosomePtr |= (getBits((unsigned long)parameterPtr->value,
										diff-1, diff) << (NUMLONGBITS - diff));
			wordBit = NUMLONGBITS - diff;				 /* reset the counter */
		}
	}
}
#endif



void copyChromosome(from, to)
	/*
	========================================
	:purpose
		make a copy of a chromosome 
	========================================
	*/
 chromosomeType *from, *to;
{
	register int i = numberOfWords;
	
	while (i--)
		*to++ = *from++;
}



void saveChromosome(fp)
    /*
    ========================================
    :purpose
        write a decoded chromosome to disk
    ========================================
    */
 FILE *fp;
{
	extern bool normalize;
	int numberOfParameters = getNumberOfParameters(),
		i;

	for (i = 0; i < numberOfParameters; i++) {
		if (normalize)
			fprintf(fp, "\t\t%d = %f\n", i, getNormalizedParameterValue(i));
		else
			fprintf(fp, "\t\t%d = %lu\n", i, getParameterValue(i));
	}
}



unsigned getChromosomeSize() {
	/* 
	========================================
	:purpose
		return the size of the chromosome in number of bits
	========================================
	*/
	return(chromosomeSize);
}



unsigned getNumberOfWords() {
	/*
	========================================
	:purpose
		return the number of words in a chromosome
	========================================
	*/
	return(numberOfWords);
}



unsigned getExtraBits() {
	/*
	========================================
	:purpose
		return the number of extra bits; 
		that is the number of bits in the 
		last word of a chromosome
	========================================
	*/
	return(extraBits);
}



void printChromosome(msg, chromosome, format)
	/*
	========================================
	:purpose
		print a chromosome to the screen
	========================================
	*/
 char *msg, format;
 chromosomeType *chromosome;
{
	register int i,j;
	register unsigned stop;
	
	printf("%s", msg);
	for (i = 0; i < numberOfWords; i++, chromosome++) {
		if ((i < (numberOfWords-1)) | (extraBits == 0))
			if (format == 'o')
				printf("%11lo ", *chromosome);
			else
				stop = 0;
		else
			if (format == 'o')
				printf("%lo", getBits(*chromosome, NUMLONGBITS-extraBits,
							extraBits));
			else
				stop = NUMLONGBITS-extraBits;
		
		if (format == 'b')
			for (j = NUMLONGBITS; j > stop; j--)
				if (getBits(*chromosome, j-1, 1))
					putchar('1');
				else
					putchar('0');
	}
}

