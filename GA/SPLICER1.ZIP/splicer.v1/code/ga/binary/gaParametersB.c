/*
 ==============================================================================
 gaParameters.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	the code in this module pertains to the parameters of the problem the
	user is encoding
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainB.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in
 gaParameters.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void createParameterArray(
#   if useFunctionPrototypes
 	unsigned
#   endif
);


/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;				/* control flags from gaMain.c */

/*
 ========================================
 global variables
 
 globals defined within this module 
 ========================================
 */

/* global array for holding parameter info */ 

static struct parameterStruct *parameterArray;

/* number of parameters in each chromosome */

static unsigned numberOfParameters = 0;

/* parameters flags */

bool sameSizeParameters = FALSE;
bool normalize			= FALSE;

/*
 ========================================
 functions
 ========================================
 */

void initParameters()
	/*
	========================================
	:purpose
		initialize the parameters module;
		called at program startup and during 
		reinitialization
	========================================
	*/
{
	parameterArray = NULL;
	setNumberOfParameters(1);
}



void preCreateInitParameters()
	/*
	========================================
	:purpose
		initialize the paramaters module;
		called just prior to creating the
		population
	========================================
	*/
{
  	setNormalizationFactors();
}



void preRunInitParameters()
	/*
	========================================
	:purpose
		initialize the parameters module;
		called just prior to running the GAs
	========================================
	*/
{
}



void reinitParameters(how)
	/*
    ========================================
    :purpose
        either save or restore (in memory)
		all parameters module global 
		variables; this is called during
		global reinitialization
    ========================================
    */
 int how;
{
    static int oldNumberOfParameters;
	static bool oldSameSizeParameters;
	static bool oldNormalize;
	static short *sizeArray = NULL;
	int i;

    switch (how) {
        case (SAVE) :
            oldNumberOfParameters = numberOfParameters;
			oldSameSizeParameters = sameSizeParameters;
			oldNormalize = normalize;

			/* save parameter sizes */

			sizeArray = (short*)malloc(numberOfParameters * sizeof(short));
			if (!sizeArray)
				die("reinitParameters(): can't allocate sizeArray[]");
			for (i = 0; i < numberOfParameters; i++)
				sizeArray[i] = getParameterSize(i);
            break;

        case (RESTORE) :
            setNumberOfParameters(oldNumberOfParameters);
			setSameSizeParameters(oldSameSizeParameters);
			setNormalize(oldNormalize);

			/* restore parameter sizes */

			setParameterSizes(sizeArray);
			free(sizeArray);
			sizeArray = NULL;
            break;

        default :
            die("reinitParameters(): bad how");
            break;
    }
}



void saveParametersParams(fp)
    /*
    ========================================
    :purpose
        save (to disk) all parameters module 
		global variables; this is called from 
       	saveParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;

	/* save number of parameters */

	fprintf(fp, "%d\t\t\tnumber of parameters\n", numberOfParameters);

	/* save parameter sizes */

	for (i = 0; i < numberOfParameters; i++)
		fprintf(fp, "%d\t\t\tsize of parameter %d\n", getParameterSize(i), i);

	/* save sameSize flag */

	fprintf(fp, "%d\t\t\tsame size parameters flag\n", sameSizeParameters);

	/* save normalize parameters flag */

	fprintf(fp, "%d\t\t\tnormalize parameters flag\n", normalize);
}



void loadParametersParams(fp)
    /*
    ========================================
    :purpose
        load (from disk) all parameters module
        global variables; this is called from
        loadParameters() in gaFileio.c
    ========================================
    */
 FILE *fp;
{
    int i;
	short *sizeArray;

	/* load number of parameters */

	setNumberOfParameters(fgetInt(fp));

	/* create the size array */

	sizeArray = (short *) malloc(numberOfParameters * sizeof(short));
	if (!sizeArray)
		die("saveParametersParams(): can't alloc sizeArray");

	/* restore parameter sizes */

	for(i = 0; i < numberOfParameters; i++)
		sizeArray[i] = fgetInt(fp);
	setParameterSizes(sizeArray);
	free(sizeArray);

	/* load the sameSize parameters flag */

	setSameSizeParameters(fgetInt(fp));

	/* load the normalize parameters flag */

	setNormalize(fgetInt(fp));
}



void setNumberOfParameters(number)
	/*
	========================================
	:purpose
		set the number of parameters
	========================================
	*/
 int number;
{
	register char string[80];
	register char *format;
	unsigned oldNumber;
	
	if (number > 0) {
		if (numberOfParameters != number) {
			if (!checkPopulationStatus())
				return;
			oldNumber = numberOfParameters;
			numberOfParameters = number;
			createParameterArray(oldNumber);
#			if MACINTOSH | X_WINDOWS
			resizeParameterSizeList(numberOfParameters);
#			endif
		}
	}
	else {
		format = "number of parameters is invalid: %d";
		sprintf(string, format, number);
		okAlert(string);
		enterNumberOfParameters();
	}
}



void enterNumberOfParameters()
	/*
	========================================
	:purpose
		allow the user to enter the number of parameters at the 
		keyboard
	========================================
	*/
{
	bool okChoice = FALSE;
	int c;
	char *string = "number of parameters";
	unsigned number = numberOfParameters;
	
	if (!checkPopulationStatus())
		return;
		
	okChoice = FALSE;
	
	while (!okChoice) {
	  	singleIntEntryDialog((int *)&number, string, "[x >= 1]", 1, 30000);
		okChoice = TRUE;
	}
	setNumberOfParameters(number);
}



unsigned getNumberOfParameters()
	/*
	========================================
	:purpose
		return the number of parameters
	========================================
	*/
{
	return(numberOfParameters);
}



void createParameterArray(oldNumber)
	/*
	========================================
	:purpose
		dynamically create the parameter 
		array; the parameter array is used 
		each time a chromosome needs to be 
		decoded and used to calculate the 
		fitness; there are many chromosomes 
		but only one parameter array; this 
		routine is also called if the number 
		of parameters changes: if the parameter 
		array exists, the old values are 
		saved and replaced in the new parameter 
		array
	========================================
	*/
 unsigned oldNumber;
{
	register int i, lastOne;
	register short *tempArray = NULL;
	register short temp[1];

	temp[0] = 0;
	
	if (parameterArray) {							/* array already exists */
		/* save the size information */
		if (sameSizeParameters)
			temp[0] = parameterArray[0].size;			/* only need one size */
		else {
			/* create the tempArray */
			tempArray = (short *) malloc(numberOfParameters * sizeof(short));
			if (!tempArray)
				die("createParameterArray: can't allocate tempArray");
			/* how many numbers should we save */
			lastOne = numberOfParameters > oldNumber ? oldNumber : 
															numberOfParameters;
			/* save the size information */
			for (i = 0; i < lastOne; i++)
				tempArray[i] = parameterArray[i].size;
			/* if the new array is larger, fill in the new sizes */
			if (numberOfParameters > oldNumber) {
				for (i = lastOne; i < numberOfParameters; i++)
					tempArray[i] = 1;
			}
		}
	}
	
	freeParameterArray();						/* delete the old array */
	
	/* create the new parameter array */
	parameterArray = (struct parameterStruct *)malloc(numberOfParameters 
										* sizeof(struct parameterStruct));
	if (parameterArray == NULL)
		die("createParameterArray(): can't allocate parameterArray");
		
	/* zero out all values */	
	for (i = 0; i < numberOfParameters; i++) {
		parameterArray[i].size				= 1;
		parameterArray[i].normalizeFactor	= 0l;
		parameterArray[i].value				= 0l;
		parameterArray[i].normalizedValue	= 0.0;
	}
	
	/* restore the saved sizes, if necessary */
	if (tempArray || temp[0]) {				/* we need to restore sizes */
		if (sameSizeParameters)
			setParameterSizes(temp);
		else {
			setParameterSizes(tempArray);
			free(tempArray);
		}
	}
}


	
void freeParameterArray()
	/*
	========================================
	:purpose
		delete the parameter array from memory
	========================================
	*/
{
	if (parameterArray != NULL)
		free(parameterArray);
}



void setParameterSizes(sizeArray)
	/*
	========================================
	:purpose
		allow the user to define the parameter 
		sizes upon user initialization; the 
		sizeArray is created by the user and 
		holds the size for each parameter; 
	========================================
	*/
 short sizeArray[];
{
	int i;
	register struct parameterStruct	*parameterPtr;
	char string[80];
	
	parameterPtr = parameterArray;
	
	/* set up the user values */
		
	for (i = 0; i < numberOfParameters; i++, parameterPtr++) {
		if (sameSizeParameters) {
			if ((sizeArray[0] > 0) && (sizeArray[0] < 32))
				parameterPtr->size = sizeArray[0];
			else {
				sprintf(string, "parameter size is not valid: %d",sizeArray[0]);
				okAlert(string);
			}
		}
		else {
			if ((sizeArray[i] > 0) && (sizeArray[i] < 32))
				parameterPtr->size = sizeArray[i];
			else {
				sprintf(string, "parameter %d size is not valid: %d", 
														i, sizeArray[i]);
				okAlert(string);
			}
		}
	}
}



void enterParameterSizes()
	/*
	========================================
	:purpose
		define the parameter sizes from the 
		keyboard
	========================================
	*/
{
#	if TTY
	register int	i;
	register int	c;
	register struct parameterStruct	*parameterPtr;
	register bool	okChoice = FALSE;
	unsigned		numberOfBits = 0;
	register char	*string, *string1;

	parameterPtr = parameterArray;

	if (!checkPopulationStatus())
		return;
	
	string = "number of bits";
	
	if (sameSizeParameters) { /* all parameters the same size? */
	
		okChoice = FALSE;
		while (!okChoice) {		  
			fflush(stdin);
			printf("   Enter the %s: ", string);
			scanf("%u", &numberOfBits);
			
			if ((numberOfBits < 1) || (numberOfBits > NUMLONGBITS))
				printf("   Number of bits must be in the range: 0 < x < %d\7\n",
								NUMLONGBITS+1);
			else
				okChoice = TRUE;
		}
	}
	
	for (i = 0; i < numberOfParameters; i++, parameterPtr++) {
		if (sameSizeParameters) {/* all have the same size? */
			parameterPtr->size = numberOfBits;
		}
		else {
			okChoice = FALSE;
			while (!okChoice) {
				fflush(stdin);
				printf("   Enter the number of bits for parameter # %d: ", i);
				scanf("%u", &numberOfBits);
				if ((numberOfBits < 1) || (numberOfBits > NUMLONGBITS))
					printf(
					   "   Number of bits must be in the range: 0 < x < %d\7\n",
								NUMLONGBITS+1);
				else
					okChoice = TRUE;
			}
			parameterPtr->size = numberOfBits;
		}		
	}
#	endif
}



void setNormalizationFactors()
	/*
	========================================
	:purpose
		this function sets up the normalization 
		factors for each parameter if the 
		normalize flag is set
	========================================
	*/
{
	int i;
	register struct parameterStruct	*parameterPtr;

	parameterPtr = parameterArray;
	
	for (i = 0; i < numberOfParameters; i++, parameterPtr++) {
		parameterPtr->normalizeFactor = 
				(long) pow((double) 2.0, (double) parameterPtr->size) - 1;
	}
}



void setSameSizeParameters(state)
	/*
	========================================
	:purpose
		set the sameSizeParameter flag 
		according to the input parameter 
		state
	========================================
	*/
 bool state;
{
	if (!checkPopulationStatus())
		return;
		
	sameSizeParameters = state;
}



void enterSameSizeParametersFlag()
	/*
	========================================
	:purpose
		allow the user to set the 
		sameSizeParameter flag from the 
		keyboard; this flag is only used with 
		chromosomes; for the Macintosh and 
		X-Windows versions, this function 
		simply toggles the flag back and 
		forth between the two states 
	========================================
	*/
{

#	if MACINTOSH | X_WINDOWS
	if (!checkPopulationStatus())
		return;
  	sameSizeParameters = !sameSizeParameters;
#	endif
  
#	if TTY	  
	register int c;
	register char *string = "Are all parameters the same size";
	register bool okChoice = FALSE;
	
	if (!checkPopulationStatus())
		return;
		
	while (!okChoice) {
	
		fflush(stdin);
		printf("   %s? (y/n): ", string);
		c = getchar();
		
		if (c == 'y') {
			sameSizeParameters = TRUE;
			okChoice = TRUE;
		}
		else if (c == 'n') {
			sameSizeParameters = FALSE;
			okChoice = TRUE;
		}
		else
			puts("   Please enter y or n.\7");
	
	}
#	endif
}	



void setNormalize(state)
	/*
	========================================
	:purpose
		allow the user to set the normalization 
		flag according to the value of the 
		input parameter state
	========================================
	*/
 bool state;
{
	normalize = state;
}



void enterNormalizeFlag()
	/*
	========================================
	:purpose
		allow the user to set the normalization 
		flag at the keyboard; for the macintosh 
		version, this function simply toggles the 
		flag between the two states
	========================================
	*/
{

#	if MACINTOSH | X_WINDOWS
	normalize = !normalize;
#	endif
  
#	if TTY	  
	register int c;
	register bool okChoice = FALSE;
	
	while (!okChoice) {
	
		fflush(stdin);
		printf("   Normalize parameter values? (y/n): ");
		c = getchar();
		
		if (c == 'y') {
			normalize = TRUE;
			okChoice = TRUE;
		}
		else if (c == 'n') {
			normalize = FALSE;
			okChoice = TRUE;
		}
		else
			puts("   Please enter y or n.\7");
	
	}
#	endif
}



unsigned sumParameterSizes()
	/*
	========================================
	:purpose
		calculate the size of the chromosome 
		in bits by summing the parameter sizes
	========================================
	*/
{
	register int i;
	register struct parameterStruct *parameterPtr;
	register unsigned sum = 0;

	parameterPtr = parameterArray;

	/* calculate the global variable chromosomeSize */
	
	for (i = 0; i < numberOfParameters; i++, parameterPtr++)
		sum += parameterPtr->size;
	
	return(sum);
}



struct parameterStruct *getParameterArray()
	/*
	========================================
	:purpose
		return the address of the parameter array
	========================================
	*/
{
	return(parameterArray);
}


	
void setParameterSize(theCell, theSize)
	/*
	========================================
	:purpose
		set the size of a parameter
	========================================
	*/
 unsigned theCell, theSize;
{
	if (!checkPopulationStatus())
		return;
		
	parameterArray[theCell].size = theSize;
}



unsigned getParameterSize(theCell)
	/*
	========================================
	:purpose
		returns the size of a parameter
	========================================
	*/
 unsigned theCell;
{
	return(parameterArray[theCell].size);
}



parameterType getParameterValue(index)
	/*
	========================================
	:purpose
		return the specified parameter value 
		from the parameter array, indexed 
		by index
	========================================
	*/
 int index;
{
	if ((index < 0) || (index >= numberOfParameters))
		die("getParameterValue(): bad index");
	
	return(parameterArray[index].value);
}



float getNormalizedParameterValue(index)
	/*
	========================================
	:purpose
		return the specified normalized 
		parameter value from the parameter 
		array, indexed by index
	========================================
	*/
 int index;
{
	if ((index < 0) || (index >= numberOfParameters))
		die("getNormalizedParameterValue(): bad index");
	if (!normalize)
		die("getNormalizedParameterValue(): normalization flag is not set");
	
	return(parameterArray[index].normalizedValue);
}

