/*
 ==============================================================================
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module is part of the macintosh interface for the GA tool; 
	it contains all functions that deal with lists using the list manager
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/
 
/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainB.h"
#include <string.h>

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are also externed
 in macList.h
 ========================================
 */

/* general functions */

/* application-specific functions */

void initParamatersSizeList(void);
void createParameterSizeList(DialogPtr);
void deleteParameterSizeList(DialogPtr);
pascal void updateParameterSizeList(WindowPtr, int);
void activateParameterSizeList(EventRecord *);
void clickParameterSizeList(DialogPtr, EventRecord *);
void setParameterSizeListItem(DialogPtr);
void resizeParameterSizeList(unsigned);
void setParameterSizeListValues(unsigned);

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

extern bool sameSizeParameters;
extern bool normalize;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

struct {
	ListHandle	handle;
	Rect		theView;
	Rect		theBounds;
	Point		cellSize;
	Cell		theCell;
} pSizeList;

DialogPtr		paramCharDialog;
DialogRecord	paramCharDialogR;

#define BinaryParmCharDialog			340
#define ParamCharDialogOkButton			1
#define ParamCharDialogNOPStaticText	2
#define ParamCharDialogNOPButton		3
#define ParamCharDialogNormalizeButton	4
#define ParamCharDialogSameSizeButton	5
#define ParameterSizeSText				6
#define ParameterSizeListTEdit			7
#define ParameterSizeListEnterButton	8
#define ParameterSizeList				9

/*
 ========================================
 functions
 ========================================
 */

void openParamCharDialog()
	/*
	========================================
	:purpose
		create or select the parameter
		charactersitics dialog box
	========================================
	*/	
{
	if (paramCharDialog)
		SelectWindow(paramCharDialog);
	else {
		paramCharDialog = GetNewDialog(BinaryParmCharDialog, &paramCharDialogR, (WindowPtr) -1);
		createParameterSizeList(paramCharDialog);
		updateParamCharDialog();
	}
}


void closeParamCharDialog()
	/*
	========================================
	:purpose
		close the parameter charactersitics 
		dialog box
	========================================
	*/	
{
	if (paramCharDialog) {
		deleteParameterSizeList(paramCharDialog);
		CloseDialog(paramCharDialog);
		paramCharDialog = NULL;
	}
}



void doParamCharDialog(whichItem)
	/*
	========================================
	:purpose
		handle events in the parameter
		charactersitics dialog
	========================================
	*/	
 short whichItem;
{
	char *string = "Cannot change parameter characteristics during a \
run of the geneteic algorithms.  Must reinitialize first.";

	switch(whichItem) {
		case ParamCharDialogOkButton :
			closeParamCharDialog();
			updateParamDialog();
			break;
			
		case ParamCharDialogNOPButton :
			setParameter(enterNumberOfParameters);
			updateParamCharDialog();
			break;
			
		case ParamCharDialogSameSizeButton :
			if (gaFlags.runningGA || gaFlags.stop) { /* no changes */
				okAlert(string);
				break;
			}
			enterSameSizeParametersFlag();
			updateParamCharDialog();
			break;
			
		case ParamCharDialogNormalizeButton :
			if (gaFlags.runningGA || gaFlags.stop) { /* no changes */
				okAlert(string);
				break;
			}
			enterNormalizeFlag();
			updateParamCharDialog();
			break;

		case ParameterSizeListTEdit :
			break;
		
		case ParameterSizeListEnterButton :
			if (gaFlags.runningGA || gaFlags.stop) { /* no changes */
				okAlert(string);
				break;
			}
			setParameterSizeListItem(paramCharDialog);
			break;
			
 		case ParameterSizeList :
			break;
	}
}



void updateParamCharDialog()
{
	int		type;
	Handle	item;
	Rect	box;
	char	text[30];
		
	GetDItem(paramCharDialog, ParamCharDialogNOPButton, &type, &item, &box);
	sprintf(text, "%d", getNumberOfParameters());
	CtoPstr(text);
	SetCTitle(item, text);
	PtoCstr(text);
	
	GetDItem(paramCharDialog, ParamCharDialogSameSizeButton, &type, 
															&item, &box);
	SetCtlValue(item, sameSizeParameters);
	
	GetDItem(paramCharDialog, ParamCharDialogNormalizeButton, &type,
															&item, &box);
	SetCtlValue(item, normalize);
}



void paramCharDialogContentAreaEvent(theEvent)
	/*
	========================================
	:purpose
		handle events in the content area of
		the paramChar dialog
	========================================
	*/
 EventRecord *theEvent;
{
	clickParameterSizeList(paramCharDialog, theEvent);
}




void activateParamCharDialog(theEvent)
	/*
	========================================
	:purpose
		handle activate events in the 
		paramChar dialog box
	========================================
	*/
 EventRecord *theEvent;
{
	activateParameterSizeList(theEvent);
}



void initParamatersSizeList(void)
	/*
	========================================
	:purpose
		initialization of parameter size list
	========================================
	*/
{
	pSizeList.handle = NULL;
}
 


void createParameterSizeList(DialogPtr theDialog)
	/*
	========================================
	:purpose
		create the parameter size list with 
		the list manager
	========================================
	*/
{
	int			i,
				type,
				whichItem,
				size;
	Handle		item;
	WindowPtr	oldPort;

	if (pSizeList.handle)	/* already created */
		return;
		
	GetPort(&oldPort);
	SetPort(theDialog);
	GetDItem(theDialog, ParameterSizeList, &type, &item, &pSizeList.theView);
 	SetDItem(theDialog, ParameterSizeList, userItem, 
 					   (Handle)updateParameterSizeList, &pSizeList.theView);
	FrameRect(&pSizeList.theView);
	InsetRect(&pSizeList.theView, 1, 1);
	pSizeList.theView.right -= 15;
	SetRect(&pSizeList.theBounds, 0, 0, 1, getNumberOfParameters());
	SetPt(&pSizeList.cellSize, pSizeList.theView.right - 
										pSizeList.theView.left, 16);
	pSizeList.handle = LNew(&pSizeList.theView, &pSizeList.theBounds,
			pSizeList.cellSize, 0, theDialog, FALSE, FALSE, FALSE, TRUE);
	(*pSizeList.handle)->selFlags = lOnlyOne;
	InsetRect(&pSizeList.theView, -1, -1);
	
	setParameterSizeListValues(pSizeList.theBounds.bottom);
	
	SetPt(&pSizeList.theCell, 0, 0);
	LSetSelect(TRUE, pSizeList.theCell, pSizeList.handle);
	LDoDraw(TRUE, pSizeList.handle);
	SetPort(oldPort);
}



	
void setParameterSizeListValues(unsigned numberOfParameters)
	/*
	========================================
	:purpose
		get the cell values from the 
		parameter array
	========================================
	*/
{
	register int		i;
	register unsigned	size;
	register char		theString[8];
	register struct parameterStruct	*parameterPtr;
	
	parameterPtr = getParameterArray();
	for(i = 0; i < numberOfParameters; i++) {
		size = parameterPtr->size;
		parameterPtr++;
		sprintf(theString, "%3d:  %2d", i, size);
		SetPt(&pSizeList.theCell, 0, i);
		LSetCell(theString, strlen(theString), pSizeList.theCell, 
														pSizeList.handle);
	}
}



void deleteParameterSizeList(DialogPtr theDialog)
	/*
	========================================
	:purpose
		dispose of the parameter size list
	========================================
	*/
{
	WindowPtr	oldPort;
	
	if (!pSizeList.handle)
		return;
	
	GetPort(&oldPort);
	SetPort(theDialog);
	
	LDispose(pSizeList.handle);
	EraseRect(&pSizeList.theView);
	pSizeList.handle = NULL;

	SetPort(oldPort);
}



pascal void updateParameterSizeList(WindowPtr theDialog, int theItem)
	/*
	========================================
	:purpose
		update the parameter size list
	========================================
	*/
{
	if (!pSizeList.handle)
		return;
	
	FrameRect(&pSizeList.theView);
	LUpdate(theDialog->visRgn, pSizeList.handle);
}



void activateParameterSizeList(EventRecord *theEvent)
	/*
	========================================
	:purpose
		activate the parameter size list
	========================================
	*/
{
	if (!pSizeList.handle)
		return;
	
	LActivate(theEvent->modifiers & activeFlag ? TRUE : FALSE, 
														pSizeList.handle);
}



void clickParameterSizeList(DialogPtr theDialog, EventRecord *theEvent)
	/*
	========================================
	:purpose
		handle user clicks in the list
	========================================
	*/
{
	WindowPtr	oldPort;
	char		theData[2];
	int			type;
	Handle		item;
	Rect		box;
	long		temp;
	register struct parameterStruct	*parameterPtr;

	if (!pSizeList.handle)
		return;
	
	GetPort(&oldPort);
	SetPort(theDialog);
	parameterPtr = getParameterArray();
	
	GlobalToLocal(&theEvent->where);
		/* see if a double click occurred in a cell */
	if (LClick(theEvent->where, theEvent->modifiers, pSizeList.handle)) {
		temp = LLastClick(pSizeList.handle);
		pSizeList.theCell.v = HiWord(temp);
		sprintf(theData, "%d", (parameterPtr+pSizeList.theCell.v)->size);
		CtoPstr(theData);
		GetDItem(theDialog, ParameterSizeListTEdit, &type, &item, &box);
		SetIText(item, theData);
		SelIText(theDialog, ParameterSizeListTEdit, 0, 30000);
		PtoCstr(theData);
	}
	SetPort(oldPort);
}


	
void setParameterSizeListItem(DialogPtr theDialog)
	/*
	========================================
	:purpose
		change a cell value and the value in 
		the parameter array
	========================================
	*/
{
	int			type;
	Handle		item;
	Rect		box;
	long		temp;
	char		text[10];
	short		size;
	register struct parameterStruct	*parameterPtr;
	int			numberOfParameters;
	int			i;

	if (!checkPopulationStatus())
		return;

	parameterPtr = getParameterArray();
	
	GetDItem(theDialog, ParameterSizeListTEdit, &type, &item, &box);
	GetIText(item, text);
	PtoCstr(text);
	size = atoi(text);
	if ((size < 1) || (size > 31)) {
		okAlert("Size must be: 1 <= x <= 31");
		return;
	}
	
	if (sameSizeParameters) {
		numberOfParameters = getNumberOfParameters();
		for(i = 0; i < numberOfParameters; i++) {
			sprintf(text, "%3d:  %2d", i, size);
			SetPt(&pSizeList.theCell, 0, i);
			LSetCell(text, strlen(text), pSizeList.theCell, pSizeList.handle);
			setParameterSize(i, size);
		}
	}
	else {
		temp = LLastClick(pSizeList.handle);
		pSizeList.theCell.v = HiWord(temp);
		pSizeList.theCell.h = LoWord(temp);
		sprintf(text, "%3d:  %2d", pSizeList.theCell.v, size);
		LSetCell(text, strlen(text), pSizeList.theCell, pSizeList.handle);
		setParameterSize(pSizeList.theCell.v, size);
	}
}


	
void resizeParameterSizeList(unsigned numberOfParameters)
	/*
	========================================
	:purpose
		resize the parameterArray and the 
		list when the user changes the 
		number of parameters
	========================================
	*/
{
	int i;

	if ((!pSizeList.handle))
		return;
	
	watchCursor();
	if (numberOfParameters < pSizeList.theBounds.bottom)
		LDelRow(pSizeList.theBounds.bottom - numberOfParameters,
									numberOfParameters, pSizeList.handle);
	else
		LAddRow(numberOfParameters - pSizeList.theBounds.bottom,
									pSizeList.theBounds.bottom, pSizeList.handle);
	pSizeList.theBounds.bottom = numberOfParameters;
	setParameterSizeListValues(numberOfParameters);
	arrowCursor();
}
