/*
 ==============================================================================
 fitnessMinPolygon.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this is a fitness module for the Splicer genetic algorithm tool; it 
	contains three main functions:  initUser(), onBestDo(), and 
	calcFitness(); initUser() initializes Splicer control parameters; 
	onBestDo() can be used to update the User window whenever a best ever
	chromosome is found; calcFitness() is the problem-dependent fitness or
	scoring function; this module can also contain user-defined functions
	
	this fitness module minimizes the area required to enclose a circle of
	constant radius by an n-sided polygon with variable length sides
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainB.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaFitness.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */
 
/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */


/*
 ========================================
 functions
 ========================================
 */


char *getUserAboutString() {
	return("Polygon Minimization:\n\nThis problem is very similar to the polygon maximization problem (see fitnessMaxPolygon.c).  Here the object is to minimize the size (volume) of an n-sided polygon around a given circle.\n\nThis is also a good example of the use of normalized parameter values (see the code), but the fitness function is kludged by never allowing the length of a distance between one of the vertices from the center of the circle to get below a certain value.  This allows us to not worry about cutting through the circle with one of the arcs, but it keeps us from acheiving our goal of finding the smallest polygon to enclose the circle.\n");
}

#define radius	20
#define xOrigin 150
#define yOrigin 100
#define maxLen	100
#define	pi		3.14159
#define radians	pi/180

void initUser()
	/*
	========================================
	:purpose
		allow the user to initialize Splicer control parameters at run time
	
	========================================
	*/
{
	short sizeArray[1];

	sizeArray[0] = 8;
	
	initDraw();
	titleWindow("polygon minimization");
	setNumberOfParameters(6);
	setSameSizeParameters(TRUE);
	setParameterSizes(sizeArray);
	setNormalize(TRUE);
	setPopulationSize(50);
	setSamplingOperator(RANKING_METHOD);
}



void onBestDo()
	/*
	========================================
	:purpose
		this function executes whenever a bestEver member is found 
		and can be used to redraw the user window or for any other purpose
	
	========================================
	*/
{
	int i, j;
	int x1, x2, y1, y2;
	int xQuad, yQuad;
	unsigned numberOfParameters;
	float angle, sumAngle = 0.0;
	float side;
	
	numberOfParameters = getNumberOfParameters();
	angle = (360.0/numberOfParameters) * radians;
	
	eraseWindow();
	drawCircle(xOrigin,yOrigin,radius, TRUE);
	
	x1 = xOrigin+(int)(getNormalizedParameterValue(0) * (maxLen-radius) + (2.0*radius));
	y1 = yOrigin;
	
	for (i = 0; i < numberOfParameters; i++) {
		if (i == numberOfParameters-1)
			j = 0;
		else
			j = i+1;
		side = getNormalizedParameterValue(j) * (maxLen-radius) + (2.0*radius);
		sumAngle += angle;
		x2 = xOrigin + (int)(side * cos(sumAngle));
		y2 = yOrigin - (int)(side * sin(sumAngle));
		drawLine(x1, y1, x2, y2);
		x1 = x2;
		y1 = y2;
	}
}



fitnessType calcFitness(objectiveValue)
	/*
	========================================
	:purpose
		this fitness module minimizes the area required to enclose a 
		circle of constant radius by an n-sided polygon with variable 
		length sides

	:restrictions
		the nodes of the polygon are space at equal intervals--that is,
		360/number of sides; the nodes cannot get closer than two radii 
		to the center of the circle
	
	========================================
	*/
 float *objectiveValue;
{
	int i, j;
	unsigned numberOfParameters;
	float sinAngle, sumArea = 0.0;
	float side1, side2;
	
	numberOfParameters = getNumberOfParameters();
	sinAngle = sin((360.0/numberOfParameters) * radians);
		
	side1 = getNormalizedParameterValue(0) * (100.0-radius) + (2.0*radius);
	for (i = 0; i < numberOfParameters; i++) {
		if (i == numberOfParameters-1)
			j = 0;
		else
			j = i+1;
		side2 = getNormalizedParameterValue(j) * (100.0-radius) + (2.0*radius);
		sumArea += (.5 * side1 * side2 * sinAngle);
		side1 = side2;
	}	
	*objectiveValue = sumArea;
	return(1.0/(1.0 + sumArea));
}
