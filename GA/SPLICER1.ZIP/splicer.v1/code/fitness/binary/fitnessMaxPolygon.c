/*
 ==============================================================================
 fitnessMaxPolygon.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this is a fitness module for the Splicer genetic algorithm tool; it 
	contains three main functions:  initUser(), onBestDo(), and 
	calcFitness(); initUser() initializes Splicer control parameters; 
	onBestDo() can be used to update the User window whenever a best ever
	chromosome is found; calcFitness() is the problem-dependent fitness or
	scoring function; this module can also contain user-defined functions
	
	this fitness module maximizes the area required to fill a circle of
	constant radius with an n-sided polygon with variable length sides
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainB.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaFitness.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */
 
/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */


/*
 ========================================
 functions
 ========================================
 */

char *getUserAboutString() {
	return("Polygon Maximization:\n\nThe object of this problem is to maximize the size (volume) of an n-sided polygon within a given circle.  This is a simple problem, but it is a good example because it is simple and its graphics make it easy to see what is happening.  It's also a good example of the use of normalized parameter values (see the code).\n");
}

#define radius	90
#define xOrigin 150
#define yOrigin 100
#define maxLen	100
#define	pi		3.14159
#define radians	pi/180

void initUser()
	/*
	========================================
	:purpose
		allow the user to initialize Splicer control parameters at run time
	
	========================================
	*/
{
	short sizeArray[1];

	sizeArray[0] = 8;

	initDraw();
	titleWindow("polygon maximization");
	setNumberOfParameters(5);
	setSameSizeParameters(TRUE);
	setParameterSizes(sizeArray);
	setNormalize(TRUE);
	setPopulationSize(50);
	setSamplingOperator(RANKING_METHOD);
}



void onBestDo()
	/*
	========================================
	:purpose
		this function executes whenever a bestEver member is found 
		and can be used to redraw the user window or for any other purpose
	
	========================================
	*/
{
	int i, j;
	int x1, x2, y1, y2;
	int xQuad, yQuad;
	unsigned numberOfParameters;
	float angle, sumAngle = 0.0;
	float side;
	
	numberOfParameters = getNumberOfParameters();
	angle = (360.0/numberOfParameters) * radians;
	
	eraseWindow();
	drawCircle(xOrigin,yOrigin,radius, FALSE);
	
	x1 = xOrigin+(int)(getNormalizedParameterValue(0) * radius);
	y1 = yOrigin;
	
	for (i = 0; i < numberOfParameters; i++) {
		if (i == numberOfParameters-1)
			j = 0;
		else
			j = i+1;
		side = getNormalizedParameterValue(j) * radius;
		sumAngle += angle;
		x2 = xOrigin + (int)(side * cos(sumAngle));
		y2 = yOrigin - (int)(side * sin(sumAngle));
		drawLine(x1, y1, x2, y2);
		x1 = x2;
		y1 = y2;
	}
}



fitnessType calcFitness(objectiveValue)
	/*
	========================================
	:purpose
		this fitness module maximizes the area required to fill a circle
		of constant radius with an n-sided polygon with variable length 
		sides

		restrictions:  the nodes of the polygon are spaced at equal angles;
		that is, 360/number of sides
	
	========================================
	*/
 float *objectiveValue;
{
	int i, j;
	unsigned numberOfParameters;
	float sinAngle, sumArea = 0.0;
	float side1, side2;
	
	numberOfParameters = getNumberOfParameters();
	sinAngle = sin((360.0/numberOfParameters) * radians);
		
	side1 = getNormalizedParameterValue(0) * radius;
	for (i = 0; i < numberOfParameters; i++) {
		if (i == numberOfParameters-1)
			j = 0;
		else
			j = i+1;
		side2 = getNormalizedParameterValue(j) * radius;
		sumArea += (.5 * side1 * side2 * sinAngle);
		side1 = side2;
	}	
	*objectiveValue = sumArea;
	return(sumArea);
}
