/*
 ==============================================================================
 fitnessSumSquares.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this is a fitness module for the Splicer genetic algorithm tool; it 
	contains three main functions:  initUser(), onBestDo(), and 
	calcFitness(); initUser() initializes Splicer control parameters; 
	onBestDo() can be used to update the User window whenever a best ever
	chromosome is found; calcFitness() is the problem-dependent fitness or
	scoring function; this module can also contain user-defined functions
	
	this fitness module is used to search for the maximimum value of a 
	simple n-parameter polynomial: the sum of the squares of each of the 
	parameters
	 
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainB.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaFitness.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */
 
/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

#define numParams 3

short sizeArray[numParams] = { 5 };

/*
 ========================================
 functions
 ========================================
 */

char *getUserAboutString() {
    return("Sum Squares:\n\nThe purpose of this problem is to maximize the sum of the squares of n parameters; that is, for n=3, maximize x*x + y*y + z*z.  The range of the n parameters is controlled by the number of bits assigned to their representation (i.e., if they each get 5 bits, they can range from 0 to 31 (2**5)).  This is a very simple problem, and not the type of problem GAs would normally be used for (it can easily be solved other ways), but it is simple enough to understand and illustrative, so here is is.\n");
}


#define square(x) ((x)*(x))

void initUser()
	/*
	========================================
	:purpose
		allow the user to initialize Splicer control parameters at run
		time
	
	========================================
	*/
{
#	if MACINTOSH | X_WINDOWS
	initDraw();
	titleWindow("Sum Squares");
#	endif

	setPopulationSize(50);
	setNumberOfParameters(numParams);
	setSameSizeParameters(TRUE);
	setParameterSizes(sizeArray);
	setNormalize(FALSE);
}



	
#if MACINTOSH | X_WINDOWS
void onBestDo()
	/*
	========================================
	:purpose
		this function executes whenever a bestEver member is found 
		and can be used to redraw the user window or for any other purpose
	
	========================================
	*/
{
	int i;
	char s[50];

	unsigned numberOfParameters = getNumberOfParameters();

	eraseWindow();
  
	for (i = 0; i < numberOfParameters; i++) {
		sprintf(s, "x%d : %ld", i, getParameterValue(i));
		printString(20, (i+1)*20, s);
	}
}
#endif



#if TTY							/* character interface version */
void onBestDo()
	/*
	========================================
	:purpose
		this function executes whenever a bestEver member is found 
		and can be used to redraw the user window or for any other purpose
	
	========================================
	*/
{
	int i;
	char s[50];

	unsigned numberOfParameters = getNumberOfParameters();

	for (i = 0; i < numberOfParameters; i++) {
		printf("x%d : %ld", i, getParameterValue(i));
		if (i < numberOfParameters-1)
			printf(", ");
	}
  	putchar('\n');
}
#endif




fitnessType calcFitness(objectiveValue)
	/*
	========================================
	:purpose
		this fitness function computes the sum of the squares of the 
		problem parameters
	
	========================================
	*/
 fitnessType *objectiveValue;
{
	int i;
	fitnessType sumSquares = 0.0;
	unsigned numberOfParameters = getNumberOfParameters();
	
	for (i = 0; i < numberOfParameters; i++) {
		sumSquares += (fitnessType)square((fitnessType)getParameterValue(i));
	}
	*objectiveValue = sumSquares;
	return(sumSquares);
}
