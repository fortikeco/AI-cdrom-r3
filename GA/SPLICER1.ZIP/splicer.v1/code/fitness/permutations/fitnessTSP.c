/*
 ==============================================================================
 fitnessTsp.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this is a fitness module for the Splicer genetic algorithm tool; it 
	contains three main functions:  initUser(), onBestDo(), and 
	calcFitness(); initUser() initializes Splicer control parameters; 
	onBestDo() can be used to update the User window whenever a best ever
	chromosome is found; calcFitness() is the problem-dependent fitness or
	scoring function; this module can also contain user-defined functions
	
	this fitness module is for an n-city traveling salesperson problem

 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"
#include "gaMainP.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are externed in 
 gaFitness.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

void initCities(
#   if useFunctionPrototypes
    void
#   endif
);


/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */
 
/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

#define square(x) (x) * (x)

#define MIN_X   5	/* the User window is 300 pixels (x) by 200 pixels (y) */
#define MAX_X 295	/* here we are insetting by 5 pixels all around */
#define MIN_Y   5
#define MAX_Y 195

#define MAX_CITIES	200

struct citiesStruct {	/* points (cities) within the User window */
	int x;
	int y;
} cities[MAX_CITIES];

bool initFlag = TRUE;	/* used to ensure cities are created only once */

/*
 ========================================
 functions
 ========================================
 */

char *getUserAboutString() {
	return("Traveling Salesperson:\n\nThis application is for an n-city traveling salesperson problem.  The object is to look for the shortest path through the n cities.  Therefore, this is a minimization problem.\n\nThe number of cities is varaible and is controlled by the number of parameters.  The cities are set at random points within the user window.\n\n");
}
void initUser()
	/*
	========================================
	:purpose
		allow the user to initialize Splicer control parameters at run
		time
	
	========================================
	*/
{
#	if MACINTOSH | X_WINDOWS
	initDraw();
	titleWindow("Traveling Salesperson");
#	endif
	setNumberOfParameters(10);
	setPopulationSize(50);
	setCrossoverOperator(PMX);
	setMutationOperator(NO_MUTATION);
	setRandomSeed(100);
	if (initFlag)
		initCities();
}



void initCities()
	/*
	========================================
	:purpose
		user-defined function; creates MAX_CITIES randomly located cities 
		(xy points) for use within the User window
	
	========================================
	*/
{
	int i;
	
	for (i = 0; i < MAX_CITIES; i++) {
		cities[i].x = rangeRandom(MIN_X, MAX_X);
		cities[i].y = rangeRandom(MIN_Y, MAX_Y);
	}
	initFlag = FALSE;
}



void onBestDo()
	/*
	========================================
	:purpose
		this function executes whenever a bestEver member is found 
		and can be used to redraw the user window or for any other purpose
	
	========================================
	*/
{
#	if MACINTOSH | X_WINDOWS
	register int i;
	register parameterType city1, city2;
	register unsigned numberOfParameters = getNumberOfParameters();

	eraseWindow();
	city1 = getParameterValue(0);
	for (i = 1; i <= numberOfParameters; i++) {
		if (i < numberOfParameters)
			city2 = getParameterValue(i);
		else
			city2 = getParameterValue(0);
		drawCircle(cities[city1].x, cities[city1].y, 2, TRUE);
		drawLine(cities[city1].x, cities[city1].y, 
				 cities[city2].x, cities[city2].y);
		city1 = city2;
	}
#	endif
}



fitnessType calcFitness(objectiveValue)
	/*
	========================================
	:purpose
		this fitness function computes the distance through the n cities
		within the particular permutation being measured
	
	========================================
	*/
 float *objectiveValue;
{
	register int			i;
	register float			sumDistance = 0.0;
	register parameterType	city1, city2;
	register unsigned		numberOfParameters = getNumberOfParameters();
	
	sumDistance = 0.0;
	
	city1 = getParameterValue(0);
	
	for (i = 1; i <= numberOfParameters; i++) {
		if (i < numberOfParameters)
			city2 = getParameterValue(i);
		else
			city2 = getParameterValue(0);
		
		sumDistance += sqrt((double)(square((long)(cities[city1].x - cities[city2].x)) + 
			    		  			 square((long)(cities[city1].y - cities[city2].y))));
		city1 = city2;
	}
	
	*objectiveValue = sumDistance;
	return(1.0 / (1.0 + sumDistance));
}

