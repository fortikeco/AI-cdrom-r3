/*
 ==============================================================================
 tty.interface.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module is the TTY interface for the genetic algorithm tool
	
 :version 1.0d; release date 00/00/90
 
 ==============================================================================
*/
 
/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include "macDialog.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are also externed
 in tty.interface.h
 ========================================
 */
/*
void	ttyLoop(void);
*/
/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */
 
#if ANSI	
	void	doMenu(void);
	void	doRunMenu(void);
	int		ttyReinit(void);
	void	printParameters(void);
	int		setParameters(void);
	int		setRunParameters(void);
	char	getMenuChoice(int min, int max, int last);
#else
	void	doMenu();
	void	doRunMenu();
	int		ttyReinit();
	void	printParameters();
	int		setParameters();
	int		setRunParameters();
	char	getMenuChoice();
#endif

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */

char *trueS  = "True",
	 *falseS = "False";

/*
 ========================================
 functions
 ========================================
 */

main(void)
	/*
	========================================
		:purpose
			main event loop
	========================================
	*/
{
	initGA();
	initUser();
	doMenu();
}



char *banner = "\n========================================\n";

void doMenu(void)
	/*
	========================================
		:purpose
			present menu of commands to the user
	========================================
	*/
{
	int c;
	int theChoice;
	bool okChoice = FALSE;
	
	FOREVER {
  		puts(banner);
		puts("      Splicer Main Menu\n");
		puts("   1. Set  Control Parameters");
		puts("   2. Load Control Parameters");
		puts("   3. Save Control Parameters");
		puts("   4. Create Population");
		puts("   5. Run");
		puts("   6. Save Solutions");
		puts("   7. Reinitialize");
		puts("   8. Exit\n");

		switch (getMenuChoice(1, 8, 8)) {
			case 1:
				setParameters();
				break;
			case 2:
				loadParameters();
				break;
			case 3:
				saveParameters();
				break;
			case 4:
				createPopulation();
				break;
			case 5:
				gaFlags.stop = FALSE;
				if (checkRunGA())
					while(!gaFlags.stop) {
						runGA();
						doRunMenu();
					}
				break;
			case 6:
				saveBest();
				break;
			case 7:
				if (theChoice = ttyReinit())
					reinitialize(theChoice);
				break;

			case 8:
				exit(1);
		}
	}
}


	/* should we reinitialize, and, if so, how? */
	
int ttyReinit(void)
	/*
	========================================
		:purpose
			reinitialize menu
	========================================
	*/
{
	puts("   Reinitialization will reset all parameters and delete");
	puts("   the current population.\n");
	puts("   Reinitialize using: \n");
	puts("   1. Current values");
	puts("   2. User initialization values");
	puts("   3. Stored values (i.e., load from file)");
	puts("   4. Default values");
	puts("   5. Cancel\n");
	switch (getMenuChoice(1, 5, 5)) {
		case 1:
			return (CURRENT_VALUES);
			break;
		case 2:
			return (USER_VALUES);
			break;
		case 3:
			return (LOAD_VALUES);
			break;
		case 4:
			return (DEFAULT_VALUES);
			break;
		case 5:
			return (FALSE);
			break;
		default:
			die("bad choice in ttyReinit()");
			break;
	}
}



void printParameters(void)
	/*
	========================================
		:purpose
			print the control parameters to the screen
	========================================
	*/
{
	register int i;
	register unsigned number;
	register struct parameterStruct	*parameterPtr;

	parameterPtr = getParameterArray();
	
	puts(banner);
	puts("      Splicer Control Parameters:\n");
	if (gaFlags.permutation) {
		printf("   1. Number of parameters:  %u\n", number = getNumberOfParameters());
		printf("   2. Population size:       %u\n", getPopulationSize());
		printf("   3. Selection operator:    %s\n", getSelectionFunctionName());
		printf("   4. Crossover operator:    %s\n", getCrossoverFunctionName());
		printf("   5. Mutation operator:     %s\n", getMutationFunctionName());
		printf("   6. Crossover probability: %1.3g\n", getCrossoverProbability());
		printf("   7. Mutation probability:  %1.3g\n", getMutationProbability());
		printf("   8. Random seed:           %d\n", getRandomSeed());
	}
	else {
		printf("   1. Number of parameters:     %u\n", number = getNumberOfParameters());
		printf("      2. Same size parameters:  %s\n", gaFlags.sameSizeParameters ? trueS : falseS);
		printf("      3. Parameter sizes:       ");
		if (gaFlags.sameSizeParameters)
			printf("%d", parameterPtr[0].size);
		else
			for (i = 0; i < number; i++) {
				printf("%d=%u", i, parameterPtr[i].size);
				if (i < number-1)
					printf(", ");
			}
		putchar('\n');
		printf("      4. Normalize:             %s\n", gaFlags.normalize ? trueS : falseS);
		printf("   5. Population size:          %u\n", getPopulationSize());
		printf("   6. Selection operator:       %s\n", getSelectionFunctionName());
		printf("   7. Crossover operator:       %s\n", getCrossoverFunctionName());
		printf("   8. Mutation operator:        %s\n", getMutationFunctionName());
		printf("   9. Crossover probability:    %1.3g\n", getCrossoverProbability());
		printf("  10. Mutation probability:     %1.3g\n", getMutationProbability());
		printf("  11. Random seed:              %d\n", getRandomSeed());
	}
}



int setParameters(void)
	/*
	========================================
		:purpose
			set control parameters
	========================================
	*/
{
	FOREVER {
		fflush(stdin);
		printParameters();
		if (gaFlags.permutation)
			printf("   9");
		else
			printf("  12");
		puts(". Exit\n");
		
		if (gaFlags.permutation) {
			switch(getMenuChoice(1, 9, 9)) {
				case 1:
					enterNumberOfParameters();
					break;
				case 2:
					enterPopulationSize();
					break;
				case 3:
					chooseSelectionFunction();
					break;
				case 4:
					chooseCrossoverFunction();
					break;
				case 5:
					chooseMutationFunction();
					break;
				case 6:
					enterCrossoverProbability();
					break;
				case 7:
					enterMutationProbability();
					break;
				case 8:
					enterRandomSeed();
					break;
				case 9:
					return;
			}
		}
		else {
			switch(getMenuChoice(1, 12, 12)) {
				case 1:
					enterNumberOfParameters();
					break;
				case 2:
					enterSameSizeParametersFlag();
					break;
				case 3:
					enterParameterSizes();
					break;
				case 4:
					enterNormalizeFlag();
					break;
				case 5:
					enterPopulationSize();
					break;
				case 6:
					chooseSelectionFunction();
					break;
				case 7:
					chooseCrossoverFunction();
					break;
				case 8:
					chooseMutationFunction();
					break;
				case 9:
					enterCrossoverProbability();
					break;
				case 10:
					enterMutationProbability();
					break;
				case 11:
					enterRandomSeed();
					break;
				case 12:
					return;
			}
		}
	}
}



void doRunMenu(void)
	/*
	========================================
		:purpose
			present the runtime menu to the user
	========================================
	*/
{
	FOREVER {
  		puts(banner);
		puts("      Splicer Run Menu\n");
		puts("   1. Set  Control Parameters");
		puts("   2. Save Control Parameters");
		puts("   3. Resume");
		puts("   4. Stop\n");

		switch (getMenuChoice(1, 4, 4)) {
			case 1:
				setRunParameters();
				break;
			case 2:
				saveParameters();
				break;
			case 3:
				return;
				break;
			case 4:
				gaFlags.stop = TRUE;
				return;
				break;
		}
	}
}



int setRunParameters(void)
	/*
	========================================
		:purpose
			set runtime control parameters
	========================================
	*/
{
	FOREVER {
		fflush(stdin);
		printParameters();
		if (gaFlags.permutation)
			printf("   9");
		else
			printf("  12");
		puts(". Exit\n");
		
		if (gaFlags.permutation) {
			switch(getMenuChoice(3, 7, 9)) {
				case 3:
					chooseSelectionFunction();
					break;
				case 4:
					chooseCrossoverFunction();
					break;
				case 5:
					chooseMutationFunction();
					break;
				case 6:
					enterCrossoverProbability();
					break;
				case 7:
					enterMutationProbability();
					break;
				case 9:
					return;
			}
		}
		else {
			switch(getMenuChoice(6, 10, 12)) {
				case 6:
					chooseSelectionFunction();
					break;
				case 7:
					chooseCrossoverFunction();
					break;
				case 8:
					chooseMutationFunction();
					break;
				case 9:
					enterCrossoverProbability();
					break;
				case 10:
					enterMutationProbability();
					break;
				case 12:
					return;
			}
		}
	}
}



char getMenuChoice(min, max, last)
	/*
	========================================
		:purpose
			get the menu choice from the keyboard
	========================================
	*/
 int min, max, last;
{
	int c;
	
	FOREVER {
		printf("      Enter number: ");
		fflush(stdin);
		scanf("%d", &c);
		if ((c == last) | ((c >= min) && (c <= max)))
			return(c);
		else
			putchar('\7');
	}
}


/*
	the following functions are interface functions that are called
	from within the GA code itself; some of the names are funny due
	to their origin in window-based interface code; their use allows 
	us to avoid the use of #if MACINTOSH, #if TTY, etc.
*/

void okAlert(string)
	/*
	========================================
	:purpose
		simply present a message to the user and ring the bell
    ========================================
	*/
 char *string;
{
	printf("%s\7", string);
}



void singleFloatEntryDialog(theFloat, thePrompt, theRange, theMin, theMax)
	/*
    ========================================
    :purpose
        prompt the user for a real number
    ========================================
    */
 float	*theFloat;
 char	*thePrompt;
 char	*theRange;
 float	theMin;
 float	theMax;
{
    bool okChoice = FALSE;
	float theNumber;

    while (!okChoice) {
        printf("   Enter the %s: ", thePrompt);
        scanf("%f", &theNumber);

        if ((theNumber < theMin) || (theNumber > theMax))
            printf("   Must be in the range: %s\7", theRange);

        else
            okChoice = TRUE;
    }
	*theFloat = theNumber;
}



void singleIntEntryDialog(theInt, thePrompt, theRange, theMin, theMax)
    /*
    ========================================
    :purpose
        prompt the user for a real number
    ========================================
    */
 int	*theInt;
 char   *thePrompt;
 char   *theRange;
 int	theMin;
 int	theMax;
{
    bool okChoice = FALSE;
	int theNumber;

    while (!okChoice) {
        printf("   Enter the %s: ", thePrompt);
        scanf("%d", &theNumber);

        if ((theNumber < theMin) || (theNumber > theMax))
            printf("   Must be in the range: %s\7", theRange);
        else
            okChoice = TRUE;
    }
	*theInt = theNumber;
}



void getFileName(filename, prompt)
 char *filename;
 char *prompt;
{
    printf("%s ", prompt);
    scanf("%s", filename);
}



FILE *openFile(type, prompt, title)
    /*
    ========================================
    :purpose
        prompt the user for a file name and
		open the file; return NULL if can't
		open the file; return file pointer
		if sucessful
    ========================================
    */
 int type;
 char *prompt;
 char *title;
{
	FILE *fp;
	char *filename[40];
	char *how;

	getFileName(filename, prompt);
	if (type == SAVE)
		how = "w";
	else
		how = "r";

   	if ((fp = fopen(filename, how)) == NULL) {
   		printf("Can't open file: %s\n", filename);
   		return;
  	}
	return fp;
}



bool yesNoDialog(string)
 char *string;
{
	int c;
	bool okChoice = FALSE;

	printf("   %s? (y/n): ", string);

	while (!okChoice) {
		fflush(stdin);
		c = getchar();
		if ((c == 'y') || (c == 'Y'))
			return TRUE;
		else if ((c == 'n') || (c == 'N'))
			return FALSE;
	}
	puts("Please enter y or n\7");
}



void trace(msg)
    /*
    ========================================
    :purpose
        simply write a trace message to the
		screen
    ========================================
    */
 char *msg;
{
	puts(msg);
}




