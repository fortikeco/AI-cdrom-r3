/*
 ==============================================================================
 xMenus.c

 :written by

    steven e. bayer
    the mitre corporation

 :purpose

    this module contains code for building and accessing menus for the 
	X Window System interface to the GA tool

 :version 1.0; release date 03/01/91

 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"

#include "myXlib.h"

#include <ctype.h>

#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>

#if MOTIF
#	include <Xm/Xm.h>
#	include <Xm/RowColumn.h>
#	include <Xm/BulletinB.h>
#endif

#if HPW
#   include <Xw/Xw.h>
#	include <Xw/BBoard.h>
#	include <Xw/PButton.h>
#	include <Xw/MenuBtn.h>
#	include <Xw/RCManager.h>
#	include <Xw/SRaster.h>
#endif

#include <X11/bitmaps/xlogo16>

/*
 ========================================
 global functions headers

 these functions are available to any
 other module; they are externed in
 xMenus.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to
 this module
 ========================================
 */

void scalingMenuCB(
#   if useFunctionPrototypes
 	Widget, int, caddr_t
#   endif
);

void sharingMenuCB(
#   if useFunctionPrototypes
 	Widget, int, caddr_t
#   endif
);

void selectionMenuCB(
#   if useFunctionPrototypes
 	Widget, int, caddr_t
#   endif
);

void samplingMenuCB(
#   if useFunctionPrototypes
 	Widget, int, caddr_t
#   endif
);

void crossoverMenuCB(
#   if useFunctionPrototypes
 	Widget, int, caddr_t
#   endif
);

void mutationMenuCB(
#   if useFunctionPrototypes
 	Widget, int, caddr_t
#   endif
);

void saveParametersCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void loadParametersCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void saveBestCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void quitCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void createPopulationCB(
#   if useFunctionPrototypes
	Widget, caddr_t, caddr_t
#   endif
);

void runCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void checkMenuItems(
#   if useFunctionPrototypes
 	WidgetList, int, int, int
#   endif
);

void initScalingMenu(
#   if useFunctionPrototypes
    void
#   endif
);

void initSharingMenu(
#   if useFunctionPrototypes
    void
#   endif
);

void initSelectionMenu(
#   if useFunctionPrototypes
    void
#   endif
);

void initSamplingMenu(
#   if useFunctionPrototypes
    void
#   endif
);

void initCrossoverMenu(
#   if useFunctionPrototypes
    void
#   endif
);

void initMutationMenu(
#   if useFunctionPrototypes
    void
#   endif
);



/*
 ========================================
 external variables

 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

extern Widget	paramDialogTopLevel,
				userWindowTopLevel,
                fitnessWindowTopLevel,
                objectiveWindowTopLevel,
				statisticsWindowTopLevel,
                traceWindowTopLevel;

extern Widget	paramDialog,
				userWindow,
                fitnessWindow,
                objectiveWindow,
				statisticsWindow,
                traceWindow;

/*
 ========================================
 global variables

 globals defined within this module
 ========================================
 */

/*
 ========================================
 functions
 ========================================
 */

void setItem(theMenu, theButton, theText)
    /*
    ========================================
    :purpose
        set the text string (or label) for a 
		menu button
    ========================================
    */
 WidgetList theMenu;
 int        theButton;
 char       *theText;
{
    Arg     wargs[1];

    XtSetArg(wargs[0], XtNlabel, theText);
    XtSetValues(theMenu[theButton], wargs, 1);
}



void enableItem(theMenu, theButton)
    /*
    ========================================
    :purpose
        enable a menu button (i.e., make it
		active or selectable)
    ========================================
    */
 WidgetList theMenu;
 int        theButton;
{
    Arg wargs[1];

    XtSetArg(wargs[0], XtNsensitive, TRUE);
    XtSetValues(theMenu[theButton], wargs, 1);
}



void disableItem(theMenu, theButton)
    /*
    ========================================
    :purpose
        disable a menu button (i.e., make it
		inactive)
    ========================================
    */
 WidgetList theMenu;
 int        theButton;
{
    Arg wargs[1];

    XtSetArg(wargs[0], XtNsensitive, FALSE);
    XtSetValues(theMenu[theButton], wargs, 1);
}



/***************************************************************************
/*
    fitness scaling menu stuff
*/
WidgetList  scalingMenu;


void scalingMenuCB(w, theOperator, callData)
    /*
    ========================================
    :purpose
        set the scaling operator when a menu
		item has been selected from the 
		scaling menu
    ========================================
    */
 Widget     w;
 int        theOperator;
 caddr_t    callData;
{
    setScalingOperator(theOperator);
}

static myMenuStruct scalingMenuData[NUMBER_OF_SCALING_OPERATORS];



/***************************************************************************
/*
    fitness sharing menu stuff
*/
WidgetList  sharingMenu;

void sharingMenuCB(w, theOperator, callData)
    /*
    ========================================
    :purpose
        set the sharing operator when a menu
        item has been selected from the
        sharing menu
    ========================================
    */
 Widget     w;
 int        theOperator;
 caddr_t    callData;
{
    setSharingOperator(theOperator);
}

static myMenuStruct sharingMenuData[NUMBER_OF_SHARING_OPERATORS];



/***************************************************************************
/*
    selection menu stuff
*/
WidgetList  selectionMenu;

void selectionMenuCB(w, theOperator, callData)
    /*
    ========================================
    :purpose
        set the selection operator when a menu
        item has been selected from the
        selection menu
    ========================================
    */
 Widget     w;
 int        theOperator;
 caddr_t    callData;
{
    setSelectionOperator(theOperator);
}

static myMenuStruct selectionMenuData[NUMBER_OF_SELECTION_OPERATORS];



/***************************************************************************
/*
	sampling menu stuff
*/
WidgetList	samplingMenu;

void samplingMenuCB(w, theOperator, callData)
    /*
    ========================================
    :purpose
        set the sampling operator when a menu
        item has been selected from the
        sampling menu
    ========================================
    */
 Widget		w;
 int		theOperator;
 caddr_t	callData;
{
	setSamplingOperator(theOperator);
}
 
static myMenuStruct samplingMenuData[NUMBER_OF_SAMPLING_OPERATORS];


 
/***************************************************************************
/*
	crossover menu stuff
*/
WidgetList crossoverMenu;

void crossoverMenuCB(w, theOperator, callData)
    /*
    ========================================
    :purpose
        set the crossover operator when a menu
        item has been selected from the
        crossover menu
    ========================================
    */
 Widget		w;
 int		theOperator;
 caddr_t	callData;
{
	setCrossoverOperator(theOperator);
}
 
static myMenuStruct *crossoverMenuData;


 
/***************************************************************************
/*
	mutation menu stuff
*/
WidgetList mutationMenu;

void mutationMenuCB(w, theOperator, callData)
    /*
    ========================================
    :purpose
        set the mutation operator when a menu
        item has been selected from the
        mutation menu
    ========================================
    */
 Widget		w;
 int		theOperator;
 caddr_t	callData;
{
	setMutationOperator(theOperator);
}

static myMenuStruct *mutationMenuData;


 
/***************************************************************************
/*
    x menu stuff
*/
WidgetList xMenu;

void aboutSplicerCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        put up the "About Splicer..." dialog
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
	msgDialog("Splicer\n\nA genetic algorithm tool for search and optimization.\n\nWritten by Steve Bayer\nThe MITRE Corporation\n\nNASA Johnson Space Center\nSoftware Technology Branch\n\nVersion 1.0 ", "About Splicer", 'c');
}



void aboutApplicationCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        put up the "About this application..."
		dialog
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
	msgDialog(getUserAboutString(), "About this application", 'l');
}



/*
    describe the x menu.
*/
static myMenuStruct xMenuData[] = {
    { "About Splicer...",		   aboutSplicerCB,	   NULL},
    { "About this application...", aboutApplicationCB, NULL }
};




/***************************************************************************
/*
	file menu stuff
*/
WidgetList fileMenu;

void saveParametersCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        save the current parameters when the
		appropriate menu button has been
		selected
    ========================================
    */
 Widget     w;
 caddr_t	clientData;
 caddr_t    callData;
{
	saveParameters();
}



void loadParametersCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        load a set of parameters form a file 
		when the appropriate menu button has 
		been selected
    ========================================
    */
 Widget     w;
 caddr_t	clientData;
 caddr_t    callData;
{
	loadParameters();
	updateParamDialog();
}



void saveBestCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        save the ten best solutions when the
        appropriate menu button has been
        selected
    ========================================
    */
 Widget     w;
 caddr_t	clientData;
 caddr_t    callData;
{
	saveBest();
}



void quitCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        exit the program when the appropriate
		menu button has been selected
    ========================================
    */
 Widget     w;
 caddr_t	clientData;
 caddr_t    callData;
{
	exit(0);
}

extern Widget fileNamePopup;

/*
	describe the file menu.
*/
static myMenuStruct fileMenuData[] = {
	{ "Save Parameters...", saveParametersCB, NULL },
	{ "Load Parameters...", loadParametersCB, NULL },
	{ NULL,                 NULL, 			  NULL },
	{ "Save State...",      NULL, 			  NULL },
	{ "Load State...",      NULL, 			  NULL },
	{ NULL,                 NULL, 			  NULL },
	{ "Save Solutions...",  saveBestCB,		  NULL },
	{ NULL,                 NULL,			  NULL },
	{ "Quit",               quitCB, 		  NULL }
};



/***************************************************************************
/*
	control menu stuff
*/
WidgetList controlMenu;

void createPopulationCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        create the population when the 
		appropriate button has been selected
    ========================================
    */
 Widget		w;
 caddr_t	clientData;
 caddr_t	callData;
{
	createPopulation();
}


void runCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        run the genetic algorithms when the
        appropriate menu button has been
        selected
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
	int i;
	if (!gaFlags.runningGA) {
		if (checkRunGA()) {	
			gaFlags.runningGA = TRUE;
			gaFlags.stop = FALSE;
			for (i = 0; i < NUMBER_OF_FILE_MENU_OPTIONS-1; i++)
				disableItem(fileMenu, i);
			disableItem(controlMenu, CREATEPOPUL);
			disableItem(controlMenu, REINITIALIZE);
			setItem(controlMenu, RUN, "Pause");
			setItem(controlMenu, SET_PARAMETERS, "Show Control Parameters...");
   			runGA();
			XBell(XtDisplay(statisticsWindow), 0);
			setItem(controlMenu, RUN, "Resume");
			enableItem(controlMenu, RUN);
			enableItem(controlMenu, REINITIALIZE);
			enableItem(fileMenu, SAVE_PARAM);
			enableItem(fileMenu, SAVE_BEST);
			gaFlags.runningGA = FALSE;
		}
	}
	else {
		gaFlags.stop = TRUE;
		setItem(controlMenu, RUN, "Stopping after this generation");
		disableItem(controlMenu, RUN);
	}
}



/*
	describe the control menu.
*/
static myMenuStruct controlMenuData[] = {
	{ "Set Control Parameters...", toggleWindowCB,
									(caddr_t) &paramDialogTopLevel },
	{ "Create Population",         createPopulationCB, NULL },
	{ "Run",                       runCB,			   NULL },
	{ NULL,                        NULL,			   NULL },
	{ "Reinitialize...",           NULL,			   NULL }
};




/***************************************************************************
/*
	operators menu stuff
*/
WidgetList operatorsMenu;

/*
	describe the operators menu.
*/
myMenuStruct operatorsMenuData[] = {
	{ "Fitness Scaling", NULL, "Fitness Scaling" },
	{ "Fitness Sharing", NULL, "Fitness Sharing" },
	{ "Selection",		 NULL, "Selection",		 },
	{ "Sampling",		 NULL, "Sampling",		 },
	{ "Crossover",		 NULL, "Crossover"		 },
	{ "Mutation",		 NULL, "Mutation"		 }
};



 
/***************************************************************************
/*
	windows menu stuff
*/
WidgetList windowsMenu;

/*
	describe the windows menu.
*/
static myMenuStruct windowsMenuData[] = {
	{ "Statistics", toggleWindowCB,    (caddr_t) &statisticsWindowTopLevel },
	{ "Objective",  toggleWindowCB,    (caddr_t) &objectiveWindowTopLevel  },
	{ "Fitness",    toggleWindowCB,    (caddr_t) &fitnessWindowTopLevel    },
	{ "User",       toggleWindowCB,    (caddr_t) &userWindowTopLevel       },
	{ "Trace",      toggleWindowCB,    (caddr_t) &traceWindowTopLevel      },
	{ NULL,         NULL,              NULL },
	{ "Open All",   openAllWindowsCB,  NULL },
	{ "Close All",  closeAllWindowsCB, NULL }
};


 	
/***************************************************************************
/*
	menu bar stuff
*/
/*
	describe the menu bar
*/
static myMenuStruct mainMenuData[] = {
	{ "File",      NULL, NULL }, 
	{ "Control",   NULL, NULL },
	{ "Operators", NULL, NULL },
	{ "Windows",   NULL, NULL }
};
 
 
 
Widget	mainMenuTopLevel;
Widget	mainMenu, menuBar, menuMgr[5], menuButton[5];
Widget	xMenuShell, fileMenuShell, controlMenuShell, 
		operatorsMenuShell, windowsMenuShell;
Widget	sharingMenuShell, scalingMenuShell, samplingMenuShell,
		selectionMenuShell, crossoverMenuShell, mutationMenuShell;
Widget	operatorsMenuPane, samplingMenuPane, bogusPane;

void setUpMenus()
    /*
    ========================================
    :purpose
        create the menu bar and menu widgets
    ========================================
    */
{
	Arg			wargs[5];
	XImage		*theImage;
	Pixmap		bitmap,
				pixmap;
	GC			theGC;
	XGCValues	values;
	int			i, n;

	int			numberOfCrossoverOperators,
				numberOfMutationOperators;

	/*
		create the main menu widget
	*/
#	if MOTIF
#	define WIDGETCLASS xmBulletinBoardWidgetClass
#	endif

#	if HPW
#   define WIDGETCLASS XwrowColWidgetClass
#	endif

    mainMenu = XtCreateManagedWidget("mainMenu", WIDGETCLASS,
                               mainMenuTopLevel, NULL, 0);
 
#	if MOTIF
	/*
		create and manage the menubar
	*/
	menuBar = XmCreateMenuBar(mainMenu, "menuBar", NULL, 0);
	XtManageChild(menuBar);
 
	/*
		create the menu from the description
	*/
	createMenuButtons(NULL, menuBar, mainMenuData, XtNumber(mainMenuData));
#	endif

#	if HPW
	/*
		create the menu bar
	*/
	n = 0;
	XtSetArg(wargs[n], XtNwidth, 80); n++;
	XtSetArg(wargs[n], XtNsensitive, TRUE); n++;
	XtSetArg(wargs[n], XtNrecomputeSize, FALSE); n++;
	menuButton[4] = XtCreateManagedWidget("X",
							XwstaticRasterWidgetClass, mainMenu, wargs, n);
	menuButton[0] = XtCreateManagedWidget("File", 
							XwpushButtonWidgetClass, mainMenu, NULL, 0);
	menuButton[1] = XtCreateManagedWidget("Control", 
							XwpushButtonWidgetClass, mainMenu, NULL, 0);
	menuButton[2] = XtCreateManagedWidget("Operators", 
							XwpushButtonWidgetClass, mainMenu, NULL, 0);
	menuButton[3] = XtCreateManagedWidget("Windows", 
							XwpushButtonWidgetClass, mainMenu, NULL, 0);

	/* create the x logo image for the x menu button */

	n = 0;
	XtSetArg(wargs[n], XtNforeground, &values.foreground); n++;
	XtSetArg(wargs[n], XtNbackground, &values.background); n++;
	XtGetValues(menuButton[4], wargs, n);
	theGC = XtGetGC(menuButton[4], GCForeground | GCBackground, &values);

    bitmap = XCreateBitmapFromData(XtDisplay(menuButton[4]),
                            RootWindowOfScreen(XtScreen(menuButton[4])),
                            xlogo16_bits, xlogo16_width, xlogo16_height);

    pixmap = XCreatePixmap(XtDisplay(menuButton[4]),
                            RootWindowOfScreen(XtScreen(menuButton[4])),
                            xlogo16_width, xlogo16_height,
                            DefaultDepthOfScreen(XtScreen(menuButton[4])));

    XCopyPlane(XtDisplay(menuButton[4]), bitmap, pixmap, theGC, 0, 0,
						 xlogo16_width, xlogo16_height, 0, 0, 1);

	XFreePixmap(XtDisplay(menuButton[4]), bitmap);

    theImage = XGetImage(XtDisplay(menuButton[4]), pixmap, 0, 0, xlogo16_width,
                         xlogo16_height, AllPlanes, XYPixmap);

	n = 0;
	XtSetArg(wargs[n], XtNsRimage, theImage); n++;
	XtSetValues(menuButton[4], wargs, n);

	/*
		create the menu managers
	*/
	menuMgr[4] = createMenuManager(menuButton[4], "menuMgr5");
	menuMgr[0] = createMenuManager(menuButton[0], "menuMgr1");
	menuMgr[1] = createMenuManager(menuButton[1], "menuMgr2");
	menuMgr[2] = createMenuManager(menuButton[2], "menuMgr3");
	menuMgr[3] = createMenuManager(menuButton[3], "menuMgr4");

	/*
		create the sub menus
	*/

	xMenu = createMenuPane(menuMgr[4], "menuMgr5", "X Menu",
					xMenuData, XtNumber(xMenuData),
					&bogusPane, &xMenuShell);

	fileMenu = createMenuPane(menuMgr[0], "menuMgr1",  "File Menu", 
				   fileMenuData, XtNumber(fileMenuData), 
				   &bogusPane, &fileMenuShell);

	controlMenu = createMenuPane(menuMgr[1], "menuMgr2", "Control Menu", 
				   controlMenuData, XtNumber(controlMenuData), 
				   &bogusPane, &controlMenuShell);

	operatorsMenu = createMenuPane(menuMgr[2], "menuMgr3", "Operators Menu", 
				   operatorsMenuData, XtNumber(operatorsMenuData), 
				   &operatorsMenuPane, &operatorsMenuShell);

	windowsMenu = createMenuPane(menuMgr[3], "menuMgr4", "Windows Menu", 
				   windowsMenuData, XtNumber(windowsMenuData),
				   &bogusPane, &windowsMenuShell);

	/*
		create the sub sub menus
	*/

	/* fitness scaling menu */

	for (i = 0; i < NUMBER_OF_SCALING_OPERATORS; i++) {
		scalingOperatorStructType *scalingOperators 
										= getScalingOperators();
		scalingMenuData[i].name = scalingOperators[i].name;
		scalingMenuData[i].func = scalingMenuCB;
		scalingMenuData[i].data = (caddr_t) i;
	}

	scalingMenu = createMenuPane(menuMgr[2], "Fitness Scaling", 
								"Fitness Scaling Menu", scalingMenuData, 
								XtNumber(scalingMenuData), &bogusPane,
								&scalingMenuShell);

	/* fitness sharing menu */

    for (i = 0; i < NUMBER_OF_SHARING_OPERATORS; i++) {
        sharingOperatorStructType *sharingOperators
                                        = getSharingOperators();
        sharingMenuData[i].name = sharingOperators[i].name;
        sharingMenuData[i].func = sharingMenuCB;
        sharingMenuData[i].data = (caddr_t) i;
    }

	sharingMenu = createMenuPane(menuMgr[2], "Fitness Sharing",
								"Fitness Sharing Menu", sharingMenuData,
								XtNumber(sharingMenuData), &bogusPane,
								&sharingMenuShell);

	/* selection menu */

	for (i = 0; i < NUMBER_OF_SELECTION_OPERATORS; i++) {
		selectionOperatorStructType *selectionOperators 	
										= getSelectionOperators();
        selectionMenuData[i].name = selectionOperators[i].name;
        selectionMenuData[i].func = selectionMenuCB;
        selectionMenuData[i].data = (caddr_t) i;
    }

	selectionMenu = createMenuPane(menuMgr[2], "Selection",
								"Selection Menu", selectionMenuData,
								XtNumber(selectionMenuData), &bogusPane,
								&selectionMenuShell);

	/* sampling menu */

	for (i = 0; i < NUMBER_OF_SAMPLING_OPERATORS; i++) {
		samplingOperatorStructType *samplingOperators 
										= getSamplingOperators();
        samplingMenuData[i].name = samplingOperators[i].name;
        samplingMenuData[i].func = samplingMenuCB;
        samplingMenuData[i].data = (caddr_t) i;
    }

	samplingMenu = createMenuPane(menuMgr[2], "Sampling",
								"Sampling Menu", samplingMenuData,
								XtNumber(samplingMenuData), &samplingMenuPane,
								&samplingMenuShell);

	/* crossover menu */

	numberOfCrossoverOperators = getNumberOfCrossoverOperators();

	crossoverMenuData = (myMenuStruct *) malloc((numberOfCrossoverOperators+2) *
											sizeof(myMenuStruct));
	if (crossoverMenuData == NULL)
		die("setUpMenus(): can't allocate crossoverMenuData");

    for (i = 0; i < numberOfCrossoverOperators; i++) {
        crossoverOperatorStructType *crossoverOperators 
										= getCrossoverOperators();
        crossoverMenuData[i].name = crossoverOperators[i].name;
        crossoverMenuData[i].func = crossoverMenuCB;
        crossoverMenuData[i].data = (caddr_t) i;
    }

	/* set up the menu separator and the crossover probability option */

	crossoverMenuData[i].name = NULL;
	crossoverMenuData[i].func = NULL;
	crossoverMenuData[i].data = NULL;

	crossoverMenuData[++i].name = "Crossover Probability...";
	crossoverMenuData[i].func = crossoverProbabilityCB;
	crossoverMenuData[i].data = NULL;

	crossoverMenu = createMenuPane(menuMgr[2], "Crossover",
								"Crossover Menu", crossoverMenuData,
								(numberOfCrossoverOperators+2), 
								&bogusPane, &crossoverMenuShell);

	/* mutation menu */

    numberOfMutationOperators = getNumberOfMutationOperators();

	mutationMenuData = (myMenuStruct *) malloc((numberOfMutationOperators+2) *
                                            sizeof(myMenuStruct));
    if (mutationMenuData == NULL)
        die("setUpMenus(): can't allocate mutationMenuData");

    for (i = 0; i < numberOfMutationOperators; i++) {
        mutationOperatorStructType *mutationOperators 
										= getMutationOperators();
        mutationMenuData[i].name = mutationOperators[i].name;
        mutationMenuData[i].func = mutationMenuCB;
        mutationMenuData[i].data = (caddr_t) i;
    }

    /* set up the menu separator and the mutation probability option */

    mutationMenuData[i].name = NULL;
    mutationMenuData[i].func = NULL;
    mutationMenuData[i].data = NULL;

    mutationMenuData[++i].name = "Mutation Probability...";
    mutationMenuData[i].func = mutationProbabilityCB;
    mutationMenuData[i].data = NULL;

	mutationMenu = createMenuPane(menuMgr[2], "Mutation",
								"Mutation Menu", mutationMenuData,	
								(numberOfMutationOperators+2), 
								&bogusPane, &mutationMenuShell );
#	endif
}



void nameMainMenu() {
    /*
    ========================================
    :purpose
        give the menu bar widget a name
    ========================================
    */
	nameWindow(mainMenuTopLevel, "Splicer Main Menu");
}



void checkMenuItems(theMenu, n, theItem, theAlias)
    /*
    ========================================
    :purpose
    	place a check mark on items within a 
		menu
    ========================================
    */
 WidgetList theMenu;
 int n, theItem, theAlias;
{
    register int i;
	for(i = 0; i < n; i++)
        checkMenuItem(theMenu[i], FALSE);
    checkMenuItem(theMenu[theItem], TRUE);
    if (theAlias >= 0)
        checkMenuItem(theMenu[theAlias], TRUE);
}



void checkWindowsMenu() {
    /*
    ========================================
    :purpose
        check all items on the windows menu
		at program start up; to signal that 
		they are all currently open
    ========================================
    */
	checkMenuItem(controlMenu[SET_PARAMETERS], TRUE);
	checkMenuItem(windowsMenu[STATISTICS_W],   TRUE);
	checkMenuItem(windowsMenu[OBJECTIVE_W],    TRUE);
	checkMenuItem(windowsMenu[NORM_FIT_W],     TRUE);
	checkMenuItem(windowsMenu[USER_W],         TRUE);
	checkMenuItem(windowsMenu[TRACE_W],        TRUE);
}



void updateScalingMenu(menuItem)
    /*
    ========================================
    :purpose
        update the scaling menu by checking the
		the currently selected scaling operator
    ========================================
    */
 int menuItem;
{
	operatorStructType *scalingOperators = getScalingOperators();

    checkMenuItems(scalingMenu, NUMBER_OF_SCALING_OPERATORS,
							menuItem, scalingOperators[menuItem].alias);
}



void updateSharingMenu(menuItem)
    /*
    ========================================
    :purpose
        update the sharing menu by checking the
        the currently selected sharing operator
    ========================================
    */
 int menuItem;
{
    operatorStructType *sharingOperators = getSharingOperators();

    checkMenuItems(sharingMenu, NUMBER_OF_SHARING_OPERATORS,
                            menuItem, sharingOperators[menuItem].alias);
}



void updateSelectionMenu(menuItem)
    /*
    ========================================
    :purpose
        update the selection menu by checking the
        the currently selected selection operator
    ========================================
    */
 int menuItem;
{
    operatorStructType *selectionOperators = getSelectionOperators();

    checkMenuItems(selectionMenu, NUMBER_OF_SELECTION_OPERATORS,
							menuItem, selectionOperators[menuItem].alias);
}



void updateSamplingMenu(menuItem)
    /*
    ========================================
    :purpose
        update the sampling menu by checking the
        the currently selected sampling operator
    ========================================
    */
 int menuItem;
{
	operatorStructType *samplingOperators = getSamplingOperators();

    checkMenuItems(samplingMenu, NUMBER_OF_SAMPLING_OPERATORS,
							menuItem, samplingOperators[menuItem].alias);
}



void updateCrossoverMenu(menuItem)
	/*
	========================================
	:purpose
        update the crossover menu by checking the
        the currently selected crossover operator
	========================================
	*/
 int menuItem;
{
	operatorStructType *crossoverOperators = getCrossoverOperators();

    checkMenuItems(crossoverMenu, getNumberOfCrossoverOperators(),
							menuItem, crossoverOperators[menuItem].alias);
}




void updateMutationMenu(menuItem)
    /*
    ========================================
	:purpose
        update the mutation menu by checking the
        the currently selected mutation operator
    ========================================
    */
 int menuItem;
{
	operatorStructType *mutationOperators = getMutationOperators();
   
	checkMenuItems(mutationMenu, getNumberOfMutationOperators(),
							menuItem, mutationOperators[menuItem].alias);
}



void initScalingMenu()
    /*
    ========================================
	:purpose
		initialize the fitness scaling menu;
		turn off all unavailable items, then
		update the menu
    ========================================
    */
{
	int i;
	operatorStructType *scalingOperators = getScalingOperators();

	/* disable any non-available items */

	for (i = 0; i < NUMBER_OF_SCALING_OPERATORS; i++)
		if (!scalingOperators[i].available)
			disableItem(scalingMenu, i);

	/* check the selected item */

    updateScalingMenu(getScalingOperatorId());
}



void initSharingMenu()
    /*
    ========================================
    :purpose
        initialize the fitness sharing menu;
        turn off all unavailable items, then
        update the menu
    ========================================
    */
{
    int i;
    operatorStructType *sharingOperators = getSharingOperators();

    /* disable any non-available items */

    for (i = 0; i < NUMBER_OF_SHARING_OPERATORS; i++)
        if (!sharingOperators[i].available)
            disableItem(sharingMenu, i);

    /* check the selected item */

    updateSharingMenu(getSharingOperatorId());
}



void initSelectionMenu()
    /*
    ========================================
	:purpose
        initialize the selection menu;
        turn off all unavailable items, 	
		then update the menu
    ========================================
    */
{
    int i;
    operatorStructType *selectionOperators = getSelectionOperators();

    /* disable any non-available items */

    for (i = 0; i < NUMBER_OF_SELECTION_OPERATORS; i++)
        if (!selectionOperators[i].available)
            disableItem(selectionMenu, i);

    /* check the selected item */

    updateSelectionMenu(getSelectionOperatorId());
}



void initSamplingMenu()
    /*
    ========================================
    :purpose
        initialize the sampling menu;
        turn off all unavailable items, 
		then update the menu
    ========================================
    */
{
    int i;
    operatorStructType *samplingOperators = getSamplingOperators();

    /* disable any non-available items */

    for (i = 0; i < NUMBER_OF_SAMPLING_OPERATORS; i++)
        if (!samplingOperators[i].available)
            disableItem(samplingMenu, i);

    /* check the selected item */

    updateSamplingMenu(getSamplingOperatorId());
}



void initCrossoverMenu()
    /*
    ========================================
    :purpose
        initialize the crossover menu;
        turn off all unavailable items, 
		then update the menu
    ========================================
    */
{
    int i;
    operatorStructType *crossoverOperators = getCrossoverOperators();

    /* disable any non-available items */

    for (i = 0; i < getNumberOfCrossoverOperators(); i++)
        if (!crossoverOperators[i].available)
            disableItem(crossoverMenu, i);

    /* check the selected item */

    updateCrossoverMenu(getCrossoverOperatorId());
}



void initMutationMenu()
    /*
    ========================================
    :purpose
        initialize the mutation menu;
        turn off all unavailable items, 
		then update the menu
    ========================================
    */
{
    int i;
    operatorStructType *mutationOperators = getMutationOperators();

    /* disable any non-available items */

    for (i = 0; i < getNumberOfMutationOperators(); i++)
        if (!mutationOperators[i].available)
            disableItem(mutationMenu, i);

    /* check the selected item */

    updateMutationMenu(getMutationOperatorId());
}



void initGAMenus()
    /*
    ========================================
    :purpose
        initialize all of the GA menus
    ========================================
    */
{
	int i;

	/*
		init file menu
	*/
	enableItem(controlMenu, REINITIALIZE);
    enableItem (fileMenu, SAVE_PARAM);
    enableItem (fileMenu, LOAD_PARAM);
    disableItem(fileMenu, SAVE_STATE);
    disableItem(fileMenu, LOAD_STATE);
    disableItem(fileMenu, SAVE_BEST);
    enableItem(fileMenu, QUIT);

	/* init control menu */

    enableItem(controlMenu, CREATEPOPUL);
    enableItem(controlMenu, RUN);

    setItem(controlMenu, SET_PARAMETERS, "Set Control Parameters...");
    setItem(controlMenu, RUN, "Run");

	/* init sub operators menu */

	initScalingMenu();
	initSharingMenu();
	initSelectionMenu();
    initSamplingMenu();
    initCrossoverMenu();
    initMutationMenu();
}

