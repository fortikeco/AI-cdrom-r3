/*
 ==============================================================================
 macDialog.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module is part of the macintosh interface for the GA tool; 
	it contains all functions that deal with dialog boxes
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are also externed
 in macDialog.h
 ========================================
 */

/* general functions */

void messageDialog(char *, bool);
bool okCancelDialog(char *);
bool yesNoDialog(char *);
void singleIntEntryDialog(int *, char *, char *, int, int);
void singleFloatEntryDialog(float *, char *, char *, float, float);
void okAlert(char *);
void outlineButton(DialogPtr, short);

/* application-specific functions */

int macReinit(void);

void openParametersDialog(void);
void closeParametersDialog(void);
void updateParamDialog(void);

void openStatisticsDialog(void);
void closeStatisticsDialog(void);
void updateStatsDialog(void);

void createPopDialog(char *, bool, int, int);

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

pascal void drawOperatorPopupMenus(WindowPtr theDialog, int theItem);

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

	/* menu stuff */

extern MenuHandle	appleMenu,
					fileMenu,
					editMenu,
					controlMenu,
					operatorsMenu,
						scalingMenu,
						sharingMenu,
						selectionMenu,
						samplingMenu,
						crossoverMenu,
						mutationMenu,
					windowMenu;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */
 
DialogPtr		whichDialog	= NULL,
				paramDialog	= NULL,
				statsDialog	= NULL;

DialogRecord	paramDialogR,
				statsDialogR;

/*
 ========================================
 functions
 ========================================
 */

/* general functions */

void messageDialog(char *string, bool flag)
	/*
	========================================
	:purpose
		put up or take down a notification 
		of doing something
	========================================
	*/
{			
	static DialogPtr myDialog = NULL;
	
	if (flag == ON) {
		if (!myDialog) {
			ParamText(CtoPstr(string), "\p", "\p", "\p");
			PtoCstr(string);
			myDialog = GetNewDialog(MessageDialog, NULL, (WindowPtr) -1);
			DrawDialog(myDialog);
			watchCursor();
		}
	}
	else
		if (myDialog) {
			CloseDialog(myDialog);
			myDialog = NULL;
			arrowCursor();
		}
		
}	/* end messageDialog() */



	
bool okCancelDialog(char *string)
	/*
	========================================
	:purpose
		put up a message with ok and 
		cancel buttons
	========================================
	*/
{			
	short 		itemHit = -1;
	DialogPtr	myDialog;
	
	ParamText(CtoPstr(string), "\p", "\p", "\p");
	PtoCstr(string);
	myDialog = GetNewDialog(OkCancelDialog, NULL, (WindowPtr) -1);
	SetPort(myDialog);
	outlineButton(myDialog, OkCancelOkButton);

	while ((itemHit != OkCancelOkButton) && (itemHit != OkCancelCancelButton))
		 ModalDialog(NULL, &itemHit);
	CloseDialog(myDialog);
	if (itemHit == OkCancelCancelButton)
		return(FALSE);
	else
		return(TRUE);
		
}	/* end okCancelDialog() */




bool yesNoDialog(char *string)
	/*
	========================================
		:purpose
			put up a message with yes and no buttons
	========================================
	*/
{			
	short 		itemHit = -1;
	DialogPtr	myDialog;
	
	ParamText(CtoPstr(string), "\p", "\p", "\p");
	PtoCstr(string);
	myDialog = GetNewDialog(YesNoDialog, NULL, (WindowPtr) -1);
	SetPort(myDialog);
	outlineButton(myDialog, YesNoYesButton);
	
	while ((itemHit != YesNoYesButton) && (itemHit != YesNoNoButton))
		 ModalDialog(NULL, &itemHit);
		 
	CloseDialog(myDialog);
	
	if (itemHit == YesNoNoButton)
		return(FALSE);
	else
		return(TRUE);
		
}	/* end yesNoDialog() */



	
void singleIntEntryDialog(int *number, char *string1, char *string2, int low, int high)
	/*
	========================================
		:purpose
			get a single integer number from the user
	========================================
	*/
{			
	short 		itemHit;
	DialogPtr	myDialog;
	int			type;
	Handle		item;
	Rect		box;
	char		text[255];
	bool		okChoice = FALSE;
	int			myNumber;
	
	ParamText(CtoPstr(string1), CtoPstr(string2), "\p", "\p");
	PtoCstr(string1);
	PtoCstr(string2);
	myDialog = GetNewDialog(SingleNumberDialog, NULL, (WindowPtr) -1);
	SetPort(myDialog);
	outlineButton(myDialog, SingleNumberOkButton);
	
	GetDItem(myDialog, SingleNumberEText, &type, &item, &box);
	PtoCstr(text);
	sprintf(text, "%d", *number);
	CtoPstr(text);
	SetIText(item, text);
	
	while (!okChoice) {
		SelIText(myDialog, SingleNumberEText, 0, 255);
		itemHit = 0;
		while ((itemHit != SingleNumberOkButton) && (itemHit != SingleNumberCancelButton))
			 ModalDialog(NULL, &itemHit);
		if (itemHit == SingleNumberCancelButton) {
			CloseDialog(myDialog);
			return;
		}
		GetIText(item, text);
		PtoCstr(text);
		myNumber = atoi(text);
		if ((myNumber < low) || (myNumber > high))
			SysBeep(1);
		else {
			okChoice = TRUE;
			*number = myNumber;
		}
	}
	CloseDialog(myDialog);
	
}	/* end singleIntEntryDialog() */




void singleFloatEntryDialog(float *number, char *string1, char *string2, float low, float high)
	/*
	========================================
		:purpose
			get a single floating point number from the user
	========================================
	*/
{			
	short 		itemHit;
	DialogPtr	myDialog;
	int			type;
	Handle		item;
	Rect		box;
	char		text[255];
	bool		okChoice = FALSE;
	float		myNumber;
	
	ParamText(CtoPstr(string1), CtoPstr(string2), "\p", "\p");
	PtoCstr(string1);
	PtoCstr(string2);
	myDialog = GetNewDialog(SingleNumberDialog, NULL, (WindowPtr) -1);
	SetPort(myDialog);
	outlineButton(myDialog, SingleNumberOkButton);
	
	GetDItem(myDialog, SingleNumberEText, &type, &item, &box);
	PtoCstr(text);
	sprintf(text, "%g", *number);
	CtoPstr(text);
	SetIText(item, text);
	
	while (!okChoice) {
		SelIText(myDialog, SingleNumberEText, 0, 255);
		itemHit = 0;
		while ((itemHit != SingleNumberOkButton) && (itemHit != SingleNumberCancelButton))
			 ModalDialog(NULL, &itemHit);
		if (itemHit == SingleNumberCancelButton) {
			CloseDialog(myDialog);
			return;
		}
		GetIText(item, text);
		PtoCstr(text);
		myNumber = atof(text);
		if ((myNumber < low) || (myNumber > high))
			SysBeep(1);
		else {
			okChoice = TRUE;
			*number = myNumber;
		}
	}
	CloseDialog(myDialog);
	
}	/* end singleFloatEntryDialog() */



void okAlert(char *string)
	/*
	========================================
		:purpose
			put up a message with only an ok button
	========================================
	*/
{			
	short 		itemHit = 0;
	
	ParamText(CtoPstr(string), "\p", "\p", "\p");
	PtoCstr(string);
	StopAlert(OkAlert, NULL);
}



void outlineButton(DialogPtr theDialog, short itemNum)
	/*
	========================================
	:purpose
		outline default button in a dialog box (written by Gary Riley)
	========================================
	*/
{
	Handle 	itemHandle;
   	Rect	box;
   	short	itemType;

		/* get information about the dialog item that is to be outlined */
   
   	GetDItem (theDialog, itemNum, &itemType, &itemHandle, &box);
   
		/* outline the button */
   
	PenSize (3, 3);
   	InsetRect (&box,-4, -4);
   	FrameRoundRect (&box, 16, 16);
   	
   		/* Return pen size to normal */
   		
   	PenSize (1, 1);
}



/* application-specific functions */

int macReinit(void)
	/*
	========================================
	:purpose
		reinitialization dialog
	========================================
	*/
{
	DialogRecord	reinitDialogR;
	DialogPtr		reinitDialog;
	int				i;
	int				itemHit;
	int				theChoice = ReinitCurrentValuesButton;
	int			   *type;
	Handle		   *itemHandle;
	Rect		   *box;
	
	/* create the dialog box */

	reinitDialog = GetNewDialog(ReinitializationDialog, &reinitDialogR, (WindowPtr) -1);
	SetPort(reinitDialog);
	
	/* outline the cancel button as the default */
		
	GetDItem(reinitDialog, ReinitCancelButton, &type, &itemHandle, &box);
	outlineButton(reinitDialog, ReinitCancelButton);
	
	/* set the initial button values */
		
	GetDItem(reinitDialog, ReinitCurrentValuesButton, &type, &itemHandle, &box);
	SetCtlValue(itemHandle, ON);

	GetDItem(reinitDialog, ReinitUserValuesButton, &type, &itemHandle, &box);
	SetCtlValue(itemHandle, OFF);

	GetDItem(reinitDialog, ReinitStoredValuesButton, &type, &itemHandle, &box);
	SetCtlValue(itemHandle, OFF);

	GetDItem(reinitDialog, ReinitDefaultValuesButton, &type, &itemHandle, &box);
	SetCtlValue(itemHandle, OFF);
	
	/* get the user input */
	
	while ((itemHit != ReinitOkButton) && (itemHit != ReinitCancelButton)) {
		ModalDialog(NULL, &itemHit);
		if ((itemHit >= ReinitCurrentValuesButton) && (itemHit <= ReinitDefaultValuesButton)) {
			for (i = ReinitCurrentValuesButton; i <= ReinitDefaultValuesButton; i++) {
				GetDItem(reinitDialog, i, &type, &itemHandle, &box);
		 		if (itemHit == i) {
		 			theChoice = i;
		 			SetCtlValue(itemHandle, ON);
		 		}
		 		else
		 			SetCtlValue(itemHandle, OFF);
		 	}
		}
	}
	CloseDialog(reinitDialog);
	if (itemHit == ReinitCancelButton)
		return(FALSE);
	else {
		switch (theChoice) {
			case (ReinitCurrentValuesButton) :
				theChoice = CURRENT_VALUES;
				break;
			case (ReinitUserValuesButton) :
				theChoice = USER_VALUES;
				break;
			case (ReinitStoredValuesButton) :
				theChoice = LOAD_VALUES;
				break;
			case (ReinitDefaultValuesButton) :
				theChoice = DEFAULT_VALUES;
				break;
			default :
				die("macReinit(): bad choice");
				break;
		}
		return(theChoice);
	}
}



void openParametersDialog(void)
	/*
	========================================
	:purpose
		create the parameters dialog box
	========================================
	*/
{
	int			type;
	Handle		item;
	Rect		box;
	
	if (paramDialog)
		SelectWindow(paramDialog);
	else {
		paramDialog = GetNewDialog(ControlParametersDialog, 
											&paramDialogR, (WindowPtr) -1);
		GetDItem(paramDialog, ScalingOperatorUItem, &type, &item, &box);
		SetDItem(paramDialog, ScalingOperatorUItem, userItem, 
 					  				(Handle)drawOperatorPopupMenus, &box);
		updateParamDialog();
		CheckItem(controlMenu, SetParametersM, TRUE);
	}
}



void closeParametersDialog(void)
	/*
	========================================
		:purpose
			delete the parameters dialog
	========================================
	*/
{
	if (paramDialog) {
		CloseDialog(paramDialog);
		paramDialog = NULL;
		CheckItem(controlMenu, SetParametersM, FALSE);
	}
}


	
void updateParamDialog(void)
	/*
	========================================
		:purpose
			update the parameters dialog
	========================================
	*/
{
	WindowPtr	oldPort;
	char		text[255];
	int			type;
	Handle		item;
	Rect		box;

	if (!paramDialog)		/* see if the dialog box is on the screen */
		return;

	GetPort(&oldPort);
	SetPort(paramDialog);
	
	GetDItem(paramDialog, NumberOfParametersButton, &type, &item, &box);
	if (gaFlags.runningGA || gaFlags.stop) 		/* no changes allowed */
		HiliteControl(item, 255);
	else
		HiliteControl(item, 0);
	sprintf(text, "%d", getNumberOfParameters());
	CtoPstr(text);
	SetCTitle(item, text);
	PtoCstr(text);
	
	GetDItem(paramDialog, PopulationSizeButton, &type, &item, &box);
	if (gaFlags.runningGA || gaFlags.stop) 		/* no changes allowed */
		HiliteControl(item, 255);
	else
		HiliteControl(item, 0);
	sprintf(text, "%d", getPopulationSize());
	CtoPstr(text);
	SetCTitle(item, text);
	PtoCstr(text);

	GetDItem(paramDialog, ParameterCharacteristicsButton, &type, &item, &box);
	if (gaFlags.runningGA || gaFlags.stop) 		/* no changes allowed */
		HiliteControl(item, 255);
	else
		HiliteControl(item, 0);

	drawOperatorPopupMenus(paramDialog, 1);
	
	GetDItem(paramDialog, CrossoverProbabilityButton, &type, &item, &box);
	sprintf(text, "%g", getCrossoverProbability());
	CtoPstr(text);
	SetCTitle(item, text);
	PtoCstr(text);

	GetDItem(paramDialog, MutationProbabilityButton, &type, &item, &box);
	sprintf(text, "%g", getMutationProbability());
	CtoPstr(text);
	SetCTitle(item, text);
	PtoCstr(text);

	GetDItem(paramDialog, RandomSeedButton, &type, &item, &box);
	sprintf(text, "%d", getRandomSeed());
	CtoPstr(text);
	SetCTitle(item, text);
	PtoCstr(text);

	SetPort(oldPort);
}	/* end updateParamDialog() */



pascal void drawOperatorPopupMenus(WindowPtr theDialog, int theItem)
 {
	drawOperatorPopupMenu(scalingMenu, ScalingOperatorUItem, 
												getScalingOperatorName());
	
	drawOperatorPopupMenu(sharingMenu, SharingOperatorUItem, 
												getSharingOperatorName());
	
	drawOperatorPopupMenu(selectionMenu, SelectionOperatorUItem, 
												getSelectionOperatorName());
			
	drawOperatorPopupMenu(samplingMenu, SamplingOperatorUItem, 
												getSamplingOperatorName());
	
	drawOperatorPopupMenu(crossoverMenu, CrossoverOperatorUItem, 
												getCrossoverOperatorName());
			
	drawOperatorPopupMenu(mutationMenu, MutationOperatorUItem, 
												getMutationOperatorName());
}

	
void openStatisticsDialog(void)
	/*
	========================================
		:purpose
			create or select the statistics dialog
	========================================
	*/
{
	if (statsDialog)
		SelectWindow(statsDialog);
	else {
		statsDialog = GetNewDialog(StatisticsDialog, &statsDialogR, (WindowPtr) -1);
		DrawDialog(statsDialog);
		updateStatsDialog();
		CheckItem(windowMenu, StatisticsWindowM, TRUE);
	}
	
}	/* end openStatisticsDialog() */




void closeStatisticsDialog(void)
	/*
	========================================
		:purpose
			close the statistics dialog
	========================================
	*/
{
	if (statsDialog) {						/* window is open */
		CloseDialog(statsDialog);
		statsDialog = NULL;
		CheckItem(windowMenu, StatisticsWindowM, FALSE);
	}
}



	
void updateStatsDialog(void)
	/*
	========================================
		:purpose
			update the parameters dialog
	========================================
	*/
{
	char		text[255];
	int			type;
	Handle		item;
	Rect		box;
	unsigned	generationNumber;
	fitnessType	bestValue;
	fitnessType	maximumValue;
	fitnessType	minimumValue;
	fitnessType	averageValue;
	fitnessType	summedValue;

	if (!statsDialog)		/* see if the dialog box is on the screen */
		return;

	generationNumber = getGenerationNumber();
	GetDItem(statsDialog, StatsGenerationTEdit, &type, &item, &box);
	sprintf(text, "%d", generationNumber);
	CtoPstr(text);
	SetIText(item, text);
	PtoCstr(text);

	bestValue = getBestValue();
	GetDItem(statsDialog, StatsBestEverTEdit, &type, &item, &box);
	sprintf(text, "%g", bestValue);
	CtoPstr(text);
	SetIText(item, text);
	PtoCstr(text);

	maximumValue = getMaximumValue();
	GetDItem(statsDialog, StatsBestTEdit, &type, &item, &box);
	sprintf(text, "%g", maximumValue);
	CtoPstr(text);
	SetIText(item, text);
	PtoCstr(text);

	averageValue = getAverageValue();
	GetDItem(statsDialog, StatsAverageTEdit, &type, &item, &box);
	sprintf(text, "%g", averageValue);
	CtoPstr(text);
	SetIText(item, text);
	PtoCstr(text);

	minimumValue = getMinimumValue();
	GetDItem(statsDialog, StatsWorstTEdit, &type, &item, &box);
	sprintf(text, "%g", minimumValue);
	CtoPstr(text);
	SetIText(item, text);
	PtoCstr(text);

}	/* end updateStatsDialog() */




#define DRAW -1

void createPopDialog(char *string, bool flag, int max, int current)
	/*
	========================================
		:purpose
			dialog for creating the population
	========================================
	*/
{			
	static DialogPtr	myDialog = NULL;
	int					type;
	Handle				itemHandle;
	static Rect			box;
	static int			boxMaxRight;
	
	switch(flag) {
		case ON:
			if (!myDialog) {
				ParamText(CtoPstr(string), "\p", "\p", "\p");
				PtoCstr(string);
				myDialog = GetNewDialog(CreatePopulationDialog, NULL, (WindowPtr) -1);
				SetPort(myDialog);
				GetDItem(myDialog, 2, &type, &itemHandle, &box);
				FrameRect(&box);
				InsetRect(&box, 1, 1);
				boxMaxRight = box.right;
				DrawDialog(myDialog);
				watchCursor();
			}
			break;
		case OFF:
			if (myDialog) {
				CloseDialog(myDialog);
				myDialog = NULL;
				arrowCursor();
			}
			break;
		case DRAW:
			if (myDialog) {
				SetPort(myDialog);
				box.right = (int)(boxMaxRight*((float)current/max));
				FillRect(&box, gray);
			}
	}
}	/* end createPopDialog() */
