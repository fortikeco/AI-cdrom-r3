/*
 ==============================================================================
 macEvent.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module is part of the macintosh interface for the GA tool; 
	it contains all functions that deal with events in menus, windows, 
	dialogs, etc.
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/
 
/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are also externed
 in macEvent.h
 ========================================
 */

/* general functions */

void doEvent(void);

/* application-specific functions */

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/* general functions */

void toolboxInit(void);
void doEvent(void);
void doUpdateEvent(EventRecord *);
void doActivateEvent(EventRecord *);
void doMenu(long);
void doDialog(DialogPtr, short);

/* application-specific functions */

void setParameter(void (*function) ());
void restartProc(void);

/*
 ========================================
 local macros
 ========================================
 */
 
#define wneTrapNum		0x60	/* WaitNextEvent() stuff */
#define unimplTrapNumM	0x9F
#define noSleep			0L
#define nilMouseRegion	0L

#define lookForWaitNextEvent() (NGetTrapAddress(wneTrapNum, ToolTrap) != \
								NGetTrapAddress(unimplTrapNumM, ToolTrap))

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */
 
extern flagsType gaFlags;

/* menu stuff */

extern MenuHandle	appleMenu,
					fileMenu,
					editMenu,
					controlMenu,
					operatorsMenu,
						scalingMenu,
						sharingMenu,
						selectionMenu,
						samplingMenu,
						crossoverMenu,
						mutationMenu,
					windowMenu;

/* window stuff */
	
extern WindowPtr	theWindow,
					whichWindow,
					objectiveWindow,
					fitnessWindow,
					userWindow,
					traceWindow;

/* dialog stuff */
	
extern DialogPtr	whichDialog,
					paramDialog,
					statsDialog,
					paramCharDialog;

extern DialogRecord	paramDialogR,
					statsDialogR;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */
 
/* event stuff */

EventRecord		theEvent;
short			whichItem;
bool			waitNextEventImplemented;

/* textedit stuff */
	
TEHandle		theText;

Rect			dragBoundsRect,
				limitRect;

short			windowCode,
				stillInGoAway;

long			newSize;

/*
 ========================================
 functions
 ========================================
 */

/* event functions */
	
void main()
	/*
	========================================
	:purpose
		main event loop for macintosh interface
	========================================
	*/
{

	toolboxInit();
	watchCursor();
	setUpMenus();
	setUpWindows();
	
	/* initialize dragBoundsRect; this limits movement of a window */

	SetRect(&dragBoundsRect,
		screenBits.bounds.left   +  4,
		screenBits.bounds.top    + 24,
		screenBits.bounds.right  -  4,
		screenBits.bounds.bottom -  4);
		
	/* initialize limitRect - limits size of window */

	SetRect(&limitRect, 60, 40,
		screenBits.bounds.right  - screenBits.bounds.left -  4,
		screenBits.bounds.bottom - screenBits.bounds.top  - 24);
		
	theWindow = NULL;			/* no windows open */
	
	/* set up GA-specific stuff */

	initGA();					/* initialize GA variables */
	initUser();					/* allow user to override */
	initGAMenus();
	openParametersDialog();
	arrowCursor();				/* go back to the arrow cursor */

	/* begin main event loop */

	waitNextEventImplemented = lookForWaitNextEvent();
	FOREVER {
		doEvent();
	}

}	/* end of main */



void toolboxInit(void)
	/*
	========================================
	:purpose
		initialize the toolbox managers
	========================================
	*/
{	
	InitGraf(&thePort);			/* initialize quickdraw */
	InitFonts();				/* initialize the font manager */
	FlushEvents(everyEvent, 0); /* empty event queue */
	InitWindows();				/* initialize the window manager */
	InitMenus();				/* initialize menu manager */
	TEInit();					/* initialize textedit manager */
	InitDialogs(restartProc);	/* initialize dialog manager */
	InitCursor();				/* initialize the cursor */
}



void doEvent(void)
	/*
	========================================
	:purpose
		handle all events
	========================================
	*/
{
	GrafPtr		oldPort;
	char		c;
	bool		thereIsAnEvent;
	
	if (waitNextEventImplemented)
		thereIsAnEvent = WaitNextEvent(everyEvent, &theEvent, noSleep, nilMouseRegion);
	else {
		SystemTask();
		thereIsAnEvent = GetNextEvent(everyEvent, &theEvent);
	}
	if (thereIsAnEvent) {
		if (IsDialogEvent(&theEvent)) {
			if (DialogSelect(&theEvent, &whichDialog, &whichItem)) {
				doDialog(whichDialog, whichItem);
			}
		}
		switch (theEvent.what) {
			case keyDown:
				c = theEvent.message & charCodeMask;
				if (theEvent.modifiers & cmdKey) {
					doMenu(MenuKey(c));
					HiliteMenu(0);
				}
				break;
				
			case mouseDown: {
				windowCode = FindWindow(theEvent.where, &whichWindow);
				switch (windowCode) {
					case inDesk:
						if ((whichWindow = FrontWindow()) != NULL)
							HiliteWindow(whichWindow, 0);
						break;
						
					case inMenuBar:
						doMenu(MenuSelect(theEvent.where));
						break;
					
					case inSysWindow:
						break;
					
					case inContent:
						if (whichWindow == FrontWindow()) {
							if (whichWindow == paramCharDialog)
								paramCharDialogContentAreaEvent(&theEvent);
						}
						else
							SelectWindow(whichWindow);
						break;
					
					case inDrag:
						DragWindow(whichWindow, theEvent.where, 
														&dragBoundsRect);
						break;
						
					case inGrow:
						newSize = GrowWindow(whichWindow, theEvent.where,
												&limitRect);
						if (newSize) {
							GetPort(&oldPort);
							SetPort(whichWindow);
							EraseRect(&whichWindow->portRect);
							SizeWindow(whichWindow, LoWord(newSize),
													HiWord(newSize), TRUE);
							EraseRect(&whichWindow->portRect);
							InvalRect(&whichWindow->portRect);
							SetPort(oldPort);
						}
						break;
					
					case inGoAway:
						stillInGoAway = TrackGoAway(whichWindow, 
								theEvent.where);
						if (stillInGoAway) {
							if (whichWindow == objectiveWindow)
								closeObjectiveWindow();
							else if (whichWindow == userWindow)
								closeUserWindow();
							else if (whichWindow == fitnessWindow)
								closeFitnessWindow();
							else if (whichWindow == traceWindow)
								closeTraceWindow();
							else if (whichWindow == paramDialog)
								closeParametersDialog();
							else if (whichWindow == statsDialog)
								closeStatisticsDialog();
						}
						break;
					
					case inZoomIn:
					case inZoomOut:
						if (TrackBox(whichWindow, theEvent.where, windowCode)) {
							GetPort(&oldPort);
							SetPort(whichWindow);
							EraseRect(&whichWindow->portRect);
							ZoomWindow(whichWindow, windowCode, 0);
							InvalRect(&whichWindow->portRect);
							SetPort(oldPort);
						}
						break;
				}				/* end switch (windowCode) */
				break;
			}				/* end case mouseDown: */
			
			case updateEvt:
				doUpdateEvent(&theEvent);
				break;
				
			case activateEvt:
				doActivateEvent(&theEvent);
				break;
				
			default:
				break;
				
		}				/* end switch (theEvent.what) */
	}				/* end if (GetNextEvent(everyEvent, &theEvent)) */
}			/* end doEvent() */



	
void doUpdateEvent(EventRecord *theEvent)
	/*
	========================================
	:purpose
		handle all update events
	========================================
	*/
{
	WindowPtr	whichWindow, oldPort;
	
	GetPort(&oldPort);
	SetPort(whichWindow = (WindowPtr)theEvent->message);
	BeginUpdate(whichWindow);
	if (whichWindow == objectiveWindow)
		updateObjectiveWindow();
	else if (whichWindow == fitnessWindow)
		updateFitnessWindow();
	else if (whichWindow == userWindow)
		updateUserWindow();
	else if (whichWindow == traceWindow)
		updateTraceWindow();
	EndUpdate(whichWindow);
	SetPort(oldPort);
}	/* end doUpdateEvent() */



	
void doActivateEvent(EventRecord *theEvent)
	/*
	========================================
	:purpose
		handle all activate events
	========================================
	*/
{
	register WindowPtr whichWindow;

	SetPort(whichWindow = (WindowPtr)theEvent->message);
	if (whichWindow == paramCharDialog) {
		activateParamCharDialog(theEvent);
	}
	
}	/* end doActivateEvent() */



	
void doMenu(long menuResult)
	/*
	========================================
	:purpose
		handle menu events
	========================================
	*/
{
	int i;
	int theChoice;
	register short		menuID,
						itemNumber;
	Str255				daName;
	GrafPtr				theCurrentPort;
	int					type;
	Handle				item;
	Rect				box;
	
	menuID     = HiWord(menuResult);
	itemNumber = LoWord(menuResult);
	
	switch (menuID) {
	
		case AppleMenu:
			if (itemNumber == AboutSplicerM) {
				doAboutWindow();
			}
			else if (itemNumber == AboutApplicationM) {
				doAboutApplicationWindow();
			}
			else {
				GetItem(appleMenu, itemNumber, &daName);
				GetPort(&theCurrentPort);
				OpenDeskAcc(&daName);
				SetPort(theCurrentPort);
			}
			break;
		
		case FileMenu:
			switch (itemNumber) {
				case SaveParametersM:
					saveParameters();
					break;
				
				case LoadParametersM:
					loadParameters();
					updateParamDialog();
					break;

				case SaveStateM:
					saveState();
					break;
					
				case LoadStateM:
					loadState();
					break;
					
				case SaveSolutionsM:
					saveBest();
					break;
					
				case QuitM:
					ExitToShell();
					break;
					
			}	/* end switch (itemNumber) */
			break;
						
		case EditMenu:
			if  (SystemEdit(itemNumber-1))
				break;
			if (!theText)
				break;
				
			switch (itemNumber) {
				case UndoM:
					break;
					
				case CutM:
					TECut(theText);
					TEToScrap();
					break;
					
				case CopyM:
					TECopy(theText);
					TEToScrap();
					break;
					
				case PasteM:
					TEPaste(theText);
					break;
					
				case ClearM:
					TEDelete(theText);
					break;
			}
			break;
			
		case ControlMenu:
			switch (itemNumber) {
				case SetParametersM:
					openParametersDialog();
					break;

				case CreatePopulationM:
					createPopulation();
					EnableItem(controlMenu, RunM);
					break;

				case RunM:
					if (!gaFlags.runningGA) {
						if (checkRunGA()) {
							gaFlags.runningGA = TRUE;
							gaFlags.stop = FALSE;
							updateParamDialog();
							for (i = 1; i != NumberOfFileMenuOptions; i++)
								DisableItem(fileMenu, i);
							for (i = 1; i != NumberOfEditMenuOptions; i++)
								DisableItem(editMenu, i);
							DisableItem(controlMenu, CreatePopulationM);
							DisableItem(controlMenu, ReinitializeM);
							SetItem(controlMenu, RunM, "\pStop");
							SetItem(controlMenu, SetParametersM, "\pShow Control Parameters...");
							runGA();
							SysBeep(1);
							SetItem(controlMenu, RunM, "\pResume");
							EnableItem(controlMenu, RunM);
							EnableItem(fileMenu, SaveParametersM);
							/* EnableItem(fileMenu, SaveStateM); */
							EnableItem(fileMenu, SaveSolutionsM);
							EnableItem(controlMenu, ReinitializeM);
							gaFlags.runningGA = FALSE;
						}
					}
					else {
						gaFlags.stop = TRUE;
						SetItem(controlMenu, RunM, "\pStopping after this generation");
						DisableItem(controlMenu, RunM);
					}
					break;
					
				case ReinitializeM:
					theChoice = macReinit();
					if ((theChoice >= CURRENT_VALUES) &&
						(theChoice <= DEFAULT_VALUES)) {
						watchCursor();
						closeParametersDialog();
						reinitialize(theChoice);
						initGAMenus();
						eraseWindow();
						updateStatsDialog();
						openParametersDialog();
						arrowCursor();
					}
					break;
			}
			break;
			
		case OperatorsMenu:
			switch (itemNumber) {
				case FitnessScalingM:
					break;
			
				case FitnessSharingM:
					break;
					
				case SelectionM:
					break;
					
				case SamplingM:
					break;
					
				case CrossoverM:
					break;
					
				case MutationM:
					break;
			}
			break;
		
		case ScalingMenu:
			setScalingOperator(itemNumber-1);
			break;
		
		case SharingMenu:
			setSharingOperator(itemNumber-1);
			break;
		
		case SelectionMenu:
			setSelectionOperator(itemNumber-1);
			break;
		
		case SamplingMenu:
			setSamplingOperator(itemNumber-1);
			break;
		
		case CrossoverMenu:
			if (itemNumber == (getNumberOfCrossoverOperators()+2))
				setParameter(enterCrossoverProbability);
			else
				setCrossoverOperator(itemNumber-1);		
			break;
			
		case MutationMenu:
			if (itemNumber == (getNumberOfMutationOperators()+2))
				setParameter(enterMutationProbability);
			else
				setMutationOperator(itemNumber-1);		
			break;

		case WindowMenu:
			switch (itemNumber) {
				case StatisticsWindowM:
					openStatisticsDialog();
					break;
				
				case ObjectiveWindowM:
					openObjectiveWindow();
					break;
					
				case FitnessWindowM:
					openFitnessWindow();
					break;

				case UserWindowM:
					openUserWindow();
					break;
					
				case TraceWindowM:
					openTraceWindow();
					break;
					
				case OpenAllWindowsM:
					openAllWindows();
					break;
					
				case CloseAllWindowsM:
					closeAllWindows();
					break;
			}
			break;
			
		default:
			break;

	}		/* end switch (menuID) */
	HiliteMenu(0);
	
}	/* end doMenu() */



	
void doDialog(DialogPtr	whichDialog, short whichItem)
	/*
	========================================
	:purpose
		handle dialog events
	========================================
	*/
{
	int			type;
	Handle		item;
	Rect		box;
	char		text[255];

	if (whichDialog == paramDialog) {

		switch (whichItem) {
		
			/* handle the cases where the user has clicked the save button */
			
			case NumberOfParametersButton :
				setParameter(enterNumberOfParameters);
				break;
				
			case ParameterCharacteristicsButton :
				openParamCharDialog();
				break;
			
			case PopulationSizeButton :
				setParameter(enterPopulationSize);
				break;
							
			case ScalingOperatorUItem:
				popUpOperatorMenu(scalingMenu, setScalingOperator,
					NUMBER_OF_SCALING_OPERATORS, ScalingOperatorUItem,
					getScalingOperatorId()+1);
				break;
				
			case SharingOperatorUItem:
				popUpOperatorMenu(sharingMenu, setSharingOperator,
					NUMBER_OF_SHARING_OPERATORS, SharingOperatorUItem,
					getSharingOperatorId()+1);
				break;
				
			case SelectionOperatorUItem:
				popUpOperatorMenu(selectionMenu, setSelectionOperator,
					NUMBER_OF_SELECTION_OPERATORS, SelectionOperatorUItem,
					getSelectionOperatorId()+1);
				break;
				
			case SamplingOperatorUItem:
				popUpOperatorMenu(samplingMenu, setSamplingOperator,
					NUMBER_OF_SAMPLING_OPERATORS, SamplingOperatorUItem,
					getSamplingOperatorId()+1);
				break;
				
			case CrossoverOperatorUItem:
				popUpOperatorMenu(crossoverMenu, setCrossoverOperator,
					getNumberOfCrossoverOperators(), CrossoverOperatorUItem,
					getCrossoverOperatorId()+1);
				break;
			
			case MutationOperatorUItem:
				popUpOperatorMenu(mutationMenu, setMutationOperator,
					getNumberOfMutationOperators(), MutationOperatorUItem,
					getMutationOperatorId()+1);
				break;
			
			case CrossoverProbabilityButton :
				setParameter(enterCrossoverProbability);
				break;
			
			case MutationProbabilityButton :				
				setParameter(enterMutationProbability);
				break;
			
			case RandomSeedButton :
				setParameter(enterRandomSeed);
				break;

		}	/* end switch (whichItem) */
		
	}
	else if (whichDialog == paramCharDialog) {
		doParamCharDialog(whichItem);
	}
	
}	/* end doDialog() */



void restartProc(void)
	/*
	========================================
	:purpose
		restart on crashing
	========================================
	*/
{
	ExitToShell();
}



FILE *openFile(type, prompt, title)
	/*
	========================================
	:purpose
		open a file on the mac and return a 
		file pointer
	========================================
	*/
 short type;
 char *prompt;
 char *title;
{
	SFTypeList	the_type_list;
	SFReply		the_reply;
	Point		upperLeft;
	FInfo		finderinfo;
	char		*fileType;
	FILE		*fp;

	/* get the file name */
	SetPt(&upperLeft,100,80);
	the_type_list[0] = 'TEXT';  
  	if (type == LOAD) {
  		SFGetFile(upperLeft, NULL, NULL, 1, the_type_list, NULL, &the_reply);
  		fileType = "r";
  	}
  	else if (type == SAVE) {
  		CtoPstr(prompt);
  		SFPutFile(upperLeft, prompt, "\pUntitled", NULL, &the_reply);
  		PtoCstr(prompt);
  		fileType = "w";
  	} else 
  		die("openMacFile(): bad type");

	if (the_reply.good == false)					/* user clicked cancel */
		return(NULL);

	/* set the volume for this file */
	SetVol(NULL, the_reply.vRefNum); 

	/* open the file */
	PtoCstr((char *)the_reply.fName);
	fp = fopen((char *)the_reply.fName, fileType);
	CtoPstr((char *)the_reply.fName);
	
	return(fp);
}



/* application-specific functions */

void setParameter(void (*function) ())
	/*
	========================================
	:purpose
		set a control parameter and update the parameter dialog
	========================================
	*/
{
	(*function) ();
	if (paramDialog)
		updateParamDialog();
		
}	/* end setParameter() */
