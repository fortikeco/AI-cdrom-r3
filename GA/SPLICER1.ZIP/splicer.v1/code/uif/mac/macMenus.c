/*
 ==============================================================================
 macMenu.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module is part of the macintosh interface for the GA tool; 
	it contains all functions that deal with menus
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are also externed
 in macMenu.h
 ========================================
 */

/* general functions */

void setUpMenus(void);
void checkMenuItems(MenuHandle, int, int, int);
void popUpMenu(MenuHandle);

/* application-specific functions */

void initGAMenus(void);
void setGAMenus(int);
void updateSelectionMenu(int);
void updateCrossoverMenu(int);
void updateMutationMenu(int);
void initSelectionMenu(void);
void initCrossoverMenu(void);
void initMutationMenu(void);

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */


/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType	gaFlags;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */
 
	/* menu stuff */

MenuHandle		appleMenu;
MenuHandle		fileMenu;
MenuHandle		editMenu;
MenuHandle		controlMenu;
MenuHandle		operatorsMenu;
	MenuHandle		scalingMenu;
	MenuHandle		sharingMenu;
	MenuHandle		selectionMenu;
	MenuHandle		samplingMenu;
	MenuHandle		crossoverMenu;
	MenuHandle		mutationMenu;
MenuHandle		windowMenu;

/* dialog stuff */

extern DialogPtr paramDialog;

/*
 ========================================
 functions
 ========================================
 */
 
	/* menu functions */
	
void setUpMenus(void)
	/*
	========================================
		:purpose
			set up menus and add them to the menu bar
	========================================
	*/
{
	int i;
	char menuString[256];
	operatorStructType *theOperators;
	
		/* Desk Accessory Menus */
		
	appleMenu = NewMenu(AppleMenu, "\p\24");
	AppendMenu(appleMenu, "\pAbout splicer...");
	AppendMenu(appleMenu, "\pAbout this application...;(-");
	AddResMenu(appleMenu, 'DRVR');
	InsertMenu(appleMenu, 0);
	
		/* File Menu */
	
	fileMenu = GetMenu(FileMenu);
	InsertMenu(fileMenu, 0);
	
		/* Edit Menu */
	
	editMenu = GetMenu(EditMenu);
	InsertMenu(editMenu, 0);
	
		/* Control Menu */
	
	controlMenu = GetMenu(ControlMenu);
	InsertMenu(controlMenu, 0);
	
		/* Operators Menu */
	
	operatorsMenu = GetMenu(OperatorsMenu);
	InsertMenu(operatorsMenu, 0);

		/* hierarchical operator menus */
			
		scalingMenu = GetMenu(ScalingMenu);
		theOperators = getScalingOperators();
		for (i = 0; i < NUMBER_OF_SCALING_OPERATORS; i++) {
			sprintf(menuString, "%s", theOperators[i].name);
			CtoPstr(menuString);
			AppendMenu(scalingMenu, menuString);
			PtoCstr(menuString);
		}
		InsertMenu(scalingMenu, -1);

		sharingMenu = GetMenu(SharingMenu);
		theOperators = getSharingOperators();
		for (i = 0; i < NUMBER_OF_SHARING_OPERATORS; i++) {
			sprintf(menuString, "%s", theOperators[i].name);
			CtoPstr(menuString);
			AppendMenu(sharingMenu, menuString);
			PtoCstr(menuString);
		}
		InsertMenu(sharingMenu, -1);

		selectionMenu = GetMenu(SelectionMenu);
		theOperators = getSelectionOperators();
		for (i = 0; i < NUMBER_OF_SELECTION_OPERATORS; i++) {
			sprintf(menuString, "%s", theOperators[i].name);
			CtoPstr(menuString);
			AppendMenu(selectionMenu, menuString);
			PtoCstr(menuString);
		}
		InsertMenu(selectionMenu, -1);

		samplingMenu = GetMenu(SamplingMenu);
		theOperators = getSamplingOperators();
		for (i = 0; i < NUMBER_OF_SAMPLING_OPERATORS; i++) {
			sprintf(menuString, "%s", theOperators[i].name);
			CtoPstr(menuString);
			AppendMenu(samplingMenu, menuString);
			PtoCstr(menuString);
		}
		InsertMenu(samplingMenu, -1);

		crossoverMenu = GetMenu(CrossoverMenu);
		theOperators = getCrossoverOperators();
		for (i = 0; i < getNumberOfCrossoverOperators(); i++) {
			sprintf(menuString, "%s", theOperators[i].name);
			CtoPstr(menuString);
			AppendMenu(crossoverMenu, menuString);
			PtoCstr(menuString);
		}
		AppendMenu(crossoverMenu, "\p(-;Set Probability...");
		InsertMenu(crossoverMenu, -1);
		
		mutationMenu = GetMenu(MutationMenu);
		theOperators = getMutationOperators();
		for (i = 0; i < getNumberOfMutationOperators(); i++) {
			sprintf(menuString, "%s", theOperators[i].name);
			CtoPstr(menuString);
			AppendMenu(mutationMenu, menuString);
			PtoCstr(menuString);
		}
		AppendMenu(mutationMenu, "\p(-;Set Probability...");
		InsertMenu(mutationMenu, -1);
	
		/* Window Menu */
	
	windowMenu = GetMenu(WindowMenu);
	InsertMenu(windowMenu, 0);
	
	DrawMenuBar();
	
}	/* end setUpMenus() */




void updateScalingMenu(int menuItem)
	/*
	========================================
	:purpose
		update the scaling menu; 
		check the selected item(s)
	========================================
	*/
{
	operatorStructType *scalingOperators = getScalingOperators();
	
	checkMenuItems(scalingMenu, NUMBER_OF_SCALING_OPERATORS, 
						menuItem+1, scalingOperators[menuItem].alias+1);		
}



void updateSharingMenu(int menuItem)
	/*
	========================================
	:purpose
		update the sharing menu; 
		check the selected item(s)
	========================================
	*/
{
	operatorStructType *sharingOperators = getSharingOperators();
	
	checkMenuItems(sharingMenu, NUMBER_OF_SHARING_OPERATORS, 
						menuItem+1, sharingOperators[menuItem].alias+1);		
}



void updateSelectionMenu(int menuItem)
	/*
	========================================
	:purpose
		update the selection menu; 
		check the selected item(s)
	========================================
	*/
{
	operatorStructType *selectionOperators = getSelectionOperators();
	
	checkMenuItems(selectionMenu, NUMBER_OF_SELECTION_OPERATORS, 
						menuItem+1, selectionOperators[menuItem].alias+1);		
}



void updateSamplingMenu(int menuItem)
	/*
	========================================
	:purpose
		update the sampling menu; 
		check the selected item(s)
	========================================
	*/
{
	operatorStructType *samplingOperators = getSamplingOperators();
	
	checkMenuItems(samplingMenu, NUMBER_OF_SAMPLING_OPERATORS, 
						menuItem+1, samplingOperators[menuItem].alias+1);		
}



void updateCrossoverMenu(int menuItem)
	/*
	========================================
	:purpose
		update the crossover menu; 
		check the selected item
	========================================
	*/
{
	operatorStructType *crossoverOperators = getCrossoverOperators();
	
	checkMenuItems(crossoverMenu, getNumberOfCrossoverOperators(), 
						menuItem+1, crossoverOperators[menuItem].alias+1);		
}




void updateMutationMenu(int menuItem)
	/*
	========================================
	:purpose
		update the mutation menu;
		check the selected item
	========================================
	*/
{
	operatorStructType *mutationOperators = getMutationOperators();
	
	checkMenuItems(mutationMenu, getNumberOfMutationOperators(), 
						menuItem+1, mutationOperators[menuItem].alias+1);		
}



void initGAMenus(void)
	/*
	========================================
		:purpose
			init the menus; enable and/or disable items at ground state
	========================================
	*/
{
	int i;
		
	/* init file menu */
	
	EnableItem (fileMenu, SaveParametersM);
	EnableItem (fileMenu, LoadParametersM);
	DisableItem(fileMenu, SaveStateM);
	DisableItem(fileMenu, LoadStateM);
	DisableItem(fileMenu, SaveSolutionsM);
	EnableItem(fileMenu, QuitM);
		
	/* init edit menu */
	
	for (i = 1; i <= NumberOfEditMenuOptions; i++)
		EnableItem(editMenu, i);
	DisableItem(editMenu, UndoM);
	
	/* init control menu */

	EnableItem(controlMenu, CreatePopulationM);
	EnableItem(controlMenu, RunM);
	EnableItem(controlMenu, ReinitializeM);
	
	SetItem(controlMenu, SetParametersM, "\pSet Control Parameters...");
	SetItem(controlMenu, RunM, "\pRun");
	
	/* init operators menu */

	initScalingMenu();
	initSharingMenu();
	initSelectionMenu();
	initSamplingMenu();
	initCrossoverMenu();
	initMutationMenu();
}



void checkMenuItems(MenuHandle theMenu, int n, int item, int alias)
	/*
	========================================
		:purpose
			check items within a menu
	========================================
	*/
{
	register int i;
	
	for(i = 1; i <= n; i++)
		CheckItem(theMenu, i, FALSE);
	CheckItem(theMenu, item, TRUE);
	if (alias > 0)
		CheckItem(theMenu, alias, TRUE);
}



void initScalingMenu(void)
	/*
	========================================
	:purpose
		initialize the scaling menu
	========================================
	*/
{
	int i;
	operatorStructType *scalingOperators = getScalingOperators();
	
	/* disable any non-available items */
	
	for(i = 0; i < NUMBER_OF_SCALING_OPERATORS; i++)
		if (!scalingOperators[i].available)
			DisableItem(scalingMenu, i+1);
			
	/* check the selected item */

	updateScalingMenu(getScalingOperatorId());
}



void initSharingMenu(void)
	/*
	========================================
	:purpose
		initialize the sharing menu
	========================================
	*/
{
	int i;
	operatorStructType *sharingOperators = getSharingOperators();
	
	/* disable any non-available items */
	
	for(i = 0; i < NUMBER_OF_SHARING_OPERATORS; i++)
		if (!sharingOperators[i].available)
			DisableItem(sharingMenu, i+1);
			
	/* check the selected item */

	updateSharingMenu(getSharingOperatorId());
}



void initSelectionMenu(void)
	/*
	========================================
	:purpose
		initialize the selection menu
	========================================
	*/
{
	int i;
	operatorStructType *selectionOperators = getSelectionOperators();
	
	/* disable any non-available items */
	
	for(i = 0; i < NUMBER_OF_SELECTION_OPERATORS; i++)
		if (!selectionOperators[i].available)
			DisableItem(selectionMenu, i+1);
			
	/* check the selected item */

	updateSelectionMenu(getSelectionOperatorId());
}



void initSamplingMenu(void)
	/*
	========================================
	:purpose
		initialize the sampling menu
	========================================
	*/
{
	int i;
	operatorStructType *samplingOperators = getSamplingOperators();
	
	/* disable any non-available items */
	
	for(i = 0; i < NUMBER_OF_SAMPLING_OPERATORS; i++)
		if (!samplingOperators[i].available)
			DisableItem(samplingMenu, i+1);
			
	/* check the selected item */

	updateSamplingMenu(getSamplingOperatorId());
}



void initCrossoverMenu(void)
	/*
	========================================
	:purpose
		initialize the crossover menu
	========================================
	*/
{
	int i;
	operatorStructType *crossoverOperators = getCrossoverOperators();
	
	/* disable any non-available items */
	
	for(i = 0; i < getNumberOfCrossoverOperators(); i++)
		if (!crossoverOperators[i].available)
			DisableItem(crossoverMenu, i+1);
		else
			EnableItem(crossoverMenu, i+1);
			
	/* check the selected item */

	updateCrossoverMenu(getCrossoverOperatorId());
}



void initMutationMenu(void)
	/*
	========================================
	:purpose
		initialize the mutation menu
	========================================
	*/
{
	int i;
	operatorStructType *mutationOperators = getMutationOperators();
	
	/* disable any non-available items */
	
	for(i = 0; i < getNumberOfMutationOperators(); i++)
		if (!mutationOperators[i].available)
			DisableItem(mutationMenu, i+1);
		else
			EnableItem(mutationMenu, i+1);
			
	/* check the selected item */

	updateMutationMenu(getMutationOperatorId());
}



void popUpOperatorMenu(MenuHandle theMenu, 
					   voidFunctionType setOperatorFunction,
					   int numberOfOperators,
					   int dialogItem,
					   int theItem)
	/*
	========================================
	:purpose
		draw a pop up menu to set a GA
		operator
	========================================
	*/
{
	long		theChoice;
	int			theOperator;
	Point		thePoint;
	int			type;
	Handle		item;
	Rect		theBox;
	Rect		labelRect;
	WindowPtr	oldPort;

	GetPort(&oldPort);
	SetPort(paramDialog);
	
	GetDItem(paramDialog, NumberOfParametersSText, &type, &item, &labelRect);
	GetDItem(paramDialog, dialogItem, &type, &item, &theBox);

	labelRect.top    = theBox.top;
	labelRect.right  = theBox.left;
	labelRect.bottom = theBox.bottom;
	InvertRect(&labelRect);
	
	thePoint.v = theBox.top;
	thePoint.h = theBox.left;
	LocalToGlobal(&thePoint);
	theChoice = PopUpMenuSelect(theMenu, thePoint.v, thePoint.h, theItem);
	InvertRect(&labelRect);

	theOperator = LoWord(theChoice)-1;
	if ((theOperator >= 0) && (theOperator < numberOfOperators))
		(*setOperatorFunction)(theOperator);
	else if ((theMenu == crossoverMenu) && (theOperator == numberOfOperators+1)) {
		enterCrossoverProbability();
		updateParamDialog();
	}
	else if ((theMenu == mutationMenu) && (theOperator == numberOfOperators+1)) {
		enterMutationProbability();
		updateParamDialog();
	}
	SetPort(oldPort);
}



void drawOperatorPopupMenu(MenuHandle theMenu, int theDialogItem, 
														char *operatorName)
{
	int			type;
	Handle		item;
	Rect		theRect;
	WindowPtr	oldPort;

	GetPort(&oldPort);
	SetPort(paramDialog);
	
	GetDItem(paramDialog, theDialogItem, &type, &item, &theRect);
	CalcMenuSize(theMenu);
	HLock(theMenu);
	theRect.right = theRect.left + (**theMenu).menuWidth;
	HUnlock(theMenu);
	EraseRect(&theRect);
	FrameRect(&theRect);
	MoveTo(theRect.left+1, theRect.bottom);
	LineTo(theRect.right, theRect.bottom);
	LineTo(theRect.right, theRect.top+1);
	MoveTo(theRect.left + 5, theRect.bottom - 4);
	CtoPstr(operatorName);
	DrawString(operatorName);
	PtoCstr(operatorName);
	
	SetPort(oldPort);
}
