/*
 ==============================================================================
 macWindow.c
 
 :written by

	steven e. bayer
	the mitre corporation

 :purpose
 
	this module is part of the macintosh interface for the GA tool; 
	it contains all functions that deal with windows
	
 :version 1.0; release date 03/01/91
 
 ==============================================================================
*/

/*
 ========================================
 include files
 ========================================
 */

#include "gaMain.h"
#include <string.h>

/*
 ========================================
 global functions headers
 
 these functions are available to any 
 other module; they are also externed
 in macWindow.h
 ========================================
 */

/* general functions */

void setUpWindows(void);
void doAboutWindow(void);
void openAllWindows(void);
void closeAllWindows(void);

/* application-specific functions */

void openTraceWindow(void);
void closeTraceWindow(void);
void updateTraceWindow(void);
void trace(int what);

void openFitnessWindow(void);
void closeFitnessWindow(void);
void updateFitnessWindow(void);

void openObjectiveWindow(void);
void closeObjectiveWindow(void);
void updateObjectiveWindow(void);

void openUserWindow(void);
void closeUserWindow(void);
void updateUserWindow(void);

/* user window functions */

void initDraw(void);
void titleWindow(char *);
void eraseWindow(void);
void drawLine(int, int, int, int);
void drawCircle(int, int, int, bool);
void printString(int, int, char *);
void printChar(int, int, char);

/*
 ========================================
 hidden functions headers

 these functions are known only to 
 this module
 ========================================
 */

/*
 ========================================
 external variables
 
 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

	/* menu stuff */

extern MenuHandle	appleMenu,
					fileMenu,
					editMenu,
					controlMenu,
					operatorsMenu,
						scalingMenu,
						sharingMenu,
						selectionMenu,
						samplingMenu,
						crossoverMenu,
						mutationMenu,
					windowMenu;

	/* dialog stuff */
	
extern DialogPtr	whichDialog,
					paramDialog,
					statsDialog;

extern DialogRecord	paramDialogR,
					statsDialogR;

/*
 ========================================
 global variables
 
 globals defined within this module
 ========================================
 */
 
	/* window stuff */

WindowPtr		theWindow,
				whichWindow,
				objectiveWindow,
				fitnessWindow,
				userWindow,
				traceWindow = (WindowPtr)NULL;

WindowRecord	objectiveWindowR,
				fitnessWindowR,
				userWindowR,
				traceWindowR;
				
char	*windowTitle = "User";				/* title for user window */

/*
 ========================================
 functions
 ========================================
 */

/* window functions */

void setUpWindows(void)
	/*
	========================================
	:purpose
		create and open all windows; this is really redundant with
		openAllWindows() now but not a big deal
	========================================
	*/
{
	openAllWindows();
}



void openAllWindows(void)
	/*
	========================================
	:purpose
		create and open all windows
	========================================
	*/
{
	if (!statsDialog)
		openStatisticsDialog();
	if (!objectiveWindow)
		openObjectiveWindow();
	if (!fitnessWindow)
		openFitnessWindow();
	if (!traceWindow) 
		openTraceWindow();
	if (!userWindow)
		openUserWindow();
}



	
void closeAllWindows(void)
	/*
	========================================
	:purpose
		close all windows
	========================================
	*/
{
	if (statsDialog)
		closeStatisticsDialog();
	if (objectiveWindow)
		closeObjectiveWindow();
	if (fitnessWindow)
		closeFitnessWindow();
	if (traceWindow)
		closeTraceWindow();
	if (userWindow)
		closeUserWindow();
}


#define MaxY	144
#define Width	MaxY/9
#define Height	Width
#define Step	Height
#define MinY	Step
#define Inc		2
#define Left	10
#define Right	(Left + Width - 2 * Inc)

char *traceStrings[9] = {	"\pEvaluate",		"\pCalculate Fitness", 
							"\pScale Fitness",	"\pShare Fitness",
							"\pReproduce",		"\pSelect Parents", 
							"\pSample Parents",	"\pCrossover", 
							"\pMutation"
						 };

int lastTrace;


void openTraceWindow(void)
	/*
	========================================
	:purpose
		create or select the trace window
	========================================
	*/
{
	if (traceWindow)
		SelectWindow(traceWindow);
	else {
		traceWindow = GetNewWindow(TraceWindow, &traceWindowR, (WindowPtr) -1);
		CheckItem(windowMenu, TraceWindowM, TRUE);
		lastTrace = 0;
	}
}



void closeTraceWindow(void)
	/*
	========================================
	:purpose
		close the trace window
	========================================
	*/
{
	if (traceWindow) {
		DisposeWindow(traceWindow);
		traceWindow = NULL;
		CheckItem(windowMenu, TraceWindowM, FALSE);
	}
}



void updateTraceWindow(void) 
	/*
	========================================
	:purpose
		display message in the trace window
	========================================
	*/
{
	int i, j;
	Rect theRect;
	WindowPtr oldPort;
	
	GetPort(&oldPort);
	SetPort(traceWindow);
	
	TextFont(systemFont);
	
	for (i = MinY, j = 0; i <= MaxY; i += Step, j++) {
		if ((j != EVALUATE) && (j != REPRODUCE)) {
			TextFace(0);
			SetRect(&theRect, Left, i-Step+Inc, Right, i-Inc);
			FrameRect(&theRect);
		}
		else
			TextFace(underline);
		MoveTo(Right + 10, i - 4);
		DrawString(traceStrings[j]);
	}
	trace(lastTrace);
	
	SetPort(oldPort);
}



void trace(int what)
	/*
	========================================
	:purpose
		give the user some notion of what
		the program is up to at any moment
	========================================
	*/
{
	WindowPtr	oldPort;
	Rect		theRect;
	
	if (traceWindow) {
		GetPort(&oldPort);
		SetPort(traceWindow);

		/* clear the set box last */
		
		if (lastTrace) {
			SetRect(&theRect, Left, MinY+lastTrace*Step-Step+Inc, 
										Right, MinY+lastTrace*Step-Inc);
			InsetRect(&theRect, 1, 1);
			EraseRect(&theRect);
		}

		/* fill the current trace */
		
		if (what) {
			SetRect(&theRect, Left, MinY+what*Step-Step+Inc, 
								Right, MinY+what*Step-Inc);
			FillRect(&theRect, black);
		}
		
		lastTrace = what;

		SetPort(oldPort);
	}
}



void openUserWindow(void)
	/*
	========================================
	:purpose
		create or select the user window
	========================================
	*/
{
	if (userWindow)
		SelectWindow(userWindow);
	else {
		userWindow = GetNewWindow(UserWindow, &userWindowR, (WindowPtr) -1);
		titleWindow(windowTitle);
		ShowWindow(userWindow);
		CheckItem(windowMenu, UserWindowM, TRUE);
	}
}


	
void closeUserWindow(void)
	/*
	========================================
	:purpose
		close the user window
	========================================
	*/
{
	if (userWindow) {							/* window is open */
		DisposeWindow(userWindow);
		userWindow = NULL;
		CheckItem(windowMenu, UserWindowM, FALSE);
	}
}	/* end showUserWindow() */




void updateUserWindow(void)
	/*
	========================================
	:purpose
		update the user window
	========================================
	*/
{
	chromosomeType	*bestChromosome;
	
	if (!userWindow)		/* window not open */
		return;

	if (bestChromosome = getBestChromosome()) {
		decodeChromosome(bestChromosome);
		onBestDo();
	}
}	/* end updateUserWindow() */



	
void openFitnessWindow(void)
	/*
	========================================
	:purpose
		create or select the normalized fitness window
	========================================
	*/
{
	if (fitnessWindow)
		SelectWindow(fitnessWindow);
	else {
		fitnessWindow = GetNewWindow(FitnessWindow, &fitnessWindowR, (WindowPtr) -1);
		ShowWindow(fitnessWindow);
		CheckItem(windowMenu, FitnessWindowM, TRUE);
	}
}



	
void closeFitnessWindow(void)
	/*
	========================================
	:purpose
		close the normalized fitness window
	========================================
	*/
{

	if (fitnessWindow) {						/* window is open */
		DisposeWindow(fitnessWindow);
		fitnessWindow = NULL;
		CheckItem(windowMenu, FitnessWindowM, FALSE);
	}
}




void updateFitnessWindow(void)
	/*
	========================================
	:purpose
		update the normalized fitness window
	========================================
	*/
{
	register float	*bins;
	register int	i, 
					step,
					gLeft,
					gTop,
					gRight,
					gBottom,
					xMax,
					yMax,
					xStep,
					yStep;
	Rect			myRect,
					gRect;
	char			*xAxisTitle,
					*yAxisTitle;
	FontInfo		info;
	WindowPtr		oldPort;
	
	static GrafPtr	hidePort = NULL;	/* used to draw off screen */
	static BitMap	hideBMap;
			
	if (!fitnessWindow)					/* window not open, don't draw */
		return;
	
	GetPort(&oldPort);
	SetPort(fitnessWindow);
	
/*	commenting out all hidden port code for now (crashes mac II)
	/* create the hidden port if it does not already exist
	
	if (!hidePort) {
		hidePort = (GrafPtr)NewPtr(sizeof(GrafPort));
		OpenPort(hidePort);
		hideBMap.baseAddr = NULL;
	}
	
	GetPort(&oldPort);
	SetPort(hidePort);			/* do all drawing in the hidden port

	/* create the bit map if it does not exist
	
	if (!hideBMap.baseAddr) {
		int bitMapSize; 
		
		hideBMap.rowBytes = fitnessWindow->portBits.rowBytes;
		hideBMap.bounds = fitnessWindow->portBits.bounds;
		bitMapSize = hideBMap.rowBytes * (hideBMap.bounds.bottom - hideBMap.bounds.top);
		hideBMap.baseAddr = NewPtr(bitMapSize);
		SetPortBits(&hideBMap);
	}
		
	/* make the hidden port look like the fitness window
	
	hidePort->portBits.rowBytes	= fitnessWindow->portBits.rowBytes;
	hidePort->portBits.bounds	= fitnessWindow->portBits.bounds;
	hidePort->portRect			= fitnessWindow->portRect;
*/
	/* erase the old graph */
		
	myRect = fitnessWindow->portRect;
	EraseRect(&myRect);
	
	/* set up the text characteristics */
		
	TextFont(geneva);
	TextSize(9);
	GetFontInfo(&info);
	
	gLeft	= myRect.left+StringWidth("\p00000");
	gTop	= myRect.top+20;
	gRight	= myRect.right-10;
	gBottom	= myRect.bottom-2*(info.ascent+info.descent);
	xMax	= gRight - gLeft;
	yMax	= gBottom - gTop;
	xStep	= xMax/10;
	yStep	= yMax/10;

	SetRect(&gRect, gLeft, gTop, gRight, gBottom); 

	/* draw the x and y axis */
		
	MoveTo(gLeft,  gTop);
	LineTo(gLeft,  gBottom);
	MoveTo(gLeft,  gBottom);
	LineTo(gRight, gBottom);

	/* draw the tick marks */
		
	for (i = gBottom; i >= gTop; i-= yStep) {
		MoveTo(gLeft, i);
		LineTo(gLeft-1, i);
	}
	for (i = gLeft; i <= gRight; i += xStep) {
		MoveTo(i, gBottom);
		LineTo(i, gBottom+1);
	}
	
	/* title the x axis */
		
	xAxisTitle = "Fitness";
	CtoPstr(xAxisTitle);
	MoveTo((gLeft+(gRight-gLeft)/2)-(StringWidth(xAxisTitle)/2),
								gBottom+info.ascent+info.descent+5);
	DrawString(xAxisTitle);
	PtoCstr(xAxisTitle);
	MoveTo(gLeft-8, gBottom+11);
	DrawChar('0');
	MoveTo(gRight-(CharWidth('1')/2), gBottom+11);
	DrawChar('1');
	
	/* title the y axis */
		
	yAxisTitle = "%n";
	CtoPstr(yAxisTitle);
	MoveTo(myRect.left+11, myRect.bottom/2+2);
	DrawString(yAxisTitle);
	PtoCstr(yAxisTitle);
	MoveTo(gLeft-StringWidth("\p100")-2, gTop+3);
	DrawString("\p100");

	/* draw the histogram */
		
	bins = getBins();

	for (i = 0, step = gLeft; i < 10; i++, step += xStep) {
		if (bins[i] > 0.0) {
			SetRect(&gRect, step, gBottom-(int)(bins[i] * yMax), 
							  step+xStep, gBottom);
			PaintRect(&gRect);
		}
	}
/*
	/* move the drawing to the screen
	
	CopyBits(&hidePort->portBits, &fitnessWindow->portBits, 
			 &hidePort->portRect, &fitnessWindow->portRect,
			 srcCopy, fitnessWindow->visRgn);
*/
	SetPort(oldPort);
}	/* end updateFitnessWindow() */




	
void openObjectiveWindow(void)
	/*
	========================================
	:purpose
		create or select the objective window
	========================================
	*/
{
	if (objectiveWindow)
		SelectWindow(objectiveWindow);
	else {
		objectiveWindow = GetNewWindow(ObjectiveWindow, &objectiveWindowR, (WindowPtr) -1);
		ShowWindow(objectiveWindow);
		CheckItem(windowMenu, ObjectiveWindowM, TRUE);
	}
}



	
void closeObjectiveWindow(void)
	/*
	========================================
	:purpose
		close the objective window
	========================================
	*/
{

	if (objectiveWindow) {			/* window is open */
		DisposeWindow(objectiveWindow);
		objectiveWindow = NULL;
		CheckItem(windowMenu, ObjectiveWindowM, FALSE);
	}
}




void updateObjectiveWindow(void)
	/*
	========================================
	:purpose
		update the objective window
	========================================
	*/
{
	register mainStatsStructType *stats;
	register int		i, 
						gLeft,
						gTop,
						gRight,
						gBottom,
						xMax,
						yMax,
						yStep,
						iStep,
						iStep2,
						bestEver[2],
						best[2],
						worst[2],
						average[2];
	float				xStep,
						xScale,
						step;
	Rect				myRect;
	char			   *xAxisTitle,
					   *yAxisTitle,
					   *xAxisLabel,
					   *yAxisLabel;
	unsigned			generationNumber;
	float				yMaxValue,
						yScale;
	FontInfo			info;
	WindowPtr			oldPort;
	
	static GrafPtr	hidePort = NULL;	/* used to draw off screen */
	static BitMap	hideBMap;
			
	if (!objectiveWindow)				/* window not open, don't draw */
		return;
	
	generationNumber = getGenerationNumber();
	
	stats = getStats();

	GetPort(&oldPort);
	SetPort(objectiveWindow);

/* commenting out all hidden port code for now (crashes mac II)
	/* create the hidden port if it does not already exist
	
	if (!hidePort) {
		hidePort = (GrafPtr)NewPtr(sizeof(GrafPort));
		OpenPort(hidePort);
		hideBMap.baseAddr = NULL;
	}
	
	GetPort(&oldPort);
	SetPort(hidePort);			/* do all drawing in the hidden port

	/* create the bit map if it does not exist
	
	if (!hideBMap.baseAddr) {
		int bitMapSize; 
		
		hideBMap.rowBytes = objectiveWindow->portBits.rowBytes;
		hideBMap.bounds = objectiveWindow->portBits.bounds;
		bitMapSize = hideBMap.rowBytes * (hideBMap.bounds.bottom - hideBMap.bounds.top);
		hideBMap.baseAddr = NewPtr(bitMapSize);
		SetPortBits(&hideBMap);
	}
		
	/* make the hidden port look like the objective window
	
	hidePort->portBits.rowBytes	= objectiveWindow->portBits.rowBytes;
	hidePort->portBits.bounds	= objectiveWindow->portBits.bounds;
	hidePort->portRect			= objectiveWindow->portRect;
*/

	if ((generationNumber = getGenerationNumber()) >= MAX_STAT)
		return; /* temporary kludge due to saving only the first 200 points */
	
	myRect = objectiveWindow->portRect;
	EraseRect(&myRect);
	
	/* set up the text characteristics */
		
	TextFont(geneva);
	TextSize(9);
	GetFontInfo(&info);
	
	gLeft	= myRect.left+StringWidth("\p0000000");
	gTop	= myRect.top+20;
	gRight	= myRect.right-10;
	gBottom	= myRect.bottom-2*(info.ascent+info.descent);
	xMax	= gRight - gLeft;
	yMax	= gBottom - gTop;
	xStep	= (float)xMax/9.0;
	yStep	= yMax/10;

	/* draw the x and y axis */

	MoveTo(gLeft,  gTop);
	LineTo(gLeft,  gBottom);
	MoveTo(gLeft,  gBottom);
	LineTo(gRight, gBottom);

	/* draw the tick marks */
		
	for (i = gBottom; i >= gTop; i -= yStep) {
		MoveTo(gLeft, i);
		LineTo(gLeft-1, i);
	}
	for (step = gLeft; step <= (float)gRight; step += xStep) {
		iStep = (int)step;
		MoveTo(iStep, gBottom);
		LineTo(iStep, gBottom+1);
	}
	
	if ((yMaxValue = getBestValue()) < getWorstValue())
		yMaxValue = getWorstValue();
	
	if (yMaxValue > 0.0)
		yScale = yMax/yMaxValue;
	
	xScale = (float)(((generationNumber/10) + 
					((generationNumber % 10) > 0)) * 10);
	if (xScale < 10.0)
		xScale = 10.0;
	xStep  = xMax/(xScale-stats->firstGenerationPtr-1.0);

	xAxisLabel = yAxisLabel = "      ";

	/* label the x axis */

	xAxisTitle = "Generation Number";
	CtoPstr(xAxisTitle);
	MoveTo((gLeft+(gRight-gLeft)/2)-(StringWidth(xAxisTitle)/2),
								gBottom+info.ascent+info.descent+5);
	DrawString(xAxisTitle);
	PtoCstr(xAxisTitle);

	sprintf(xAxisLabel, "%3.0f", xScale);
	CtoPstr(xAxisLabel);
	MoveTo(gRight-StringWidth(xAxisLabel), gBottom+11);
	DrawString(xAxisLabel);
	PtoCstr(xAxisLabel);
	
	/* reuse the xAxisLabel string to print the generation number */
	
	sprintf(xAxisLabel, "%d", stats->firstGenerationPtr+1);
	CtoPstr(xAxisLabel);
	MoveTo(gLeft, gBottom+11);
	DrawString(xAxisLabel);
	PtoCstr(xAxisLabel);
	
	/* label the y axis */

	yAxisTitle = "f(x)";
	CtoPstr(yAxisTitle);
	MoveTo(gLeft-(StringWidth(yAxisTitle))-6, myRect.bottom/2+2);
	DrawString(yAxisTitle);
	PtoCstr(yAxisTitle);
	sprintf(yAxisLabel, "%.0f", yMaxValue);
	CtoPstr(yAxisLabel);
	MoveTo(gLeft-StringWidth(yAxisLabel)-2, gTop+3);
	DrawString(yAxisLabel);
	PtoCstr(yAxisLabel);
	MoveTo(gLeft-8, gBottom+5);
	DrawChar('0');

	if (generationNumber != 0) {
		int start, stop;

		start = stats->firstGenerationPtr % MAX_STAT;
		stop  = stats->movingPtr % MAX_STAT;

		/* draw the stripchart */
		
		bestEver[0]	= gBottom-(int)(stats->data[start].bestEver * yScale);
		best[0] 	= gBottom-(int)(stats->data[start].best	   * yScale);
		average[0]	= gBottom-(int)(stats->data[start].average  * yScale);
		worst[0]	= gBottom-(int)(stats->data[start].worst    * yScale);
		
		for (i = start+1, step = gLeft; (i % MAX_STAT) != stop; 
													i++, step += xStep) {
			bestEver[1]	= gBottom-(int)(stats->data[i%MAX_STAT].bestEver 
																* yScale);
			best[1] 	= gBottom-(int)(stats->data[i%MAX_STAT].best 
																* yScale);
			worst[1]	= gBottom-(int)(stats->data[i%MAX_STAT].worst 
																* yScale);
			average[1]	= gBottom-(int)(stats->data[i%MAX_STAT].average 
																* yScale);	
			iStep  = (int)step;
			iStep2 = (int)(step+xStep);
			MoveTo(iStep,  bestEver[0]);
			LineTo(iStep2, bestEver[1]);
			MoveTo(iStep,  best[0]);
			LineTo(iStep2, best[1]);
			MoveTo(iStep,  average[0]);
			LineTo(iStep2, average[1]);
			MoveTo(iStep,  worst[0]);
			LineTo(iStep2, worst[1]);
			bestEver[0]	= bestEver[1];
			best[0] 	= best[1];
			average[0]	= average[1];
			worst[0]	= worst[1];
		}
	}
/*	
	/* move the drawing to the screen
	
	CopyBits(&hidePort->portBits, &objectiveWindow->portBits, 
			 &hidePort->portRect, &objectiveWindow->portRect,
			 srcCopy, objectiveWindow->visRgn);
*/
	SetPort(oldPort);
}	/* end updateObjectiveWindow() */



	
void doAboutWindow(void)
	/*
	========================================
	:purpose
		display the about window
	========================================
	*/
{
	Rect			aboutRect;
	Rect			lineRect;
	GrafPtr			port;
	WindowPtr		aboutWindow;
	EventRecord		anEvent;
	char		   *line[5];
	int				i;

	line[0] = "splicer: a genetic algorithm tool";
	line[1] = "written by steve bayer";
	line[2] = "the mitre corporation";
	line[3] = "nasa johnson space center";
	line[4] = "software technology branch";
	
	GetPort(&port);
	SetRect(&lineRect, 5, 5, 345, 20);
	SetRect(&aboutRect, 75, 50, 425, 160);
	aboutWindow = NewWindow((WindowPeek) NULL, &aboutRect, "\1x", 0xff, 
			altDBoxProc, (WindowPtr) -1L, 0xff, 0);
	SetPort(aboutWindow);
	
	TextSize(12);
	TextFont(0);
	
	for (i = 0; i < 5; i++) {
		TextBox(line[i], strlen(line[i]), &lineRect, 1);
		OffsetRect(&lineRect, 0, 20);
	}

	do {
		GetNextEvent(everyEvent, &anEvent);
	} while (anEvent.what != mouseDown);
	
	DisposeWindow(aboutWindow);
	
	SetPort(port);
}


#define NumChars 40
#define NumLines 20

void doAboutApplicationWindow()
	/*
	========================================
	:purpose
		display information about the 
		current application
	========================================
	*/
{
}




/* user window functions */

Rect	userRect,	/* global variables for the user window functions */
		tmpRect;
		

void initDraw(void)
	/*
	========================================
	:purpose
		initialize drawing in the user window
	========================================
	*/
{
	SetRect(&userRect, 0, 0, 300, 200);
	eraseWindow();
}



void titleWindow(char *string)
	/*
	========================================
	:purpose
		give the user window a new title
	========================================
	*/
{
	windowTitle = string;					/* save the user's title */
	
	if (!userWindow)
		return;
	SetWTitle(userWindow, CtoPstr(string));
	SetItem(windowMenu, UserWindowM, string);
	PtoCstr(string);
}



void eraseWindow(void)
	/*
	========================================
	:purpose
		erase the contents of the user window
	========================================
	*/
{
	if (!userWindow)
		return;
	GetPort(theWindow);
	SetPort(userWindow);
	EraseRect(&userRect);
	SetPort(theWindow);
}	



void drawLine(int x1, int y1, int x2, int y2)
	/*
	========================================
	:purpose
		draw a line within the user window
	========================================
	*/
{
	if (!userWindow)
		return;
	GetPort(theWindow);
	SetPort(userWindow);
	MoveTo(x1, y1);
	LineTo(x2, y2);
	SetPort(theWindow);
}



void drawCircle(int x, int y, int width, bool fill)
	/*
	========================================
	:purpose
		draw a circle (possibly filled) within the user window
	========================================
	*/
{
	if (!userWindow)
		return;
	GetPort(theWindow);
	SetPort(userWindow);
	MoveTo(x,y);
	SetRect(&tmpRect, x-width, y-width, x+width, y+width);
	if (fill)
		FillOval(&tmpRect, black);
	else
		FrameOval(&tmpRect);
	SetPort(theWindow);
}



void printString(int x, int y, char *string)
	/*
	========================================
	:purpose
		print a string of characters within the user window
	========================================
	*/
{
	if (!userWindow)
		return;
	GetPort(theWindow);
	SetPort(userWindow);
	MoveTo(x,y);
	CtoPstr(string);
	DrawString(string);
	PtoCstr(string);
	SetPort(theWindow);
}



void printChar(int x, int y, char c)
	/*
	========================================
	:purpose
		print a character within the user window
	========================================
	*/
{
	if (!userWindow)
		return;
	GetPort(theWindow);
	SetPort(userWindow);
	MoveTo(x,y);
	DrawChar(c);
	SetPort(theWindow);
}

