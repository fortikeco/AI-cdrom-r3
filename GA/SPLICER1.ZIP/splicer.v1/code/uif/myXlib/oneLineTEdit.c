#include <stdio.h>
#include "myXlib.h"

#include <ctype.h>

#if MOTIF
#   include <Xm/Xm.h>
#endif

#if HPW
#   include <Xw/Xw.h>
#   include <Xw/TextEdit.h>
#endif

/****************************************************************************/
/*
    associate the action "beep" with the function beep()
*/

static XtActionsRec actionsTable[] = {
    { "beep", beep },
};

/*
    override all translations that enter a newline
*/

static char defaultTranslations[] =
    "Ctrl<Key>J:        beep() \n\
     Ctrl<Key>O:        beep() \n\
     Ctrl<Key>N:        beep() \n\
     <Key> Return:      beep()";

Widget createOneLineTextEditWidget(name, parent, args, nArgs)
 char   *name;
 Widget parent;
 Arg    args[];
 int    nArgs;
{
    XFontStruct     *font;
    Widget          w;
    Arg             wargs[1];
    XtTranslations  transTable;

    /*
        add the actions and compile the table
    */
    XtAddActions(actionsTable, XtNumber(actionsTable));
    transTable = XtParseTranslationTable(defaultTranslations);

    /*
        create a textedit widget
    */
#	if HPW
    w = XtCreateManagedWidget(name, XwtexteditWidgetClass, parent, args, nArgs);
#	endif

    /*
        install the translations
    */
    XtOverrideTranslations(w, transTable);

    /*
        get the font used by the widget
    */
    XtSetArg(wargs[0], XtNfont, &font);
    XtGetValues(w, wargs, 1);

    /*
        set the widget height according to the font height
    */
    XtSetArg(wargs[0], XtNheight, fontHeight(font) + 6);
    XtSetValues(w, wargs, 1);

    return(w);
}



