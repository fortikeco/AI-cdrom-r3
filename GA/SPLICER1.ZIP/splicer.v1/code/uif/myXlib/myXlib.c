#include <stdio.h>
#include "myXlib.h"

#include <ctype.h>

#if MOTIF
#	include <Xm/Xm.h>
#endif

#if HPW
#	include <Xw/Xw.h>
#endif

/****************************************************************************/
/*
    make a class name for the application
*/
char *makeClassName(str1, str2)
 char *str1, *str2;
{
    strcpy(str2, str1);
    if (islower(str2[0]))
		str2[0] = toupper(str2[0]);
	if (str2[0] == 'X')
		if (islower(str2[1]))
			str2[1] = toupper(str2[1]);
    return(str2);
}



/****************************************************************************/
/*
    name a window and its icon
*/
void nameWindow(w, name)
 Widget w;
 char   *name;
{
    XStoreName(XtDisplay(w), XtWindow(w), name);
    XSetIconName(XtDisplay(w), XtWindow(w), name);
}



/****************************************************************************/
/*
    ring the terminal bell
*/

void beep(w, event, params, nParams)
 Widget w;
 XEvent *event;
 String *params;
 int    nParams;
{
    XBell(XtDisplay(w), 100);
}



/****************************************************************************/
/*
   set the value of a static text field
*/
void setTextField(textWidget, textString)
 Widget textWidget;
 char   *textString;
{
    Arg warg[1];

    XtSetArg(warg[0], XtNstring, textString);
    XtSetValues(textWidget, warg, 1);
}

