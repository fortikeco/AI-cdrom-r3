#include <stdio.h>
#include "myXlib.h"

#include <ctype.h>

#include <X11/Shell.h>

#if MOTIF
#   include <Xm/Xm.h>
#   include <Xm/Separator.h>
#   include <Xm/PushB.h>
#   include <Xm/CascadeB.h>
#   include <Xm/RowColumn.h>
#   include <Xm/Label.h>
#   include <Xm/BulletinB.h>
#endif

#if HPW
#   include <Xw/Xw.h>
#	include <Xw/MenuSep.h>
#	include <Xw/MenuBtn.h>
#	include <Xw/Cascade.h>
#	include <Xw/PopupMgr.h>
#	include <Xw/RCManager.h>
#endif


/****************************************************************************/
/*
    create a popUp menu
*/
#if MOTIF
void createMenuButtons(title, menu, menuList, nItems)
 char           *title;
 Widget         menu;
 myMenuStruct   *menuList;
 int            nItems;
{
    Arg         wargs[1];
    int         i;
    WidgetList  buttons;
    int         separators = 0;

    /*
        allocate a widget list to hold all button widgets
    */
    buttons = (WidgetList) XtMalloc(nItems * sizeof(Widget));

    /*
        if a title is given, create label and separator widgets
    */
    if (title) {
        XtCreateManagedWidget(title, xmLabelWidgetClass, menu, NULL, 0);
        XtCreateManagedWidget("separator", xmSeparatorWidgetClass, menu,NULL,0);
    }

    /*
        create an entry for each item in the menu
    */
    for (i = 0; i < nItems; i++) {
        /*
            a NULL name represents a separator
        */
        if (menuList[i].name == NULL) {
            XtCreateManagedWidget("separator", xmSeparatorWidgetClass, menu,
                                  NULL, 0);
        separators++;   /* count how many entries are not buttons */
        }

        /*
            if there is a name and a callback, create a selectable menu
            entry and register the callback function
        */
        else if (menuList[i].func) {
            buttons[i-separators] = XtCreateWidget(menuList[i].name,
                               			xmPushButtonWidgetClass, menu, NULL, 0);
            XtAddCallback(buttons[i-separators], XmNactivateCallback,
                                        menuList[i].func, menuList[i].data);
        }

        /*
            if there is a name, but no callback function, the entry
            must be a label, unless there is a submenu
        */
        else if (!menuList[i].subMenu) {
            buttons[i-separators] = XtCreateWidget(menuList[i].name,
                                            xmLabelWidgetClass, menu, NULL, 0);
        /*
            if we got here, the entry must be a submenu.
            create a pulldown menu pane and an XmCascadeButton widget.
            attach the menu pane and make a recursive call to create the entries
            in the submenu.
        */
        }
        else {
            Widget subMenu;
            subMenu = XmCreatePulldownMenu(menu, menuList[i].subMenuTitle,
                                                                        NULL,0);
            XtSetArg(wargs[0], XmNsubMenuId, subMenu);
            buttons[i-separators] = XtCreateWidget(menuList[i].name,
                                xmCascadeButtonWidgetClass, menu, wargs, 1);
            createMenuButtons(menuList[i].subMenuTitle, subMenu,
                                menuList[i].subMenu, menuList[i].nSubItems);
       }
    }
    /*
    manage all button widgets; menu panes are not mangaged.
    */
    XtManageChildren(buttons, nItems - separators);
}
#endif


/****************************************************************************/
#if HPW
Widget createMenuManager(parent, mgrName)
 Widget parent;
 char	*mgrName;
{
	Widget	shell,
			menuMgr;

	shell = XtCreatePopupShell(mgrName, shellWidgetClass, parent, NULL, 0);

	menuMgr = XtCreateManagedWidget(mgrName, XwpopupmgrWidgetClass, shell, 
																	NULL, 0);
	return(menuMgr);
}
#	endif


/****************************************************************************/
#if HPW
WidgetList createMenuPane(manager, mgrName, name, menuList, nItems, menuPane,
	paneShell)
 Widget 		manager;
 char			*mgrName, 
				*name;
 myMenuStruct	*menuList;
 int			nItems;
 Widget			*menuPane;
 Widget			*paneShell;
{
	WidgetList	buttons;
	Arg			wargs[1];
	int			i;

	/*
		allocate a widget list to hold all button widgets
	*/
	buttons = (WidgetList) XtMalloc(nItems * sizeof(Widget));

	/*
		create a popup shell to hold the pane
	*/
	*paneShell = XtCreatePopupShell("paneShell", shellWidgetClass, manager,
														NULL, 0);

	/*
		create a cascade menu pane and attach it to the given manager
		widget
	*/
	XtSetArg(wargs[0], XtNattachTo, (XtArgVal) mgrName);
	*menuPane = XtCreateManagedWidget (name, XwcascadeWidgetClass, *paneShell,
														wargs, 1);

	/*
		create a menu button for each item in the menu
	*/
	for (i = 0; i < nItems; i++) {
		/*
			if we have a name, create the menu button
		*/
		if (menuList[i].name) {	
			buttons[i] = XtCreateWidget(menuList[i].name, 
							XwmenubuttonWidgetClass, *menuPane, NULL, 0);
			/*
				if we have a function, create the callback
			*/
			if (menuList[i].func) {
				XtAddCallback(buttons[i], XtNselect, menuList[i].func,
											menuList[i].data);
			}
		}
		else {	/* null name means create a separator */
			buttons[i] = XtCreateWidget("separator", XwmenuSepWidgetClass,
							*menuPane, NULL, 0);
		}
	}
	/*
		manage all button widgets
	*/
	XtManageChildren(buttons, nItems);
	return(buttons);
}
#endif


/****************************************************************************/
/*
	check a menu item
*/
void checkMenuItem(w, flag)
 Widget	w;
 bool	flag;
{
	Arg wargs[1];
	
	XtSetArg(wargs[0], XtNsetMark, flag);
	XtSetValues(w, wargs, 1);
}

