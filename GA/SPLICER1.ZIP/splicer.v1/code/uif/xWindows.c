/*
 ==============================================================================
 xWindows.c

 :written by

    steven e. bayer
    the mitre corporation

 :purpose

    this module contains all the code for creating and accessing 
	windows for the X Window System interface for the GA tool

 :version 1.0; release date 03/01/91

 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"

#include "myXlib.h"

#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>

#if MOTIF
#	include <Xm/Xm.h>
#	include <Xm/MainW.h>
#endif

#if HPW
#	include <Xw/Xw.h>
#	include <Xw/WorkSpace.h>
#	include <Xw/RCManager.h>
#	include <Xw/SText.h>
#	include <Xw/PButton.h>
#	include <Xw/SRaster.h>
#endif

/*
 ========================================
 global functions headers

 these functions are available to any
 other module; they are externed in
 xWindows.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to
 this module
 ========================================
 */

void updateFitnessWindowCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void updateObjectiveWindowCB(
#   if useFunctionPrototypes
	Widget, caddr_t, caddr_t
#   endif
);

void setUpStatisticsWindow(
#   if useFunctionPrototypes
    void
#   endif
);

void setUpTraceWindow(
#   if useFunctionPrototypes
    void
#   endif
);

void updateUserWindowCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void createGC(
#   if useFunctionPrototypes
 	GC, Widget
#   endif
);


/*
 ========================================
 external variables

 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables

 globals defined within this module
 ========================================
 */

Widget	userWindowTopLevel,
        fitnessWindowTopLevel,
        objectiveWindowTopLevel,
		statisticsWindowTopLevel,
        traceWindowTopLevel;

Widget	userWindow,
		fitnessWindow,
		objectiveWindow,
		statisticsWindow,
		traceWindow;
 
XGCValues	gcValues;

/*
 ========================================
 functions
 ========================================
 */

void setUpWindows()
    /*
    ========================================
    :purpose
        set up all windows
    ========================================
    */
{
	/*
		create the various window widgets
	*/
#	if MOTIF
#	define WIDGETCLASS1 xmMainWindowWidgetClass
#	endif

#	if HPW
#	define WIDGETCLASS1 XwworkSpaceWidgetClass 
#	define WIDGETCLASS2 XwrowColWidgetClass
#	endif

	statisticsWindow	= XtCreateManagedWidget("statisticsWindow", 
												WIDGETCLASS2,
												statisticsWindowTopLevel,
												NULL, 0);
	setUpStatisticsWindow();
 
	objectiveWindow		= XtCreateManagedWidget("objectiveWindow", 
												WIDGETCLASS1,
												objectiveWindowTopLevel,
												NULL, 0);

	fitnessWindow		= XtCreateManagedWidget("fitnessWindow",
												WIDGETCLASS1,
												fitnessWindowTopLevel,
												NULL, 0);

	userWindow			= XtCreateManagedWidget("userWindow",
												WIDGETCLASS1,
												userWindowTopLevel,
												NULL, 0);

	traceWindow			= XtCreateManagedWidget("traceWindow", 
												WIDGETCLASS2,
												traceWindowTopLevel,
												NULL, 0);
	setUpTraceWindow();
}
#undef WIDGETCLASS1
#undef WIDGETCLASS2



/***************************************************************************
	fitness window stuff
*/
GC		fitnessGC;

void createFitnessWindowGC()
    /*
    ========================================
    :purpose
        create the graphics context for the 
		fitness window
    ========================================
    */
{
	createGC(&fitnessGC, fitnessWindow);
}



void updateFitnessWindowCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        update the information in the 
        fitness window
    ========================================
    */
 Widget		w;
 caddr_t	clientData;
 caddr_t	callData;
{
	updateFitnessWindow();
}



void addFitnessWindowCallbacks() {
    /*
    ========================================
    :purpose
        attach any callbacks to the 
        fitness window
    ========================================
    */
	XtAddCallback(fitnessWindow, XtNexpose, updateFitnessWindowCB, NULL);
}



void updateFitnessWindow()
    /*
    ========================================
    :purpose
        update the fitness window
    ========================================
    */
{
	register float	*bins;
	register int	i,
					step,
                    gLeft,
                    gTop,
                    gRight,
                    gBottom,
                    xMax,
                    yMax,
                    xStep,
                    yStep;
    char            *xAxisTitle,
                    *yAxisTitle;
	Arg				wargs[2];
	Cardinal		n = 0;
	Dimension		width;
	Dimension		height;
	Display			*display = XtDisplay(fitnessWindow);
	Window			window   = XtWindow(fitnessWindow);
	XFontStruct		*font;
	XGCValues		theValues;

    if (!isWindowOpen(fitnessWindow))	/* window not open, don't draw */
        return;

    /* erase the old graph */

	XClearWindow(display, window);

	/* get the current window size */
	
	n = 0;
	XtSetArg(wargs[n], XtNwidth,  &width);  n++;
	XtSetArg(wargs[n], XtNheight, &height); n++;
	XtGetValues(fitnessWindow, wargs, n);

/*	get the current font info 

	XGetGCValues(display, fitnessGC, GCFont, &theValues);

	font = XQueryFont(display, theValues.font);
	if (font == NULL)
		puts("bad font");

	gLeft   = XTextWidth(font, "00000", strlen("00000"));
*/
	gLeft	= 40;
    gTop    = 20;
    gRight  = width-10;
    /* gBottom = height-2*(fontHeight(font)); */
    gBottom = height-30;

    xMax    = gRight - gLeft;
    yMax    = gBottom - gTop;
    xStep   = xMax/10;
    yStep   = yMax/10;

    /* draw the x and y axis */
	XDrawLine(display, window, fitnessGC, gLeft, gTop, gLeft, gBottom);
	XDrawLine(display, window, fitnessGC, gLeft, gBottom, gRight, gBottom);

    /* draw the tick marks */ 

    for (i = gBottom; i >= gTop; i-= yStep) {
		XDrawLine(display, window, fitnessGC, gLeft-1, i, gLeft-2, i);
    } for (i = gLeft; i <= gRight; i += xStep) {
		XDrawLine(display, window, fitnessGC, i, gBottom, i, gBottom+1);
    }

    /* title the x axis */ 

    xAxisTitle = "Fitness";
	XDrawString(display, window, fitnessGC, 
					/*  ((gLeft+(gRight-gLeft)/2)-(StringWidth(xAxisTitle)/2) */
    					((gLeft+(gRight-gLeft)/2)-28),
					/*  (gBottom+fontheight(font)+5) */
                        (gBottom+20),
						xAxisTitle, strlen(xAxisTitle));

	XDrawString(display, window, fitnessGC, gLeft-8, gBottom+11, "0", 1); 
	XDrawString(display, window, fitnessGC, 
					/*  (gRight-(CharWidth('1')/2), (gBottom+11), "1", 1); */ 
						(gRight-4), (gBottom+11), "1", 1); 

    /* title the y axis */

    yAxisTitle = "%n";
	XDrawString(display, window, fitnessGC, 11, height/2+2, 
										yAxisTitle, strlen(yAxisTitle));
    XDrawString(display, window, fitnessGC,
					/*  (gLeft-StringWidth("100")-2)  */
                        (gLeft-22), (gTop+3), "100", 3);

    /* draw the histogram */

    bins = getBins();

    for (i = 0, step = gLeft; i < 10; i++, step += xStep) {
        if (bins[i] > 0.0) {
			XFillRectangle(display, window, fitnessGC, 
								step,  (gBottom-(int)(bins[i] * yMax)), 
                              	xStep, (int)(bins[i] * yMax));
        }
    }
}   /* end updateFitnessWindow() */


 


/***************************************************************************
	objective window stuff
*/
GC	objectiveGC;

void createObjectiveWindowGC()
    /*
    ========================================
    :purpose
		create the graphics context for the
		objective window
    ========================================
    */
{
	createGC(&objectiveGC, objectiveWindow);
}



void updateObjectiveWindowCB(w, clientData, callData)
    /*
    ========================================
    :purpose
		update the objective window whenever
		it is exposed
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
    updateObjectiveWindow();
}



void addObjectiveWindowCallbacks()
    /*
    ========================================
    :purpose
        attach any callbacks to the 
		objective window
    ========================================
    */
{
    XtAddCallback(objectiveWindow, XtNexpose, updateObjectiveWindowCB, NULL);
}



void updateObjectiveWindow()
    /*
    ========================================
    :purpose
		update the objective window
    ========================================
    */
{
    register mainStatsStructType *stats;
    register int        i,
                        gLeft,
                        gTop,
                        gRight,
                        gBottom,
                        xMax,
                        yMax,
                        yStep,
                        iStep,
                        iStep2,
                        bestEver[2],
                        best[2],
                        worst[2],
                        average[2];
    float               xStep,
                        xScale,
                        step;
    char               *xAxisTitle,
                       *yAxisTitle,
                       *xAxisLabel,
                       *yAxisLabel;
    unsigned            generationNumber;
    float               yMaxValue,
                        yScale;
	Arg					wargs[2];
	Cardinal			n = 0;
	Dimension			width,
						height;
    Display				*display = XtDisplay(objectiveWindow);
    Window				window   = XtWindow(objectiveWindow);
/*  XFontStruct 	    *font;     */
/*  XGCValues      		theValues; */

    if (!isWindowOpen(objectiveWindow))		/* window not open, don't draw */
        return;

    generationNumber = getGenerationNumber();

	stats = getStats();

    /* erase the old graph */

    XClearWindow(display, window);

    /* get the current window size */

	n = 0;
    XtSetArg(wargs[n], XtNwidth,  &width);  n++;
    XtSetArg(wargs[n], XtNheight, &height); n++;
    XtGetValues(objectiveWindow, wargs, n);

/* set up the text characteristics 

    XGetGCValues(display, fitnessGC, GCFont, &theValues);

    font = XQueryFont(display, theValues.font);
    if (font == NULL)
        puts("bad font");

    gLeft   = XTextWidth(font, "0000000", strlen("0000000"));
*/
	gLeft	= (7*strlen("0000000"));
    gTop    = 20;
    gRight  = width-10;
/*  gBottom = height-2*(fontHeight(font)); */
	gBottom = height-30;

    xMax    = gRight - gLeft;
    yMax    = gBottom - gTop;
    xStep   = (float)xMax/9.0;
    yStep   = yMax/10;

    /* draw the x and y axis */

    XDrawLine(display, window, fitnessGC, gLeft, gTop, gLeft, gBottom);
    XDrawLine(display, window, fitnessGC, gLeft, gBottom, gRight, gBottom);

    /* draw the tick marks */

    for (i = gBottom; i >= gTop; i -= yStep) {
        XDrawLine(display, window, fitnessGC, gLeft-1, i, gLeft-2, i);
    }
    for (step = gLeft; step <= (float)gRight; step += xStep) {
        iStep = (int)step;
        XDrawLine(display, window, fitnessGC, iStep, gBottom, iStep, gBottom+1);
    }

    if ((yMaxValue = getBestValue()) < getWorstValue())
        yMaxValue = getWorstValue();

    if (yMaxValue > 0.0)
        yScale = yMax/yMaxValue;

    xScale = (float)(((generationNumber/10) + 
					((generationNumber % 10) > 0)) * 10);
    if (xScale < 10.0)
        xScale = 10.0;
	xStep = xMax/(xScale-stats->firstGenerationPtr-1.0);

    xAxisLabel = yAxisLabel = "      ";

    /* label the x axis */

    xAxisTitle = "Generation Number";
    XDrawString(display, window, fitnessGC,
                    /*  ((gLeft+(gRight-gLeft)/2)-(StringWidth(xAxisTitle)/2) */
                        ((gLeft+(gRight-gLeft)/2)-(7*strlen(xAxisTitle)/2)+5),
                    /*  (gBottom+fontheight(font)+5) */
                        (gBottom+20),
                        xAxisTitle, strlen(xAxisTitle));

    sprintf(xAxisLabel, "%3.0f", xScale);
    XDrawString(display, window, fitnessGC,
                    /*  (gRight-StringWidth(xAxisLabel), gBottom+11), */
                        (gRight-(7*strlen(xAxisLabel)/2)), (gBottom+11), 
						xAxisLabel, strlen(xAxisLabel));

	/* reuse the xAxisLabel string to print the generation number */

	sprintf(xAxisLabel, "%d", stats->firstGenerationPtr+1);
    XDrawString(display, window, fitnessGC, gLeft, gBottom+11, 
											xAxisLabel, strlen(xAxisLabel));
   
	/* label the y axis */

    yAxisTitle = "f(x)";
    XDrawString(display, window, fitnessGC, 11, height/2+2,
                                        yAxisTitle, strlen(yAxisTitle));

    sprintf(yAxisLabel, "%.0f", yMaxValue);
    XDrawString(display, window, fitnessGC,
                    /*  (gLeft-StringWidth(yAxisLabel)-2)  */
                        (gLeft-(7*strlen(yAxisLabel))-1), (gTop+3), 
						yAxisLabel, strlen(yAxisLabel));

    XDrawString(display, window, fitnessGC,
                        (gLeft-8), gBottom, "0", 1);

    if (generationNumber != 0) {
		int start, stop;
	
		start = stats->firstGenerationPtr % MAX_STAT;
		stop  = stats->movingPtr % MAX_STAT;

        /* draw the stripchart */

        bestEver[0] = gBottom - (int)(stats->data[start].bestEver * yScale);
        best[0]     = gBottom - (int)(stats->data[start].best * yScale);
        average[0]  = gBottom - (int)(stats->data[start].average * yScale);
        worst[0]    = gBottom - (int)(stats->data[start].worst * yScale);

        for (i = start+1, step = gLeft; (i % MAX_STAT) != stop; 
													i++, step += xStep) {
            bestEver[1] = gBottom-(int)(stats->data[i%MAX_STAT].bestEver 
															* yScale);
            best[1]     = gBottom-(int)(stats->data[i%MAX_STAT].best
															* yScale);
            worst[1]    = gBottom-(int)(stats->data[i%MAX_STAT].worst
															* yScale);
            average[1]  = gBottom-(int)(stats->data[i%MAX_STAT].average
															* yScale);
            iStep  = (int)step;
            iStep2 = (int)(step+xStep);
			XDrawLine(display, window, fitnessGC,
						iStep, bestEver[0], iStep2, bestEver[1]);
			XDrawLine(display, window, fitnessGC,
						iStep, best[0], iStep2, best[1]);
			XDrawLine(display, window, fitnessGC,
						iStep, average[0], iStep2, average[1]);
			XDrawLine(display, window, fitnessGC,
						iStep, worst[0], iStep2, worst[1]);

            bestEver[0] = bestEver[1];
            best[0]     = best[1];
            average[0]  = average[1];
            worst[0]    = worst[1];
        }
    }
}   /* end updateObjectiveWindow() */



/***************************************************************************
	statistics window stuff
*/

#if HPW
#	define WIDGETCLASS1 XwstaticTextWidgetClass
#	define WIDGETCLASS2 XwstaticTextWidgetClass
#endif

Widget	generationLBL,  generationST,
		bestEverLBL,	bestEverST, 
		bestLBL,		bestST,
		averageLBL,		averageST,
		worstLBL,		worstST;

void setUpStatisticsWindow()
    /*
    ========================================
    :purpose
        create all widgets within the
		statistics window
    ========================================
    */
{
    generationLBL = XtCreateManagedWidget("generationLBL",
                                        WIDGETCLASS1,
                                        statisticsWindow, NULL, 0);
    generationST  = XtCreateManagedWidget("generationST",
                                        WIDGETCLASS2,
                                        statisticsWindow, NULL, 0);

	bestEverLBL	= XtCreateManagedWidget("bestEverLBL", 
										WIDGETCLASS1,
										statisticsWindow, NULL, 0);
	bestEverST	= XtCreateManagedWidget("bestEverST",
										WIDGETCLASS2,
										statisticsWindow, NULL, 0);

	bestLBL		= XtCreateManagedWidget("bestLBL", 
										WIDGETCLASS1,
										statisticsWindow, NULL, 0);
	bestST		= XtCreateManagedWidget("bestST", 
										WIDGETCLASS2,
										statisticsWindow, NULL, 0);

	averageLBL	= XtCreateManagedWidget("averageLBL", 
										WIDGETCLASS1,
										statisticsWindow, NULL, 0);
	averageST	= XtCreateManagedWidget("averageST",
										WIDGETCLASS2, 
										statisticsWindow, NULL, 0);

	worstLBL	= XtCreateManagedWidget("worstLBL", 
										WIDGETCLASS1,
										statisticsWindow, NULL, 0);
	worstST		= XtCreateManagedWidget("worstST", 
										WIDGETCLASS2,
										statisticsWindow, NULL, 0);
}
#undef WIDGETCLASS1
#undef WIDGETCLASS2



void updateStatsDialog()
    /*
	========================================
	:purpose
    	update the statistics dialog box
	========================================
    */
{
    char        text[30];
	unsigned	generationNumber;
	float		bestValue;
	float		maximumValue;
	float		averageValue;
	float		minimumValue;
	float		summedValue;

	if (!isWindowOpen(statisticsWindow))	/* window not open; don't update */
       return;

    sprintf(text, "%d", getGenerationNumber());
    setTextField(generationST, text);

    sprintf(text, "%g", getBestValue());
    setTextField(bestEverST, text);

    sprintf(text, "%g", getMaximumValue());
    setTextField(bestST, text);

    sprintf(text, "%g", getAverageValue());
    setTextField(averageST, text);

    sprintf(text, "%g", getMinimumValue());
    setTextField(worstST, text);
}



/***************************************************************************
	trace window stuff
*/
#if HPW
#	define WIDGETCLASS1 XwstaticTextWidgetClass
#	define WIDGETCLASS2 XwstaticTextWidgetClass
#endif

Widget	evaluateST, calcFitnessST, scaleST, shareST, 
		reproduceST, selectST, sampleST, crossoverST, mutationST;	
Widget	evaluateSR, calcFitnessSR, scaleSR, shareSR, 
		reproduceSR, selectSR, sampleSR, crossoverSR, mutationSR;	
Widget	lastWidget;
Pixel	background, highLight;

void setUpTraceWindow()
    /*
    ========================================
    :purpose
        set up the widgets within the trace
		window
    ========================================
    */
{
	Arg	wargs[1];

	evaluateSR = XtCreateManagedWidget("evaluateBox", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	evaluateST = XtCreateManagedWidget("evaluateST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	calcFitnessSR = XtCreateManagedWidget("box", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	calcFitnessST = XtCreateManagedWidget("calcFitnessST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	scaleSR = XtCreateManagedWidget("box", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	scaleST = XtCreateManagedWidget("scaleST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	shareSR = XtCreateManagedWidget("box", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	shareST = XtCreateManagedWidget("shareST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	reproduceSR = XtCreateManagedWidget("reproduceBox", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	reproduceST = XtCreateManagedWidget("reproduceST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	selectSR = XtCreateManagedWidget("box", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	selectST = XtCreateManagedWidget("selectST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	sampleSR = XtCreateManagedWidget("box", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	sampleST = XtCreateManagedWidget("sampleST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	crossoverSR = XtCreateManagedWidget("box", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	crossoverST = XtCreateManagedWidget("crossoverST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	mutationSR = XtCreateManagedWidget("box", WIDGETCLASS2, 
									traceWindow, NULL, 0);
	mutationST = XtCreateManagedWidget("mutationST", WIDGETCLASS1, 
									traceWindow, NULL, 0);
	XtSetArg(wargs[0], XtNbackground, &background);
	XtGetValues(evaluateST, wargs, 1);

	XtSetArg(wargs[0], XtNhighlightColor, &highLight);
	XtGetValues(evaluateST, wargs, 1);

	lastWidget = NULL;
}
#undef WIDGETCLASS

void trace(what)
    /*
    ========================================
    :purpose
        give the user some notion of what the
		program is up to at any moment
    ========================================
    */
 int what;
{
    Arg    wargs[2];
	Widget widget;

	if (!isWindowOpen(traceWindow))		/* window not open; don't trace */
		return;

	if (lastWidget) {
	    XtSetArg(wargs[0], XtNbackground, background);
    	XtSetValues(lastWidget, wargs, 1);
	}

	switch (what) {
		case (FITNESS)   :
			widget = calcFitnessSR;
			break;
		case (SCALE)     :
			widget = scaleSR;
			break;
		case (SHARE)     :
			widget = shareSR;
			break;
		case (SELECT)    :
			widget = selectSR;
			break;
		case (SAMPLE)    :
			widget = sampleSR;
			break;
		case (CROSSOVER) :
			widget = crossoverSR;
			break;
		case (MUTATION)  :
			widget = mutationSR;
			break;
		case (NULL)      :
			widget = NULL;
			break;
	}

	if (widget)	{
		XtSetArg(wargs[0], XtNbackground, highLight);
		XtSetValues(widget, wargs, 1);
	}
	lastWidget = widget;
}



/***************************************************************************
	user window stuff
*/



void updateUserWindowCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        update the user window whenever it
		is exposed
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
    updateUserWindow();
}



void addUserWindowCallbacks() 
    /*
    ========================================
    :purpose
        attach any callbacks to the user
		window
    ========================================
    */
{
    XtAddCallback(userWindow, XtNexpose, updateUserWindowCB, NULL);
}



void updateUserWindow() 
    /*
    ========================================
    :purpose
        update the user window
    ========================================
    */
{
	chromosomeType	*bestChromosome;

/*
	if (!userWindow)
		return;
*/
	
	if (bestChromosome = getBestChromosome()) {
		decodeChromosome(bestChromosome);
		onBestDo();
	}
}


/*
 ========================================
 :purpose
	the following routines are meant to
	be used by the creator of fitness 
	functions to draw graphics within
	the user window
 ========================================
*/

GC	userGC;

void eraseWindow() 
    /*
    ========================================
    :purpose
        erase the user window
    ========================================
    */
{
	XClearWindow(XtDisplay(userWindow), XtWindow(userWindow));
}



void initDraw() 
    /*
    ========================================
    :purpose
        initialize drawing in the user window
    ========================================
    */
{
	createGC(&userGC, userWindow);
	eraseWindow();
}



void titleWindow(string)
    /*
    ========================================
    :purpose
        give the user window a new title
    ========================================
    */
 char *string;
{
	extern WidgetList windowsMenu;

	nameWindow(userWindowTopLevel, string);
	setItem(windowsMenu, USER_W, string);
}



void drawLine(x1, y1, x2, y2)
    /*
    ========================================
    :purpose
        draw a line in the user window
    ========================================
    */
 int x1, y1, x2, y2;
{
	XDrawLine(XtDisplay(userWindow), XtWindow(userWindow), userGC, 
															x1, y1, x2, y2);
}



void drawCircle(x, y, width, fill)
    /*
    ========================================
    :purpose
        draw a circle in the user window;
		can be filled by settin fill to TRUE
    ========================================
    */
 int	x, y, width;
 bool	fill;
{
	if (fill)
		XFillArc(XtDisplay(userWindow), XtWindow(userWindow), userGC, 
							x-width, y-width, 2*width, 2*width, 0, 360 * 64);
	else
		XDrawArc(XtDisplay(userWindow), XtWindow(userWindow), userGC, 
							x-width, y-width, 2*width, 2*width, 0, 360 * 64);
}



void printString(x, y, string)
    /*
    ========================================
    :purpose
        print a character string within the
		user window
    ========================================
    */
 int	x, y;
 char	*string;
{
	XDrawString(XtDisplay(userWindow), XtWindow(userWindow), userGC, 
											x, y, string, strlen(string));
}



void printChar(x, y, c)
    /*
    ========================================
    :purpose
        print a character within the user 
		window
    ========================================
    */
 int	x, y;
 char	c;
{
	char *string = " ";
	string[0] = c;
    XDrawString(XtDisplay(userWindow), XtWindow(userWindow), userGC, 
															x, y, string, 1); 
}



/***************************************************************************
    misc. window stuff
*/

void toggleWindowCB(w, theWindow, callData)
    /*
    ========================================
    :purpose
    	toggle a window between mapped and 	
		unmapped
    ========================================
    */
 Widget         w;
 Widget         *theWindow;
 caddr_t        callData;
{
/*
    bool windowIsOpen;
    Arg  wargs[1];

    XtSetArg(wargs[0], XtNsetMark, &windowIsOpen);
    XtGetValues(w, wargs, 1);

    if (windowIsOpen) {
*/
	if (isWindowOpen(*theWindow)) {
        XUnmapWindow(XtDisplay(*theWindow),
                       XtWindow(*theWindow));
        checkMenuItem(w, FALSE);
    }
    else {
        XMapWindow(XtDisplay(*theWindow),
                       XtWindow(*theWindow));
        checkMenuItem(w, TRUE);
    }
}



bool isWindowOpen(w)
    /*
    ========================================
    :purpose
        determine whether a window is open
		or closed
    ========================================
    */
 Widget w;
{
	XWindowAttributes windowAttributes;

	XGetWindowAttributes(XtDisplay(w), XtWindow(w), &windowAttributes);

	if (windowAttributes.map_state == IsUnmapped)
		return(FALSE);
	else
		return(TRUE);
}



void openAllWindowsCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        open all windows (e.g., display them
		all; this doesn't create them)
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
	extern WidgetList windowsMenu;
    Display *display;

    display = XtDisplay(statisticsWindowTopLevel);

    XMapWindow(display, XtWindow(statisticsWindowTopLevel));
	checkMenuItem(windowsMenu[STATISTICS_W], TRUE);

    XMapWindow(display, XtWindow(objectiveWindowTopLevel));
    checkMenuItem(windowsMenu[OBJECTIVE_W], TRUE);

    XMapWindow(display, XtWindow(fitnessWindowTopLevel));
    checkMenuItem(windowsMenu[NORM_FIT_W], TRUE);

    XMapWindow(display, XtWindow(userWindowTopLevel));
    checkMenuItem(windowsMenu[USER_W], TRUE);

    XMapWindow(display, XtWindow(traceWindowTopLevel));
    checkMenuItem(windowsMenu[TRACE_W], TRUE);
}



void closeAllWindowsCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        close all windows
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
	extern WidgetList windowsMenu;
    Display *display;

    display = XtDisplay(statisticsWindowTopLevel);

    XUnmapWindow(display, XtWindow(statisticsWindowTopLevel));
    checkMenuItem(windowsMenu[STATISTICS_W], FALSE);

    XUnmapWindow(display, XtWindow(objectiveWindowTopLevel));
    checkMenuItem(windowsMenu[OBJECTIVE_W], FALSE);

    XUnmapWindow(display, XtWindow(fitnessWindowTopLevel));
    checkMenuItem(windowsMenu[NORM_FIT_W], FALSE);

    XUnmapWindow(display, XtWindow(userWindowTopLevel));
    checkMenuItem(windowsMenu[USER_W], FALSE);

    XUnmapWindow(display, XtWindow(traceWindowTopLevel));
    checkMenuItem(windowsMenu[TRACE_W], FALSE);
}




void nameWindows() 
    /*
    ========================================
    :purpose
        name all of the windows
    ========================================
    */
{
    nameWindow(userWindowTopLevel,       "User");
    nameWindow(fitnessWindowTopLevel,    "Fitness");
    nameWindow(objectiveWindowTopLevel,  "Objective");
    nameWindow(statisticsWindowTopLevel, "Statistics");
    nameWindow(traceWindowTopLevel,      "Trace");
}



void createGC(theGC, theWindow)
    /*
    ========================================
    :purpose
        create a graphics context for a 
		window
    ========================================
    */
 GC         *theGC;
 Widget     theWindow;
{
    Arg         wargs[2];
	Cardinal	n = 0;

    XtSetArg(wargs[n], XtNforeground, &gcValues.foreground); n++;
    XtSetArg(wargs[n], XtNbackground, &gcValues.background); n++;
    XtGetValues(theWindow, wargs, n);

    *theGC = XCreateGC(XtDisplay(theWindow), XtWindow(theWindow),
                        (GCForeground | GCBackground), &gcValues);
}



