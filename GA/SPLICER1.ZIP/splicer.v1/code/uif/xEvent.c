/*
 ==============================================================================
 xEvent.c

 :written by

    steven e. bayer
    the mitre corporation

 :purpose

    this module contains the main event loop (and misc. functions) for the
	X Window System interface for the GA tool

 :version 1.0; release date 03/01/91

 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"

#include "myXlib.h"
 
#include <ctype.h>

#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#if MOTIF
#	include <Xm/Xm.h>
#endif

#if HPW
#	include <Xw/Xw.h>
#endif

/*
 ========================================
 global functions headers

 these functions are available to any
 other module; they are externed in
 xEvent.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to
 this module
 ========================================
 */

/*
 ========================================
 external variables

 variables from other modules
 ========================================
 */

/*
 ========================================
 global variables

 globals defined within this module
 ========================================
 */

/*
 ========================================
 functions
 ========================================
 */


main(argc, argv)
    /*
    ========================================
    :purpose
        main function for X interface; sets
		up and initializes everything and 
		enters main event loop
    ========================================
    */
 int argc;
 char *argv[];
{
	XtAppContext	theContext;
	Display			*theDisplay = NULL;
	Screen			*theScreen;
 
	char			appClassName[40];
	Arg				wargs[8];
	Cardinal		n = 0;
 
	extern Widget	mainMenuTopLevel;

	extern Widget	paramDialogTopLevel,
					userWindowTopLevel,
					fitnessWindowTopLevel,
					objectiveWindowTopLevel,
					statisticsWindowTopLevel,
					traceWindowTopLevel;

	extern Widget	samplingOperatorPB,
					crossoverOperatorPB,
					mutationOperatorPB;
 
	/*
		make the application class name
	*/
	makeClassName(argv[0], appClassName);
 
	/*
		create the top level widgets
	*/
    mainMenuTopLevel = XtInitialize(argv[0], appClassName, NULL, 0,
																 &argc, argv);

    paramDialogTopLevel		 = XtCreateApplicationShell(argv[0],
                                        applicationShellWidgetClass, NULL, 0);
    userWindowTopLevel		 = XtCreateApplicationShell(argv[0],
                                        applicationShellWidgetClass, NULL, 0);
    fitnessWindowTopLevel	 = XtCreateApplicationShell(argv[0],
                                        applicationShellWidgetClass, NULL, 0);
    objectiveWindowTopLevel	 = XtCreateApplicationShell(argv[0],
                                        applicationShellWidgetClass, NULL, 0);
    statisticsWindowTopLevel = XtCreateApplicationShell(argv[0],
                                        applicationShellWidgetClass, NULL, 0);
    traceWindowTopLevel		 = XtCreateApplicationShell(argv[0],
                                        applicationShellWidgetClass, NULL, 0);

	/*
		create the widgets
	*/
	setUpMenus();
	setUpWindows();
	setUpDialogs();

	/*
		draw the windows
	*/
	XtRealizeWidget(mainMenuTopLevel);
	XtRealizeWidget(paramDialogTopLevel);
	XtRealizeWidget(statisticsWindowTopLevel);
	XtRealizeWidget(traceWindowTopLevel);
	XtRealizeWidget(objectiveWindowTopLevel);
	XtRealizeWidget(fitnessWindowTopLevel);
	XtRealizeWidget(userWindowTopLevel);

	/*
		check the window menu items
	*/
	checkWindowsMenu();

	/*
		add window call backs
	*/
	addFitnessWindowCallbacks();
	addObjectiveWindowCallbacks();
	addUserWindowCallbacks();

	/*
		set up window graph ports
	*/
	createFitnessWindowGC();
	createObjectiveWindowGC();	

	/*
		title all the windows
	*/
	nameMainMenu();
	nameWindows();
	nameDialogs();

	/*
		set up the GA-specific stuff
	*/
	initGA();							/* initialize GA variables */
	initUser();							/* allow user to override */
	initGAMenus();

	updateParamDialog();
	updateStatsDialog();

	/*
		enter the main loop
	*/
	XtMainLoop();
}


void sufferUserInterface()
	/*
    ========================================
	purpose:
		used whenever we need to look for 
		events but can't jump back to the 
		main event loop (e.g., when running 
		the GA code); it simply looks to see 
		if there is an event and, if so, it 
		dispatches the event
    ========================================
	*/
{
	XEvent theEvent;

	if (XtPending()) {
		XtNextEvent(&theEvent);
		XtDispatchEvent(&theEvent);
	}
}


static char *filename =
           "\0                                                     ";

FILE *openFile(type, prompt, title)
    /*
    ========================================
    :purpose
        prompt the user for a file name and
		open the file; return a pointer to
		the file if successful; return NULL
		if can't open the file
    ========================================
    */
 int type;
 char *prompt;
 char *title;
{
	FILE	*fp;
	char	*how; 
char *string = "                                                       ";
    if (!getStringDialog(filename, prompt, title))
        return;
	if (type == SAVE)
		how = "w";
	else
		how = "r";

    if ((fp = fopen(filename, how)) == NULL) {
        sprintf(string, "Can't open file: %s\n", filename);
        okAlert(string);
        return;
    }
	return fp;
}

