/*
 ==============================================================================
 xDialogs.c

 :written by

    steven e. bayer
    the mitre corporation

 :purpose

    this module contains all code for creating and accessing dialog boxes
	for the X Window System for the GA interface

 :version 1.0; release date 03/01/91

 ==============================================================================
*/

/*
 ========================================
 #include files
 ========================================
 */

#include "gaMain.h"

#include "myXlib.h"

#include <X11/Intrinsic.h>
#include <X11/Shell.h>

#if MOTIF
#   include <Xm/Xm.h>
#   include <Xm/MainW.h>
#endif

#if HPW
#   include <Xw/Xw.h>
#   include <Xw/BBoard.h>
#   include <Xw/RCManager.h>
#   include <Xw/List.h>
#   include <Xw/PButton.h>
#   include <Xw/SText.h>
#   include <Xw/TextEdit.h>
#	include <Xw/SWindow.h>
#endif

/*
 ========================================
 global functions headers

 these functions are available to any
 other module; they are externed in
 xDialogs.h
 ========================================
 */

/*
 ========================================
 hidden functions headers

 these functions are known only to
 this module
 ========================================
 */

void numberOfParametersCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void populationSizeCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void scalingOperatorCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void selectionOperatorCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void samplingOperatorCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void randomSeedCB(
#   if useFunctionPrototypes
 	Widget, caddr_t, caddr_t
#   endif
);

void setUpParamDialog(
#   if useFunctionPrototypes
    void
#   endif
);

void popupDialogCB(
#   if useFunctionPrototypes
 	Widget, dStruct *, caddr_t
#   endif
);

void cancelButtonCB(
#   if useFunctionPrototypes
 	Widget, dStruct *, caddr_t
#   endif
);

void setUpMsgDialogBox(
#   if useFunctionPrototypes
 	mStruct *
#   endif
);

void setUpOkAlertBox(
#   if useFunctionPrototypes
 	oaStruct *
#   endif
);

void yesNoOkCB(
#   if useFunctionPrototypes
 	Widget, ynStruct *, caddr_t
#   endif
);

void yesNoOkCancelDialog(
#   if useFunctionPrototypes
 	char *
#   endif
);

void setUpYesNoDialogBox(
#   if useFunctionPrototypes
 	ynStruct *
#   endif
);

void singleIntOkCB(
#   if useFunctionPrototypes
 	Widget, siStruct *, caddr_t
#   endif
);

void setUpSingleIntEntryDialogBox(
#   if useFunctionPrototypes
 	siStruct *
#   endif
);

void singleFloatOkCB(
#   if useFunctionPrototypes
 	Widget, sfStruct *, caddr_t
#   endif
);

void setUpSingleFloatEntryDialogBox(
#	if useFunctionPrototypes
	sfStruct *
#   endif
);

void getStringOkCB(
#   if useFunctionPrototypes
 	Widget, gsStruct *, caddr_t
#   endif
);

void setUpGetStringDialog(
#   if useFunctionPrototypes
 	gsStruct *
#   endif
);

void reinitOkCB(
#   if useFunctionPrototypes
 	Widget, riStruct *, caddr_t
#   endif
);

Widget setUpReinitDialog(
#   if useFunctionPrototypes
 	riStruct *
#   endif
);


/*
 ========================================
 external variables

 variables from other modules
 ========================================
 */

extern flagsType gaFlags;

/*
 ========================================
 global variables

 globals defined within this module
 ========================================
 */

/*
 ========================================
 functions
 ========================================
 */

/***************************************************************************
    control parameters dialog box stuff

	the control dialog box is not a popup dialog box; it is treated like
	a normal window, but it has buttons, so I put it here
*/
Widget  paramDialogTopLevel,
		paramDialog;

Widget  numberOfParametersPB,       numberOfParametersST,
        parameterCharacteristicsPB, parameterCharacteristicsST,
        populationSizePB,           populationSizeST,
		scalingOperatorPB,			scalingOperatorST,
		sharingOperatorPB,			sharingOperatorST,
        selectionOperatorPB,        selectionOperatorST,
        samplingOperatorPB,         samplingOperatorST,
        crossoverOperatorPB,        crossoverOperatorST,
        mutationOperatorPB,         mutationOperatorST,
        crossoverProbabilityPB,     crossoverProbabilityST,
        mutationProbabilityPB,      mutationProbabilityST,
        randomSeedPB,               randomSeedST;

void setParameter(function)
    /*
    ========================================
    :purpose
        set one parameter on the parameter
		dialog box and then update the box
    ========================================
    */
 void (*function)();
{
   	(*function)();
   	updateParamDialog();
}



void numberOfParametersCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        set the number of parameters when
		the appropriate button is pressed
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
    if (gaFlags.runningGA || gaFlags.stop) /* no changes while running */
        return;
    else
		setParameter(enterNumberOfParameters);
}



void populationSizeCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        set the population size when
        the appropriate button is pressed
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
    if (gaFlags.runningGA || gaFlags.stop) /* no changes while running */
        return;
    else
    	setParameter(enterPopulationSize);
}



void operatorsMenuCB(w, clientData, callData)
    /*
    ========================================
    :purpose
		post the operators menu when one of 
		the operator buttons has been pressed
		on the control parameters dialog box;
		this should be changed so that the
		specific submenu is posted, but this
		will do for now
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
	Window	root, child;
	int		x, y, x1, y1;
	unsigned int keysButtons;	
	extern Widget menuMgr[];
	Arg	wargs[1];

	XQueryPointer(XtDisplay(w), XtWindow(w),
						&root, &child, &x, &y, &x1, &y1, &keysButtons);
	XwPostPopup(menuMgr[2], NULL, x-20, y-30);
	
	XtSetArg(wargs[0], XtNset, FALSE);
	XtSetValues(w, wargs, 1); 
}



void scalingOperatorCB(w, clientData, callData)
    /*
    ========================================
    :purpose
		set the scaling operator when the
        appropriate button is selected; this
        should pop up the scaling menu
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
}



void sharingOperatorCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        set the sharing operator when the
        appropriate button is selected; this
        should pop up the sharing menu
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
}



void selectionOperatorCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        set the selection operator when the
        appropriate button is selected; this
        should pop up the selection menu
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
}



void samplingOperatorCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        set the sampling operator when the
        appropriate button is selected; this
        should pop up the sampling menu
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
    Window  root, child;
    int     x, y, x1, y1;
    unsigned int keysButtons;

	extern Widget menuMgr[];
	extern Widget operatorsMenuPane, samplingMenuPane;
	Arg wargs[1];

    XQueryPointer(XtDisplay(w), XtWindow(w),
                        &root, &child, &x, &y, &x1, &y1, &keysButtons);

	XtSetArg(wargs[0], XtNattachTo, NULL);
	XtSetValues(operatorsMenuPane, wargs, 1);

	XtSetArg(wargs[0], XtNattachTo, (XtArgVal) "menuMgr3");
	XtSetValues(samplingMenuPane, wargs, 1);

	XwPostPopup(menuMgr[2], NULL, x+10, y+10);
}



void samplingOperatorRCB(w, clientData, callData)
 Widget		w;
 caddr_t    clientData;
 caddr_t    callData;
{
    extern myMenuStruct operatorsMenuData[];
	extern Widget samplingMenuPane;
	Arg wargs[1];

	XtSetArg(wargs[0], XtNattachTo, (XtArgVal) operatorsMenuData[3].name);
	XtSetValues(samplingMenuPane, wargs, 1);

    XtSetArg(wargs[0], XtNset, FALSE);
    XtSetValues(w, wargs, 1);
}



void crossoverProbabilityCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        set the crossover probability when
		the appropriate button has been
		selected
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
    setParameter(enterCrossoverProbability);
}



void mutationProbabilityCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        set the mutation probability when
        the appropriate button has been
        selected
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
    setParameter(enterMutationProbability);
}



void randomSeedCB(w, clientData, callData)
    /*
    ========================================
    :purpose
        set the random number seed when
        the appropriate button has been
        selected
    ========================================
    */
 Widget     w;
 caddr_t    clientData;
 caddr_t    callData;
{
    setParameter(enterRandomSeed);
}



#if HPW
#   define WIDGETCLASS1 XwpushButtonWidgetClass
#   define WIDGETCLASS2 XwstaticTextWidgetClass
#endif


void setUpParamDialog()
    /*
    ========================================
    :purpose
        set up the control parameters 
		dialog box
    ========================================
    */
{
#   if MOTIF
#   define WIDGETCLASS xmMainWindowWidgetClass
#   endif

#   if HPW
#   define WIDGETCLASS XwrowColWidgetClass
#   endif

	/* create the parameters dialog box */

    paramDialog   = XtCreateManagedWidget("paramDialog",
                                                WIDGETCLASS,
                                                paramDialogTopLevel,
                                                NULL, 0);

	/* create the number of parameters widgets */

    numberOfParametersPB    = XtCreateManagedWidget("numberOfParametersPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(numberOfParametersPB, XtNselect, numberOfParametersCB, NULL);
    numberOfParametersST    = XtCreateManagedWidget("numberOfParametersST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

	/* create the parameter characteristics widgets */

    parameterCharacteristicsPB  = XtCreateManagedWidget(
                                                "parameterCharacteristicsPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    parameterCharacteristicsST  = XtCreateManagedWidget(
												"parameterCharacteristicsST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

	/* create the population size widgets */

    populationSizePB        = XtCreateManagedWidget("populationSizePB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(populationSizePB, XtNselect, populationSizeCB, NULL);
    populationSizeST        = XtCreateManagedWidget("populationSizeST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

	/* create the scaling operator widgets */

    scalingOperatorPB     = XtCreateManagedWidget("scalingOperatorPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(scalingOperatorPB, XtNselect, operatorsMenuCB, NULL);
    scalingOperatorST     = XtCreateManagedWidget("scalingOperatorST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

    /* create the sharing operator widgets */

    sharingOperatorPB     = XtCreateManagedWidget("sharingOperatorPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(sharingOperatorPB, XtNselect, operatorsMenuCB, NULL);
    sharingOperatorST     = XtCreateManagedWidget("sharingOperatorST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

	/* create the selection operator widgets */

    selectionOperatorPB     = XtCreateManagedWidget("selectionOperatorPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(selectionOperatorPB, XtNselect, operatorsMenuCB, NULL);
    selectionOperatorST     = XtCreateManagedWidget("selectionOperatorST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

	/* create the sampling operator widgets */

    samplingOperatorPB     = XtCreateManagedWidget("samplingOperatorPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
/*
    XtAddCallback(samplingOperatorPB, XtNselect, samplingOperatorCB, NULL);
    XtAddCallback(samplingOperatorPB, XtNrelease, samplingOperatorRCB, NULL);
*/
	XtAddCallback(samplingOperatorPB, XtNselect, operatorsMenuCB, NULL);
    samplingOperatorST     = XtCreateManagedWidget("samplingOperatorST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

	/* create the crossover operator widgets */

    crossoverOperatorPB     = XtCreateManagedWidget("crossoverOperatorPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(crossoverOperatorPB, XtNselect, operatorsMenuCB, NULL);
    crossoverOperatorST     = XtCreateManagedWidget("crossoverOperatorST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);


	/* create the mutation operator widgets */

    mutationOperatorPB      = XtCreateManagedWidget("mutationOperatorPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(mutationOperatorPB, XtNselect, operatorsMenuCB, NULL);
    mutationOperatorST      = XtCreateManagedWidget("mutationOperatorST ",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);


	/* create the crossover probability widgets */

    crossoverProbabilityPB  = XtCreateManagedWidget("crossoverProbabilityPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(crossoverProbabilityPB, XtNselect, crossoverProbabilityCB,
                                                NULL);
    crossoverProbabilityST  = XtCreateManagedWidget("crossoverProbabilityST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

	/* create the mutation probability widgets */

    mutationProbabilityPB   = XtCreateManagedWidget("mutationProbabilityPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(mutationProbabilityPB, XtNselect, mutationProbabilityCB,
                                                NULL);
    mutationProbabilityST  = XtCreateManagedWidget("muationaProbabilityST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);

	/* create the random seed widgets */

    randomSeedPB            = XtCreateManagedWidget("randomSeedPB",
                                                WIDGETCLASS1,
                                                paramDialog, NULL, 0);
    XtAddCallback(randomSeedPB, XtNselect, randomSeedCB, NULL);
    randomSeedST            = XtCreateManagedWidget("randomSeedST",
                                                WIDGETCLASS2,
                                                paramDialog, NULL, 0);
}
#undef WIDGETCLASS1
#undef WIDGETCLASS2



void updateParamDialog()
    /*
    ========================================
    :purpose
        update the control parameters dialog box
    ========================================
    */
{
    char        text[30];
    unsigned    numberOfParameters;
    unsigned    populationSize;
    float       crossoverProbability;
    float       mutationProbability;
    int         randomSeed;

/*
    if (!paramDialog)          /* see if the dialog box is on the screen
       return;
*/

    numberOfParameters = getNumberOfParameters();
    sprintf(text, "%d", numberOfParameters);
    setTextField(numberOfParametersST, text);

    populationSize = getPopulationSize();
    sprintf(text, "%d", populationSize);
    setTextField(populationSizeST, text);

    setTextField(scalingOperatorST,		getScalingOperatorName());
    setTextField(sharingOperatorST,		getSharingOperatorName());
    setTextField(selectionOperatorST,	getSelectionOperatorName());
    setTextField(samplingOperatorST,	getSamplingOperatorName());
    setTextField(crossoverOperatorST,	getCrossoverOperatorName());
    setTextField(mutationOperatorST,	getMutationOperatorName());

    crossoverProbability = getCrossoverProbability();
    sprintf(text, "%g", crossoverProbability);
    setTextField(crossoverProbabilityST, text);

    mutationProbability = getMutationProbability();
    sprintf(text, "%g", mutationProbability);
    setTextField(mutationProbabilityST, text);

    randomSeed = getRandomSeed();
    sprintf(text, "%d", randomSeed);
    setTextField(randomSeedST, text);
}



/***************************************************************************
    popup dialog box stuff
*/

/*
	generic dialog box structure
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
	bool			setFlag;
    char            *windowTitle;
	bool			ok;
} dStruct;



/*
	generic dialog box pop up function
*/

void popupDialogCB(w, dialogStruct, callData)
    /*
    ========================================
    :purpose
        generic callback for popping up a
		dialog box
    ========================================
    */
 Widget         w;
 dStruct       *dialogStruct;
 caddr_t        callData;
{
    Arg wargs[1];

	if (dialogStruct->enableButton) {
    	XtSetArg(wargs[0], XtNsensitive, FALSE);
    	XtSetValues(dialogStruct->enableButton, wargs, 1);
	}

    XtPopup(dialogStruct->shellWidget, XtGrabNone);
    nameWindow(dialogStruct->shellWidget, dialogStruct->windowTitle);
}



/*
	generic cancel button function
*/

void cancelButtonCB(w, dialogStruct, callData)
    /*
    ========================================
    :purpose
        generic callback for a dialog box
		cancel button
    ========================================
    */
 Widget         w;
 dStruct		*dialogStruct;
 caddr_t        callData;
{
    Arg wargs[1];

    XtPopdown(dialogStruct->shellWidget);
	if (dialogStruct->enableButton) {
    	XtSetArg(wargs[0], XtNsensitive, TRUE);
    	XtSetValues(dialogStruct->enableButton, wargs, 1);
	}

	/* signal that the cancel button has been clicked */
	dialogStruct->ok = FALSE;

	/* signal that the user closed the dialog box */
    dialogStruct->setFlag = TRUE;
}



/***************************************************************************
    message dialog box stuff
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
    bool            setFlag;
    char            *windowTitle;
    bool            ok;

    Widget          staticTextWidget;
} mStruct;

mStruct    msgDialogStruct;



void msgDialog(theString, theTitle, how)
    /*
    ========================================
    :purpose
        present a dialog box to the user
        with a long text message and just 
		an ok button; this is meant to be
		used for "About..." boxes
    ========================================
    */
 char   *theString;
 char	*theTitle;
 char	how;
{
    Arg wargs[1];
	XwAlignment align;

    msgDialogStruct.setFlag = FALSE;
    msgDialogStruct.enableButton = NULL;

	if (how == 'c')
		align = XwALIGN_CENTER;
	else if (how == 'r')
		align = XwALIGN_RIGHT;
	else
		align = XwALIGN_LEFT;

	XtSetArg(wargs[0], XtNalignment, align);
	XtSetValues(msgDialogStruct.staticTextWidget, wargs, 1);

    setTextField(msgDialogStruct.staticTextWidget, theString);

    XtPopup(msgDialogStruct.shellWidget, XtGrabNone);
    nameWindow(msgDialogStruct.shellWidget, theTitle);

    while(!msgDialogStruct.setFlag)
        sufferUserInterface();
}



void setUpMsgDialogBox(msgDialogStruct)
    /*
    ========================================
    :purpose
        create the widgets for the message
        dialog box
    ========================================
    */
 mStruct *msgDialogStruct;
{
    Widget  msgDialogPopup, msgDialogPane, scrolledWindow, okButton;
    Arg     wargs[7];
    int     n = 0;

    /*
        create a popup shell to hold the dialog box
    */
    n = 0;
    XtSetArg(wargs[n], XtNwidth,  474); n++;
    XtSetArg(wargs[n], XtNheight, 190); n++;
    msgDialogStruct->shellWidget = msgDialogPopup =
                        XtCreatePopupShell("msgDialogPopup", shellWidgetClass,
                                            msgDialogStruct->parent, wargs, n);

    /*
        create a BulletinBoard widget to hold the fields
    */
    msgDialogPane  = XtCreateManagedWidget("msgDialogPane",
                                            XwbulletinWidgetClass,
                                            msgDialogPopup, NULL, 0);
    /*
        create the scrolled window widget
    */
    n = 0;
    XtSetArg(wargs[n], XtNwidth,        	470);   n++;
    XtSetArg(wargs[n], XtNheight,       	150);   n++;
    XtSetArg(wargs[n], XtNforceVerticalSB,  TRUE);  n++;
    scrolledWindow = XtCreateManagedWidget("msgDialogSWindow", 
							XwswindowWidgetClass, msgDialogPane, wargs, n);

    /*
        create the static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNwidth,        430);   n++;
    XtSetArg(wargs[n], XtNheight,       400);   n++;
    XtSetArg(wargs[n], XtNborderWidth,  0);     n++;
    XtSetArg(wargs[n], XtNstring,       "");    n++;
    XtSetArg(wargs[n], XtNalignment,    XwALIGN_CENTER); n++;
    XtSetArg(wargs[n], XtNgravity,		NorthGravity); n++;
    XtSetArg(wargs[n], XtNrecomputeSize,FALSE); n++;
    msgDialogStruct->staticTextWidget = XtCreateManagedWidget(
                                "msgDialogText", XwstatictextWidgetClass,
                                scrolledWindow, wargs, n);

    /*
        create a OK button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      380); n++;
    XtSetArg(wargs[n], XtNy,      160);  n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "OK");    n++;
    okButton = XtCreateManagedWidget("msgDialogOkButton",
                                XwpushButtonWidgetClass,
                                msgDialogPane, wargs, n);

    XtAddCallback(okButton, XtNrelease, cancelButtonCB, msgDialogStruct);
}



/***************************************************************************
    ok alert dialog box stuff
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
    bool            setFlag;
    char            *windowTitle;
	bool			ok;

	Widget			staticTextWidget;
} oaStruct;

oaStruct	okAlertStruct;



void okAlert(theString)
    /*
    ========================================
    :purpose
        present an alert box to the user 
		with a message and just an ok button
    ========================================
    */
 char   *theString;
{
    Arg wargs[1];

    okAlertStruct.setFlag = FALSE;
    okAlertStruct.enableButton = NULL;

	setTextField(okAlertStruct.staticTextWidget, theString);

    XtPopup(okAlertStruct.shellWidget, XtGrabNone);
    nameWindow(okAlertStruct.shellWidget, "");

    while(!okAlertStruct.setFlag)
        sufferUserInterface();
}




void setUpOkAlertBox(okAlertStruct)
    /*
    ========================================
    :purpose
        create the widgets for the okAlert
		box
    ========================================
    */
 oaStruct *okAlertStruct;
{
    Widget  okAlertPopup, okAlertPane, okButton;
    Arg     wargs[6];
    int     n = 0;

    /*
        create a popup shell to hold the dialog box
    */
    n = 0;
    XtSetArg(wargs[n], XtNwidth,  450); n++;
    XtSetArg(wargs[n], XtNheight, 100); n++;
    okAlertStruct->shellWidget = okAlertPopup =
                        XtCreatePopupShell("okAlertPopup", shellWidgetClass,
                                            okAlertStruct->parent, wargs, n);

    /*
        create a BulletinBoard widget to hold the fields
    */
    okAlertPane  = XtCreateManagedWidget("okAlertPane",
                                            XwbulletinWidgetClass,
                                            okAlertPopup, NULL, 0);

    /*
        create the prompt static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,            10);    n++;
    XtSetArg(wargs[n], XtNy,            10);    n++;
    XtSetArg(wargs[n], XtNwidth,        430);   n++;
    XtSetArg(wargs[n], XtNheight,       60);    n++;
    XtSetArg(wargs[n], XtNborderWidth,  0);     n++;
    XtSetArg(wargs[n], XtNstring,       "");    n++;
    okAlertStruct->staticTextWidget = XtCreateManagedWidget(
                                "okAlertPrompt", XwstatictextWidgetClass,
                                okAlertPane, wargs, n);

    /*
        create a OK button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      360); n++;
    XtSetArg(wargs[n], XtNy,      70);  n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "OK");    n++;
    okButton = XtCreateManagedWidget("okAlertOkButton",
                                XwpushButtonWidgetClass,
                                okAlertPane, wargs, n);

    XtAddCallback(okButton, XtNrelease, cancelButtonCB, okAlertStruct);
}



/***************************************************************************
    yes/no ok/cancel dialog box stuff
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
    bool            setFlag;
    char            *windowTitle;
	bool			ok;

    Widget          staticTextWidget;
	Widget			okButton;
	Widget			cancelButton;
	bool			flag;
} ynStruct;

ynStruct    yesNoStruct;



void yesNoOkCB(w, yesNoStruct, callData)
    /*
    ========================================
    :purpose
		handle the ok button of the yes/no
		dialog box
    ========================================
    */
 Widget         w;
 ynStruct       *yesNoStruct;
 caddr_t        callData;
{
    extern Widget textEditWidget;
    Arg wargs[1];

	yesNoStruct->flag = TRUE;

    XtPopdown(yesNoStruct->shellWidget);
    if (yesNoStruct->enableButton) {
        XtSetArg(wargs[0], XtNsensitive, TRUE);
        XtSetValues(yesNoStruct->enableButton, wargs, 1);
    }

	/* signal that the ok button was clicked */
	yesNoStruct->ok = TRUE;

    /* signal that the user closed the dialog box */
    yesNoStruct->setFlag = TRUE;
}



void yesNoOkCancelDialog(string)
    /*
    ========================================
    :purpose
        handle the cancel button of the 
		yes/no dialog box
    ========================================
    */
 char       *string;
{
    Arg wargs[1];

    yesNoStruct.setFlag = FALSE;
    yesNoStruct.enableButton = NULL;
	yesNoStruct.flag = FALSE;

	setTextField(yesNoStruct.staticTextWidget, string);

    XtPopup(yesNoStruct.shellWidget, XtGrabNone);
    nameWindow(yesNoStruct.shellWidget, "");

    while(!yesNoStruct.setFlag)
        sufferUserInterface();
}



bool yesNoDialog(string)
    /*
    ========================================
    :purpose
        present a dialog box to the user
        with a message and yes and no buttons
    ========================================
    */
 char *string;
{
    Arg wargs[1];

    XtSetArg(wargs[0], XtNlabel, "Yes");
    XtSetValues(yesNoStruct.okButton, wargs, 1);

    XtSetArg(wargs[0], XtNlabel, "No");
    XtSetValues(yesNoStruct.cancelButton, wargs, 1);

    yesNoOkCancelDialog(string);
	return(yesNoStruct.flag);
}



bool okCancelDialog(string)
    /*
    ========================================
    :purpose
        present a dialog box to the user
		with a message and ok and cancel 
		buttons; this is the same as the
		yes/no dialog with different labels
		on the buttons
    ========================================
    */
 char *string;
{
    Arg wargs[1];

    XtSetArg(wargs[0], XtNlabel, "OK");
    XtSetValues(yesNoStruct.okButton, wargs, 1);

    XtSetArg(wargs[0], XtNlabel, "Cancel");
    XtSetValues(yesNoStruct.cancelButton, wargs, 1);

    yesNoOkCancelDialog(string);
	return(yesNoStruct.flag);
}



void setUpYesNoDialogBox(yesNoStruct)
    /*
    ========================================
    :purpose
        create the widgets for the yes/no
		dialog box
    ========================================
    */
 ynStruct *yesNoStruct;
{
    Widget  yesNoPopup, yesNoPane;
    Arg     wargs[6];
    int     n = 0;

    /*
        create a popup shell to hold the dialog box
    */
    n = 0;
    XtSetArg(wargs[n], XtNwidth,  450); n++;
    XtSetArg(wargs[n], XtNheight, 130); n++;
    yesNoStruct->shellWidget = yesNoPopup =
                        XtCreatePopupShell("yesNoPopup", shellWidgetClass,
                                            yesNoStruct->parent, wargs, n);

    /*
        create a BulletinBoard widget to hold the fields
    */
    yesNoPane  = XtCreateManagedWidget("yesNoPane",
                                            XwbulletinWidgetClass,
                                            yesNoPopup, NULL, 0);

    /*
        create the prompt static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,            10);    n++;
    XtSetArg(wargs[n], XtNy,            10);    n++;
    XtSetArg(wargs[n], XtNwidth,        430);   n++;
    XtSetArg(wargs[n], XtNheight,       60);    n++;
    XtSetArg(wargs[n], XtNborderWidth,  0);     n++;
    yesNoStruct->staticTextWidget = XtCreateManagedWidget(
                                "yesNoPrompt", XwstatictextWidgetClass,
                                yesNoPane, wargs, n);

    /*
        create a Cancel button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      270); n++;
    XtSetArg(wargs[n], XtNy,      100); n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "Cancel");  n++;
    yesNoStruct->cancelButton = XtCreateManagedWidget("yesNoCancelButton",
                                XwpushButtonWidgetClass,
                                yesNoPane, wargs, n);

    XtAddCallback(yesNoStruct->cancelButton, XtNrelease, cancelButtonCB, 
											yesNoStruct);


    /*
        create a OK button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      360); n++;
    XtSetArg(wargs[n], XtNy,      100); n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "OK");    n++;
    yesNoStruct->okButton = XtCreateManagedWidget("yesNoOkButton",
                                XwpushButtonWidgetClass,
                                yesNoPane, wargs, n);

    XtAddCallback(yesNoStruct->okButton, XtNrelease, yesNoOkCB, yesNoStruct);
}




/***************************************************************************
    single integer entry dialog box stuff
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
    bool            setFlag;
    char            *windowTitle;
	bool			ok;

	Widget			textEditWidget;
    Widget          staticTextWidget1;
	Widget			staticTextWidget2;
	int				*theNumber;
	int				low, high;
} siStruct;

siStruct    singleIntStruct;



void singleIntOkCB(w, singleIntStruct, callData)
    /*
    ========================================
    :purpose
        handle the ok button for the single
		integer entry dialog box
    ========================================
    */
 Widget         w;
 siStruct       *singleIntStruct;
 caddr_t        callData;
{
    extern Widget textEditWidget;
    Arg wargs[1];
    char *string;
	int	theNumber;

    string = (char *) XwTextCopyBuffer(singleIntStruct->textEditWidget);
	theNumber = atoi(string);
	XtFree(string);
	if ((theNumber < singleIntStruct->low) || 
		(theNumber > singleIntStruct->high)) {
		XBell(XtDisplay(w), 100);
		return;
	}
	else
		*singleIntStruct->theNumber = theNumber;

    XtPopdown(singleIntStruct->shellWidget);
    if (singleIntStruct->enableButton) {
        XtSetArg(wargs[0], XtNsensitive, TRUE);
        XtSetValues(singleIntStruct->enableButton, wargs, 1);
    }

	/* signal that the ok button was clicked */
	singleIntStruct->ok = TRUE;

    /* signal that the user closed the dialog box */
    singleIntStruct->setFlag = TRUE;
}




void singleIntEntryDialog(number, string1, string2, low, high)
    /*
    ========================================
    :purpose
		present a dialog box to the user and
		solicit a single integer
    ========================================
    */
 int		*number;
 char		*string1;
 char		*string2;
 int		low, high;
{
    Arg wargs[1];
	char string[200];

    singleIntStruct.setFlag = FALSE;
	singleIntStruct.theNumber = number;
	singleIntStruct.enableButton = NULL;
	singleIntStruct.low = low;
	singleIntStruct.high = high;

	sprintf(string, "Enter %s:", string1);
	setTextField(singleIntStruct.staticTextWidget1, string);

	setTextField(singleIntStruct.staticTextWidget2, string2);

	sprintf(string, "%d", *number);
	XwTextClearBuffer(singleIntStruct.textEditWidget);
	XwTextInsert(singleIntStruct.textEditWidget, string);

    XtPopup(singleIntStruct.shellWidget, XtGrabNone);
    nameWindow(singleIntStruct.shellWidget, "");

    while(!singleIntStruct.setFlag)
        sufferUserInterface();
}




void setUpSingleIntEntryDialogBox(singleIntStruct)
    /*
    ========================================
    :purpose
        create the widgets for the single
		integer entry dialog box
    ========================================
    */
 siStruct *singleIntStruct;
{
    Widget  singleIntPopup, singleIntPane, okButton, cancelButton;
    Arg     wargs[6];
    int     n = 0;

    /*
        create a popup shell to hold the dialog box
    */
    n = 0;
    XtSetArg(wargs[n], XtNwidth,  450); n++;
    XtSetArg(wargs[n], XtNheight, 130); n++;
    singleIntStruct->shellWidget = singleIntPopup =
                        XtCreatePopupShell("singleIntPopup", shellWidgetClass,
                                            singleIntStruct->parent, wargs, n);

    /*
        create a BulletinBoard widget to hold the fields
    */
    singleIntPane  = XtCreateManagedWidget("singleIntPane",
                                            XwbulletinWidgetClass,
                                            singleIntPopup, NULL, 0);

    /*
        create the prompt static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,            10);    n++;
    XtSetArg(wargs[n], XtNy,            10);    n++;
    XtSetArg(wargs[n], XtNwidth,        330);   n++;
    XtSetArg(wargs[n], XtNheight,       60);    n++;
    XtSetArg(wargs[n], XtNborderWidth,  0);     n++;
    singleIntStruct->staticTextWidget1 = XtCreateManagedWidget(
                                "singleIntPrompt", XwstatictextWidgetClass,
                                singleIntPane, wargs, n);

    /*
        create the range static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,            10);    n++;
    XtSetArg(wargs[n], XtNy,            70);    n++;
    XtSetArg(wargs[n], XtNwidth,        430);   n++;
    XtSetArg(wargs[n], XtNheight,       20);    n++;
    XtSetArg(wargs[n], XtNborderWidth,  0);     n++;
    singleIntStruct->staticTextWidget2 = XtCreateManagedWidget(
                                "singleIntRange", XwstatictextWidgetClass,
                                singleIntPane, wargs, n);

    /*
        create the text edit field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      360);             n++;
    XtSetArg(wargs[n], XtNy,      10);              n++;
    XtSetArg(wargs[n], XtNwidth,  80);              n++;
    XtSetArg(wargs[n], XtNheight, 20);              n++;
    XtSetArg(wargs[n], XtNeditType, XwtextEdit);    n++;
    singleIntStruct->textEditWidget = createOneLineTextEditWidget(
                                                            "singleIntTEdit",
                                                            singleIntPane,
                                                            wargs, n);

    /*
        create a Cancel button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      270); n++;
    XtSetArg(wargs[n], XtNy,      100); n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "Cancel");  n++;
    cancelButton = XtCreateManagedWidget("singleIntCancelButton",
                                XwpushButtonWidgetClass,
                                singleIntPane, wargs, n);

    XtAddCallback(cancelButton, XtNrelease, cancelButtonCB, singleIntStruct);


    /*
        create a OK button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      360); n++;
    XtSetArg(wargs[n], XtNy,      100); n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "OK");    n++;
    okButton = XtCreateManagedWidget("singleIntOkButton",
                                XwpushButtonWidgetClass,
                                singleIntPane, wargs, n);

    XtAddCallback(okButton, XtNrelease, singleIntOkCB, singleIntStruct);
}



/***************************************************************************
    single float entry dialog box stuff
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
    bool            setFlag;
    char            *windowTitle;
	bool			ok;

    Widget          textEditWidget;
    Widget          staticTextWidget1;
    Widget          staticTextWidget2;
    float			*theNumber;
    float			low, high;
} sfStruct;

sfStruct    singleFloatStruct;



void singleFloatOkCB(w, singleFloatStruct, callData)
    /*
    ========================================
    :purpose
        handle the ok button for the single
		float entry dialog box
    ========================================
    */
 Widget         w;
 sfStruct       *singleFloatStruct;
 caddr_t        callData;
{
    extern Widget textEditWidget;
    Arg wargs[1];
    char *string;
    float theNumber;

    string = (char *) XwTextCopyBuffer(singleFloatStruct->textEditWidget);
    theNumber = atof(string);
	XtFree(string);
    if ((theNumber < singleFloatStruct->low) ||
        (theNumber > singleFloatStruct->high)) {
        XBell(XtDisplay(w), 100);
        return;
    }
    else
        *singleFloatStruct->theNumber = theNumber;

    XtPopdown(singleFloatStruct->shellWidget);
    if (singleFloatStruct->enableButton) {
        XtSetArg(wargs[0], XtNsensitive, TRUE);
        XtSetValues(singleFloatStruct->enableButton, wargs, 1);
    }

	/* signal that the ok button was clicked */
	singleFloatStruct->ok = TRUE;

    /* signal that the user closed the dialog box */
    singleFloatStruct->setFlag = TRUE;
}




void singleFloatEntryDialog(number, string1, string2, low, high)
    /*
    ========================================
    :purpose
		present a dialog box to the user and
		solicit a single floating point value
    ========================================
    */
 float		*number;
 char       *string1;
 char       *string2;
 float		low, high;
{
    Arg wargs[1];
    char string[200];

    singleFloatStruct.setFlag = FALSE;
    singleFloatStruct.enableButton = NULL;
    singleFloatStruct.theNumber = number;
    singleFloatStruct.low = low;
    singleFloatStruct.high = high;

    sprintf(string, "Enter %s:", string1);
	setTextField(singleFloatStruct.staticTextWidget1, string);

	setTextField(singleFloatStruct.staticTextWidget2, string2);

    sprintf(string, "%f", *number);
    XwTextClearBuffer(singleFloatStruct.textEditWidget);
    XwTextInsert(singleFloatStruct.textEditWidget, string);

    XtPopup(singleFloatStruct.shellWidget, XtGrabNone);
    nameWindow(singleFloatStruct.shellWidget, "");

    while(!singleFloatStruct.setFlag)
        sufferUserInterface();
}




void setUpSingleFloatEntryDialogBox(singleFloatStruct)
    /*
    ========================================
    :purpose
        create the widgets for the single
		floating point entry dialog box
    ========================================
    */
 siStruct *singleFloatStruct;
{
    Widget  singleFloatPopup, singleFloatPane, okButton, cancelButton;
    Arg     wargs[6];
    int     n = 0;

    /*
        create a popup shell to hold the dialog box
    */
    n = 0;
    XtSetArg(wargs[n], XtNwidth,  450); n++;
    XtSetArg(wargs[n], XtNheight, 130); n++;
    singleFloatStruct->shellWidget = singleFloatPopup =
                        XtCreatePopupShell("singleFloatPopup", shellWidgetClass,
                                          singleFloatStruct->parent, wargs, n);

    /*
        create a BulletinBoard widget to hold the fields
    */
    singleFloatPane  = XtCreateManagedWidget("singleFloatPane",
                                            XwbulletinWidgetClass,
                                            singleFloatPopup, NULL, 0);

    /*
        create the prompt static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,            10);    n++;
    XtSetArg(wargs[n], XtNy,            10);    n++;
    XtSetArg(wargs[n], XtNwidth,        330);   n++;
    XtSetArg(wargs[n], XtNheight,       60);    n++;
    XtSetArg(wargs[n], XtNborderWidth,  0);     n++;
    singleFloatStruct->staticTextWidget1 = XtCreateManagedWidget(
                                "singleFloatPrompt", XwstatictextWidgetClass,
                                singleFloatPane, wargs, n);

    /*
        create the range static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,            10);    n++;
    XtSetArg(wargs[n], XtNy,            70);    n++;
    XtSetArg(wargs[n], XtNwidth,        430);   n++;
    XtSetArg(wargs[n], XtNheight,       20);    n++;
    XtSetArg(wargs[n], XtNborderWidth,  0);     n++;
    singleFloatStruct->staticTextWidget2 = XtCreateManagedWidget(
                                "singleFloatRange", XwstatictextWidgetClass,
                                singleFloatPane, wargs, n);

    /*
        create the text edit field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      360);             n++;
    XtSetArg(wargs[n], XtNy,      10);              n++;
    XtSetArg(wargs[n], XtNwidth,  80);              n++;
    XtSetArg(wargs[n], XtNheight, 20);              n++;
    XtSetArg(wargs[n], XtNeditType, XwtextEdit);    n++;
    singleFloatStruct->textEditWidget = createOneLineTextEditWidget(
                                                            "singleFloatTEdit",
                                                            singleFloatPane,
                                                            wargs, n);

    /*
        create a Cancel button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      270); n++;
    XtSetArg(wargs[n], XtNy,      100); n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "Cancel");  n++;
    cancelButton = XtCreateManagedWidget("singleFloatCancelButton",
                                XwpushButtonWidgetClass,
                                singleFloatPane, wargs, n);

    XtAddCallback(cancelButton, XtNrelease, cancelButtonCB, singleFloatStruct);


    /*
        create a OK button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      360); n++;
    XtSetArg(wargs[n], XtNy,      100); n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "OK");    n++;
    okButton = XtCreateManagedWidget("singleFloatOkButton",
                                XwpushButtonWidgetClass,
                                singleFloatPane, wargs, n);

    XtAddCallback(okButton, XtNrelease, singleFloatOkCB, singleFloatStruct);
}




/***************************************************************************
	getString dialog box stuff
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
	bool			setFlag;
	char			*windowTitle;
	bool			ok;
	Widget			staticTextWidget;
	Widget			textEditWidget;
	char			*theString;
} gsStruct;

gsStruct getStringStruct;



void getStringOkCB(w, getStringStruct, callData)
    /*
    ========================================
    :purpose
        handle the ok button for the get
		string dialog box
    ========================================
    */
 Widget			w;
 gsStruct       *getStringStruct;
 caddr_t		callData;
{
	extern Widget textEditWidget;
	Arg	wargs[1];
	char *string;

	string = (char *) XwTextCopyBuffer(getStringStruct->textEditWidget);
	strcpy(getStringStruct->theString, string);
	XtFree(string);

	XtPopdown(getStringStruct->shellWidget);
	if (getStringStruct->enableButton) {
		XtSetArg(wargs[0], XtNsensitive, TRUE);
		XtSetValues(getStringStruct->enableButton, wargs, 1);
	}

	/* signal that the ok button has been clicked */
	getStringStruct->ok = TRUE;

	/* signal that the user closed the dialog box */
	getStringStruct->setFlag = TRUE;
}



bool getStringDialog(theString, thePrompt, theTitle)
    /*
    ========================================
    :purpose
        present a dialog box to the user and
		solicit a string of characters
	========================================
	*/
 char	*theString;
 char	*thePrompt;
 char	*theTitle;
{
	Arg wargs[1];

	getStringStruct.setFlag = FALSE;
	getStringStruct.theString = theString;

	getStringStruct.enableButton = NULL;
	if (getStringStruct.enableButton) {
		XtSetArg(wargs[0], XtNsensitive, FALSE);
		XtSetValues(getStringStruct.enableButton, wargs, 1);
	}

	setTextField(getStringStruct.staticTextWidget, thePrompt);

	XwTextClearBuffer(getStringStruct.textEditWidget);
	if (strlen(theString) > 0)
		XwTextInsert(getStringStruct.textEditWidget, theString);

	XtPopup(getStringStruct.shellWidget, XtGrabNone);
	nameWindow(getStringStruct.shellWidget, theTitle);

	/*
		wait here until the user closes the dialog box
	*/
	while(!getStringStruct.setFlag)
		sufferUserInterface();

	return(getStringStruct.ok);
}



void setUpGetStringDialog(getStringStruct)
	/*
	========================================
	:purpose
		create the widgets for the get
		string dialog box
	========================================
	*/
 gsStruct *getStringStruct; 
{
	Widget	getStringPopup, getStringPane, okButton, cancelButton;
	Arg		wargs[6];
	int		n = 0;

	/*
		create a popup shell to hold the dialog box
	*/
	n = 0;
	XtSetArg(wargs[n], XtNwidth,  450); n++;
	XtSetArg(wargs[n], XtNheight, 100); n++;
	getStringStruct->shellWidget = getStringPopup = 
						XtCreatePopupShell("getStringPopup", shellWidgetClass,
											getStringStruct->parent, wargs, n);

	/*
		create a BulletinBoard widget to hold the fields
	*/
	getStringPane  = XtCreateManagedWidget("getStringPane", 
											XwbulletinWidgetClass,
											getStringPopup, NULL, 0);

	/*
		create the prompt static text field
	*/
	n = 0;
	XtSetArg(wargs[n], XtNx,		  	10);	n++;
	XtSetArg(wargs[n], XtNy,		  	10);	n++;
	XtSetArg(wargs[n], XtNwidth,	  	430);	n++;
	XtSetArg(wargs[n], XtNheight,	  	20);	n++;
	XtSetArg(wargs[n], XtNborderWidth,	0);		n++;
	XtSetArg(wargs[n], XtNstring,		"");	n++;
	getStringStruct->staticTextWidget = XtCreateManagedWidget(
								"getStringPrompt", XwstatictextWidgetClass,
								getStringPane, wargs, n);

	/*
		create the text edit field
	*/
	n = 0;
	XtSetArg(wargs[n], XtNx,      10);				n++;
	XtSetArg(wargs[n], XtNy,      40);				n++;
	XtSetArg(wargs[n], XtNwidth,  430);				n++;
	XtSetArg(wargs[n], XtNheight, 20);				n++;
	XtSetArg(wargs[n], XtNeditType, XwtextEdit);	n++;
	getStringStruct->textEditWidget = createOneLineTextEditWidget(
															"getStringTEdit", 
															getStringPane, 
															wargs, n);

    /*
        create a Cancel button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      270); n++;
    XtSetArg(wargs[n], XtNy,      70);  n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "Cancel");  n++;
    cancelButton = XtCreateManagedWidget("getStringCancelButton",
                                XwpushButtonWidgetClass,
                                getStringPane, wargs, n);

	XtAddCallback(cancelButton, XtNrelease, cancelButtonCB, getStringStruct);

    /*
        create a OK button and register a popdown callback
    */
	n = 0;
	XtSetArg(wargs[n], XtNx,      360);	n++;
	XtSetArg(wargs[n], XtNy,      70);	n++;
	XtSetArg(wargs[n], XtNwidth,  80);	n++;
	XtSetArg(wargs[n], XtNheight, 20);	n++;
	XtSetArg(wargs[n], XtNlabel,  "OK");	n++;
    okButton = XtCreateManagedWidget("getStringOkButton", 
								XwpushButtonWidgetClass,
                                getStringPane, wargs, n);

	XtAddCallback(okButton, XtNrelease, getStringOkCB, getStringStruct);
}



/****************************************************************************
	reinitialize dialog box stuff
*/
typedef struct {
    Widget          parent;
    Widget          shellWidget;
    Widget          enableButton;
	bool			setFlag;
	char			*windowTitle;
	bool			ok;

	Widget			toggleButtons[4];
} riStruct;

riStruct reinitStruct;


void reinitOkCB(w, reinitStruct, callData)
    /*
    ========================================
    :purpose
        handle the ok button on the 
		reinitialize dialog box
    ========================================
    */
 Widget         w;
 riStruct       *reinitStruct;
 caddr_t        callData;
{
	bool	set[4];
	int		theChoice;
	int i;
    Arg wargs[1];

	for (i = 0; i < 4; i++) {
		XtSetArg(wargs[0], XtNset, &set[i]);
		XtGetValues(reinitStruct->toggleButtons[i], wargs, 1);
	}

	if (set[0])
		theChoice = CURRENT_VALUES;
	else if (set[1])
		theChoice = USER_VALUES;
	else if (set[2])
		theChoice = LOAD_VALUES;
	else if (set[3])
		theChoice = DEFAULT_VALUES;
	else {
		okAlert("Please set one of the option buttons.");
		return;
	}
	
	reinitialize(theChoice);
	initGAMenus();
	eraseWindow();
	updateStatsDialog();
	updateObjectiveWindow();
	updateFitnessWindow();

    XtPopdown(reinitStruct->shellWidget);
	if (reinitStruct->enableButton) {
    	XtSetArg(wargs[0], XtNsensitive, TRUE);
    	XtSetValues(reinitStruct->enableButton, wargs, 1);
	}
}


Widget setUpReinitDialog(reinitStruct)
    /*
    ========================================
    :purpose
        create the widgets for the 
		reinitialize dialog box
    ========================================
    */
 riStruct *reinitStruct;
{
    Widget  reinitPopup, reinitPane, rc, rc1, rc2,
			staticText[4], okButton, cancelButton;
    Arg     wargs[7];
    int     n = 0;
	int		i;
	static char	*labels[] = { "Current values",
							 "User initialization values",
							 "Stored values (i.e., load from file)",
							 "Default values"
					   	   };

    /*
        create a popup shell to hold the dialog box
    */
    n = 0;
    XtSetArg(wargs[0], XtNwidth,  450); n++;
    XtSetArg(wargs[1], XtNheight, 210); n++;
    reinitStruct->shellWidget = reinitPopup =
                        XtCreatePopupShell("reinitPopup", shellWidgetClass,
                                            reinitStruct->parent, wargs, n);

    /*
        create a BulletinBoard widget to hold the fields
    */
    reinitPane  = XtCreateManagedWidget("reinitPane",
                                            XwbulletinWidgetClass,
                                            reinitPopup, NULL, 0);

    /*
        create the prompt static text field
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,            10);                     n++;
    XtSetArg(wargs[n], XtNy,            10);                     n++;
    XtSetArg(wargs[n], XtNwidth,        430);                    n++;
    XtSetArg(wargs[n], XtNheight,       40);                     n++;
    XtSetArg(wargs[n], XtNborderWidth,  0);                      n++;
    XtSetArg(wargs[n], XtNstring,       
		"Reinitialization will reset all parameters and delete the current population.  Reset using:"); n++;
    XtCreateManagedWidget("reinitPrompt", XwstatictextWidgetClass,
                                reinitPane, wargs, n);

	/*
		create a rowColumn manager for the button and static text rcs
	*/
    n = 0;
    XtSetArg(wargs[n], XtNx,     	   10);          n++;
	XtSetArg(wargs[n], XtNy,     	   60);			 n++;
	XtSetArg(wargs[n], XtNcolumns,	   2);			 n++;
	XtSetArg(wargs[n], XtNborderWidth, 0);			 n++;
	rc = XtCreateManagedWidget("reinitRC", XwrowColWidgetClass,
								reinitPane, wargs, n);
    /*
        create a rowColumn manager for the buttons
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,           10);            n++;
    XtSetArg(wargs[n], XtNy,           60);            n++;
    XtSetArg(wargs[n], XtNmode,        XwONE_OF_MANY); n++;
    XtSetArg(wargs[n], XtNborderWidth, 0);             n++;
    XtSetArg(wargs[n], XtNcolumns,     1);             n++;
    rc1 = XtCreateManagedWidget("reinitRC1", XwrowColWidgetClass,
                                rc, wargs, n);

    /*
        create a rowColumn manager for the static text fields
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,           30);            n++;
    XtSetArg(wargs[n], XtNy,           60);            n++;
    XtSetArg(wargs[n], XtNborderWidth, 0);             n++;
    XtSetArg(wargs[n], XtNforceSize,   TRUE);          n++;
    XtSetArg(wargs[n], XtNcolumns,     1);             n++;
    rc2 = XtCreateManagedWidget("reinitRC2", XwrowColWidgetClass,
                                rc, wargs, n);


    /*
        create the toggle buttons and static text fields
    */
	for (i = 0; i < 4; i++) {
		n = 0;
    	XtSetArg(wargs[n], XtNx,      10);		n++;
    	XtSetArg(wargs[n], XtNwidth,  20);		n++;
    	XtSetArg(wargs[n], XtNheight, 20);		n++;
		XtSetArg(wargs[n], XtNtoggle, TRUE);	n++;
		XtSetArg(wargs[n], XtNlabel,  "");		n++;
		XtSetArg(wargs[n], XtNset,	  (i==0) ? TRUE : FALSE); n++;
    	reinitStruct->toggleButtons[i] = XtCreateManagedWidget(
										"toggleButton",					
										XwpushButtonWidgetClass,
                               			rc1, wargs, n);
    	n = 0;
    	XtSetArg(wargs[n], XtNx,		   100);		 n++;
    	XtSetArg(wargs[n], XtNwidth,	   300);		 n++;
    	XtSetArg(wargs[n], XtNheight,	   22);			 n++;
		XtSetArg(wargs[n], XtNstring,	   labels[i]);   n++;
		XtSetArg(wargs[n], XtNgravity,	   WestGravity); n++;
		XtSetArg(wargs[n], XtNborderWidth, 0);			 n++;
        staticText[i] = XtCreateManagedWidget(
                                        "static text",
                                        XwstaticTextWidgetClass,
                                        rc2, wargs, n);
	}


    /*
        create a Cancel button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      270); n++;
    XtSetArg(wargs[n], XtNy,      180); n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "Cancel");  n++;
    cancelButton = XtCreateManagedWidget("reinitCancelButton",
                                		XwpushButtonWidgetClass,
                                		reinitPane, wargs, n);

    XtAddCallback(cancelButton, XtNrelease, cancelButtonCB, reinitStruct);

    /*
        create a OK button and register a popdown callback
    */
    n = 0;
    XtSetArg(wargs[n], XtNx,      360); n++;
    XtSetArg(wargs[n], XtNy,      180); n++;
    XtSetArg(wargs[n], XtNwidth,  80);  n++;
    XtSetArg(wargs[n], XtNheight, 20);  n++;
    XtSetArg(wargs[n], XtNlabel,  "OK");    n++;
    okButton = XtCreateManagedWidget("reinitOkButton",
                                		XwpushButtonWidgetClass,
                                		reinitPane, wargs, n);

    XtAddCallback(okButton, XtNrelease, reinitOkCB, reinitStruct);
}



/****************************************************************************
	set up all dialog boxes
*/
void setUpDialogs() 
    /*
    ========================================
    :purpose
		set up all of the dialog boxes
    ========================================
    */
{
	extern Widget menuMgr[];
	extern WidgetList fileMenu;
	extern WidgetList controlMenu;

    setUpParamDialog();

	/*
		the following dialog boxes are used in many places by 
		different functions
	*/

	/*	set up the message dialog box */
	msgDialogStruct.parent = menuMgr[4];
	setUpMsgDialogBox(&msgDialogStruct);

	/*	set up the ok alert box */
	okAlertStruct.parent = menuMgr[0];
	setUpOkAlertBox(&okAlertStruct);

	/*  set up the yes/no alert box */
    yesNoStruct.parent = menuMgr[0];
    setUpYesNoDialogBox(&yesNoStruct);

	/*	set up the single integer entry dialog box */
	singleIntStruct.parent = menuMgr[0];
	setUpSingleIntEntryDialogBox(&singleIntStruct);

	/*	set up the single float entry dialog box */
	singleFloatStruct.parent = menuMgr[0];
	setUpSingleFloatEntryDialogBox(&singleFloatStruct);

	/*	set up get string dialog box */
	getStringStruct.parent = menuMgr[0];
	setUpGetStringDialog(&getStringStruct);

	/*
		the following dialog boxes are use by only one function
		and for only one purpose
	*/

	/*
		set up the reinitialization dialog box
	*/

	reinitStruct.parent = menuMgr[1];
	reinitStruct.enableButton = controlMenu[4];
	reinitStruct.windowTitle = "Reinitilize";
	setUpReinitDialog(&reinitStruct);
	XtAddCallback(controlMenu[4], XtNselect, popupDialogCB, &reinitStruct);
	
	/*
		set up the parameter characteristic dialog box
	*/

	createParamCharDialog(parameterCharacteristicsPB, menuMgr[1]);
}



void nameDialogs() 
    /*
    ========================================
    :purpose
        give the dialog boxes a name
    ========================================
    */
{
	nameWindow(paramDialogTopLevel, "Control Parameters");
}

