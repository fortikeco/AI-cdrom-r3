/************************************************************
;                                                           *
;  William M. Spears					    *
;  Navy Center for Applied Research in AI                   *
;  Naval Research Laboratory                                *
;                                                           *
;  This software is the property of the Department of the   *
;  Navy. Permission is hereby granted to copy all or any    *
;  part of this program for free distribution, however      *
;  this header is required on all copies.		    *
;                                                           *
; File: term.c                                              *
;************************************************************/

#include "header.h"

/* Return true if the GA should terminate. One can define
   lots of different termination functions, based on the
   number of evaluations, convergence, etc...*/

int termination () { return(best == solution); }
