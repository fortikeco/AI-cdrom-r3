/************************************************************
;                                                           *
;  William M. Spears					    *
;  Navy Center for Applied Research in AI                   *
;  Naval Research Laboratory                                *
;                                                           *
;  This software is the property of the Department of the   *
;  Navy. Permission is hereby granted to copy all or any    *
;  part of this program for free distribution, however      *
;  this header is required on all copies.		    *
;                                                           *
; File: main.c                                              *
;************************************************************/

/* Called with "gac pop_size string_length number_of_cross_over_points
                    number_of_experiments file" */

main(argc, argv)
int argc;
char *argv[];
{
	srandom(atoi(argv[1]));
	run(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]),
	         atoi(argv[4]), argv[5]);
}
