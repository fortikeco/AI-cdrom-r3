/************************************************************
;                                                           *
;  William M. Spears					    *
;  Navy Center for Applied Research in AI                   *
;  Naval Research Laboratory                                *
;                                                           *
;  This software is the property of the Department of the   *
;  Navy. Permission is hereby granted to copy all or any    *
;  part of this program for free distribution, however      *
;  this header is required on all copies.		    *
;                                                           *
; File: select.c                                            *
;************************************************************/

#include "header.h"

/* Standard Baker's SUS algorithm */

void ga_select ()
{
   int i, count;
   double r;
   double ssrand();

   i = 1;
   count = 1;
   r = ssrand();
   loop:
   if (r < f[i]) {
	sh[count] = i;
	r = r + 1.0;
	count++;
	goto loop;
   }
   else if (count <= size) { i++; goto loop; }
}
