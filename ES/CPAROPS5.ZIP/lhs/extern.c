
/****************************************************************************
 *
 * MODULE:  extern.c
 *
 ****************************************************************************
 *
 * Abstract:
 *    Instantiations for global variables.
 *
 ****************************************************************************
 *
 * CParaOPS5
 * Change Log:
 *    12 May 89 V2.0 Dirk Kalp
 *                   Create CParaOPS5 from ParaOPS5 4.2.
 *
 ****************************************************************************
 *
 * ParaOPS5
 * Change Log:
 *    14 Feb 89 V4.1  Dirk Kalp
 *                    Added "g_vecatt_list" to collect up all the vector
 *                    attributes so they can be represented at the end of
 *                    the assembly file. This is to support standard OPS5
 *                    print format for wmes.
 *    24 Oct 88 V4.0  Dirk Kalp
 *                    Release of ParaOPS5 Version 4.0.
 *     1 Oct 88 V3.1  Dirk Kalp
 *                    Added definitions to support OPS5 user interface cmds
 *                    "matches" and "call" given at the top level.
 *    13 Aug 88 V3.0  Dirk Kalp
 *                    Increase max CEs permitted in LHS from 64 to 256.
 *    25 May 88 V2.0  Dirk Kalp
 *                    Updated to consolidate Vax and Encore versions.
 *    15 Sep 86       Dirk Kalp
 *    19 Aug 86       Dirk Kalp
 *     9 Jul 86
 *    14 May 86
 *     1 May 86
 *    29 Apr 86
 *    16 Apr 86
 *     4 Apr 86
 *    14 Mar 86 V1.0  Dirk Kalp
 *                    Put together from previous version created by
 *                    Quei-Len Lee.
 *
 * Copyright (c) 1986, 1987, 1988, 1989 Carnegie-Mellon University
 * All rights reserved.  The CMU software License Agreement
 * specifies the terms and conditions for use and redistribution.
 *
 ****************************************************************************/


#include   "defs.h"   



FILE       *yyin;
FILE       *codeout;
FILE       *fp_root;
FILE       *fp_sub ;
FILE       *fp_incl ;
int        SourceLineNum;
int        debug;
int        debugnet;
csw_struct csw;




symptr     hashtable[HASHTABSIZE];

attptr     b_attptr;
attptr     e_attptr;
attptr     free_attptr;

cname_ptr  b_cname_ptr;
cname_ptr  e_cname_ptr;

sym_attptr bucket[BUCKETSIZE];
opsnum     g_last_buc; 

int        ce_type[LAST_CE_INDEX+1];

sym_attptr g_vecatt_list;      /* Global head of list of all vector attributes. */



varptr     g_bvar;
varptr     g_cbvar;
opsnum     g_bvarnum;
opsnum     g_cbvarnum;


boolean    have_compiled_p;
boolean    flag_rhs;
boolean    have_cmprhs;
boolean    first_inst;

int 	   g_num_rete_roots;
int        g_max_rules_in_rete; /* Max number of rules in a network before it is split */

string     g_pname;
int        g_pcount;
int        g_featurecount;

nodeptr    g_root;
nodeptr    g_last;
nodeptr    g_lastbranch;

boolean    g_flag_negce;
int        g_cecount;
opsnum     g_subnum;
scalar     g_curtest;
anyatm_ptr g_anyatm;
varptr     g_curvar;
varptr     g_var;
varptr     g_cevar;
int        g_betalev;

varptr     freevar;
nodeptr    freenode;
nodeptr    freetnode;
nodeptr    freepnode;
nodeptr    freebetanode;
nodeptr    freeanynode;
anyatm_ptr free_anyatm;
tests_ptr  free_test;

sym_attptr g_opssym;
sym_attptr g_lastsym;
int        g_offset;




plist_ptr    ProductionList;   /* Provides access to each production and its beta nodes. */
plist_ptr    g_prod;           /* Collects up the beta nodes for the production being compiled. */

elist_ptr    ExternalList;     /* A list to access all the names declared as external functions. */




stkptr      stacktree;
stkptr      freestack;

linkptr     beta_testlink;
linkptr     beta_passlink;
linkptr     freelink;

int         g_label;

int         flag_ri;
int         flag_skip_son; 

int         nodeid_cnt;

int         cur_nodeid;
int         cur_betalev;

int         g_topcnt;
int         g_exitcnt;
