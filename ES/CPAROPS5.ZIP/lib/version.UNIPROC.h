
/****************************************************************************
 *
 * MODULE:  version.h
 *
 ****************************************************************************
 *
 * Abstract:
 *    This module selects the required version.
 *
 * Change Log:
 *    29 Sep 89 V5.3  Dirk Kalp
 *                    Added define for SYS_DEBUG.
 *    16 Aug 89 V5.0  Anurag Acharya
 *                    Integrated the uniprocessor version.
 *                    Added define for UNIPROC_VERSION.
 *    24 Oct 88 V4.0  Dirk Kalp
 *                    Release of ParaOPS5 Version 4.0.
 *    13 Aug 88 V3.0  Dirk Kalp
 *                    No changes.
 *    25 May 88 V2.0  Dirk Kalp
 *
 * Copyright (c) 1986, 1987, 1988 Carnegie-Mellon University
 * All rights reserved.  The CMU software License Agreement
 * specifies the terms and conditions for use and redistribution.
 *
 *
 ****************************************************************************/

/* Comment out the appropriate defines below */


/* #define  VAX_VERSION      1 */

/* #define  ENCORE_VERSION   1 */

#define  UNIPROC_VERSION  1


/* #define  MACH_SHARED_MEMORY_VERSION  1 */

/* #define  UMAX_SHARED_MEMORY_VERSION  1 */ 


/* #define  SYS_DEBUG  1 */
