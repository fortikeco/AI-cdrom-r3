#!/bin/sh
#
# Program: tkmobal
#
# This file is an automatically created shell script
# for starting the application named: tkmobal.tcl
#
# adapt the following variables to fit your
# local site:
#
# WHIS_CMD is the wish interpreter to be used
WISH_CMD=$MOBALHOME/TclTk/bin/wish
#WISH_CMD=$MOBALHOME/TclTk/tk3.6/wish
#
# Where are the TkMobal sources located ?
TK_MOBAL=$MOBALHOME/TclTk/TkMobal
#
# Where are the X, Xpm, Tcl, and Tk libraries located?
if test "$LD_LIBRARY_PATH" = ""; then
   LD_LIBRARY_PATH=/vol/X11R5/lib:/vol/X11R5/include:/vol/openwin/lib:/usr/lib:$MOBALHOME/TclTk/lib:$MOBALHOME/TclTk/lib/tk:$MOBALHOME/TclTk/lib/tcl
else
   LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$MOBALHOME/TclTk/lib:$MOBALHOME/TclTk/lib/tk:$MOBALHOME/TclTk/lib/tcl
fi
export LD_LIBRARY_PATH
#
# Where are the Tcl library files located ?
TCL_LIBRARY=$MOBALHOME/TclTk/lib/tcl
export TCL_LIBRARY
#
# Where are the Tk library files located ?
TK_LIBRARY=$MOBALHOME/TclTk/lib/tk
export TK_LIBRARY
#
#
##############################################
# Please don't change anything below this line
##############################################
#
# XF_LOAD_PATH is the path were the tcl modules
# for this application are located
if test "$XF_LOAD_PATH" = ""; then
  XF_LOAD_PATH=$TK_MOBAL:.:/usr/local/lib/
else
  XF_LOAD_PATH=$TK_MOBAL:$XF_LOAD_PATH:.:/usr/local/lib/
fi
#
#
ARGC=$#
COMMANDLINE=
while [ $ARGC -gt 0 ]; do
  C=$1
  shift
  ARGC=`expr $ARGC - 1`
  case $C in
    -xfloadpath)
      if [ $ARGC -gt 0 ]; then
        C=$1
        shift
        ARGC=`expr $ARGC - 1`
        XF_LOAD_PATH=$C:$XF_LOAD_PATH
      else
        echo "tkmobal.tcl: expected path for -xfloadpath"
        exit 2
      fi;;
    *)
      COMMANDLINE=$COMMANDLINE" "$C;;
  esac
done
#
export XF_LOAD_PATH
for p in `echo $XF_LOAD_PATH|awk 'BEGIN{RS=":"}
{print $0}'`; do
  if test -f $p/tkmobal.tcl; then 
    exec $WISH_CMD -name tkmobal -file $p/tkmobal.tcl $COMMANDLINE
  fi
  (cd $p; retrv -q tkmobal.tcl) 2>/dev/null
  if test -f $p/tkmobal.tcl; then 
    $WISH_CMD -name tkmobal -file $p/tkmobal.tcl $COMMANDLINE
    (cd $p; rm -f tkmobal.tcl) 2>/dev/null
  fi
done
echo "Could not find: tkmobal.tcl"
# eof

