/* CLIPS Version 3.1   9/18/86 */

#include <stdio.h>
#include "clips.h"
	
#define TRUE 1
#define FALSE 0
#define OFF 0
#define ON 1
#define LHS 0
#define RHS 1

#define BINDS_MATCH 1
#define BINDS_NOT_IN_COMMON 0
#define BINDS_MISMATCH -1


/************************************************************************/
/* FILE DESCRIPTOR LIST                                                 */
/*   This data structure houses the nodes which link the file id tags   */
/*   used by CLIPS external I/O functions with the appropriate streams. */
/************************************************************************/
typedef struct filelist
  {
   char *fileid;
   FILE *stream;
   struct filelist *next;
  } filelist;

typedef filelist *fileptr;

fileptr headfile = NULL;        /*Top node in the file list*/

                                                  
/******************************************/
/*   FUNCTION DECLARATIONS                */
/******************************************/
int fileiofctns();
float cl_open(),cl_close(),
    file_open(),file_close();
FILE *findfile();

/*****************************/
/* FUNCTION TYPE DEFINITIONS */
/*****************************/

   char *genalloc();
   char *getstring();
   char *make_symbol();
   struct element *get_piece();
   struct values *localbind();
   struct values *generic_compute();
   struct values *valuescopy();
   struct values *cleanvalues();
   struct lr *deletelocals();
   struct element *processnewstring();
   struct values *newnid();
   struct values *nonotsvaluescopy();
   struct values *find_other_values();
   struct values *executerhs();
   struct values *bind_execute();
   struct values *if_execute();
   struct values *while_execute();
   struct lr *process_binds();
   struct values *runknown();
   float rfloat();
   struct fact *assertx();
   struct fact *assert();
   struct values *get_b_or_n();
   struct values *mult_bind();

/*********************************************************/
/* GLOBAL VARIABLES REQUIRED FOR EXTERNAL FUNCTION CALLS */
/*********************************************************/

   struct funtab *fctn_list = NULL;   /* The list of user and system    */
                                      /*  defined functions.            */
  
   struct test *new_fctn_args;

   struct values *fctn_locals;        /* The list of bound local        */
                                      /*  variables at the time the     */
                                      /*  function is called.           */

   struct values *fctn2_locals;

/*****************************************/
/* VARIABLES IMPORTED FROM PARSER MODULE */
/*****************************************/

   extern char *token;        /* Indicates the type of token.       */

   extern float TKNNUMBER;    /* Value of token if token is NUMBER. */

   extern char *TKNWORD;      /* String associated with token.      */


/***************/
/* OTHER STUFF */
/***************/

   extern struct pat_node *new_patn_list;

   struct internode *AGENDA = NULL;

   struct fact *factlist;        /* Points to the beginning fact */
                                 /* in the fact list.            */

   struct fact *last_fact;       /* Points to the last fact in   */
                                 /* the factlist.                */
   
   int watch_rules = OFF;        /* Displays fact assertions  */
                                 /* and retractions.          */
    
   int watch_facts = OFF;        /* Displays rule firings.    */

   int watch_activations = OFF;  /* Displays rule activations */
                                 /* and deactivations.        */

   int EXECUTION_ERROR;

   int NID = -2;

   int AGENDA_COUNT = 0;         /* count of rules placed on agenda */
  
   int ID;                       /* Holds the value of the current */
                                 /* fact id.                       */

   int RULE_FIRE_ERROR = FALSE;
                      
   char *currentrule;

/*************************************************/
/* INIT_CLIPS: Performs initialization of CLIPS. */
/*************************************************/
init_clips()
  {
   init_streams();	  /* Initalizes streams for i/o.       */
   init_hash();           /* Initializes the hash table.       */
   init_keywords();       /* Sets up key word definitions.     */
   sysdep_inits();        /* System dependent initializations. */
   createinitial();       /* Sets up the initial-fact.         */
   sysfctns();            /* Define system functions.          */
   usrfuncs();            /* Define user functions.            */
  }

/**************************************************************/
/* RUN: Begins execution of rules.  If run limit is less than */
/*   zero, then rules will be executed until the agenda  is   */
/*   empty.  If run limit is greater than zero, then rules    */
/*   will be executed until either the agenda is empty or the */
/*   run limit has been reached.  Returns the number of rules */
/*   fired.                                                   */
/**************************************************************/
run(run_limit)
  int run_limit;
  {
   extern struct internode *AGENDA;
   extern int watch_rules, watch_facts;

   struct comm *commands;
   struct values *local_vars;
   struct internode *rule_to_fire;
   int fire_count = 0;
   int rules_fired = 0;

   /*=================================================*/
   /* Fire rules until the agenda is empty or the run */
   /* limit has been reached.                         */
   /*=================================================*/
   
   RULE_FIRE_ERROR = FALSE;

   while ((AGENDA != NULL) && (run_limit != 0) &&
          (RULE_FIRE_ERROR == FALSE))
     {
      /*==========================*/
      /* Bookkeeping and Tracing. */
      /*==========================*/
       
      currentrule = AGENDA->rhs->locals->name;
      fire_count++;
      rules_fired++;
      if (run_limit > 0) { run_limit--; }

      if (watch_rules == ON)
        {         
         sprintf(GLOBALSTR,"FIRE %4d %s: ",fire_count,currentrule);
	 cl_print(wdisplay,GLOBALSTR);
         print_fact_basis(AGENDA->lhs->locals);
        }

      /*=============================================*/
      /* Execute the rule's right hand side actions. */
      /*=============================================*/
      
      rule_to_fire = AGENDA;
      AGENDA = AGENDA->next;
      commands = (struct comm *) rule_to_fire->rhs->next;
      local_vars = rule_to_fire->lhs->locals;
      local_vars = executerhs(commands,local_vars);

      /*========================================*/
      /* Return the agenda node to free memory. */
      /*========================================*/
      
      returnvalues(local_vars);
      rtn_lr(rule_to_fire->lhs);
      rtn_internode(rule_to_fire);      
     }

   return(rules_fired);
  }
	
/*******************************************************************/
/* drive: Drives a set of variable bindings through the join net.  */ 
/*   Input variables are join (the join in the join net being      */ 
/*   entered), binds (the set of variable bindings being passed to */
/*   the join), and enter_direction (the direction, left or right, */ 
/*   that binds are entering the join.  Drive will alter and use   */ 
/*   binds, so if the calling routine does not want binds altered, */
/*   then it should make a copy of them before calling drive.      */
/*******************************************************************/
drive(binds,join,enter_direction)
  struct lr *binds;
  struct internode *join;
  int enter_direction;
  {
   struct values *localvalues, *temp_value;
   struct lr *compare_side, *give;
   char entry_logic, opp_logic;
   int mismatch, fc_mismatch;
   struct values *single_bind, *other_locals;
   struct values *fc_binds, *ofc_binds;

   /*=======================================================*/
   /* If the link to next join is null, then the terminator */
   /* join has been reached and the rule is ready to fire.  */
   /* This join is connected to the list of actions for the */
   /* rule about to fire.  Add the rule to the agenda.      */
   /*=======================================================*/
    
   if (join->next == NULL)
     {
      addfired(join->rhs,binds);
      return(1);
     }

   /*======================================================*/
   /* If the rhs of the join uses not logic and the join   */
   /* was entered from the lhs, then the variable bindings */
   /* to be attached to the lhs must have a "counter"      */
   /* attached to them which will indicate how many of the */
   /* bindings on the rhs of join do not conflict with the */
   /* new bindings.                                        */
   /*======================================================*/

   localvalues = binds->locals;

   if ((join->rhs_log == '-') && (enter_direction == LHS))
     {
      temp_value = get_values();
      temp_value->whoset = 0;
      temp_value->state = '+';
      temp_value->value = DOLLARS;
      temp_value->name = DOLLARS;
      temp_value->next = localvalues;
     
      binds->locals = temp_value;
     }

   /*==============================================*/
   /* Store the bound variables on the appropriate */
   /* side of the join.                            */
   /*==============================================*/

   if (enter_direction == RHS)
     {
      binds->next = join->rhs;
      join->rhs = binds;
     }
   else if (enter_direction == LHS) 
     {
      binds->next = join->lhs;
      join->lhs = binds;
     }
   else
     {
      cl_print(wdialog,"*** SYSTEM ERROR ***\n");
      cl_print(wdialog,"Join entered with illegal direction number in drive\n");
      cl_exit(1);
     }
  
   /*=================================================*/
   /* Set up a group of variables to indicate which   */
   /* binds the new binds are to be compared with and */
   /* the logic of each side of the join.             */
   /*=================================================*/

   if (enter_direction == RHS)
     { 
      compare_side = join->lhs;
      opp_logic = join->lhs_log;
      entry_logic = join->rhs_log;
     }
   else
     {
      compare_side = join->rhs;
      opp_logic = join->rhs_log;
      entry_logic = join->lhs_log;
     }

   /*===================================================*/
   /* If the opposite side of the join that was entered */
   /* has positive logic, but has no binds, then no     */
   /* binds will be passed down to the next join.       */
   /*===================================================*/

   if ((opp_logic == '+') && (compare_side == NULL))
     { return(1); }

   /*===================================================*/
   /* If the opposite side of the join that was entered */
   /* is empty (no pattern or upper level join enters   */
   /* through that side), then perform the appropriate  */
   /* action for the rhs join logic.                    */
   /*===================================================*/

   if (opp_logic == 'e')
     {
      empty_drive(enter_direction,entry_logic,join,localvalues);
      return(1);
     }

   /*===================================================*/
   /* Compare each set of binds on the opposite side of */
   /* the join with the set of binds that entered this  */
   /* join.  If the binds don't mismatch, then perform  */
   /* the appropriate action for the logic of the join. */
   /*===================================================*/

   while (compare_side != NULL)
     {
      mismatch = FALSE;
      single_bind = localvalues;

      /*============================================*/
      /* Do not include the counter in the bindings */
      /* from the other side.                       */
      /*============================================*/

      if ((entry_logic == '-') && (opp_logic == '+'))
        { other_locals = compare_side->locals->next; }
      else 
        { other_locals = compare_side->locals; }

      /*========================================================*/
      /* Check to see if the bindings from both sides mismatch. */
      /*========================================================*/

      while (single_bind != NULL)
	{			      
	 if (lookup(single_bind,other_locals) != BINDS_MISMATCH)
	   { single_bind = single_bind->next; }
	 else
	   {
            single_bind = NULL;
            mismatch = TRUE;
           }
        }

      /*======================================================*/
      /* Evaluate the binds that have function call expansion */
      /* and predicate test evaluations.                      */
      /*======================================================*/

      if (enter_direction == RHS)
        { 
         fc_binds = localvalues;
         ofc_binds = other_locals;
        }
      else
        { 
         fc_binds = other_locals;
         ofc_binds = localvalues;
        }

      fc_mismatch = FALSE;
      if (mismatch == FALSE)
        {
         fc_mismatch = decision(fc_binds,ofc_binds);
         if (fc_mismatch == TRUE) { mismatch = TRUE; }
        } 

      /*=================================================*/
      /* If the bindings don't mismatch then perform the */
      /* appropriate actions.                            */
      /*=================================================*/
 
      if (mismatch == FALSE)
	{
         if ((entry_logic == '+') && (opp_logic == '+'))
           { pp_drive(enter_direction,localvalues,other_locals,join); }
         else if (entry_logic == '-')
           { pn_drive(join,compare_side); }
         else if (opp_logic = '-')
           { binds->locals->whoset++; }
        }

      compare_side = compare_side->next;
     } 

   /*====================================================*/
   /* If a join with a positive lhs and a negative rhs   */
   /* was entered from the lhs side of the join, and all */
   /* of the bindings from the rhs mismatched the lhs    */
   /* bindings (the counter on the lhs is set to zero),  */
   /* then the lhs bindings should be sent down to the   */
   /* next join along with an ID marker that indicates   */
   /* that the not pattern was satisfied.                */
   /*====================================================*/

   if ((opp_logic == '-') && (binds->locals->whoset == 0))
     {
      binds->locals->whoset = NID;
      give = get_lr();
      give->next = NULL;
      give->locals = newnid(NID);
      NID--;
      give->locals->next = valuescopy(binds->locals->next);
      if (final_decision(join,give->locals) == TRUE)
        { drive(give,join->next,LHS); }
      else
        {
         returnvalues(give->locals);
         rtn_lr(give);
        }
     }
   
   return(1); 
  }

/*********************************************************************/
/* pp_drive: Handles the entry of a set of variable bindings into    */
/*   a join which has a positive LHS entry and a positive RHS entry. */
/*********************************************************************/
pp_drive(enter_direction,entry_locals,other_locals,join)
  int enter_direction;
  struct values *entry_locals, *other_locals;
  struct internode *join;
  {
   struct lr *lhs_binds;
   struct values *bind_ptr, *rhs_binds;

   lhs_binds = get_lr();   /* bug fix 8 */
   lhs_binds->next = NULL; /* bug fix 8 */

   /*===============================================*/
   /* Get a copy of the RHS bindings and remove any */
   /* negated variable bindings.                    */
   /*===============================================*/             
   
   if (enter_direction == RHS)
     { rhs_binds = nonotsvaluescopy(entry_locals); }  /* bug fix 8 */
   else
     { rhs_binds = nonotsvaluescopy(other_locals); }  /* bug fix 8 */

   /* bind_ptr = rhs_binds->locals; */  /* bug fix 8 */

   /*===============================================*/
   /* Get the values from the LHS bindings that are */
   /* not already present in the RHS bindings.      */
   /*===============================================*/

   if (enter_direction == RHS)
     { lhs_binds->locals = find_other_values(rhs_binds,other_locals); }
   else
     { lhs_binds->locals = find_other_values(rhs_binds,entry_locals); }
         
   bind_ptr = lhs_binds->locals;      /* bug fix 8 */

   /*===============================================*/
   /* Find the last bind in the valid LHS bindings, */  /* bug fix 8 */
   /* and attach the valid RHS bindings to it.      */
   /*===============================================*/

   if (bind_ptr != NULL)
     {
      while (bind_ptr->next != NULL)
        { bind_ptr = bind_ptr->next; }
     }

   if (bind_ptr == NULL)
     { lhs_binds->locals = rhs_binds; }  /* bug fix 8 */
   else
     { bind_ptr->next = rhs_binds; }     /* bug fix 8 */

   /*====================================================*/
   /* If the composite set of binds passes all predicate */
   /* and function expansion tests, then send the set of */
   /* binds down to the next join.                       */
   /*====================================================*/

   if (final_decision(join,lhs_binds->locals) == TRUE) /* bug fix 8 */
     { drive(lhs_binds,join->next,LHS); }              /* bug fix 8 */
   else
     {
      returnvalues(lhs_binds->locals);   /* bug fix 8 */
      rtn_lr(lhs_binds);                 /* bug fix 8 */
     }

   return(1);
  }

/*********************************************************************/
/* pn_drive: Handles the entry of a set of variable bindings into    */
/*   a join which has a positive LHS entry and a negative RHS entry. */
/*********************************************************************/
pn_drive(join,lhs_binds)
  struct internode *join;
  struct lr *lhs_binds;
  {
   int not_id;
   struct internode *node;

   /*==============================================================*/ 
   /* The positive LHS entry bindings of a positive-negative join  */
   /* have a "counter" attached to them which indicates the number */
   /* of RHS entry bindings which are consistent with them. If     */
   /* no RHS bindings are consistent, then the not side has been   */
   /* satisfied, the counter will have a value of < 0 (which       */
   /* indicates the id associated with the not and that there are  */
   /* no consistent bindings), and the LHS bindings will have been */
   /* sent down to the next join.  This routine handles the case   */
   /* in which a set of bindings entered the negative RHS entry of */
   /* the join and were consistent with the LHS binds.  If the     */
   /* counter for the LHS binds is less than zero, then all binds  */
   /* with that "not" id value must be removed from lower joins.   */
   /* All agenda activations with that id are also removed. If the */
   /* counter for the binds is greater than zero, then the counter */
   /* needs only to be incremented.                                */
   /*==============================================================*/ 
   
   if (lhs_binds->locals->whoset < 0)
     {
      not_id = lhs_binds->locals->whoset;
      lhs_binds->locals->whoset = 1;
      cleanagendaof(not_id);
      node = join->next;
      while (node != NULL)
        {
         node->lhs = deletelocals(not_id,node->lhs);
         node = node->next;
        }
     }
   else
     { lhs_binds->locals->whoset++; }
  }

/******************************************************/
/* empty_drive: Handles drive logic when the lhs side */
/*   of a join is empty.                              */
/******************************************************/
empty_drive(enter_direction,entry_logic,join,localvalues)
  int enter_direction;
  char entry_logic;
  struct internode *join;
  struct values *localvalues;
  {
   struct lr *give;
   int fc_mismatch;

   if (enter_direction != RHS)
     {
      cl_print(wdialog,"*** SYSTEM ERROR ***\n");
      cl_print(wdialog,"Binds not entering from rhs in empty join\n");
      cl_exit(1);
     }

   if (entry_logic == '-')
     {
      fc_mismatch = decision(localvalues,NULL);
      if (fc_mismatch == TRUE)
        { return(1); }

      cleanagendaof(join->id);
      clear_lower_lhs(join);
      return(1);
     }
   else /* entry logic is '+' */
     {
      fc_mismatch = decision(localvalues,NULL);
      if (fc_mismatch == TRUE)
        { return(1); }      

      give = get_lr();
      give->next = NULL;
      give->locals = valuescopy(localvalues);
 
      if (final_decision(join,give->locals) == TRUE)
        {
         drive(give,join->next,LHS);
        }
      else
        {
         returnvalues(give->locals);
         rtn_lr(give);
        }
      return(1);
     }
  }

/*******************************************************************/
/* final_decision:                                                 */
/*******************************************************************/
final_decision(join,binds)
  struct internode *join;
  struct values *binds;
  {
   float ppt;
   struct link *linktemp;
   struct values *cresult;

   /* perform all test conditions */
   linktemp = join->cond;
   ppt = 1.0;
   while ((linktemp != NULL) && (ppt == 1.0))
     {
      cresult = generic_compute(linktemp->hook,binds,NULL);
      if (cresult->type != NUMBER)
        { cl_print(wdialog,"*** ERROR in final_decision 1 ***\n"); }
      else
        { ppt = cresult->ivalue; }
      linktemp = linktemp->next;
     }

   if (ppt == 1.0)
     { return(TRUE); }
   else 
     { return(FALSE); }
  }

/*******************************************************************/
/* clear_lower_lhs:                                                */
/*******************************************************************/
clear_lower_lhs(join)
  struct internode *join;
  {
   struct internode *node;
   struct lr *not_binds, *temp_binds;

   node = join->next;
   while (node != NULL)
     {
      not_binds = node->lhs;
      node->lhs = NULL;
      while (not_binds != NULL)
        { 
         returnvalues(not_binds->locals);
         temp_binds = not_binds->next;
         rtn_lr(not_binds);
         not_binds = temp_binds;
        }
      node = node->next;
     }
  }

/*******************************************************************/
/* compare:                                                        */
/*******************************************************************/
compare(fact_ptr,elem_ptr,patn_ptr,epos,ppos,markers,level)
  struct fact *fact_ptr;
  struct element *elem_ptr;
  struct pat_node *patn_ptr;
  int epos, ppos;
  struct fact_marker *markers;
  int level;
  {
   struct bind_node *get_binds;
   struct lr *var_list;
   struct internode *join;
   int entry_direction;
   struct match *list_of_matches;
   struct fact_marker *new_mark;
   struct element *temp_elem;
   int end_epos, finish_match;
   struct basic *check;

  while (patn_ptr != NULL)
    {
     finish_match = FALSE;
     check = patn_ptr->check_list;

     /*==========================================================*/
     /* If there are no elements in the fact left to match, and  */
     /* the pattern element being matched against is not an end  */
     /* of pattern marker or a multiple element binder, then the */
     /* pattern matching attempt for this pattern has failed.    */
     /*==========================================================*/

     if ((elem_ptr == NULL) && 
         (check->type != STOP) &&
         (check->type != MULTIPLE) &&
         (check->type != BWORDS))
       { finish_match = TRUE; }

     /*===========================================================*/
     /* If there are elements in the fact left to match, and the  */
     /* pattern element being matched against is an end of        */
     /* pattern marker, then the fact is too long for the pattern */
     /* and pattern matching attempt has failed.                  */
     /*===========================================================*/

     if ((elem_ptr != NULL) && (check->type == STOP))
       { finish_match = TRUE; }

     /*===========================================================*/
     /* If there are no elements in the fact left to match, and   */
     /* the pattern element being matched against is an end of    */
     /* pattern marker, then the pattern has matched.             */
     /*===========================================================*/
    
     if ((elem_ptr == NULL) && (check->type == STOP))
       {
        /*=======================================================*/
        /* Add the pattern to the list of matches for this fact. */
        /*=======================================================*/
       
        list_of_matches = fact_ptr->list;
        fact_ptr->list = get_match();
        fact_ptr->list->next = list_of_matches;
        fact_ptr->list->slot = patn_ptr;

        /*==================================================*/
        /* Get the variable bindings associated with this   */
        /* pattern, and "drive" them to the joins connected */
        /* to this pattern.                                 */
        /*==================================================*/

        get_binds = patn_ptr->var_list;
        while (get_binds != NULL)
          {
           var_list = process_binds(fact_ptr,get_binds,markers);
           if (var_list != NULL)
             {
              join = get_binds->entrance->path;
              entry_direction = RHS;
	      drive(var_list,join,entry_direction);
             }
           get_binds = get_binds->next_list;
          }
        finish_match = TRUE;
       }

     /*====================================================*/
     /* Compare the pattern element with the fact element. */
     /*====================================================*/
     
     if (finish_match == TRUE)
       {
        /*==================================================*/
        /* Either the pattern failed from a test above, or  */
        /* the pattern matched.  In either case, no further */
        /* comparison for this pattern is needed.           */
        /*==================================================*/
       }
     else if (check->type == SINGLE)
       {
        /*=====================================================*/
        /* Pattern element is a '?'.  The type or value of the */ 
        /* fact element does not matter.  Proceed to the next  */ 
        /* level of the compare.                               */
        /*=====================================================*/

        compare(fact_ptr,elem_ptr->next,patn_ptr->next_level,
                   epos+1,ppos+1,markers,level+1);
       }
     else if (check->type == MULTIPLE)
       {
        /*======================================================*/
        /* Pattern element is a '$?'.  The type or value of the */ 
        /* fact element does not matter, however multiple paths */
        /* of comparison have to be followed since the '$?' can */
        /* bind to zero or more fact elements.                  */
        /*======================================================*/

        /* code deleted here */

           new_mark = get_fmarker();
           new_mark->element = ppos;
           new_mark->start = epos;
           new_mark->end = (epos - 1);
           new_mark->next = markers;
           compare(fact_ptr,elem_ptr,patn_ptr->next_level,epos,ppos+1,
                   new_mark,level+1);

           /* Consider rest of _bindings */
        
           temp_elem = elem_ptr;
           end_epos = epos;
           while (temp_elem != NULL)
             {
              new_mark->element = ppos;
              new_mark->start = epos;
              new_mark->end = end_epos;
              new_mark->next = markers;
              compare(fact_ptr,temp_elem->next,patn_ptr->next_level,
                         end_epos+1,ppos+1,new_mark,level+1);
              temp_elem = temp_elem->next;
              end_epos++;
             }
           rtn_fmarker(new_mark);
       }        
     else if ((check->type == WORD) || 
              (check->type == STRING) ||
              (check->type == NUMBER))
       {
        /*==================================================*/
        /* Pattern element is a constant.  Check that the   */
        /* fact element is the same type and value, and if  */
        /* it is then proceed to the next level of compare. */
        /*==================================================*/
        
        if (element_compare(elem_ptr,check) == TRUE)
          { 
           compare(fact_ptr,elem_ptr->next,patn_ptr->next_level,
                      epos+1,ppos+1,markers,level+1); 
          }        
       }

     patn_ptr = patn_ptr->same_level;
    }
  }

/*******************************************************************/
/* element_compare:                                                */
/*******************************************************************/
element_compare(elem_ptr,patn_ptr)
  struct element *elem_ptr;
  struct basic *patn_ptr;
  {
   int successful_match = FALSE;

   while (TRUE)
     {
      if (patn_ptr->type != elem_ptr->type)
        {
         if (patn_ptr->state == 'o')
           { successful_match = FALSE; }
         else
           { successful_match = TRUE; }
        }
      else if (((patn_ptr->type == WORD) && (elem_ptr->type == WORD)) ||
               ((patn_ptr->type == STRING) && (elem_ptr->type == STRING)))
        {
         if ((patn_ptr->state == 'o') && 
             (patn_ptr->svalue == elem_ptr->facts))
           { successful_match = TRUE; }
         else if ((patn_ptr->state == 'n') && 
                  (patn_ptr->svalue != elem_ptr->facts))
           { successful_match = TRUE; }
         else
           { successful_match = FALSE; }
        }
      else if ((patn_ptr->type == NUMBER) && (elem_ptr->type == NUMBER))
        {
         if ((patn_ptr->state == 'o') && 
             (patn_ptr->ivalue == elem_ptr->ivalue))
           { successful_match = TRUE; }
         else if ((patn_ptr->state == 'n') && 
                  (patn_ptr->ivalue != elem_ptr->ivalue))
           { successful_match = TRUE; }
         else
           { successful_match = FALSE; }
        }
      else
        { cl_print(wdialog,"Undefined case in element_compare\n"); }

      if (patn_ptr->or == NULL)
        { return(successful_match); }
      
      if ((patn_ptr->conn == 'z') || (patn_ptr->conn == ')'))
        { return(successful_match); }

      if ((patn_ptr->conn == '|') && (successful_match == TRUE))
        { return(TRUE); }

      if ((patn_ptr->conn == '&') && (successful_match == FALSE))
        { return(FALSE); }

      patn_ptr = patn_ptr->or;
     }
  }

/**********************************************************/
/* process_binds: Given a fact and the list of binds that */
/*   are to be extracted from this fact, this function    */
/*   returns the list of those binds.                     */
/**********************************************************/
struct lr *process_binds(fact_ptr,bind_list,markers)
  struct fact *fact_ptr;
  struct bind_node *bind_list;
  struct fact_marker *markers;
  {
   struct element *elem_ptr;
   int position_in_pattern, increment;
   struct lr *mtemp;
   struct values *new_bind, *last_bind;
   struct values *head = NULL;
   struct values *mult_list;

   /*========================*/
   /* System Error Checking. */
   /*========================*/
   
   if (bind_list == NULL)
     {
      cl_print(wdialog,"*** SYSTEM ERROR ***\n");
      cl_print(wdialog,"Bind list is null in process_binds\n");
      return(NULL);
     }

   /*==========================================================*/
   /* Create default bind or pattern binding.  If default bind */
   /* is the only bind, then return with that bind.            */
   /*==========================================================*/
     
   head = get_b_or_n(bind_list,fact_ptr);
   if (bind_list->start_pos == -1)
     {
      mtemp = get_lr();
      mtemp->next = NULL;
      mtemp->locals = head;
      return(mtemp);
     }
   else if (bind_list->type == BINDER)
     { bind_list = bind_list->next_bind; }

   last_bind = head;
   
   /*===================================*/
   /* Find all other variable bindings. */
   /*===================================*/
 
   position_in_pattern = 1;
   elem_ptr = fact_ptr->word; 
  
   while (bind_list != NULL)
     { 
      /*======================================================*/
      /* Position elem_ptr to point at the starting position  */
      /* of the bind in the fact.  Position_in_pattern        */ 
      /* indicates the position within the pattern on the LHS */  
      /* of the rule, which may have fewer fields than the    */
      /* fact to which it matched (because of $? and $?var).  */
      /*======================================================*/

      while (bind_list->start_pos != position_in_pattern)
        {
         increment = get_increment(markers,position_in_pattern);
         while (increment > 0)
           {        
            elem_ptr = elem_ptr->next;
            increment--;
           }
         position_in_pattern++;
        }

      /*=====================================================*/
      /* Allocate a bind structure for the variable binding. */
      /*=====================================================*/

      new_bind = get_values();
      new_bind->whoset = fact_ptr->ID;
      new_bind->name = bind_list->var_name;
      new_bind->origin = fact_ptr;
      new_bind->next = NULL;

      /*=========================================================*/
      /* Process each of the different types of binds (single    */ 
      /* field binds, multiple field binds, function expansions, */
      /* and predicate tests) as appropriate.                    */
      /*=========================================================*/

      if (bind_list->type == BWORD)
        {
         /* Process single field binds. */
         new_bind->type = elem_ptr->type;
         new_bind->state = bind_list->logic;
         if (elem_ptr->type == NUMBER)
	   { new_bind->ivalue = elem_ptr->ivalue; }
         else
           { new_bind->value = elem_ptr->facts; }
        }
      else if ((bind_list->type == FCALL) || (bind_list->type == COAMP))
        {
         /* Process function expansions and predicate test binds. */
         new_bind->type = bind_list->type;
         new_bind->state = bind_list->logic;
         new_bind->name = elem_ptr->type;
         new_bind->cond = bind_list->expression;
         if (elem_ptr->type == NUMBER)
	   { new_bind->ivalue = elem_ptr->ivalue; }
         else
           { new_bind->value = elem_ptr->facts; }
        }
      else if (bind_list->type == BWORDS)
        {
         /* Process multiple field binds. */
         new_bind->type = BWORDS;
         new_bind->state = bind_list->logic; 
         increment = get_increment(markers,position_in_pattern);
         mult_list = mult_bind(increment,fact_ptr,
                                       elem_ptr,bind_list);
         new_bind->multiple = mult_list;
        }

      /*===========================================================*/
      /* If a ?var or $?var is being bound, and this same variable */
      /* was previously bound within the same pattern, then check  */
      /* to see if the two bindings are consistent.  If the binds  */
      /* are not consistent then the pattern has not matched, and  */
      /* no bindings should be generated.                          */
      /*===========================================================*/     

      if (((bind_list->type == BWORD) || (bind_list->type == BWORDS)) &&
          (bind_list->prev_bound == TRUE) &&
          (lookup(new_bind,head) == BINDS_MISMATCH))
        {
         new_bind->next = NULL;
         returnvalues(new_bind);
         returnvalues(head);
         return(NULL);
        }

      /*=============================================================*/
      /* Add the new binds to the list of binds for this pattern.    */
      /* If a ?var or $?var was previously bound within the pattern, */
      /* then it does not have to be added to the list.              */
      /*=============================================================*/  
      
      if (bind_list->prev_bound == FALSE)
        { 
         last_bind->next = new_bind;
         last_bind = new_bind;
        }
      else
        { returnvalues(new_bind); }

      /*====================================*/
      /* Get the next bind to be processed. */
      /*====================================*/
   
      bind_list = bind_list->next_bind;
     }

   /*===========================================================*/
   /* Tack a lr structure to the list of binds and return them. */
   /*===========================================================*/

   mtemp = get_lr();
   mtemp->next = NULL;
   mtemp->locals = head;
   return(mtemp);
  }


    
/*******************************************************************/
/* mult_bind                                                       */
/*******************************************************************/
struct values *mult_bind(increment,fact_ptr,elem_ptr,bind_list)
  int increment;
  struct fact *fact_ptr;
  struct bind_node *bind_list;
  struct element *elem_ptr;
  {
   struct values *new_multiple;
   struct values *last_multiple = NULL;
   struct values *mult_list = NULL;

   while (increment > 0)
     {
      new_multiple = get_values();
      new_multiple->next = NULL;
      new_multiple->whoset = fact_ptr->ID;
      new_multiple->name = bind_list->var_name;
      new_multiple->type = elem_ptr->type;
      new_multiple->state = bind_list->logic;
      new_multiple->origin = fact_ptr;

      if (elem_ptr->type == NUMBER)
	{ new_multiple->ivalue = elem_ptr->ivalue; }
      else
        { new_multiple->value = elem_ptr->facts; }
            
      if (mult_list == NULL)
        {
         mult_list = new_multiple;
         last_multiple = new_multiple;
        }
      else
        { 
         last_multiple->next = new_multiple;
         last_multiple = new_multiple;
        }
       
      increment--;
      elem_ptr = elem_ptr->next;
     }

   return(mult_list);
  }

/***************************************************************/
/* get_b_or_n                                                  */
/***************************************************************/
struct values *get_b_or_n(bind_list,fact_ptr)
  struct fact *fact_ptr;
  struct bind_node *bind_list;
  {
   struct values *head;


   head = get_values();
   head->next = NULL;
   head->state = '$';   
   head->name = DOLLARS;
   head->whoset = fact_ptr->ID;
   head->origin = fact_ptr;
	
   if ((bind_list->start_pos != -1) &&
       (bind_list->type == BINDER))
     {
      head->type = BINDER;    /* bug fix */
      head->value = bind_list->var_name;
     }
   else 
     {
      head->type = BINDER;   /* bug fix */
      head->value = WORD;
     }
   return(head);
  }
   
/***********************************************************************/
/* get_increment                                                       */
/***********************************************************************/
get_increment(mark_ptr,position)
  struct fact_marker *mark_ptr;
  int position;
  {
   int increment = 1;

   while (mark_ptr != NULL)
     {
      if (mark_ptr->element == position)
        {
         increment = (mark_ptr->end - mark_ptr->start) + 1;
         return(increment);
        }
      else
        { mark_ptr = mark_ptr->next; }
     }
   return(increment);
  }
	
/***********************************************************************/
/* addfired: This function adds a rule activation to the AGENDA.  This */
/*   function is normally called when all the patterns on the LHS of a */
/*   rule have been satisfied.                                         */
/***********************************************************************/
addfired(rhs,binds)
  struct lr *rhs;
  struct lr *binds;
  {
   extern struct internode *AGENDA;
   extern int AGENDA_COUNT;
   int salience;
   struct internode *activation, *act_ptr, *last_act;

   /*========================================================*/
   /* Create the activation.  Store the join connected to    */ 
   /* the actions in the rhs and the list of local variables */
   /* in the lhs.                                            */
   /*========================================================*/

   activation = get_internode();
   activation->id = AGENDA_COUNT++;
   activation->rhs = rhs;
   activation->lhs = binds;
   activation->cond = NULL;
   activation->next = NULL;

   /*====================================================*/
   /* If activations are being watch, display a message. */
   /*====================================================*/

   if (watch_activations == ON)
     {
      sprintf(GLOBALSTR,"==> Activation %4d ",activation->id);
      cl_print(wdisplay,GLOBALSTR);
      sprintf(GLOBALSTR,"%s: ",activation->rhs->locals->name);
      cl_print(wdisplay,GLOBALSTR);
      print_fact_basis(binds->locals);   
     }

   /*==============================================*/
   /* Place the rule activation at the appropriate */ 
   /* place in the agenda.                         */
   /*==============================================*/

   if (AGENDA == NULL)
     {
      AGENDA = activation;
      return(1);
     }

   act_ptr = AGENDA; 
   last_act = NULL;
   salience = activation->rhs->locals->ivalue;

   while ((act_ptr != NULL) && 
          (act_ptr->rhs->locals->ivalue > salience))
     {
      last_act = act_ptr;
      act_ptr = act_ptr->next;
     }

   if (last_act == NULL)               
     {
      /* Place at the front of the agenda. */
      activation->next = AGENDA;
      AGENDA = activation;
     }
   else if (act_ptr == NULL)           
     {
      /* Place at the end of the agenda. */ 
      last_act->next = activation;
     }
   else                           
     {
      /* Place in the middle of the agenda. */
      activation->next = last_act->next;
      last_act->next = activation;
     }
  }


/************************************************************/
/* equal:  Determines if two facts are identical.  Returns  */ 
/*   TRUE (1) if identical, and FALSE (0) if not identical. */
/************************************************************/
equal(fact1,fact2)
  struct element *fact1, *fact2; 
  {
   /*==================================================*/
   /* Compare each field of both facts until the facts */
   /* match completely or the facts mismatch.          */
   /*==================================================*/

   while (TRUE)
     {
      /*=========================================*/
      /* Check that the fields are the same type */
      /* (i.e. string or float).                 */
      /*=========================================*/

      if (fact1->type != fact2->type)
        { return(FALSE); }

      /*=============================================*/
      /* Check to see that the fields match exactly. */
      /*=============================================*/

      if (fact1->type == NUMBER)
        {
         if (fact1->ivalue != fact2->ivalue)
           { return(FALSE); }
        }
      else
        {
         if (fact1->facts != fact2->facts)
           { return(FALSE); }
        }

      /*====================================*/
      /* If both facts have no more fields, */ 
      /* then they have matched exactly.    */
      /*====================================*/

      if ((fact1->next == NULL) && (fact2->next == NULL))
        { return(TRUE); }

      /*=========================================*/
      /* If one of the facts has no more fields, */
      /* then the facts do not match.            */
      /*=========================================*/

      if ((fact1->next == NULL) || (fact2->next == NULL))
        { return(FALSE); }

      /*===================================*/
      /* Get the next fields in the facts. */
      /*===================================*/

      fact1 = fact1->next;
      fact2 = fact2->next;
     } 
  }

/******************************************************************/
/* assert: Places a fact onto the end of the fact list and calls  */
/*   opnet to run the fact through the join net.  Returns null if */
/*   the fact was already in the knowledge base, and a pointer to */
/*   the fact if it was not in the knowledge base.                */
/******************************************************************/

struct fact *assertx(fact)
  struct element *fact;
  {
   extern struct fact *factlist;
   extern struct fact *last_fact;
   
   struct fact *factptr;
   extern int ID;
   extern struct pat_node *new_patn_list;
   struct fact *temp;
   int looking_for_fact = TRUE;

   temp = factlist;
   if (temp == NULL) 
     {
      temp = get_fact();
      temp->next = NULL;
      temp->list = NULL;
      temp->previous = NULL;
      temp->name = NULL;
      temp->ID = ID;
      temp->word = fact;
      last_fact = temp;
      factlist = temp;
      factptr = temp;
     }
   else
     {
      while (looking_for_fact == TRUE)
        {
	 if (equal(temp->word,fact) == 1)
	   {
            ID--;                  /* bug fix */
	    returnelements(fact);          
            return(NULL);
	   }
         else if (temp->next == NULL)
	   {
            temp->next = get_fact();
            factptr = temp;
            temp = temp->next;
	    temp->next = NULL;
	    temp->word = fact;
            temp->list = NULL;
            temp->previous = factptr;
     	    temp->ID = ID;
            temp->name = NULL;
            last_fact = temp;
            factptr = temp;
	    looking_for_fact = FALSE;
	   }
	 else
	   { temp = temp->next; }
        }
     }

   if (watch_facts == ON)
     {
      cl_print(wdisplay,"==> ");
      show_fact(factptr);
      cl_print(wdisplay,"\n");
     }

   compare(factptr,fact,new_patn_list,1,1,NULL,1);

   return(factptr);

  } /*assertx*/



/***********************************************************************/
/*exists: The purpose of this function is test to see whether or not a */
/*        fact exists in the fact list. If it does then a 0 is         */
/*        returned, else a -1 is returned for a did not match value.   */
/***********************************************************************/
	
exists(fact,list_of_facts)
  struct element *fact;
  struct fact *list_of_facts;
  {
   struct fact *ftemp;
	
   ftemp = list_of_facts;

   while (ftemp != NULL)
     {
      if (equal(fact,ftemp->word) == 1)
         { return(0); }
      else
         { ftemp = ftemp->next; }
     }

   return(-1);
  }

/********************************************************************/
/*lookup: compares the bindings                                     */
/*        returns 1 if 1 or more binding names matched              */
/*        returns 0 if no binding names in common                   */
/*        returns -1 if bindings names in common but didn't match   */
/********************************************************************/

lookup(element,list)
  struct values *list;
  struct values *element;
  {
   struct values *mlist1, *mlist2;
   int match;

   /* check only for 'o' and 'n'. '$' will pass through */
   if (((element->state == 'o') || (element->state == 'n')) &&
       (element->type != FCALL) && (element->type != COAMP))
     {
      while (list != NULL)
        {
	 if ((list->state != '+') &&
             (list->state != '-') &&
             (element->name == list->name))
	   {
            if (element->type == BWORDS)
              {
               mlist1 = element->multiple;
               mlist2 = list->multiple;
               while ((mlist1 != NULL) || (mlist2 != NULL))
                 {
                  match = single_compare(mlist1,mlist2);
                  if (match == FALSE)
                    { 
                     mlist1 = NULL;
                     mlist2 = NULL;
                    }
                  else
                    {
                     mlist1 = mlist1->next;
                     mlist2 = mlist2->next;
                    }
                 }
              }
            else
              { match = single_compare(element,list); }

            /* If one binding indicates match should be a certain */
            /* value, and the other binding indicates that match  */
            /* should not be a certain value, then reverse match  */
            /* logic.                                             */

            if (element->state != list->state)
              {
               if (match == TRUE)
                 { match = FALSE; }
               else
                 { match = TRUE; }
              }

            if (match == FALSE)
              { return(BINDS_MISMATCH); }
            else
              { return(BINDS_MATCH); }
           }
	 list = list->next;
        }/*while*/
     }

   return(BINDS_NOT_IN_COMMON);

  }/*lookup*/

/**********************************************************************/
/* single_compare:                                                    */
/**********************************************************************/
single_compare(element,list)
  struct values *element, *list;
  {
   if ((element == NULL) || (list == NULL))
     { return(FALSE); }

   if (element->type != list->type)
     { return(FALSE); }
   
   if (element->type == NUMBER)
     { 
      if (element->ivalue != list->ivalue)
	{ return(FALSE); }
      else 
        { return(TRUE); }
     }      
   else
     {
      if (element->value != list->value)
	{ return(FALSE); }
      else 
        { return(TRUE); }
     }
  }
 
/**********************************************************************/
/*cleanvalues: Removes values structures from a given list for "&~".  */
/**********************************************************************/

struct values *cleanvalues(back)
  struct values *back;
  {
   struct values *vpast, *vtemp;
   struct values *throw_away;

   vpast = NULL;
   vtemp = back;

   while (vtemp != NULL)
     {
      if (vtemp->state == 'n')
	{
	 throw_away = vtemp;
	 if (vpast == NULL)
 	   {
            back = back->next;
            vtemp = back;
           }
	 else
	   {
	    vpast->next = vtemp->next;
	    vtemp = vpast->next;
	   }
         throw_away->next = NULL; 
	 returnvalues(throw_away);   /* bug fix 6 */
	}
      else
	{
	 vpast = vtemp;
	 vtemp = vtemp->next;
        }
     }/*while*/

   return(back);
  }/*cleanvalues*/

/*******************************************************************/
/* find_other_values: the purpose of this function is to check for */
/*    duplicate values and return a list which contains none.      */
/*******************************************************************/

struct values *find_other_values(master,checker)
  struct values *master, *checker;
  {
   struct values *list, *head;
 
   head = NULL;
   list = NULL;
   while (checker != NULL)
     {
      if (lookup(checker,master) != BINDS_MATCH)
        {
         /* bug fix 8 */
         if (head == NULL)
           {
            head = get_values();
            list = head;
           }
         else
           {
            list->next = get_values();
            list = list->next;
           }
         list->name = checker->name;
         list->whoset = checker->whoset;
         list->state = checker->state;
         list->cond = checker->cond;
         list->ivalue = checker->ivalue;
         list->type = checker->type;
         list->origin = checker->origin;
         list->value = checker->value;
         list->multiple = valuescopy(checker->multiple); /* bug fix 7 */
         list->next = NULL;
        }
      checker = checker->next;
     }

   return(head);
  }

/**********************************************************************/
/*find_id: Purpose of this function is to compare the fact id number  */
/*     with those that are within the list, and return 0 if one an    */
/*     is tagged with the same id number, thus originated from that   */
/*     fact that was tagged with that same id number.                 */
/**********************************************************************/

find_id(code,values)
  int code;
  struct values *values;
  {

   while (values != NULL)
     {
      if (values->whoset == code)
        {
         if ((values->state != '+') && (values->state != '-'))
           { return(-1); }
        }
      values = values->next; 
     }
   return(0);
  }

/*******************************************************************/
/* deletelocals: Deletes a set of bindings from a list of binds if */
/*   the set has any bindings which have the ID fact_num.          */
/*******************************************************************/
struct lr *deletelocals(fact_num,list_of_binds)
  int fact_num;               /* The id number to be deleted. */
  struct lr *list_of_binds;   /* The list of bound variables. */
  {
   struct lr *head;           /* Points to the beginning of the */
                              /*   list of bound variables.     */
   struct lr *past_bind;      /* Points to the last bind considered. */
   struct lr *next_bind;    

   past_bind = NULL;
   head = list_of_binds;

   while (list_of_binds != NULL)
     {
      if (find_id(fact_num,list_of_binds->locals) != 0)
        {
         if (list_of_binds == head)
           {
            /* Delete bind at beginning of list. */
	    next_bind = list_of_binds->next;
            returnvalues(list_of_binds->locals);
            rtn_lr(list_of_binds);
	    list_of_binds = next_bind;
	    head = list_of_binds;
           }
         else
           {
            /* Delete bind after beginning of list. */
            past_bind->next = list_of_binds->next;
	    returnvalues(list_of_binds->locals);
            rtn_lr(list_of_binds);
	    list_of_binds = past_bind->next;
           }
        }
      else
        {
         past_bind = list_of_binds;
         list_of_binds = list_of_binds->next;
        }
     }
   return(head);
  }

/**********************************************************************/
/*localbind: The purpose of this function is to return the value of a */
/*           local variable that is bound inside of the net, if the   */
/*           value does not exist then the value  "$$x" is returned.  */
/*           Otherwise, the value of the variable is returned as a    */
/*           string.                                                  */
/**********************************************************************/

struct values *localbind(local,others,name)
  struct values *local, *others;
  char *name;
  {
   static struct values bind_result;

   while (local != NULL)
     {
      if ((local->state == 'o') && (name == local->name) &&
	  (local->type != FCALL) && (local->type != COAMP))
        {
	 if (local->type == NUMBER)
	   {
	    bind_result.ivalue = local->ivalue;
            bind_result.value = NUMBER;
            bind_result.type = NUMBER;
           }
         else
           {
            bind_result.ivalue = 0.0; 
            bind_result.value = local->value;
            bind_result.type = local->type; 
           }
         return(&bind_result);
        }
      else
        { local = local->next; }
     }

   /* Check the other list */
   while (others != NULL)
     {
      if ((others->state == 'o') && (name == others->name) &&
	  (others->type != FCALL) && (others->type != COAMP))
        {
	 if (others->type == NUMBER)
	   {
	    bind_result.ivalue = others->ivalue;
            bind_result.value = NUMBER;
            bind_result.type = NUMBER;
           }
         else
           { 
            bind_result.value = others->value;
            bind_result.ivalue = 0.0;
            bind_result.type = others->type; 
           }
         return(&bind_result);
        }
      else
        { others = others->next; }
     }

   sprintf(GLOBALSTR,"Variable %s not found\n",name);
   cl_print(wdialog,GLOBALSTR);
   bind_result.value = NUMBER;
   bind_result.ivalue = 0.0;
   bind_result.type = WORD;
   return(&bind_result);
  }
	
/*******************************************************************/
/* executerhs: Purpose is to execute the right hand side of a rule */
/*   given a set of commands for the rhs of the rule and a list of */
/*   local variables.  The following commands can be processed:    */ 
/*   assert, retract, printout, bind, if, while, and call.         */
/*******************************************************************/
struct values *executerhs(commands,local)
  struct comm *commands;
  struct values *local;
  {
   while ((commands != NULL) && (RULE_FIRE_ERROR == FALSE))
     {
      if (commands->value == KASSERT)
        { assert_fact(commands,local); }
      else if (commands->value == RETRACT)
        { exec_retract(commands,local); }
      else if (commands->value == KPRINTOUT)
        { printout(commands,local); }
      else if (commands->value == KFPRINTOUT)
        { fprintout(commands,local); }
      else if (commands->value == KBIND)
        { local = bind_execute(commands,local); }
      else if (commands->value == KIF)
        { local = if_execute(commands,local); }
      else if (commands->value == KWHILE)
        { local = while_execute(commands,local); }
      else if (commands->value == KCALL)
        { generic_compute(commands->cond,local,NULL); }
      else
        { cl_print(wdialog,"*** SYSTEM ERROR: executerhs ***\n"); }

      commands = commands->next;
     }
   return(local);
  }

/********************************************************************/
/* bind command                                                     */
/********************************************************************/
struct values *bind_execute(commands,local)
  struct comm *commands;
  struct values *local; 
  {
   struct values *new_bind, *result;
   struct test *bind_test;
   struct values *prev_bind, *check_bind;
   char *bind_var;

   bind_var = commands->name;
   bind_test = commands->cond;  

   result = generic_compute(bind_test,local,NULL);

   /*===========================================*/
   /* Check to see if bind for variable exists. */
   /*===========================================*/

   prev_bind = NULL;
   check_bind = local;
   while (check_bind != NULL)
     {
      if (check_bind->name == bind_var)
        {
         check_bind->type = result->type;
         check_bind->name = bind_var;
         if (result->type == NUMBER)
           { check_bind->ivalue = result->ivalue; }
         else
           { check_bind->value = getstring(result->value); }
         return(local);
        }
      prev_bind = check_bind;
      check_bind = check_bind->next;
     }

   /*===========================================*/
   /* Create new bind.                          */
   /*===========================================*/  

   new_bind = get_values();
   new_bind->next = NULL;
   new_bind->cond = NULL;
   new_bind->multiple = NULL;
   new_bind->name = bind_var;
   new_bind->state = 'o';
   
   new_bind->type = result->type;
   if (result->type == NUMBER)
     { new_bind->ivalue = result->ivalue; }
   else
     { new_bind->value = getstring(result->value); }

   if (prev_bind == NULL)
     { local = new_bind; }
   else
     { prev_bind->next = new_bind; }
   
   return(local);
  }

/********************************************************************/
/* while command                                                    */
/********************************************************************/
struct values *while_execute(commands,local)
  struct comm *commands;
  struct values *local; 
  {
   struct values *result;
   struct test *while_test;

   while_test = commands->cond;
   
   while(TRUE)
     {
      result = generic_compute(while_test,local,NULL);

      if ((result->type == NUMBER) && (result->ivalue != 0.0))
        { local = executerhs(commands->args,local); }
      else
        { return(local); }
     }
  }

/********************************************************************/
/* if command                                                       */
/********************************************************************/
struct values *if_execute(commands,local)
  struct comm *commands;
  struct values *local; 
  {
   struct values *result;
   struct test *if_test;

   if_test = commands->cond;

   result = generic_compute(if_test,local,NULL);

   if ((result->type == NUMBER) && (result->ivalue != 0.0))
     { local = executerhs(commands->args->next,local); }
   else if (commands->args->args != NULL)
     { local = executerhs(commands->args->args->next,local); }

   return(local);
  }

/********************************************************************/
/* assert command                                                   */
/********************************************************************/
assert_fact(commands,local)
  struct comm *commands;
  struct values *local;
  {
   struct element *piece, *head;
   struct values *bind;
   struct comm *step;
   struct values *chase, *margs;
   struct element *newm, *lastm;
   struct element *last_piece;
   struct values *fc_return;
   extern int ID;
    
   ID++;
   head = NULL;

   step = commands->args;   /* loop through each entry in the assert list */
   while (step != NULL)
     {
      if (step->name == FCALL)
        {
         fc_return = generic_compute(step->cond,local,NULL);
         piece = get_piece(fc_return->type,fc_return->ivalue,fc_return->value);
	}
      else if ((step->name == WORD) || (step->name == STRING) ||
               (step->name == NUMBER))
        {
         piece = get_piece(step->name,step->ivalue,step->value);
        }
      else if (step->name == BWORD)
        { 
	 bind = localbind(local,NULL,step->value);
         piece = get_piece(bind->type,bind->ivalue,bind->value); 
        }
      else if (step->name == BWORDS)
	{
	 chase = local;
	 while (chase != NULL)
           {
	    if (step->value == chase->name) 
              {
               margs = chase->multiple; 
               piece = NULL;
               lastm = NULL;
               while (margs != NULL)
                 {
                  newm = get_piece(margs->type,margs->ivalue,margs->value);
                  if (piece == NULL)
                    { piece = newm; }
                  else
                    { lastm->next = newm; }
                  lastm = newm;
                  margs = margs->next;
                 }
               chase = NULL;
	      }
            else
              { chase = chase->next; }
           }
        }
      else
        { cl_print(wdialog,"Undefined type in assert_fact\n"); }

      if (head == NULL)
        { head = piece; }
      else         
        { last_piece->next = piece; }

      while (piece != NULL)
        {
         last_piece = piece;
         piece = piece->next;
        }     

      step = step->args;
     }
   
   if (head == NULL)  
     { cl_print(wdialog,"Cannot Assert a fact with the value of NULL\n"); }
   else
     { assertx(head); }

  }

/**********************************************************************/
/* get_piece:                                                         */
/**********************************************************************/
struct element *get_piece(type,fvalue,svalue)
  char *type;
  float fvalue;
  char *svalue;
  {
   struct element *piece;

   piece = get_element();
   piece->next = NULL;
   if (type == NUMBER)
     {
      piece->type = NUMBER;
      piece->facts = NUMBER;
      piece->ivalue = fvalue;
     }
   else
     {
      piece->type = type;
      piece->facts = svalue;
      piece->ivalue = 0.0;
     }

   return(piece);
  }
	
/********************************************************************/
/* retract command                                                  */
/********************************************************************/

exec_retract(commands,bindings)
  struct comm *commands;
  struct values *bindings; 
  {
   struct comm *list_of_vars;
   struct values *chase;
   int bind_found;

   /* List_of_vars points at linked list of values that tell */
   /* which variables to retract (e.g. ?x ?y ?z).            */
   list_of_vars = commands->args;
   
   /* Process the entire list of variables. */ 
   while (list_of_vars != NULL)
     {
      /* Find binding that goes with retract variable */
      chase = bindings;
      bind_found = FALSE;
      while ((chase != NULL) && (bind_found == FALSE))
        {
         if ((chase->name == DOLLARS) &&
	     (chase->value == list_of_vars->value))
           { bind_found = TRUE; }
         else
           { chase = chase->next; }
	}

      if (chase == NULL)  
	{
         /* Binding for retract variable was not found. */
         sprintf("ERROR: attempted to retract %s ",list_of_vars->value);
         cl_print(wdialog,GLOBALSTR);
         sprintf("which was not bound on the LHS of %s\n",currentrule);
	 cl_print(wdialog,GLOBALSTR);
         return(1);
        }
      else
        {
         /* Binding for retract variable was found.  Call */
         /* retract_num was the fact id of the bound fact */
         /* and a pointer to the fact itself.             */
         retract_fact(chase->origin);
        }
 
      list_of_vars = list_of_vars->args;
     }
  } 

/**********************************************************************/
/* retract_fact:                                                      */
/**********************************************************************/
retract_fact(fact_ptr)
  struct fact *fact_ptr;  /* points to the fact in the factlist */
  {
   extern struct fact *factlist;
   int fact_num, direction;
   struct lr *nlr;
   struct fact *temp_ptr;
   struct list *ltemp;
   struct match *heads, *temp_head;
   struct internode *join;
   struct bind_node *pattern_end;

   fact_num = fact_ptr->ID;

   if (watch_facts == ON)
     {
      cl_print(wdisplay,"<== ");
      show_fact(fact_ptr);
      cl_print(wdisplay,"\n");
     }
    
   /*=====================================*/
   /* Delete the fact from the fact list. */
   /*=====================================*/

   /* Save the list of pattern matches. */
   heads = fact_ptr->list;

   if (fact_ptr->previous == NULL)
     {
      /* Delete the head of the fact list. */
      factlist = factlist->next;
      if (factlist != NULL)
        { factlist->previous = NULL; }
      returnelements(fact_ptr->word);
      rtn_fact(fact_ptr);
     }
   else
     {
      /* Delete a fact other than the head of the fact list. */
      temp_ptr = fact_ptr;
      fact_ptr->previous->next = fact_ptr->next;
      if (fact_ptr->next != NULL)
        { fact_ptr->next->previous = fact_ptr->previous; }
      returnelements(temp_ptr->word);
      rtn_fact(temp_ptr);
     }

   /*======================================================*/
   /* Go through the list of all the patterns that matched */
   /* the fact and remove the binds of that fact from the  */
   /* join net starting at the pattern's entry point into  */
   /* the join net.                                        */
   /*======================================================*/

   while (heads != NULL)
     {
      pattern_end = heads->slot->var_list;
      while (pattern_end != NULL)
        {
         ltemp = pattern_end->entrance;

	 join = ltemp->path;
	 direction = RHS;
         /* not case */
	 if (ltemp->boolean == '-')
	   {
            join = ltemp->path;

            if (join->lhs_log == 'e')
              { 
               join->rhs = deletelocals(fact_num,join->rhs);
               if (join->rhs == NULL)
                 {
                  join->id = NID;
                  nlr = get_lr();
                  nlr->next = NULL;                  
	          nlr->locals = newnid(NID);
                  NID--;
	          drive(nlr,join->next,0);
                 }
              }
            else if (join->lhs_log == '+')
              { retractpnn(join,fact_num); }
            else if (join->lhs_log == '-')
              {
               cl_print(wdialog,"SYSTEM ERROR\n");
               cl_print(wdialog,"Left hand side of a join ");
               cl_print(wdialog,"has negative logic in retract_num\n");
              }    
	   }
         else  /* positive case */
           {
           while (join->next != NULL)
	     {
	      if (direction == RHS)
	        { join->rhs = deletelocals(fact_num,join->rhs); }
	      else
	        { join->lhs = deletelocals(fact_num,join->lhs); }
	      direction = LHS;
	      join = join->next;
	     }
           }
         pattern_end = pattern_end->next_list;
        }
      temp_head = heads->next;
      rtn_match(heads); 
      heads = temp_head;
     } /*while heads*/

   cleanagendaof(fact_num);
  }
 
/********************************************************/
/* retractpnn                                           */ 
/********************************************************/
retractpnn(join,fact_num)
  struct internode *join;
  int fact_num;
  {
   struct values *other_values, *individual;
   struct lr *nlr, *chase, *check;
   int mismatch, fc_mismatch;
            
   chase = join->rhs;
   while (chase != NULL)
     {
      /* Looking for binds on - side that match fact. */ 
      if (find_id(fact_num,chase->locals) == -1)
        {
         /* Found binds that match fact. */
         check = join->lhs;
         while (check != NULL)
           {
            /* Comparing binds against other side. */
            individual = check->locals->next;
            mismatch = FALSE;
            while (individual != NULL)
              {
               if (lookup(individual,chase->locals) == -1)
                 {
                  mismatch = TRUE;
                  individual = NULL;
                 }
               else
                 { individual = individual->next; }
              }
            
            /* Check for predicate and fcall internal pattern */
            /* test mismatch.                                 */
            fc_mismatch = FALSE;
            if (mismatch == FALSE)
              {
               fc_mismatch = decision(chase->locals,check->locals->next);
               if (fc_mismatch == TRUE) { mismatch = TRUE; }
              } 

            if ((mismatch == FALSE) && (check->locals->whoset <= 0))
              { cl_print(wdialog,"logic error a in retract_num\n"); }
            if (mismatch == FALSE)
              { check->locals->whoset--; }
            if (check->locals->whoset == 0)
              {
               nlr = get_lr();
               nlr->next = NULL;
               check->locals->whoset = NID;
               nlr->locals = newnid(NID);
               NID--;
               other_values = cleanvalues(valuescopy(check->locals->next));
               nlr->locals->next = other_values;
               drive(nlr,join->next,0);
              }
            check = check->next;
           }
        }
      chase = chase->next;
     }
   join->rhs = deletelocals(fact_num,join->rhs);
  }

/********************************************************************/
/* decision                                                         */
/********************************************************************/
decision(fc_binds,other_binds)
  struct values *fc_binds, *other_binds;
  {
   int fc_mismatch = FALSE;
   struct values *start_binds, *cresult;

   start_binds = fc_binds;
   while ((fc_binds != NULL) && (fc_mismatch != TRUE))
     {
      if (fc_binds->type == FCALL)
        {
         cresult = generic_compute(fc_binds->cond,other_binds,start_binds);
         if (cresult->type != fc_binds->name)
           { fc_mismatch = TRUE; }
         else if ((cresult->type == NUMBER) && 
                  (cresult->ivalue != fc_binds->ivalue))
           { fc_mismatch = TRUE; }
         else if (cresult->value != fc_binds->value)
           { fc_mismatch = TRUE; }
         if (fc_binds->state == 'n')
           { fc_mismatch = 1 - fc_mismatch; }
        }
      else if (fc_binds->type == COAMP)
        {
         if (fc_binds->cond == NULL)
           { cl_print(wdialog,"NULL cond"); }
         cresult = generic_compute(fc_binds->cond,other_binds,start_binds);
         if (cresult->type != NUMBER)
           { fc_mismatch = TRUE; }
         else if (cresult->ivalue == 0.0)
           { fc_mismatch = TRUE; }

         if (fc_binds->state == 'n')
           { fc_mismatch = 1 - fc_mismatch; }
        }
      fc_binds = fc_binds->next;
     }
    
   return(fc_mismatch);
  }

/********************************************************************/
/* printout command                                                 */
/********************************************************************/
printout(commands,local)
  struct comm *commands;
  struct values *local; 
  { exec_print(commands->args,stdout,local); }

/*********************************************************************/
/* fprintout command                                                 */
/*********************************************************************/
fprintout(commands,local)
  struct comm *commands;
  struct values *local; 
  {
   struct comm *step;
   struct values *bind;
       
   extern FILE *findfile();  
   char dummyid[80];
   FILE *outfile;

   step = commands->args;
   if (step->name == WORD) 
     { strcpy(dummyid,step->value); }
   else 
    {
     bind = localbind(local,NULL,step->value);
     if (bind->type == NUMBER) 
       { sprintf(dummyid,"%f",bind->ivalue); }
     else if (bind->type == WORD)
       { strcpy(dummyid,bind->value); }
     else
       {
        cl_print(wdialog,"Illegal file id for PRINTOUT of ");
	sprintf(GLOBALSTR,"%s.\n",currentrule); 
	cl_print(wdialog,GLOBALSTR);
	RULE_FIRE_ERROR = TRUE;
       }
     }

   if ((outfile = findfile(dummyid,1)) == NULL)
     { 
      RULE_FIRE_ERROR = TRUE; 
      return(0.0);
     }

   step = step->args;
   exec_print(step,outfile,local);
  }


/**************************************************************/
/* exec_print                                                 */
/**************************************************************/
exec_print(step,outfile,local)
  struct comm *step;
  FILE *outfile;
  struct values *local; 
  {
   struct values *bind;
   struct values *chase, *multi_values;

   while (step != NULL)
     {
      if (step->name == WORD)
        {                           
         if (step->value == KCRLF)
           { cl_print(outfile,"\n"); }
        }
      else if (step->name == STRING)
        { cl_print(outfile,step->value); }
      else if (step->name == BWORDS)
   	{
	 chase = local;
	 while (chase != NULL)
           {
	    if (step->value == chase->name)
	      {
               multi_values = chase->multiple;
               while (multi_values != NULL)
                 {
	          if (multi_values->type == WORD)
                    { cl_print(outfile,multi_values->value); }
                  else if (multi_values->type == STRING)
                    { sprintf(GLOBALSTR,"\"%s\"",multi_values->value); 
		      cl_print(outfile,GLOBALSTR); }
	          else  /* float num fix 1 */
                    { print_num(outfile,multi_values->ivalue); }

                  if (multi_values->next != NULL)
                    { cl_print(outfile," "); }
                  multi_values = multi_values->next;
                 }
              }
	    chase = chase->next;
	   }     
        }/*BWORDS*/
      else if (step->name == BWORD)
        {
         bind = localbind(local,NULL,step->value);

         if (bind->type == NUMBER)  /* float num fix 1 */
           { print_num(outfile,bind->ivalue); }
         else if (bind->type == STRING)       /* bug fix 11 */
           { 
            sprintf(GLOBALSTR,"\"%s\"",bind->value);
            cl_print(outfile,GLOBALSTR);      /* bug fix 13 */
           }
	 else if (bind->value != NULL)
           {
             cl_print(outfile,bind->value); }
         else
           { 
            sprintf(GLOBALSTR,"%s not found in PRINTOUT of ",step->name);
	    cl_print(wdialog,GLOBALSTR);
            sprintf(GLOBALSTR,"%s\n",currentrule);                      
	    cl_print(wdialog,GLOBALSTR);
	    RULE_FIRE_ERROR = TRUE;
            return(0);
           }
        }
      else if (step->name == NUMBER) /* float num fix 1 */
        { print_num(outfile,step->ivalue); }
      else 
        { 
         sprintf(GLOBALSTR,"Unsupported option %s to PRINTOUT\n",step->name); 
         cl_print(wdialog,GLOBALSTR);
	 RULE_FIRE_ERROR = TRUE;
         return(0);
        }
      step = step->args;
     }

   return(1);
  }
                

/************************************************************/
/* print_num:  Controls printout of floating point numbers. */
/************************************************************/
print_num(outfile,number)
  float number;
  FILE *outfile;
  {
   float tempa, tempb, tempc;  /* float num fix 2 */
   int sig_dig, last_dig;    /* float num fix 2 */
   static char *digits = "0123456789";
   static char *fstr   = "%.4f";

   if (number < 0)
     { tempa = - number; }
   else
     { tempa = number; }

   if ( ((tempa > 0) && (tempa < 0.0001)) ||
        (tempa > 99999) )      /* float num fix 2 */
     { 
      sprintf(GLOBALSTR,"%6.4e",number); /* print fix 3 */
      cl_print(outfile,GLOBALSTR);      /* print fix 1 */
      return(1);
     }

   sig_dig = 0;
   last_dig = 0;
   tempb = tempa - (float) ((int) tempa);
   while ((tempb >= 0.00000001) && (sig_dig < 8))    /* float num fix 2 */
     {
      sig_dig++;
      tempb = tempb * 10;
      tempc = (float) (int) tempb;     /* float num fix 2 */
      tempb = tempb - (float) ((int) tempb);
      if (tempc != 0) { last_dig = sig_dig; }    /* float num fix 2 */
     }

   fstr[2] = digits[last_dig];

   sprintf(GLOBALSTR,fstr,number);
   cl_print(outfile,GLOBALSTR);      /* print fix 1 */

   return(1);
  }

/*********************************************************************/
/* cleanagenda: Removes all instantiations from the agenda that were */
/*   were triggered by the fact with ID fact_num.                    */
/*********************************************************************/
cleanagendaof(fact_num)
  int fact_num;
  {
   extern struct internode *AGENDA;
   struct internode *temp, *past;

   temp = AGENDA;
   past = NULL;

   while (temp != NULL)
     {
      if (find_id(fact_num,temp->lhs->locals) == -1)
        {
	 if (watch_activations == ON)
	   {
	    sprintf(GLOBALSTR,"<== Activation %4d ",temp->id);
	    cl_print(wdisplay,GLOBALSTR);
	    sprintf(GLOBALSTR,"%s: ",temp->rhs->locals->name);
	    cl_print(wdisplay,GLOBALSTR);
	    print_fact_basis(temp->lhs->locals);
	   }
         returnvalues(temp->lhs->locals);
         rtn_lr(temp->lhs);
	 temp->lhs = NULL;
	 if (past == NULL)
	   {
	    AGENDA = AGENDA->next;
	    rtn_internode(temp);
	    temp = AGENDA;
	   }
	 else
	   {
	    past->next = temp->next;
	    rtn_internode(temp);
	    temp = past->next;
	   }
	}
      else
	{
         past = temp;
         temp = temp->next;
        }
     }
  }/*cleanagendaof*/

/*****************************************************************/
/*processnewstring: The purpose of this function is to take a    */
/* given string and parse it into a element structure that       */
/* then can be used as a fact or part of a fact in the structure */
/* of this program. Presently, it is used to parse the return    */
/* value string from fctn. calls from within the ASSERT          */
/* construction.	                                         */
/*****************************************************************/

struct element *processnewstring(str)
  char *str;
  {
   int count = 0;
   float tally = 0;
   struct element *head,*etemp;
   char lm;
   int sign = 1;
   int ten = 10;
   char temp[256];
   int up = 0;

   head = NULL;
   while (str[count] != '\0')
     {
      while (((lm = str[count]) == ' ') ||
	     (lm == '\t') ||
	     (lm == '\n'))
	{ count++; }
      if (str[count] !=  '\0')
	{
         if (head == NULL)
	   {
	    head = get_element();
	    etemp = head;
	   }
         else
 	   {
	    etemp->next = get_element();
	    etemp = etemp->next;
	   }
	 if ((str[count] <= '9') && (str[count] >= '0'))
           /* PROCESS NUMBER */
	   {
	    tally = 0;
	    while (((lm = str[count]) <= '9') && (lm >= '0'))
	      {
	       count++;
	       tally = tally*10 + (lm - '0');
	      }
	    if (lm == '.')
	      {
	       count++;
	       ten = 10;
	       while (((lm = str[count]) <= '9') && (lm >= '0'))
	         {
		  count++;
		  tally = tally + ((lm - '0')/ten);
		  ten = ten*10;
		 }
	      }/*lm*/
	    etemp->ivalue = tally*sign;
            etemp->facts = NUMBER;
	    etemp->type = NUMBER;
	    sign = 1;
	   }/*<=*/
	 else if ((str[count] <= 'z') && (str[count] >= 'A'))
           /* PROCESS IDENTIFIER */
	   {
	    up = 0;
            while ((((lm = str[count]) >= 'A') && (lm <= 'z'))
	          || ((lm <= '9') && (lm >= '0'))
	          || (lm == '-'))
	      {
	       count++;
	       temp[up++] = lm;
               if (up == 256)
                 {
                  cl_print(wdialog,"Identifier longer than 255 characters\n");
                  cl_exit(1);
                 }
	      }
	    temp[up] = '\0';
	    etemp->facts = getstring(temp);
            etemp->ivalue = 0.0;
	    etemp->type = WORD;
	   }/*if*/
         else if (str[count] == '"') 
           /* PROCESS STRING */
	   {
	    up = 0;
            count++; /* skip over first paren */
            while (((lm = str[count]) != '"') && (str[count] != '\0')) 
	      {
	       count++;
	       temp[up++] = lm;
               if (up == 255)
                 {
                  cl_print(wdialog,"Identifier longer than 255 characters\n");
                  cl_exit(1);
                 }  
	      }
            count++; /* skip over last paren */
	    temp[up] = '\0';
	    etemp->facts = getstring(temp);
            etemp->ivalue = 0.0;
	    etemp->type = STRING;
	   }/*if*/
         else if (str[count] != ' ') 
           /* PROCESS SPECIAL IDENTIFIER */
	   {
	    up = 0;
            while (((lm = str[count]) != ' ') && (str[count] != '\0')) 
	      {
	       count++;
	       temp[up++] = lm;
               if (up == 256)
                 {
                  cl_print(wdialog,"Identifier longer than 255 characters\n");
                  cl_exit(1);
                 }
	      }
            temp[up] = '\0';
	    etemp->facts = getstring(temp);
            etemp->ivalue = 0.0;
	    etemp->type = WORD;
	   }/*if*/
         else
	   { count++; }
        }
     }/*while*/
   etemp->next = NULL;
   return(head);
  }/*processnewstring*/

/***************************************************************/
/* assert function                                             */
/***************************************************************/

struct fact *assert(string)
  char *string;
  {
   struct element *head;
   head = processnewstring(string);
   ID++;
   return(assertx(head));
  }

/***************************************************************/
/*print_fact_basis: Purpose is to sort a locals list and print */
/* out the fact IDs that exist in the list.                    */
/***************************************************************/

print_fact_basis(list)
  struct values *list;
  {
   /* bug fix 8 */
   while (list != NULL)
     {
      if (list->type == BINDER)
        { 
         sprintf(GLOBALSTR," f-%d ",list->whoset);
	 cl_print(wdisplay, GLOBALSTR); 
        }
      list = list->next;
     }
     
   cl_print(wdisplay,"\n");
  }

/***********************************************************/
/*newnid: Purpose is to create a new node that has the NID */
/* indicated by the argument, this node is a node of type  */
/* (struct values *). The NID is the ID number of a NOT    */
/* pattern, this node is a temporary driver node necessary */
/* for the side of the internode to satisfy a not state    */
/* condition.                     			   */
/***********************************************************/

struct values *newnid(num)
  int num;
  {
   struct values *vtemp;
   vtemp = get_values();
   vtemp->next = NULL;
   vtemp->origin = NULL;
   vtemp->name = DOLLARS;
   vtemp->value = NOT;
   vtemp->type = WORD;
   vtemp->state = '$';
   vtemp->cond = NULL;
   vtemp->multiple = NULL;
   vtemp->whoset = num;
   return(vtemp);
  }

/******************************************************************/
/*valuescopy: Purpose is to return a copy of a values structure.  */
/******************************************************************/

struct values *valuescopy(structv)
  struct values *structv;
  {
   struct values *head,*trace;
   head = NULL;
   while (structv != NULL)
     {
      if (head == NULL)
        {
	 head = get_values();
	 trace = head;
   	}
      else
 	{
	 trace->next = get_values();
	 trace = trace->next;
	}
      trace->next = NULL;
      trace->name = structv->name;
      trace->whoset = structv->whoset;
      trace->state = structv->state;
      trace->cond = structv->cond;
      trace->ivalue = structv->ivalue;
      trace->type = structv->type;
      trace->origin = structv->origin;
      trace->value = structv->value;
      /* copy multiple copies. could put a test here. */
      trace->multiple = valuescopy(structv->multiple);
      structv = structv->next;
     }
   return(head);
  }

/************************************************************************/
/*nonotsvaluescopy: Purpose is to return a copy of a values structure.  */
/************************************************************************/

struct values *nonotsvaluescopy(structv)
  struct values *structv;
  {
   struct values *head,*trace;

   head = NULL;

   while ((structv != NULL) && 
          ((structv->state == 'n') || 
           (structv->type == FCALL) ||
           (structv->type == COAMP)))
     { structv = structv->next; }

   while (structv != NULL)
     {
      if (head == NULL)
        {
	 head = get_values();
	 trace = head;
   	}
      else
 	{
	 trace->next = get_values();
	 trace = trace->next;
	}
      trace->next = NULL;
      trace->name = structv->name;
      trace->whoset = structv->whoset;
      trace->state = structv->state;
      trace->cond = structv->cond;
      trace->ivalue = structv->ivalue;
      trace->type = structv->type;
      trace->origin = structv->origin;
      trace->value = structv->value;
      trace->multiple = valuescopy(structv->multiple);
      
      structv = structv->next;
      while ((structv != NULL) && 
             ((structv->state == 'n') || 
              (structv->type == FCALL) ||
              (structv->type == COAMP)))
        { structv = structv->next; }
     }

   return(head);
  }




/********************************************************************/
/* generic_compute:                                                 */
/********************************************************************/
struct values *generic_compute(problem,locals1,locals2)
  struct test *problem;
  struct values *locals1, *locals2;
  {
   static struct values compute_result;
   struct values *bind, *vresult;
   int boolean_result;
   float result, next_result;
   char *sresult;
   struct test *arguments, *temp_arg;
   char opcode;
   struct funtab *fun_list;
   char *fun_name;

   if (problem == NULL)
     {
      cl_print(wdialog,"Problem was null\n");
      compute_result.type = NUMBER; 
      compute_result.ivalue = 1.0;
      compute_result.value = NUMBER;     
      return(&compute_result);
     }

   /*==================*/
   /* Variable Binding */
   /*==================*/

   if (problem->utype == BWORD)  /* test fix 1 */
     {
      bind = localbind(locals1,locals2,problem->utest.sval);
      compute_result.type = bind->type;
      compute_result.ivalue = bind->ivalue;
      compute_result.value = bind->value;      
      return(&compute_result);
     }

   /*========*/
   /* String */
   /*========*/

   if (problem->utype == STRING)  /* test fix 1 */
     { 
      compute_result.type = STRING;
      compute_result.value = problem->utest.sval;
      compute_result.ivalue = 0.0;    
      return(&compute_result);
     }

   /*======*/
   /* Word */
   /*======*/

   if (problem->utype == WORD)  /* test fix 1 */
     { 
      compute_result.type = WORD;
      compute_result.value = problem->utest.sval;
      compute_result.ivalue = 0.0;        
      return(&compute_result);
     }

   /*=======================*/
   /* Floating Point Number */
   /*=======================*/

   if (problem->utype == NUMBER)  /* test fix 1 */
     { 
      compute_result.type = NUMBER;
      compute_result.ivalue = problem->utest.fvalue;
      compute_result.value = NUMBER;    
      return(&compute_result);
     }

   /*===============*/
   /* Function Call */
   /*===============*/

   if (problem->utype == FCALL)     /* test fix 1 */
     {
      fctn_locals = locals1;
      fctn2_locals = locals2;
      fun_name = problem->utest.sval;

      fun_list = fctn_list;
      while ((fun_list != NULL) && (fun_name != fun_list->fun_name))
        { fun_list = fun_list->next; }

      if (fun_list == NULL)
	{ 
         cl_print(wdialog,"Missing function declaration for ");
         sprintf(GLOBALSTR,"%s\n",fun_name);
	 cl_print(wdialog,GLOBALSTR); 
         compute_result.type = NUMBER;
         compute_result.ivalue = 0.0;
         compute_result.value = NUMBER;
         RULE_FIRE_ERROR = TRUE;
         return(&compute_result);
        }

      temp_arg = new_fctn_args;
      new_fctn_args = get_test();
      new_fctn_args->utest.sval = problem->utest.sval;
      new_fctn_args->arg_list = problem->arg_list;
      new_fctn_args->next_arg = temp_arg;

      switch(fun_list->fun_type)
        {
	 case 'i' : result = (float) (*fun_list->ip)();                
                    compute_result.type = NUMBER;
                    compute_result.ivalue = result;  
                    break;
	 case 'f' : result = (*fun_list->fp)();                
                    compute_result.type = NUMBER;
                    compute_result.ivalue = result; 
                    break;
	 case 's' : sresult = (*fun_list->sp)();
                    compute_result.type = WORD;
                    compute_result.value = getstring(sresult); 
                    break;
	 case 'c' : (*fun_list->cp)(); 
                    break;
         case 'u' : vresult = (struct values *) (*fun_list->sp)();
                    if (vresult->type == NUMBER)
                      {                
                       compute_result.type = NUMBER;
                       compute_result.ivalue = vresult->ivalue;
                      }
                    else
                      {
                       compute_result.type = vresult->type;
                       compute_result.value = vresult->value;
                      }
                    break;
          
        }
      temp_arg = new_fctn_args->next_arg;
      rtn_test(new_fctn_args);
      new_fctn_args = temp_arg;
      return(&compute_result);
     }
   
   /*========================*/
   /* System Error Checking. */
   /*========================*/

   cl_print(wdialog,"*** SYSTEM ERROR ***\n");
   sprintf(GLOBALSTR,"Undefined problem type %c in generic_compute\n",problem->utype);
   cl_print(wdialog,GLOBALSTR);
   compute_result.type = NUMBER;
   compute_result.value = NUMBER;
   compute_result.ivalue = 0.0;
   return(&compute_result);
     
  }

/*************************************************************/
/* define_function: Used to define a system or user external */
/*   function so that CLIPS can access it.                   */
/*************************************************************/
define_function(name,return_type,pointer)
  char *name;
  char return_type;
  int (*pointer)();
  {
   extern struct funtab *fctn_list;

   struct funtab *new_function;
   
   new_function = new_funtab();
   new_function->fun_name = getstring(name);
   new_function->fun_type = return_type;
   new_function->next = fctn_list;
   switch(return_type)
     {
      case 'i' : new_function->ip = pointer;
                 break;
      case 'f' : new_function->fp = (float (*)()) pointer;
                 break;
      case 's' : new_function->sp = (char *(*)()) pointer;
                 break;
      case 'c' : new_function->cp = (char (*)()) pointer;
                 break;
      case 'u' : new_function->sp = (char *(*)()) pointer;
                 break;
      default  : cl_print(wdialog,"Illegal function type\n");
                 genfree(new_function,sizeof(struct funtab));
                 return(0);
                 break;
     }

   fctn_list = new_function;

   return(1);
  }

/************************************************************/
/* find_function: Returns true (1) if a function name is in */
/*   the function list, otherwise returns false (0).        */
/************************************************************/
find_function(fun_name)
  char *fun_name;
  {
   extern struct funtab *fctn_list;
   struct funtab *fun_list;

   fun_list = fctn_list;
   if (fun_list == NULL) { return(FALSE); }

   while (strcmp(fun_name,fun_list->fun_name) != 0) 
     { 
      fun_list = fun_list->next;
      if (fun_list == NULL) { return(FALSE); }
     }

   return(TRUE);
  }

/**************************************************************/
/*char rstring: Purpose is to return a pointer to a character */
/* array that represents an argument to a function call,      */
/* called by the fctn.                                        */
/**************************************************************/
char *rstring(string_pos)
  int string_pos; 
  {
   extern struct values *fctn_locals;

   int count = 1;
   struct values *result;
   struct test *arg_ptr;

   /*=====================================================*/
   /* Find the appropriate argument in the argument list. */
   /*=====================================================*/

   arg_ptr = new_fctn_args->arg_list;
   while ((arg_ptr != NULL) && (count < string_pos))
     {
      count++; 
      arg_ptr = arg_ptr->next_arg; 
     }

   if (arg_ptr == NULL)
     {
      sprintf(GLOBALSTR,"Non-existent argument #%d for function ",string_pos);
      cl_print(wdialog,GLOBALSTR);
      sprintf(GLOBALSTR,"%s requested with rfloat call\n",new_fctn_args->utest.sval);
      cl_print(wdialog,GLOBALSTR);
      EXECUTION_ERROR = TRUE;
      return(NULL);
     }

   /*=================================================*/
   /* Return the value associated with that argument. */
   /*=================================================*/

   result = generic_compute(arg_ptr,fctn_locals,fctn2_locals);
   if ((result->type != WORD) && (result->type != STRING))
     {
      sprintf(GLOBALSTR,"Non-string argument #%d found in function ",string_pos);
      cl_print(wdialog,GLOBALSTR);
      sprintf(GLOBALSTR," %s in rstring call\n",new_fctn_args->utest.sval);
      cl_print(wdialog,GLOBALSTR);
      return(NULL);
     }

   return(result->value);
  }

/**************************************************************/
/* rfloat:  Returns the nth argument of a function call. The  */
/*   argument should be a floating point number, otherwise an */
/*   error will occur.                                        */
/**************************************************************/
float rfloat(float_pos)
  int float_pos;
  {
   extern struct values *fctn_locals;

   int count = 1;
   struct values *result;
   struct test *arg_ptr;

   /*=====================================================*/
   /* Find the appropriate argument in the argument list. */
   /*=====================================================*/

   arg_ptr = new_fctn_args->arg_list;
   while ((arg_ptr != NULL) && (count < float_pos))
     {
      count++; 
      arg_ptr = arg_ptr->next_arg; 
     }

   if (arg_ptr == NULL)
     {
      sprintf(GLOBALSTR,"Non-existent argument #%d for function ",float_pos);
      cl_print(wdialog,GLOBALSTR);
      sprintf(GLOBALSTR,"%s requested with rfloat call\n",new_fctn_args->utest.sval);
      cl_print(wdialog,GLOBALSTR);
      EXECUTION_ERROR = TRUE;
      return(1.0);
     }

   /*=================================================*/
   /* Return the value associated with that argument. */
   /*=================================================*/

   result = generic_compute(arg_ptr,fctn_locals,fctn2_locals);
   if (result->type != NUMBER)
     {
      sprintf(GLOBALSTR,"Non-float argument #%d found in function ",float_pos);
      cl_print(wdialog,GLOBALSTR);
      sprintf(GLOBALSTR," %s in rfloat call\n",new_fctn_args->utest.sval);
      cl_print(wdialog,GLOBALSTR);
      return(1.0);
     }
   
   return(result->ivalue);   
  }

/********************************************************/
/* runknown: returns an argument thats type is unknown. */
/********************************************************/
struct values *runknown(arg_pos)
  int arg_pos;
  {
   extern struct values *fctn_locals;
   /* struct values *rv; */

   int count = 1;
   struct test *arg_ptr;

   /*=====================================================*/
   /* Find the appropriate argument in the argument list. */
   /*=====================================================*/

   arg_ptr = new_fctn_args->arg_list;
   while ((arg_ptr != NULL) && (count < arg_pos))
     {
      count++; 
      arg_ptr = arg_ptr->next_arg; 
     }

   if (arg_ptr == NULL)
     {
      sprintf(GLOBALSTR,"Non-existent argument #%d for function ",arg_pos);
      cl_print(wdialog,GLOBALSTR);
      sprintf(GLOBALSTR,"%s requested ",new_fctn_args->utest.sval);
      cl_print(wdialog,GLOBALSTR);
      cl_print(wdialog,"with runknown call\n");
      EXECUTION_ERROR = TRUE;
      return(NULL);
     }

   /*=================================================*/
   /* Return the value associated with that argument. */
   /*=================================================*/

   /*
   rv = generic_compute(arg_ptr,fctn_locals,fctn2_locals);
   printf("runknown type = %s\n",rv->type);
   printf("runknown value = %s\n",rv->value);
   printf("runknown ivalue = %f\n",rv->ivalue); 
   */
   return(generic_compute(arg_ptr,fctn_locals,fctn2_locals));
  }

/******************************************************************/
/* num_args: Returns the length of the argument list for a        */
/*   function call.  Useful for system and user defined functions */
/*   which accept a variable number of arguments.                 */
/******************************************************************/
num_args()
  {
   extern struct test *new_fctn_args;
   int count = 0;
   struct test *arg_ptr;

   arg_ptr = new_fctn_args->arg_list;

   while (arg_ptr != NULL)
     {
      count++; 
      arg_ptr = arg_ptr->next_arg;
     }
   
   /* printf("Number of arguments = %d\n",count); */
   return(count);
  }

/*##############################################*/
/*##############################################*/
/*######                                  ######*/
/*######     SYSTEM DEFINED FUNCTIONS     ######*/
/*######                                  ######*/
/*##############################################*/
/*##############################################*/

/****************************************/
/* do_nothing                           */
/****************************************/
float do_nothing()
  { return(1.0); }

/****************************************/
/* setgen                               */
/****************************************/

static int gen_number = 1;

float setgen()
  {
   gen_number = (int) rfloat(1);
   return( (float) gen_number);
  }

/****************************************/
/* gensym                               */
/****************************************/
char *gensym()
  {
   int needed_space = 4;
   int i, countdown, tempa, tempb;
   char *genstring;

   countdown = gen_number;

   while (countdown > 0)
     {
      needed_space++;
      countdown = countdown / 10;
     }

   genstring = (char *) genalloc(sizeof(char) * needed_space);
   genstring[0] = 'g';
   genstring[1] = 'e';
   genstring[2] = 'n';
 
   tempa = gen_number;
   for (i = (needed_space - 2) ; i > 2 ; i--)
     {
      tempb = tempa - ((tempa / 10) * 10);
      genstring[i] = '0' + tempb;
      tempa = tempa / 10;
     }

   gen_number++;
   genstring[needed_space - 1] = '\0';
   return(getstring(genstring));
  }

/****************************************/
/* read                                 */
/****************************************/
struct values *my_read()
  {
   static struct values read_value;
   int arg_no;               
   extern FILE *findfile();
   char dummyid[40];
   FILE *infile;   

   arg_no = num_args();
   if (arg_no == 0) 
     { strcpy(dummyid, "t"); }
   else if (arg_no == 1) 
     { strcpy(dummyid,rstring(1)); }
   else 
     {
      RULE_FIRE_ERROR = TRUE;
      cl_print(wdialog,"Too many arguments for read function.\n");
      read_value.type = STRING;
      read_value.value = "*** READ ERROR ***";
      return(&read_value); 
     }

   if ((infile = findfile(dummyid,0)) == NULL) 
     {
      RULE_FIRE_ERROR = TRUE;
      sprintf(GLOBALSTR,"Unable to open file with id %s.\n",dummyid);
      cl_print(wdialog, GLOBALSTR);
      read_value.type = STRING;
      read_value.value = "*** READ ERROR ***";
      return(&read_value);
     }

   gettoken(infile);
   read_value.type = token;
   if (token == NUMBER)
     { read_value.ivalue = TKNNUMBER; }
   else if ((token == STRING) || (token == WORD))
     { read_value.value = TKNWORD; }
   else if (token == STOP)
     {
      read_value.type = WORD;
      read_value.value = getstring("EOF");
     }
   else
     {
      read_value.type = STRING;
      read_value.value = "*** READ ERROR ***";
     }

   if (infile == stdin) flush_term();
   return(&read_value);
  }

/****************************************/
/* eq                                   */
/****************************************/
float my_eq()
  {
   struct values *item;
   char *type1;
   float number1;
   char *value1;
   struct values *next_item;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { return(0.0); }
   
   item = runknown(1);
   type1 = item->type;
   number1 = item->ivalue;
   value1 = item->value;

   for (i = 2 ; i <= num_a ; i++)
     {
      next_item = runknown(i);
      if (next_item->type != type1)
        { return(0.0); }
      
      if (next_item->type == NUMBER)  /* fix was here */
        { if (next_item->ivalue != number1) return(0.0); }
      else if (next_item->value != value1)
        { return(0.0); }        
     }
   
   return(1.0);
  }

/****************************************/
/* neq                                  */
/****************************************/
float my_neq()
  {
   struct values *item;
   char *type1;
   float number1;
   char *value1;
   struct values *next_item;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { return(0.0); }
   
   item = runknown(1);
   type1 = item->type;
   number1 = item->ivalue;
   value1 = item->value;

   for (i = 2 ; i <= num_a ; i++)
     {
      next_item = runknown(i);
      if (next_item->type != type1)
        { return(1.0); }
      
      if (next_item->type == NUMBER)  
        { if (next_item->ivalue == number1) return(0.0); }
      else if (next_item->value == value1)
        { return(0.0); }        
     }
   
   return(1.0);
  }

/****************************************/
/* oddp                                 */
/****************************************/
float oddp()
  {
   float f_value;
   int i_value;

   f_value = rfloat(1);
   if (((float) (int) f_value) != f_value)
     { return(0.0); }
   i_value = (int) f_value;
   if ((i_value % 2) != 0)
     { return(1.0); }
   else
     { return(0.0); }
  }

/****************************************/
/* evenp                                */
/****************************************/
float evenp()
  {
   float f_value;
   int i_value;

   f_value = rfloat(1);
   if (((float) (int) f_value) != f_value)
     { return(0.0); }
   i_value = (int) f_value;
   if ((i_value % 2) == 0)
     { return(1.0); }
   else
     { return(0.0); }
  }

/****************************************/
/* stringp                              */
/****************************************/
float stringp()
  {
   struct values *item;
   
   item = runknown(1);

   if ((item->type == WORD) || (item->type == STRING))
     { return(1.0); }
   else
     { return(0.0); }
  }

/****************************************/
/* numberp                              */
/****************************************/
float numberp()
  {
   struct values *item;
   
   item = runknown(1);

   if (item->type == NUMBER)
     { return(1.0); }
   else
     { return(0.0); }
  }

/****************************************/
/* not                                  */
/****************************************/
float my_not()
  {
   float not_value;

   not_value = rfloat(1);

   if (not_value != 0.0)
     { return(0.0); }
   else
     { return(1.0); }

  }

/****************************************/
/* and                                  */
/****************************************/
float my_and()
  {
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { return(1.0); }

   for (i = 1 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
       if (arg_value == 0.0)
        { return(0.0); }
     }
   
   return(1.0);
  }

/****************************************/
/* or                                   */
/****************************************/
float my_or()
  {
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { return(0.0); }

   for (i = 1 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
       if (arg_value != 0.0)
        { return(1.0); }
     }
   
   return(0.0);
  }

/****************************************/
/* plus                                 */
/****************************************/
float my_add()
  {
   float total;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { return(0.0); }

   total = 0.0;

   for (i = 1 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      total += arg_value;
     }
   
   return(total);
  }
 
/****************************************/
/* multiply                             */
/****************************************/
float my_mult()
  {
   float total;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { return(1.0); }

   total = 1.0;

   for (i = 1 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      total *= arg_value;
     }
   
   return(total);
  } 

/****************************************/
/* subtract                             */
/****************************************/
float my_sub()
  {
   float total;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { return(0.0); }

   total = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      total -= arg_value;
     }
   
   return(total);
  } 

/****************************************/
/* divide                               */
/****************************************/
float my_divide()
  {
   float total;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { return(1.0); }

   total = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      total /= arg_value;
     }
   
   return(total);
  } 

/****************************************/
/* less than or equal                   */
/****************************************/
float my_lteq()
  {
   float first;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a < 2.0)
     { return(1.0); }

   first = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      if (first > arg_value)
        { return(0.0); }
      first = arg_value;
     }
   
   return(1.0);
  } 

/****************************************/
/* greater than or equal                */
/****************************************/
float my_gteq()
  {
   float first;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a < 2.0)
     { return(1.0); }

   first = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      if (first < arg_value)
        { return(0.0); }
      first = arg_value;
     }
   
   return(1.0);
  } 

/****************************************/
/* less than                            */
/****************************************/
float my_lt()
  {
   float first;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a < 2.0)
     { return(1.0); }

   first = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      if (first >= arg_value)
        { return(0.0); }
      first = arg_value;
     }
   
   return(1.0);
  }
 
/****************************************/
/* greater than                         */
/****************************************/
float my_gt()
  {
   float first;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a < 2.0)
     { return(1.0); }

   first = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      if (first <= arg_value)
        { return(0.0); }
      first = arg_value;
     }
   
   return(1.0);
  }
 
/****************************************/
/* numeric equal                        */
/****************************************/
float my_num_eq()
  {
   float first;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a < 2.0)
     { return(1.0); }

   first = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      if (first != arg_value)
        { return(0.0); }
      first = arg_value;
     }
   
   return(1.0);
  } 
 
/****************************************/
/* numeric not equal                    */
/****************************************/
float my_num_neq()
  {
   float first;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a < 2.0)
     { return(1.0); }

   first = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      if (first == arg_value)
        { return(0.0); }
      first = arg_value;
     }
   
   return(1.0);
  }

/****************************************/
/* exponentiation                       */
/****************************************/
float my_pow()
  {
   float num, exp;
   float ret = 1.0;

   num = rfloat(1);
   exp = rfloat(2);

   while (exp > 0.0)
     {
      ret = ret*num;
      exp--;
     }

    return(ret);
   }

/****************************************/
/* progn                                */
/****************************************/
struct values *progn()
  {
   static struct values progn_value;
   struct values *eval_result;
   int numa, i;

   numa = num_args();

   if (numa == 0)
     {
      progn_value.type = WORD;
      progn_value.value = WORD; 
      progn_value.ivalue = 0.0;
      return(&progn_value);
     }

   i = 1;
   while (i < numa)
     {
      runknown(i); 
      i++;
     }

   eval_result = runknown(numa);
   progn_value.type = eval_result->type;
   progn_value.value = eval_result->value;
   progn_value.ivalue = eval_result->ivalue;
   return(&progn_value);
  }

/**************************************************************/
/* cl_open: This function opens a file named by the user and  */
/*   identifies it with a character string tag specified by   */
/*   the user.  This function returns a non-zero value if the */
/*   file was successfully opened.                            */
/**************************************************************/
float cl_open() 
  {
   int arg_no; 
   char *newfilename, *newfileid, *newmode;            

   /*======================================================*/
   /* Check for valid number of arguments and assignments. */
   /*======================================================*/

   arg_no = num_args();
   switch(arg_no) 
     {
      case 0  :
      case 1  : RULE_FIRE_ERROR = TRUE;
                cl_print(wdialog,"File name, id, and optional ");
                cl_print(wdialog,"mode required for open function.\n");
                return(0.0);
                break;
      case 2  : newfilename = rstring(1);
                newfileid = rstring(2);
                newmode = "r";
                break;
      case 3  : newfilename = rstring(1);
                newfileid = rstring(2);
                newmode = rstring(3);
                break;
      default : RULE_FIRE_ERROR = TRUE;
                cl_print(wdialog,"Too many arguments for open function.\n");
                return(0.0);
     }

   /*===================================*/
   /* Check for valid file access mode. */
   /*===================================*/

   if ((strcmp(newmode,"r") != 0) &&
       (strcmp(newmode,"r+") != 0) &&
       (strcmp(newmode,"w") != 0) &&
       (strcmp(newmode,"a") != 0))
     {
      RULE_FIRE_ERROR = TRUE;
      cl_print(wdialog,"Invalid mode for open function.\n");
      return(0.0); 
     }                                     

   /*======================================================*/
   /* Open named file and store it with named tag on list. */
   /*======================================================*/

   return(file_open(newfilename,newmode,newfileid));
  }

/************************************************************************/
/* file_open:  Opens a file with the specified access mode and stores   */
/*   the opened stream as well as the file id tag on the global file    */
/*   list. Returns a non-zero value if the file was succesfully opened. */
/************************************************************************/
float file_open(fname,fmode,fid) 
  char *fname,*fmode,*fid; 
  {

   FILE *newstream;
   fileptr fptr, prev;

   newstream = fopen(fname,fmode);

   /*==================================================================*/
   /* Make sure the file can be opened with the specified access mode. */
   /*==================================================================*/

   if (newstream == NULL) 
     {
      printf("Unable to open file \"%s\" with id %s.\n",fname,fid);
      return(0.0);
     }

   /*=====================================*/
   /* Add stream and file id tag to list. */
   /*=====================================*/

   if (headfile == NULL)
     {
      headfile = (struct filelist *) genalloc (sizeof (filelist));
      headfile->fileid = fid;
      headfile->stream = newstream;
      headfile->next = NULL; 
     }
   else 
     {
      fptr = headfile; 
      prev = fptr;
      while (fptr != NULL)
        {
         prev = fptr;
         fptr = fptr->next; 
        }
      fptr = (struct filelist *) genalloc (sizeof(filelist));
      fptr->fileid = fid;
      fptr->stream = newstream;
      fptr->next = NULL;
      prev->next = fptr;
     }
               
   return(1.0);
  }


/********************************************************************/
/* cl_close:  This function closes the file stream with the file id */
/*   specified by the user, if such a stream exists.  This function */
/*   returns a non-zero value if the file was successfully closed.  */
/********************************************************************/
float cl_close()
  {
   int arg_no;
   char *fileid;
                                                                    
   /*======================================================*/
   /* Check for valid number of arguments and assignments. */
   /*======================================================*/

   arg_no = num_args();
   if (arg_no == 0)
     {
      close_all();
      return(1.0);
     }
   else if (arg_no != 1)
     {
      RULE_FIRE_ERROR = TRUE;
      cl_print(wdialog,"Bad number of arguments for close function.\n");
      return(0.0);
      }

   fileid = rstring(1);

    return(file_close(fileid));
   }    

/**************************************************************/
/* close_all:  Closes all files opened the file io utilities. */
/**************************************************************/
close_all()
  {
   fileptr fptr, prev;

   fptr = headfile;

   while (fptr != NULL)
     {
      fclose(fptr->stream);
      prev = fptr;
      fptr = fptr->next;
      genfree(prev,sizeof(filelist));
     }

   headfile = NULL;

   return(1);
  }
                              
/******************************************************************/
/* file_close:  Closes a file with the specified file id tag.     */
/*   Returns a non-zero value if the file was succesfully closed. */
/******************************************************************/
float file_close(fid) 
  char *fid;
  {
   fileptr fptr, prev;

   /*=====================================================*/
   /* Locate the file with the given id in the file list. */
   /*=====================================================*/

   fptr = headfile;
   prev = NULL;

   if (fptr == NULL) { return(0.0); }

   while (strcmp(fptr->fileid,fid) != 0)
     {
      prev = fptr;
      fptr = fptr->next;
      if (fptr == NULL) 
        {
         RULE_FIRE_ERROR = TRUE;
         cl_print(wdialog,"Error: attempted to close unopened file id ");
         sprintf(GLOBALSTR,"%s.\n",fid);
         cl_print(wdialog,GLOBALSTR); 
         return(0.0);
        }
     }

   /*==================================================*/
   /* Close the file and remove it from the file list. */
   /*==================================================*/

   fclose(fptr->stream);
   if (prev == NULL)
     { headfile = fptr->next; }
   else
     { prev->next = fptr->next; }
   genfree(fptr,sizeof(filelist));

   return(1.0);
  }


/*******************************************************/
/* findfile:  Returns a pointer to a file stream for a */
/*   given file id tag.                                */
/*******************************************************/
FILE *findfile(fileid,iocode) 
  char *fileid; 
  unsigned iocode; /* IOCODE : 0 - Input; 1 - Output */
  {
   fileptr fptr;
                                                                 
   /*========================================================*/
   /* Check to see if standard input or output is requested. */
   /*========================================================*/

   if ((strcmp(fileid,"t") == 0) || (strcmp(fileid,"T") == 0))
     {
      if (iocode == 0) return(stdin);
      else return(stdout);                                   
     }

   /*=========================================================*/
   /* Otherwise, look up the file id on the global file list. */
   /*=========================================================*/
           
   fptr = headfile;
   while ((fptr != NULL) && (strcmp(fileid,fptr->fileid) != 0))
     { fptr = fptr->next; }

   if (fptr != NULL) return(fptr->stream);

   RULE_FIRE_ERROR = TRUE;
   sprintf(GLOBALSTR,"File id %s not found.\n",fileid);
   cl_print(wdialog,GLOBALSTR);
   return(NULL); 
  }

  
/*******************************************/
/* sysfctns: sets up definitions of system */
/*   defined functions.                    */
/*******************************************/
sysfctns()
  {
   float my_eq(), my_neq();
   float oddp(), evenp(), stringp(), numberp();
   float my_not(), my_and(), my_or(), my_add();
   float my_mult(), my_sub(), my_divide(), my_lteq();
   float my_gteq(), my_lt(), my_gt(), my_num_eq();
   float my_pow();
   char *gensym();
   float setgen(), do_nothing();
   struct values *read(), *progn();
   float cl_open(), cl_close();
   float my_system();

   define_function("open",'f',cl_open);
   define_function("close",'f',cl_close);  
   define_function("oddp",'f',oddp);
   define_function("evenp",'f',evenp);
   define_function("stringp",'f',stringp);
   define_function("numberp",'f',numberp);
   define_function("gensym",'s',gensym);
   define_function("read",'u',my_read);
   define_function("eq",'f',my_eq);
   define_function("neq",'f',my_neq);
   define_function("do_nothing",'f',do_nothing);
   define_function("setgen",'f',setgen);
   define_function("!",'f',my_not);
   define_function("&&",'f',my_and);
   define_function("||",'f',my_or);
   define_function("+",'f',my_add);
   define_function("*",'f',my_mult);
   define_function("-",'f',my_sub);
   define_function("/",'f',my_divide);
   define_function("<=",'f',my_lteq);
   define_function(">=",'f',my_gteq);
   define_function("<",'f',my_lt);
   define_function(">",'f',my_gt);
   define_function("=",'f',my_num_eq);
   define_function("!=",'f',my_num_neq);
   define_function("**",'f',my_pow);
   define_function("progn",'u',progn);
   define_function("system",'f',my_system);
  }

