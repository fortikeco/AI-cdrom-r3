/* CLIPS Version 3.1   9/18/86 */
 
   /*******************************************************/
   /*      "C" Language Integrated Production System      */
   /*                RULE PARSING FUNCTIONS               */
   /*******************************************************/

#include <stdio.h>
#include "clips.h"

#define TRUE 1
#define FALSE 0
#define LHS 0
#define RHS 1
#define ON 1

/************************/
/* FUNCTION DEFINITIONS */
/************************/

   struct node *reverse_or();
   struct node *copy_ao();
   struct node *cleanup();
   struct node *mod_ao_list();

   char *getstring();
   struct test *parse_test_construct();
   struct values *valuescopy();
   struct comm *processrhs();
   struct comm *prs_retract();
   struct comm *prs_printout();
   struct comm *prs_fprintout();
   struct comm *prs_p_items();
   struct comm *assert_parse();
   struct comm *bind_parse();
   struct comm *call_parse();
   struct comm *while_parse();
   struct comm *if_parse();
   struct node *lhs_parse();
   struct node *pat_parse();
   struct node *get_field();
   struct internode *construct_joins();

   struct basic *base_pattern();
   struct bind_node *get_var_binds();
   struct pat_node *place_pattern();
   struct link *test_bind_extract();
   struct node *get_or_values();
   int analyze_basics();

   FILE *fopen();

/************************/
/* VARIABLE DEFINITIONS */
/************************/
   struct pat_node *new_patn_list = NULL;
   extern char save_buffer[];

   struct ruleinfo *temp_rule;
   int PARSE_ERROR;
   int NUMBER_OF_PATTERNS;
   int DECLARATIONS_VALID;
   float glo_salience;

   extern struct fact *deflist;          
   struct fact *defptr = NULL;          /* Points to the last fact added */
                                        /*  to the global deflist.       */
   extern int ID;                       /* Holds the ID number for the   */
                                        /*  next fact to be asserted.    */
   extern char *currentrule;

 
   extern struct fact *factlist;
   struct ruleinfo *list_of_rules;      /* The list of all the rules */
                                        /*  loaded into the system.  */
   extern int watch_rules;

   int LOAD_FLAG = FALSE;
  
   FILE *source;
  
/*****************************************/    
/* VARIABLES IMPORTED FROM PARSER MODULE */
/*****************************************/

   extern char *token;          /* indicates type of token               */
   extern float TKNNUMBER;      /* value of token if token is NUMBER     */
   extern char *TKNWORD;        /* string associated with token if any   */


/*****************************************************************/
/* load_rules:  Loads the set of defrules and deffacts contained */
/*   within the file specified by file_name.                     */
/*****************************************************************/
load_rules(file_name)
  char *file_name;
  {
   extern char *token;
   extern char *TKNWORD;
   extern float TKNNUMBER;
   int error_flag;

   /* ======================================*/
   /* Open the file specified by file_name. */
   /* ======================================*/

   source = fopen(file_name,"r");
    
   if (source == NULL)
     { return(-1); }

   /*==================================================*/
   /* Parse the file until the end of file is reached. */
   /*==================================================*/
 
   error_flag = FALSE;
   gettoken(source);

   while (token != STOP)
     {

      error_flag = error_alignment(error_flag);

      if (token == STOP) { return(0); }

      if ((token == WORD) && (TKNWORD == DEFFACTS) && 
          (error_flag == FALSE))
        {
         if (parse_deffacts(source) != 0)
           { error_flag = TRUE; }
         else
           { error_flag = FALSE; }
         flush_save_buffer();
        }
      else if ((TKNWORD == DEFRULE) && (error_flag == FALSE))
        {
	 parse_rule(source);
         if (PARSE_ERROR == TRUE) 
            {
             cl_print(wdialog,"\nERROR:\n");
             cl_print(wdialog,"(defrule ");
   	     cl_print(wdialog,save_buffer);
             cl_print(wdialog,"\n");
             error_flag = TRUE;
            }
         else 
           { error_flag = FALSE; }
         flush_save_buffer();        
        }

      gettoken(source);
     }

   /*==================================================*/
   /* Print a carriage return if *'s and $'s are being */
   /* printed to indicate defrules and deffacts being  */
   /* processed.  Close the file.                      */
   /*==================================================*/
 
   if ((watch_rules == FALSE) && (LOAD_FLAG == TRUE)) 
     { cl_print(wdialog,"\n"); }

   fclose(source);

   return(0);
     
  } /* load rules */

/*************************************************************/
/* error_alignment                                           */
/*************************************************************/
error_alignment(error_flag)
  int error_flag;
  {
   char *last_token;

   last_token = STOP;

   if (error_flag == FALSE)
     {
      if (token != LPAREN)
        {
         cl_print(wdialog,"Expected left parenthesis to begin ");
         cl_print(wdialog,"defrule or deffacts statement\n");
         error_flag = TRUE;
        }
      else
        {
         gettoken(source);
         
         if ((token == WORD) && 
              (TKNWORD != DEFFACTS) && (TKNWORD != DEFRULE))
           {
            sprintf(GLOBALSTR,"Illegal construct %s\n",TKNWORD);
	    cl_print(wdialog,GLOBALSTR);
            error_flag = TRUE;
           }
         else
           {
            flush_save_buffer(); 
            return(error_flag);
           }
        }
     }

   /* Error Correction */
   while ((error_flag == TRUE) && (token != STOP))
     {
      while ((token != LPAREN) && (token != STOP))
        { gettoken(source); }
      if (token != STOP)
        { 
         gettoken(source);
         if ((token == WORD) && 
             ((TKNWORD == DEFFACTS) || (TKNWORD == DEFRULE)))
           {
            flush_save_buffer(); 
            return(FALSE);
           }
        }
     }
   if (token == STOP) { return(-1); }
   return(error_flag);
  }

/*************************************************************/
/* createinitial:  Creates the initial fact, (initial-fact), */
/*   and places it on the deffacts list.                     */
/*************************************************************/
createinitial()
  {
   extern int ID;
   extern struct fact *deflist;
   extern struct fact *defptr;

   /*==============================*/
   /* Set fact ID counter to zero. */
   /*==============================*/

   ID = 0;                           

   /*============================================================*/
   /* Create the initial fact and place it on the deffacts list. */
   /*============================================================*/
  
   deflist = get_fact();   
   deflist->next = NULL;
   deflist->list = NULL;
   deflist->name = getstring("initial-fact");
   deflist->previous = NULL;
   deflist->ID = ID;
   deflist->word = get_element();
   deflist->word->facts = getstring("initial-fact");
   deflist->word->type = WORD;
   deflist->word->next = NULL;

   /*================================================*/
   /* Set the variable which points to the last fact */
   /* added to the deffacts list.                    */
   /*================================================*/

   defptr = deflist;             
  }

/***********************************************************************/
/* parse_deffacts:  The purpose of this function is to parse the       */
/*   deffacts statement into a list of facts which can be asserted     */
/*   when a reset is performed.  The name of the deffacts block is     */
/*   saved along with each fact for use with the undeffacts statement. */
/***********************************************************************/
parse_deffacts(read_source)
  FILE *read_source;
  {
   extern int ID;
   extern char *token;
   extern char *TKNWORD;
   extern float TKNNUMBER;
   extern struct fact *defptr;
   extern int PARSE_ERROR;

   char *deffacts_name;
   struct element *first_element;
   struct element *last_element;
   struct element *next_element;
   struct fact *temp;
   
   source = read_source;
   PARSE_ERROR = FALSE;
 
   /*===========================================================*/
   /* Get next token, which should be the name of the deffacts. */
   /*===========================================================*/

   gettoken(source);
   if (token != WORD)
     { 
      cl_print(wdialog,"Missing Deffact name - fatal\n");
      PARSE_ERROR = TRUE;
      return(-1);
     }
   else
     { deffacts_name = TKNWORD; }
   
   /*==========================================================*/
   /* If watch rules is on, indicate deffacts being processed. */
   /*==========================================================*/

   if ((watch_rules == ON) && (LOAD_FLAG == TRUE))
     {
      sprintf(GLOBALSTR,"Processing deffacts block: %s\n",deffacts_name);
      cl_print(wdialog,GLOBALSTR);
     }
   else if (LOAD_FLAG == TRUE)
     { cl_print(wdialog,"$"); }

   /*=================================*/
   /* Check that next token is a '('. */
   /*=================================*/

   gettoken(source);
   if (token != LPAREN)
     {
      cl_print(wdialog,"Missing left parenthesis in ");
      sprintf(GLOBALSTR,"deffact block %s\n",deffacts_name);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      return(-1);
     }     
	  
   /*================================================*/
   /* Add all of the facts in the deffacts construct */
   /* to the deffacts list.                          */
   /*================================================*/
   
   while (TRUE)
     {
      /*===========================================*/
      /* Create a fact structure for the next fact */
      /* found in the deffacts construct.          */
      /*===========================================*/

      temp = get_fact();
      temp->list = NULL;
      temp->previous = NULL;
      temp->next = NULL;
      temp->name = deffacts_name;
      temp->word = NULL;
 
      /*=======================================================*/
      /* Create a linked list of the fields (symbols, numbers, */
      /* and strings) of the new fact.                         */
      /*=======================================================*/

      first_element = NULL;
      gettoken(source);

      while ((token == WORD) || (token == NUMBER) || (token == STRING))
	{ 
         next_element = get_element();
         next_element->next = NULL;
         next_element->type = token;
         next_element->ivalue = TKNNUMBER;
	 next_element->facts = TKNWORD; 
          
         if (first_element == NULL)
           { first_element = next_element; }
         else
           { last_element->next = next_element; }
         last_element = next_element;
         gettoken(source);           
        }

      /*=======================================================*/
      /* If the fact has no fields, then an error has occured. */
      /* Otherwise, attach the linked list of fields to the    */
      /* fact structure.                                       */
      /*=======================================================*/

      if (first_element == NULL)
        {
         sprintf(GLOBALSTR,"Null fact in deffacts block %s\n",deffacts_name);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         rtn_fact(temp);
         return(-1);
        }
      temp->word = first_element;

      /*=============================================*/
      /* If the fact was not closed with a ')', then */
      /* an error has occured.                       */
      /*=============================================*/

      if (token != RPAREN)
        {  
         cl_print(wdialog,"Missing right paren for fact in ");
         sprintf(GLOBALSTR,"deffacts %s\n",deffacts_name);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         returnelements(temp->word);
         rtn_fact(temp);
         return(-1);
        }

      /*========================================*/
      /* Add the new fact to the deffacts list. */
      /*========================================*/

      temp->previous = defptr;
      if (defptr == NULL)
        { deflist = temp; }
      else
        { defptr->next = temp; }
      defptr = temp;

      /*======================================================*/
      /* The next token must either be a ')', which indicates */
      /* the end of the deffacts construct, or a '(', which   */
      /* indicates the beginning of another fact.             */
      /*======================================================*/

      gettoken(source);
      if ((token != RPAREN) && (token != LPAREN))
        {
         cl_print(wdialog,"Missing closing right paren in ");
         sprintf(GLOBALSTR,"deffacts %s\n",deffacts_name);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         /* IMPORTANT: undeffacts(deffacts_name) */
         return(-1);
        }
      else if (token == RPAREN)    
        { return(0); }
     }
                               
   return(0);
  }

/*********************************************************************/
/* parse_rule():                                                     */
/*   This function compiles the left and right hand sides of a rule. */
/*********************************************************************/
parse_rule(read_source)
  FILE *read_source;
  {
   extern float TKNNUMBER;
   extern char *TKNWORD;
   extern char *token;
   extern char *currentrule;
   extern struct ruleinfo *list_of_rules;
   extern struct ruleinfo *temp_rule;
   struct ruleinfo *chase_rule;
   extern int PARSE_ERROR;

   struct internode *rhs_link;
   struct node *logicalrepresentation;
   struct node *convert_rep, *temp_node;
   struct internode *last_join;
   char *comment = "";
   extern float glo_salience;

   source = read_source;
   PARSE_ERROR = 0;

   /*============================================*/
   /* Next token should be the name of the rule. */
   /*============================================*/

   gettoken(source);                   
   if (token != WORD)
     { 
      cl_print(wdialog,"Missing rule name!\n");
      PARSE_ERROR = 1;
      return(-1);
     }
   currentrule = TKNWORD;

   /*=======================================================*/
   /* If rule is already in knowledge base, then remove it. */
   /*=======================================================*/

   if ((name_excise(currentrule) == 1) && (watch_rules == ON))
     { 
      sprintf(GLOBALSTR,"Removing rule %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
     }

   /*===============================================================*/
   /* If rules being watched, indicate that rule is being compiled. */
   /*===============================================================*/

   if ((watch_rules == 1) && (LOAD_FLAG == TRUE))
     {
      sprintf(GLOBALSTR,"Compiling rule: %s\n",TKNWORD);
      cl_print(wdialog,GLOBALSTR);
     }
   else if (LOAD_FLAG == TRUE)
     { cl_print(wdialog,"*"); }

   /*=================================*/
   /* Add rule name to list of rules. */
   /*=================================*/

   temp_rule = get_ruleinfo();
   temp_rule->name = getstring(currentrule);
   temp_rule->pats = NULL;
   temp_rule->next = NULL;

   /*===========================*/
   /* Get comment if it exists. */
   /*===========================*/

   gettoken(source);
   if (token == STRING)
     {
      comment = TKNWORD; 
      gettoken(source);
     }

   /*===============================================*/
   /* Begin parsing the left hand side of the rule. */
   /*===============================================*/

   /*==========================================================*/
   /* Check to see that first pattern begins with a paren or a */
   /* variable to which the pattern is to be bound.            */
   /*==========================================================*/

   if ((token != LPAREN) && (token != BWORD))
     {
      PARSE_ERROR = 1;
      cl_print(wdialog,"Expected left paren or binding after rule name\n");
      return(-1);
     }

   /*==========================================================*/
   /* Create the logical representation for the left hand side */
   /* of the rule.                                             */
   /*==========================================================*/

   glo_salience = 0.0;
   DECLARATIONS_VALID = TRUE;
   NUMBER_OF_PATTERNS = 0;
   logicalrepresentation = lhs_parse();

   if (PARSE_ERROR == TRUE)
     {
      rtn_ruleinfo(temp_rule);
      return(-1);
     }

   /*======================================================*/
   /* Check to see that NOT's appear only before patterns. */
   /*======================================================*/

   if (not_check(logicalrepresentation) == 0)
     {
      PARSE_ERROR = 1;
      cl_print(wdialog,"Only a single pattern may appear after a NOT\n");
      return(-1);
     }

   /*======================================================*/
   /* Convert logical representation to new representation */
   /* with only a single top level or.                     */
   /*======================================================*/

   convert_rep = get_node();
   convert_rep->type = KAND;
   convert_rep->svalue = KAND;
   convert_rep->bottom = NULL;
   convert_rep->right = copy_ao(logicalrepresentation);
   convert_rep = mod_ao_list(convert_rep);
   
   /*================================================*/
   /* Begin parsing the right hand side of the rule. */
   /*================================================*/
   
   /*==========================================================*/
   /* Token should be a separator on return from the functions */
   /* which parse the left hand side of a rule.                */
   /*==========================================================*/

   if (token != SEPARATOR)
      {
       sprintf(GLOBALSTR,"Found %s when expecting => in %s\n",token,currentrule);
       cl_print(wdialog,GLOBALSTR);
       PARSE_ERROR = 1;
       rtn_ruleinfo(temp_rule);
       return(-1);
      }

   /*=======================================================*/
   /* Create link which connects to the actions of the rule */
   /*=======================================================*/

   rhs_link = get_internode();          
   rhs_link->id = 0;
   rhs_link->lhs_log = '+';
   rhs_link->rhs_log = 't';
   rhs_link->cond = NULL;
   rhs_link->next = NULL;
   temp_rule->rhs_info = rhs_link;  

   /*======================================================*/
   /* Store the name of the rule and its salience value in */
   /* the right hand side of the link internode.           */
   /*======================================================*/
 
   rhs_link->next = NULL;
   rhs_link->lhs = NULL;
   rhs_link->rhs  = get_lr();
   rhs_link->rhs->locals = get_values();
   rhs_link->rhs->locals->name = currentrule;
   rhs_link->rhs->locals->value = comment;
   rhs_link->rhs->locals->ivalue = glo_salience;
   rhs_link->rhs->locals->next = NULL;
   rhs_link->rhs->locals->cond = NULL;
   rhs_link->rhs->locals->multiple = NULL;

   /*=============================================================*/
   /* Process the actions on the right hand side of the rule and  */
   /* link them to the values structure containing the rule name. */
   /*=============================================================*/

   rhs_link->rhs->next = (struct lr *) processrhs();

   if (PARSE_ERROR == TRUE) 
     {
      rtn_ruleinfo(temp_rule);
      return(-1);
     }

   if (token != RPAREN)
     {
      cl_print(wdialog,"Expected right parenthesis to finish rule\n");
      PARSE_ERROR = TRUE;
      rtn_ruleinfo(temp_rule);
      returncomms(rhs_link->rhs->next);
      return(-1);
     }
   
   /*============================*/
   /* Connect joins to patterns. */
   /*============================*/

   if (convert_rep->type == KOR)
     { 
      temp_node = convert_rep;
      convert_rep = convert_rep->right;
      temp_node->right = NULL;
      temp_node->bottom = NULL;
      returnnodes(temp_node);
     }

   while (convert_rep != NULL)
     {
      if (convert_rep->type == KAND)
        { temp_node = convert_rep->right; }
      else if (convert_rep->type == PATTERN)
        { temp_node = convert_rep; }
      else
        {
         cl_print(wdialog,"*** Conversion Error ***\n");
         cl_exit(1);
        }
 
      /* rule_analysis(temp_node); */    /* needed to analize rules */
      last_join = construct_joins(temp_node);
      if (PARSE_ERROR == TRUE) 
        {
         rtn_ruleinfo(temp_rule);
         return(-1);
        }

      /*=============================================*/
      /* Connect last join of the rule to link node. */
      /*=============================================*/

      last_join->next = rhs_link;

      temp_node = convert_rep->bottom;
      convert_rep->bottom = NULL;
      returnnodes(convert_rep);
      convert_rep = temp_node;
     }
    
   /*======================================*/
   /* Save the nice printout of the rules. */
   /*======================================*/

   temp_rule->ppinfo = logicalrepresentation;

   /*===============================================*/
   /* Rule completely parsed. Add to list of rules. */
   /*===============================================*/

   chase_rule = list_of_rules;

   if (chase_rule == NULL)
     { list_of_rules = temp_rule; }
   else
     {
      while (chase_rule->next != NULL)
        { chase_rule = chase_rule->next; }
      chase_rule->next = temp_rule;
     }

   return(0);
  }

/********************************************************************/
/* construct_joins:  Takes the logical representation of a rule and */
/*   builds the set of linked joins which represents the left hand  */
/*   side of the rule.  Returns the last join constructed which     */
/*   functions as a link between the join net and the right hand    */
/*   side actions of the rule.                                      */
/********************************************************************/
struct internode *construct_joins(log_rep)
  struct node *log_rep;      
  {
   struct link *new_test, *old_tests;
   struct internode *last_join, *join;
   struct bind_node *var_list;
   struct node *new_pattern;
   struct basic *basic_list;
   struct pat_node *join_place;
   struct link *test_list;

   last_join = NULL;

   /*=========================================================*/
   /* A pattern must be the first construct.  Test constructs */
   /* cannot be the first construct of a rule.                */
   /*=========================================================*/

   if (log_rep->type == TEST)
     {
      cl_print(wdialog,"A test construct cannot be the first pattern ");
      cl_print(wdialog,"in a rule\n");
      return(NULL);
     }

   /*=======================================================*/
   /* Process each of the patterns and/or test constructs   */
   /* of the rule.  At this point, there should be no lower */
   /* level 'and' or 'or' logic structures.                 */
   /*=======================================================*/ 
    
   while (log_rep != NULL)
     {
      /*===================================================*/
      /* Add a new join for each pattern.  Test constructs */
      /* are attached to the last join created, so a new   */
      /* join does not have to be created for them.        */
      /*===================================================*/

      if (log_rep->type != TEST)
        {
         join = get_internode();
	 join->next = NULL;
         join->cond = NULL;
	 join->lhs = NULL;
	 join->rhs = NULL;
         join->id = 0;

         if (last_join == NULL)
           { join->lhs_log = 'e'; }
         else
           {
            join->lhs_log = '+';           
	    last_join->next = join;
           }
         last_join = join;
        }

      if (log_rep->type == NOT)
	{
         /*=========================*/
         /* Process (not (pattern)) */
         /*=========================*/

	 if (log_rep->right != NULL)
	   {
	    if (log_rep->right->type == PATTERN)
	      {   
               new_pattern = log_rep->right->right;
               basic_list = base_pattern(new_pattern);
               var_list = get_var_binds(new_pattern);
               test_list = test_bind_extract(new_pattern);
               join->rhs_test = test_list;
               join->rhs_log = '-';
               join_place = place_pattern(new_patn_list,NULL,
                                          basic_list,var_list);
	       conn_pat_to_join(join,join_place,'-');
	      } 
	   }
	 else
	   { 
            cl_print(wdialog,"*** SYSTEM ERROR ***\n");
            cl_print(wdialog,"Logical NOT in construct joins\n");
            cl_exit(1);
           }
        }
      else if (log_rep->type == PATTERN)
	{
         /*===================*/
         /* Process (pattern) */
         /*===================*/

         new_pattern = log_rep->right;
         basic_list = base_pattern(new_pattern);
         var_list = get_var_binds(new_pattern);
         test_list = test_bind_extract(new_pattern);
         join->rhs_test = test_list;
         join->rhs_log = '+';
         join_place = place_pattern(new_patn_list,NULL,
                                          basic_list,var_list);
	 conn_pat_to_join(join,join_place,'+');
	}
      else if (log_rep->type == TEST)
	{
         /*======================*/
         /* Process (test (exp)) */
         /*======================*/

	 new_test = get_link();
         new_test->hook = log_rep->test;
	 new_test->next = NULL;

         if (join->cond == NULL)
           { join->cond = new_test; }
         else
           {
            old_tests = join->cond;
            while (old_tests->next != NULL)
              { old_tests = old_tests->next; }
            old_tests->next = new_test;
           }
	}
      else
        {
         /*========================*/
         /* System Error Checking. */
         /*========================*/

         cl_print(wdialog,"*** SYSTEM ERROR ***\n");
         sprintf(GLOBALSTR,"Encountered %s pattern construct ",log_rep->type);
	 cl_print(wdialog,GLOBALSTR);
         cl_print(wdialog,"in construct_joins\n");
         return(NULL);
        }

      log_rep = log_rep->bottom;
     }

   return(last_join);
  }

/**********************************************************************/
/*  lhs_parse:                                                        */
/*                                                                    */
/*  The purpose of this is to create a parse of the lhs of a rule     */
/*  construction. This calls the function <pat_parse> which parses a  */
/*  pattern slot into a structure which is then later returned as the */
/*  return value of the function. These functions are used to create  */
/*  a internal logical representation of the LHS which is then parsed */
/*  logically into patterns that are placed into the opnet structure. */
/*                                                                    */
/**********************************************************************/
struct node *lhs_parse()
  {
   extern char *token;
   extern char *currentrule;
   extern char *TKNWORD;

   struct node *head, *next_place;
   struct node *last_place;

   head = NULL;

   while (TRUE)
     {
      next_place = NULL;
      /* Check to see if we have a fact being binded to a variable. */
      if (token == BWORD)
        {
         DECLARATIONS_VALID = FALSE;
         /* If a fact is being bound, then store */
         /* the variable and parse the pattern.  */
         next_place = get_node();
         next_place->type = PATTERN;
         next_place->right = get_node();
	 next_place->right->svalue = TKNWORD;
         next_place->right->type = BINDER;

         /* Check for binder token, "<-", after variable. */
         gettoken(source);
         if (token != BINDER)
           {
            sprintf(GLOBALSTR,"Missing <- after ?%s ",next_place->right->svalue);
	    cl_print(wdialog,GLOBALSTR);
            sprintf(GLOBALSTR,"in the LHS of %s\n",currentrule);
	    cl_print(wdialog,GLOBALSTR);
            PARSE_ERROR = TRUE;
            return(NULL);
           }

         /* Check for opening left parenthesis of pattern. */ 
         gettoken(source);
         if (token != LPAREN)
           {
            sprintf(GLOBALSTR,"Missing ( after ?%s <- ",next_place->right->svalue);
	    cl_print(wdialog,GLOBALSTR);
            sprintf(GLOBALSTR,"in the LHS of %s\n",currentrule);
	    cl_print(wdialog,GLOBALSTR);
            PARSE_ERROR = TRUE;
            return(NULL);
           }
   
         gettoken(source);
         NUMBER_OF_PATTERNS++;
	 next_place->right->right = pat_parse();
         if (PARSE_ERROR == 1) return(NULL);
	}
      else if (token == LPAREN)
        {
         gettoken(source);            
         if ((token == WORD) && (TKNWORD == TEST))
	   {
            DECLARATIONS_VALID = FALSE;
            next_place = get_node();
	    next_place->type = TKNWORD;
	    next_place->test = parse_test_construct(source);
            if (PARSE_ERROR == TRUE) return(NULL);
	    next_place->right = NULL;
            gettoken(source);
	    if (token != RPAREN)
              { 
               sprintf(GLOBALSTR,"Missing ')' for test in %s\n",currentrule);
	       cl_print(wdialog,GLOBALSTR);
               PARSE_ERROR = TRUE;
               return(NULL);
              }
            gettoken(source);
	   }
         else if ((token == WORD) && (TKNWORD == KDECLARE))
           { 
            parse_salience();
            gettoken(source); 
           } 
         else if ((token == WORD) &&
	          ((TKNWORD == KAND) || (TKNWORD == KOR)  ||
	           (TKNWORD == NOT)))
	   {
            DECLARATIONS_VALID = FALSE;
            next_place = get_node();
	    next_place->type = TKNWORD;
            gettoken(source);
	    if ((token != LPAREN) && (token != BWORD))  /* bug fix 12 */
              { 
               sprintf(GLOBALSTR,"Missing '(' in %s\n",currentrule);
	       cl_print(wdialog,GLOBALSTR);
               PARSE_ERROR = TRUE;
               return(NULL);
              } 
	    next_place->right = lhs_parse();
            if (PARSE_ERROR == TRUE) return(NULL);
	    gettoken(source);
	   }
         else
           {
            DECLARATIONS_VALID = FALSE;
            next_place = get_node();
	    next_place->type = PATTERN;
            NUMBER_OF_PATTERNS++;
	    next_place->right = pat_parse();
            if (PARSE_ERROR == TRUE) return(NULL);
	   } 
        }
      else if ((token ==  SEPARATOR) || (token == RPAREN))
        { return(head); }
      else
        {
         sprintf(GLOBALSTR,"Unexpected token found on the LHS of %s\n",currentrule);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         return(NULL);
        }
      
      if (next_place != NULL)
        {
         if (head == NULL) 
           { head = next_place; }
         else
           { last_place->bottom = next_place; }
         last_place = next_place;
        }
     }
  } /* lhs_parse */

/**********************************************************************/
/*   pat_parse:                                                       */
/*                                                                    */
/*  Reads in one pattern structure and returns a pointer to           */
/* the pattern. It first checks to see if each element is proceeded by*/
/* a "~", if it is then the state slot is set to 'n', else 'o' is set.*/
/* It then cases the element type and sets the value within the cell. */
/* Next it checks to see if there are any logical connectors: '&' '|'.*/
/* If there are, then the cell slot conn is set to the connector. If  */
/* there is not a connector then the conn slot is set to 'z'.         */
/**********************************************************************/
struct node *pat_parse()
  {
   extern char *token;

   struct node *logp, *head;
   struct node *new_node, *top_level;

   head = NULL;   
   logp = NULL;

   while (TRUE)
     {
      new_node = get_field();      

      if (PARSE_ERROR == TRUE)
        { return(NULL); }

      if (head == NULL)
        {
         head = new_node;
         top_level = new_node;
         logp = new_node;
        }
      else if (logp == NULL)
        {
         top_level->right = new_node;
         top_level = new_node;
         logp = new_node;
        }
      else
        {
         logp->bottom = new_node;
         logp = new_node;
        }

      if (token == LOR)
	{
	 gettoken(source);
	 new_node->conn = '|';
	}
      else if (token == LAND)
	{
	 gettoken(source);
	 new_node->conn = '&';
	}
      else
        {
         new_node->conn = 'z'; 
         logp = NULL;
        }
 
      if (token == RPAREN)
	{
	 gettoken(source);
         return(head);
	}
     }
  }

/*******************************************************/
/* get_field: Retrieves a single field from a pattern. */
/*******************************************************/
struct node *get_field()
  {
   extern float TKNNUMBER;       
   struct node *head;
   
   head = get_node();

   head->right = NULL;
   head->bottom = NULL;
   head->cond = NULL; 
   head->test = NULL;

   /*=======================================================*/
   /* Determine if the field has a '~' preceding it.  If it */
   /* does, then the field has 'n' or negative state logic. */
   /* Otherwise the field has 'o' or ordinary state logic.  */
   /*=======================================================*/

   if (token == LNOT)
     {
      gettoken(source);
      head->state = 'n';
     }
   else
     { head->state = 'o'; }
   
   /*================================================================*/ 
   /* Determine if the field is valid.  Valid fields are ?variables, */
   /* words, ?, $?, $?variables, :(expression), =(expression),       */
   /* strings, and numbers.                                          */
   /*================================================================*/   
 
   if ((token == BWORD)  ||  (token == WORD) ||
       (token == SINGLE) ||  (token == MULTIPLE) ||
       (token == STRING) ||  (token == COAMP)  || 
       ((token == OPERATOR) && (TKNWORD == KEQ)) || 
       (token == BWORDS) || (token == NUMBER))
     {
      head->type = token;
      if ((token == COAMP) || (token == OPERATOR))
	{
	 if (token == OPERATOR)
	   { head->type = FCALL; }
	 head->cond = parse_test_construct(source);
         if (PARSE_ERROR == TRUE) 
           {
            returnnodes(head);
            return(NULL);
           }
	 gettoken(source);
         
	}
      else
        {
	 if (token == NUMBER)
	   { head->ivalue = TKNNUMBER; }
	 else
	   { head->svalue = TKNWORD; }
	 gettoken(source);
        }
     }
   else
     {
      cl_print(wdialog,"Expected a pattern element such as a variable, word,\n");
      sprintf(GLOBALSTR,"or number in the pattern of rule %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returnnodes(head);
      return(NULL);
     }


   return(head);
  }

/********************************************/
/* parse_salience : parses a salience line. */
/*   Syntax: (declare (salience <number>))  */
/********************************************/
parse_salience()
  {
   extern char *token;
   extern float TKNNUMBER;
   extern char *currentrule;             

   float salience;

   /*=====================================================*/
   /* Declaration statements are valid only if they occur */
   /* before any patterns on the left hand side.          */
   /*=====================================================*/

   if (DECLARATIONS_VALID == FALSE)
     { 
      sprintf(GLOBALSTR,"Declarations illegal at this point in %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      return(0);
     }

   DECLARATIONS_VALID = TRUE;

   /*===========================*/
   /* Next token must be a '('. */
   /*===========================*/

   gettoken(source);                     
   if (token != LPAREN)
     {  
      sprintf(GLOBALSTR,"Missing '(' after declare in %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      return(0);
     }
   
   /*=========================================*/
   /* Next token must be the word "salience". */
   /*=========================================*/
   
   gettoken(source);
   if (TKNWORD != SALIENCE)
     {
      sprintf(GLOBALSTR,"keyword salience must follow ( in %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      return(0);
     }

   /*==============================*/
   /* Next token must be a number. */
   /*==============================*/

   gettoken(source);
   if (token != NUMBER)
     {
      sprintf(GLOBALSTR,"Nonumeric Salience given in %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      return(0);
     }

   /*=======================================================*/
   /* Salience number must be in the range -10000 to 10000. */
   /*=======================================================*/

   salience = (float) ((int) TKNNUMBER);

   if ((salience > 10000.0) || (salience < -10000.0))
     {  
      cl_print(wdialog,"Salience value out of range -10000 to 10000\n");
      PARSE_ERROR = TRUE;
      return(0);
     }

   /*============================================*/
   /* Salience declaration is closed with a ')'. */
   /*============================================*/   

   gettoken(source);
   if (token != RPAREN)
     {
      cl_print(wdialog,"Missing ')' in Salience declaration ");
      sprintf(GLOBALSTR,"of %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      return(0);
     }

   /*===================================*/
   /* Declaration is closed with a ')'. */
   /*===================================*/
 
   gettoken(source);
   if (token != RPAREN)
     {
      cl_print(wdialog,"Missing end ')' in declaration ");
      sprintf(GLOBALSTR,"of %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      return(0);
     }

   /*==============================================*/
   /* Return the value of the salience through the */
   /* global variable salience_value.              */
   /*==============================================*/

   glo_salience = salience;
   return(0);

  }

/******************************************************************/
/* conn_pat_to_join: Connects the end of a pattern in the pattern */
/*   net to its corresponding join in the join net.               */
/******************************************************************/
conn_pat_to_join(join,pattern,boolean)
  struct internode *join;
  struct pat_node *pattern;
  char boolean;
  {
   extern struct ruleinfo *temp_rule;
   struct list *pat_to_join;
   struct patptr *tmp_ptr;

   /*======================================================*/
   /* Connect the pattern net to the join net for a single */
   /* pattern of a rule.                                   */
   /*======================================================*/

   pat_to_join = get_list();
   pat_to_join->next = NULL;
   pat_to_join->path = join;
   pat_to_join->boolean = boolean;

   pattern->var_list->entrance = pat_to_join;

   /*============================================================*/
   /* Keep track for each rule how it is attached to the pattern */
   /* network.  This information will be used by other commands  */
   /* such as excise and clear.                                  */
   /*============================================================*/

   tmp_ptr = temp_rule->pats;
   temp_rule->pats = get_patptr();
   temp_rule->pats->next = tmp_ptr;
   temp_rule->pats->pptr = pattern;
   temp_rule->pats->lptr = pattern->var_list;
   
  }

/***********************************************************************/
/* not_check:  Takes as input the logical representation of the lhs of */
/*   a rule and makes sure that any NOT's only appear before patterns. */
/*   It also checks to see that only one pattern follows a NOT.        */
/***********************************************************************/
not_check(log_rep)
  struct node *log_rep;
  {
   struct node *temp;

   if (log_rep == NULL)
     { return(1); } 
   if (log_rep->type == NOT)
     {
      temp = log_rep->right;
      if (temp == NULL)
        {
         cl_print(wdialog,"*** SYSTEM ERROR ***\n");
         cl_print(wdialog,"Logical not error in not_check\n");
         cl_exit(1);
        }
      /* only patterns may follow a not */
      if (temp->type != PATTERN)
        { return(0); }
      /* only one pattern may follow a not */
      if (temp->bottom != NULL)
        { return(0); }
     }
   if (not_check(log_rep->right) == 0) return(0);
   if (not_check(log_rep->bottom) == 0) return(0);
   return(1);
  }

/**********************************************************************/
/* parse_test_construct: Callcycle parses the TEST operands/operators */
/*   into a structure and returns a pointer to the structure          */
/*   representing it.                                                 */
/**********************************************************************/
struct test *parse_test_construct(in_file)
  FILE *in_file;
  {
   extern char *token;
   extern char *TKNWORD;
   extern char GBLOPER;
   extern float TKNNUMBER;

   struct test *top, *next_one, *last_one;

   top = get_test();

   gettoken(in_file);

   if (token == RPAREN)
     {
      returntests(top);
      return(NULL);
     }

   if (token == BWORD)
     {
      top->utype = BWORD;       /* test fix 1 */
      top->utest.sval = TKNWORD;
      return(top);
     }

   if (token == NUMBER)
     {
      top->utype = NUMBER;    /* test fix 1 */
      top->utest.fvalue = TKNNUMBER;
      return(top);
     }

   if (token == WORD)
     {
      top->utype = WORD;     /* test fix 1 */
      top->utest.sval = TKNWORD;
      return(top);
     }

   if (token == STRING)
     {
      top->utype = STRING;          /* test fix 1 */
      top->utest.sval = TKNWORD;
      return(top);
     }     

   if (token != LPAREN)
     {
      cl_print(wdialog,"Expected a '(', variable, number, word, ");
      cl_print(wdialog,"or string in the function call in ");
      sprintf(GLOBALSTR,"%s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returntests(top);
      return(NULL);
     }

   /*=====================================================*/
   /* Functions are either names or arithmetic operators. */
   /*=====================================================*/

   gettoken(in_file);
   if ((token != OPERATOR) && (token != WORD))
     {
      cl_print(wdialog,"Invalid function call: Expected function name ");
      cl_print(wdialog," or arithmetic operator in ");
      sprintf(GLOBALSTR,"%s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returntests(top);
      return(NULL);
     }
   
   /*================================*/
   /* Has the function been defined? */
   /*================================*/

   if (find_function(TKNWORD) == FALSE)
     {       
      cl_print(wdialog,"Missing function declaration for ");
      sprintf(GLOBALSTR,"%s in %s\n",TKNWORD,currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returntests(top);
      return(NULL); 
     }

   top->utype = FCALL;         /* test fix 1 */
   top->utest.sval = TKNWORD;

   last_one = NULL;

   while (TRUE)
     {
      next_one = parse_test_construct(in_file);

      if (PARSE_ERROR == TRUE)
        {
         returntests(top); 
         return(NULL);
        }
         
      if (next_one == NULL)
        { return(top); }

      if (last_one == NULL)
        { top->arg_list = next_one; }
      else
        { last_one->next_arg = next_one; }

      last_one = next_one;
     }
  } 

/*****************************************************************/
/* processrhs: Parses the right hand side actions of a rule into */
/*   the appropriate data structures.                            */
/*****************************************************************/
struct comm *processrhs()
  {
   extern char *TKNWORD;        
   extern char *currentrule;   
   struct comm *next_comm, *last_comm, *first_comm;
   char *command;

   /*========================================================*/
   /* Continue until all appropriate commands are processed. */
   /*========================================================*/

   gettoken(source);
   first_comm = NULL;

   while (TRUE)
     {
      /*=====================================================*/
      /* A ')' or the keyword 'else' at this point signifies */
      /* the end of the rhs actions to be processed.         */
      /*=====================================================*/
       
      if ((token == RPAREN) ||
          ((token == WORD) && (TKNWORD == KELSE))) 
        { return(first_comm); } 

      /*====================================*/
      /* All commands must begin with a '(' */
      /*====================================*/

      if (token != LPAREN)
        { 
         sprintf(GLOBALSTR,"A command must begin with a '(' in %s",currentrule);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         returncomms(first_comm);
         return(NULL);
        }

      /*=========================================*/
      /* The name of the command must be a word. */
      /*=========================================*/

      gettoken(source);
      if (token != WORD)
        {
         sprintf(GLOBALSTR,"Expected command name on rhs of %s\n",currentrule);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         returncomms(first_comm);
         return(NULL);
        }
      command = TKNWORD;

      /*=====================================================*/
      /* Call the appropriate parse routine for the command. */
      /* Valid commands are assert, retract, bind, call, if, */
      /* while, and printout.                                */
      /*=====================================================*/

      if (command == RETRACT)
        { next_comm = prs_retract(); }	
      else if (command == KPRINTOUT)
        { next_comm = prs_printout(); }
      else if (command == KFPRINTOUT)
        { next_comm = prs_fprintout(); }	
      else if (command == KASSERT)
        { next_comm = assert_parse(); }
      else if (command == KBIND)
        { next_comm = bind_parse(); }
      else if (command == KCALL)
        { next_comm = call_parse(); }
      else if (command == KIF)
        { next_comm = if_parse(); }
      else if (command == KWHILE)
        { next_comm = while_parse(); }
      else
        {
         sprintf(GLOBALSTR,"Unknown command %s ",command);
	 cl_print(wdialog,GLOBALSTR);
         sprintf(GLOBALSTR,"on rhs of rule %s\n",currentrule);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
        }

      /*============================================*/
      /* Return the command structures to memory if */
      /* a parse error occurred.                    */
      /*============================================*/

      if (PARSE_ERROR == TRUE)
        {
         returncomms(first_comm); 
         return(NULL);
        }

      /*==============================================*/
      /* Add the new command to the list of commands. */
      /*==============================================*/

      if (first_comm == NULL)
        {
         first_comm = next_comm;
         last_comm = next_comm;
        }
      else
        {
         last_comm->next = next_comm;
         last_comm = next_comm;
        }

      gettoken(source);
     }
  }

/***************************************************************/
/* assert_parse: Purpose is to parse the assert statement. The */
/*   parse of the statement is the return value.               */
/*   Assert syntax:                                            */
/*     (assert (<field>+))                                     */
/***************************************************************/
struct comm *assert_parse()
  {
   extern float TKNNUMBER;
   struct comm *nextslot, *parse;

   parse = get_comm();
   nextslot = parse;
   nextslot->value = KASSERT;
	    
   /*=========================================*/
   /* Check for the opening '(' after assert. */
   /*=========================================*/
 	
   gettoken(source);
   if (token != LPAREN)
     {
      sprintf(GLOBALSTR,"Expected '(' following assert in %s",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }
   
   /*==========================================================*/
   /* Parse the fields within the assert statement until a ')' */
   /* is encountered.  Valid fields are word, numbers, strings */
   /* ?variables, $?variables, and function call expansions.   */
   /*==========================================================*/
  
   gettoken(source);
   while (token != RPAREN)
     {
      nextslot->args = get_comm();
      nextslot = nextslot->args;
      if ((token == OPERATOR) && (TKNWORD == KEQ))
        {
	 nextslot->name = FCALL;
         nextslot->cond = parse_test_construct(source);
         if (PARSE_ERROR == TRUE) 
           {
            returncomms(parse);
            return(NULL);
           }		       
	}
      else if ((token == WORD) || (token == STRING) ||
               (token == BWORD) || (token == BWORDS))
        {
	 nextslot->name = token;
         nextslot->ivalue = 0.0;
         nextslot->value = TKNWORD;
	}
      else if (token == NUMBER)
        {
	 nextslot->name = token;
         nextslot->value = NUMBER;
         nextslot->ivalue = TKNNUMBER;
	}
      else
        { 
         cl_print(wdialog,"Illegal field in assert on rhs of "); 
         sprintf(GLOBALSTR,"%s\n",currentrule);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         returncomms(parse);
         return(NULL);
        }
      gettoken(source);
     }

   /*======================================================*/
   /* Check for the ')' which closes the assert construct. */
   /*======================================================*/

   gettoken(source); 
   if (token != RPAREN)
     {
      sprintf(GLOBALSTR,"An assert on the rhs of %s ",currentrule);
      cl_print(wdialog,GLOBALSTR);
      sprintf(GLOBALSTR,"is missing a closing ')'\n");
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }
   return(parse);
  }

/***********************************************************/
/* call_parse: purpose is to parse the call statement. The */
/*   parse of the statement is the return value.           */
/*   Syntax:  (call <expression>)                          */
/***********************************************************/
struct comm *call_parse()
  {
   struct comm *parse;

   parse = get_comm();
   parse->value = KCALL;

   /*==============================*/
   /* Process the call expression. */
   /*==============================*/

   parse->cond = parse_test_construct(source);
   if (PARSE_ERROR == TRUE) 
     {
      returncomms(parse); 
      return(NULL);
     }

   /*===========================================*/
   /* Call construct must be closed with a ')'. */
   /*===========================================*/

   gettoken(source);
   if (token != RPAREN)
     {  
      cl_print(wdialog,"Expected a ')' to close the call construct ");
      sprintf(GLOBALSTR,"in %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }

   return(parse);
  }

/*********************************************************/
/* while_parse: purpose is to parse the while statement. */
/*   The parse of the statement is the return value.     */
/*   Syntax: (while <expression> <action>+)              */
/*********************************************************/
struct comm *while_parse()
  {
   struct comm *parse;

   parse = get_comm();
   parse->value = KWHILE;

   /*===============================*/
   /* Process the while expression. */
   /*===============================*/

   parse->cond = parse_test_construct(source);
   if (PARSE_ERROR == TRUE) 
     { 
      returncomms(parse);
      return(NULL);
     }

   /*============================*/
   /* Process the while actions. */
   /*============================*/

   parse->args = processrhs();
   if (PARSE_ERROR == TRUE) 
     {
      returncomms(parse); 
      return(NULL);
     }

   return(parse);
  }

/*********************************************************/
/* if_parse: purpose is to parse the if statement.  The  */
/*   parse of the statement is the return value.         */
/*   Syntax: (if <expression> then <action>+             */
/*               [ else <action>+ ] )                    */
/*********************************************************/
struct comm *if_parse()
  {
   struct comm *parse;

   parse = get_comm();
   parse->value = KIF;

   /*============================*/
   /* Process the if expression. */
   /*============================*/

   parse->cond = parse_test_construct(source);
   if (PARSE_ERROR == TRUE) 
     {
      returncomms(parse);
      return(NULL);
     }

   /*========================================*/
   /* Keyword 'then' must follow expression. */
   /*========================================*/

   gettoken(source);
   if ((token != WORD) || (TKNWORD != KTHEN))
     { 
      cl_print(wdialog,"Keyword then expected in if construct of ");
      sprintf(GLOBALSTR,"%s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }

   /*==============================*/
   /* Process the if then actions. */
   /*==============================*/

   parse->args = get_comm();
   parse->args->next = processrhs();
   if (PARSE_ERROR == TRUE) 
     {
      returncomms(parse); 
      return(NULL); 
     }

   /*===========================================*/
   /* A ')' signals an if then without an else. */
   /*===========================================*/

   if (token == RPAREN) 
     { return(parse); }

   /*=============================================*/
   /* Keyword 'else' must follow if then actions. */
   /*=============================================*/

   if ((token != WORD) || (TKNWORD != KELSE))
     { 
      cl_print(wdialog,"Keyword else expected in if construct of ");
      sprintf(GLOBALSTR,"%s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }

   /*==============================*/
   /* Process the if else actions. */
   /*==============================*/

   parse->args->args = get_comm();
   parse->args->args->next = processrhs();
   if (PARSE_ERROR == TRUE) 
    {
     returncomms(parse); 
     return(NULL); 
    }

   /*=========================================*/
   /* If construct must be closed with a ')'. */
   /*=========================================*/

   if (token != RPAREN) 
     { 
      cl_print(wdialog,"Expected a ')' to close the if construct ");
      sprintf(GLOBALSTR,"in %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }

   return(parse);
  }

/***********************************************************/
/* bind_parse: purpose is to parse the bind statement. The */
/*   parse of the statement is the return value.           */
/*   Syntax:  (bind ?var <expression>)                     */
/***********************************************************/
struct comm *bind_parse()
  {
   struct comm *parse;

   parse = get_comm();
   parse->next = NULL;
   parse->value = KBIND;

   /*=============================================*/
   /* Next token must be the name of the variable */
   /* to be bound.                                */
   /*=============================================*/ 

   gettoken(source);
   if (token != BWORD)
     {
      cl_print(wdialog,"Expected binding variable after bind ");
      sprintf(GLOBALSTR,"in %s\n",currentrule);  
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }

   /*==============================*/
   /* Process the bind expression. */
   /*==============================*/

   parse->name = TKNWORD;
   parse->cond = parse_test_construct(source);
   if (PARSE_ERROR == TRUE) 
     {
      returncomms(parse); 
      return(NULL);
     }

   /*===========================================*/
   /* Bind construct must be closed with a ')'. */
   /*===========================================*/

   gettoken(source);
   if (token != RPAREN)
     {  
      cl_print(wdialog,"Expected a ')' to close the bind construct ");
      sprintf(GLOBALSTR,"in %s\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }

   return(parse);
  }

/***************************************************************/
/* prs_retract: Purpose is to parse the retract statement. The */
/*   parse of the statement is the return value.               */
/*   Syntax: (retract <?-var>+ )                               */
/***************************************************************/
struct comm *prs_retract()
  {
   struct comm *nextslot, *parse;

   parse = get_comm();
   nextslot = parse;
   nextslot->value = RETRACT;

   /*================================================*/
   /* Process the list of variables to be retracted. */
   /* The list end is signaled by a ')'.             */
   /*================================================*/

   gettoken(source);
   while (token != RPAREN)
     {
      nextslot->args = get_comm();
      nextslot = nextslot->args;
      if (token != BWORD)
        {
         cl_print(wdialog,"Bound variable expected ");
         sprintf(GLOBALSTR,"in retract of %s\n",currentrule);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         returncomms(parse);
         return(NULL);
        }
      else
       {
        nextslot->name = BWORD;
        nextslot->value = TKNWORD;
        gettoken(source);
       }
    }

   return(parse);
  }

/*************************************************************/
/* prs_printout: Purpose is to parse the printout statement. */
/*   The parse of the statement is the return value.         */
/*   Syntax: (printout <item>+ )                             */
/*************************************************************/
struct comm *prs_printout()
  {
   extern float TKNNUMBER;
   struct comm *nextslot, *parse;

   parse = get_comm();
   nextslot = parse;
   nextslot->value = KPRINTOUT;
   
   nextslot->args = prs_p_items();
   if (PARSE_ERROR == TRUE)
     {
      returncomms(parse);
      return(NULL);
     }

   return(parse);
  }

/***************************************************************/
/* prs_fprintout: Purpose is to parse the fprintout statement. */
/*   The parse of the statement is the return value.           */
/*   Syntax: (fprintout <file-id> <item>+ )                    */
/***************************************************************/
struct comm *prs_fprintout()
  {
   extern float TKNNUMBER;
   struct comm *nextslot, *parse;

   parse = get_comm();
   nextslot = parse;
   nextslot->value = KFPRINTOUT;

   /*==================*/
   /* Get the file id. */
   /*==================*/

   gettoken(source);

   nextslot->args = get_comm();   
   nextslot = nextslot->args;
   if (token == NUMBER) 
     {
      nextslot->name = WORD;
      sprintf(nextslot->value,"%f",TKNNUMBER);
     }
   else if ((token == WORD) || (token == BWORD)) 
     {
      nextslot->name = token;
      nextslot->value = TKNWORD; 
     }
   else 
     {
      cl_print(wdialog,"Illegal file id for PRINTOUT statement in ");
      sprintf(GLOBALSTR,"%s.\n",currentrule);
      cl_print(wdialog,GLOBALSTR);
      PARSE_ERROR = TRUE;
      returncomms(parse);
      return(NULL);
     }
   
   nextslot->args = prs_p_items();
   if (PARSE_ERROR == TRUE)
     {
      returncomms(parse);
      return(NULL);
     }

   return(parse);
  }

/***********************************************************/
/* prs_p_items: Purpose is to parse the print items of the */
/*   printout and fprintout statements.                    */
/***********************************************************/
struct comm *prs_p_items()
  {
   struct comm *nextslot;
   struct comm *parse = NULL;

   gettoken(source);
   while (token != RPAREN)
     {
      if (parse == NULL)
        { 
         parse = get_comm();
         nextslot = parse;
        }
      else
        {  
         nextslot->args = get_comm();
         nextslot = nextslot->args;
        }

      if (token == WORD)
        {
         if ((TKNWORD != KTAB) && (TKNWORD != KCRLF))
           {
            cl_print(wdialog,"Illegal print command ");
            sprintf(GLOBALSTR,"in printout of %s\n",currentrule);
	    cl_print(wdialog,GLOBALSTR);
            PARSE_ERROR = TRUE;
            returncomms(parse);
            return(NULL);
           }
         nextslot->name = token;
         nextslot->value = TKNWORD;
         gettoken(source);
        }
      else if ((token == BWORD) || (token == BWORDS) || (token == STRING))
        {
         nextslot->name = token;
         nextslot->value = TKNWORD;
         gettoken(source);
        }
      else if (token == NUMBER)
        {
         nextslot->name = token;
         nextslot->ivalue = TKNNUMBER;
         gettoken(source);
        }
      else
        {
         cl_print(wdialog,"Variable, word, string, or number expected ");
         sprintf(GLOBALSTR,"in printout of %s\n",currentrule);
	 cl_print(wdialog,GLOBALSTR);
         PARSE_ERROR = TRUE;
         returncomms(parse);
         return(NULL);
        }
    }
   return(parse);
  }

/*************************/
/* COMPARE OPTIMIZATIONS */
/*************************/
   

/*****************************************/
/* base_pattern                          */
/*****************************************/
struct basic *base_pattern(new_pattern)
  struct node *new_pattern;
  {
   struct basic *head = NULL;
   struct basic *last_add = NULL;
   struct basic *new_add = NULL;

   if (new_pattern->type == BINDER)
     { new_pattern = new_pattern->right; }

   while (new_pattern != NULL)
     {
      new_add = get_basic();
      new_add->next = NULL;
      new_add->or = NULL;
      new_add->type = SINGLE;
      new_add->conn = 'z';
      new_add->state = 'o';

      if (head == NULL)
        {
         head = new_add;
         last_add = new_add;
        }
      else
        { 
         last_add->next = new_add;
         last_add = new_add;
        }

      get_or_values(last_add,new_pattern);
      new_pattern = new_pattern->right; 
     }

   last_add->next = get_basic();
   last_add = last_add->next;
   last_add->next = NULL;
   last_add->type = STOP;
   last_add->or = NULL;

   return(head);
  }

/*****************************************/
/* get_or_values                         */
/*****************************************/
struct node *get_or_values(last_add,pattern)
  struct node *pattern;
  struct basic *last_add;
  {
   struct basic *new_or;

   while (pattern != NULL)
     {
      if ((pattern->type == MULTIPLE) || (pattern->type == BWORDS))
        {
         if (last_add->type == SINGLE)
           { last_add->type = MULTIPLE; }
        }
      else if (pattern->type == NUMBER)
        {
         if ((last_add->type != SINGLE) &&
             (last_add->type != MULTIPLE))
           {
            new_or = get_basic();
            new_or->or = NULL;
            last_add->or = new_or;
            last_add = new_or;
           }
         last_add->conn = pattern->conn;
         last_add->state = pattern->state;         
         last_add->type = NUMBER; 
         last_add->ivalue = pattern->ivalue;
        }
      else if ((pattern->type == WORD) || (pattern->type == STRING))
        {
         if ((last_add->type != SINGLE) &&
             (last_add->type != MULTIPLE))
           {
            new_or = get_basic();
            new_or->or = NULL;
            last_add->or = new_or;
            last_add = new_or;
           }
         last_add->conn = pattern->conn;
         last_add->state = pattern->state;       
         last_add->type = pattern->type;
         last_add->svalue = pattern->svalue;
        }
     pattern = pattern->bottom;
    }
   
   return(NULL);
  }

/****************************************************************/
/* get_var_binds: Searches a pattern for the list of variables  */
/*   that must be bound when the pattern has been matched.  The */
/*   return value is the list of variables which must be bound. */
/****************************************************************/
struct bind_node *get_var_binds(pattern)
  struct node *pattern;
  {
   struct node *same_element;
   struct bind_node *var_list = NULL;
   struct bind_node *new_var, *last_var;
   int element = 1;
   char last_conn = '&';

   while (pattern != NULL)
     {
      same_element = pattern;
      while (same_element != NULL)
        {
         if ((same_element->type == BWORD) || 
             (same_element->type == BWORDS) ||
             (same_element->type == BINDER) ||
             (same_element->type == FCALL) ||
             (same_element->type == COAMP))
           {
            new_var = get_bind_node();
            new_var->next_list = NULL;
            new_var->next_bind = NULL;
            new_var->start_pos = element;
            new_var->var_name = same_element->svalue;
            new_var->type = same_element->type;
            new_var->logic = same_element->state;
            new_var->expression = same_element->cond;
            new_var->prev_bound = FALSE;
  
            if ((same_element->type == FCALL) ||
                (same_element->type == COAMP))
              { last_conn = same_element->conn; }

            if ((same_element->type == BWORD) || 
                (same_element->type == BWORDS))
              { 
               new_var->prev_bound = find_var(new_var->var_name,var_list);
              }

            if (var_list == NULL)
              {
               var_list = new_var;
               last_var = var_list; 
              }
            else
              {
               last_var->next_bind = new_var;
               last_var = new_var;
              }    
           }
         same_element = same_element->bottom;
        }

      if (pattern->type != BINDER) { element++; }
      pattern = pattern->right;
     }

   if (var_list == NULL)
     {
      var_list = get_bind_node();
      var_list->next_bind = NULL;
      var_list->start_pos = -1;
     }

   return(var_list);
  }

/*****************************************/
/* find_var:                             */
/*****************************************/
find_var(var_name,var_list)
  char *var_name;
  struct bind_node *var_list;
  {
   while (var_list != NULL)
     {
      if (((var_list->type == BWORD) || (var_list->type == BWORDS)) &&
          (var_list->var_name == var_name) &&
          (var_list->logic == 'o'))
        { return(TRUE); }
      var_list = var_list->next_bind;
     }
   return(FALSE);
  }

/*****************************************/
/* test_bind_extract                     */
/*****************************************/
struct link *test_bind_extract(pattern)
  struct node *pattern;
  {
   struct node *same_element;
   struct link *test_list = NULL;
   struct link *new_test, *last_test;
   char last_conn;

   while (pattern != NULL)
     {
      same_element = pattern;
      while (same_element != NULL)
        {
         if ((same_element->type == FCALL) || 
             (same_element->type == COAMP))
           {
            new_test = get_link();
            new_test->next = NULL;
            new_test->conn = 'z';
            if (test_list == NULL)
              {
               test_list = new_test;
               last_test = test_list; 
              }
            else
              {
               last_test->conn = last_conn;
               last_test->next = new_test;
               last_test = new_test;
              }
            new_test->type = same_element->type;
            new_test->state = same_element->state;
            new_test->hook = same_element->cond;
           }
         last_conn = same_element->conn;
         same_element = same_element->bottom;
        }
      pattern = pattern->right;
     }
   return(test_list);
  }


/*****************************************/
/* place_pattern                         */
/*****************************************/
struct pat_node *place_pattern(pattern_list,upper_level,
                               basic_list,var_list)
  struct basic *basic_list;
  struct bind_node *var_list;
  struct pat_node *pattern_list;
  struct pat_node *upper_level;
  {
   struct basic *old_basic;
   struct pat_node *cur_elem, *new_elem;
   struct bind_node *list_of_binds;
   struct pat_node *last_look = NULL;

   /*=================================================*/
   /* Check for a match on this level of the pattern  */
   /* network.                                        */
   /*=================================================*/

   cur_elem = pattern_list;
   while (cur_elem != NULL)
     { 
      if (same_thing(cur_elem->check_list,basic_list) == TRUE)
        {
         if (basic_list->type == STOP)
           {
            list_of_binds = cur_elem->var_list;
            cur_elem->var_list = var_list;
            var_list->next_list = list_of_binds;
            returnbasics(basic_list);   /* bug fix */
            return(cur_elem);           
           }
         old_basic = basic_list;
         basic_list = basic_list->next;
         old_basic->next = NULL;
         returnbasics(old_basic);   
         cur_elem = place_pattern(cur_elem->next_level,cur_elem,
                       basic_list,var_list);
         return(cur_elem);         
        }
      else
        {
         last_look = cur_elem; 
         cur_elem = cur_elem->same_level;
        }
     }

   /*==================================================*/
   /* Pattern node not found.  Need to add new pattern */
   /* node into the pattern network.                   */
   /*==================================================*/

   if (last_look == NULL)
     {
      if (upper_level == NULL)
        {
         new_patn_list = get_pnode();
         new_elem = new_patn_list;
        }
      else
        {
         upper_level->next_level = get_pnode();
         new_elem = upper_level->next_level;
        }
     }
   else
     {
      last_look->same_level = get_pnode();
      new_elem = last_look->same_level;
     }
      
   new_elem->last_level = upper_level;
   new_elem->next_level = NULL;
   new_elem->same_level = NULL;
   new_elem->prev = last_look;
   new_elem->var_list = NULL;
   new_elem->check_list = basic_list;

   if (basic_list->type == STOP)
     {
      var_list->next_list = NULL;
      new_elem->var_list = var_list;
      return(new_elem);           
     }

   old_basic = basic_list;
   basic_list = basic_list->next;
   old_basic->next = NULL;
         
   new_elem = place_pattern(NULL,new_elem,basic_list,var_list);
   return(new_elem);
  }
 
/*****************************************/
/* same_thing                            */
/*****************************************/
same_thing(check_elem,basic_list)
  struct basic *check_elem, *basic_list;
  {
   while ((basic_list != NULL) && (check_elem != NULL))
     {
      if ((basic_list->type == STOP) &&
          (check_elem->type == STOP))
        { return(TRUE); }

      if ((basic_list->type != check_elem->type) ||
          (basic_list->state != check_elem->state) ||
          (basic_list->conn != check_elem->conn))
        { return(FALSE); }

      if ((basic_list->type == WORD) && 
          (basic_list->svalue != check_elem->svalue))
        { return(FALSE); }

      if ((basic_list->type == STRING) &&              /* bug fix 9 */
          (basic_list->svalue != check_elem->svalue))
        { return(FALSE); }

      if ((basic_list->type == NUMBER) && 
          (basic_list->ivalue != check_elem->ivalue))
        { return(FALSE); }

      check_elem = check_elem->or;
      basic_list = basic_list->or;
     }
  
   if ((check_elem == NULL) && (basic_list == NULL))
     { return(TRUE); }
   else
     { return(FALSE); }
  }

/*****************************************/
/* show_compare_net                      */
/*****************************************/
show_compare_net(pat_ptr,level)
  struct pat_node *pat_ptr;
  int level;
  {
   struct basic *check;
   int count = 1;
   
   while (pat_ptr != NULL)
     {
      check = pat_ptr->check_list;
      if (check->type == STOP)
        {
         sprintf(GLOBALSTR,"At Level %d %d: STOP\n",level,count);
	 cl_print(wdialog,GLOBALSTR);
         cl_print(wdialog,"Variable Bindings\n");
         /* show_variable_bindings(element->next); */
        }
      else
        {
         sprintf(GLOBALSTR,"At Level %d %d: ",level,count);
	 cl_print(wdialog,GLOBALSTR);
         if (check->type == SINGLE)
           { cl_print(wdialog,"? "); }
         else if (check->type == MULTIPLE)
           { cl_print(wdialog,"$? "); }
         else if (check->type == WORD)
           { 
            sprintf(GLOBALSTR,"%c %s ",check->state,check->svalue);
	    cl_print(wdialog,GLOBALSTR);
           }
         else if (check->type == STRING)
           {
            sprintf(GLOBALSTR,"%c \"%s\" ",check->state,check->svalue);
	    cl_print(wdialog,GLOBALSTR);
           }
         else if (check->type == NUMBER)
           {
            sprintf(GLOBALSTR,"%c %6.4f ",check->state,check->ivalue);
	    cl_print(wdialog,GLOBALSTR);
           }
         cl_print(wdialog,"\n");

         show_compare_net(pat_ptr->next_level,level + 1);
        } 
      count++;
      pat_ptr = pat_ptr->same_level;
     }
  }

/*****************************************/
/* show_variable_bindings                */
/*****************************************/
show_variable_bindings(var_list)
   struct bind_node *var_list;
   {
    if (var_list == NULL)
      { return(0); }

    show_variable_bindings(var_list->next_list);
    cl_print(wdialog,"one set\n");
    while (var_list != NULL)
      {
       if (var_list->start_pos == -1)
         { cl_print(wdialog," NULL\n"); }
       else
         { 
          sprintf(GLOBALSTR," %s %s %d %c\n",var_list->type,var_list->var_name,
                 var_list->start_pos,var_list->logic);
	  cl_print(wdialog,GLOBALSTR);
         }
       var_list = var_list->next_bind;
      }
   }

/**************************************/
/* FUNCTIONS FOR REORDERING LHS PARSE */
/**************************************/
      
/**************************************************/
/* reverse_or: Switches and/or constructs into    */
/*   or/and constructs.                           */ 
/*   For example:                                 */
/*     (and (or a b) (or c d))                    */
/*   would be converted to                        */
/*     (or (and a (or c d)) (and b (or c d))),    */
/*   if the or pointer were pointing at (or a b). */
/**************************************************/
struct node *reverse_or(ao_list,or_ptr,or_num)
  struct node *ao_list;
  struct node *or_ptr;
  int or_num;
  {
   int count;
   struct node *before;
   struct node *my_list = NULL;
   struct node *last_add = NULL;
   struct node *new_list, *replace_slot;

   while (or_ptr != NULL)
     {
      new_list = copy_ao(ao_list);
      count = 1;
      replace_slot = new_list->right;
      before = NULL;
      while (count != or_num)
        {
         before = replace_slot;
         replace_slot = replace_slot->bottom;
         count++;
        }
      returnnodes(replace_slot->right);
      replace_slot->type = or_ptr->type;
      replace_slot->right = copy_ao(or_ptr->right);
      replace_slot->svalue = or_ptr->svalue;

      if (last_add == NULL)
        { 
         my_list = new_list;
         new_list->bottom = NULL;
         last_add = new_list;
        }
      else
        {
         last_add->bottom = new_list;
         new_list->bottom = NULL;
         last_add = new_list;
        }

      or_ptr = or_ptr->bottom;
     }

   returnnodes(ao_list); 
   new_list = get_node();
   new_list->type = KOR;
   new_list->svalue = KOR;
   new_list->bottom = NULL;
   new_list->right = my_list;
   
   return(new_list);
  }
 
/**************************************************/
/* COPY_AO                                        */
/**************************************************/
struct node *copy_ao(ao_list)
  struct node *ao_list;
  {
   struct node *head;

   if (ao_list == NULL)
     { return(NULL); }

   head = get_node();
   head->type = ao_list->type;
   head->ivalue = ao_list->ivalue;
   head->svalue = ao_list->svalue;
   head->state = ao_list->state;
   head->conn = ao_list->conn;
   head->test = ao_list->test;
   head->cond = ao_list->cond;
   head->right = copy_ao(ao_list->right);
   head->bottom = copy_ao(ao_list->bottom);

   return(head);
  }

/**************************************************/
/* MOD_AO_LIST                                    */
/**************************************************/
struct node *mod_ao_list(ao_list)
  struct node *ao_list;
  {
   struct node *args;
   struct node *before, *save;
   int count;
   
   ao_list = cleanup(ao_list);

   if (ao_list->type == KAND)
     {
      count = 1;
      args = ao_list->right;
      while (args != NULL)
        {
         if (args->type == KOR)
           {
            ao_list = reverse_or(ao_list,args->right,count);
            args = NULL;
           }
         else
           {
            count++;
            args = args->bottom;
           }
        }
     }
  
   ao_list = cleanup(ao_list); 

   before = NULL;
   args = ao_list->right;


   while (args != NULL)
     {
      save = args->bottom;
      if ((args->type == KAND) || (args->type == KOR))
        {
         if (before == NULL)
           {
            args->bottom = NULL;
            ao_list->right = mod_ao_list(args);
            ao_list->right->bottom = save;
            before = ao_list->right;
           }
         else
           {
            args->bottom = NULL;
            before->bottom = mod_ao_list(args);
            before->bottom->bottom = save;
            before = before->bottom;
           }
        }
      args = save;
     }

   ao_list = cleanup(ao_list);
   return(ao_list);
  }

/**************************************************/
/* CLEANUP : frees garbage properly               */
/**************************************************/
struct node *cleanup(ao_list)
  struct node *ao_list;
  {
   char *logic;
   struct node *args, *save, *before, *end; 

   logic = ao_list->type;
   args = ao_list->right;
   before = NULL;

   while (args != NULL)
     {
      save = args->bottom;
      end = args;
      if ((args->type == logic) && 
          ((args->type == KAND) || (args->type == KOR)))
        {
         if (before == NULL)
           {
            ao_list->right = args->right;
            end = ao_list->right;
           }
         else
           {
            before->bottom = args->right;
            end = args->right;
           }

         args->bottom = NULL;
         args->right = NULL;
         returnnodes(args);
        
         while (end->bottom != NULL)
           { end = end->bottom; }
         end->bottom = save;

        }
      before = end;
      args = save;
     }

   args = ao_list->right;
   before = NULL;
   while (args != NULL)
     {
      save = args->bottom;
      if ((args->type == KAND) || (args->type == KOR))
        {
         if (before == NULL)
           {
            save = args->bottom; 
            ao_list->right = cleanup(args);
            ao_list->right->bottom = save;
           }
         else
           {
            save = args->bottom;
            before->bottom = cleanup(args);
            before->bottom->bottom = save;
           }
        }
      before = args;
      args = save;
     }

   return(ao_list);
  }

