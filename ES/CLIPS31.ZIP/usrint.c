/* CLIPS Version 3.1   9/18/86 */

#include <stdio.h>
#include "clips.h"

#define OFF 0
#define ON  1
#define LHS 0
#define RHS 1
#define TRUE 1
#define FALSE 0

extern struct fact *factlist;
struct fact *deflist;
extern struct fact *defptr;

extern char save_buffer[];
extern int PARSE_ERROR;
int EVAL_PRINT = TRUE;

/*****************************/
/* FUNCTION TYPE DEFINITIONS */
/*****************************/

   struct values *newnid();
   char *getstring();
   struct values *valuescopy();
   struct values *generic_compute();
   struct test *parse_test_construct();
   
   struct internode *web_clear();
   char *malloc();
   float clips_time();
 
   FILE *fopen();

/*****************************************/
/* VARIABLES IMPORTED FROM PARSER MODULE */
/*****************************************/

   extern char *token;        /* Indicates the type of token.       */

   extern float TKNNUMBER;    /* Value of token if token is NUMBER. */

   extern char *TKNWORD;      /* String associated with token.      */

   extern int EXPECTING_EOL;  /* new code */

/***************/
/* OTHER STUFF */
/***************/

   extern struct pat_node *new_patn_list;

   /* this is the variable with the present fact  */
   extern struct fact *last_fact;
                  
   extern int watch_rules;
   extern int watch_facts;
   extern int watch_activations;

   extern int AGENDA_COUNT;
   
   extern int NID;

   /* the list of all the rules loaded into the system */
   extern struct ruleinfo *list_of_rules;

   struct fact *factptr;  /*points to the last fact in factlist */
   extern struct internode *AGENDA;
   extern int ID;      /*this variable holds the values of the fact ids */
   extern char *currentrule;

   extern int LOAD_FLAG;

/********************************************/
/* USER INTERFACE FUNCTIONS                 */
/********************************************/

/************************************************************/
/* watch_command: parses the watch command and sets the     */
/*   appropriate global variable to the value of 1. Fact    */
/*   assertions and retractions, and rule activations,      */
/*   deactivations, and firings are respectively monitored  */
/*   if facts or rules are watched.                         */
/************************************************************/
float watch_command()
  {
   int num_a;
   struct values *arg_ptr;
   char *argument;
   float set_watch();

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 1)
     { 
      cl_print(wdialog,"Missing argument for watch\n");
      return(0.0);
     }

   arg_ptr = runknown(1);
   
   if (arg_ptr->type != WORD)
     { 
      cl_print(wdialog,"Illegal argument for watch\n");
      return(0.0);
     }

   argument = arg_ptr->value;
   
   return(set_watch(argument,ON));
  }

/************************************************************/
/* unwatch_command: parses the unwatch command and sets the */
/*   appropriate global variable to the value of 0. Fact    */
/*   assertions and retractions, and rule activations,      */
/*   deactivations, and firings are respectively not        */
/*   monitored if facts or rules are unwatched.             */
/************************************************************/
float unwatch_command()
  {
   int num_a;
   struct values *arg_ptr;
   char *argument;
   float set_watch();

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 1)
     { 
      cl_print(wdialog,"Missing argument for unwatch\n");
      return(0.0);
     }

   arg_ptr = runknown(1);
   if (arg_ptr->type != WORD)
     { 
      cl_print(wdialog,"Illegal argument for unwatch\n");
      return(0.0);
     }

   argument = arg_ptr->value;
   
   return(set_watch(argument,OFF));
  }

/*************************************************************/
/* set_watch:  Sets the global watch variables to on or off. */
/*************************************************************/
float set_watch(item,act_value)
  char *item;
  int act_value; 
  {
   if ((act_value != ON) && (act_value != OFF))
     { 
      cl_print(wdialog,"Watch items may only be set on or off\n");
      return(0.0); 
     }

   if (strcmp(item,"facts") == 0)            
     { watch_facts = act_value; } 
   else if (strcmp(item,"rules") == 0)      
     { watch_rules = act_value; } 
   else if (strcmp(item,"activations") == 0)
     { watch_activations = act_value; } 
   else
     {
      sprintf(GLOBALSTR,"%s is illegal argument for unwatch\n",item);
      cl_print(wdialog,GLOBALSTR); 
      return(0.0);
     }

   return(1.0);
  }

/************************************************************/
/* rule_display: displays the list of rules.                */
/*   Syntax: (rules)                                        */
/************************************************************/
float rule_display()
  {
   struct ruleinfo *rule_list;

   rule_list = list_of_rules;
   while (rule_list != NULL)
     {
      sprintf(GLOBALSTR,"%s\n",rule_list->name);
      cl_print(wdisplay,GLOBALSTR);
      rule_list = rule_list->next;
     }

   EVAL_PRINT = FALSE;
   return(1.0);
  }

/***************************************************/
/* printagenda: Prints out the agenda of the rules */
/*   that are ready to fire.                       */
/*   Syntax: (agenda)                              */
/***************************************************/
float printagenda()
  {
   struct internode *agenda;

   agenda = AGENDA;
   while (agenda != NULL)
     {
      sprintf(GLOBALSTR,"%-4d",(int) agenda->rhs->locals->ivalue);
      cl_print(wdisplay,GLOBALSTR);
      sprintf(GLOBALSTR,"%s ",agenda->rhs->locals->name);
      cl_print(wdisplay,GLOBALSTR);
      print_fact_basis(agenda->lhs->locals);
      agenda = agenda->next;
     }

   EVAL_PRINT = FALSE;
   return(1.0);
  }

/***************************************************/
/* displayfacts:  Displays the facts in fact list. */
/*   Syntax: (facts)                               */
/***************************************************/
float displayfacts()
  {   
   struct fact *list;

   list = factlist; 
   while (list != NULL)
     {
      show_fact(list);
      cl_print(wdisplay,"\n");
      list = list->next;
     }

   EVAL_PRINT = FALSE;
   return(1.0);
  }

/***************************************/
/* show_fact:  Displays a single fact. */
/***************************************/
show_fact(list)
  struct fact *list;
  {
   struct element *sublist;

   sprintf(GLOBALSTR,"f-%-5d (",list->ID);
   cl_print(wdisplay,GLOBALSTR);
   sublist = list->word;
   while (sublist != NULL)
     {
      if (sublist->type == NUMBER) /* float num fix 1 */
        { print_num(wdisplay,sublist->ivalue); }
      else if (sublist->type == WORD)
        { cl_print(wdisplay,sublist->facts); }
      else if (sublist->type == STRING)
        { 
         sprintf(GLOBALSTR,"\"%s\"",sublist->facts); 
	 cl_print(wdisplay,GLOBALSTR);
        }
      if (sublist->next != NULL)
        { cl_print(wdisplay," "); }
      sublist = sublist->next;
     }
   cl_print(wdisplay,")");
  }

/************************************************************/
/* comm_retract: retracts a fact from the database given */
/*   the number of the fact.                                */
/*   Syntax: (retract <number>)                             */
/************************************************************/
float comm_retract()
  {
   int fact_num, num_a;
   struct fact *ptr;
   struct values *arg_ptr;

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 1)
     {
      cl_print(wdialog,"Missing argument for retract\n");
      return(0.0);
     }

   arg_ptr = runknown(1);
   if (arg_ptr->type != NUMBER)
     {
      cl_print(wdialog,"Illegal argument for retract\n");
      return(0.0);
     }

   fact_num = (int) arg_ptr->ivalue;

   ptr = factlist;
   while (ptr != NULL)
     {
      if (ptr->ID == fact_num)
        { 
         retract_fact(ptr);
         return(1.0);
        }
      ptr = ptr->next;
     }

   sprintf(GLOBALSTR,"Fact %d does not exist\n",fact_num);
   cl_print(wdialog,GLOBALSTR);

   return(0.0);
  }

/************************************************************/
/* assert_command:  Asserts a new fact into the fact list.  */
/*   Syntax: (assert (<element>+ ) )                        */
/************************************************************/
assert_command()
  {	
   extern int ID;
   struct element *piece, *head, *last_piece;

   /*=========================================*/
   /* Check for the opening left parenthesis. */
   /*=========================================*/

   gettoken(stdin);
   if (token != LPAREN)
     {
      cl_print(wdialog,"Expected a '(' after assert\n");
      if (token != STOP) flush_term();
      return(FALSE);
     }

   /*=========================================================*/
   /* Construct the fact.  The only fields allowed are words, */
   /* strings, and numbers.                                   */
   /*=========================================================*/
    
   ID++;
   head = NULL;
   last_piece = NULL;

   gettoken(stdin);
   while ((token == WORD) || (token == STRING) || (token == NUMBER))
     {
      piece = get_element();
      piece->type = token;
      piece->facts = TKNWORD;
      piece->ivalue = TKNNUMBER;
      piece->next = NULL;
    
      if (head == NULL)
        { 
         head = piece;
         last_piece = piece;
        }
      else
        {
         last_piece->next = piece;
         last_piece = piece;
        }

      gettoken(stdin);
     }
 
   /*==========================================================*/
   /* Determine that the assert command was finished properly, */
   /* and that a 'null' fact is not being asserted.            */
   /*==========================================================*/

   if (close_test() == FALSE)
     {
      ID--;
      if (head != NULL) returnelements(head); 
      return(FALSE);
     }

   if (head == NULL)
     {
      cl_print(wdialog,"Cannot assert null fact ()\n");
      ID--;
      return(FALSE);
     }

   /*======================*/
   /* Assert the new fact. */
   /*======================*/

   assertx(head);
   return(TRUE);
  }
     
/***********************************************************/
/* run_command: begins execution of the production rules.  */
/*   Takes an optional argument which indicates the number */
/*   of rules to fire before stopping.                     */
/*   Syntax: (run [ <number> ])                            */
/***********************************************************/
float run_command()
  {
   int num_a;
   int run_limit;
   struct values *arg_ptr;

   EVAL_PRINT = FALSE;
   num_a = num_args();

   if (num_a == 0)
     { run_limit = -1; }
   else if (num_a == 1)
     {
      arg_ptr = runknown(1);
      if (arg_ptr->type != NUMBER)
        {
         cl_print(wdialog,"Run limit must be a number\n");
         return(0.0);
        }
      run_limit = (int) arg_ptr->ivalue;
     }
   else
     { 
      cl_print(wdialog,"Illegal number of arguments for run\n");
      return(0.0);
     }

   timed_run(run_limit); 
   return(1.0);
  }
    
/********************************************************/
/* timed_run:  Calls a timing function to determine the */
/*   amount of time a run has taken.                    */
/********************************************************/
timed_run(run_limit)
  int run_limit;
  {
   int rules_fired;

   float start_time, end_time;

   start_time = clips_time();

   rules_fired = run(run_limit);

   if (run_limit == rules_fired)
     { cl_print(wdialog,"rule firing limit reached\n"); }
   sprintf(GLOBALSTR,"%d rules fired\n",rules_fired);
   cl_print(wdialog,GLOBALSTR);

   end_time = clips_time();

   if (start_time != end_time)
     { 
      sprintf(GLOBALSTR,"Run time is %6.4f seconds\n",end_time - start_time);
      cl_print(wdialog,GLOBALSTR);
     }  
  }

/***************************************************************/
/* load_command: parses the load command and calls load_rules  */
/*   which will load a set of rules from a file.               */
/*   Syntax:  (load <file-name>)                               */
/***************************************************************/
float load_command()
  {
   int num_a;
   struct values *arg_ptr;
   char *file_found;

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 1)
     {
      cl_print(wdialog,"Load command requires a single argument\n");
      return(0.0);
     }

   arg_ptr = runknown(1);
   if (arg_ptr->type != STRING)
     {
      cl_print(wdialog,"File name argument must be a string\n");
      return(0.0);
     }

   file_found = arg_ptr->value;
   
   LOAD_FLAG = TRUE;
   if (load_rules(file_found) == -1) 
     {
      LOAD_FLAG = FALSE; 
      sprintf(GLOBALSTR,"Unable to open file %s\n",file_found);
      cl_print(wdialog,GLOBALSTR);
      return(0.0); 
     }

   LOAD_FLAG = FALSE;
   return(1.0);
  }

/**********************************************/
/* save_command:  Executes the save commands. */
/*   Syntax:  (save <file-name>)              */ 
/**********************************************/ 
float save_command()
  {
   int num_a;
   struct values *arg_ptr;
   char *file_found;

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 1)
     {
      cl_print(wdialog,"Load command requires a single argument\n");
      return(0.0);
     }

   arg_ptr = runknown(1);
   if (arg_ptr->type != STRING)
     { 
      cl_print(wdialog,"File name argument must be a string\n");
      return(0.0);
     }

   file_found = arg_ptr->value;

   if (save_rules(file_found) == FALSE) 
     { 
      sprintf(GLOBALSTR,"Unable to open file %s\n",file_found);
      cl_print(wdialog,GLOBALSTR);
      return(0.0);
     }

   return(1.0);
  }

/********************************************************/
/* save_rules:  Saves the current set of rules into the */
/*   specified file.                                    */ 
/********************************************************/ 
save_rules(file_found)
  char *file_found;
  {
   FILE *outfile;
   struct ruleinfo *rule_ptr;

   outfile = fopen(file_found,"w");
   
   if (outfile == NULL) 
     { return(FALSE); }

   rule_ptr = list_of_rules;
   while (rule_ptr != NULL)
     {
      pretty_print(rule_ptr->name,outfile);
      cl_print(outfile,"\n");
      rule_ptr = rule_ptr->next;
     }
   fclose(outfile);
   return(TRUE);
  }


/************************************************/
/* clear_command: Clears the CLIPS environment. */
/*   Syntax:  (clear)                           */
/************************************************/
float clear_command()
  {
   int num_a;

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 0)
     { 
      cl_print(wdialog,"Clear command has no arguments.\n");
      return(0.0);
     }
  
   clear_clips();

   return(1.0);
  }

/****************************************************************/
/* clear_clips: the purpose of this function is to clear the    */
/*   CLIPS environment.  All rules and facts are removed. The   */
/*   effect is as if CLIPS were completely restarted.           */
/*   Syntax:  (clear)                                           */
/****************************************************************/
clear_clips()
  {
   struct fact *traverse;
   struct internode *temp_agenda;
   struct fact *temp_fact;
   struct match *pat_matches, *temp_match;

   /*====================================*/
   /* Initialize some global parameters. */
   /*====================================*/

   ID = -1;        
   NID = -2;         
   AGENDA_COUNT = 0;

   /*======================================*/
   /* Remove all facts from the fact list. */
   /*======================================*/

   while (factlist != NULL)
     {
      temp_fact = factlist->next;
      pat_matches = factlist->list;
      while (pat_matches != NULL)
        {
         temp_match = pat_matches->next;
         rtn_match(pat_matches);
         pat_matches = temp_match;
        }
      returnelements(factlist->word);
      rtn_fact(factlist);
      factlist = temp_fact;
     }

   /*========================================*/
   /* Remove all bindings from the join net. */
   /*========================================*/

   flush_web(new_patn_list);
   
   /*=========================================*/ 
   /* Remove all activations from the agenda. */
   /*=========================================*/

   while (AGENDA != NULL)
     {
      returnvalues(AGENDA->lhs->locals);
      rtn_lr(AGENDA->lhs);
      temp_agenda = AGENDA->next;
      rtn_internode(AGENDA);
      AGENDA = temp_agenda;
     }

   /*====================================================*/ 
   /* Remove all deffacts, then create the initial fact. */
   /*====================================================*/ 

   while (deflist != NULL)
     {
      traverse = deflist->next;
      returnelements(deflist->word);
      rtn_fact(deflist,sizeof(struct fact));
      deflist = traverse;
     }
   createinitial();

   /*===================================*/
   /* Remove all rules from the system. */
   /*===================================*/

   while (list_of_rules != NULL)
     { name_excise(list_of_rules->name); }

   /*========================*/
   /* System Error Checking. */
   /*========================*/

   if (new_patn_list != NULL)
     { 
      cl_print(wdialog,"*** SYSTEM ERROR ***\n");
      cl_print(wdialog,"Pattern Net error detected in clear_clips()\n");
     }
  }

/*****************************************************/
/* excise_command: excises a rule from the database. */
/*   Syntax: (excise <rule name>)                    */
/*****************************************************/
float excise_command()
  {
   char *rule_name;
   int num_a;
   struct values *arg_ptr;

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 1)
     { 
      cl_print(wdialog,"Missing argument for excise\n");
      return(0.0); 
     }

   arg_ptr = runknown(1);
   if (arg_ptr->type != WORD)
     {
      cl_print(wdialog,"Illegal argument for excise\n");
      return(0.0);
     }

   rule_name = arg_ptr->value;
 
   if (name_excise(rule_name) == FALSE)        
     {
      sprintf(GLOBALSTR,"Unable to find rule %s\n",rule_name);
      cl_print(wdialog,GLOBALSTR);
      return(0.0);
     }

   return(1.0);
  }

/***********************************************************/
/* name_excise: Remove a named rule from the database.     */
/*   Returns 1 if the rule was found and removed.  Returns */
/*   -1 if the rule was not found.                         */
/***********************************************************/
name_excise(rule_name)
  char *rule_name;
  {
   struct ruleinfo *rule_ptr, *rule_before;
   struct patptr *pat_del, *next_del;
   struct internode *temp_node;
   int rule_found;

   /*=================================================*/
   /* Search for the named rule in the list of rules. */
   /*=================================================*/

   rule_before = NULL;
   rule_found = FALSE;
   rule_ptr = list_of_rules;
   while ((rule_ptr != NULL) && (rule_found == FALSE))
     {
      if (rule_ptr->name == rule_name)
        { rule_found = TRUE; }
      else
        {  
         rule_before = rule_ptr;
         rule_ptr = rule_ptr->next;
        } 
     }

   if (rule_found == FALSE)
     { return(FALSE); }

   if (watch_rules == TRUE)
     { 
      sprintf(GLOBALSTR,"Excising rule: %s\n",rule_name);
      cl_print(wdisplay,GLOBALSTR);
     }

   /*============================================================*/
   /* Clear the agenda of all the activations added by the rule. */
   /*============================================================*/

   agnd_clear(rule_name);

   /*=============================================================*/
   /* Remove all structures associated with each pattern on the   */
   /* lhs of a rule from both the pattern and join nets.  This    */
   /* will also remove the structures associated with the actions */
   /* of the rhs of the rule.                                     */
   /*=============================================================*/

   pat_del = rule_ptr->pats;
   while (pat_del != NULL)
     {
      next_del = pat_del->next;
      /* fact_clear(pat_del->pptr); */
      temp_node = web_clear(pat_del);
      join_clear(temp_node);
      rtn_patptr(pat_del);
      pat_del = next_del;
     }
   rule_ptr->pats = NULL;

   /*============================================================*/
   /* Return the structures associated with the rhs of the rule. */
   /*============================================================*/
 
   returncomms((struct comm *) rule_ptr->rhs_info->rhs->next);
   rtn_values(rule_ptr->rhs_info->rhs->locals);
   rtn_lr(rule_ptr->rhs_info->rhs);
   rtn_internode(rule_ptr->rhs_info);

   /*========================================================*/
   /* Return the data structures used to pretty print a rule */
   /* to the pool of free memory.                            */
   /*========================================================*/

   returnnodes(rule_ptr->ppinfo);
   rule_ptr->ppinfo = NULL;

   /*=========================================*/
   /* Remove the rule from the list of rules. */
   /*=========================================*/

   if (rule_before == NULL)
     {
      list_of_rules = rule_ptr->next;
      rtn_ruleinfo(rule_ptr);
     }
   else
     {
      rule_before->next = rule_ptr->next;
      rtn_ruleinfo(rule_ptr);
     }

   /*=====================*/
   /* System Error Check. */
   /*=====================*/

   if ((list_of_rules == NULL) && (new_patn_list != NULL))
     {
      cl_print(wdialog,"*** SYSTEM ERROR ***\n");
      cl_print(wdialog,"Pattern net error detected in name_excise\n");
     }

   return(TRUE);
  }

/************************************************************/
/* web_clear: clears the web of a specific list structure   */
/*   connected to the pattern which is to be removed.       */
/*   If the list structure is the only one for the pattern  */
/*   then the pattern is also removed.                      */
/*   Returns a pointer to the internode which must be       */
/*   remove to excise the rule completely.                  */
/************************************************************/
struct internode *web_clear(pat_del)
  struct patptr *pat_del;
  {
   struct pat_node *pat_ptr;
   struct pat_node *upper_level;
   struct bind_node *bind_ptr, *before_bind, *temp_bind;
   struct list *list_ptr;
   struct internode *join_ptr;
    
   /*========================*/
   /* System Error Checking. */
   /*========================*/

   if (pat_del->pptr == NULL) 
     {
      cl_print(wdialog,"*** SYSTEM ERROR ***\n");
      cl_print(wdialog,"Null pattern pointer encountered in web_clear\n");
      return(NULL);
     }

   /*=============================================================*/
   /* Get a pointer to the end of the pattern (the pattern node   */
   /* with a value of STOP), and a pointer to the set of variable */
   /* bindings which are associated with this pattern.            */
   /*=============================================================*/
 
   pat_ptr = pat_del->pptr;
   bind_ptr = pat_del->lptr;

   /*=========================================================*/
   /* Detach the structure which contains binding information */
   /* from the STOP pattern node.                             */
   /*=========================================================*/ 

   if (pat_ptr->var_list == bind_ptr)
     { pat_ptr->var_list = bind_ptr->next_list; }
   else
     {
      before_bind = pat_ptr->var_list;
      while (before_bind->next_list != bind_ptr)
        { before_bind = before_bind->next_list; }
      before_bind->next_list = bind_ptr->next_list; 
     }

   /*=============================================================*/
   /* Return the binding information and the list structure which */
   /* connects to the join associated with this pattern to free   */
   /* memory.                                                     */
   /*=============================================================*/

   list_ptr = bind_ptr->entrance;
   join_ptr = list_ptr->path;
   
   while (bind_ptr != NULL)
     {
      temp_bind = bind_ptr->next_bind;
      rtn_bind_node(bind_ptr);
      bind_ptr = temp_bind;
     }

   rtn_list(list_ptr);

   /*============================================================*/
   /* If the pattern node no longer has any variable bindings    */ 
   /* associated with it, then the pattern needs to be removed   */
   /* from the pattern net up to the point at which other viable */
   /* patterns are reached which are a part of this pattern.     */ 
   /*============================================================*/

   if (pat_ptr->var_list == NULL)
     { detach_pattern(pat_ptr); }

   return(join_ptr);
  }

/*************************************************************/
/* detach_pattern:  Detaches a pattern from the pattern net. */
/*   The pattern net is a tree-like structure.               */
/*   Detachment of a pattern involves starting at the end    */ 
/*   of the pattern in the net (the terminating leaf) and    */ 
/*   removing the longest "limb" of the pattern.             */
/*   Example:                                                */
/*     Patterns (a b c d) and (a b e f) would be represented */
/*     by the pattern net shown on the left.  If (a b c d)   */
/*     was detached, the resultant pattern net would be the  */
/*     one shown on the right. The '=' represents an end of  */
/*     of pattern or STOP marker.                            */  
/*                                                           */
/*           a                  a                            */
/*           |                  |                            */
/*           b                  b                            */
/*           |                  |                            */
/*           c--e               e                            */
/*           |  |               |                            */
/*           d  f               f                            */
/*           |  |               |                            */
/*           =  =               =                            */
/*                                                           */
/*************************************************************/
detach_pattern(pat_ptr)
  struct pat_node *pat_ptr;
  {
   struct pat_node *upper_level;

   /*========================*/
   /* System Error Checking. */
   /*========================*/

   if (pat_ptr->next_level != NULL) 
     {
      cl_print(wdialog,"*** SYSTEM ERROR ***\n");
      cl_print(wdialog,"Attempting to detach pattern");
      cl_print(wdialog," from the middle in detach_pattern\n");
      return(FALSE);
     }

   /*==============================================================*/
   /* Loop until all appropriate pattern nodes have been detached. */
   /*==============================================================*/

   upper_level = pat_ptr;
   while (upper_level != NULL)
     {
      if ((upper_level->prev == NULL) &&
          (upper_level->same_level == NULL))
        {
         /*===============================================*/
         /* Pattern node is the only node on this level.  */
         /* Remove it and continue detaching other nodes  */
         /* above this one, because no other patterns are */
         /* dependent upon this node.                     */
         /*===============================================*/
         
         pat_ptr = upper_level;
         upper_level = pat_ptr->last_level;
         if (upper_level == NULL) 
           { new_patn_list = NULL; }
         returnbasics(pat_ptr->check_list);
         rtn_pnode(pat_ptr);
        }
      else if (upper_level->prev != NULL)
        {
         /*====================================================*/
         /* Pattern node has another pattern node which must   */
         /* be checked preceding it.  Remove the pattern node, */
         /* but do not detach any nodes above this one.        */      
         /*====================================================*/

         pat_ptr = upper_level;
         upper_level->prev->same_level = upper_level->same_level;
         if (upper_level->same_level != NULL)
           { upper_level->same_level->prev = upper_level->prev; }
         returnbasics(pat_ptr->check_list);
         rtn_pnode(pat_ptr);
         upper_level = NULL;
        }
      else
        {
         /*====================================================*/
         /* Pattern node has no pattern node preceding it, but */
         /* does have one succeeding it.  Remove the pattern   */
         /* node, but do not detach any nodes above this one.  */      
         /*====================================================*/

         pat_ptr = upper_level;
         upper_level = upper_level->last_level;
         if (upper_level == NULL)
           { new_patn_list = pat_ptr->same_level; }
         else
           { upper_level->next_level = pat_ptr->same_level; }
         pat_ptr->same_level->prev = NULL;
         returnbasics(pat_ptr->check_list);
         rtn_pnode(pat_ptr);
         upper_level = NULL;
        }
     }
  }

/*************************************************************/
/* join_clear: Returns the data structures associated with a */
/*   join to free memory along with the join itself.  Also   */
/*   returns the rhs action connector join if that join is   */
/*   connected to this join.                                 */
/*************************************************************/
join_clear(join_ptr)
  struct internode *join_ptr;
  {
   struct lr *loc, *next_loc;
   struct link *tloc, *next_tloc;
   
   /*========================*/
   /* System Error Checking. */
   /*========================*/

   if (join_ptr == NULL) 
     {
      cl_print(wdialog,"*** SYSTEM ERROR ***\n");
      cl_print(wdialog,"Null Join encountered in join_clear\n");
      return(0);
     }  
   
   /*========================================================*/
   /* Return any values associated with the lhs of the join. */
   /*========================================================*/

   loc = join_ptr->lhs;
   while (loc != NULL)
     {
      returnvalues(loc->locals);
      next_loc = loc->next;
      rtn_lr(loc);
      loc = next_loc;
     }

   /*========================================================*/
   /* Return any values associated with the rhs of the join. */
   /*========================================================*/

   loc = join_ptr->rhs;
   while (loc != NULL)
     {
      returnvalues(loc->locals);
      next_loc = loc->next;
      rtn_lr(loc);
      loc = next_loc;
     }

   /*======================================================*/
   /* Return any tests associated with the test construct. */
   /*======================================================*/

   tloc = join_ptr->cond;
   while (tloc != NULL)
     {
      returntests(tloc->hook);
      next_tloc = tloc->next;
      rtn_link(tloc);
      tloc = next_tloc;
     }

   /*===================================================*/
   /* Return any tests associated with the rhs pattern. */
   /*===================================================*/

   tloc = join_ptr->rhs_test;
   while (tloc != NULL)
     {
      returntests(tloc->hook);
      next_tloc = tloc->next;
      rtn_link(tloc);
      tloc = next_tloc;
     }
       
   /*==================*/
   /* Return the join. */
   /*==================*/

   rtn_internode(join_ptr);
   return(1);
  }

/*****************************************************/
/* undeffacts_command: removes a deffacts statement. */
/*   Syntax: (undeffacts <deffacts name>)            */
/*****************************************************/
float undeffacts_command()
  {
   char *deffacts_name;
   float delete_deffacts();
   int num_a;
   struct values *arg_ptr;

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 1)
     { 
      cl_print(wdialog,"Missing argument for undeffacts\n");
      return(0.0);
     }

   arg_ptr = runknown(1);
   if (arg_ptr->type != WORD)
     {
      cl_print(wdialog,"Illegal argument for undeffacts\n");
      return(0.0);
     }
  
   deffacts_name = arg_ptr->value;

   return(delete_deffacts(deffacts_name));
  }

/*****************************************************/
/* delete_deffacts: Delete all facts in the deffacts */
/*   list which have the identifying name of the     */
/*   deffacts block to be removed.                   */
/*****************************************************/
float delete_deffacts(deffacts_name)
   char *deffacts_name;
  {
   extern struct fact *deflist;
   struct fact *next_deffact, *last_deffact;
   struct fact *cur_deffact;
   int flag = FALSE;

   last_deffact = NULL;
   cur_deffact = deflist;
   while (cur_deffact != NULL)
     {
      next_deffact = cur_deffact->next;
      last_deffact = cur_deffact->previous;
      if (cur_deffact->name == deffacts_name)
        {
         flag = TRUE;
         returnelements(cur_deffact->word);
         rtn_fact(cur_deffact);

         if (last_deffact == NULL)
           { deflist = next_deffact; }
         else
           { last_deffact->next = next_deffact; }

         if (next_deffact != NULL) 
           { next_deffact->previous = last_deffact; }
        }
  
      cur_deffact = next_deffact;
     }

   /*=================================================*/
   /* Position the global variable defptr to point to */
   /* the last fact in the deffacts list for the easy */
   /* addition of other deffacts statements.          */
   /*=================================================*/

   defptr = deflist;
   if (defptr != NULL)
     {
      while (defptr->next != NULL)
        { defptr = defptr->next; }
     } 

   if (flag == TRUE)
     { return(1.0); }

   sprintf(GLOBALSTR,"No deffacts block named %s found.",deffacts_name);
   cl_print(wdialog,GLOBALSTR);
   return(0.0); 
  }


/************************************************************/
/* fact_clear: clears the fact list of all pointers which   */
/*   point to a specific pattern.  The pointers are used to */
/*   to remember which patterns were matched by a fact to   */
/*   make retraction easier.  When a rule is excised, the   */
/*   pointers need to be removed.                           */
/************************************************************/
fact_clear(pat_ptr)
  struct pat_node *pat_ptr;
  {
   extern struct fact *factlist;
   struct fact *fact_ptr;
   struct match *match_before, *match_ptr;
 
   /*===========================================*/
   /* Loop through every fact in the fact list. */
   /*===========================================*/
  
   fact_ptr = factlist;
   while (fact_ptr != NULL)
     {
      match_before = NULL;
      match_ptr = fact_ptr->list;

      /*========================================*/
      /* Loop through every match for the fact. */
      /*========================================*/

      while (match_ptr != NULL)
        {
         if (match_ptr->slot == pat_ptr)
           {
            /* Remove the match. */
	    if (match_before == NULL)
	      {
	       fact_ptr->list = match_ptr->next;
               rtn_match(match_ptr);
               match_ptr = fact_ptr->list;
              }
            else
	      {
	       match_before->next = match_ptr->next;
	       rtn_match(match_ptr);
               match_ptr = match_before->next;
              }
	   }
         else
	   {
            /* Move on to the next match. */
	    match_before = match_ptr;
	    match_ptr = match_ptr->next;
           }
	}
      fact_ptr = fact_ptr->next;
     }
  }

/**********************************************************/
/* agnd_clear: clears the agenda of a specified rule name */
/**********************************************************/
agnd_clear(rule_name)
  char *rule_name;
  {
   extern struct internode *AGENDA;
   struct internode *agenda_ptr, *agenda_before;

   agenda_ptr = AGENDA;
   agenda_before = NULL;

   /*==============================================*/
   /* Loop through every activation on the agenda. */
   /*==============================================*/

   while (agenda_ptr != NULL)
     {
      if (agenda_ptr->rhs->locals->name == rule_name)
        {
         /* Activation matching rule name found. */

         /* Indicate removal if rule tracing turned on. */
	 if (watch_rules == TRUE)
	   {
	    cl_print(wdisplay,"<== Activation ");
            sprintf(GLOBALSTR,"%4d ",agenda_ptr->id);
	    cl_print(wdisplay,GLOBALSTR);
            sprintf(GLOBALSTR,"%s: ",agenda_ptr->rhs->locals->name);
	    cl_print(wdisplay,GLOBALSTR);
	    print_fact_basis(agenda_ptr->lhs->locals);
	   }

         /* Remove agenda rule activation. */
         if (agenda_before == NULL)
           {
	    /* Delete activation from head of list. */
	    AGENDA = agenda_ptr->next;
            rtn_internode(agenda_ptr);
            agenda_ptr = AGENDA;
           }
         else
           {
            /* Delete activation from middle or end of list. */
	    agenda_before->next = agenda_ptr->next;
            rtn_internode(agenda_ptr);
            agenda_ptr = agenda_before->next;
           }
        }
      else
        {
         /* Move on to next agenda activation. */ 
         agenda_before = agenda_ptr;
         agenda_ptr = agenda_ptr->next;
        }
     }
  }

/**********************************************/
/* exit_command: Exits the CLIPS environment. */
/*   Syntax:  (exit)                          */
/**********************************************/
float exit_command()
  {
   int num_a;

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 0)
     {
      cl_print(wdialog,"Exit command has no arguments\n");
      return(0.0);
     }
  
   cl_exit(1);

   return(1.0);
  }

/************************************************/
/* reset_command: Resets the CLIPS environment. */
/*   Syntax:  (reset)                           */
/************************************************/
float reset_command()
  {
   int num_a;
 
   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 0)
     {
      cl_print(wdialog,"Reset command has no arguments\n");
      return(0.0);
     }
  
   reset_clips();

   return(1.0);
  }

/****************************************************************/
/* reset_clips: the purpose of this function is to reset the    */
/*   CLIPS environment.  The factlist is reset to the deffacts  */
/*   statements, the agenda is cleared, and the opnet is reset. */
/****************************************************************/
reset_clips()
  {
   struct fact *traverse,*lasttrav,*temp_fact;
   struct element *travelem,*lastelem,*tempelem;
   struct internode *temp_agenda;
   struct match *pat_matches, *temp_match;

   /*====================================*/
   /* Initialize some global parameters. */
   /*====================================*/

   ID = -1;         
   AGENDA_COUNT = 0;

   /*======================================*/
   /* Remove all facts from the fact list. */
   /*======================================*/

   while (factlist != NULL)
     {
      temp_fact = factlist->next;
      pat_matches = factlist->list;
      while (pat_matches != NULL)
        {
         temp_match = pat_matches->next;
         rtn_match(pat_matches);
         pat_matches = temp_match;
        }
      returnelements(factlist->word);
      rtn_fact(factlist);
      factlist = temp_fact;
     }

   /*========================================*/
   /* Remove all bindings from the join net. */
   /*========================================*/

   flush_web(new_patn_list);

   /*=========================================*/
   /* Remove all activations from the agenda. */
   /*=========================================*/

   while (AGENDA != NULL)
     {
      returnvalues(AGENDA->lhs->locals);
      rtn_lr(AGENDA->lhs);
      temp_agenda = AGENDA->next;
      rtn_internode(AGENDA);
      AGENDA = temp_agenda;
     }

   /*============================================================*/
   /* Reset the not pattern counter and initialize not patterns. */
   /*============================================================*/

   NID = -2; 
   setnots(new_patn_list);

   /*==========================================*/
   /* Copy the deffacts list to the fact list. */
   /*=========================================*/

   init_deffacts();

   /*===============================================*/
   /* Loop through each fact in the fact list added */
   /* by deffacts constructs and assert the fact.   */
   /*===============================================*/

   traverse = factlist;
   while (traverse != NULL)
     {
      last_fact = traverse;
      compare(traverse,traverse->word,new_patn_list,1,1,NULL,1);
      traverse = traverse->next;
     }
  }

/**************************************************************/
/* init_deffacts:  Copies the deffacts list to the fact list. */
/**************************************************************/
init_deffacts()
  {
   struct fact *def_ptr, *last_fact, *tempfact;
   struct element *elem_ptr, *last_elem, *temp_elem;

   /*======================================*/
   /* Copy facts from deflist to factlist. */
   /*======================================*/

   def_ptr = deflist;
   last_fact = NULL;
   while (def_ptr != NULL)
     {
      /*===================================*/
      /* Make a copy of the deffacts fact. */
      /*===================================*/

      ID++;
      tempfact = get_fact();
      tempfact->list = NULL;
      tempfact->previous = last_fact;
      tempfact->ID = ID;
      tempfact->next = NULL;
      tempfact->name = NULL;
      tempfact->word = NULL;

      /*===========================*/
      /* Copy individual elements. */
      /*===========================*/

      elem_ptr = def_ptr->word;
      last_elem = NULL;
      while (elem_ptr != NULL)
        {
         temp_elem = get_element();
         temp_elem->facts = elem_ptr->facts;
         temp_elem->ivalue = elem_ptr->ivalue;
         temp_elem->type = elem_ptr->type;
         temp_elem->next = NULL;
         if (last_elem != NULL)
           { last_elem->next = temp_elem; }
         else
           { tempfact->word = temp_elem; }
         last_elem = temp_elem;
         elem_ptr = elem_ptr->next;
        }

      /*============================*/
      /* Place fact into fact list. */
      /*============================*/

      factptr = last_fact;
      if (last_fact != NULL)
        { last_fact->next = tempfact; }
      else
        { factlist = tempfact; }
      last_fact = tempfact;
      def_ptr = def_ptr->next;
     }
  }

/************************************************************/
/* pprule_command: pretty prints a rule.                    */
/*   Syntax: (pprule <rule name>)                           */
/************************************************************/
float pprule_command()
  {
   char *rule_name;
   struct values *arg_ptr;
   int num_a;

   EVAL_PRINT = FALSE;
   num_a = num_args();
   if (num_a != 1)
     { 
      cl_print(wdialog,"pprule requires a single argument\n");
      return(0.0);
     }

   arg_ptr = runknown(1);

   if (arg_ptr->type != WORD)
     { 
      cl_print(wdialog,"pprule requires the name of a rule\n");
      return(0.0);
     }     

   rule_name = arg_ptr->value;

   pretty_print(rule_name,wdialog);

   return(1.0);
  }

/************************************************************/
/* pretty_print: the driver which actually does the pretty  */
/*   printing of the rule.                                  */
/************************************************************/
pretty_print(rule_name,outfile)
  char *rule_name;
  FILE *outfile;
  {
   struct ruleinfo *rule_ptr;
   struct patptr *tmpptr;
   struct values *rhs_info;
   struct internode *node_ptr;
   struct comm *action;
   int rule_found;

   /*======================*/
   /* Search for the rule. */
   /*======================*/

   rule_found = FALSE;
   rule_ptr = list_of_rules;
   while ((rule_ptr != NULL) && (rule_found == FALSE))
     {
      if (rule_ptr->name == rule_name)
        { rule_found = TRUE; }
      else
        { rule_ptr = rule_ptr->next; }
     }

   if (rule_ptr == NULL)
     {
      sprintf(GLOBALSTR,"Unable to find rule %s\n",rule_name);
      cl_print(wdialog,GLOBALSTR);
      return(FALSE);
     }

   /*======================================*/
   /* Print out the LHS of the rule.       */
   /*======================================*/

   node_ptr = rule_ptr->pats->lptr->entrance->path;
   while (node_ptr->next != NULL)
     { node_ptr = node_ptr->next; }
   rhs_info = node_ptr->rhs->locals;

   sprintf(GLOBALSTR,"(defrule %s \"%s\"",rule_name,rhs_info->value);
   cl_print(outfile,GLOBALSTR);
   if (rhs_info->ivalue != 0.0)
     { 
      sprintf(GLOBALSTR,"\n   (declare (salience %d))",
              (int) rhs_info->ivalue);
      cl_print(outfile,GLOBALSTR);
     }
   pp_logic(rule_ptr->ppinfo,3,1,outfile);

   /*======================================*/
   /* Print out the RHS of the rule.       */
   /*======================================*/

   cl_print(outfile,"\n   =>");
   tmpptr = rule_ptr->pats;
   node_ptr = tmpptr->lptr->entrance->path;

   if (node_ptr == NULL) cl_print("Logic Error 1 in pretty_print\n");
  
   /* trace down the internodes to find the right hand side */
   while (node_ptr->next != NULL)
     { node_ptr = node_ptr->next; }
   action = (struct comm *) node_ptr->rhs->next;

   rhs_pp(action,outfile,3);
   cl_print(outfile,")\n");

   return(TRUE);
  }
  
/****************************************************/
/* pp_logic:                                        */
/****************************************************/
pp_logic(node_ptr,indent,flag,outfile)
  struct node *node_ptr;
  int indent, flag;
  FILE *outfile;
  {

   while (node_ptr != NULL)
     {
      if (node_ptr->type == NOT)
        {
         if (flag) 
           {
            cl_print(outfile,"\n");
            put_spaces(indent,outfile);
            flag = 0; 
           } 
         cl_print(outfile,"(not ");
         flag = pp_logic(node_ptr->right,indent+5,flag,outfile);
         cl_print(outfile,")");
        }
      else if (node_ptr->type == KAND)
        {
         if (flag) 
           { 
            cl_print(outfile,"\n"); 
            put_spaces(indent,outfile);
            flag = 0;
           }
         cl_print(outfile,"(and ");
         flag = pp_logic(node_ptr->right,indent+5,flag,outfile);
         cl_print(outfile,")");
        }
      else if (node_ptr->type == KOR)
        {
         if (flag) 
           {
            cl_print(outfile,"\n"); 
            put_spaces(indent,outfile);
            flag = 0;
           }
         cl_print(outfile,"(or  ");
         flag = pp_logic(node_ptr->right,indent+5,flag,outfile);
         cl_print(outfile,")");
        }
      else if (node_ptr->type == PATTERN)
        {
         if (flag) 
           { 
            cl_print(outfile,"\n");
            put_spaces(indent,outfile);
           }
         pat_pp(node_ptr->right,outfile);
         flag = 1;
        }
      else if (node_ptr->type == TEST)
        { 
         if (flag) 
           { 
            cl_print(outfile,"\n");
            put_spaces(indent,outfile);
            flag = 0;
           }
         cl_print(outfile,"(test ");
         pp_test(node_ptr->test,outfile);
         flag = 1;
         cl_print(outfile,")");
        }
      
      node_ptr = node_ptr->bottom;
     }
   return(flag);
  }

/****************************************************/
/* pp_test: Pretty prints a test construct.         */
/****************************************************/
pp_test(test_ptr,outfile)
  struct test *test_ptr;
  FILE *outfile;
  {

   if (test_ptr == NULL) 
     { return(1); }

   while (test_ptr != NULL)
     {
      if (test_ptr->utype == BWORD) /* test fix 1 */
        { 
         sprintf(GLOBALSTR,"?%s",test_ptr->utest.sval); 
	 cl_print(outfile,GLOBALSTR);
        }
      else if (test_ptr->utype == NUMBER) /* float num fix 1 */
        { print_num(outfile,test_ptr->utest.fvalue); }
      else if (test_ptr->utype == WORD)
        { 
         sprintf(GLOBALSTR,"%s",test_ptr->utest.sval); 
	 cl_print(outfile,GLOBALSTR);
        }
      else if (test_ptr->utype == STRING)
        {
         sprintf(GLOBALSTR,"\"%s\"",test_ptr->utest.sval); 
	 cl_print(outfile,GLOBALSTR);
        }
      else if (test_ptr->utype == FCALL)
        {
         sprintf(GLOBALSTR,"(%s",test_ptr->utest.sval);
         cl_print(outfile,GLOBALSTR);
         if (test_ptr->arg_list != NULL) { cl_print(outfile," "); }
         pp_test(test_ptr->arg_list,outfile);
         cl_print(outfile,")");
        }
      else
        {
         cl_print(wdialog,"*** SYSTEM ERROR ***\n");
         sprintf(GLOBALSTR,"Undefined case %s in pp_test ***",test_ptr->utype);
	 cl_print(wdialog,GLOBALSTR);
        }

      test_ptr = test_ptr->next_arg;
      if (test_ptr != NULL) cl_print(outfile," ");
     }

   return(1);
  }

/*****************************************/
/* pat_pp: prints out a pattern line.    */
/*****************************************/   
pat_pp(tmpptr,outfile)
  struct node *tmpptr;
  FILE *outfile;
  {
   struct node *b_ptr;

   if (tmpptr == NULL) return(1);

   /* check for binder */
   if ((tmpptr != NULL) && (tmpptr->type == BINDER))
     {
      sprintf(GLOBALSTR,"?%s <- (",tmpptr->svalue);
      cl_print(outfile,GLOBALSTR);
      tmpptr = tmpptr->right;
     }
   else
     { cl_print(outfile,"("); }

   while (tmpptr != NULL)
     {
      b_ptr = tmpptr;
      while (b_ptr != NULL)
        {
         if (b_ptr->state == 'n') cl_print(outfile,"~");

         print_item(b_ptr->type,b_ptr->svalue,b_ptr->ivalue,
                    b_ptr->cond,outfile);
    
         if (b_ptr->conn == '&') cl_print(outfile,"&");
         else if (b_ptr->conn == '|') cl_print(outfile," | ");

         b_ptr = b_ptr->bottom;
        }         

      tmpptr = tmpptr->right;
      if (tmpptr != NULL) cl_print(outfile," ");
     }
   cl_print(outfile,")");
  }
   
/****************************************************/
/* rhs_pp: Pretty prints right hand side actions.   */
/****************************************************/
rhs_pp(action,outfile,white_space)
  struct comm *action;
  FILE *outfile;
  int white_space;
  {
   struct comm *act_vals;

   while (action != NULL)
     {
      /* Pretty print assert action. */
      if (action->value == KASSERT)
        {
         cl_print(outfile,"\n");
         put_spaces(white_space,outfile);
         cl_print(outfile,"(assert (");
         act_vals = action->args;         
         while (act_vals != NULL)
           { 
            print_item(act_vals->name,act_vals->value,
                       act_vals->ivalue,act_vals->cond,outfile);
            act_vals = act_vals->args;
            if (act_vals != NULL) { cl_print(outfile," "); } 
           }
         cl_print(outfile,"))");
        }
      /* Pretty print printout and retract action. */
      else if ((action->value == KPRINTOUT) ||
               (action->value == RETRACT))
        {
         cl_print(outfile,"\n");
         put_spaces(white_space,outfile);
         sprintf(GLOBALSTR,"(%s ",action->value);
	 cl_print(outfile,GLOBALSTR);
         act_vals = action->args;         
         while (act_vals != NULL)
           { 
            print_item(act_vals->name,act_vals->value,
                       act_vals->ivalue,act_vals->cond,outfile);
            act_vals = act_vals->args;
            if (act_vals != NULL) { cl_print(outfile," "); }  
           }
         cl_print(outfile,")");
        }
      /* Pretty print bind action. */
      else if (action->value == KBIND)
        {
         cl_print(outfile,"\n");
         put_spaces(white_space,outfile);
         sprintf(GLOBALSTR,"(bind ?%s ",action->name);
	 cl_print(outfile,GLOBALSTR);
         pp_test(action->cond,outfile);
         cl_print(outfile,")");
        }
      /* Pretty print call action. */
      else if (action->value == KCALL)
        {
         cl_print(outfile,"\n");
         put_spaces(white_space,outfile);
         cl_print(outfile,"(call ");
         pp_test(action->cond,outfile);
         cl_print(outfile,")");
        }
      /* Pretty print while action. */
      else if (action->value == KWHILE)
        {
         cl_print(outfile,"\n");
         put_spaces(white_space,outfile);
         cl_print(outfile,"(while ");
         pp_test(action->cond,outfile);
         rhs_pp(action->args,outfile,white_space + 3);
         cl_print(outfile,")");
        }
      /* Pretty print if action. */
      else if (action->value == KIF)
        {
         cl_print(outfile,"\n");
         put_spaces(white_space,outfile);
         cl_print(outfile,"(if ");
         pp_test(action->cond,outfile);
         cl_print(outfile,"\n");
         put_spaces(white_space + 3,outfile);
         cl_print(outfile,"then");
         rhs_pp(action->args->next,outfile,white_space + 3);
         if (action->args->args != NULL)
           {
            cl_print(outfile,"\n");
            put_spaces(white_space + 3,outfile);
            cl_print(outfile,"else");
            rhs_pp(action->args->args->next,outfile,white_space + 3);
           }
         cl_print(outfile,")");
        }
         
      action = action->next;
     }
  }

/****************************************************/
/* print_item: Prints out a single item.            */
/****************************************************/
print_item(type,string,number,exp,outfile)
  char *type, *string;
  float number;
  struct test *exp;
  FILE *outfile;
  {
   if (type == WORD)
     { cl_print(outfile,string); }
   else if (type == STRING)
     { 
      sprintf(GLOBALSTR,"\"%s\"",string);
      cl_print(outfile,GLOBALSTR);
     }
   else if (type == BWORD) 
     {
      cl_print(outfile,"?");
      cl_print(outfile,string);
     }
   else if (type == BWORDS) 
     {
      cl_print(outfile,"$?");
      cl_print(outfile,string);
     }
   else if (type == NUMBER) /* float num fix 1 */
     { print_num(outfile,number); }  /* bug fix 10 */
   else if (type == SINGLE)
     { cl_print(outfile,"?"); }
   else if (type == MULTIPLE)
     { cl_print(outfile,"$?"); }
   else if (type == FCALL)
     { 
      cl_print(outfile,"=");
      pp_test(exp,outfile);
     }
   else if (type == COAMP)
     { 
      cl_print(outfile,":");
      pp_test(exp,outfile); 
     }
   else 
     { 
      sprintf(GLOBALSTR,"*** %s ***",string);
      cl_print(outfile,GLOBALSTR);
     }
  }

/************************************************************/
/* command_loop: prompts the user for clips commands and    */
/*   calls the appropriate functions to execute the command */
/************************************************************/
command_loop()
  { 
   while (TRUE)
     {
      flush_save_buffer();
      EXPECTING_EOL = FALSE;     /* new code */
      PARSE_ERROR = FALSE;
      cl_print(wclips,"CLIPS> ");
      gettoken(stdin);
      if ((token != LPAREN) && (token != STOP))
        {
         cl_print(wdialog,"Expected a '('\n");
         flush_term();
        }
      else if (token == LPAREN)
        {
         gettoken(stdin);
         if ((token != WORD) && (token != OPERATOR)) /* top level fix 1 */
           {
            cl_print(wdialog,"Expected a command.\n");
            flush_term();
           }
         else
           { route_command(TKNWORD); }
        }
     }
  }	

/*******************************************/
/* route_command:                          */
/*******************************************/
route_command(command)
  char *command;
  {
   struct values *result;
   struct test *top, *new_add, *last_add;
 
   /*============================*/
   /* Evaluate Top Level Assert? */
   /*============================*/

   if (command == KASSERT)
     { 
      assert_command();
      return(0);
     }

   /*==============================*/
   /* Evaluate Top Level Deffacts? */
   /*==============================*/

   if (command == DEFFACTS)
     {
      parse_deffacts(stdin);
      if (token != STOP) flush_term();
      return(0);
     }

   /*=============================*/
   /* Evaluate Top Level Defrule? */
   /*=============================*/

   if (command == DEFRULE)
     {
      parse_rule(stdin);
      if (PARSE_ERROR == TRUE)
        { 
         cl_print(wdialog,"\nERROR:\n"); 
         cl_print(wdialog,save_buffer); /* bug fix 3 */
         cl_print(wdialog,"\n");
        }
      if (token != STOP) flush_term();
      return(0);
     }

   /*================================*/
   /* Parse Top Level Function Call. */
   /*================================*/

   currentrule = "top level command";

   if (find_function(command) == FALSE)
     {       
      cl_print(wdialog,"Missing function declaration for ");
      sprintf(GLOBALSTR,"%s in %s.\n",command,currentrule);
      cl_print(wdialog,GLOBALSTR);
      if (token != STOP) flush_term();
      return(0); 
     }

   top = get_test();
   top->utype = FCALL;        
   top->utest.sval = command;

   last_add = NULL;
   new_add = NULL;

   while ( (new_add = parse_test_construct(stdin)) != NULL)
     {
      if (last_add == NULL)
        { top->arg_list = new_add; }
      else
        { last_add->next_arg = new_add; }
      last_add = new_add;
     }

   if (PARSE_ERROR == TRUE)
     {
      returntests(top);
      if (token != STOP) flush_term();
      return(0);
     }

   /*===================================*/
   /* Evaluate Top Level Function Call. */
   /*===================================*/

   EVAL_PRINT = TRUE;
   result = generic_compute(top,NULL,NULL);
   returntests(top);

   if (EVAL_PRINT == FALSE) { return(0); }

   if (result->type == NUMBER)
     { 
      print_num(stdout,result->ivalue);
      cl_print(wdialog,"\n");
     }
   else if (result->type == WORD)
     {
      sprintf(GLOBALSTR,"%s\n",result->value);
      cl_print(wdialog,GLOBALSTR);
     }
   else if (result->type == STRING)
     {
      sprintf(GLOBALSTR,"\"%s\"\n",result->value);
      cl_print(wdialog,GLOBALSTR);
     }

   return(0);
  }

/*******************************************/
/* define_commands:                        */
/*******************************************/
define_commands()
  {
   float pprule_command(), displayfacts();
   float rule_display(), printagenda();
   float reset_command(), clear_command();
   float load_command(), run_command();
   float watch_command(), unwatch_command();
   float exit_command(), excise_command();
   float save_command(), comm_retract();
   float undeffacts_command();

   define_function("pprule",'f',pprule_command);
   define_function("facts",'f',displayfacts);
   define_function("rules",'f',rule_display);
   define_function("agenda",'f',printagenda);
   define_function("watch",'f',watch_command);
   define_function("unwatch",'f',unwatch_command);
   define_function("reset",'f',reset_command);
   define_function("clear",'f',clear_command);
   define_function("load",'f',load_command);
   define_function("save",'f',save_command);
   define_function("run",'f',run_command);
   define_function("exit",'f',exit_command);
   define_function("excise",'f',excise_command);
   define_function("retract",'f',comm_retract);
   define_function("undeffacts",'f',undeffacts_command);
  }

/*******************************************/
/* flush_web: Purpose is to flush the web. */
/*******************************************/
flush_web(pat_net)
  struct pat_node *pat_net;
  {
   struct pat_node *pat_ptr;
   struct bind_node *bind_ptr;

   pat_ptr = pat_net;
   while (pat_ptr != NULL)
     {
      if (pat_ptr->check_list->type == STOP)
        {
         bind_ptr = pat_ptr->var_list;
         while (bind_ptr != NULL)
           {            
            clear_path(bind_ptr->entrance);            
            bind_ptr = bind_ptr->next_list;
           }
        }
      else
        { flush_web(pat_ptr->next_level); }
      pat_ptr = pat_ptr->same_level;
     }
  }

/*******************************************/
/* clear_path                              */
/*******************************************/
clear_path(list_ptr)
  struct list *list_ptr;
  {
   struct internode *node_ptr;

   while (list_ptr != NULL)
     {
      node_ptr = list_ptr->path;

      /*===========================================*/
      /* Clear bindings from LHS and RHS of joins. */
      /*===========================================*/

      while (node_ptr->next != NULL)
        {
         if (node_ptr->rhs != NULL)
           { 
            returnlr(node_ptr->rhs);
            node_ptr->rhs = NULL;
           }
         if (node_ptr->lhs != NULL)
           {
            returnlr(node_ptr->lhs);
            node_ptr->lhs = NULL;
           }
         node_ptr = node_ptr->next;
        }

      /*========================*/
      /* System Error Checking. */
      /*========================*/
 
      if (node_ptr->lhs != NULL)
        {
         cl_print(wdialog,"*** SYSTEM LOGIC ERROR: clear_path ***\n");
         cl_print(wdialog,"LHS of action join should be empty\n");
         cl_exit(1);
        }

      list_ptr = list_ptr->next;
     }
  }

/*******************************************/
/* returnlr                                */
/*******************************************/
returnlr(plr)
  struct lr *plr;
  {
   struct lr *plrtemp;

   while (plr != NULL)
     {
      returnvalues(plr->locals);
      plrtemp = plr->next;
      rtn_lr(plr);
      plr = plrtemp;
     }
  }		

/************************************************************************/
/* setnots: The purpose of this code is to set the patterns that have   */
/*    a not condition before them to true until a pattern matches them. */
/************************************************************************/
setnots(pat_net)
  struct pat_node *pat_net;
  {
   extern int NID;

   struct list *list_of_entry_joins;
   struct pat_node *pat_ptr;
   struct bind_node *bind_ptr;        
   struct internode *join;          
   struct lr *new_lr;

   pat_ptr = pat_net;

   while (pat_ptr != NULL)
     { 
      if (pat_ptr->check_list->type == STOP)
        {
         bind_ptr = pat_ptr->var_list;
         while (bind_ptr != NULL)
           {
            list_of_entry_joins = bind_ptr->entrance;
            while (list_of_entry_joins != NULL)
              {
               if ((list_of_entry_joins->boolean == '-') &&
                   (list_of_entry_joins->path->lhs_log == 'e'))
                 {
                  join = list_of_entry_joins->path;
                  join->id = NID;
                  new_lr = get_lr();
                  new_lr->next = NULL;
	          new_lr->locals = newnid(NID);
                  NID--;
	          drive(new_lr,join->next,LHS);
	         }
               list_of_entry_joins = list_of_entry_joins->next;
              }
            bind_ptr = bind_ptr->next_list;
           }
        }
      else
        { setnots(pat_ptr->next_level); }
      pat_ptr = pat_ptr->same_level;
     }
  }

/*************************************************************/
/* close_test: Checks that a command has a closing right     */
/*   parenthesis and that no tokens follow the closing right */
/*   parenthesis.                                            */
/*************************************************************/
close_test()
  {
   if (token == STOP)
     {
      cl_print(wdialog,"Expected closing ')'\n");
      return(FALSE);
     }

   gettoken(stdin);
   if (token != RPAREN)
/* FGW's patch for damaged file starts with PAREN in line above */
     {
      cl_print(wdialog,"Expected right parenthesis\n");
      return(FALSE);
     }
   EXPECTING_EOL=TRUE;
   gettoken(stdin);
   if (token != STOP)
     {
      cl_print(wdialog,"Expected end of line\n");
      return(FALSE);
     }
     return(TRUE);
  }

flush_term(){
	fflush(stdin);
}
	
put_spaces(int indent,FILE *outfile){
	int n;
	for (n=0;n<indent;n++){
		putc(' ',outfile);
	}
}
