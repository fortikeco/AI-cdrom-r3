/* -*- Mode: PL1; Fonts: MEDFNB -*- */

/****************************************************************/
/*         "C" Language Integrated Production System            */
/*                      STRUCTURES                              */
/****************************************************************/

/********************************************************/
/* Fact_marker is used in the pattern matching process  */
/* to match $? and $?variables.  It is used to indicate */
/* that a single pattern element may span more than one */
/* fact element.                                        */
/********************************************************/

struct fact_marker
   {
    int element;
    int start;                                   
    int end;
    struct fact_marker *next;
   };

struct basic
  {
   char *type;
   struct basic *or;
   struct basic *next; 
   float ivalue;                             
   char *svalue;
   char state;
   char conn;
  };

/*******************************************************************/
/* Pat_node:                                                       */
/* Used to join together the tree of elements which constitute     */
/* the pattern network.  For a given node, last_level points to    */
/* the previous element in the pattern, same_level points to other */
/* elements which may fill this slot in the pattern, and next      */
/* level points to the elements which may fill the next position   */
/* assuming that this element is matched.  Check_list holds the    */
/* actual pattern element (e.g. (?, blue | red , ~3, $?, end of    */
/* pattern)).  If the element to be matched is the end of the      */
/* pattern, then var_list will contain the list of variable        */ 
/* bindings, functions call, and predicate tests which must be     */
/* made for the pattern.                                           */
/*******************************************************************/
struct pat_node
  {
   struct pat_node *same_level;
   struct pat_node *prev;
   struct pat_node *next_level;
   struct pat_node *last_level;        
   struct basic *check_list;
   struct bind_node *var_list;
  };

struct bind_node
  {
   struct bind_node *next_list;
   struct bind_node *next_bind;  
   char *type;
   char *var_name;
   char logic;
   int start_pos;
   int prev_bound;
   struct list *entrance;
   struct test *expression;
  };
   

/*****************************************************/
/* union is used for only one of the three are       */
/* needed for slot needs.  These are operator, name, */
/* and floating value(constant).                     */
/*****************************************************/

struct test 
   {
    char *utype;       /* test fix 1 - changed from char to *char */
    union  
      {
       float fvalue;   /* remove operator after this */
       char *sval;               
       } utest;
    struct test *arg_list;
    struct test *next_arg;
   };

/***************************************/
  
struct draw
  {
   char *contents;
   struct draw *next;
  };

/*************************************/

struct ruleinfo
  {
   char *name;
   struct ruleinfo *next;
   struct patptr *pats;
   struct node *ppinfo;
   struct internode *rhs_info;
  };

struct patptr
  {
   struct pat_node *pptr;
   struct bind_node *lptr;			
   struct patptr *next;
  };

/* link: Creates a linked list out of the test structures */

struct link
   {
    char *type;
    char state;
    char conn;
    struct test *hook;
    struct link *next;
   };

struct node
  {
   char *type;
   float ivalue;
   char *svalue;
   struct node *right;
   struct node *bottom;
   char state;
   char conn;
   struct test *test;
   struct test *cond;
  };

/**************************************************************/

struct match
  {
   struct match *next;
   struct pat_node *slot;
  };

/***************************************************************/

struct list
  {
   char boolean;              /* Entry logic: '+' or '-' */
   struct internode *path;    /* Points to entry join    */
   struct list *next;         
  };


/****************************************************************/

struct internode
  {
   struct lr *lhs;            /* Bindings from left hand side      */
   struct lr *rhs;            /* Bindings from right hand side     */
   char lhs_log;              /* Left hand side logic:  '+' or 'e' */
   char rhs_log;              /* Right hand side logic: '+' or '-' */
   struct link *cond;         /* List of test conditions           */
   struct link *rhs_test;     /* List of rhs test conditions       */
   int id;                    /* Not id if "e -" join              */
   struct internode *next;    /* The next join to enter            */
  };

/***************************************************************/

struct values
  {
   char *name;
   char *value;
   struct values *next;
   int whoset;
   float ivalue;
   struct fact *origin;
   char *type;
   char state;
   struct test *cond;
   struct values *multiple;
  };

/************************************************************/

struct comm
  {
   char *name;
   char *value;
   float ivalue;
   struct comm *next;
   struct comm *args;
   struct test *cond;
  };

/************************************************************/

struct lr 
  {
   struct values *locals;
   struct lr *next;
  };


/*********************************************************/

struct fact
  {
   struct element *word;   /* Pointer to list of individual  */
                           /* elements of the fact.          */
   struct match *list;     /* List of matches for this fact. */
   char *name;           
   int ID;               
   struct fact *next;     
   struct fact *previous;  
  };

/*************************************************************/

struct element
  {
   char *facts;
   struct element *next;
   float ivalue;
   char *type;
  };

/*******************************************/

struct funtab
  {
   char *fun_name; /* function name */
   char fun_type;  /* function type */
   int (*ip)();
   char (*cp)();
   char *(*sp)();
   double (*fp)();
   struct funtab *next;
  };

/***********************************************************/
/* functions which use the structures                      */
/***********************************************************/

struct draw         *new_draw();
struct funtab       *new_funtab();
struct fact         *get_fact();
struct element      *get_element();
struct comm         *get_comm();
struct node         *get_node();
struct basic        *get_basic();
struct pat_node     *get_pnode();
struct bind_node    *get_bind_node();
struct test         *get_test();
struct ruleinfo     *get_ruleinfo();
struct patptr       *get_patptr();
struct link         *get_link();
struct list         *get_list();
struct internode    *get_internode();
struct values       *get_values();
struct match        *get_match();
struct lr           *get_lr();
struct fact_marker  *get_fmarker();
