/* CLIPS Version 3.1   9/18/86 */

/*********************************************************************/
/*         "C" Language Integrated Production System                 */
/*                      PARSING FUNCTIONS                            */
/*********************************************************************/
#include <stdio.h>
#include "clips.h"

#define HASHSIZE 167
#define WORDLENGTH 100
#define EOS     '\0'
#define TRUE 1
#define FALSE 0
  
char GLOBALSTR[512];
char *token;
float TKNNUMBER;
char *TKNWORD;
int EXPECTING_EOL;      /* new code */

int SPC_SIG = TRUE;     /* new code */

char *fetchvar();
char *fetchany();
char *getstring();
char *genalloc();
char *get_some_mem();

struct draw *hashtable[HASHSIZE];

/*####################################################################*/
/*####################################################################*/
/*###                                                              ###*/
/*###                  CONSTANT INITIALIZATION                     ###*/
/*###                                                              ###*/
/*####################################################################*/
/*####################################################################*/

char *NOT;
char *KPRINTOUT;
char *KFPRINTOUT;
char *FCALL;
char *LNOT;
char *LAND;
char *LOR;
char *SPLIT;
char *RETRACT;
char *NUMBER;
char *COAMP;
char *COMMA;
char *KDOLLAR;
char *STRING;
char *STOP;
char *PATTERN;
char *KASSERT;
char *DEFFACTS;
char *DEFRULE;
char *SALIENCE;
char *KAND;
char *KOR;
char *QUOTATION;
char *SEPARATOR;
char *BINDER;
char *MULTIPLE;
char *LPAREN;
char *RPAREN;
char *SINGLE;
char *WORD;
char *BWORD;
char *BWORDS;
char *OPERATOR;
char *TEST;
char *DOLLARS;
char *NUM;

char *KCALL;
char *KBIND;

char *KTAB;
char *KCRLF;

char *KACTIVATIONS;

char *KANALYZE;
char *KIF;
char *KTHEN;
char *KELSE;
char *KDECLARE;
char *KWHILE;
char *KUNDEFFACTS;

char *KSHOW1;
char *KSHOW2;
char *KSHOW3;

char *KUNKNOWN;

char *KADD;
char *KSUBTRACT;
char *KMULT;
char *KDIVIDE;
char *KGTEQ;
char *KLTEQ;
char *KGT;
char *KLT;
char *KEQ;
char *KNEQ;
char *KTAND;
char *KTOR;
char *KTNOT;
char *KEXP;

/*******************************************************************/
/* init_keywords: Initializes the values of key words and symbols  */
/*   used by the parser.  String compares can then be accomplished */
/*   between words with a simple pointer comparison.               */
/*******************************************************************/
init_keywords()
  {
   KPRINTOUT    = getstring("printout");
   KFPRINTOUT   = getstring("fprintout");
   NOT	        = getstring("not");
   LNOT	        = getstring("~");
   LAND	        = getstring("&");
   STRING       = getstring("string");
   LOR	        = getstring("|");
   SPLIT        = getstring("split");
   RETRACT      = getstring("retract");
   NUMBER       = getstring("number");
   COAMP        = getstring("&:");
   COMMA        = getstring(",");
   KDOLLAR      = getstring("$");
   STOP	        = getstring("stop");
   PATTERN      = getstring("pattern");
   KASSERT      = getstring("assert");
   DEFFACTS     = getstring("deffacts");
   DEFRULE      = getstring("defrule");
   SALIENCE     = getstring("salience");
   KAND	        = getstring("and");
   KOR	        = getstring("or");
   QUOTATION    = getstring("\"");
   SEPARATOR    = getstring("=>");
   BINDER       = getstring("<-");
   MULTIPLE     = getstring("$?");
   LPAREN       = getstring("(");
   RPAREN       = getstring(")");
   SINGLE       = getstring("?");
   WORD	        = getstring("word");
   BWORD        = getstring("bword");
   BWORDS       = getstring("bwords");
   FCALL        = getstring("fcall");
   OPERATOR     = getstring("operator");
   TEST	        = getstring("test");
   DOLLARS      = getstring("$$$");
   NUM	        = getstring("$$n");
   STOP	        = getstring("stop");
   KCALL        = getstring("call");
   KBIND        = getstring("bind");
   KTAB         = getstring("tab");
   KCRLF        = getstring("crlf");
   KACTIVATIONS = getstring("activations");
   KANALYZE     = getstring("analyze");
   KIF          = getstring("if");
   KTHEN        = getstring("then");
   KELSE        = getstring("else");
   KUNDEFFACTS  = getstring("undeffacts");
   KDECLARE     = getstring("declare");
   KWHILE       = getstring("while");
   KSHOW1       = getstring("show1");
   KSHOW2       = getstring("show2");
   KSHOW3       = getstring("show3");
   KUNKNOWN     = getstring("unknown");
   KADD         = getstring("+");
   KSUBTRACT    = getstring("-");
   KMULT        = getstring("*");
   KDIVIDE      = getstring("/");
   KGTEQ        = getstring(">=");
   KLTEQ        = getstring("<=");
   KGT          = getstring(">");
   KLT          = getstring("<");
   KEQ          = getstring("=");
   KNEQ         = getstring("!=");
   KTAND        = getstring("&&");
   KTOR         = getstring("||");
   KTNOT        = getstring("!");
   KEXP         = getstring("**");
  }
       
/*####################################################################*/
/*####################################################################*/
/*###                                                              ###*/
/*###                          SCANNER                             ###*/
/*###                                                              ###*/
/*####################################################################*/
/*####################################################################*/

/*********************************************************************/
/*gettoken: Purpose is to fetch an input token. The rules that apply */
/*          to what an input token can resemble are those of the     */
/*          system.  It returns the token type in the global variable*/
/*          <token>, and the token value in the global <word>.       */
/*********************************************************************/
gettoken(infile)
 FILE *infile;
 {
   extern float TKNNUMBER;
   extern char *token;
   extern char *TKNWORD;

   int inchar;
   float fetchnum();

   /*=======================================*/
   /* Set Unknown default values for token. */
   /*=======================================*/

   token = KUNKNOWN;
   TKNWORD = KUNKNOWN;
   TKNNUMBER = 0.0;

   /*==============================================*/
   /* Remove all white space before processing the */ 
   /* gettoken() request.                          */
   /*==============================================*/

   inchar = savegetc(infile);
   while ((inchar == ' ') || (inchar == '\n') ||
          (inchar == ';') || (inchar == '\t'))
         {
          /* if input from terminal, stop at CR */
          
          if ((inchar == '\n') &&
              (SPC_SIG == TRUE) &&       /* new code */ 
              (infile == stdin) &&
              (EXPECTING_EOL == TRUE))   /* new code */
            {
             token = STOP;
             return(1);
            }
          
 
          if (inchar == ';')               /*   remove comment lines */
            {
             while ((inchar = savegetc(infile)) != '\n');
             if ((infile == stdin) && 
                 (EXPECTING_EOL == TRUE)) /* new code */
               {
                token = STOP;
                return(1);
               }
            }
          inchar = savegetc(infile);
         }

/********************   Process actual line   *************************/

   if (((inchar >= 'a') && (inchar <= 'z')) ||
       ((inchar >= 'A') && (inchar <= 'Z')))
     {
      token = WORD;
      unsavegetc(inchar,infile);
      TKNWORD = fetchvar(infile);
     }
   else if (inchar == '"')                    /* get a quoted word token */
          {
	   TKNWORD = fetchany(infile);
	   token = STRING;
          }
   else if (inchar == '(')                      /* open parentheses */
	  { token = LPAREN; }
   else if (inchar == ')')                      /* close parenthese */
	  { token = RPAREN; }
   else if ((inchar >= '0') && (inchar <= '9'))  /* get a number token */
          {
           unsavegetc(inchar,infile);
           TKNNUMBER = fetchnum(infile);
           TKNWORD = NUMBER;
	   token = NUMBER;
          }
   else if (inchar == '-')                     

/* got a minus sign, check context to see how to interpret it */

          {
	   inchar = savegetc(infile);
	   if ((inchar == '.') ||        /* number or decimal follows, */
               ((inchar >= '0') &&       /* process as numerical token */
                (inchar <= '9')))
              {
               unsavegetc(inchar,infile);
               unsavegetc('-',infile);
               TKNNUMBER = fetchnum(infile);
               TKNWORD = NUMBER;
	       token = NUMBER;
              }
           else                        /* otherwise, use it as the */
              {                        /* subtraction operator     */
               token = OPERATOR;
               TKNWORD = KSUBTRACT;
	       unsavegetc(inchar,infile);
	      }
          }
   else if (inchar == '+')

/* got a plus sign, check context to see how to interpret it */

          {
	   inchar = savegetc(infile);
	   if ((inchar == '.') ||         /* number or decimal follows, */
               ((inchar >= '0') &&        /* process as numerical token */
                (inchar <= '9')))
              {
               unsavegetc(inchar,infile);
               unsavegetc('+',infile);
               TKNNUMBER = fetchnum(infile);
	       token = NUMBER;
              }
           else                                /* otherwise, use as the */
              {                                /* ADD operator.         */
               token = OPERATOR;
               TKNWORD = KADD;
	       unsavegetc(inchar,infile);
	      }
          }
   else if (inchar == '?')                    /* get a variable name */
          {
           inchar = savegetc(infile);
           if (((inchar >= 'a') && (inchar <= 'z')) ||
               ((inchar >= 'A') && (inchar <= 'Z')))
             {
              unsavegetc(inchar,infile);
              TKNWORD = fetchvar(infile);
	      token = BWORD;
             }
           else
             {
	      token = SINGLE;
              unsavegetc(inchar,infile);
             }
	  }
   else if (inchar == '&')
          {
	   if ((inchar = savegetc(infile)) == '&')
	     {
	      token = OPERATOR;
   	      TKNWORD = KTAND;
	     }
           else
	     {
	      unsavegetc(inchar,infile);
	      token = LAND;
	     }
	  }
   else if (inchar == ':')
          { token = COAMP; }
   else if (inchar == '|') 
          {
	   if ((inchar = savegetc(infile)) == '|')
	     {
	      token = OPERATOR;
	      TKNWORD = KTOR;
	     }
	   else
	     {
	      unsavegetc(inchar,infile);
	      token = LOR;
	     }
	  }
   else if (inchar == '~') 
	  { token = LNOT; }
   else if (inchar == '$')
          {
	   if ((inchar = savegetc(infile)) == '?')
             {
              inchar = savegetc(infile);
              if (((inchar >= 'a') && (inchar <= 'z')) ||
                  ((inchar >= 'A') && (inchar <= 'Z')))
                {
                 unsavegetc(inchar,infile);
                 TKNWORD = fetchvar(infile);
		 token = BWORDS;
                }
              else
		{
		 token = MULTIPLE;
                 unsavegetc(inchar,infile);
	        }
	     }
           else 
             {
	      token = KDOLLAR;
	      unsavegetc(inchar,infile);
             }
          }
   else if (inchar == '=') 
	  {
           if ((inchar = savegetc(infile)) == '>')
             { token = SEPARATOR; }
           else
   	     {
	      token = OPERATOR;
	      TKNWORD = KEQ;
	      unsavegetc(inchar,infile);
	     }
	  }
   else if (inchar == '<')
	  {
           if ((inchar = savegetc(infile)) == '-')
	     { token = BINDER; }
	   else if (inchar == '=')
	          {
	           token = OPERATOR;
	           TKNWORD = KLTEQ;
	          }
	        else
	          {
	           unsavegetc(inchar,infile);
		   token = OPERATOR;
	           TKNWORD = KLT;
	          }
 	  }
   else if (inchar == EOF)
	  { token = STOP; }
        else 
          {
	   token = OPERATOR;
           switch(inchar)
	   {
	    case '/' : TKNWORD = KDIVIDE; break;
	    case '*' : 
		       if ((inchar = savegetc(infile)) == '*')
		         { TKNWORD = KEXP; }
		       else
			 {
			  TKNWORD = KMULT;
		          unsavegetc(inchar,infile);
		         }
		       break;
	    case '>' : 
		       if ((inchar = savegetc(infile)) == '=')
			 { TKNWORD = KGTEQ; }
		       else
			 {
			  TKNWORD = KGT;
			  unsavegetc(inchar,infile);
			 }
		       break;
            case '!' :
		       if ((inchar = savegetc(infile)) == '=')
			 { TKNWORD = KNEQ; }
		       else
			 {
			  TKNWORD = KTNOT;
			  unsavegetc(inchar,infile);
			 }
		       break;
            default: 
                     cl_print(wdialog,"Unidentified input character ");
                     sprintf(GLOBALSTR," %c (ASCII %d) found\n",inchar,inchar);
		     cl_print(wdialog,GLOBALSTR);
                     token = KUNKNOWN;
                     TKNWORD = KUNKNOWN;
               }
	   }/*else switch*/
   }/*gettoken*/

/**********************************************************************/
/* fetchvar:  The purpose of fetchvar is to input one legal variable  */
/*   name. A legal variable name consists of letters, numbers, "-"'s, */
/*   and "_"'s in any sequence, until any other character is read.    */
/**********************************************************************/
char *fetchvar(infile)
FILE *infile;
  {
   char wordt[WORDLENGTH];
   int count = 0;
   int inchar;

   inchar = savegetc(infile);
   while (((inchar >= 'a') && (inchar <= 'z')) ||
          ((inchar >= 'A') && (inchar <= 'Z')) ||
          (inchar == '-') ||
          (inchar == '_') ||
          ((inchar <= '9') && (inchar >= '0')))
      { 
       wordt[count++] = inchar;
       inchar = savegetc(infile);
      }

   wordt[count] = EOS;

   unsavegetc(inchar,infile);   /* stuff last character back into buffer */
   return(getstring(wordt));    /* and return the word through hasher    */
  }

/********************************************************************/
/* fetchany:  The purpose of fetchany is to input one word with any */
/*   embedded characters. It is delimited by a leading and trailing */
/*   double quote.                                                  */
/********************************************************************/
char *fetchany(infile)
FILE *infile;
  {
   char wordt[WORDLENGTH];
   int count = 0;
   int inchar;

   inchar = savegetc(infile);                          /* new code */
   while ((inchar != '"') || (SPC_SIG == FALSE))       /* new code */
     {
      if (count > (WORDLENGTH - 2))
        {
         cl_print(wdialog,"SYSTEM ERROR\n");
         sprintf(GLOBALSTR,"Maximum token length of %d exceeded\n",WORDLENGTH);
	 cl_print(wdialog,GLOBALSTR);
         cl_exit(2);
        }

      /* if (inchar == '\\') */                     /* new code */
      /*   { inchar = savegetc(infile); } */        /* new code */

      if (((inchar == '\n') && (SPC_SIG == FALSE)) ||  /* new code */
          (inchar == EOF))
        {   
         unsavegetc(inchar,infile); 
         wordt[count] = EOS;
         return(getstring(wordt));
        }
 
      wordt[count++] = inchar;
      inchar = savegetc(infile);             /* new code */       
     }
         
   wordt[count] = EOS;
   return(getstring(wordt));
  }

/********************************************************************/
/* fetchnum:  The purpose of fetchnum is to input a numeric value   */
/*   and return it as a token. The number may be proceeded by a '+' */
/*   or a '-' sign, and may be in exponential form.                 */
/********************************************************************/
float fetchnum(infile)
FILE *infile;
  {
   char wordt[WORDLENGTH];
   int count = 0;
   int inchar;
   double atof();                  /* convert string to double */

   inchar = savegetc(infile);
   while ((inchar == '+') || (inchar == '-') ||
          (inchar == '.') ||
          (inchar == 'e') || (inchar == 'E') ||
          ((inchar <= '9') && (inchar >= '0')))
        { 
         wordt[count++] = inchar;
         inchar = savegetc(infile);
        }

   wordt[count] = EOS;

   unsavegetc(inchar,infile);   /* stuff last character back into buffer */
   return((float) atof(wordt));    /* and return the number */
  }

/*********************************************************************/
/*inum: Fetch the next float number from the input stream.           */
/*********************************************************************/
float inum(infile)
   FILE *infile;
   {
    float temp;
    float count;
    int inchar;
    temp = 0;
    /***********/
    inchar = savegetc(infile);

    while ((inchar <= '9') && (inchar >= '0'))
       {
        temp = temp*10 + (inchar - '0');
        inchar = savegetc(infile);
       }
    if (inchar == '.')
       {
        inchar = savegetc(infile);
        count = 10;
        while ((inchar <= '9') && (inchar >= '0'))
           {
            temp = temp + ((inchar - '0')/count);
            count = count * 10.0;
            inchar = savegetc(infile);
           }
        }
   unsavegetc(inchar,infile);
   return(temp);
}

int save_pos = 0;
int max_save_length = 490;
char save_buffer[490];

flush_save_buffer()
  {
   save_pos = 0;
   save_buffer[0] = EOS;
  }

savegetc(infile)
  FILE *infile;
  {
   int inchar;
   
   SPC_SIG = TRUE;           /* new code */
   inchar = cl_getc(infile);
   /* new code */
   if (inchar == '\\') 
     {
      SPC_SIG = FALSE;
      inchar = cl_getc(infile);
     }

   if ((save_pos < (max_save_length - 3)) && (inchar != -1))
     {
      if (SPC_SIG == FALSE)
        { save_buffer[save_pos++] = '\\'; }
      save_buffer[save_pos++] = (char) inchar;
      save_buffer[save_pos] = EOS;
     }
   return(inchar);
  }

unsavegetc(outchar,infile)
  int outchar;
  FILE *infile;
  {   
   cl_ungetc(outchar,infile);
   if (save_pos > 0)
     { save_pos--; }

   /* new code */
   if ((SPC_SIG == FALSE) && (save_pos > 0))
     { save_pos--; }

   save_buffer[save_pos] = EOS;
  }

print_save_buffer()
  {
   int i = 0;
   while (save_buffer[i] != EOS)
     {
      sprintf(GLOBALSTR,"%c",save_buffer[i]);
      cl_print(wdialog,GLOBALSTR);
      i++;
     }
  }

/*####################################################################*/
/*####################################################################*/
/*###                                                              ###*/
/*###                      HASHING FUNCTIONS                       ###*/
/*###                                                              ###*/
/*####################################################################*/
/*####################################################################*/
	  
/*******************************************************************/
/* getstring:  Searches for the string in the hash table. If the   */ 
/*   string is already in the hash table, then the address of the  */
/*   string is returned.  Otherwise, the string is hashed into the */
/*   table and the address of the string is also returned.         */
/*******************************************************************/
char *getstring(str)
   char *str;
   {
    extern struct draw *hashtable[];
    int tally;
    struct draw *past, *peek;
    
    /*====================================*/
    /* Get the hash value for the string. */
    /*====================================*/

    tally = hash(str);
    peek = hashtable[tally];

    /*==================================================*/
    /* If the hash table entry for the string is empty, */
    /* then place the string at that location, and      */
    /* return the address of the string.                */
    /*==================================================*/

    if (peek == NULL)
      {
       peek = new_draw(); 
       hashtable[tally] = peek;
       peek->contents = (char *) genalloc(strlen(str) + 1);
       peek->next = NULL;
       strcpy(peek->contents,str);
       return(peek->contents);
      }

    /*==================================================*/
    /* Search for the string in the list of entries for */ 
    /* this hash location.  If the string is found,     */
    /* then return the address of the string.           */
    /*==================================================*/

    while (peek != NULL)
      {
       if (strcmp(str,peek->contents) == 0)
	 { return(peek->contents); }
       past = peek;
       peek = peek->next;
      }

    /*==================================================*/
    /* Add the string at the end of the list of entries */
    /* for this hash location.  Return the address of   */
    /* the string.                                      */
    /*==================================================*/

    past->next = new_draw();
    peek = past->next;
    peek->contents = (char *) genalloc(strlen(str) + 1);
    peek->next = NULL;
    strcpy(peek->contents,str);
    return(peek->contents);
   }

/***************************************************************/
/* init_hash: Purpose is to initialize the hash table to NULL. */
/***************************************************************/
init_hash()
   {
    extern struct draw *hashtable[];
    int i;
    for (i=0; i<HASHSIZE; i++)
        hashtable[i] = NULL;
   }

/**********************************************************************/
/*hash: Finds the draw number for the string given to it, hash draw.  */
/**********************************************************************/
int hash(word)
   char *word;
   {
    int tally = 0;
    while (*word != EOS)
       {
        tally = tally + *word;
        word++;
       }
    return(tally % HASHSIZE);
   }
 
/*            
int hash(word)
   char *word;
   {
    int tally = 0, posn = 0;
    while (*word != EOS)
       {
        tally = tally + (*word)*posn;
        word++; posn++;           
        }
    return(tally % HASHSIZE);
   }
*/

/*####################################################################*/
/*####################################################################*/
/*###                                                              ###*/
/*###     MEMORY MANAGEMENT SECTION: ALLOCATION & DEALLOCATION     ###*/
/*###                                                              ###*/
/*####################################################################*/
/*####################################################################*/

struct values *free_values_list = NULL;
struct lr *free_lr_list = NULL;
struct match *free_match_list = NULL;
struct internode *free_internode_list = NULL;
struct element *free_element_list = NULL;
struct fact *free_fact_list = NULL;
struct fact_marker *free_fmarker_list = NULL;
struct node *free_node_list = NULL;
struct comm *free_comm_list = NULL;
struct basic *free_basic_list = NULL;
struct pat_node *free_pnode_list = NULL;
struct bind_node *free_bind_node_list = NULL;
struct test *free_test_list = NULL;
struct ruleinfo *free_ruleinfo_list = NULL;
struct patptr *free_patptr_list = NULL;
struct link *free_link_list = NULL;
struct list *free_list_list = NULL;

/********************************************************************/
/* get_fact_marker: allocates fact_marker structure from a list of  */
/*   available fact_marker structures.  Structure values must be    */
/*   initialized by calling routine.                                */
/********************************************************************/
struct fact_marker *get_fmarker()
  {
   extern struct fact_marker *free_fmarker_list;
   struct fact_marker *mem;

   if (free_fmarker_list == NULL)
     {
      mem = (struct fact_marker *) 
            get_some_mem(sizeof(struct fact_marker),"get_fact_marker");
     }
   else
     {
      mem = free_fmarker_list;
      free_fmarker_list = free_fmarker_list->next;
     }

   return(mem);
  }

/************************************************************/
/* rtn_fmarker: returns fact_marker structure to a list */
/*   of available fact_marker structures.                   */
/************************************************************/
rtn_fmarker(freed)
  struct fact_marker *freed;
  {
   struct fact_marker *temp;

   if (freed == NULL) { return(0); }

   temp = free_fmarker_list;
   free_fmarker_list = freed;

   free_fmarker_list->next = temp;
  }

/****************************************************************/
/* get_pnode:  allocates a pnode structure from a list of */
/*   available pnode structures.                             */
/****************************************************************/
struct pat_node *get_pnode()
  {
   extern struct pat_node *free_pnode_list;
   struct pat_node *mem;

   if (free_pnode_list == NULL)
     {
      mem = (struct pat_node *) 
            get_some_mem(sizeof(struct pat_node),"get_pat_node");
     }
   else
     {
      mem = free_pnode_list;
      free_pnode_list = free_pnode_list->next_level;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->same_level = NULL;
   mem->prev = NULL;
   mem->next_level = NULL;
   mem->last_level = NULL;
   mem->check_list = NULL;
   mem->var_list = NULL;

   return(mem);
  }

/***********************************************************/
/* rtn_pnode: returns a pat_node structure to a list of */
/*   available pat_node structures.                        */
/***********************************************************/
rtn_pnode(freed)
  struct pat_node *freed;
  {
   struct pat_node *temp;

   if (freed == NULL) { return(0); }

   temp = free_pnode_list;
   free_pnode_list = freed;

   free_pnode_list->next_level = temp;
  }

/******************************************************************/
/* get_bind_node:  allocates a bind_node structure from a list of */
/*   available bind_node structures.                              */
/******************************************************************/
struct bind_node *get_bind_node()
  {
   extern struct bind_node *free_bind_node_list;
   struct bind_node *mem;

   if (free_bind_node_list == NULL)
     {
      mem = (struct bind_node *) 
            get_some_mem(sizeof(struct bind_node),"get_bind_node");
     }
   else
     {
      mem = free_bind_node_list;
      free_bind_node_list = free_bind_node_list->next_list;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->next_list = NULL;
   mem->next_bind = NULL;
   mem->type = NULL;
   mem->var_name = NULL;
   mem->logic = '?';
   mem->start_pos = 0;
   mem->prev_bound = 0;
   mem->entrance = NULL;
   mem->expression = NULL;

   return(mem);
  }

/*************************************************************/
/* rtn_bind_node: returns a bind_node structure to a list of */
/*   available bind_node structures.                         */
/*************************************************************/
rtn_bind_node(freed)
  struct bind_node *freed;
  {
   struct bind_node *temp;

   if (freed == NULL) { return(0); }

   temp = free_bind_node_list;
   free_bind_node_list = freed;

   free_bind_node_list->next_list = temp;
  }

/********************************************************************/
/* get_basic:  allocates a basic structure from a list of available */
/*   basic structures.                                              */
/********************************************************************/
struct basic *get_basic()
  {
   extern struct basic *free_basic_list;
   struct basic *mem;

   if (free_basic_list == NULL)
     {
      mem = (struct basic *) 
            get_some_mem(sizeof(struct basic),"get_basic");
     }
   else
     {
      mem = free_basic_list;
      free_basic_list = free_basic_list->next;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/
   
   mem->type = NULL;
   mem->or = NULL;
   mem->next = NULL;
   mem->ivalue = 0.0;
   mem->svalue = NULL;
   mem->state = '?';
   mem->conn = '?';

   return(mem);
  }

/***************************************************************/
/* rtn_basic: returns a basic structure to a list of available */
/*    basic structures.                                        */
/***************************************************************/
rtn_basic(freed)
  struct basic *freed;
  {
   struct basic *temp;

   if (freed == NULL) { return(0); }

   temp = free_basic_list;
   free_basic_list = freed;

   free_basic_list->next = temp;
  }

/*********************************************************************/
/* returnbasics:  Returns a multiply linked list of basic structures */
/*   to the list of free basics .                                    */
/*********************************************************************/
returnbasics(waste)
  struct basic *waste;
  {
   if (waste != NULL)
     {
      if (waste->next != NULL) { returnbasics(waste->next); }
      if (waste->or != NULL) { returnbasics(waste->or); }
      rtn_basic(waste);
     }
  }

/******************************************************************/
/* get_test:  allocates a test structure from a list of available */
/*   test structures.                                             */
/******************************************************************/
struct test *get_test()
  {
   extern struct test *free_test_list;
   struct test *mem;

   if (free_test_list == NULL)
     {
      mem = (struct test *) 
            get_some_mem(sizeof(struct test),"get_test");
     }
   else
     {
      mem = free_test_list;
      free_test_list = free_test_list->next_arg;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->utype = KUNKNOWN;
   mem->arg_list = NULL;
   mem->next_arg = NULL;

   return(mem);
  }

/*************************************************************/
/* rtn_test: returns a test structure to a list of available */
/*    test structures.                                       */
/*************************************************************/
rtn_test(freed)
  struct test *freed;
  {
   struct test *temp;

   if (freed == NULL) { return(0); }

   temp = free_test_list;
   free_test_list = freed;

   free_test_list->next_arg = temp;
  }

/*******************************************************************/
/* returntests:  Returns a multiply linked list of test structures */
/*   to the list of free tests .                                   */
/*******************************************************************/
returntests(waste)
  struct test *waste;
  {
   if (waste != NULL)
     {
      returntests(waste->arg_list);
      returntests(waste->next_arg);
      rtn_test(waste);
     }
  }

/************************************************************/
/* new_funtab: allocates funtab structure from free memory. */
/************************************************************/
struct funtab *new_funtab()
  {
   struct funtab *mem;

   mem = (struct funtab *) 
         get_some_mem(sizeof(struct funtab),"new_funtab");

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->fun_name = NULL;
   mem->fun_type = '?';
   mem->ip = NULL;
   mem->cp = NULL;
   mem->sp = NULL;
   mem->fp = NULL;
   mem->next = NULL;

   return(mem);
  }

/************************************************************/
/* get_patptr:  Allocates a patptr structure from a list of */
/*   available patptr structures.                           */
/************************************************************/
struct patptr *get_patptr()
  {
   extern struct patptr *free_patptr_list;
   struct patptr *mem;

   if (free_patptr_list == NULL)
     {
      mem = (struct patptr *)
            get_some_mem(sizeof(struct patptr),"get_patptr");
     }
   else
     {
      mem = free_patptr_list;
      free_patptr_list = free_patptr_list->next;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->pptr = NULL;
   mem->lptr = NULL;
   mem->next = NULL;

   return(mem);
  }

/***********************************************************/
/* rtn_patptr: returns a patptr structure to a list of */
/*   available patptr structures.                        */
/***********************************************************/
rtn_patptr(freed)
  struct patptr *freed;
  {
   struct patptr *temp;

   if (freed == NULL) { return(0); }

   temp = free_patptr_list;
   free_patptr_list = freed;

   free_patptr_list->next = temp;
  }

/****************************************************************/
/* get_ruleinfo:  Allocates a ruleinfo structure from a list of */
/*   available ruleinfo structures.                             */
/****************************************************************/
struct ruleinfo *get_ruleinfo()
  {
   extern struct ruleinfo *free_ruleinfo_list;
   struct ruleinfo *mem;

   if (free_ruleinfo_list == NULL)
     {
      mem = (struct ruleinfo *)
            get_some_mem(sizeof(struct ruleinfo),"get_ruleinfo");
     }
   else
     {
      mem = free_ruleinfo_list;
      free_ruleinfo_list = free_ruleinfo_list->next;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->name = NULL;
   mem->next = NULL;   
   mem->pats = NULL;
   mem->ppinfo = NULL;
   mem->rhs_info = NULL;

   return(mem);
  }

/***********************************************************/
/* rtn_ruleinfo: returns a ruleinfo structure to a list of */
/*   available ruleinfo structures.                        */
/***********************************************************/
rtn_ruleinfo(freed)
  struct ruleinfo *freed;
  {
   struct ruleinfo *temp;

   if (freed == NULL) { return(0); }

   temp = free_ruleinfo_list;
   free_ruleinfo_list = freed;

   free_ruleinfo_list->next = temp;
  }


/***********************************************************************/
/* get_node:  allocates a node structure from a list of available node */
/*   structures.                                                       */
/***********************************************************************/
struct node *get_node()
  {
   extern struct node *free_node_list;
   struct node *mem;

   if (free_node_list == NULL)
     {
      mem = (struct node *) get_some_mem(sizeof(struct node),"get_node");
     }
   else
     {
      mem = free_node_list;
      free_node_list = free_node_list->right;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->bottom = NULL;
   mem->right = NULL;    
   mem->test = NULL;    
   mem->cond = NULL;    
   mem->svalue = NULL;
   mem->type = NULL;    
   mem->ivalue = 0.0;
   mem->state = '?';
   mem->conn = '?';

   return(mem);
  }

/******************************************************************/
/* rtn_node: returns a node structure to a list of available node */
/*    structures.                                                 */
/******************************************************************/
rtn_node(freed)
  struct node *freed;
  {
   struct node *temp;

   if (freed == NULL) { return(0); }

   temp = free_node_list;
   free_node_list = freed;

   free_node_list->right = temp;
  }

/*******************************************************************/
/* returnnodes:  Returns a multiply linked list of node structures */
/*   to the list of free nodes.                                    */
/*******************************************************************/
returnnodes(waste)
  struct node *waste;
  {
   if (waste != NULL)
     {
      returnnodes(waste->right);
      returnnodes(waste->bottom);
      rtn_node(waste);
     } 
  }

/***********************************************************************/
/* get_comm:  allocates a comm structure from a list of available comm */
/*   structures.                                                       */
/***********************************************************************/
struct comm *get_comm()
  {
   extern struct comm *free_comm_list;
   struct comm *mem;

   if (free_comm_list == NULL)
     {
      mem = (struct comm *) get_some_mem(sizeof(struct comm),"get_comm");
     }
   else
     {
      mem = free_comm_list;
      free_comm_list = free_comm_list->next;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->cond = NULL;
   mem->next = NULL;
   mem->args = NULL;
   mem->ivalue = 0.0;
   mem->value = NULL;
   mem->name = NULL;

   return(mem);
  }

/******************************************************************/
/* rtn_comm: returns a comm structure to a list of available comm */
/*    structures.                                                 */
/******************************************************************/
rtn_comm(freed)
  struct comm *freed;
  {
   struct comm *temp;

   if (freed == NULL) { return(0); }

   temp = free_comm_list;
   free_comm_list = freed;

   free_comm_list->next = temp;
  }

/*******************************************************************/
/* returncomms:  Returns a multiply linked list of comm structures */
/*   to the list of free comms.                                    */
/*******************************************************************/
returncomms(waste)
  struct comm *waste;
  {
   if (waste != NULL)
     {
      returncomms(waste->args);
      returncomms(waste->next);
      returntests(waste->cond);
      rtn_comm(waste);
     }
  }

/*******************************************************/
/* new_draw: allocates draw structure from free memory. */
/*   Structure values must be initialized by calling   */
/*   routine.                                          */
/*******************************************************/
struct draw *new_draw()
  {
   struct draw *mem;

   mem = (struct draw *) get_some_mem(sizeof(struct draw),"new_draw");

   return(mem);
  }

/********************************************************************/
/* get_fact:  Allocates a fact structure from the list of available */
/*   fact structures.  Structure values are not initialized by this */
/*   routine.                                                       */
/********************************************************************/
struct fact *get_fact()
  {
   extern struct fact *free_fact_list;
   struct fact *mem;

   if (free_fact_list == NULL)
     {
      mem = (struct fact *) get_some_mem(sizeof(struct fact),"get_fact");
     }
   else
     {
      mem = free_fact_list;
      free_fact_list = free_fact_list->next;
     }

   return(mem);
  }

/******************************************************************/
/* rtn_fact: returns a fact structure to a fact of available fact */
/*    structures.                                                 */
/******************************************************************/
rtn_fact(freed)
  struct fact *freed;
  {
   struct fact *temp;

   if (freed == NULL) { return(0); }

   temp = free_fact_list;
   free_fact_list = freed;

   free_fact_list->next = temp;
  }

/***********************************************************************/
/* get_list:  allocates a list structure from a list of available list */
/*   structures.                                                       */
/***********************************************************************/
struct list *get_list()
  {
   extern struct list *free_list_list;
   struct list *mem;

   if (free_list_list == NULL)
     {
      mem = (struct list *) get_some_mem(sizeof(struct list),"get_list");
     }
   else
     {
      mem = free_list_list;
      free_list_list = free_list_list->next;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->boolean = '?';
   mem->path = NULL;
   mem->next = NULL;

   return(mem);
  }

/******************************************************************/
/* rtn_list: returns a list structure to a list of available list */
/*    structures.                                                 */
/******************************************************************/
rtn_list(freed)
  struct list *freed;
  {
   struct list *temp;

   if (freed == NULL) { return(0); }

   temp = free_list_list;
   free_list_list = freed;

   free_list_list->next = temp;
  }

/******************************************************************/
/* get_internode:  Allocates an internode structure from the list */
/*   of available internode structures.                           */
/******************************************************************/
struct internode *get_internode()
  {
   extern struct internode *free_internode_list;
   struct internode *mem;

   if (free_internode_list == NULL)
     {
      mem = (struct internode *) 
            get_some_mem(sizeof(struct internode),"newinternode");
   
      mem->lhs_log = '?';
      mem->rhs_log = '?';
     }
   else
     {
      mem = free_internode_list;
      free_internode_list = free_internode_list->next;
     }
  
   mem->next = NULL;
   mem->lhs = NULL;
   mem->rhs = NULL;
   mem->rhs_test = NULL;
   mem->cond = NULL;
   mem->id = 0;

   return(mem);
  }

/*****************************************************************/
/* rtn_internode:  Returns an internode structure to the list of */
/*   available internode structures.                             */
/*****************************************************************/
rtn_internode(freed)
  struct internode *freed;
  {
   struct internode *temp;

   if (freed == NULL) { return(0); }

   temp = free_internode_list;
   free_internode_list = freed;

   free_internode_list->next = temp;
  }

/************************************************************/
/* get_values:  Allocates an values structure from the list */
/*   of available values structures.                        */
/************************************************************/
struct values *get_values()
  {
   extern struct values *free_values_list;
   struct values *mem;

   if (free_values_list == NULL)
     {
      mem = (struct values *) 
            get_some_mem(sizeof(struct values),"get_values");

      mem->name = NULL;
      mem->value = NULL;
      mem->whoset = 0;
      mem->ivalue = 0.0;
      mem->origin = NULL;
      mem->type = NULL;
      mem->state = '?';
     }
   else
     {
      mem = free_values_list;
      free_values_list = free_values_list->next;
     }

   mem->next = NULL;
   mem->cond = NULL;
   mem->multiple = NULL;

   return(mem);
  }

/**********************************************************************/
/* rtn_values:  Returns an values structure and any values structures */
/*   in the multiple slot to the list of available values structures. */
/**********************************************************************/
rtn_values(freed)
  struct values *freed;
  {
   struct values *temp;

   if (freed == NULL) { return(0); }

   temp = free_values_list;
   free_values_list = freed;

   free_values_list->next = temp;

   /* bug fix 6 */
  }

/***********************************************************/
/* returnvalues:  Returns a multiply linked list of values */
/*   structures to the list of free values.                */
/***********************************************************/
returnvalues(waste)
  struct values *waste;
  {
   if (waste != NULL)
     {
      if (waste->multiple != NULL) returnvalues(waste->multiple);
      if (waste->next != NULL) returnvalues(waste->next);
      rtn_values(waste);
     }
  }

/**************************************************************/
/* get_element:  Allocates an element structure from the list */
/*   of available element structures.  Structures values are  */
/*   not initialized.                                         */
/**************************************************************/
struct element *get_element()
  {
   extern struct element *free_element_list;
   struct element *mem;

   if (free_element_list == NULL)
     {
      mem = (struct element *) 
            get_some_mem(sizeof(struct element),"newelement");
     }
   else
     {
      mem = free_element_list;
      free_element_list = free_element_list->next;
     }

   return(mem);
  }

/***********************************************************************/
/* rtn_element:  Returns an element structure to the list of available */
/*   element structures.                                               */
/***********************************************************************/
rtn_element(freed)
  struct element *freed;
  {
   struct element *temp;

   if (freed == NULL) { return(0); }

   temp = free_element_list;
   free_element_list = freed;

   free_element_list->next = temp;

  }

/***************************************************************/
/* returnelements:  Returns a multiply linked list of elements */
/*   structures to the list of free elements.                  */
/***************************************************************/
returnelements(freed)
  struct element *freed;
  {
   struct element *temp, *chase;

   if (freed == NULL) { return(0); }

   temp = free_element_list;
   free_element_list = freed;

   chase = freed;
   while (chase->next != NULL)
     { chase = chase->next; }

   chase->next = temp;
  }

/***********************************************************************/
/* get_link:  allocates a link structure from a list of available link */
/*   structures.                                                       */
/***********************************************************************/
struct link *get_link()
  {
   extern struct link *free_link_list;
   struct link *mem;

   if (free_link_list == NULL)
     {
      mem = (struct link *) get_some_mem(sizeof(struct link),"get_link");
     }
   else
     {
      mem = free_link_list;
      free_link_list = free_link_list->next;
     }

   /*==============================================*/
   /* Structure is not allocated during run time.  */
   /* Initialize values without concern for speed. */
   /*==============================================*/

   mem->type = NULL;
   mem->state = '?';
   mem->conn = '?';
   mem->hook = NULL;
   mem->next = NULL;

   return(mem);
  }

/******************************************************************/
/* rtn_link: returns a link structure to a list of available link */
/*    structures.                                                 */
/******************************************************************/
rtn_link(freed)
  struct link *freed;
  {
   struct link *temp;

   if (freed == NULL) { return(0); }

   temp = free_link_list;
   free_link_list = freed;

   free_link_list->next = temp;
  }

/*****************************************************************/
/* get_lr:  allocates an lr structure from the list of available */
/*   lr structures.                                              */
/*****************************************************************/
struct lr *get_lr()
  {
   extern struct lr *free_lr_list;
   struct lr *mem;

   if (free_lr_list == NULL)
     {
      mem = (struct lr *) get_some_mem(sizeof(struct lr),"get_lr");
     }
   else
     {
      mem = free_lr_list;
      free_lr_list = free_lr_list->next;
     }

   mem->next = NULL;
   mem->locals = NULL;

   return(mem);
  }

/***************************************************************/
/* rtn_lr: Returns an lr structure to the list of available lr */
/*    structures.                                              */
/***************************************************************/
rtn_lr(freed)
  struct lr *freed;
  {
   struct lr *temp;

   if (freed == NULL) { return(0); }

   temp = free_lr_list;
   free_lr_list = freed;

   free_lr_list->next = temp;

  }

/**********************************************************************/
/* get_match:  Allocates a match structure from the list of available */
/*   match structures.                                                */
/**********************************************************************/
struct match *get_match()
  {
   extern struct match *free_match_list;
   struct match *mem;

   if (free_match_list == NULL)
     { 
      mem = (struct match *)
            get_some_mem(sizeof(struct match),"get_match");
     }
   else
     {
      mem = free_match_list;
      free_match_list = free_match_list->next;
     }

   return(mem);
  }

/******************************************************************/
/* rtn_match:  Returns a match structure to the list of available */
/*    match structures.                                           */
/******************************************************************/
rtn_match(freed)
  struct match *freed;
  {
   struct match *temp;

   if (freed == NULL) { return(0); }

   temp = free_match_list;
   free_match_list = freed;

   free_match_list->next = temp;

  }

/******************************************************************/
/* dump_some_mem:  Returns a structure to the pool of free memory */
/*   with a "generic" free function.                              */
/******************************************************************/
dump_some_mem(mem,size,struct_type)
  char *mem;
  int size;
  char *struct_type;
  {
   if (genfree(mem,size) == -1)
     { 
      sprintf(GLOBALSTR,"Release error in %s structure\n",struct_type);
      cl_print(wdialog,GLOBALSTR);
      cl_exit(1);
     }
  }

/**************************************************************/
/* get_some_mem:  Allocates a structure from the pool of free */
/*   memory with a "generic" allocate function.               */
/**************************************************************/
char *get_some_mem(size,who_wants_it)
  int size;
  char *who_wants_it;
  {
   char *mem = NULL;

   mem = genalloc(size);

   if (mem == NULL)
     { 
      free_up_lists(); 
      mem = genalloc(size);
      if (mem == NULL)
        {
         sprintf(GLOBALSTR,"Out of memory in %s\n",who_wants_it);
	 cl_print(wdialog,GLOBALSTR);
         cl_exit(1);
        }
     }

   return(mem);
  }

/*******************************************************************/
/* free_up_lists:  Returns all the lists of stored data structures */
/*   to the pool of free memory.                                   */
/*******************************************************************/
free_up_lists()
  {
   char *next_mem;

   cl_print(wdialog,"\n*** DEALLOCATING MEMORY ***\n");

   while (free_values_list != NULL)
     {
      next_mem = (char *) free_values_list->next;
      dump_some_mem(free_values_list,sizeof(struct values),"values");
      free_values_list = (struct values *) next_mem;
     }
      
   while (free_lr_list != NULL)
     {
      next_mem = (char *) free_lr_list->next;
      dump_some_mem(free_lr_list,sizeof(struct lr),"lr");
      free_lr_list = (struct lr *) next_mem;
     }

   while (free_match_list != NULL)
     {
      next_mem = (char *) free_match_list->next;
      dump_some_mem(free_match_list,sizeof(struct match),"match");
      free_match_list = (struct match *) next_mem;
     }

   while (free_internode_list != NULL)
     {
      next_mem = (char *) free_internode_list->next;
      dump_some_mem(free_internode_list,sizeof(struct internode),
                    "internode");
      free_internode_list = (struct internode *) next_mem;
     }

   while (free_element_list != NULL)
     {
      next_mem = (char *) free_element_list->next;
      dump_some_mem(free_element_list,sizeof(struct element),"element");
      free_element_list = (struct element *) next_mem;
     }

   while (free_fact_list != NULL)
     {
      next_mem = (char *) free_fact_list->next;
      dump_some_mem(free_fact_list,sizeof(struct fact),"fact");
      free_fact_list = (struct fact *) next_mem;
     }

   while (free_fmarker_list != NULL)
     {
      next_mem = (char *) free_fmarker_list->next;
      dump_some_mem(free_fmarker_list,sizeof(struct fact_marker),
                    "fact_marker");
      free_fmarker_list = (struct fact_marker *) next_mem;
     }

   while (free_node_list != NULL)
     {
      next_mem = (char *) free_node_list->right;
      dump_some_mem(free_node_list,sizeof(struct node),"node");
      free_node_list = (struct node *) next_mem;
     }

   while (free_comm_list != NULL)
     {
      next_mem = (char *) free_comm_list->next;
      dump_some_mem(free_comm_list,sizeof(struct comm),"comm");
      free_comm_list = (struct comm *) next_mem;
     }

   while (free_basic_list != NULL)
     {
      next_mem = (char *) free_basic_list->next;
      dump_some_mem(free_basic_list,sizeof(struct basic),"basic");
      free_basic_list = (struct basic *) next_mem;
     }

   while (free_pnode_list != NULL)
     {
      next_mem = (char *) free_pnode_list->next_level;
      dump_some_mem(free_pnode_list,sizeof(struct pat_node),"pat_node");
      free_pnode_list = (struct pat_node *) next_mem;
     }

   while (free_bind_node_list != NULL)
     {
      next_mem = (char *) free_bind_node_list->next_list;
      dump_some_mem(free_bind_node_list,sizeof(struct bind_node),
                    "bind_node");
      free_bind_node_list = (struct bind_node *) next_mem;
     }

   while (free_test_list != NULL)
     {
      next_mem = (char *) free_test_list->next_arg;
      dump_some_mem(free_test_list,sizeof(struct test),"test");
      free_test_list = (struct test *) next_mem;
     }

   while (free_ruleinfo_list != NULL)
     {
      next_mem = (char *) free_ruleinfo_list->next;
      dump_some_mem(free_ruleinfo_list,sizeof(struct ruleinfo),"ruleinfo");
      free_ruleinfo_list = (struct ruleinfo *) next_mem;
     }

   while (free_patptr_list != NULL)
     {
      next_mem = (char *) free_patptr_list->next;
      dump_some_mem(free_patptr_list,sizeof(struct patptr),"patptr");
      free_patptr_list = (struct patptr *) next_mem;
     }

   while (free_link_list != NULL)
     {
      next_mem = (char *) free_link_list->next;
      dump_some_mem(free_link_list,sizeof(struct link),"link");
      free_link_list = (struct link *) next_mem;
     }

   while (free_list_list != NULL)
     {
      next_mem = (char *) free_list_list->next;
      dump_some_mem(free_list_list,sizeof(struct list),"list");
      free_list_list = (struct list *) next_mem;
     }

   cl_print(wdialog,"\n*** MEMORY  DEALLOCATED ***\n");
  }


/************************************************************************/ 
/* FINDSTR FUNCTION -- Finds second string in first string and returns  */
/*	the index of the first string where the second string started,  */
/*	-1 if the second string was not found.                          */
/************************************************************************/ 
int findstr(s,t) 
    char *s, *t; {

	int i,j,k;

	for (i = 0; s[i] != '\0'; i++) {
	    for (j = i, k = 0; t[k] != '\0' && s[j] == t[k]; j++, k++) ;
	    if ((t[k] == '\0')&&(k != 0))
	    	return(i);
	}                 
	return(-1);
    }
