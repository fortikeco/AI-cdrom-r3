/* CLIPS Version 3.1   9/18/86 */

#include <stdio.h>
#include "clips.h"

#define EOS '\0'
#define TRUE 1

FILE *wclips, *wdialog, *wdisplay;

/***************************************************/
/* genalloc: a generic memory allocation function. */
/***************************************************/
char *genalloc(size)
  int size;
  {
   extern char *malloc();

   return(malloc(size));
  }

/****************************************************/
/* genfree: a generic memory deallocation function. */
/****************************************************/
genfree(waste,size)
  char *waste;
  int size;
  {
   if (free(waste) == -1)
     { 
      printf("Release error in genfree\n");
      return(-1);
     }

   return(0); 
  }

/**********************************************/
/* INIT_STREAMS:  Initializes output streams. */
/**********************************************/
init_streams()
  {     
   wclips = stdout;
   wdisplay = (FILE *) genalloc (sizeof(FILE));  
   wdialog = stderr;


/**************************************/
/* CL_PRINT:  Generic print function. */
/**************************************/
cl_print(stream, str)
  FILE *stream;
  char *str;
  {
   if ((stream == wclips) || (stream == wdisplay) || (stream == wdialog))
     { printf("%s",str); }
   else
     { fprintf(stream,"%s",str); }
  }       

/*********************************************/
/* CL_GETC:  Generic get character function. */
/*********************************************/
int cl_getc(stream)
  FILE *stream;
  { return(getc(stream)); }

/*************************************************/
/* CL_UNGETC:  Generic unget character function. */
/*************************************************/
int cl_ungetc(ch,stream) 
  char ch;
  FILE *stream;
  { ungetc(ch,stream); }

/************************************/
/* CL_EXIT:  Generic exit function. */
/************************************/
int cl_exit(num)
  int num; 
  {
   close_all();       /* Closes all open files. */ 
   exit(num); 
  }

/*************************************************************/
/* CLIPS_TIME: A function to return a floating point number  */
/*   which indicates the present time.  As currently defined */
/*   it returns 0.0 (examples are included which return more */
/*   meaningful values, but are non-portable).               */
/*************************************************************/

/* The following line is needed for VAX VMS timing. */
/* #include timeb */

float clips_time()
  {
   /* The following section of code which is commented out     */
   /* is included as an example for timing on a VAX using VMS. */

   /* 
   float sec, msec, time;
   struct timeb time_pointer;

   ftime(&time_pointer);
   sec = (float) (time_pointer.time - 513612000);
   msec = (float) time_pointer.millitm;
   return(sec + (msec / 1000.0));
   */

   /* The following section of code is included for machines */
   /* which have a time function implemented.                */

   /* return( (float) time() ); */

   /* The following section of code is included for machines */
   /* which have no time functions.                          */

   return(0.0);  
  }

/*****************************************************************/
/* MY_SYSTEM:  This function can be called from CLIPS.  It will  */
/*   form a command string from its arguments, and pass this     */
/*   string to the operating system.  As currently defined, this */
/*   function does nothing, however, code has been included      */
/*   which should allow this function to work under VAX VMS and  */
/*   UNIX compatible systems.                                    */
/*****************************************************************/
float my_system()
  {
   char comm_buff[256];
   int buff_index = 0;
   int numa, i, j;
   struct values *arg_ptr;
   char *str_ptr, next_char;

   comm_buff[0] = EOS;
   numa = num_args();

   for (i = 1 ; i <= numa; i++)
     {
      arg_ptr = runknown(i);
      if ((arg_ptr->type != STRING) &&
          (arg_ptr->type != WORD))
        {
         RULE_FIRE_ERROR = TRUE;
         cl_print(wclips,"Invalid argument for system function");
         return(0.0);
        }
      
     str_ptr = arg_ptr->value;
     j = 0;
     while ((next_char = str_ptr[j++]) != EOS)
       { 
        if (buff_index < 255)
          { comm_buff[buff_index++] = next_char; }
        else
          {
           RULE_FIRE_ERROR = TRUE;
           cl_print(wclips,"Command buffer overflow in system function");
           return(0.0);
          }
       }
     comm_buff[buff_index] = EOS;
    } 

   /* The next line should be uncommented for system to work. */
     system(comm_buff); 

   /* The next line should be commented for system to work. */  
/*   printf("System function not fully defined for this system.\n");*/

   return(1.0);
  }


/* For VAX VMS system calls uncomment the following code. */
/*
#include <descrip.h>
#include <ssdef.h>
#include <stsdef.h>

extern int LIB$SPAWN();

int system(cmd)
  char *cmd;
  {
   long status, complcode;
   struct dsc$descriptor_s cmd_desc;

   cmd_desc.dsc$w_length = strlen(cmd);
   cmd_desc.dsc$a_pointer = cmd;
   cmd_desc.dsc$b_class = DSC$K_CLASS_S;
   cmd_desc.dsc$b_dtype = DSC$K_DTYPE_T;

   status = LIB$SPAWN(&cmd_desc,0,0,0,0,0,&complcode,0,0,0);
   if ((status == SS$_NORMAL) && ((complcode & STS$M_SUCCESS) != 0))
     { return 0; }
   else
     { return -1; }
  }
*/

/**************************************************************/
/* The following two functions are provided to trap control-c */
/* in order to interrupt the execution of a program.  The     */
/* lines of code commented out will trap crtl-c for VMS VAX.  */
/**************************************************************/
/* #include <signal.h> */

sysdep_inits()
  {
    
   int catch_ctrl_c();

/*   signal(SIGINT,catch_ctrl_c); */

  }

catch_ctrl_c()
  {
   
   extern int RULE_FIRE_ERROR;

   RULE_FIRE_ERROR = TRUE;

/*    signal(SIGINT,catch_ctrl_c); */

  }

