/* -*- Mode: PL1; Fonts: MEDFNB -*- */

/*****************************************************************/
/*       "C" Language Integrated Production System               */
/*                CONSTANT DEFINITIONS                           */
/*****************************************************************/

extern char *NOT;
extern char *KPRINTOUT;
extern char *KFPRINTOUT;
extern char *FCALL;
extern char *LNOT;
extern char *LAND;
extern char *LOR;
extern char *SPLIT;
extern char *RETRACT;
extern char *NUMBER;
extern char *LBRACK;
extern char *RBRACK;
extern char *COAMP;
extern char *COMMA;
extern char *KDOLLAR;
extern char *KPOUND;
extern char *STRING;
extern char *STOP;
extern char *PATTERN;
extern char *GARBAGE;
extern char *KASSERT;
extern char *DEFFACTS;
extern char *DEFRULE;
extern char *SALIENCE;
extern char *SPECIAL;
extern char *KAND;
extern char *KOR;
extern char *QUOTATION;
extern char *SEPARATOR;
extern char *BINDER;
extern char *MULTIPLE;
extern char *LPAREN;
extern char *RPAREN;
extern char *SINGLE;
extern char *WORD;
extern char *BWORD;
extern char *BWORDS;
extern char *OPERATOR;
extern char *TEST;
extern char *DOLLARS;
extern char *NUM;

extern char *KCALL;
extern char *KBIND;

extern char *KTAB;
extern char *KCRLF;

extern char *KACTIVATIONS;

extern char *KANALYZE;
extern char *KIF;
extern char *KTHEN;
extern char *KELSE;
extern char *KDECLARE;
extern char *KWHILE;

extern char *KSHOW1;
extern char *KSHOW2;
extern char *KSHOW3;


extern char *KUNKNOWN;
extern char *KADD;
extern char *KSUBTRACT;
extern char *KMULT;
extern char *KDIVIDE;
extern char *KGTEQ;
extern char *KLTEQ;
extern char *KGT;
extern char *KLT;
extern char *KEQ;
extern char *KNEQ;
extern char *KTAND;
extern char *KTOR;
extern char *KTNOT;
extern char *KEXP;

extern char GLOBALSTR[];
