/* CLIPS Version 3.1   9/18/86 */

/****************************************************************************/
/*                                                                          */
/*                       SYSTEM MATHEMATICAL FUNCTIONS                      */
/*                                                                          */
/****************************************************************************/
#include <stdio.h>

#include <math.h>
#ifndef PI
#define PI   3.14159265358979323846
#endif
#ifndef PID2
#define PID2 1.57079632679489661923	/* PI divided by 2 */
#endif

#include "clips.h"

#define TRUE 1              
#define FALSE 0


/*****************************/
/*DEFINITIONS                */
/*****************************/

float clcos(),clsin(),cltan(),clacos(),clasin(),clatan(),
      clcosh(),clsinh(),cltanh(),clacosh(),clasinh(),clatanh(),
      clasech(),clacsch(),clacoth(),
      clexp(),cllog(),cllog10(),clsqrt();

mathfctns()
   {
   float my_cos(),   my_sin(),  my_tan(),   my_sec(),   my_csc(),   my_cot();
   float my_acos(),  my_asin(), my_atan(),  my_asec(),  my_acsc(),  my_acot();
   float my_cosh(),  my_sinh(), my_tanh(),  my_sech(),  my_csch(),  my_coth();
   float my_acosh(), my_asinh(), my_atanh(), my_asech(), my_acsch(), my_acoth();

   float my_min(), my_max(), mod(); 
   float my_exp(), my_log(), my_log10(), my_sqrt();
   float my_trunc(), my_pi(), my_deg_rad(), my_rad_deg();
   float my_deg_grad(), my_grad_deg();
   float my_abs();

   define_function("cos",'f',my_cos);
   define_function("sin",'f',my_sin);
   define_function("tan",'f',my_tan);
   define_function("sec",'f',my_sec);
   define_function("csc",'f',my_csc);
   define_function("cot",'f',my_cot);
   define_function("acos",'f',my_acos);
   define_function("asin",'f',my_asin);
   define_function("atan",'f',my_atan);
   define_function("asec",'f',my_asec);
   define_function("acsc",'f',my_acsc);
   define_function("acot",'f',my_acot);
   define_function("cosh",'f',my_cosh);
   define_function("sinh",'f',my_sinh);
   define_function("tanh",'f',my_tanh);
   define_function("sech",'f',my_sech);
   define_function("csch",'f',my_csch);
   define_function("coth",'f',my_coth);
   define_function("acosh",'f',my_acosh);
   define_function("asinh",'f',my_asinh);
   define_function("atanh",'f',my_atanh);
   define_function("asech",'f',my_asech);
   define_function("acsch",'f',my_acsch);
   define_function("acoth",'f',my_acoth);

   define_function("mod",'f',mod);
   define_function("min",'f',my_min);
   define_function("max",'f',my_max);
   define_function("exp",'f',my_exp);
   define_function("log",'f',my_log);
   define_function("log10",'f',my_log10);
   define_function("sqrt",'f',my_sqrt);
   define_function("trunc",'f',my_trunc);
   define_function("pi",'f',my_pi);
   define_function("deg-rad",'f',my_deg_rad);
   define_function("rad-deg",'f',my_rad_deg);
   define_function("deg-grad",'f',my_deg_grad);
   define_function("grad-deg",'f',my_grad_deg);
   define_function("abs",'f',my_abs);   
   }


/*******************************************/
/*   CLIPS TRIGONOMETRIC FUNCTIONS         */
/*******************************************/
int arg_no_check(fnstr)
  char *fnstr;
  {
   int arg_no;
   struct values *item;
   char msg[80];

   arg_no = num_args();
   if (arg_no != 1) 
     {
      sprintf(msg,"Bad number of arguments for %s function.\n",fnstr);
      cl_print(wdialog,msg);
      RULE_FIRE_ERROR = TRUE;
      return FALSE;
     }

   item = runknown(1);
   if (item->type != NUMBER) 
     {
      sprintf(msg,"Bad data type for %s function.\n",fnstr);
      cl_print(wdialog,msg);
      RULE_FIRE_ERROR = TRUE;
      return FALSE;
     }

   return TRUE;
  }

float my_cos()
  {
    float num,result;

    extern float clcos();
                         
    if (arg_no_check("cos") == FALSE) return(0.0);
    num = rfloat(1);
    result = clcos(num);
    return(result);
  }

float my_sin()                                 
  {
    float num,result;

    extern float clsin();

    if (arg_no_check("sin") == FALSE) return(0.0);
    num = rfloat(1);
    result = clsin(num);
    return(result);
  }

int check_multiple(cmp_num,tst_num) 
    float cmp_num,tst_num; {

    float look_num;

    look_num = fabs(cmp_num/tst_num)-fabs((float)((int)(cmp_num/tst_num)));
    if (look_num < 0.000001) { 
      cl_print(wdialog,"Singularity at asymptote in trigonometric function.\n");
      RULE_FIRE_ERROR = TRUE;
      return TRUE; }
    else return FALSE;
   }

float my_tan()
  {
    float num,result;

    extern float cltan();

    if (arg_no_check("tan") == FALSE) return (0.0);
    num = rfloat(1);
    if (check_multiple(num,PID2) == TRUE) return(0.0);
    result = cltan(num);
    return(result);
  }

int test_zero_range(nval)
  float nval; 
  {
    if ((nval >= -0.000001) && (nval <= 0.000001)) return TRUE;
    else return FALSE; 
  }


float my_sec()
  {
    float num,result;

    extern float clcos();

    if (arg_no_check("sec") == FALSE) return(0.0);
    num = rfloat(1);
    if (check_multiple(num,PID2) == TRUE) return(0.0);
    result = clcos(num);
    result = 1.0 / result;
    return(result); 
  }

float my_csc()
  {
    float num,result;

    extern float clsin();

    if (arg_no_check("csc") == FALSE) return(0.0);
    num = rfloat(1);
    if (check_multiple(num,PI) == TRUE) return(0.0);
    result = clsin(num);
    result = 1.0 / result;
    return(result);
  }

float my_cot()
  {
    float num,result;

    extern float cltan();

    if (arg_no_check("cot") == FALSE) return(0.0);
    num = rfloat(1);
    if (check_multiple(num,PI) == TRUE) return(0.0);
    result = clcos(num)/clsin(num);
    return(result); 
  }

float my_acos()
  {
    float num,result;

    extern float clacos();

    if (arg_no_check("acos") == FALSE) return(0.0);
    num = rfloat(1);
    if ((num > 1.000000000)||(num < -1.000000000)) {
	 cl_print(wdialog,"Argument overflow for acos function.\n");
         RULE_FIRE_ERROR = TRUE;
	 return(0.0); }
    result = clacos(num);
    return(result);       
  }

float my_asin()
  {
    float num,result;

    extern float clasin();

    if (arg_no_check("asin") == FALSE) return(0.0);
    num = rfloat(1);
    if ((num > 1.000000000)||(num < -1.000000000)) {
	 cl_print(wdialog,"Argument overflow for asin function.\n");
         RULE_FIRE_ERROR = TRUE;
	 return(0.0); }
    result = clasin(num);
    return(result);
  }

float my_atan()
  {
    float num,result;

    extern float clatan();

    if (arg_no_check("atan") == FALSE) return(0.0);
    num = rfloat(1);
    result = clatan(num);
    return(result);
  }

float my_asec()
  {
    float num,result;

    extern float clacos();

    if (arg_no_check("asec") == FALSE) return(0.0);
    num = rfloat(1);
    if ((num < 1.000000000)&&(num > -1.000000000)) {
	 cl_print(wdialog,"Argument overflow for asec function.\n");
         RULE_FIRE_ERROR = TRUE;
	 return(0.0); }
    num = 1.0 / num;
    result = clacos(num);
    return(result);
  }

float my_acsc()
  {
    float num,result;

    extern float clasin();

    if (arg_no_check("acsc") == FALSE) return(0.0);
    num = rfloat(1);
    if ((num < 1.000000000)&&(num > -1.000000000)) {
	 cl_print(wdialog,"Argument overflow for acsc function.\n");
         RULE_FIRE_ERROR = TRUE;
	 return(0.0); }
    num = 1.0 / num;
    result = clasin(num);
    return(result);
  }


float my_acot()
  {
    float num,result;

    extern float clatan();

    if (arg_no_check("acot") == FALSE) return(0.0);
    num = rfloat(1);
    if (test_zero_range(num) != TRUE) 
        num = 1.0 / num;
    else return(PID2);
    result = clatan(num);
    return(result);
  }


float my_cosh()
    {
    float num,result;

    extern float clcosh();

    if (arg_no_check("cosh") == FALSE) return(0.0);
    num = rfloat(1);
    result = clcosh(num);
    return(result);
    }


float my_sinh()
    {
    float num,result;

    extern float clsinh();

    if (arg_no_check("sinh") == FALSE) return(0.0);
    num = rfloat(1);
    result = clsinh(num);
    return(result);
    }


float my_tanh()
    {
    float num,result;

    extern float cltanh();

    if (arg_no_check("tanh") == FALSE) return(0.0);
    num = rfloat(1);
    result = cltanh(num);
    return(result);
    }


float my_sech()
    {
    float num,result;

    extern float clcosh();

    if (arg_no_check("sech") == FALSE) return(0.0);
    num = rfloat(1);
    result = clcosh(num);
    result = 1.0 / result;
    return(result); 
    }


float my_csch()
    {
    float num,result;

    extern float clsinh();

    if (arg_no_check("csch") == FALSE) return(0.0);
    num = rfloat(1);
    if (test_zero_range(num) == TRUE) {
	 cl_print(wdialog,"Argument overflow for csch function.\n");
         RULE_FIRE_ERROR = TRUE;
	 return(0.0); }
    result = clsinh(num);
    result = 1.0 / result;
    return(result); 
    }


float my_coth()
    {
    float num,result;

    extern float cltanh();

    if (arg_no_check("coth") == FALSE) return(0.0);
    num = rfloat(1);
    if (test_zero_range(num) == TRUE) {
	RULE_FIRE_ERROR = TRUE;
        cl_print(wdialog,"Argument overflow for coth function.\n");
        return(0.0); }
    result = cltanh(num);
    result = 1.0 / result;
    return(result); 
    }


float my_acosh()
    {
    float num,result;

    extern float clacosh();

    if (arg_no_check("acosh") == FALSE) return(0.0);
    num = rfloat(1);
    if (num < 1.000000000) {
	    RULE_FIRE_ERROR = TRUE;
         cl_print(wdialog,"Argument overflow for acosh function.\n");
         return(0.0); }
    result = clacosh(num);
    return(result);
    }


float my_asinh()
    {
    float num,result;

    extern float clasinh();

    if (arg_no_check("asinh") == FALSE) return(0.0);
    num = rfloat(1);
    result = clasinh(num);
    return(result);
    }


float my_atanh()
    {
    float num,result;

    extern float clatanh();

    if (arg_no_check("atanh") == FALSE) return(0.0);
    num = rfloat(1);
    if ((num > 1.000000000)||(num < -1.000000000)) {
	    cl_print(wdialog,"Argument overflow for atanh function.\n");
         RULE_FIRE_ERROR = TRUE;
	    return(0.0); }
    result = clatanh(num);
    return(result);
    }


float my_asech()
    {
    float num,result;

    extern float clasech();

    if (arg_no_check("asech") == FALSE) return(0.0);
    num = rfloat(1);
    if ((num > 1.000000000)||(num < 0.000000001)) {
	    cl_print(wdialog,"Argument overflow for asech function.\n");
         RULE_FIRE_ERROR = TRUE;
	    return(0.0); }
    result = clasech(num);
    return(result);
    }


float my_acsch()
    {
    float num,result;

    extern float clacsch();

    if (arg_no_check("acsch") == FALSE) return(0.0);
    num = rfloat(1);
    if (test_zero_range(num) == TRUE) {
	    RULE_FIRE_ERROR = TRUE;
         cl_print(wdialog,"Argument overflow for acsch function.\n");
         return(0.0); }
    result = clacsch(num);
    return(result);
    }


float my_acoth()
    {
    float num,result;

    extern float clacoth();

    if (arg_no_check("acoth") == FALSE) return(0.0);
    num = rfloat(1);
    if ((num < 1.000000001)&&(num > -1.000000001)) {
	    cl_print(wdialog,"Argument overflow for acoth function.\n");
         RULE_FIRE_ERROR = TRUE;
	    return(0.0); }
    result = clacoth(num);
    return(result);
    }


float my_exp()
    {
    float num,result;

    extern float clexp();

    if (arg_no_check("exp") == FALSE) return(0.0);
    num = rfloat(1);
    result = clexp(num);
    return(result);
    }


float my_log()
    {
    float num,result;

    extern float cllog();

    if (arg_no_check("log") == FALSE) return(0.0);
    num = rfloat(1);
    if (num < 0.000001) {
   	  RULE_FIRE_ERROR = TRUE;
	  cl_print(wdialog,"Argument overflow for log function.\n");
	  return(0.0); }
    result = cllog(num);
    return(result);
    }


float my_log10()
    {
    float num,result;

    extern float cllog10();

    if (arg_no_check("log10") == FALSE) return(0.0);
    num = rfloat(1);
    if (num < 0.000001) {
   	  RULE_FIRE_ERROR = TRUE;
	  cl_print(wdialog,"Argument overflow for log10 function.\n");
	  return(0.0); }
    result = cllog10(num);
    return(result);
    }


float my_sqrt()
    {
    float num,result;

    extern float clsqrt();

    if (arg_no_check("sqrt") == FALSE) return(0.0);
    num = rfloat(1);
    if (num < 0.00000) {
   	  RULE_FIRE_ERROR = TRUE;
	  cl_print(wdialog,"Argument overflow for sqrt function.\n");
	  return(0.0); }
    result = clsqrt(num);
    return(result);
    }


/****************************************/
/* min                                  */
/****************************************/
float my_min()
  {
   float min_value;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { cl_print(wdialog,"Bad number of arguments for min function.\n"); 
       RULE_FIRE_ERROR = TRUE;
       return(0.0); }

   min_value = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
       if (arg_value < min_value)
        { min_value = arg_value; }
     }
   
   return(min_value);
  } 

/****************************************/
/* max                                  */
/****************************************/
float my_max()
  {
   float max_value;
   float arg_value;
   int num_a, i;

   num_a = num_args();

   if (num_a == 0)
     { cl_print(wdialog,"Bad number of arguments for max function.\n");
       RULE_FIRE_ERROR = TRUE; 
       return(0.0); }

   max_value = rfloat(1);

   for (i = 2 ; i <= num_a ; i++)
     {
      arg_value = rfloat(i);
      if (arg_value > max_value)
        { max_value = arg_value; }
     }
   
   return(max_value);
  }

/*************************************/
/*mod                                */
/*************************************/

float mod()
  {
    int arg_no;
    struct values *item1,*item2;
    float fnum1,fnum2,fnum3;
    int inum1,inum2,inum3;

    arg_no = num_args();
    if (arg_no != 2) {
       cl_print(wdialog,"Bad number of arguments for mod function.\n");
       RULE_FIRE_ERROR = TRUE;
       return(0.0); }
    item1 = runknown(1);
    item2 = runknown(2);
    if ((item1->type != NUMBER) || (item2->type != NUMBER)) {
       cl_print(wdialog,"Bad data type for mod function.\n");
       RULE_FIRE_ERROR = TRUE;
       return(0.0); }
    fnum1 = rfloat(1);
    fnum2 = rfloat(2);
    inum1 = (int) fnum1;
    inum2 = (int) fnum2;
    inum3 = inum1 % inum2;
    fnum3 = (float) inum3;
    return(fnum3);
  }

float my_trunc() {
        
	float num,result;

	if (arg_no_check("trunc") == FALSE) return(0.0);
	num = rfloat(1);
	result = (float) ((int) num);
	return(result);

    } 

float my_pi() {

     	return(PI);
    }
   
                   
float my_deg_rad() {
        
	float num,result;

	if (arg_no_check("deg-rad") == FALSE) return(0.0);
	num = rfloat(1);
	result = num * PI / 180.0;
	return(result);

    }

float my_rad_deg() {
        
	float num,result;

	if (arg_no_check("rad-deg") == FALSE) return(0.0);
	num = rfloat(1);
	result = num * 180.0 / PI;
	return(result);

    }

float my_deg_grad() {
        
	float num,result;
      
	if (arg_no_check("deg-grad") == FALSE) return(0.0);
	num = rfloat(1);
	result = num / 3.6;
	return(result);

    }

float my_grad_deg() {
        
	float num,result;

	if (arg_no_check("grad-deg") == FALSE) return(0.0);
	num = rfloat(1);
	result = num * 3.6;       
	return(result);

    }

float my_abs()                                 
  {
    float num,result;

    extern float clsin();

    if (arg_no_check("abs") == FALSE) return(0.0);
    num = rfloat(1);

    if (num < 0.0)
      { result = -num; }
    else
      { result = num; }
    
    return(result);
  }

/***************************************************************************/
/*                                                                         */
/*                 SYSTEM DEPENDENT FUNCTIONS                              */
/*                                                                         */
/***************************************************************************/
float clcos(num)
   float num; {

     double arg,result;
     float rval;

     arg = (double) num;
     result = cos(arg);
     rval = (float) result;
     return(rval);
   }

float clsin(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = sin(arg);
    rval = (float) result;
    return(rval);
    }


float cltan(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = tan(arg);
    rval = (float) result;
    return(rval);
    }


float clacos(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;

    result = acos(arg);
    rval = (float) result;
    return(rval);
    }


float clasin(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = asin(arg);
    rval = (float) result;
    return(rval);
    }


float clatan(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = atan(arg);
    rval = (float) result;
    return(rval);
    }


float clcosh(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = cosh(arg);
    rval = (float) result;
    return(rval);
    }


float clsinh(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = sinh(arg);
    rval = (float) result;
    return(rval);
    }


float cltanh(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = tanh(arg);
    rval = (float) result;
    return(rval);
    }



float clacosh(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = log(arg + sqrt(arg*arg-1.0));
    rval = (float) result;
    return(rval);
    }


float clasinh(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = log(arg + sqrt(arg*arg+1.0));
    rval = (float) result;
    return(rval);
    }


float clatanh(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = (0.5)*log((1.0 + arg)/(1.0 - arg));
    rval = (float) result;
    return(rval);
    }


float clasech(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = log(1.0/arg + sqrt(1.0/(arg*arg) - 1.0));
    rval = (float) result;
    return(rval);
    }


float clacsch(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = log(1.0/arg + sqrt(1.0/(arg*arg) + 1.0));
    rval = (float) result;
    return(rval);
    }


float clacoth(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = (0.5)*log((arg + 1.0)/(arg - 1.0));
    rval = (float) result;
    return(rval);
    }


float clexp(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = exp(arg);
    rval = (float) result;
    return(rval);
    }


float cllog(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = log(arg);
    rval = (float) result;
    return(rval);
    }


float cllog10(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = log10(arg);
    rval = (float) result;
    return(rval);
    }


float clsqrt(num)
    float num; {

    double arg,result;
    float rval;

    arg = (double) num;
    result = sqrt(arg);
    rval = (float) result;
    return(rval);
    }
