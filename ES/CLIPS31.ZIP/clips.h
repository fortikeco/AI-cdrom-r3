#include "constdef.h"
#include "structdef.h"

extern define_function();
extern int num_args();     
extern float rfloat();
extern char *rstring();
extern struct values *runknown();
extern int findstr();

extern FILE *wclips, *wdialog, *wdisplay;
extern int cl_getc();
extern int cl_ungetc();
extern int cl_print();
extern int cl_exit();

extern int RULE_FIRE_ERROR;

