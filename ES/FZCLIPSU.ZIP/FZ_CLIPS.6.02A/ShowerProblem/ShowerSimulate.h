#define 	PX  30.0	/* [kPa] air pressure at shower head */

#define		TC  5.0		/* [Celcius] cold water temperature (initial) */
#define		TH  65.0	/* [Celcius] hot  water temperature (initial) */
#define		TScalding  45.0  /* [Celcius] temp of scalding water */

#define		PC  60.0	/* [kPa] cold water pressure (initial) */
#define		PH  60.0	/* [kPa] hot water pressure (initial) */

#define		T_OPT  36.0	/* [Celcius] optimal water temperature */
#define		F_OPT 12.0	/* [litres/second] optimal water flow */

#define		T_OPT_range 2.0  /* amount above or below T_OPT that is acceptable */
#define		F_OPT_range 1.0  /* amount above or below F_OPT that is acceptable */

#define		T_MAX  45.0	/* [Celcius] maximum water temperature */
#define		T_MIN  15.0	/* [Celcius] minimum water temperature */


#define NoProblem 0
#define HotWaterProblem 1
#define ColdWaterProblem 2
#define HotWaterTempProblem 3
#define ColdWaterTempProblem 4


#define AutoMode  0
#define ManualMode 1


#define MaxLogFileEntries 1000    /* max size of arrays to hold logging data */
#define MaxStatFileEntries 300   /* max size of arrays to hold stat data */

#define ValveMoveSetupTime   5    /* milliseconds to set up the valve to move */
#define ValveFullMoveTime 100.0  /* milliseconds to move valve from full off to full on */

#define ValvesMoveOneAtaTime  TRUE     /* TRUE if can only move vales one after the other */
