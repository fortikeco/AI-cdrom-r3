#ifndef _T_SHOWER_H_
#define _T_SHOWER_H_

/* ----------------------------------------------------------------
 *	A few generally useful macros...
 */

#if !defined(ANSI)

#if  defined(__STDC__)  ||  defined(__cplusplus)
#define	ANSI(stmt)	stmt
#define	TRAD(stmt)
#else
#define	ANSI(stmt)
#define	TRAD(stmt)	stmt
#endif	/* __STDC__ || __cplusplus */

#endif	/* ANSI */


#if !defined(IF_DEBUG)

#if defined(DEBUG)
#define	IF_DEBUG(stmt)	stmt
#else
#define	IF_DEBUG(stmt)
#endif	/* DEBUG */
#endif	/* IF_DEBUG */



	/* Prototypes for all generated callback routines */

	/*  Common Client Side for All Button Handlers */

extern void GNTButtonHandler ();


	/*
	 *    Callback Routine for: 
	 *
	 *	ChngPressureMenu (Item Handler for Item number 0)
	 *	ChngPressureMenu (Item Handler for Item number 1)
	 *	ChngPressureMenu (Item Handler for Item number 2)
	 *	ChngPressureMenu (Item Handler for Item number 3)
	 *	ChngPressureMenu (Item Handler for Item number 4)
	 *	ChngPressureMenu (Item Handler for Item number 5)
	 */

extern void ChngPressureMenuItemHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	RTimeScaleMenu (Item Handler for Item number 0)
	 *	RTimeScaleMenu (Item Handler for Item number 1)
	 *	RTimeScaleMenu (Item Handler for Item number 2)
	 *	RTimeScaleMenu (Item Handler for Item number 3)
	 *	RTimeScaleMenu (Item Handler for Item number 4)
	 */

extern void RTimeMenuItemHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	loggingMenu (Item Handler for Item number 1)
	 */

extern void StopLoggingMenuItemHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	FuzzyShower (Notifier)
	 *	StartLoggingPopupWindow (Notifier)
	 */

extern void windowquit ();

	/*
	 *    Callback Routine for: 
	 *
	 *	ModeSetting (Notifier)
	 */

extern void ModeSettingNotifyHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	HotValveSlider (Notifier)
	 */

extern void HotValveNotifyHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	HotTempSlider (Notifier)
	 */

extern void HotTempNotifyHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	ColdValveSlider (Notifier)
	 */

extern void ColdValveNotifyHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	ColdTempSlider (Notifier)
	 */

extern void ColdTempNotifyHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	StartLogFileTextfield (Notifier)
	 *	StartLoggingButton (Notifier)
	 */

extern void StartLoggingTextHandler ();

	/*
	 *    Callback Routine for: 
	 *
	 *	StartLoggingButton (Notifier)
	 */

extern void StartLoggingButtonHandler ();

	/*
	 * define the string structures 
	 *
	 */ 

extern struct stringtype Shower_strings[];


	/*
	 *    Autoloader Routine 
	 *
	 */
extern void autoloader ();

	/*
	 *    Object number definitions
	 */

#define SHOWER_CHNGPRESSUREMENU                  0
#define SHOWER_CHNGPRESSUREMENU_itm0	1
#define SHOWER_CHNGPRESSUREMENU_itm1	2
#define SHOWER_CHNGPRESSUREMENU_itm2	3
#define SHOWER_CHNGPRESSUREMENU_itm3	4
#define SHOWER_CHNGPRESSUREMENU_itm4	5
#define SHOWER_CHNGPRESSUREMENU_itm5	6
#define SHOWER_RTIMESCALEMENU                    7
#define SHOWER_RTIMESCALEMENU_itm0	8
#define SHOWER_RTIMESCALEMENU_itm1	9
#define SHOWER_RTIMESCALEMENU_itm2	10
#define SHOWER_RTIMESCALEMENU_itm3	11
#define SHOWER_RTIMESCALEMENU_itm4	12
#define SHOWER_LOGGINGMENU                       13
#define SHOWER_LOGGINGMENU_itm1		14
#define SHOWER_FUZZYSHOWER                       15
#define SHOWER_FUZZYSHOWER_CONTROLNORTH          16
#define SHOWER_FUZZYSHOWER_SHOWERTEMPMESSAGE     17
#define SHOWER_FUZZYSHOWER_SHOWERFLOWMESSAGE     18
#define SHOWER_FUZZYSHOWER_SHOWERTEMPGUAGE       19
#define SHOWER_FUZZYSHOWER_SHOWERFLOWGUAGE       20
#define SHOWER_FUZZYSHOWER_CONTROLWEST           21
#define SHOWER_FUZZYSHOWER_MODESETTING           22
#define SHOWER_FUZZYSHOWER_HOTVALVEMESSAGE       23
#define SHOWER_FUZZYSHOWER_HOTVALVESLIDER        24
#define SHOWER_FUZZYSHOWER_HOTTEMPMESSAGE        25
#define SHOWER_FUZZYSHOWER_HOTTEMPSLIDER         26
#define SHOWER_FUZZYSHOWER_CONTROLEAST           27
#define SHOWER_FUZZYSHOWER_TIMETEXT              28
#define SHOWER_FUZZYSHOWER_COLDVALVEMESSAGE      29
#define SHOWER_FUZZYSHOWER_COLDVALVESLIDER       30
#define SHOWER_FUZZYSHOWER_COLDTEMPMESSAGE       31
#define SHOWER_FUZZYSHOWER_COLDTEMPSLIDER        32
#define SHOWER_FUZZYSHOWER_SHOWERPIPINGCANVAS    33
#define SHOWER_FUZZYSHOWER_CONTROLSOUTH          34
#define SHOWER_FUZZYSHOWER_HOTPRESSUREMESSAGE    35
#define SHOWER_FUZZYSHOWER_COLDPRESSUREMESSAGE   36
#define SHOWER_FUZZYSHOWER_HOTPRESSUREGUAGE      37
#define SHOWER_FUZZYSHOWER_COLDPRESSUREGUAGE     38
#define SHOWER_FUZZYSHOWER_CONTROLS1             39
#define SHOWER_FUZZYSHOWER_REALTIMESCALEBUTTON   40
#define SHOWER_FUZZYSHOWER_LOGFILEBUTTON         41
#define SHOWER_FUZZYSHOWER_CHANGEPRESSUREBUTTON  42
#define SHOWER_STARTLOGGINGPOPUPWINDOW           43
#define SHOWER_STARTLOGGINGPOPUPWINDOW_CONTROLS2 44
#define SHOWER_STARTLOGGINGPOPUPWINDOW_STARTLOGDIRTEXTFIELD 45
#define SHOWER_STARTLOGGINGPOPUPWINDOW_STARTLOGFILETEXTFIELD 46
#define SHOWER_STARTLOGGINGPOPUPWINDOW_STARTLOGGINGBUTTON 47
#define LOADFILE_SHOWER				 48

	/*
	 *    Operational Functions
	 */

void Allocate_Shower_Tags ();	/* Allocate the tokens/tags for the callbacks */
int runShower ();	/* Load PostScript Interface and Server Callbacks */



#ifdef PROTO
extern int	popup_up;
#endif /* PROTO */

extern boolean	gntquit;


#endif
