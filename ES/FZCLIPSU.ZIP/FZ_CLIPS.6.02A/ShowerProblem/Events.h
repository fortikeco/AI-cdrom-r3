
/*  definition of events for the Shower Simulation Problem

	NOTE: must also define EventNames.h !!!!
*/


#define EVENT_changePressureHot	(short) 1
#define EVENT_changePressureCold	(short) 2
#define EVENT_updateClock		(short) 3
#define EVENT_moveHotValve		(short) 4
#define EVENT_moveColdValve	(short) 5
#define EVENT_moveHotValve_setProblem	(short) 6
#define EVENT_moveColdValve_setProblem	(short) 7



struct eventData
	{  int intValue;
	   float floatValue;
	   char *stringValue;
	};

/* values below stored in the int slot of the eventData structure */

#define NothingSpecial		0
#define Toilet1FlushStart 	1
#define Toilet1FlushEnd		2
#define Toilet2FlushStart 	3
#define Toilet2FlushEnd		4
#define GardenHoseON		5
#define GardenHoseOFF		6
#define WashingMachineStart		7
#define WashingMachineCycle1End	8
#define WashingMachineCycle2Start 	9
#define WashingMachineCycle2End	10
#define WashingMachineEnd		11
#define DishwasherStart		12
#define DishwasherCycle1End		13
#define DishwasherCycle2Start	14
#define DishwasherCycle2End		15
#define DishwasherEnd		16

