/*
  Definitions of names of the event for the Shower simulation problem

	See also Events.h

*/




#define EVN1 "Event - Change pressure of Hot water"      
#define EVN2 "Event - Change pressure of Cold water"
#define EVN3 "Event - Update clock - 1 second intervals"
#define EVN4 "Event - Move Hot Water Valve"
#define EVN5 "Event - Move Cold Water Valve"
#define EVN6 "Event - Move Hot Water Valve, set valvePositionsDetermined to TRUE  and set SystemProblem"
#define EVN7 "Event - Move Cold Water Valve, set valvePositionsDetermined to TRUE  and set SystemProblem"


static char *eventNames[] = {"", EVN1, EVN2, EVN3, EVN4, EVN5 };




