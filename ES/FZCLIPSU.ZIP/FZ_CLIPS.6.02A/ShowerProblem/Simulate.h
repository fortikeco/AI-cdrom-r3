/*
  Definitions for the Simulation

*/




#include "Events.h"  /* specific to the current simulation -- as shown below */

/*

 ***** replace a, b, c, d etc below with required event names *******

#define EVENT_a		(short) 1
#define EVENT_b		(short) 2
#define EVENT_c		(short) 3
#define EVENT_d		(short) 4
#define EVENT_e		(short) 5
#define EVENT_f		(short) 6

 ****** replace the struct below with the one needed for the simulation *****

struct eventData
	{  int intValue;
	   float floatValue;
	   char *stringValue;
	};


*/


#include "EventNames.h"   /* define routine specific to surrent simulation 
			   as show below   */
/*

#define EVN1 "Event a name"      
#define EVN2 "Event b name"
#define EVN3 "Event c name"
#define EVN4 "Event d name"
#define EVN5 "Event e name"
#define EVN6 "Event f name"


static char *eventNames[] = {"", EVN1, EVN2, EVN3, EVN4, EVN5, EVN6 };


*/



struct eventQueue   /* the event queue structure (a linked list of these) */
{
  short eventType;                /* type of event (get level, pump on, etc.) */
  long  eventTime;                /* time of the event */
  struct eventData *eventDataPtr; /* some value to record here -- specific to
				     the event -- defined in Events.h   */
  struct eventQueue *next;        /* next event in the queue */
};

