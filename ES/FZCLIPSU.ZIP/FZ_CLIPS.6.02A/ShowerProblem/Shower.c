    /* 
     *  Shower.c C Interface to Callbacks 
     */


#include <sys/types.h>
#if defined(SYSV)
#include <string.h>
#else
#include <strings.h>
#endif
#include <stdio.h>
#include <wire/wire.h>
#include <psload.h>
#include <jot/jot.h>
#include <jot/text.h>
#include <jot/view.h>
#include <jot/undo.h>
#include <guideJot.h>
#include <help/helplib.h>

#include "tmp/Shower.h"
#include "tmp/Shower_c.h"
#include "tmp/Shower_C.h"
#include "src/Shower_p.h"

int t_Shower_ChngPressureMenu;	/* Tag number for ChngPressureMenu */
int tk_Shower_ChngPressureMenu;	/* Token number for ChngPressureMenu */
int t_Shower_ChngPressureMenu_itm0;/* Tag number for ChngPressureMenu */
int t_Shower_ChngPressureMenu_itm1;/* Tag number for ChngPressureMenu */
int t_Shower_ChngPressureMenu_itm2;/* Tag number for ChngPressureMenu */
int t_Shower_ChngPressureMenu_itm3;/* Tag number for ChngPressureMenu */
int t_Shower_ChngPressureMenu_itm4;/* Tag number for ChngPressureMenu */
int t_Shower_ChngPressureMenu_itm5;/* Tag number for ChngPressureMenu */
int t_Shower_RTimeScaleMenu;	/* Tag number for RTimeScaleMenu */
int tk_Shower_RTimeScaleMenu;	/* Token number for RTimeScaleMenu */
int t_Shower_RTimeScaleMenu_itm0;/* Tag number for RTimeScaleMenu */
int t_Shower_RTimeScaleMenu_itm1;/* Tag number for RTimeScaleMenu */
int t_Shower_RTimeScaleMenu_itm2;/* Tag number for RTimeScaleMenu */
int t_Shower_RTimeScaleMenu_itm3;/* Tag number for RTimeScaleMenu */
int t_Shower_RTimeScaleMenu_itm4;/* Tag number for RTimeScaleMenu */
int t_Shower_loggingMenu;	/* Tag number for loggingMenu */
int tk_Shower_loggingMenu;	/* Token number for loggingMenu */
int t_Shower_loggingMenu_itm1;/* Tag number for loggingMenu */
int t_Shower_FuzzyShower;	/* Tag number for FuzzyShower */
int tk_Shower_FuzzyShower;	/* Token number for FuzzyShower */
int t_Shower_FuzzyShower_ControlNorth;/* Tag number for ControlNorth */
int tk_Shower_FuzzyShower_ControlNorth;/* Token number for ControlNorth */
int t_Shower_FuzzyShower_ShowerTempMessage;/* Tag number for ShowerTempMessage */
int tk_Shower_FuzzyShower_ShowerTempMessage;/* Token number for ShowerTempMessage */
int t_Shower_FuzzyShower_ShowerFlowMessage;/* Tag number for ShowerFlowMessage */
int tk_Shower_FuzzyShower_ShowerFlowMessage;/* Token number for ShowerFlowMessage */
int t_Shower_FuzzyShower_ShowerTempGuage;/* Tag number for ShowerTempGuage */
int tk_Shower_FuzzyShower_ShowerTempGuage;/* Token number for ShowerTempGuage */
int t_Shower_FuzzyShower_ShowerFlowGuage;/* Tag number for ShowerFlowGuage */
int tk_Shower_FuzzyShower_ShowerFlowGuage;/* Token number for ShowerFlowGuage */
int t_Shower_FuzzyShower_ControlWest;/* Tag number for ControlWest */
int tk_Shower_FuzzyShower_ControlWest;/* Token number for ControlWest */
int t_Shower_FuzzyShower_ModeSetting;/* Tag number for ModeSetting */
int tk_Shower_FuzzyShower_ModeSetting;/* Token number for ModeSetting */
int t_Shower_FuzzyShower_HotValveMessage;/* Tag number for HotValveMessage */
int tk_Shower_FuzzyShower_HotValveMessage;/* Token number for HotValveMessage */
int t_Shower_FuzzyShower_HotValveSlider;/* Tag number for HotValveSlider */
int tk_Shower_FuzzyShower_HotValveSlider;/* Token number for HotValveSlider */
int t_Shower_FuzzyShower_HotTempMessage;/* Tag number for HotTempMessage */
int tk_Shower_FuzzyShower_HotTempMessage;/* Token number for HotTempMessage */
int t_Shower_FuzzyShower_HotTempSlider;/* Tag number for HotTempSlider */
int tk_Shower_FuzzyShower_HotTempSlider;/* Token number for HotTempSlider */
int t_Shower_FuzzyShower_ControlEast;/* Tag number for ControlEast */
int tk_Shower_FuzzyShower_ControlEast;/* Token number for ControlEast */
int t_Shower_FuzzyShower_TimeText;/* Tag number for TimeText */
int tk_Shower_FuzzyShower_TimeText;/* Token number for TimeText */
int t_Shower_FuzzyShower_ColdValveMessage;/* Tag number for ColdValveMessage */
int tk_Shower_FuzzyShower_ColdValveMessage;/* Token number for ColdValveMessage */
int t_Shower_FuzzyShower_ColdValveSlider;/* Tag number for ColdValveSlider */
int tk_Shower_FuzzyShower_ColdValveSlider;/* Token number for ColdValveSlider */
int t_Shower_FuzzyShower_ColdTempMessage;/* Tag number for ColdTempMessage */
int tk_Shower_FuzzyShower_ColdTempMessage;/* Token number for ColdTempMessage */
int t_Shower_FuzzyShower_ColdTempSlider;/* Tag number for ColdTempSlider */
int tk_Shower_FuzzyShower_ColdTempSlider;/* Token number for ColdTempSlider */
int t_Shower_FuzzyShower_ShowerPipingCanvas;/* Tag number for ShowerPipingCanvas */
int tk_Shower_FuzzyShower_ShowerPipingCanvas;/* Token number for ShowerPipingCanvas */
int t_Shower_FuzzyShower_ControlSouth;/* Tag number for ControlSouth */
int tk_Shower_FuzzyShower_ControlSouth;/* Token number for ControlSouth */
int t_Shower_FuzzyShower_HotPressureMessage;/* Tag number for HotPressureMessage */
int tk_Shower_FuzzyShower_HotPressureMessage;/* Token number for HotPressureMessage */
int t_Shower_FuzzyShower_ColdPressureMessage;/* Tag number for ColdPressureMessage */
int tk_Shower_FuzzyShower_ColdPressureMessage;/* Token number for ColdPressureMessage */
int t_Shower_FuzzyShower_HotPressureGuage;/* Tag number for HotPressureGuage */
int tk_Shower_FuzzyShower_HotPressureGuage;/* Token number for HotPressureGuage */
int t_Shower_FuzzyShower_ColdPressureGuage;/* Tag number for ColdPressureGuage */
int tk_Shower_FuzzyShower_ColdPressureGuage;/* Token number for ColdPressureGuage */
int t_Shower_FuzzyShower_controls1;/* Tag number for controls1 */
int tk_Shower_FuzzyShower_controls1;/* Token number for controls1 */
int t_Shower_FuzzyShower_RealTimeScaleButton;/* Tag number for RealTimeScaleButton */
int tk_Shower_FuzzyShower_RealTimeScaleButton;/* Token number for RealTimeScaleButton */
int t_Shower_FuzzyShower_LogFileButton;/* Tag number for LogFileButton */
int tk_Shower_FuzzyShower_LogFileButton;/* Token number for LogFileButton */
int t_Shower_FuzzyShower_ChangePressureButton;/* Tag number for ChangePressureButton */
int tk_Shower_FuzzyShower_ChangePressureButton;/* Token number for ChangePressureButton */
int t_Shower_StartLoggingPopupWindow;/* Tag number for StartLoggingPopupWindow */
int tk_Shower_StartLoggingPopupWindow;/* Token number for StartLoggingPopupWindow */
int t_Shower_StartLoggingPopupWindow_controls2;/* Tag number for controls2 */
int tk_Shower_StartLoggingPopupWindow_controls2;/* Token number for controls2 */
int t_Shower_StartLoggingPopupWindow_StartLogDirTextfield;/* Tag number for StartLogDirTextfield */
int tk_Shower_StartLoggingPopupWindow_StartLogDirTextfield;/* Token number for StartLogDirTextfield */
int t_Shower_StartLoggingPopupWindow_StartLogFileTextfield;/* Tag number for StartLogFileTextfield */
int tk_Shower_StartLoggingPopupWindow_StartLogFileTextfield;/* Token number for StartLogFileTextfield */
int t_Shower_StartLoggingPopupWindow_StartLoggingButton;/* Tag number for StartLoggingButton */
int tk_Shower_StartLoggingPopupWindow_StartLoggingButton;/* Token number for StartLoggingButton */
int t_Shower;			/* Tag number for autoload file Shower*/


int	t_scratch;

int    *tagarray [] =
{
	&t_Shower_ChngPressureMenu,
	&t_Shower_ChngPressureMenu_itm0,
	&t_Shower_ChngPressureMenu_itm1,
	&t_Shower_ChngPressureMenu_itm2,
	&t_Shower_ChngPressureMenu_itm3,
	&t_Shower_ChngPressureMenu_itm4,
	&t_Shower_ChngPressureMenu_itm5,
	&t_Shower_RTimeScaleMenu,
	&t_Shower_RTimeScaleMenu_itm0,
	&t_Shower_RTimeScaleMenu_itm1,
	&t_Shower_RTimeScaleMenu_itm2,
	&t_Shower_RTimeScaleMenu_itm3,
	&t_Shower_RTimeScaleMenu_itm4,
	&t_Shower_loggingMenu,
	&t_Shower_loggingMenu_itm1,
	&t_Shower_FuzzyShower,
	&t_Shower_FuzzyShower_ControlNorth,
	&t_Shower_FuzzyShower_ShowerTempMessage,
	&t_Shower_FuzzyShower_ShowerFlowMessage,
	&t_Shower_FuzzyShower_ShowerTempGuage,
	&t_Shower_FuzzyShower_ShowerFlowGuage,
	&t_Shower_FuzzyShower_ControlWest,
	&t_Shower_FuzzyShower_ModeSetting,
	&t_Shower_FuzzyShower_HotValveMessage,
	&t_Shower_FuzzyShower_HotValveSlider,
	&t_Shower_FuzzyShower_HotTempMessage,
	&t_Shower_FuzzyShower_HotTempSlider,
	&t_Shower_FuzzyShower_ControlEast,
	&t_Shower_FuzzyShower_TimeText,
	&t_Shower_FuzzyShower_ColdValveMessage,
	&t_Shower_FuzzyShower_ColdValveSlider,
	&t_Shower_FuzzyShower_ColdTempMessage,
	&t_Shower_FuzzyShower_ColdTempSlider,
	&t_Shower_FuzzyShower_ShowerPipingCanvas,
	&t_Shower_FuzzyShower_ControlSouth,
	&t_Shower_FuzzyShower_HotPressureMessage,
	&t_Shower_FuzzyShower_ColdPressureMessage,
	&t_Shower_FuzzyShower_HotPressureGuage,
	&t_Shower_FuzzyShower_ColdPressureGuage,
	&t_Shower_FuzzyShower_controls1,
	&t_Shower_FuzzyShower_RealTimeScaleButton,
	&t_Shower_FuzzyShower_LogFileButton,
	&t_Shower_FuzzyShower_ChangePressureButton,
	&t_Shower_StartLoggingPopupWindow,
	&t_Shower_StartLoggingPopupWindow_controls2,
	&t_Shower_StartLoggingPopupWindow_StartLogDirTextfield,
	&t_Shower_StartLoggingPopupWindow_StartLogFileTextfield,
	&t_Shower_StartLoggingPopupWindow_StartLoggingButton,
	&t_Shower,
	&t_scratch,
	0
};

int    *tokenarray [] =
{
	&tk_Shower_ChngPressureMenu,
	&tk_Shower_RTimeScaleMenu,
	&tk_Shower_loggingMenu,
	&tk_Shower_FuzzyShower,
	&tk_Shower_FuzzyShower_ControlNorth,
	&tk_Shower_FuzzyShower_ShowerTempMessage,
	&tk_Shower_FuzzyShower_ShowerFlowMessage,
	&tk_Shower_FuzzyShower_ShowerTempGuage,
	&tk_Shower_FuzzyShower_ShowerFlowGuage,
	&tk_Shower_FuzzyShower_ControlWest,
	&tk_Shower_FuzzyShower_ModeSetting,
	&tk_Shower_FuzzyShower_HotValveMessage,
	&tk_Shower_FuzzyShower_HotValveSlider,
	&tk_Shower_FuzzyShower_HotTempMessage,
	&tk_Shower_FuzzyShower_HotTempSlider,
	&tk_Shower_FuzzyShower_ControlEast,
	&tk_Shower_FuzzyShower_TimeText,
	&tk_Shower_FuzzyShower_ColdValveMessage,
	&tk_Shower_FuzzyShower_ColdValveSlider,
	&tk_Shower_FuzzyShower_ColdTempMessage,
	&tk_Shower_FuzzyShower_ColdTempSlider,
	&tk_Shower_FuzzyShower_ShowerPipingCanvas,
	&tk_Shower_FuzzyShower_ControlSouth,
	&tk_Shower_FuzzyShower_HotPressureMessage,
	&tk_Shower_FuzzyShower_ColdPressureMessage,
	&tk_Shower_FuzzyShower_HotPressureGuage,
	&tk_Shower_FuzzyShower_ColdPressureGuage,
	&tk_Shower_FuzzyShower_controls1,
	&tk_Shower_FuzzyShower_RealTimeScaleButton,
	&tk_Shower_FuzzyShower_LogFileButton,
	&tk_Shower_FuzzyShower_ChangePressureButton,
	&tk_Shower_StartLoggingPopupWindow,
	&tk_Shower_StartLoggingPopupWindow_controls2,
	&tk_Shower_StartLoggingPopupWindow_StartLogDirTextfield,
	&tk_Shower_StartLoggingPopupWindow_StartLogFileTextfield,
	&tk_Shower_StartLoggingPopupWindow_StartLoggingButton,
	0
};

   /*
    * Allocate_Shower_Tags ()
    *
    *	Automatically sets up callback routines for each object.
    *	Code is generated by GNT cside
    * 
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

void
Allocate_Shower_Tags()
{
    cps_set_Shower(t_Shower);

    wire_RegisterTag(t_Shower_ChngPressureMenu_itm0, ChngPressureMenuItemHandler,0);
    wire_RegisterTag(t_Shower_ChngPressureMenu_itm1, ChngPressureMenuItemHandler,0);
    wire_RegisterTag(t_Shower_ChngPressureMenu_itm2, ChngPressureMenuItemHandler,0);
    wire_RegisterTag(t_Shower_ChngPressureMenu_itm3, ChngPressureMenuItemHandler,0);
    wire_RegisterTag(t_Shower_ChngPressureMenu_itm4, ChngPressureMenuItemHandler,0);
    wire_RegisterTag(t_Shower_ChngPressureMenu_itm5, ChngPressureMenuItemHandler,0);
    wire_RegisterTag(t_Shower_RTimeScaleMenu_itm0, RTimeMenuItemHandler,0);
    wire_RegisterTag(t_Shower_RTimeScaleMenu_itm1, RTimeMenuItemHandler,0);
    wire_RegisterTag(t_Shower_RTimeScaleMenu_itm2, RTimeMenuItemHandler,0);
    wire_RegisterTag(t_Shower_RTimeScaleMenu_itm3, RTimeMenuItemHandler,0);
    wire_RegisterTag(t_Shower_RTimeScaleMenu_itm4, RTimeMenuItemHandler,0);
    wire_RegisterTag(t_Shower_loggingMenu_itm1, StopLoggingMenuItemHandler,0);
    wire_RegisterTag (t_Shower_FuzzyShower, windowquit,0);
    wire_RegisterTag (t_Shower_FuzzyShower_ModeSetting, ModeSettingNotifyHandler,0);
    wire_RegisterTag (t_Shower_FuzzyShower_HotValveSlider, HotValveNotifyHandler,0);
    wire_RegisterTag (t_Shower_FuzzyShower_HotTempSlider, HotTempNotifyHandler,0);
    wire_RegisterTag (t_Shower_FuzzyShower_ColdValveSlider, ColdValveNotifyHandler,0);
    wire_RegisterTag (t_Shower_FuzzyShower_ColdTempSlider, ColdTempNotifyHandler,0);
    wire_RegisterTag (t_Shower_StartLoggingPopupWindow, windowquit,0);
    wire_RegisterTag (t_Shower_StartLoggingPopupWindow_StartLogFileTextfield, StartLoggingTextHandler,0);
    wire_RegisterTag (t_Shower_StartLoggingPopupWindow_StartLoggingButton, StartLoggingButtonHandler,0);
    wire_RegisterTag(t_Shower, autoloader, 0);
}

   /*
    * runShower
    *	Loads callbacks and the Interface File
    *
    *	Code is generated by GNT cside
    * 
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

int
runShower ()
{
    wire_Wire	thewire;


    /*
     *    Allocate user tokens for the objects
     */

    thewire =wire_Current ();
    wire_AllocateNamedTags(tagarray);
    wire_AllocateNamedTokens(thewire, tokenarray);

    autoloader (t_Shower,0);

#ifdef PROTO
#else
/******  Added at NRC for ShowerProblem ******/

   setShowerPipingCanvasPaint();

/******  Added at NRC for ShowerProblem ******/
#endif

    Allocate_Shower_Tags();

    /*
     * Activate all windows and open those mapped true
     */

    cps_open_windows();

    return (0);	    /* No error */ 
}



   /*
    * GNTButtonHandler ()
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

void
GNTButtonHandler ()
{
    char buf[256];
    wire_ReadString(buf);

    if (!strcmp(buf, "Shower_StartLoggingPopupWindow_StartLoggingButton"))
    {
	StartLoggingButtonHandler(t_Shower_StartLoggingPopupWindow_StartLoggingButton, 0);
    }
    else
        wire_SkipEvent ();
}


   /*
    * ChngPressureMenuItemHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    ChngPressureMenu (Item Handler for Item number 0)
    *	    ChngPressureMenu (Item Handler for Item number 1)
    *	    ChngPressureMenu (Item Handler for Item number 2)
    *	    ChngPressureMenu (Item Handler for Item number 3)
    *	    ChngPressureMenu (Item Handler for Item number 4)
    *	    ChngPressureMenu (Item Handler for Item number 5)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
ChngPressureMenuItemHandler (tag, data)
    int tag;
    caddr_t data;
{
    int relativetag;
    int index;		/* Index of selected item */
    int state;		/* Boolean of selected */
    char buf[256];	/* Buffer for string */

    relativetag = tag - t_Shower_ChngPressureMenu;
    switch (relativetag)
    {
	case SHOWER_CHNGPRESSUREMENU_itm0:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("ChngPressureMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("ChngPressureMenu called with index %d value %s false\n", index, buf);
#else
	        /* Custom code goes here */
		FlushToilet1Callback();
#endif
	    break;
	case SHOWER_CHNGPRESSUREMENU_itm1:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("ChngPressureMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("ChngPressureMenu called with index %d value %s false\n", index, buf);
#else
	        /* Custom code goes here */
		FlushToilet2Callback();
#endif
	    break;
	case SHOWER_CHNGPRESSUREMENU_itm2:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("ChngPressureMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("ChngPressureMenu called with index %d value %s false\n", index, buf);
#else
	        /* Custom code goes here */
		GardenHoseOnCallback();
#endif
	    break;
	case SHOWER_CHNGPRESSUREMENU_itm3:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("ChngPressureMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("ChngPressureMenu called with index %d value %s false\n", index, buf);
#else
	        /* Custom code goes here */
		GardenHoseOffCallback();
#endif
	    break;
	case SHOWER_CHNGPRESSUREMENU_itm4:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("ChngPressureMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("ChngPressureMenu called with index %d value %s false\n", index, buf);
#else
	        /* Custom code goes here */
		DishwasherOnCallback();
#endif
	    break;
	case SHOWER_CHNGPRESSUREMENU_itm5:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("ChngPressureMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("ChngPressureMenu called with index %d value %s false\n", index, buf);
#else
	        /* Custom code goes here */
		WashingMachineOnCallback();
#endif
	    break;
    } /* end switch (relativetag) */
}


   /*
    * RTimeMenuItemHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    RTimeScaleMenu (Item Handler for Item number 0)
    *	    RTimeScaleMenu (Item Handler for Item number 1)
    *	    RTimeScaleMenu (Item Handler for Item number 2)
    *	    RTimeScaleMenu (Item Handler for Item number 3)
    *	    RTimeScaleMenu (Item Handler for Item number 4)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
RTimeMenuItemHandler (tag, data)
    int tag;
    caddr_t data;
{
    int relativetag;
    int index;		/* Index of selected item */
    int state;		/* Boolean of selected */
    char buf[256];	/* Buffer for string */

    relativetag = tag - t_Shower_ChngPressureMenu;
    switch (relativetag)
    {
	case SHOWER_RTIMESCALEMENU_itm0:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("RTimeScaleMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("RTimeScaleMenu called with index %d value %s false\n", index, buf);
#else
#endif
	    break;
	case SHOWER_RTIMESCALEMENU_itm1:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("RTimeScaleMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("RTimeScaleMenu called with index %d value %s false\n", index, buf);
#else
#endif
	    break;
	case SHOWER_RTIMESCALEMENU_itm2:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("RTimeScaleMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("RTimeScaleMenu called with index %d value %s false\n", index, buf);
#else
#endif
	    break;
	case SHOWER_RTIMESCALEMENU_itm3:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("RTimeScaleMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("RTimeScaleMenu called with index %d value %s false\n", index, buf);
#else
#endif
	    break;
	case SHOWER_RTIMESCALEMENU_itm4:
	    index = wire_ReadInt ();
	    state = wire_ReadInt ();
	    wire_ReadString (buf);

#ifdef PROTO
	    if (state)
	        printf("RTimeScaleMenu called with index %d value %s true\n", index, buf);
	    else
	        printf("RTimeScaleMenu called with index %d value %s false\n", index, buf);
#else
#endif
	    break;
    } /* end switch (relativetag) */
}


   /*
    * StopLoggingMenuItemHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    loggingMenu (Item Handler for Item number 1)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
StopLoggingMenuItemHandler (tag, data)
    int tag;
    caddr_t data;
{
    int index;		/* Index of selected item */
    int state;		/* Boolean of selected */
    char buf[256];	/* Buffer for string */
    index = wire_ReadInt ();
    state = wire_ReadInt ();
    wire_ReadString (buf);

#ifdef PROTO
    if (state)
        printf("loggingMenu called with index %d value %s true\n", index, buf);
    else
        printf("loggingMenu called with index %d value %s false\n", index, buf);
#else
        /* Custom code goes here */
	StopLoggingCallback();
#endif
}


   /*
    * windowquit
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    FuzzyShower (Notifier)
    *	    StartLoggingPopupWindow (Notifier)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
windowquit (tag, data)
    int tag;
    caddr_t data;
{
    int relativetag;
    int result;

    relativetag = tag - t_Shower_ChngPressureMenu;
    switch (relativetag)
    {

	case SHOWER_FUZZYSHOWER:
	    cps_ConfirmQuit_Shower_FuzzyShower (&result,t_scratch);
	    if (result)
	        {
	        gntquit = 1;
#ifdef PROTO
	        printf("FuzzyShower quit\n");
#else
	        /* Custom code goes here */
#endif
	       }
	    break;

	case SHOWER_STARTLOGGINGPOPUPWINDOW:
#ifdef PROTO
	    popup_up = 0;
	    printf("StartLoggingPopupWindow was dismissed\n");
#else
	        /* Custom code goes here */
#endif
	    break;
    } /* end switch (relativetag) */
}


   /*
    * ModeSettingNotifyHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    ModeSetting (Notifier)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
ModeSettingNotifyHandler (tag, data)
    int tag;
    caddr_t data;
{
    int index;		/* Index of selected item */
    int state;		/* Boolean of selected */
    char buf[256];	/* Buffer for string */
    index = wire_ReadInt ();
    state = wire_ReadInt ();
    wire_ReadString (buf);

#ifdef PROTO
    if (state)
        printf("ModeSetting called with index %d value %s true\n", index, buf);
    else
        printf("ModeSetting called with index %d value %s false\n", index, buf);
#else
        /* Custom code goes here */
	ModeSettingCallback(index);
#endif
}


   /*
    * HotValveNotifyHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    HotValveSlider (Notifier)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
HotValveNotifyHandler (tag, data)
    int tag;
    caddr_t data;
{
    float slidervalue;	/* Sliders return floats */
    slidervalue = wire_ReadFloat ();

#ifdef PROTO
    printf("HotValveSlider called with value %f\n",slidervalue);
#else
        /* Custom code goes here */
	HotValveCallback(slidervalue);
#endif
}


   /*
    * HotTempNotifyHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    HotTempSlider (Notifier)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
HotTempNotifyHandler (tag, data)
    int tag;
    caddr_t data;
{
    float slidervalue;	/* Sliders return floats */
    slidervalue = wire_ReadFloat ();

#ifdef PROTO
    printf("HotTempSlider called with value %f\n",slidervalue);
#else
        /* Custom code goes here */
	HotTempSliderCallback(slidervalue);
#endif
}


   /*
    * ColdValveNotifyHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    ColdValveSlider (Notifier)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
ColdValveNotifyHandler (tag, data)
    int tag;
    caddr_t data;
{
    float slidervalue;	/* Sliders return floats */
    slidervalue = wire_ReadFloat ();

#ifdef PROTO
    printf("ColdValveSlider called with value %f\n",slidervalue);
#else
        /* Custom code goes here */
	ColdValveCallback(slidervalue);
#endif
}


   /*
    * ColdTempNotifyHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    ColdTempSlider (Notifier)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
ColdTempNotifyHandler (tag, data)
    int tag;
    caddr_t data;
{
    float slidervalue;	/* Sliders return floats */
    slidervalue = wire_ReadFloat ();

#ifdef PROTO
    printf("ColdTempSlider called with value %f\n",slidervalue);
#else
        /* Custom code goes here */
	ColdTempSliderCallback(slidervalue);
#endif
}


   /*
    * StartLoggingTextHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    StartLogFileTextfield (Notifier)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921120	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
StartLoggingTextHandler (tag, data)
    int tag;
    caddr_t data;
{
    char buf[256];	/* Buffer for string */
    wire_ReadString(buf);

#ifdef PROTO
    printf("StartLogFileTextfield called with string %s\n",buf);
#else
	        /* Custom code goes here */
		StartLoggingCallback();
#endif
}



   /*
    * StartLoggingButtonHandler
    *
    *	Automatically generated callback routine 
    *	for the following object(s):
    *
    *	    StartLoggingButton (Notifier)
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921120	1.0	-Auto-	Stubs Generated by GNT from Shower.G
    */

    void
StartLoggingButtonHandler (tag, data)
    int tag;
    caddr_t data;
{
    int index;		/* Index of selected item */
    int state;		/* Boolean of selected */
    char buf[256];	/* Buffer for string */
    index = wire_ReadInt ();
    state = wire_ReadInt ();
    wire_ReadString (buf);

#ifdef PROTO
    if (state)
        printf("StartLoggingButton called with index %d value %s true\n", index, buf);
    else
        printf("StartLoggingButton called with index %d value %s false\n", index, buf);
#else
	        /* Custom code goes here */
		StartLoggingCallback();
#endif
}


   /*
    *
    *	Automatically generated routine for autoloading
    *
    * Revision History:
    *
    *	Date	Vers	Who	What
    *	===============================================================
    *	921001	1.0	-Auto-	Stubs Generated by GNT from Shower.G
     */

    void
autoloader  (tag, data)
    int tag;
    caddr_t data;
{
    int relativetag;
    int i;

    relativetag = tag - t_Shower_ChngPressureMenu;
    switch(relativetag)
    {

	case LOADFILE_SHOWER:  /* Loads Shower.ps Shower.PS and Shower_I.ps */
	    if ((i = loadPostScript(0, "C", "src/Shower.ps", "Shower", Showerps_loadfile, 0)) != 0)
	    {
		printf("Shower.ps did not load\n");
		exit (0);
	    }

	    if ((i = loadPostScript((int *)Shower_strings, "C", "tmp/Shower.PS", "Shower", Shower_loadfile, 1)) != 0)
	    {
		printf("Shower.PS did not load\n");
		exit (0);
	    }

	    if ((i = loadPostScript(0, "C", "src/Shower_I.ps", "Shower", ShowerIps_loadfile, 0)) != 0)
	    {
		printf("Shower_I.ps did not load\n");
		exit (0);
	    }

            cps_setShower_ChngPressureMenu (tk_Shower_ChngPressureMenu, t_Shower_ChngPressureMenu_itm0, t_Shower_ChngPressureMenu_itm1, t_Shower_ChngPressureMenu_itm2, t_Shower_ChngPressureMenu_itm3, t_Shower_ChngPressureMenu_itm4, t_Shower_ChngPressureMenu_itm5);
            cps_setShower_RTimeScaleMenu (tk_Shower_RTimeScaleMenu, t_Shower_RTimeScaleMenu_itm0, t_Shower_RTimeScaleMenu_itm1, t_Shower_RTimeScaleMenu_itm2, t_Shower_RTimeScaleMenu_itm3, t_Shower_RTimeScaleMenu_itm4);
            cps_setShower_loggingMenu (tk_Shower_loggingMenu, t_Shower_loggingMenu_itm1);
            cps_setShower_FuzzyShower (t_Shower_FuzzyShower, tk_Shower_FuzzyShower);
            cps_setShower_FuzzyShower_ControlNorth (tk_Shower_FuzzyShower_ControlNorth);
            cps_setShower_FuzzyShower_ShowerTempMessage (tk_Shower_FuzzyShower_ShowerTempMessage);
            cps_setShower_FuzzyShower_ShowerFlowMessage (tk_Shower_FuzzyShower_ShowerFlowMessage);
            cps_setShower_FuzzyShower_ShowerTempGuage (tk_Shower_FuzzyShower_ShowerTempGuage);
            cps_setShower_FuzzyShower_ShowerFlowGuage (tk_Shower_FuzzyShower_ShowerFlowGuage);
            cps_setShower_FuzzyShower_ControlWest (tk_Shower_FuzzyShower_ControlWest);
            cps_setShower_FuzzyShower_ModeSetting (t_Shower_FuzzyShower_ModeSetting, tk_Shower_FuzzyShower_ModeSetting);
            cps_setShower_FuzzyShower_HotValveMessage (tk_Shower_FuzzyShower_HotValveMessage);
            cps_setShower_FuzzyShower_HotValveSlider (t_Shower_FuzzyShower_HotValveSlider, tk_Shower_FuzzyShower_HotValveSlider);
            cps_setShower_FuzzyShower_HotTempMessage (tk_Shower_FuzzyShower_HotTempMessage);
            cps_setShower_FuzzyShower_HotTempSlider (t_Shower_FuzzyShower_HotTempSlider, tk_Shower_FuzzyShower_HotTempSlider);
            cps_setShower_FuzzyShower_ControlEast (tk_Shower_FuzzyShower_ControlEast);
            cps_setShower_FuzzyShower_TimeText (tk_Shower_FuzzyShower_TimeText);
            cps_setShower_FuzzyShower_ColdValveMessage (tk_Shower_FuzzyShower_ColdValveMessage);
            cps_setShower_FuzzyShower_ColdValveSlider (t_Shower_FuzzyShower_ColdValveSlider, tk_Shower_FuzzyShower_ColdValveSlider);
            cps_setShower_FuzzyShower_ColdTempMessage (tk_Shower_FuzzyShower_ColdTempMessage);
            cps_setShower_FuzzyShower_ColdTempSlider (t_Shower_FuzzyShower_ColdTempSlider, tk_Shower_FuzzyShower_ColdTempSlider);
            cps_setShower_FuzzyShower_ShowerPipingCanvas (tk_Shower_FuzzyShower_ShowerPipingCanvas);
            cps_setShower_FuzzyShower_ControlSouth (tk_Shower_FuzzyShower_ControlSouth);
            cps_setShower_FuzzyShower_HotPressureMessage (tk_Shower_FuzzyShower_HotPressureMessage);
            cps_setShower_FuzzyShower_ColdPressureMessage (tk_Shower_FuzzyShower_ColdPressureMessage);
            cps_setShower_FuzzyShower_HotPressureGuage (tk_Shower_FuzzyShower_HotPressureGuage);
            cps_setShower_FuzzyShower_ColdPressureGuage (tk_Shower_FuzzyShower_ColdPressureGuage);
            cps_setShower_FuzzyShower_controls1 (tk_Shower_FuzzyShower_controls1);
            cps_setShower_FuzzyShower_RealTimeScaleButton (tk_Shower_FuzzyShower_RealTimeScaleButton);
            cps_setShower_FuzzyShower_LogFileButton (tk_Shower_FuzzyShower_LogFileButton);
            cps_setShower_FuzzyShower_ChangePressureButton (tk_Shower_FuzzyShower_ChangePressureButton);
            cps_setShower_StartLoggingPopupWindow (t_Shower_StartLoggingPopupWindow, tk_Shower_StartLoggingPopupWindow);
            cps_setShower_StartLoggingPopupWindow_controls2 (tk_Shower_StartLoggingPopupWindow_controls2);
            cps_setShower_StartLoggingPopupWindow_StartLogDirTextfield (tk_Shower_StartLoggingPopupWindow_StartLogDirTextfield);
            cps_setShower_StartLoggingPopupWindow_StartLogFileTextfield (t_Shower_StartLoggingPopupWindow_StartLogFileTextfield, tk_Shower_StartLoggingPopupWindow_StartLogFileTextfield);
            cps_setShower_StartLoggingPopupWindow_StartLoggingButton (tk_Shower_StartLoggingPopupWindow_StartLoggingButton);
	    break;

    }
}

