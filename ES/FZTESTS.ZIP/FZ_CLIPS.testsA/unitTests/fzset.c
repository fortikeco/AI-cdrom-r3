/*
    Create some random fuzzy sets (A and B) and perform the funion and maxmin
    calulations on them. Display these sets A and B and theit intersection
    and max of min level on a graph using 'xvgr' graphics package.

    To use xvgr we just pipe the output of this to xvgr.

        eg.     fzset | xvgr -p fzset.par -pipe

                then type CR to advance to another test
                and type ^C to quit when you've seen enough


    Will ask for a linefeed between each A, B pair created to allow inspection
    of the sets

*/
#include <stdio.h>
#include <math.h>

#define MAX 15

#include "constant.h"
#include "setup.h"

#include <stdlib.h>
#include "memory.h"
#include "clipsmem.h"

#include "fuzzyval.h"
#include "fuzzyutl.h"
#include <values.h>



double FuzzyFloatPrecision;
int    FuzzyInferenceType;


double drandom()
{
  long l;

  l = random();
  return( (double)l/(double)MAXLONG );
}


main(argc, argv)
    int argc;
    char **argv;
{
    int i, j, n1, n2;
    double Ax[MAX], Ay[MAX], Bx[MAX], By[MAX];
    struct fuzzy_value A, B;
    struct fuzzy_value *ABunionPtr, *ABintersectPtr;
    double maxOfMins;

    InitializeMemory(); 
  

    A.x = Ax; A.y = Ay; A.maxn = MAX; A.n = 0;
    B.x = Bx; B.y = By; B.maxn = MAX; B.n = 0;

    srandom(25863);

    j = 1;

    while (1)
      {
         /* create set A and set B  */
         n1 = (random() % (MAX-2)) + 1;
         n2 = (random() % (MAX-2)) + 1;
         A.n = n1 + 2;  /* 2 extra for the start and end points */
         B.n = n2 + 2;

         A.x[0] = 0.0;
         A.y[0] = drandom();

         for (i=1; i < A.n-1; i++) /* set A */
           {
              A.y[i] = drandom();

              A.x[i] = A.x[i-1] + drandom()*(1.0-A.x[0])/(A.n-1);
              if (A.x[i] == A.x[i-1] && A.y[i] == A.y[i-1])
                 i--;
              else if (A.x[i] == A.x[i-1])
                if (i > 2 && A.x[i] == A.x[i-2] && A.x[i] == A.x[i-3])
		  { A.x[i-1] = A.x[i];
                    i--;
                  }
           }

         if (A.x[A.n-2] < 1.0)
             A.x[A.n-1] = 1.0;
         else
             A.x[A.n-1] = 1.01;
         A.y[A.n-1] = A.y[A.n-2];
       
         B.x[0] = 0.0;
         B.y[0] = drandom();

         for (i=1; i < B.n-1; i++) /* set B */
           {
              B.y[i] = drandom();

              B.x[i] = B.x[i-1] + drandom()*(1.0-B.x[0])/(B.n-1);
              if (B.x[i] == B.x[i-1]  && B.y[i] == B.y[i-1])
                 i--;
              else if (B.x[i] == B.x[i-1])
                if (i > 2 && B.x[i] == B.x[i-2] && B.x[i] == B.x[i-3])
		  { B.x[i-1] = B.x[i];
                    i--;
                  }
            }

         if (B.x[B.n-2] < 1.0)
             B.x[B.n-1] = 1.0;
         else
             B.x[B.n-1] = 1.01;
         B.y[B.n-1] = B.y[B.n-2];

          /* Calc max of mins and create the funion of the sets A and B */
          maxOfMins = max_of_min(&A, &B);
          ABunionPtr = funion(&A, &B);
          ABintersectPtr = fintersect(&A, &B);

          /* Write out the sets A, B, the union, the intersection
             and also show max of mins level 
          */
          printf("@with g0\n");
          printf("@s0 COLOR 5\n"); /* yellow */
          printf("@s0 linewidth 8\n");

          for (i=0; i<A.n; i++)
            { 
               printf("%lf %lf\n", A.x[i], A.y[i]);
            }
          printf("&\n");
          printf("@s1 COLOR 9\n"); /* light blue */
          printf("@s1 linewidth 8\n");

          for (i=0; i<B.n; i++)
            { 
               printf("%lf %lf\n", B.x[i], B.y[i]);
            }
          printf("&\n");
          printf("@s2 COLOR 4\n"); /* blue */
          printf("@s2 linewidth 3\n");

          printf("%lf %lf\n", 0.0, ABunionPtr->y[0]);
          for (i=0; i < ABunionPtr->n; i++)
            { 
               printf("%lf %lf\n", ABunionPtr->x[i], ABunionPtr->y[i]);
            }
          printf("%lf %lf\n", 1.0, ABunionPtr->y[(ABunionPtr->n)-1]);
          printf("&\n");
          printf("@s3 COLOR 2\n"); /* red */

          printf("%lf %lf\n", 0.0, ABintersectPtr->y[0]);
          for (i=0; i < ABintersectPtr->n; i++)
            { 
               printf("%lf %lf\n", ABintersectPtr->x[i], ABintersectPtr->y[i]);
            }
          printf("%lf %lf\n", 1.0, ABintersectPtr->y[(ABintersectPtr->n)-1]);
          printf("&\n");
          printf("@s4 COLOR 2\n"); /* red */

          printf("%lf %lf\n%lf %lf\n", 0.0, maxOfMins, 1.0, maxOfMins);
          printf("&\n");

          printf("@subtitle \"Test # %d\"\n", j);

          printf("@redraw\n");
	  fflush(stdout);
/*          printf("@sleep 3\n");*/
          getchar(); /* pause between sets */
	  printf("@kill s0\n@kill s1\n@kill s2\n@kill s3\n@kill s4\n");

          /* cleanup */
          FrtnArray(ABunionPtr->x, ABunionPtr->n);
          FrtnArray(ABunionPtr->y, ABunionPtr->n);
	  rtn_struct(fuzzy_value, ABunionPtr);
          FrtnArray(ABintersectPtr->x, ABintersectPtr->n);
          FrtnArray(ABintersectPtr->y, ABintersectPtr->n);
	  rtn_struct(fuzzy_value, ABintersectPtr);
          j++;
      }
}


/* routines below needed for funion and max_of_mins */


char    *WERROR = "";

VOID    PrintFactWithIdentifier(c, f)
  char *c;
  struct fact *f;
{}



VOID   DeinstallFuzzyValue(fv)
  VOID *fv;
{}

 
struct PartialMatch  * GlobalLHSBinds = NULL;

VOID   rtnFuzzyValue(fv)
  struct fuzzy_value *fv;
{}



VOID   printCF(c, cf)
  char *c;
  double cf;
{}


VOID   ExitCLIPS(i)
  int i;
{}


int   ArgTypeCheck(c, i, j, o)
  char *c;
  int i, j;
  struct dataObject *o;
{}


char  * WTRACE  = "";


VOID   CLIPSSystemError(c, i)
  char *c;
  int i;
{}


VOID   PrintFloat(c, f)
  char *c;
  double f;
{}


VOID   *AddFuzzyValue(fv)
  struct fuzzy_value *fv;
{}


int   PrintCLIPS(c1, c2)
  char *c1, *c2;
{}


struct defrule   *ExecutingRule  = NULL;


VOID   *AddSymbol(c)
  char *c;
{}



VOID   InstallFuzzyValue(fv)
   VOID *fv;
{}



VOID   PeriodicCleanup(b1, b2)
  BOOLEAN b1, b2;
{}


char    *WDIALOG  = NULL;


VOID   PrintErrorID(c, i1, i2)
  char *c;
  int i1, i2;
{}


struct fuzzy_value   *Get_S_Z_or_PI_FuzzyValue(a,b,c,d)
  double a,b,c;
  int d;
{}


struct entityRecord    *PrimitivesArray[1];
 
struct expr   *Function0Parse(c)
  char *c;
{}


struct expr   *Function1Parse(c)
  char *c;
{}


int   EvaluateExpression(a, b)
  struct expr *a;
  struct dataObject *b;
{}

BOOLEAN   GetStaticConstraintChecking()
{}


VOID   SavePPBuffer(c)
  char *c;
{}


struct expr   *CurrentExpression = NULL;


VOID   *AddLong (i)
  long int i;
{}


VOID   *AddDouble(d)
  double d;
{}


VOID   ReturnExpression(e)
  struct expr *e;
{}


VOID   GetToken(c, t)
  char *c;
  struct token *t;
{}


struct expr   *GenConstant(i, p)
  int i;
  VOID *p;
{}

VOID   SyntaxErrorMessage(c)
  char *c;
{}

globle VOID PPBackup()
  {
  }



globle VOID SetFactListChanged(i)
   int i;
  {
  }

globle VOID executeModifyFunction()
  {
  }

globle struct modifierListItem *FindModifier(name)
   VOID *name;
{
}


