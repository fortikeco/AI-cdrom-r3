
#include <stdio.h>
#include <math.h>
#include "setup.h"
#include "constant.h"

#include <stdlib.h>
#include "memory.h" 
#include "clipsmem.h"
#include "fuzzyval.h"
#include "fuzzyutl.h"



double FuzzyFloatPrecision;
int    FuzzyInferenceType;


char    *WERROR = "";

VOID    PrintFactWithIdentifier(c, f)
  char *c;
  struct fact *f;
{}





VOID   DeinstallFuzzyValue(fv)
  VOID *fv;
{}

 
struct PartialMatch  * GlobalLHSBinds = NULL;

VOID   rtnFuzzyValue(fv)
  struct fuzzy_value *fv;
{}



VOID   printCF(c, cf)
  char *c;
  double cf;
{}


VOID   ExitCLIPS(i)
  int i;
{}


int   ArgTypeCheck(c, i, j, o)
  char *c;
  int i, j;
  struct dataObject *o;
{}


char  * WTRACE  = "";


VOID   CLIPSSystemError(c, i)
  char *c;
  int i;
{}


VOID   PrintFloat(c, f)
  char *c;
  double f;
{}


VOID   *AddFuzzyValue(fv)
  struct fuzzy_value *fv;
{}


int   PrintCLIPS(c1, c2)
  char *c1, *c2;
{}


struct defrule   *ExecutingRule  = NULL;


VOID   *AddSymbol(c)
  char *c;
{}



VOID   InstallFuzzyValue(fv)
   VOID *fv;
{}



VOID   PeriodicCleanup(b1, b2)
  BOOLEAN b1, b2;
{}


char    *WDIALOG  = NULL;


VOID   PrintErrorID(c, i1, i2)
  char *c;
  int i1, i2;
{}


struct fuzzy_value   *Get_S_Z_or_PI_FuzzyValue(a,b,c,d)
  double a,b,c;
  int d;
{}


struct entityRecord    *PrimitivesArray[1];
 
struct expr   *Function0Parse(c)
  char *c;
{}


struct expr   *Function1Parse(c)
  char *c;
{}


int   EvaluateExpression(a, b)
  struct expr *a;
  struct dataObject *b;
{}

BOOLEAN   GetStaticConstraintChecking()
{}


VOID   SavePPBuffer(c)
  char *c;
{}


struct expr   *CurrentExpression = NULL;


VOID   *AddLong (i)
  long int i;
{}


VOID   *AddDouble(d)
  double d;
{}


VOID   ReturnExpression(e)
  struct expr *e;
{}


VOID   GetToken(c, t)
  char *c;
  struct token *t;
{}


struct expr   *GenConstant(i, p)
  int i;
  VOID *p;
{}

VOID   SyntaxErrorMessage(c)
  char *c;
{}

globle VOID PPBackup()
  {
  }


globle VOID SetFactListChanged(i)
   int i;
  {
  }

globle VOID executeModifyFunction()
  {
  }

globle struct modifierListItem *FindModifier(name)
   VOID *name;
{
}




main()
{
double *Ax, *Ay;
int Alen;
double *Bx, *By;
int Blen;
char rcd[500];  /* max record length in test data file */
int i, npoints;
char *p;
char sep[3];
FILE *testdata, *output;

remove("MaxMin.out");

output = fopen("MaxMin.out","a");

if ((testdata = fopen("fuzzytst.dat","r")) == NULL)
  {
   printf("\n\n*** ERROR cannot open test data file.\n\n");
   exit(0);
  }

while (fgets(rcd, 500, testdata) != NULL)
  {

   /* If the start of a test. */

   if (!strncmp(rcd, "Test", 4))
     {
      fputs(rcd, output);
      printf("%s\n",rcd);  /* the test name */
      fgets(rcd, 500, testdata);  /* 1st data set consists of x,y pairs as
                                     type double and seperated with a space. */

      /* Calculate the number of points = #spaces + 1 / 2.
         Allocate space for 2 arrays of type double and length npoints.
      */

      npoints = i = 0;
      while (rcd[i] != '\0')
        {
         if (rcd[i] == ' ')
           npoints++;
         i++;
        }
      Alen = (npoints + 1)/2;
      Ax = (double *) malloc (Alen * sizeof(double)); /* 1st data set x-coord */
      Ay = (double *) malloc (Alen * sizeof(double)); /* 1st data set y-coord */

      strcpy(sep," ");
      i = 1;
      *Ax = atof(strtok(rcd, sep));
      Ax++;
      i++;
      while ((p = strtok(NULL, sep)) != NULL)
        {
         if (fmod((double)i,2.0) == 0.0) /* even numbered elements go into Ay */
           {
            *Ay = atof(p);
            i++;
            Ay++;
           }
         else     /* odd numbered elements go into Ax */
           {
            *Ax = atof(p);
            i++;
            Ax++;
           }
        }

      /* Move Ax and Ay to point at beginning of arrays */
      for (i=0; i<Alen; i++)
        {
         Ax--;
         Ay--;
        }

      fgets(rcd, 500, testdata);  /* 2st data set consists of x,y pairs as
                                     type double and seperated with a space. */

      /* Calculate the number of points = #spaces + 1 / 2.
         Allocate space for 2 arrays of type double and length npoints.
      */

      npoints = i = 0;
      while (rcd[i] != '\0')
        {
         if (rcd[i] == ' ')
           npoints++;
         i++;
        }
      Blen = (npoints + 1)/2;
      Bx = (double *) malloc (Blen * sizeof(double)); /* 1st data set x-coord */
      By = (double *) malloc (Blen * sizeof(double)); /* 1st data set y-coord */

      strcpy(sep," ");
      i = 1;
      *Bx = atof(strtok(rcd, sep));
      Bx++;
      i++;
      while ((p = strtok(NULL, sep)) != NULL)
        {
         if (fmod((double)i,2.0) == 0.0) /* even numbered elements go into By */
           {
            *By = atof(p);
            i++;
            By++;
           }
         else     /* odd numbered elements go into Bx */
           {
            *Bx = atof(p);
            i++;
            Bx++;
           }
        }

      /* Move Bx and By to point at beginning of arrays */
      for (i=0; i<Blen; i++)
        {
         Bx--;
         By--;
        }
      MaxMinUnion(Ax, Ay, Alen, Bx, By, Blen, output);


      /* do again interchanging A and B sets */

      fprintf(output, "****Reverse Data Sets****\n");

      MaxMinUnion(Bx, By, Blen, Ax, Ay, Alen, output);
      free(Ax);
      free(Ay);
      free(Bx);
      free(By);
     }
  }
fclose(output);

printf("\nComparing Results ...\n");
compare_results();
printf("Comparison done\n");
}



MaxMinUnion(Ax, Ay, Alen, Bx, By, Blen, outfile)
double *Ax;
double *Ay;
int Alen;
double *Bx;
double *By;
int Blen;
FILE *outfile;
{
  int i;
  struct fuzzy_value fv1, fv2;
  struct fuzzy_value *fvptr;
  
  double maxmin;
  
  InitializeMemory();

  fv1.maxn = Alen;
  fv1.n = Alen;
  fv1.name = NULL;
  fv1.x = Ax;
  fv1.y = Ay;
  
  fv2.maxn = Blen;
  fv2.n = Blen;
  fv2.name = NULL;
  fv2.x = Bx;
  fv2.y = By;

  maxmin = max_of_min(&fv1, &fv2);

  fprintf(outfile,"MaxMin is:\n%.16f\n",maxmin);

  fvptr = funion(&fv1, &fv2);
  
  
  fprintf(outfile,"Union is:\n");
  for (i=0; i<fvptr->n; i++)
     fprintf(outfile,"%.16f, %.16f\n", fvptr->x[i], fvptr->y[i]);

/*  FrtnArray(fvptr->x);
  FrtnArray(fvptr->y);
  rtn_struct(fuzzy_value, fvptr);
*/
  fflush(outfile);

  fvptr = fintersect(&fv1, &fv2);
  
  
  fprintf(outfile,"Intersection is:\n");
  for (i=0; i<fvptr->n; i++)
     fprintf(outfile,"%.16f, %.16f\n", fvptr->x[i], fvptr->y[i]);

  FrtnArray(fvptr->x);
  FrtnArray(fvptr->y);
  rtn_struct(fuzzy_value, fvptr);

}



/* Compare MaxMin.exp with MaxMin.out record by record.
   If there are any differences detected during a test,
   write the differences to MaxMin.rsl. If there are no
   differences, write "No differences." in MaxMin.rsl.
*/

compare_results()
{
int error = FALSE;
char testnum[50];
char expbuff[100], outbuff[100];
FILE *expect, *outfile, *result;

remove("MaxMin.rsl");

if ((expect = fopen("MaxMin.exp","r")) == NULL)
  {
   printf("***WARNING -- file MaxMin.exp was not found.\n");
   return;
  }

outfile = fopen("MaxMin.out","r");

while (fgets(outbuff, 100, outfile) != NULL)
  {
   if (!strncmp(outbuff, "Test", 4))
     {
      strcpy(testnum, outbuff);
      fgets(expbuff, 100, expect);
     }
   else
     {
      fgets(expbuff, 100, expect);
      if (strcmp(outbuff, expbuff))
        {
         error = TRUE;
         result = fopen("MaxMin.rsl","a");
         fputs(testnum, result);
         fputs(outbuff, result);
         fclose(result);
        }
     }
  }
fclose(expect);
fclose(outfile);
if (!error)
  {
   result = fopen("MaxMin.rsl","w");
   fprintf(result, "There were no differences. ");
   fclose(result);
  }
}


