# include <stdio.h>
# include <curses.h>
# define NIL (struct ob *)(0)
# define MAX_STRING_LENGTH 132
# define MAX_RECURSION 10
# define max(a,b)    ((a>b)?a:b)

struct attribute
  {
  char *name;                                   /*The name of this attribute*/
  char *prompt;                                 /*User supplied prompt*/
  int value;                                    /*Its current value (0,1,-1)*/
  struct attribute *next;
  } at;
struct object
  {
  char *name;                                   /*Object name*/
  char *eqn;                                    /*Expression for when its true*/
  int value;                                    /*Current value*/
  struct object *next;
  } ob;
struct rejected
  {
  char *name;                                   /*Object name*/
  char *attrib;                                 /*Attribute that made it false*/
  int condition;                      /*Value of the object that made it false*/
  struct rejected *next;
  } rj;
struct rejected *rejects = NIL, *r;
struct object *objs = NIL, *t, *obj[MAX_RECURSION + 2], *oo;
struct attribute *ats = NIL, *a;
char token[MAX_STRING_LENGTH];
char *p_pos[MAX_RECURSION + 2];
WINDOW *cmdwin, *qwin, *answin;
char c;
char fn[80];
char line[MAX_STRING_LENGTH];
FILE *fp, *ofp;
int recur_depth = 0;
int i, j, k;

/* Three routines here, each one just allocates a chunk of memory
   appropriate for one type of structure, and returns with a
   pointer to it.
*/
/* Allocate an attrribute record*/
struct attribute *get_at()
  {
    return ((struct attribute *)malloc(sizeof (at)));
  }

  
/*allocate space for an object*/
struct object *get_ob()
  {
    return ((struct object *)malloc(sizeof (ob)));
  }

  
/*allcate space for a reject */
struct rejected *get_rj()
  {
    return ((struct rejected *)malloc(sizeof (rj)));
  }

  
/*The next three routines add records to the end of their
  appointed lists.
*/
/*Add the structure pointed to by att to the attribute list*/
void add_att(att)
struct attribute *att;
  {
    struct attribute *a;

    a = ats;

    if (a == NIL)
      {
	ats = att;
      }
    else
      {
	while (a -> next != NIL)
	  {
	    a = a -> next;
	  }

	a -> next = att;
      }
  }

  
/*Add the structure pointed to by r to the rejected list*/
void add_rj(r)
struct rejected *r;
  {
    struct attribute *r2;

    r2 = rejects;

    if (r2 == NIL)
      {
	rejects = r;
      }
    else
      {
	while (r2 -> next != NIL)
	  {
	    r2 = r2 -> next;
	  }

	r2 -> next = r;
      }
  }

  
/*Add the structure pointed to by obj to the object list*/
void add_ob(obj)
struct object *obj;
  {
    struct object *o;

    o = objs;

    if (o == NIL)
      {
	objs = obj;
      }
    else
      {
	while (o -> next != NIL)
	  {
	    o = o -> next;
	  }

	o -> next = obj;
      }
  }

  
/* Clear all the linked lists and deallocate all of allocated memory.
   It's a  pretty basic algorithm, just traverse the list and
   free the memory as yo go, then set the head pointers to NIL.
*/
clear_kbase()
  {
    struct object *ob1, *ob2;
    struct attribute *at1, *at2;
    struct rejected *rj1, *rj2;

    ob1 = objs;                                 /*Objects disappear first*/

    while (ob1 != NIL)
      {
	ob2 = ob1;
	ob1 = ob1 -> next;
	cfree(ob2 -> name);                     /*along with their strings*/
	cfree(ob2 -> eqn);
	free(ob2);
      }

    rj1 = rejects;                              /*Then rejects*/

    while (rj1 != NIL)
      {
	rj2 = rj1;
	rj1 = rj1 -> next;
	cfree(rj2 -> name);
	cfree(rj2 -> attrib);
	free(rj2);
      }

    at1 = ats;                                  /*Then attributes*/

    while (at1 != NIL)
      {
	at2 = at1;
	at1 = at1 -> next;
	cfree(at2 -> name);
	cfree(at2 -> prompt);
	free(at2);
      }

    ats = NIL;
    objs = NIL;
    rejects = NIL;
  }

  
/*Prompt the user for the rules file to use, then read it into
  memory.

  The file should be in this format:

      Attributes are defined by a line beginning with 'att' or 'attribute',
      an attribute name an equals sign, a quotation mark, a prompt string to
      use to ask if the attribute is true or not, and another quote.

      ex.    

      attribute works = "Does it work? "

      Objects are defined by the 'obj' or 'object' beginning a new line, a name,
      an equals, a parenthesis, a boolean equation of attributes, another parenthesis,
      a semicolon, a quote, some amount of text to display when the object is true,
      and another quote.  The text can be of arbitrary length since only the name and
      equation are stored in memory.

      ex.

      object passes = (works & runs & (~crashes)); "It works ok."

      See the equation parser for more info on the format of the equations.
      WHITESPACE is SKIPPED, and objects and attributes can be interspersed in the
      file in any order you wish.

      For efficiency reasons, it is suggested that objects with similiar attributes
      be grouped together, and those objects and attributes which occur most often
      appear closest to the top of the file.  But, there is nothing to enforce this.

*/
init()
  {
    char line[MAX_STRING_LENGTH];

    printf("Rule file: ");
    gets(fn);
    clear_kbase();
    fp = fopen(fn, "r");

    if ( ! fp)
      {
	printf("Can't open file:");
	printf(" %s\n", fn);
      }
    else
      {
	while ( ! feof(fp))
	  {
	    c = getc(fp);

	    if (tolower(c) == 'a')
	      {
		while (c != ' ')
		  {
		    c = getc(fp);
		  }

		while (c == ' ')
		  {
		    c = getc(fp);
		  }

		a = get_at();
		i = 0;
		line[i++] = c;

		while ((c != ' ') && (c != '='))
		  {
		    line[i++] = c = getc(fp);
		  }

		line[--i] = '\0';
		a -> name = (char *)(calloc((strlen(line) + 1), (sizeof (char))));
		strcpy(a -> name, line);

		while (c != 34)
		  c = getc(fp);

		i = 0;
		c = getc(fp);

		if (c != 34)
		  line[i++] = c;

		while (c != 34)
		  {
		    line[i++] = c = getc(fp);
		  }

		line[--i] = '\0';
		a -> prompt = (char *)(calloc((strlen(line) + 1), (sizeof (char))));
		strcpy(a -> prompt, line);

		while (c != '\n')
		  c = getc(fp);

		a -> value = -1;
		a -> next = NIL;
		add_att(a);
	      }
	    else
	      {
		if (tolower(c) == 'o')
		  {
		    while (c != ' ')
		      {
			c = getc(fp);
		      }

		    while (c == ' ')
		      {
			c = getc(fp);
		      }

		    t = get_ob();
		    i = 0;
		    line[i++] = c;

		    while ((c != ' ') && (c != '='))
		      {
			line[i++] = c = getc(fp);
		      }

		    line[--i] = '\0';
		    t -> name = (char *)(calloc((strlen(line) + 1), (sizeof (char))));
		    strcpy(t -> name, line);

		    while (c != '(')
		      c = getc(fp);

		    i = 0;
		    line[i++] = c;
		    c = getc(fp);

		    if (c != ')')
		      line[i++] = c;
		    else
		      {
			printf("Null equation.\n");
		      }

		    while (c != ';')
		      {
			line[i++] = c = getc(fp);
		      }

		    line[--i] = '\0';
		    t -> eqn = (char *)(calloc((strlen(line) + 1), (sizeof (char))));
		    strcpy(t -> eqn, line);
		    t -> next = NIL;
		    t -> value = -1;
		    add_ob(t);

		    while (c != 34)
		      c = getc(fp);

		    c = getc(fp);

		    while ((c != 34) && ( ! feof(fp)))
		      c = getc(fp);

		    while ((c != '\n') && ( ! feof(fp)))
		      c = getc(fp);
		  }
		else
		  {
		    if ((c != '\n') && ( ! feof(fp)))
		      {
			printf("syntax error\n");
			break;
		      }
		  }
	      }
	  }

	fclose(fp);
      }

    /*    a = ats;

    while (a != NIL)
      {
	printf("Attribute: %s\n", a -> name);
	printf("Prompt   : %s\n", a -> prompt);
	a = a -> next;
      }

    printf("\n\n\n");
    t = objs;

    while (t != NIL)
      {
	printf("Object    : %s\n", t -> name);
	printf("Equation  : %s\n", t -> eqn);
	t = t -> next;
      }*/
  }

  
/*This routine is used when an object is known to be true.  We go out to the file,
  find the object with the same name as this one and print out whatever the text
  field is to the user's screen.  Formatting and such are expected to be done by
  the user.
*/
print_text(obj)
struct object *obj;
  {
    int x, y;

    fp = fopen(fn, "r");

    if ( ! fp)
      {
	{
	  printf("Can't open file: %s\n", fn);
	}
      }
    else
      {
	while (( ! feof(fp)) && (strcmp(token, obj -> name)))
	  {
	    c = getc(fp);

	    if (tolower(c) == 'o')
	      {
		c = getc(fp);

		if (tolower(c) == 'b')
		  {
		    c = getc(fp);

		    if (tolower(c) == 'j')
		      {
			while (c != ' ')
			  {
			    c = getc(fp);
			  }

			while (c == ' ')
			  {
			    c = getc(fp);
			  }

			i = 0;
			token[i++] = c;

			while ((c != ' ') && (c != '='))
			  {
			    token[i++] = c = getc(fp);
			  }

			token[--i] = '\0';

			while (c != ';')
			  {
			    c = getc(fp);
			  }

			while (c != 34)
			  c = getc(fp);

			c = getc(fp);

			if (strcmp(token, obj -> name))
			  {
			    while ((c != 34) && ( ! feof(fp)))
			      {
				c = getc(fp);
			      }

			    while ((c != '\n') && ( ! feof(fp)))
			      c = getc(fp);
			  }
			else
			  {
			    while ((c != 34) && ( ! feof(fp)))
			      {
				putc(c, ofp);
				c = getc(fp);
			      }
			  }
		      }
		  }
	      }
	  }
      }

    fclose(fp);
  }

  
void print_report()
  {
    struct object *ob;
    struct attribute *at;
    char c, ofn[80];

    printf("Report file: ");
    gets(ofn);
    ofp = fopen(ofn, "w+");
    printf("Header line: ");
    gets(ofn);
    fprintf(ofp, " ++++++ %s ++++++\n\n\n", ofn);
    fprintf(ofp, "Known Attributes: \n\n");
    at = ats;

    while (at -> next != NIL)
      {
	if (at -> value > -1)
	  {
	    fprintf(ofp, "   Atribute %s (\"%s\") is %s.\n", at -> name, at -> prompt, ((at -> value == 0) ? "False" : "True"));
	  }

	at = at -> next;
      }

    if (at -> value > -1)
      {
	fprintf(ofp, "   Atribute %s (\"%s\") is %s.\n", at -> name, at -> prompt, ((at -> value == 0) ? "False" : "True"));
      }

    fprintf(ofp, "\n\n\nKnown True Objects :\n\n");
    ob = objs;

    while (ob -> next != NIL)
      {
	if (ob -> value == 1)
	  {
	    fprintf(ofp, "Object %s [%s] is True.  Conclusions: \n", ob -> name, ob -> eqn);
	    print_text(ob);
	    fprintf(ofp, "\n\n");
	  }

	ob = ob -> next;
      }

    if (ob -> value == 1)
      {
	fprintf(ofp, "Object %s [%s] is True.  Conclusions: \n", ob -> name, ob -> eqn);
	print_text(ob);
      }

    fprintf(ofp, "\014");
    fclose(ofp);
  }

  
/*
   Use the prompt the user gave us for this attribute to ask him if
   the attribute is true or not.  Set the attribute's value
   field appropriately.

   Expected responses are 'y' or 't' for true
                          'n' or 'f' for false
                          'w'        for why
*/
prompt(at)
struct attribute *at;
  {
    char ans[80];

    *ans = 'q';

    while ( ! (is_in(tolower(*ans), "yntf")))
      {
	printf("%s", at -> prompt);
	gets(ans);

	if ((tolower(*ans) == 'y') || (tolower(*ans) == 't'))
	  at -> value = 1;
	else
	  if ((tolower(*ans) == 'n') || (tolower(*ans) == 'f'))
	    at -> value = 0;
	  else
	    if (tolower(*ans) == 'w')
	      reason();
      }
  }

  
/* 
   Prompt the user for each attribute in the equation for this object
   until we have enough to give the object a definite value.

   Take special note of how if we don't find the attribute they want on the
   attribute list, we will try searching the object list, and then will
   prompt for that new object as necessary.  This object list search,
   however, introduces the possibility of recursive definitions that may
   never end  (ex. a=(b), b=(a) if both are unknown).  We handle that by
   using recur_depth to tell how far down we've gone and MAX_RECURSION to
   make sure things don't get out of hand.

   If we find out that the object is false, add it to the reject list.
   We tell when we have enough by calling the parser routines to give us
   a value for this object's equation and just noticing when it stops being        
   -1 (our value for "I don't know")
*/
query(ob)
struct object *ob;
  {
    char *id;
    struct rejected *r;
    struct object *o;

    if (recur_depth >= MAX_RECURSION)
      return;

    p_pos[recur_depth] = obj[recur_depth] -> eqn;

    if (obj[recur_depth] != NIL)
      while (obj[recur_depth] -> value == -1)
	{
	  get_token();

	  while (is_in(*token, "()&|~"))
	    get_token();

	  id = p_pos[recur_depth];
	  a = ats;

	  while (strcmp(a -> name, token))
	    {
	      a = a -> next;

	      if (a == NIL)
		break;
	    }

	  if (a == NIL)
	    {
	      o = objs;

	      while (strcmp(o -> name, token))
		{
		  o = o -> next;

		  if (o == NIL)
		    break;
		}

	      if (o == NIL)
		{
		  if ( strlen(token) )
		    printf("Undefined attribute: %s\n", token);

		  return;
		}
	      else
		{
		  if ((o -> value == -1) && (recur_depth < MAX_RECURSION))
		    {
		      recur_depth++;
		      obj[recur_depth] = o;
		      oo = o;
		      p_pos[recur_depth] = o -> eqn;
		      get_token();

		      while (is_in(*token, "()&|~"))
			get_token();

		      analyse(&(o -> value));

		      if (o -> value == -1)
			{
			  query(o);
			}

		      obj[recur_depth] = NIL;
		      recur_depth--;
		    }
		  else
		    return;
		}
	    }
	  else
	    {
	      if (a -> value == -1)
		{
		  prompt(a);
		  analyse(&(obj[recur_depth] -> value));

		  if (obj[recur_depth] -> value == 0)
		    {
		      r = get_rj();
		      r -> name = (char *)(calloc((strlen(obj[recur_depth] -> name) + 1), (sizeof (char))));
		      strcpy(r -> name, obj[recur_depth] -> name);
		      r -> attrib = (char *)(calloc((strlen(a -> prompt) + 1), (sizeof (char))));
		      strcpy(r -> attrib, a -> prompt);
		      r -> condition = a -> value;
		      r -> next = NIL;
		      add_rj(r);
		    }

		  p_pos[recur_depth] = id;
		}
	    }
	}
  }

  
/*
   Tell the user what object we are working on
   and give him a display of the rejected list
*/
reason()
  {
    struct rejected *rej;
    int i;

    rej = rejects;
    printf("\n  Working on: %s\n\n", obj[recur_depth] -> name);

    for (i = recur_depth - 1; i >= 0; i--)
      {
	printf("  %s is a required for %s.\n", obj[i] -> name, obj[i + 1] -> name);
      }

    printf("\n  %s is a required attribute.\n", a -> name);

    if (rej != NIL)
      {
	while (rej -> next != NIL)
	  {
	    printf("  %s rejected because \"%s\" is %s.\n", rej -> name, rej -> attrib,
		(rej -> condition ? ((rej -> condition == 1) ? "TRUE" : "UNDECIDABLE") : "FALSE"));
	    rej = rej -> next;
	  }

	printf("  %s rejected because \"%s\" is %s.\n", rej -> name, rej -> attrib,
	    (rej -> condition ? ((rej -> condition == 1) ? "TRUE" : "UNDECIDABLE") : "FALSE"));
      }
  }

  
/* Start of recursive descent parser

   The next four routines parse and evaluate the boolean expression
   in obj->eqn.  The grammar which they parse (notice how nicely
   production rules match routine names) is:

          exprs -> term [ | term]
          term  -> factor [ & factor]
          factor -> primitive [(exprs)] [~factor]
          primitive -> ['A'..'Z','a'..'z','0'..'9','_',...] (anything but spaces)

  
  ~ takes precedence over & and |
  & takes precedence over |
  operators of equivalent precedence are left associative

  except where overridden by parenthesis

*/
analyse(result)
int *result;
  {
    p_pos[recur_depth] = obj[recur_depth] -> eqn;
    get_token();

    if ( ! *token)
      {
	serror(2);
	return;
      }

    exprs(result);
  }

  
exprs(result)
int *result;
  {
    register char op;
    int hold;

    term(result);

    while ((op = *token) == '|')
      {
	get_token();
	term(&hold);
	determine(op, result, &hold);
      }
  }

  
term(result)
int *result;
  {
    int hold;
    char op;

    factor(result);

    while ((op = *token) == '&')
      {
	get_token();
	factor(&hold);
	determine(op, result, &hold);
      }
  }

  
factor(result)
int *result;
  {
    register char op;

    op = 0;

    if (*token == '~')
      {
	op = '~';
	get_token();
      }

    level4(result);

    if (op)
      determine(op, result, result);
  }

  
level4(result)
int *result;
  {
    if ((*token == '('))
      {
	get_token();
	exprs(result);

	if (*token != ')')
	  serror(1);

	get_token();
      }
    else
      primitive(result);
  }

  
/*
   Return the value of the attribute whose name is in token
*/
primitive(result)
int *result;
  {
    struct attribute *i;
    struct object *j;                           /* try the attributes first */

    for (i = ats; i != NIL; i = i -> next)
      {
	if ( ! strcmp(i -> name, token))
	  {
	    *result = i -> value;
	    return get_token();
	  }
      }

    /* If we don't find an attribute with this name,
       try the object list*/
    for (j = objs; j != NIL; j = j -> next)
      {
	if ( ! strcmp(j -> name, token))
	  {
	    *result = j -> value;
	    return get_token();
	  }
      }

    serror(0);
  }

  
/* 
   This routine is the guts of the expression parser.
   It does the actual operations and returns the appropriate value
   according to this truth table.

   (remember True = 1, False = 0, Unknown = -1)

        r   h    r&h    r|h    ~r
       ---------------------------
        T   T     T      T      F
        T   F     F      T      F
        F   T     F      T      T
        F   F     F      F      T
        U   T     U      T      U
        U   F     F      U      U
        T   U     U      T      F
        F   U     F      U      T

*/
determine(o, r, h)
char o;                                         /*the operation*/
int *r, *h;                                     /*the operands*/
/* return with *r=result*/
  {
    register int t, ex;

    switch (o)
      {
      case '&':
	if (*r != -1 && *h != -1)
	  {
	    *r = *r && *h;
	    return;
	  }

	if (*r == -1 && *h == 0)
	  *r = 0;
	else
	  if (*r == 0 && *h == -1)
	    *r = 0;
	  else
	    *r = -1;

	break;

      case '|':
	if (*r != -1 && *h != -1)
	  {
	    *r = *r || *h;
	    return;
	  }

	if (*r == 1 || *h == 1)
	  *r = 1;
	else
	  *r = -1;

	break;

      case '~':
	if (*r != -1)
	  *r = ! *r;
	else
	  *r = -1;

	break;
    }
  }

  
/*
   Print error messages for screwed up equations.
     0 = syntax error
     1 = Unbalanced parenthesis
     2 = Null expression
*/
serror(error)
int error;
  {
    static char *e[] = { "Syntax error.", "Unbalanced parenthesis.", "No expression present." };

    printf(line, "\n%s\n", e[error]);
  }

  
/*
  Get the next token.
  It will be one of the operators "()|~&"
  or an attribute name
*/
get_token()
  {
    char *p;

    p = token;

    while (*(p_pos[recur_depth]) == ' ')
      (p_pos[recur_depth])++;

    if (*(p_pos[recur_depth]) == '\0')
      {
	*p++ = '\0';
	return;
      }

    if (is_in(*(p_pos[recur_depth]), "()|&~"))
      {
	*p = *(p_pos[recur_depth]);
	p++;
	(p_pos[recur_depth])++;
	*p = '\0';
	return;
      }

    while (*(p_pos[recur_depth]) != ' ' && ! is_in(*(p_pos[recur_depth]), "()&|~") && *(p_pos[recur_depth]) != '\0')
      {
	*p = *(p_pos[recur_depth])++;
	p++;
      }

    *p = '\0';
  }

  
/* End of recursive descent expression parser */
is_in(c, s)
char c, *s;
  {
    while (*s)
      {
	if (c == *s)
	  return (1);

	s++;
      }

    return (0);
  }

  
/*
   a quick little routine to let to tell if the user wants to
   keep looking for other objects that might be true or not
*/
int goon()
  {
    char ans[80];
    int x, y;

    *ans = 'q';

    while ( ! (is_in(tolower(*ans), "yntf")))
      {
	printf("  Continue? ");
	gets(ans);
      }

    if ((tolower(*ans) == 'y') || (tolower(*ans) == 't'))
      return (1);
    else
      return (0);
  }

  
main()
  {
    int done = 0, f = 0, e = 0, x, y;
    char ans[5];

    while (1)
      {
	*ans = 'z';
	done = 0;

	while ( ! (is_in(tolower(*ans), "lqre")))
	  {
	    printf("Load   Query   Report   Exit: ");
	    gets(ans);
	    *ans = tolower(*ans);
	  }

	done = 0;

	if (tolower(*ans) == 'l')               /*load new knowledge base*/
	  init();
	else
	  if (tolower(*ans) == 'r')             /*Print written report*/
	    print_report();
	  else
	    if (tolower(*ans) == 'e')           /*exit*/
	      return;
	    else
	      if (tolower(*ans) == 'q')         /*query*/
		{
		  if (objs == NIL)
		    {
		      printf("\n  Please load a valid knowledge base.\n");
		    }
		  else
		    {
		      done = 0;
		      obj[recur_depth] = objs;

		      while (obj[recur_depth] != NIL)
			/*init all values to unknown*/
			{
			  obj[recur_depth] -> value = (-1);
			  obj[recur_depth] = obj[recur_depth] -> next;
			}

		      a = ats;

		      while (a != NIL)          /*ditto for attributes*/
			{
			  a -> value = (-1);
			  a = a -> next;
			}

		      if (rejects != NIL)       /*clear the reject list*/
			{
			  register struct rejected *rj1, *rj2;

			  rj1 = rejects;

			  while (rj1 != NIL)
			    {
			      rj2 = rj1;
			      rj1 = rj1 -> next;
			      cfree(rj2 -> name);
			      cfree(rj2 -> attrib);
			      free(rj2);
			    }

			  rejects = NIL;
			}

		      while ( ! done)
			{
			  obj[recur_depth] = objs;
			  f = 0;
			  e = 0;
			  done = 0;

			  while ((obj[recur_depth] -> next != NIL))
			    {
			      if (obj[recur_depth] -> value == 1)
				{
				  printf(" Object '%s' fits current description.\n", obj[recur_depth] -> name);
				  f += 1;
				}

			      if (obj[recur_depth] -> value == -1)
				e++;

			      obj[recur_depth] = obj[recur_depth] -> next;
			    }

			  if (obj[recur_depth] -> value == -1)
			    e++;

			  if ((obj[recur_depth] -> next == NIL) && (obj[recur_depth] -> value == 1))
			    {
			      printf(" Object '%s' fits current description.\n", obj[recur_depth] -> name);
			      f += 1;
			      obj[recur_depth] = NIL;
			    }

			  if (f)
			    {
			      printf("  %d Objects found so far.\n", f);

			      if ( ! goon())
				done = 1;
			    }

			  if (( ! e) && ( ! done))
			    {
			      printf(answin, "  No more objects found.\n");
			      done = 1;
			    }

			  if ( ! done)
			    if (obj[recur_depth] == NIL)
			      {
				done = 1;
			      }
			    else
			      {
				obj[recur_depth] = objs;

				while (obj[recur_depth] -> value > -1)
				  obj[recur_depth] = obj[recur_depth] -> next;
			/*find the first unknown object and*/

				query(obj[recur_depth]);

				/*Prompt the user until we have a definite
                                                                            value for it*/
				obj[recur_depth] = objs;

				while (obj[recur_depth] != NIL)
				  /*reeval the list to include in new info
                                                                            we learned from that last try*/
				  {
				    if (obj[recur_depth] -> value == -1)
				      {
					analyse(&(obj[recur_depth] -> value));

					if (obj[recur_depth] -> value == 0)
					  /*reject any others that became flase
                                                                            while I was working on the last one*/
					  {
					    r = get_rj();
					    r -> name = (char *)(calloc((strlen(obj[recur_depth] -> name) + 1), (sizeof (char))));
					    strcpy(r -> name, obj[recur_depth] -> name);

					    if (a != NIL)
					      {
						r -> attrib = (char *)(calloc((strlen(a -> prompt) + 1), (sizeof (char))));
						strcpy(r -> attrib, a -> prompt);
						r -> condition = a -> value;
					      }
					    else
					      {
						r -> attrib = (char *)(calloc((strlen(oo -> name) + 1), (sizeof (char))));
						strcpy(r -> attrib, oo -> name);
						r -> condition = oo -> value;
					      }

					    r -> next = NIL;
					    add_rj(r);
					  }
				      }

				    obj[recur_depth] = obj[recur_depth] -> next;
				  }
			      }
			}
		    }
		}
      }
  }
