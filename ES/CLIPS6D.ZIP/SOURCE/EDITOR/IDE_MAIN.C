   /*******************************************************/
   /*      "C" Language Integrated Production System      */
   /*                                                     */
   /*                  A Product Of The                   */
   /*             Software Technology Branch              */
   /*             NASA - Johnson Space Center             */
   /*                                                     */
   /*               CLIPS Version 6.00  01/01/93          */
   /*              IDE Text Editor 1.00  01/01/93         */
   /*                                                     */
   /*                    MAIN MODULE                      */
   /*******************************************************/

/**************************************************************/
/* Purpose: For Starting, Maintaining and Stopping a Dymanic  */
/*    Data Exchange (DDE) conversation with a CLIPS Server.   */
/*                                                            */
/* Principal Programmer(s):                                   */
/*      Christopher J. Ortiz                                  */
/*                                                            */
/* Contributing Programmer(s):                                */
/*                                                            */
/* Revision History:                                          */
/**************************************************************/

/*-------------------------------+
| Windows & System Include Files |
+-------------------------------*/
#include <windows.h>
#include <commdlg.h>
#include <io.h>
#include <stdio.h>
#include <string.h>
#include <sys\stat.h>

/*---------------------+
| Editor Include Files |
+---------------------*/
#include "ide_ids.h"
#include "ide_misc.h"
#include "ide_dde.h"
#include "ide_bal.h"
#include "ide_srch.h"

/*-----------------+
| Global Variables |
+-----------------*/

HFONT hFont;          /* Handle to the font */
HANDLE hAccTable;     /* handle to accelerator table */
HWND hwnd;            /* handle to main window */
HWND hEditWnd;        /* handle to edit window */
HANDLE hInst;
HANDLE hHourGlass;    /* handle to hourglass cursor      */
OPENFILENAME ofn;    

char szFileName[MAXFILENAME];
char szFileTitle[MAXFILENAME];

HANDLE hEditBuffer;    /* handle to editing buffer */
int hFile;             /* file handle */
OFSTRUCT OfStruct;     /* information from OpenFile() */
BOOL bChanges = FALSE; /* TRUE if the file is changed */

char szTemp[128];      /* Temp Buffer */

/*----------------+
| Local Functions |
+----------------*/

DoFileMenu (HWND hWnd, WPARAM wParam );
DoEditMenu (HWND hWnd, WPARAM wParam, LPARAM lParam );

/******************************************************************
* WinMain : Calls initialization function & processes the
*   message loop
******************************************************************/

int PASCAL _export WinMain (
   HANDLE hInstance,
   HANDLE hPrevInstance,
   LPSTR  lpCmdLine,
   int    nCmdShow )

{  extern HWND hwnd;
   extern HANDLE hAccTable;
   MSG msg;

   if (!hPrevInstance)
      if (!InitApplication(hInstance))
         return (FALSE);

   if (!InitInstance(hInstance, nCmdShow))
      return (FALSE);

   StartUpDDE( hwnd );

   while (GetMessage(&msg, NULL, NULL, NULL))
   {  if (!TranslateAccelerator(hwnd, hAccTable, &msg))
      {  TranslateMessage(&msg);
         DispatchMessage(&msg); 
      }
   }
   ShutDownDDE ( );
   return (msg.wParam);
}

/******************************************************************
* InitApplication :  Initializes window data and registers
*   the window class    
******************************************************************/

BOOL InitApplication( HANDLE hInstance )

{  WNDCLASS  wc;

   wc.style = NULL;
   wc.lpfnWndProc = MainWndProc;
   wc.cbClsExtra = 0;
   wc.cbWndExtra = 0;
   wc.hInstance = hInstance;
   wc.hIcon =LoadIcon(hInstance, "Clips_Text");
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = COLOR_WINDOW+1;
   wc.lpszMenuName =  "ClipsEditMenu";
   wc.lpszClassName = "ClipsEditWClass";

   return (RegisterClass(&wc));
}


/******************************************************************
* InitInstance :  Saves instance handle and creates the main window
******************************************************************/

BOOL InitInstance (
   HANDLE hInstance,
   int nCmdShow )

{  extern HWND hEditWnd, hwnd;
   extern HANDLE hInst;
   extern HANDLE hAccTable;
   RECT Rect;

   hInst = hInstance;

   hAccTable = LoadAccelerators(hInst, "ClipsAcc");

   hwnd = CreateWindow
   (  "ClipsEditWClass",
      "Edit File - (untitled)",
      WS_OVERLAPPEDWINDOW,
      100, 100, CW_USEDEFAULT, CW_USEDEFAULT,
      NULL, NULL, hInstance, NULL
   );

   if (!hwnd)
      return (FALSE);

   GetClientRect(hwnd, (LPRECT) &Rect);

   /*----------------------------+
   |Create a child editor window |
   +----------------------------*/
   hEditWnd = CreateWindow
   (  "Edit", "",
      ES_LEFT | ES_MULTILINE | ES_AUTOVSCROLL |
      ES_AUTOHSCROLL | ES_WANTRETURN | WS_CHILD |
      WS_VISIBLE  | WS_VSCROLL | WS_HSCROLL | WS_TABSTOP,
      0, 0, (Rect.right-Rect.left), (Rect.bottom-Rect.top),
      hwnd, IDC_EDIT, hInst, NULL
   );

   if (!hEditWnd)
   {  DestroyWindow(hwnd);
      return (NULL);
   }

   /*-----------------------------------------------------+
   | Get an hourglass cursor to use during file transfers |
   +-----------------------------------------------------*/
   {  extern HANDLE hHourGlass;
      hHourGlass = LoadCursor(NULL, IDC_WAIT);
   }
    
   /*---------------------------------------------------+
   | fill in non-variant fields of OPENFILENAME struct. |
   +---------------------------------------------------*/
   {  extern char szFileName[];
      extern char szFileTitle[];
      extern OPENFILENAME ofn;
      ofn.lStructSize       = sizeof(OPENFILENAME);
      ofn.hwndOwner	  = hwnd;
      ofn.lpstrFilter	  = "CLIPS Files (*.CLP)\0*.CLP\0Batch Files (*.BAT)\0*.BAT\0All Files (*.*)\0*.*\0";
      ofn.lpstrCustomFilter = NULL;
      ofn.nMaxCustFilter	  = 0;
      ofn.nFilterIndex	  = 1;
      ofn.lpstrFile         = szFileName;
      ofn.nMaxFile	  = MAXFILENAME;
      ofn.lpstrInitialDir   = NULL;
      ofn.lpstrFileTitle    = szFileTitle;
      ofn.nMaxFileTitle     = MAXFILENAME;
      ofn.lpstrTitle        = NULL;
      ofn.lpstrDefExt       = "CLP";
      ofn.Flags             = 0;
   }

   /*-----------------------------------------------+
   | fill in non-variant fields of PRINTDLG struct. |
   +-----------------------------------------------*/
   {  extern PRINTDLG pd;
      pd.lStructSize    = sizeof(PRINTDLG);
      pd.hwndOwner      = hwnd;
      pd.hDevMode       = NULL;
      pd.hDevNames      = NULL;
      pd.Flags          = PD_RETURNDC | PD_NOSELECTION | PD_NOPAGENUMS;
      pd.nCopies        = 1;
   }

   /*-------------------------+
   | Set Font to a Fixed Font |
   +-------------------------*/
   {  extern HFONT hFont;
      hFont = GetStockObject(SYSTEM_FIXED_FONT);
      SendMessage(hEditWnd, WM_SETFONT, GetStockObject(SYSTEM_FIXED_FONT), 0L);
   }

   ShowWindow(hwnd, nCmdShow);
   UpdateWindow(hwnd);

   /*-----------------------+
   | Setup for Find Replace |
   +-----------------------*/
   {  extern FINDREPLACE fr;
      extern char SearchFor[];
      extern char ReplaceWith[];
      extern UINT uFindReplaceMsg;
      uFindReplaceMsg = RegisterWindowMessage(FINDMSGSTRING);

      memset ( &SearchFor, '\0', 255 );
      memset ( &ReplaceWith, '\0', 255 );
      memset ( &fr, 0, sizeof ( FINDREPLACE ) );

      fr.lStructSize = sizeof ( FINDREPLACE );
      fr.hwndOwner = hwnd;
      fr.lpstrFindWhat = (LPSTR) &SearchFor;
      fr.lpstrReplaceWith = (LPSTR) &ReplaceWith;
      fr.wFindWhatLen = 255;
      fr.wReplaceWithLen = 255;
      fr.Flags = FR_HIDEUPDOWN | FR_HIDEWHOLEWORD ;
   }

   return (TRUE);
}

/******************************************************************
* MainWndProc :  Processes all Messages for Editor Application.
******************************************************************/

long FAR PASCAL _export MainWndProc (
   HWND hWnd,
   UINT message,
   WPARAM wParam,
   LPARAM lParam )

{  extern UINT uFindReplaceMsg;
   extern HWND hEditWnd;   /* handle to edit window */

   /*-------------------------------------+
   | Process the Find and Replace Message |
   +-------------------------------------*/
   if ( message == uFindReplaceMsg )  
      return StartSearch (hWnd, wParam, lParam );

   switch (message)
   {  case WM_COMMAND:
      {  switch (wParam)
         {  case 0x00DA:
	       SendMessage (hEditWnd,WM_CHAR,VK_BACK,0L);
	       break;

	    case 0x00E0:
	       SendMessage (hEditWnd,WM_CHAR,VK_RETURN,0L);
               break;

	    /*-------------------+
	    | FILE menu commands |
	    +-------------------*/

	    case IDM_FILE_NEW:
	    case IDM_FILE_OPEN:
	    case IDM_FILE_REVERT:
	    case IDM_FILE_SAVE:
	    case IDM_FILE_SAVEAS:
	    case IDM_FILE_PRINT:
	    case IDM_FILE_SETUP:
	    case IDM_FILE_CLOSE:
	       return DoFileMenu ( hWnd, wParam );

	    /*-------------------+
	    | EDIT menu commands |
	    +-------------------*/

	    case IDM_EDIT_UNDO:
	    case IDM_EDIT_CLEAR:
	    case IDM_EDIT_CUT:
	    case IDM_EDIT_COPY:
	    case IDM_EDIT_PASTE:
	    case IDM_EDIT_BALANCE:
	    case IDM_EDIT_FONT:
	    case IDC_EDIT:
	       return DoEditMenu (hWnd, wParam, lParam );

	    /*---------------------+
	    | BUFFER menu commands |
	    +---------------------*/

            case IDM_BUFFER_FIND:
            {  SetUpSearch ( hWnd, 0 );
               break;
            }

            case IDM_BUFFER_REPLACE:
            {  SetUpSearch ( hWnd, 1 );
               break;
            }

	    case IDM_BUFFER_BATCH:
            case IDM_HELP_COMPLETE:
	    case IDM_EDIT_COMPLETE:
	    case IDM_BUFFER_LOAD:
	    case IDM_BUFFER_LBUF:
	       return MessageDDE( wParam );


            case IDM_HELP_CLIPS:
            {  WinHelp ( hWnd, "CLIPS6.HLP", HELP_INDEX, NULL );
               break;
            }
	    /*-------------------+
	    | ABOUT menu command |
	    +-------------------*/
            case IDM_ABOUT:
            {  extern HANDLE hInst;
               FARPROC lpProcAbout;
               lpProcAbout = MakeProcInstance(About, hInst);
               DialogBox(hInst, "AboutBox", hWnd, lpProcAbout);
               FreeProcInstance(lpProcAbout);
               break;
            }
	 }
         break;
      } 
      
      case WM_INITMENUPOPUP:
      {  extern HCONV hConv;
         DWORD sel   = SendMessage(hEditWnd,EM_GETSEL,0,0L);
         WORD  len   = HIWORD(sel)-LOWORD(sel);
         UINT  Flags = MF_BYCOMMAND|MF_GRAYED;
         HMENU hMenu = GetMenu(hWnd);

         if ( len > 0  && hConv != NULL )
            Flags = MF_BYCOMMAND|MF_ENABLED;

         EnableMenuItem(hMenu, IDM_BUFFER_LOAD, Flags);
	 EnableMenuItem(hMenu, IDM_BUFFER_BATCH,Flags);
         break;
      }

      case WM_SETFOCUS:
         SetFocus (hEditWnd);
         break;

      case WM_SIZE:
         MoveWindow(hEditWnd, 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE);
         break;

      case WM_QUERYENDSESSION:
         return (QuerySaveFile(hWnd));

      case WM_CLOSE:
      {  extern HFONT hFont;
         if (!QuerySaveFile(hWnd))
            return (FALSE);
         DestroyWindow(hWnd);
         DeleteObject ( hFont );
         return(TRUE);
      }

      case WM_DESTROY:
      {  FreeDDE ( );
         PostQuitMessage(0);
	 break;
      }

      case WM_INITMENU:
         if ( wParam == (WPARAM) GetMenu(hWnd))
	 {  if (OpenClipboard(hWnd))
	    {  if (IsClipboardFormatAvailable(CF_TEXT) ||
	          IsClipboardFormatAvailable(CF_OEMTEXT))
	          EnableMenuItem(wParam,IDM_EDIT_PASTE,MF_ENABLED);
	       else
	          EnableMenuItem(wParam,IDM_EDIT_PASTE,MF_GRAYED);
	       CloseClipboard ();
	       return (TRUE);
	    }
	    else
	       return (FALSE);
	 }
	 return (TRUE);

      default:
         return (DefWindowProc(hWnd, message, wParam, lParam));
   }
   return (NULL);
}

/******************************************************************
* DoFileMenu :  Processes all Messages for File Menu Item
******************************************************************/

BOOL DoFileMenu (HWND hWnd, WPARAM wParam )
{  switch (wParam)
   {  case IDM_FILE_NEW:
      {  extern BOOL bChanges;
         extern char szFileName[];
         /*-----------------------------------+
	 | If current file has been modified, |
	 | query user about saving it.        |
         +-----------------------------------*/

         if (!QuerySaveFile(hWnd))
            return (NULL);

	 /*-----------------------------------------------+
	 | bChanges is set to FALSE to indicate there     |
	 | have been no changes since the last file save. |
         +-----------------------------------------------*/
         bChanges = FALSE;
         szFileName[0] = 0;

	 /*-----------------------+
	 | Update the edit buffer |
	 +-----------------------*/
         SetNewBuffer(hWnd, NULL, "Edit File - (untitled)");
         EnableMenuItem ( GetMenu(hWnd), IDM_FILE_REVERT,
            MF_BYCOMMAND | MF_GRAYED);
         break;
      }

      case IDM_FILE_OPEN:
      {  extern OPENFILENAME ofn;

	 if (!QuerySaveFile(hWnd))
            return (NULL);

	 /*-------------------------+
	 | Use standard open dialog |
	 +-------------------------*/
	 if (!GetOpenFileName ((LPOPENFILENAME)&ofn))
            return NULL;

         EnableMenuItem ( GetMenu(hWnd), IDM_FILE_REVERT,
            MF_BYCOMMAND | MF_ENABLED);

         /*-------------------------------------------+
         | Fall Through to Revert to Open & Read File |
         +-------------------------------------------*/
      }

      case IDM_FILE_REVERT:
      {  extern int hFile;
	 extern char szFileTitle[];
         extern char szFileName[];
         struct stat FileStatus;
         extern HANDLE hEditBuffer;
         PSTR pEditBuffer;
	 extern HANDLE hHourGlass;
	 HANDLE hSaveCursor;
         WORD IOStatus;

         /*------------------+
         | Revert Safety Net |
         +------------------*/
         if ( wParam == IDM_FILE_REVERT )
         {  if (MessageBox (hWnd,"Revert to Last Saved Document ?","Warning",
               MB_YESNO | MB_ICONHAND) == IDNO )
               return 0;
         }

	 /*---------------------------------+
	 | Open the file and get its handle |
	 +---------------------------------*/
	 hFile = OpenFile ((LPSTR)szFileName,
	    (LPOFSTRUCT)&OfStruct, OF_READ);
         if (!hFile)
            return (NULL);

	 /*-------------------------------------------------+
	 | Allocate edit buffer to the size of the file + 1 |
	 +-------------------------------------------------*/
	 if (fstat(hFile, &FileStatus))
	 {  MessageBox(hWnd, "File not found !",
               "FILE READ ERROR", MB_OK | MB_ICONEXCLAMATION);
            close(hFile);
            return (NULL);
         }

	 if (FileStatus.st_size > 65534)
	 {  MessageBox(hWnd, "Can't load files larger than 65,534 bytes long !",
               "FILE READ ERROR", MB_OK | MB_ICONEXCLAMATION);
            close(hFile);
            return (NULL);
         }

         hEditBuffer = LocalAlloc(LMEM_MOVEABLE | LMEM_ZEROINIT,
	    (WORD)FileStatus.st_size+1);

	 if (!hEditBuffer)
	 {  MessageBox(hWnd, "Not enough memory.",
               NULL, MB_OK | MB_ICONEXCLAMATION);
            close(hFile);
            return (NULL);
         }

         hSaveCursor = SetCursor(hHourGlass);
         pEditBuffer = LocalLock(hEditBuffer);

         IOStatus = read(hFile, pEditBuffer, (WORD)FileStatus.st_size);
         close(hFile);

	 /*----------------------------------+
	 | # bytes read must equal file size |
	 +----------------------------------*/
         if (IOStatus != (WORD)FileStatus.st_size)
	 {  sprintf(szTemp, "Error reading %s.", szFileName);
            SetCursor(hSaveCursor);      /* Remove the hourglass */
            MessageBox(hWnd, szTemp, NULL, MB_OK | MB_ICONEXCLAMATION);
         }

         LocalUnlock(hEditBuffer);

	 /*-------------------------------------+
	 | Set up a new buffer and window title |
	 +-------------------------------------*/
	 sprintf(szTemp, "Edit File - (%s)", szFileTitle);
	 SetNewBuffer(hWnd, hEditBuffer, (LPSTR)&szTemp);
         SetCursor(hSaveCursor);
         break;
      }

      case IDM_FILE_SAVE:
      {  /*------------------------------------------------+
         | If there is no filename, use the saveas command |
	 | to get one.  Otherwise, save the file using the |
	 | current filename.                               |
         +------------------------------------------------*/
	 extern char szFileName[];
	 if (szFileName[0])
	 {  extern BOOL bChanges;
	    if (bChanges)
	       SaveFile(hWnd);
	    break;
	 }
	 /*-------------------------------------+
	 | else fall thru for Saveas processing |
	 +-------------------------------------*/
      }

      case IDM_FILE_SAVEAS:
      {  extern OPENFILENAME ofn;
         extern char szFileTitle[];
         char szWindowTitle[80];

	 /*-------------------------+
	 | Use standard save dialog |
	 +-------------------------*/
	 if (!GetSaveFileName ((LPOPENFILENAME)&ofn))
	    return FALSE;
                 
	 /*------------------------------------------+
	 | Change window title to include file title |
	 +------------------------------------------*/
	 lstrcpy(szWindowTitle, "CLIPS 6.0 Editor");
         lstrcat(szWindowTitle, " - ");
         lstrcat(szWindowTitle, szFileTitle);
         SetWindowText(hWnd, szWindowTitle);
         SaveFile(hWnd);
	 break;
      }

      case IDM_FILE_PRINT:
         return ( PrintFile (hWnd));

      case IDM_FILE_SETUP:
      {  extern PRINTDLG pd;
         DWORD FlagSave;
	 FlagSave = pd.Flags;
         pd.Flags |= PD_PRINTSETUP;    /* Set option */
         PrintDlg((LPPRINTDLG)&pd);
         pd.Flags = FlagSave;          /* Remove option */
         break;
      }

      case IDM_FILE_CLOSE:
      {  if (QuerySaveFile(hWnd))
         WinHelp ( hWnd, "CLIPS6.HLP", HELP_QUIT, NULL );
         DestroyWindow(hWnd);
	 break;
      }
   }
   return TRUE;
}

/******************************************************************
* DoFileMenu :  Processes all Messages for File Menu Item
******************************************************************/

DoEditMenu (HWND hWnd, WPARAM wParam, LPARAM lParam )

{  extern HWND hEditWnd;

   switch (wParam)
   {  case IDM_EDIT_UNDO:
         if(SendMessage(hEditWnd, EM_CANUNDO, 0, 0L))
	    SendMessage(hEditWnd, EM_UNDO,0,0l);
         break;

      case IDM_EDIT_CLEAR:
         SendMessage(hEditWnd, WM_CLEAR, 0, 0L);
	 break;

      case IDM_EDIT_CUT:
         SendMessage(hEditWnd, WM_CUT, 0, 0L);
	 break;

      case IDM_EDIT_COPY:
         SendMessage(hEditWnd, WM_COPY, 0, 0L);
	 break;

      case IDM_EDIT_PASTE:
         SendMessage(hEditWnd, WM_PASTE, 0, 0L);
	 break;

      case IDM_EDIT_BALANCE:
         Balance(hEditWnd);
         break;
      
      case IDM_EDIT_FONT:
      {  extern HWND hwnd;
         LOGFONT lf;
         CHOOSEFONT cf;

	 memset ( &cf, 0, sizeof ( CHOOSEFONT) );

	 cf.lStructSize = sizeof ( CHOOSEFONT );
	 cf.hwndOwner = hwnd;
	 cf.lpLogFont = &lf;
	 cf.Flags = CF_BOTH;
	 cf.rgbColors = RGB(0,255,255);
	 cf.nFontType = SCREEN_FONTTYPE;

	 if (ChooseFont (&cf ))
	 {  extern HFONT hFont;
	    DeleteObject ( hFont );
	    hFont = CreateFontIndirect (cf.lpLogFont);
	    SendMessage (hEditWnd, WM_SETFONT, (WORD)hFont,(LONG)TRUE);
	 }
	 break;
      }

      case IDC_EDIT:
      {  if (HIWORD (lParam) == EN_CHANGE)
	 {  extern BOOL bChanges;
	    EnableMenuItem(GetMenu(hWnd), IDM_EDIT_UNDO, MF_ENABLED);
	    bChanges = TRUE;
	 }
	 if (HIWORD (lParam) == EN_ERRSPACE)
	 {  MessageBox ( GetFocus (), "Out of memory.",
               "PrntFile Sample Application",
               MB_ICONHAND | MB_OK);
         }
	 break;
      }
   }
   return ( TRUE );
}