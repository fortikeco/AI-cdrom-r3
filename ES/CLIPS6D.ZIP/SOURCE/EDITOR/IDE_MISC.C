   /*******************************************************/
   /*      "C" Language Integrated Production System      */
   /*                                                     */
   /*                  A Product Of The                   */
   /*             Software Technology Branch              */
   /*             NASA - Johnson Space Center             */
   /*                                                     */
   /*               CLIPS Version 6.00  01/01/93          */
   /*              IDE Text Editor 1.00  01/01/93         */
   /*                                                     */
   /*                     PRINT MODULE                    */
   /*******************************************************/

/**************************************************************/
/* Purpose: Handle Dialogs, File I/O, and Printing.           */
/*                                                            */
/* Principal Programmer(s):                                   */
/*      Christopher J. Ortiz                                  */
/*                                                            */
/* Contributing Programmer(s):                                */
/*      Sample Code from Microsoft SDK                        */
/*      Sample Code from Borland C++                          */
/*                                                            */
/* Revision History:                                          */
/*                                                            */
/**************************************************************/

#include <windows.h>
#include <commdlg.h>

#include <drivinit.h>
#include <io.h>
#include <stdio.h>
#include <string.h>

#include "ide_ids.h"
#include "ide_misc.h"

PRINTDLG pd;
BOOL     bAbort = NULL;
HWND     hAbortDlgWnd = NULL;

/******************************************************************
* SaveFile: This saves the current contents of the Edit buffer
*******************************************************************/

BOOL SaveFile(hWnd)
   HWND hWnd;

{  extern HWND hEditWnd;
   HANDLE hSaveCursor;
   extern HANDLE hHourGlass;
   extern HANDLE hEditBuffer;
   PSTR pEditBuffer;           
   BOOL bSuccess;
   int IOStatus;   
   extern int hFile;
   extern OFSTRUCT OfStruct;
   extern char szFileName[];

   if ((hFile = OpenFile(szFileName, &OfStruct, OF_CANCEL | OF_CREATE)) < 0)
   {  extern char szTemp[];
      /*---------------------------+
      | If the file can't be saved |
      +---------------------------*/
      sprintf(szTemp, "Cannot write to %s.", szFileName);
      MessageBox(hWnd, szTemp, NULL, MB_OK | MB_ICONHAND);
      return (FALSE);
   }

   hEditBuffer = (HANDLE)SendMessage(hEditWnd, EM_GETHANDLE, 0, 0L);
   pEditBuffer = LocalLock(hEditBuffer);

   /*--------------------------------------------------------+
   | Set the cursor to an hourglass during the file transfer |
   +--------------------------------------------------------*/
   hSaveCursor = SetCursor(hHourGlass);
   IOStatus = write(hFile, pEditBuffer, strlen(pEditBuffer));
   close(hFile);
   SetCursor(hSaveCursor);
   if (IOStatus != (int)strlen(pEditBuffer))
   {  extern char szTemp[];
      sprintf(szTemp, "Error writing to %s.", szFileName);
      MessageBox(hWnd, szTemp, NULL, MB_OK | MB_ICONHAND);
      bSuccess = FALSE;
   }
   else
   {  extern BOOL bChanges;
      bSuccess = TRUE;                /* Indicates the file was saved      */
      bChanges = FALSE;               /* Indicates changes have been saved */
   }

   LocalUnlock(hEditBuffer);
   return (bSuccess);
}

/******************************************************************
* QuerySaveFile: Called when some action might lose current contents
*******************************************************************/

BOOL QuerySaveFile(hWnd)
   HWND hWnd;

{  int Response;
   extern BOOL bChanges;

   if (bChanges)
   {  extern char szTemp[];
      extern char szFileName[];
      sprintf(szTemp, "Save current changes: %s", szFileName);
      Response = MessageBox(hWnd, szTemp, "EditFile",  MB_YESNOCANCEL | MB_ICONEXCLAMATION);
      if (Response == IDYES)
      {  /*-----------------------------------------+
	 | Make sure there is a filename to save to |
	 +-----------------------------------------*/
	 while (!szFileName[0])
	 {  extern OPENFILENAME ofn;
	    if (!GetSaveFileName ((LPOPENFILENAME)&ofn))
	       return FALSE;
         }
         SaveFile(hWnd);
      }
      else if (Response == IDCANCEL)
         return (FALSE);
   }
   return ( TRUE );
}

/******************************************************************
* SetNewBuffer: Set new buffer for edit window
*******************************************************************/

void SetNewBuffer(hWnd, hNewBuffer, Title)
   HWND hWnd;
   HANDLE hNewBuffer;
   char *Title;

{  extern HWND hEditWnd;
   extern BOOL bChanges;
   HANDLE hOldBuffer;

   hOldBuffer = (HANDLE)SendMessage(hEditWnd, EM_GETHANDLE, 0, 0L);
   LocalFree(hOldBuffer);

   /*----------------------------------+
   | Allocates a buffer if none exists |
   +----------------------------------*/
   if (!hNewBuffer)                    
      hNewBuffer = LocalAlloc(LMEM_MOVEABLE | LMEM_ZEROINIT, 1);

   /*-------------------------------------------+
   | Updates the buffer and displays new buffer |
   +-------------------------------------------*/
   SendMessage(hEditWnd, EM_SETHANDLE, hNewBuffer, 0L); 
   SetWindowText(hWnd, Title);
   SetFocus(hEditWnd);
   bChanges = FALSE;
}

/******************************************************************
* GetPrinterDC: Get hDc for current device on current output port
*   according to info in WIN.INI.
*******************************************************************/

HDC GetPrinterDC(void)

{  HDC         hDC;
   LPDEVMODE   lpDevMode = NULL;
   LPDEVNAMES  lpDevNames;
   LPSTR       lpszDriverName;
   LPSTR       lpszDeviceName;
   LPSTR       lpszPortName;

   if (!PrintDlg((LPPRINTDLG)&pd))
      return(NULL);

   if (pd.hDC)
   {  hDC = pd.hDC;
   }
   else
   {  if (!pd.hDevNames)
         return(NULL);

      lpDevNames = (LPDEVNAMES)GlobalLock(pd.hDevNames);
      lpszDriverName = (LPSTR)lpDevNames + lpDevNames->wDriverOffset;
      lpszDeviceName = (LPSTR)lpDevNames + lpDevNames->wDeviceOffset;
      lpszPortName   = (LPSTR)lpDevNames + lpDevNames->wOutputOffset;
      GlobalUnlock(pd.hDevNames);

      if (pd.hDevMode)
        lpDevMode = (LPDEVMODE)GlobalLock(pd.hDevMode);

      hDC = CreateDC(lpszDriverName, lpszDeviceName, lpszPortName, (LPSTR)lpDevMode);

      if (pd.hDevMode && lpDevMode)
        GlobalUnlock(pd.hDevMode);
   }

   if (pd.hDevNames)
   {  GlobalFree(pd.hDevNames);
      pd.hDevNames=NULL;
   }

   if (pd.hDevMode)
   {  GlobalFree(pd.hDevMode);
      pd.hDevMode=NULL;
   }
   return(hDC);
}

/******************************************************************
* AbortProc: Processes messages for the Abort Dialog box
*******************************************************************/

int FAR PASCAL _export AbortProc(hPr, Code)
   HDC hPr;                          
   int Code;                       

{  MSG msg;

    /*---------------------------------+
    | If the abort dialog isn't up yet |
    +---------------------------------*/
   if (!hAbortDlgWnd)             
      return(TRUE);

   /*---------------------------------------------------+
   | Process messages intended for the abort dialog box |
   +---------------------------------------------------*/

   while (!bAbort && PeekMessage(&msg, NULL, NULL, NULL, TRUE))
   {  if (!IsDialogMessage(hAbortDlgWnd, &msg))
      {   TranslateMessage(&msg);
          DispatchMessage(&msg);
      }
   }
   return (!bAbort);
}

/******************************************************************
* AbortDlg: Processes messages for printer abort dialog box
*******************************************************************/

int FAR PASCAL _export AbortDlg(hDlg, msg, wParam, lParam)
   HWND hDlg;
   unsigned msg;
   WORD wParam;
   LONG lParam;

{  switch(msg)
   {  /*-------------------------------------+
      | Watch for Cancel button, RETURN key, |
      | ESCAPE key, or SPACE BAR             |
      +-------------------------------------*/

      case WM_COMMAND:
         return (bAbort = TRUE);

      case WM_INITDIALOG:
      {  /*----------------------------------------------+
	 | Set the focus to the Cancel box of the dialog |
	 +----------------------------------------------*/
         extern char szFileName[];

         SetFocus(GetDlgItem(hDlg, IDCANCEL));
         SetDlgItemText(hDlg, IDC_FILENAME, szFileName);
	 return (TRUE);
      }
   }
   return (FALSE);
}

/******************************************************************
* About: Processes messages for "About" dialog box
*******************************************************************/

BOOL FAR PASCAL _export About(hDlg, message, wParam, lParam)
   HWND hDlg;  
   unsigned message;
   WORD wParam;
   LONG lParam;

{  switch (message)
   {  case WM_INITDIALOG:
         return (TRUE);

      case WM_COMMAND:
      { if (wParam == IDOK || wParam == IDCANCEL)
	 {  EndDialog(hDlg, TRUE);
            return (TRUE);
         }
	 return (TRUE);
      }
   }
   return (FALSE);
}

/******************************************************************
* PrintFile: Procedure to send editor buffer out to a printer.
*******************************************************************/

BOOL PrintFile ( hWnd )
   HWND hWnd;

{  extern BOOL bAbort;
   extern HWND hAbortDlgWnd;
   extern HWND hEditWnd;
   extern HANDLE hHourGlass;
   extern HANDLE hInst;
   extern char szTemp[];

   int nPageSize;	   /* vert. resolution of printer device */
   int LineSpace;          /* spacing between lines          */
   int LinesPerPage;       /* lines per page                 */
   int CurrentLine;        /* current line                   */
   int LineLength;         /* line length                    */
   WORD wLines;            /* number of lines to print       */
   WORD wIndex;            /* index into lines to print      */
   char szLine[128];       /* buffer to store lines before printing */
   TEXTMETRIC TextMetric;  /* information about character size      */
   FARPROC lpAbortDlg;
   FARPROC lpAbortProc;
   HANDLE hSaveCursor;
   HDC hPr;
   int Status;

   hSaveCursor = SetCursor(hHourGlass);
   hPr = GetPrinterDC();
   if (!hPr)
   {  extern char szFileName[];
      sprintf(szTemp, "Cannot print %s", szFileName);
      MessageBox(hWnd, szTemp, NULL, MB_OK | MB_ICONHAND);
      return (NULL);
   }

   lpAbortDlg =  MakeProcInstance(AbortDlg, hInst);
   lpAbortProc = MakeProcInstance(AbortProc, hInst);

   /*--------------------------+
   | Define the abort function |
   +--------------------------*/

   Escape(hPr, SETABORTPROC, NULL, (LPSTR)  lpAbortProc, (LPSTR) NULL);

   if (Escape(hPr, STARTDOC, 14, "PrntFile text", (LPSTR) NULL) < 0)
   {  MessageBox(hWnd, "Unable to start print job", NULL, MB_OK | MB_ICONHAND);
      FreeProcInstance(lpAbortDlg);
      FreeProcInstance(lpAbortProc);
      DeleteDC(hPr);
   }

   /*---------------------+
   | Clear the abort flag |
   +---------------------*/
   bAbort = FALSE;

   /*---------------------------------------+
   | Create the Abort dialog box (modeless) |
   +---------------------------------------*/

   hAbortDlgWnd = CreateDialog(hInst, "AbortDlg", hWnd, lpAbortDlg);

   if (!hAbortDlgWnd)
   {  SetCursor(hSaveCursor);
      MessageBox(hWnd, "NULL Abort window handle", NULL, MB_OK | MB_ICONHAND);
      return (FALSE);
   }
                    
   /*----------------------+
   | Now show Abort dialog |
   +----------------------*/
   ShowWindow (hAbortDlgWnd, SW_NORMAL);

   /*---------------------------+
   | Disable the main window to |
   | avoid reentrancy problems  |
   +---------------------------*/

   EnableWindow(hWnd, FALSE);
   SetCursor(hSaveCursor);

   /*---------------------------------------------------------+                                                          
   | Since you may have more than one line, you need to       |
   | compute the spacing between lines.  You can do that by   |
   | retrieving the height of the characters you are printing |
   | and advancing their height plus the recommended external |
   | leading height.                                          |
   +---------------------------------------------------------*/

   GetTextMetrics(hPr, &TextMetric);
   LineSpace = TextMetric.tmHeight + TextMetric.tmExternalLeading;

   /*------------------------------------------------------+
   | Since you may have more lines than can fit on one     |
   | page, you need to compute the number of lines you can |
   | print per page.  You can do that by retrieving the    |
   | dimensions of the page and dividing the height        |
   | by the line spacing.                                  |
   +------------------------------------------------------*/

   nPageSize = GetDeviceCaps (hPr, VERTRES);
   LinesPerPage = nPageSize / LineSpace - 1;

   /*----------------------------------------------------------+
   | You can output only one line at a time, so you need a     |
   | count of the number of lines to print.  You can retrieve  |
   | the count sending the EM_GETLINECOUNT message to the edit |
   | control.                                                  |
   +----------------------------------------------------------*/

   wLines = (WORD)SendMessage(hEditWnd, EM_GETLINECOUNT, 0, 0L);

   /*---------------------------------------------------+
   | Keep track of the current line on the current page |
   +---------------------------------------------------*/

   CurrentLine = 1;

   /*-------------------------------------------------------+
   | One way to output one line at a time is to retrieve    |
   | one line at a time from the edit control and write it  |
   | using the TextOut function.  For each line you need to |
   | advance one line space.  Also, you need to check for   |
   | the end of the page and start a new page if necessary. |    
   +-------------------------------------------------------*/

   Status = 0;
   for (wIndex = 0; wIndex < wLines; wIndex++)
   {  szLine[0] = 127;	 
      szLine[1] = 0;
      LineLength = (int)SendMessage(hEditWnd, EM_GETLINE, wIndex, (DWORD)(LPSTR)szLine);
      TextOut(hPr, 0, CurrentLine*LineSpace, (LPSTR)szLine, LineLength);
      if (++CurrentLine > LinesPerPage )
      {  CurrentLine = 1;
         Status = Escape(hPr, NEWFRAME, 0, 0L, 0L);
	 if (Status < 0 || bAbort) break;
      }
   }

   if (Status >= 0 && !bAbort)
   {  Escape(hPr, NEWFRAME, 0, 0L, 0L);
      Escape(hPr, ENDDOC, 0, 0L, 0L);
   }
   EnableWindow(hWnd, TRUE);

   /*-----------------------------+
   | Destroy the Abort dialog box |
   +-----------------------------*/

   DestroyWindow(hAbortDlgWnd);
   FreeProcInstance(lpAbortDlg);
   FreeProcInstance(lpAbortProc);
   DeleteDC(hPr);
   return ( TRUE );
}
