void system ( char * );

void system ( char * CommandBuffer )
{
}
