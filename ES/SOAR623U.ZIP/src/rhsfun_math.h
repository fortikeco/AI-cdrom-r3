/*
 * $Id: rhsfun_math.h,v 1.2 1993/11/21 23:59:08 portelli Exp $
 * $Log: rhsfun_math.h,v $
 * Revision 1.2  1993/11/21  23:59:08  portelli
 * 6.1.1 checkin
 *
 * Revision 1.1  93/11/21  16:21:25  soarhack
 * initial checkin
 */


extern void init_built_in_rhs_math_functions (void);
