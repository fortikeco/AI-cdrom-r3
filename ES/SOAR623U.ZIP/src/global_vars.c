/*
 * $Id: global_vars.c,v 1.2 1993/11/21 16:52:41 soarhack Exp $
 * $Log: global_vars.c,v $
 * Revision 1.2  1993/11/21  16:52:41  soarhack
 * 6.1.1 checkin
 *
 * Revision 1.1  1993/06/17  20:47:15  jtraub
 * Released
 *
 * Revision 0.1  1993/06/17  20:20:01  jtraub
 * 6.1_checkin
 *
 * Revision 9.2  1993/05/10  18:12:19  jtraub
 * removed thinkc ifdef because this file is never compiled standalone
 *
 */
/* Globals */
#define GLOBAL

#include "global_vars.h"
