
#include <stdio.h>

main()
{

printf("\n  Sending add ALL COMMAND (facts) to blackboard \n");

INIT_DYNACLIPS("C-PROG");

SEND_BB_STR("add ALL COMMAND (facts) ");

sleep (5);


}
