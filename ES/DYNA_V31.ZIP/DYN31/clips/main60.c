
/*******************************************************************
DYNACLIPS ( DYNAmic CLIPS Utilities)  Version 3.1
COPYRIGHT 1994  by Yilmaz Cengeloglu.

This utilities and libraries for CLIPS are  the sole property of
        Yilmaz Cengeloglu
        P.O. Box 4142
        Winter Park, FL 32793-4142, USA


DYNACLIPS Version 3.1  can be  freely used and redistributed for
educational purpose. Commercial use of these utilities is subject to the
terms and conditions of a license agreement with the  Yilmaz Cengeloglu.



 **********************************************************************/

#include <stdio.h>
#include "setup.h"
#include "sysdep.h"
#include "extnfunc.h"
#include "commline.h"
#include "clips.h"

 

#define   DOEXTERN
#include "dyn.h"


int main(argc,argv)
  int argc;
  char *argv[] ;
{


if ( (argc>1) && (strcmp(argv[1], "-clips") ==0 )) 
      {
       printf("\nDYNACLIPS: Entering regular CLIP 6.0  Mode. ");
       printf("\n");
      
       InitializeCLIPS();
       RerouteStdin(argc,argv);
       CommandLoop();
       return(-1);

      }


DYNACLIPS(argc,argv);


}

VOID UserFunctions()
{
DEFINE_DYNACLIPS_FUNCTIONS();

}

