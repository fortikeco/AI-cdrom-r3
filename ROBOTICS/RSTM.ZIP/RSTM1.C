int sonar()
{
    int sonar_distance;
    
    sonar_end = 0;
    sonar_start_time = 0;
    sonar_end_time = 0;
    
    poke(0x1021, 1);

    poke(0x5000, 0);
    poke(0x5000, 1);
    msleep(20L);
    poke(0x5000, 0);

    msleep(20L);

    poke(0x5000, 1);

    while(sonar_end == 0);
    if (tof == 256)
    {
        sonar_distance = ((32767 - sonar_start_time) + sonar_end_time) / 151;
    }
    else 
    {
        sonar_distance = (sonar_end_time - sonar_start_time) / 151;
    }
    poke(0x5000, 0);
    return sonar_distance;
}
