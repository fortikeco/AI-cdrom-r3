int sonar()
{
    int sonar_distance;
    
    sonar_end = 0;
    sonar_start_time = 0;
    sonar_end_time = 0;
    poke(0x5000, 0);

    if (digital(3) == 1)
    {
    msleep(200L);
    poke(0x5000, 1);
    msleep(100L);
    poke(0x5000, 0);
    msleep(1000L);
    }

    poke(0x1021, 1);
    poke(0x5000, 1);
    while(sonar_end == 0);
    if ((sonar_start_time < 0) && (sonar_end_time > 0))
    {
        sonar_distance = ((sonar_start_time ^ 65535) + sonar_end_time) / 303;
        printf("<   >\n");
    }
    else if ((sonar_start_time < 0) && (sonar_end_time < 0))
    {
        sonar_distance = ((sonar_start_time ^ 65535) - (sonar_end_time ^ 65535)) / 303;
        printf("<   <\n");
    }
    else if ((sonar_start_time > 0) && (sonar_end_time < 0))
    {
        sonar_distance = (sonar_start_time - (32767 - (sonar_end_time ^ 65535))) / 303;
        printf(">   <\n");
    }
    else if ((sonar_start_time > 0) && (sonar_end_time > 0))
    {
        sonar_distance = (sonar_end_time - sonar_start_time) / 303;
        printf(">   >\n");
    }
    poke(0x5000, 0);
    return sonar_distance;
}
