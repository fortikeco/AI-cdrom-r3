
These pictures are copyright of The Robot Group, their authors or both.
Permision to copy only for personal and non-comercial use is hereby granted.
Contact The Robot Group for any other purpose.

March 1994.

