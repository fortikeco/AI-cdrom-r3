/* The wrong way to read the joystick port...                                */
/* Firmware Furnace #4                                                       */

#include <conio.h>
#include <stdlib.h>
#include <stdio.h>

#define JOYPORT 0x201                  /* joystick port value                */
#define MAXAXIS 3                      /* last axis to use                   */

unsigned int Axes[MAXAXIS+1];          /* buttons are bits 0:3               */
int Buttons;



/*---------------------------------------------------------------------------*/
/* Program loop version of joystick port read routine                        */

#define MAXLOOPS 1000

int ReadJoyStick(int JoyPort,unsigned int *pAxes);

int ReadJoyStick(int JoyPort,unsigned int *pAxes) {

  unsigned int loops;                            /* loop counter             */
  int portval;                                   /* current port value       */
  int lastport;                                  /* previous port value      */
  int delta;                                     /* changed axis bits        */

/*--- set up for loop                                                        */

  loops = 1;
  outp(JoyPort,0);                               /* trigger the hardware     */
  portval = inp(JoyPort);
  lastport = portval;

/*--- run loop until all axes done or max loops run out                      */

  do {
     portval = 0x0f & inp(JoyPort);              /* get current bits         */
     delta = portval ^ lastport;                 /* any changes?             */

     if (delta & 0x01)                           /* set current time         */
        *(pAxes+0) = loops;
     if (delta & 0x02)
        *(pAxes+1) = loops;
     if (delta & 0x04)
        *(pAxes+2) = loops;
     if (delta & 0x08)
        *(pAxes+3) = loops;

     lastport = portval;                         /* remember axis bits       */

  } while ((loops++ < MAXLOOPS) &&
           (lastport != 0x00));

  return (0x0f & (~inp(JoyPort)>>4));            /* figure out switches      */

}

/*---------------------------------------------------------------------------*/
/* The Main Loop                                                             */

int main(void) {

int axis;

  printf("Reading the joystick port using loop timing...\n");

  while (!kbhit()) {

     Buttons = ReadJoyStick(JOYPORT,Axes);

     printf("Axis values: ");
     for (axis=0; axis<=MAXAXIS; axis++) {
        printf("%5u ",Axes[axis]);
     }

     printf("Buttons: %1.1X",Buttons);

     printf("\r");
  }

  return(0);

}
