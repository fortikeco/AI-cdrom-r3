/* High-speed joystick reading                                               */
/* Firmware Furnace #4                                                       */

#include <conio.h>
#include <stdlib.h>
#include <stdio.h>

#define JOYPORT 0x201                  /* joystick port value                */
#define MAXAXIS 3                      /* last axis to use                   */

unsigned int Axes[MAXAXIS+1];          /* result of reading all four axes    */
int Buttons;

extern int ReadJoyStick(int JoyPort,unsigned int *Axes);

int main(void) {

int axis;

  printf("Reading the joystick port using Timer 2...\n");

  while (!kbhit()) {

     Buttons = ReadJoyStick(JOYPORT,Axes);

     printf("Axis values: ");
     for (axis=0; axis<=MAXAXIS; axis++) {
        printf("%5u ",Axes[axis]);
     }

     printf("Buttons: %1.1X",Buttons);

     printf("\r");
  }

  return(0);

}
