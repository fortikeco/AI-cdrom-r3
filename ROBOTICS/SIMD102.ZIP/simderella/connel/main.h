/**************************************************************************/
/* main.h                                                       /\/\      */
/* Version 2.2.1 --  August  1991                               \  /      */
/*                                                              /  \      */
/* Author: P. Patrick van der Smagt                          _  \/\/  _   */
/*         University of Amsterdam                          | |      | |  */
/*         Dept. of Computer Systems                        | | /\/\ | |  */
/*         Amsterdam                                        | | \  / | |  */
/*         THE NETHERLANDS                                  | | /  \ | |  */
/*         smagt@fwi.uva.nl                                 | | \/\/ | |  */
/*                                                          | \______/ |  */
/* This software has been written with financial             \________/   */
/* support of the Dutch Foundation for Neural Networks                    */
/* and is therefore owned by the mentioned foundation.          /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/*                                                              \/\/      */
/**************************************************************************/

#ifndef _main_h
#define _main_h

#ifndef MAIN_EXTERN
#	define MAIN_EXTERN extern
#endif

#include "config.h"

/*
 * OSCAR is a robot with one, hand-held, camera only.  We need to
 * know the `real' area of the object and the focus of the lens
 * in order to get vertical information.
 * These are global variables.
 */
MAIN_EXTERN REAL E, focus;

void leave(void);
void main(int argc, char *argv[]);
void loop(void);
char get_next_command(void);


#endif
