/**************************************************************************/
/* config.h                                                     /\/\      */
/* Version 2.2.2 -- February 1993                               \  /      */
/*                                                              /  \      */
/* Author: P. Patrick van der Smagt                          _  \/\/  _   */
/*         University of Amsterdam                          | |      | |  */
/*         Dept. of Computer Systems                        | | /\/\ | |  */
/*         Amsterdam                                        | | \  / | |  */
/*         THE NETHERLANDS                                  | | /  \ | |  */
/*         smagt@fwi.uva.nl                                 | | \/\/ | |  */
/*                                                          | \______/ |  */
/* This software has been written with financial             \________/   */
/* support of the Dutch Foundation for Neural Networks                    */
/* and is therefore owned by the mentioned foundation.          /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/*                                                              \/\/      */
/**************************************************************************/
#ifndef _config_h
#define _config_h


/*
 * Define here what kind of reals you like: float or double.
 */
#define REAL		double



/*
 * Define SGI if you have an SGI machine, or another operating
 * system which complains about the unavailability of signbit()
 * and iszero().  It will replace them by l_signbit() and l_iszero()
 * which are defined in matrix/src/ieee.c.
 * If your machine does not have IEEE routines or is missing the include
 * file <fp_class.h>, define SGI=1 and NO_IEEE=1.
 */
#define SGI		0
#define NO_IEEE		0


#endif
