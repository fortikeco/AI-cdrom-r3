/**************************************************************************/
/* ieee.h                                                       /\/\      */
/* Version 2.2.1 --  June 1992                                  \  /      */
/*                                                              /  \      */
/* Author: P. Patrick van der Smagt                          _  \/\/  _   */
/*         University of Amsterdam                          | |      | |  */
/*         Dept. of Computer Systems                        | | /\/\ | |  */
/*         Amsterdam                                        | | \  / | |  */
/*         THE NETHERLANDS                                  | | /  \ | |  */
/*         smagt@fwi.uva.nl                                 | | \/\/ | |  */
/*                                                          | \______/ |  */
/* This software has been written with financial             \________/   */
/* support of the Dutch Foundation for Neural Networks                    */
/* and is therefore owned by the mentioned foundation.          /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/*                                                              \/\/      */
/**************************************************************************/
#ifndef _ieee_h
#define _ieee_h

#include "config.h"

#if SGI


#if !NO_IEEE
#include <fp_class.h>
#endif

#define signbit(a)	l_signbit(a)
#define iszero(a)	l_iszero(a)


int l_iszero(double x);
int l_signbit(double x);


#endif

#endif
