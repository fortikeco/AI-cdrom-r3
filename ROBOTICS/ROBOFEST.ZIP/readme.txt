
This is the list of pictures from The Robot Group. Most of them are from the recent
Robofest IV in Austin, TX (May 22 & 23, 1993).

All of them are Copyright, The Robot Group, Austin TX, 1993.

For any information/comment/question or to order the Robot Group T-shirt
($15 +S&H see t-shirt.gif), you can contact us by sending a message to
robot-group@cs.utexas.edu.

All the pictures take about 1.4 Mbytes of disk space.

-- Carlos Puchol
-- cpg@cs.utexas.edu

3dtravel.gif	The person in the "flies" in a 3D world in the screens by moving th head.
alex.gif	Alex Iles, designer of some of the blimps. (Sorry, picture too dark).
band1.gif	The robot band (I), by Craig & Charlene Sainsott.
band2.gif	The robot band (II).
bill.gif	Bill Craig, designer of some of the blimps.
blimpbase.gif	Detail of the base of the Mark V blimp.
blimps1.gif	Picture of two of the blimps.
bwlogo.gif	Black and White picture of the Robot Group logo design. (C) The Robot Group, 1993.
carlos.gif	Carlos Puchol, setting up a miniboard for a minidemo.
contest.gif	Student built their own mobiles. The trick was to place a pin in a hole.
dsantos.gif	David Santos and Varmint, one of the earliest robots in the group.
dweebvis.gif	Front picture of Dweebvision (screen shows the guy taking the picture).
glenn.gif	Glenn Currie, designer of Dweebvision. A small telepresence experiment.
gym1.gif	Panoramic view of the main gym will some of the stands.
hand.gif	A giant creeping hand, by Brooks Coleman.
hoover.gif	A hoovercraft, sort of a giant yo-yo, almost no friction. Tim Sheridan.
kuipers.gif	Dr. Kuipers from UT Austin CS, during his lecture on research on robotics.
mb.gif		A picture of a miniboard.
pitbull.gif	The pitbull, by Brooks Coleman.
preparation.gif	Some of the preparations or Robofest.
rover.gif	Rover, a mobile robot from UT Austin CS Robotics lab, conveniently dressed up.
seattle.gif	Huey, by Car Lunt from the Seattle Robotics Society.
skull.gif	A freaking skull that moves to the rhythm of the music.
the_group.gif	Most of the members of the group in the usual meeting place, Ted's Greek corner.
trashcan.gif	One arm opens, the other gets the trash inside. Leon Hubby, Kevin Reichs.
tshirt.gif	A t-shirt with the Robot Group logo on it.
varmint.gif	Another picture of Varmint.
virtualbbal.gif	Virtual Basketball, by Karen Pittman and John Witham. (Hey, Jordan came to play!)
zoo.gif		The robotic zoo, by Tim Shedridan. Sparky the dog barking.
