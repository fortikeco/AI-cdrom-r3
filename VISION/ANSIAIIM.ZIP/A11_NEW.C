/* This program was written by Mike Fleischmann of Optical Publishing, Inc.
	Copyright 1993 Optical Publishing, Inc. All rights reserved.
	Redistribution and use in source and binary form are freely permitted
	provided that the above copyright notice appears in all documentation.
	
	THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESSED OR IMPLIED
	WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
	MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. By installing this 
	software, you agree to hold Optical Publishing, Inc. harmless for any 
	damages resulting from the use of this software.
*/

/* The program was copyrighted to allow you to know the source of the code. 
	This way if you need to contact us, you at least know the company name.
	We are in based in Ft. Collins, Colorado at (303)-226-3466.
	Our intention is to allow you to use, modify, copy and redistribute this
	code as well as integrate it into your applications at no charge or 
	royalties of any kind. Our only request is that if you use sections of 
	this code in your products, you include a 'Portions Copyright 1993 Optical
	Publishing, Inc. All rights reserved.' in your documentation. That's it, 
	we want to make this standard as easy to use as possible and giving away
	working code seemed the best way to do it.
*/

/***********************************************************************
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!      NOTE NOTE NOTE    !!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	This version has proposed changes that affect table A.1 in annex A of
	the standard. Although this change is likely to be approved please 
	contact AIIM for confirmation of the approval.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
/***********************************************************************/

/* although this program was developed to generate the examples in appendix
	E of the ANSI/AIIM MS53-199x standard it would work as a primitive 
	import routine. This program should compile with either Borland C or 
	Microsoft C. The tab spacing was set to 4.
	
	This was not written to be the most efficient code but rather as a  
	demo of the A11 standard encoding. Also, there is minimal error checking
	a full implementation would have extensive error checking.


	The program's calling parameters are GEN_A11 filename.ext where
		filename.ext is the name of the control file.
	The control file is in the format keyword=value. All values are in HEX!!
	NOTE: all the keywords are not necessary if you are excluding the area
	where they are used. i.e. clipping.

	keywords are (case insensitive):
		infile		the input image file
		outfile		the output image file name. (an extension .A11 is suggested)
		length		the length of the data file
		c4			the last digit in the c1 c2 c3 c4 encoding string
		cp			the compression flag
		lp			the line progression 
		pp			the pel path
		ps			the pel spaces value
		rl			the raster ratio for line spacing
		rp			the raster ratio for pel spacing
		sl			the spacing length
		string		the user string. (note this can span lines needs to be 
					ended with the tilda (~) character.
		dh			horizontal block dimensions
		dv			vertical block dimensions
		fx			first X clipping coord in BMUs
		fy			first Y clipping coord in BMUs
		hp			horizontal page dimensions in BMUs
		nl			number of lines (if known)
		ph			horizontal starting position in BMUs
		pl			number of pels per line
		pv			vertical starting position in BMUs 
		sx			second X clipping coord in BMUs
		sy			secong Y clipping coord in BMUs
		vp			vertical page dimensions in BMUs
*/

/****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define LEN_A1_NARY (sizeof(a1_nary))
#define LEN_A2 (sizeof(a2))
#define LEN_A3_NARY (sizeof(a3_nary))
#define LEN_A4 (sizeof(a4))

unsigned char a1_nary[]={	/* fixed portion of a1 */
	0x84,0x05,
		0x2a,0x86,0x48,0xce,0x1c,
	0xa5,0x06,
		0x06,0x04,
			0x58,0x02,0x07,0x02,
		0x86,0x01,
			0x00,
	0xa8,0x4e,
		0x43,0x40,
			0x43,0x43,0x49,0x54,0x54,0x20,0x52,0x65,0x63,0x2e,
			0x20,0x54,0x2e,0x34,0x31,0x30,0x20,0x73,0x65,0x72,
			0x69,0x65,0x73,0x20,0x28,0x31,0x39,0x39,0x32,0x29,
			0x20,0x7c,0x20,0x49,0x53,0x4f,0x2f,0x49,0x45,0x43,
			0x20,0x38,0x36,0x31,0x33,0x3a,0x31,0x39,0x39,0x33,
			0x3b,0x20,0x76,0x65,0x72,0x73,0x69,0x6f,0x6e,0x20,
			0x32,0x2e,0x30,0x30,
		0x44,0x0a,
			0x31,0x39,0x39,0x32,0x2d,0x30,0x35,0x2d,0x30,0x31,
	0xaa,0x10,
		0xa0,0x0e,
			0x80,0x04,
				0x58,0x02,0x07,0x02,
			0xaa,0x06,
				0x86,0x04,
					0x58,0x03,0x07,0x06
	};

unsigned char a2[]={		/* The document layout root  fixed content */
					0xa2,0x0d,
						0x02,0x01,
							0x00,
						0x31,0x08,
							0x41,0x01,
								0x31,
							0xa0,0x03,
								0x12,0x01,
									0x30
					};

unsigned char a3_nary[]={	/* fixed portion of a3 */
		0x41,0x03,
			0x31,0x20,0x30,
		0xa0,0x03,
			0x12,0x01,
				0x30,
			0xaf,0x06,
				0x80,0x01,
					0x00,
				0x80,0x01,
					0x00
	};

unsigned char a4[]={		/* The document layout root  fixed content */
					0xa2,0x11,
						0x02,0x01,
							0x03,
						0x31,0x0c,
							0x41,0x05,
								0x31,0x20,0x30,0x20,0x30,
							0xa0,0x03,
								0x12,0x01,
									0x30
					};

unsigned char c1[]={0x58,0x03,0x07,0xff};	/* the c1c2c3c4 param */
unsigned char cp=0xff;		/* compression set to invalid value */
unsigned char lp=0xff;		/* line progression set to invalid value */
unsigned char pp=0xff;		/* pel path set to invalid character */
unsigned char ps=0;	/* pel spaces (invalid value)*/
unsigned char rl=0;	/* raster ratio line spacing (invalid value) */
unsigned char rp=0;	/* raster ratio pel spacing (invalid value) */
unsigned char sl=0;	/* spacing length (invalid value) */
char str1[510];			/* the variable length string. (512 bytes max) */

long dh=0;				/* horizontal block dimensions in BMUs */
long dv=0;				/* vertical block dimensions in BMUs */
long fx=0;				/* first x clipping coord in BMUs */
long fy=0;				/* first y clipping coord in BMUs */
long hp=0;				/* horizontal page dimensions in BMU's */
long nl=0;				/* number of lines */
long ph=0;				/* horizontal starting position in BMUs */
long pl=0;				/* number of pels per line */
long pv=0;				/* vertical starting position */
long sx=0;				/* second X clipping coord in BMUs */
long sy=0;				/* second Y clipping coord in BMUs */
long vp=0;				/* vertical page dimensions in BMUs */

long length=0;			/* length of the input data file */

FILE *fin;				/* handle for the input image file */
FILE *fout;				/* handle for the output A11 file */
FILE *ctrl;				/* the file handle for the control file */

unsigned char buff[0x8000];		/* work buffer */
unsigned char line[0x200];		/* line entry buffer */

char *keyword[]={
	"INFILE",
	"OUTFILE",
	"LENGTH",
	"C4",
	"CP",
	"LP",
	"PP",
	"PS",
	"RL",
	"RP",
	"SL",
	"STRING",
	"DH",
	"DV",
	"FX",
	"FY",
	"HP",
	"NL",
	"PH",
	"PL",
	"PV",
	"SX",
	"SY",
	"VP",
	"~~~"};		/* mark as the end */

#define INFILE 0
#define OUTFILE 1
#define LENGTH 2 
#define C4 3 
#define CP 4 
#define LP 5
#define PP 6
#define PS 7
#define RL 8
#define RP 9 
#define SL 10
#define STRING 11
#define DH 12
#define DV 13
#define FX 14
#define FY 15
#define HP 16
#define NL 17
#define PH 18
#define PL 19
#define PV 20
#define SX 21
#define SY 22
#define VP 23


void Get_Line(void);
int Char2val(int);
long Get_Hex(char *);
Read_Control(void);
Do_In_Fun(int,char *);
int Gen_Lxx(int,unsigned long);		/* gen the format lxx table 5*/
int Gen_Len(int,unsigned long);		/* gen the format lxx table 4*/
Do_A1(void);		/* this and the following will build the data from
					the end
					*/ 
Do_A3(void);
Do_A5c(void);
Do_A5(int,int);		/* first int is current, second int is scpe loc */
Do_A6d(void);
Do_A6i(void);



int main(argc,argv)
int argc;
char *argv[];
{
	int rtn;		/* used for function return checking */

	str1[0]=' ';	/* guarentee at least a comment */
	str1[1]=0;	/* guarentee at least a comment */
	if(argc<2)
	{
		printf("calling parameters are A11_NEW ctrlfile.ext\n");
		printf(" where ctrlfile.ext is the controll file. See source code for\n");
		printf(" more information\n");
		exit(0);
	}
	
	ctrl=fopen(argv[1],"r");
	if(ctrl==NULL)
	{
		printf("unable to open the controll file >%s<\n",argv[1]);
		exit(0);
	}
	
	rtn=Read_Control();			/* read the control file in */
	if(rtn)		/* if an error */
	{
		printf("error reading controll file. Program ending\n");
		exit(0);
	}
	rtn=Do_A1();		/* go and do the a.1 table */
	if(rtn)		/* if an error */
	{
		printf("error in generation of the A.1 header table. Program ending\n");
		exit(0);
	}

	rtn=fwrite(a2,1,LEN_A2,fout);		/* output the a2 table */
	if(rtn!=LEN_A2)		/* if an error */
	{
		printf("error in writing A.2 table. Program ending\n");
		exit(0);
	}

	rtn=Do_A3();		/* go and do the a.3 table */
	if(rtn)		/* if an error */
	{
		printf("error in generation of the A.3 header table. Program ending\n");
		exit(0);
	}

	rtn=fwrite(a4,1,LEN_A4,fout);		/* output the a4 table */
	if(rtn!=LEN_A4)		/* if an error */
	{
		printf("error in writing A.4 table. Program ending\n");
		exit(0);
	}

	if(fx!=0 || fy!=0 || sx!=0 || sy!=0)
	{
		/* if here we have clipping */
		rtn=Do_A5c();		/* go and do the a.5 table for clipping */
		if(rtn)		/* if an error */
		{
			printf("error in generation of the A.51 header table. Program ending\n");
			exit(0);
		}
	}
	else
	{
		rtn=Do_A5(0x400,0x400);		/* go and do the a.5 table for no clipping*/
		if(rtn)		/* if an error */
		{
			printf("error in generation of the A.3 header table. Program ending\n");
			exit(0);
		}
	}

	if(length>0)		/* definite length */
	{
		rtn=Do_A6d();		/* go and do the a.6 table */
		if(rtn)		/* if an error */
		{
			printf("error in generation of the A.6 table. Program ending\n");
			exit(0);
		}
	}
	else	/* indefinite length */
	{
		rtn=Do_A6i();		/* go and do the a.6 table */
		if(rtn)		/* if an error */
		{
			printf("error in generation of the A.6 table. Program ending\n");
			exit(0);
		}
	}

	fclose(fout);
	fclose(fin);
	fclose(ctrl);
	printf("File build finished\n");
	return(0);
}

void Get_Line()
{
	int i;		/* temp work variable */

	fgets(line,0x200,ctrl);
	i=strlen(line);
	for(i--;i>0 && line[i]<=' ';line[i--]=0) ;  /* remove trailing crlf */
	
	/* turn to uppercase */
	for(i=0;line[i] && line[i]!='=';line[i]=toupper(line[i]),i++);
	if(memcmp(line,"STRING",6)!=0)	/* skip string case */
		for(;line[i];line[i]=toupper(line[i]),i++);

}

int Char2val(ch)
int ch;
{
	if(ch<='9')
		ch-='0';
	else
		ch = ch-'A'+10;
	return(ch);
}

long Get_Hex(str)
char *str;
{
	long l1;
	int i;
	
	for(i=0;str[i]<=' ' && str[i];i++);	/* ignore leading white space */

	for(i=0,l1=0;isxdigit(str[i]);i++)
	{
		l1<<=4;
		l1+=(long)Char2val(str[i]);
	}
	return(l1);
}

Read_Control()
{
	/* this will read in the control file and initialize the variables */
	char *cptr,*cptr1;		/* temp char pointer used for parsing */
	int i,j,k;
	
	Get_Line();		/* input the line */
	while(!feof(ctrl))
	{
		cptr=line;
		while(cptr[0]==' ')		/* skip leading spaces */
			cptr++;
		cptr1=strchr(cptr,'=');
		if(cptr1!=NULL)		/* if null treat as comment field */
		{
			/* if here have something to work with */
			cptr1[0]=0;		/* mark end */
			cptr1++;
			i=strlen(cptr);		/* get the length of compare string  */
			for(j=0;keyword[j][0]!='~';j++)
			{
				if(memcmp(cptr,keyword[j],i)==0)
				{
					k=Do_In_Fun(j,cptr1);
					if(k)
						return(k);		/* return if error */
					break;
				}
			}
		}
		Get_Line();		/* input the line */
	}
	return(0);		/* return valid processing */
}

Do_In_Fun(fun,str)
int fun;		/* the function number to do */
char *str;		/* the remaining string */
{
	int i,j;
	char *cptr;
	
	switch(fun)
	{
		case INFILE:
			fin=fopen(str,"rb");		/* open the input image file */
			if(fin==NULL)
				return(INFILE+1);
			break;
		case OUTFILE:
			fout=fopen(str,"wb");		/* open the output A11 file */
			if(fout==NULL)
				return(OUTFILE+1);
			break;
		case LENGTH:
			length=Get_Hex(str);		/* get the length */
			if(length<1)
				return(LENGTH+1);
			break;
		case C4:
			c1[3]=(char)Get_Hex(str);	/* get the c4 character */
			if(c1[3]>8)
				return(C4+1);
			break;
		case CP:
			cp=(char)Get_Hex(str);	/* get the cp character */
			if(cp<0 || cp>1)
				return(CP+1);
			break;
		case LP:
			lp=(char)Get_Hex(str);	/* get the lp character */
			if(lp!=1 && lp!=3)
				return(LP+1);
			break;
		case PP:
			pp=(char)Get_Hex(str);	/* get the pp character */
			if(pp<0 || pp>3)
				return(PP+1);
			break;
		case PS:
			ps=(char)Get_Hex(str);	/* get the ps character */
			if(ps==0)
				return(PS+1);
			break;
		case RL:
			rl=(char)Get_Hex(str);	/* get the cp character */
			if(rl==0)
				return(RL+1);
			break;
		case RP:
			rp=(char)Get_Hex(str);	/* get the cp character */
			if(rp==0)
				return(RP+1);
			break;
		case SL:
			sl=(char)Get_Hex(str);	/* get the cp character */
			if(sl==0)
				return(SL+1);
			break;
		case STRING:
			j=0;
			cptr=str;
			while(1)
			{
				for(i=0;cptr[i] && cptr[i]!='~' && j<500;i++)
					str1[j++]=cptr[i];
				if(j>499 || cptr[i]=='~')	/* done entering string */
					break;
				Get_Line();
				if(feof(ctrl))
					return(STRING+1);
				cptr=line;
			}
			str1[j++]=0;		/* null terminate */
			break;
		case DH:
			dh=Get_Hex(str);	/* get the dh value */
			if(dh<1)
				return(DH+1);
			break;
		case DV:
			dv=Get_Hex(str);	/* get the dv value */
			if(dv<1)
				return(DV+1);
			break;
		case FX:
			fx=Get_Hex(str);	/* get the fx value */
			break;
		case FY:
			fy=Get_Hex(str);	/* get the fy value */
			break;
		case HP:
			hp=Get_Hex(str);	/* get the hp value */
			if(hp<1)
				return(HP+1);
			break;
		case NL:
			nl=Get_Hex(str);	/* get the nl value */
			if(nl<1)
				return(NL+1);
			break;
		case PH:
			ph=Get_Hex(str);	/* get the ph value */
			if(dh<0)
				return(PH+1);
			break;
		case PL:
			pl=Get_Hex(str);	/* get the pl value */
			if(pl<1)
				return(PL+1);
			break;
		case PV:
			pv=Get_Hex(str);	/* get the pv value */
			break;
		case SX:
			sx=Get_Hex(str);	/* get the sx value */
			break;
		case SY:
			sy=Get_Hex(str);	/* get the sy value */
			break;
		case VP:
			vp=Get_Hex(str);	/* get the vp value */
			if(vp<1)
				return(VP+1);
			break;
		default:
			return(-1);
	}
    return(0);
}

int Gen_Lxx(cur,val)		/* gen the format table 5 */
int cur;		/* current position in buff */
unsigned long val;		/* value to insert */
{
	
	if(val <0x80L)	/* single byte */
	{
		buff[cur]=(unsigned char) val & 0xff;
		return(1);
	}
	else if(val <0x100L)	/* single byte */
	{
		buff[cur]=(unsigned char) val & 0xff;
		buff[cur-1]=0x81;
		return(2);
	}
	else if(val <0x10000L)	/* 2 bytes */
	{
		buff[cur]=(unsigned char) val & 0xff;
		buff[cur-1]=(unsigned char) (val>>8) & 0xff;
		buff[cur-2]=0x82;
		return(3);
	}
	else if(val <0x1000000L)	/* 3 bytes */
	{
		buff[cur]=(unsigned char) val & 0xff;
		buff[cur-1]=(unsigned char) (val>>8) & 0xff;
		buff[cur-2]=(unsigned char) (val>>16) & 0xff;
		buff[cur-3]=0x83;
		return(4);
	}
	else	/* 4 bytes */
	{
		buff[cur]=(unsigned char) val & 0xff;
		buff[cur-1]=(unsigned char) (val>>8) & 0xff;
		buff[cur-2]=(unsigned char) (val>>16) & 0xff;
		buff[cur-3]=(unsigned char) (val>>24) & 0xff;
		buff[cur-4]=0x84;
		return(5);
	}
}

int Gen_Len(cur,val)		/* gen the format table 4 */
int cur;		/* current position in buff */
unsigned long val;		/* value to insert */
{
	
	if(val <0x100L)	/* single byte */
	{
		buff[cur]=(unsigned char) val & 0xff;
		buff[cur-1]=1;
		return(2);
	}
	else if(val <0x10000L)	/* 2 bytes */
	{
		buff[cur]=(unsigned char) val & 0xff;
		buff[cur-1]=(unsigned char) (val>>8) & 0xff;
		buff[cur-2]=2;
		return(3);
	}
	else if(val <0x1000000L)	/* 3 bytes */
	{
		buff[cur]=(unsigned char) val & 0xff;
		buff[cur-1]=(unsigned char) (val>>8) & 0xff;
		buff[cur-2]=(unsigned char) (val>>16) & 0xff;
		buff[cur-3]=3;
		return(4);
	}
	else	/* 4 bytes */
	{
		buff[cur]=(unsigned char) val & 0xff;
		buff[cur-1]=(unsigned char) (val>>8) & 0xff;
		buff[cur-2]=(unsigned char) (val>>16) & 0xff;
		buff[cur-3]=(unsigned char) (val>>24) & 0xff;
		buff[cur-4]=4;
		return(5);
	}
}

Do_A1()		/* this and the following will build the data from the end 
			towards the front */
{
	int a1_end=0x400;
	int cur=0x400;
	int dend;
	int nend;
	int pt8;
	int pt7;
	int pt3;
	int i;
	
	i=strlen(str1);
	i--;
	while(i>=0)		/* copy the users string */
	{
		buff[cur--]=str1[i--];
	}

	cur-=Gen_Lxx(cur,a1_end-cur);		/* do the LDR section */
	buff[cur--]=0x43;
	
	cur-=Gen_Lxx(cur,a1_end-cur);		/* do the LD3 section */
	buff[cur--]=0xa5;
	
	cur-=Gen_Lxx(cur,a1_end-cur);		/* do the LD2 section */
	buff[cur--]=0xa7;
	
	cur-=Gen_Lxx(cur,a1_end-cur);		/* do the LD1 section */
	buff[cur--]=0xa3;
	dend=cur;		/* mark the current position */
	
	i=LEN_A1_NARY;
	i--;
	while(i>=0)		/* copy the fixed array stuff */
	{
		buff[cur--]=a1_nary[i--];
	}
	nend=cur;		/* mark position of a1_end byte */
	
	buff[cur--]=ps;
	buff[cur--]=1;
	buff[cur--]=2;

	buff[cur--]=sl;
	buff[cur--]=1;
	buff[cur--]=2;
	buff[cur--]=6;
	buff[cur--]=0xa0;
	buff[cur--]=8;
	buff[cur--]=0xa5;
	
	buff[cur--]=lp;
	buff[cur--]=1;
	buff[cur--]=0x8a;
	
	buff[cur--]=pp;
	buff[cur--]=1;
	buff[cur--]=0x89;
	buff[cur--]=0x10;
	buff[cur--]=0xa4;
	
	buff[cur--]=cp;
	buff[cur--]=1;
	buff[cur--]=0x80;
	buff[cur--]=3;
	buff[cur--]=0xa3;

	pt8=cur;
	buff[cur--]=0;
	buff[cur--]=1;
	buff[cur--]=2;
	pt7=cur;
	
	cur-=Gen_Len(cur,vp);		/* do the vp */
	buff[cur--]=0x80;

	cur-=Gen_Len(cur,hp);		/* do the hp */
	buff[cur--]=0x80;

	cur-=Gen_Lxx(cur,pt7-cur);		/* do the L13 */
	buff[cur--]=0x30;
	
	cur-=Gen_Lxx(cur,pt8-cur);		/* do the LNP */
	buff[cur--]=0x30;
	
	cur-=Gen_Lxx(cur,pt8-cur);		/* do the LMT */
	buff[cur--]=0xa8;
	pt3=cur;
	
	cur-=Gen_Len(cur,vp);		/* do the vp */
	buff[cur--]=0x80;

	cur-=Gen_Len(cur,hp);		/* do the hp */
	buff[cur--]=0x80;

	cur-=Gen_Lxx(cur,pt3-cur);		/* do the L12 */
	buff[cur--]=0x30;
	
	cur-=Gen_Lxx(cur,pt3-cur);		/* do the L11 */
	buff[cur--]=0xa2;
	
	cur-=Gen_Lxx(cur,nend-cur);		/* do the LND */
	buff[cur--]=0xa2;
	buff[cur--]=0x00;
	buff[cur--]=0x01;
	buff[cur--]=0x81;
	
	cur-=Gen_Lxx(cur,dend-cur);		/* do the LDC*/
	buff[cur--]=0xa2;
	buff[cur--]=0x31;
	buff[cur--]=0x01;
	buff[cur--]=0x81;
	
	cur-=Gen_Lxx(cur,a1_end-cur);		/* do the LDP*/
	buff[cur--]=0xa0;
	
	i=fwrite(&buff[cur+1],1,a1_end-cur,fout);
	if(i!=a1_end-cur)
		return(1);
	return(0);
}

Do_A3()
{
	int a3_end=0x400;
	int cur=0x400;
	int a3_nend;
	int a3_mt;
	int a3_nps;
	int a3_pde;
	int a3_pds;
	int a3_body;
	int a3_start;
	int i;
	
	buff[cur--]=0;
	buff[cur--]=1;
	buff[cur--]=2;
	a3_nend=cur;
	
	cur-=Gen_Len(cur,vp);		/* do the vp */
	buff[cur--]=0x80;

	cur-=Gen_Len(cur,hp);		/* do the hp */
	buff[cur--]=0x80;
	a3_nps=cur;

	cur-=Gen_Lxx(cur,a3_nend-a3_nps);		/* do the LN3 */
	buff[cur--]=0x30;
	a3_mt=cur;
	
	cur-=Gen_Lxx(cur,a3_end-a3_mt);		/* do the LM3 */
	buff[cur--]=0xb0;
	a3_pde=cur;
	
	cur-=Gen_Len(cur,vp);		/* do the vp */
	buff[cur--]=0x80;

	cur-=Gen_Len(cur,hp);		/* do the hp */
	buff[cur--]=0x80;
	a3_pds=cur;

	cur-=Gen_Lxx(cur,a3_pde-a3_pds);		/* do the LPD */
	buff[cur--]=0xa4;

	i=LEN_A3_NARY;
	i--;
	while(i>=0)		/* copy the fixed array stuff */
	{
		buff[cur--]=a3_nary[i--];
	}
	a3_body=cur;		/* mark position */
	cur-=Gen_Lxx(cur,a3_end-a3_body);		/* do the LAB */
	buff[cur--]=0x31;
	buff[cur--]=0x02;
	buff[cur--]=0x01;
	buff[cur--]=0x02;


	a3_start=cur;		/* mark position of a1_end byte */

	cur-=Gen_Lxx(cur,a3_end-a3_start);		/* do the LA3 */
	buff[cur--]=0xa2;

	i=fwrite(&buff[cur+1],1,a3_end-cur,fout);
	if(i!=a3_end-cur)
		return(1);
	return(0);
}

Do_A5c()
{
	int a5_end=0x400;
	int cur=0x400;
	int a5_dime;
	int a5_scpe;
	int a5_fcpe;
	
	
	if(nl<1)		/* if we don't know the number of lines (required for clp)*/
	{
		return(1);		/* return the error */
	}

	cur-=Gen_Len(cur,pv);		/* do the pv */
	buff[cur--]=0x80;

	cur-=Gen_Len(cur,ph);		/* do the ph */
	buff[cur--]=0x80;

	cur-=Gen_Lxx(cur,a5_end-cur);		/* do the LPS */
	buff[cur--]=0xa3;
	a5_dime=cur;

	cur-=Gen_Len(cur,dv);		/* do the dv */
	buff[cur--]=0x80;

	cur-=Gen_Len(cur,dh);		/* do the dh */
	buff[cur--]=0x80;

	cur-=Gen_Lxx(cur,a5_dime-cur);		/* do the LDM */
	buff[cur--]=0xa4;
	a5_scpe=cur;

	cur-=Gen_Len(cur,sy);		/* do the sy */
	buff[cur--]=0x2;

	cur-=Gen_Len(cur,sx);		/* do the sx */
	buff[cur--]=0x2;

	cur-=Gen_Lxx(cur,a5_scpe-cur);		/* do the LSP */
	buff[cur--]=0xa1;
	a5_fcpe=cur;

	cur-=Gen_Len(cur,fy);		/* do the fy */
	buff[cur--]=0x2;

	cur-=Gen_Len(cur,fx);		/* do the fx */
	buff[cur--]=0x2;

	cur-=Gen_Lxx(cur,a5_fcpe-cur);		/* do the LFP */
	buff[cur--]=0xa0;

	cur-=Gen_Lxx(cur,a5_scpe-cur);		/* do the LFP */
	buff[cur--]=0xa4;

	return(Do_A5(cur,a5_scpe));
}

Do_A5(cur,a5_scpe)
int	cur;			/* current position in the buffer */
int a5_scpe;		/* scpe position in the buffer */
{
	int i;
	int a5_end=0x400;
	static char pa_data[]={6,4,0x58,2,7,2};
	static unsigned char db_data[]={
							0x41,7,0x31,0x20,0x30,0x20,0x30,0x20,0x30,
							0xa1,3,0x12,1,0x30
						};
	
	buff[cur--]=rp;			/* pel spacing ratio */
	buff[cur--]=0x1;
	buff[cur--]=0x2;
	
	buff[cur--]=rl;			/* pel spacing ratio */
	buff[cur--]=0x1;
	buff[cur--]=0x2;
	
	buff[cur--]=0x6;
	buff[cur--]=0xa6;
	
	buff[cur--]=ps;			/* pel spaces */
	buff[cur--]=0x1;
	buff[cur--]=0x2;
	
	buff[cur--]=sl;			/* spacing length */
	buff[cur--]=0x1;
	buff[cur--]=0x2;
	
	buff[cur--]=0x6;
	buff[cur--]=0xa0;
	
	buff[cur--]=0x8;		/* pel spacing */
	buff[cur--]=0xa5;
	
	buff[cur--]=lp;			/* line progression */
	buff[cur--]=0x1;
	buff[cur--]=0x81;
	
	buff[cur--]=pp;			/* pel path */
	buff[cur--]=0x1;
	buff[cur--]=0x80;
	
	cur-=Gen_Lxx(cur,a5_scpe-cur);		/* do the LRG */
	buff[cur--]=0xa1;

	for(i=sizeof(pa_data)-1;i>=0;i--)
	{
		buff[cur--]=pa_data[i];
	}
	
	cur-=Gen_Lxx(cur,a5_scpe-cur);		/* do the LPA */
	buff[cur--]=0xa6;

	for(i=sizeof(db_data)-1;i>=0;i--)
	{
		buff[cur--]=db_data[i];
	}
	
	cur-=Gen_Lxx(cur,a5_end-cur);		/* do the LDB */
	buff[cur--]=0x31;

	buff[cur--]=0x4;		/* pel spacing */
	buff[cur--]=0x1;		/* pel spacing */
	buff[cur--]=0x2;		/* pel spacing */
	
	cur-=Gen_Lxx(cur,a5_end-cur);		/* do the LDL */
	buff[cur--]=0xa2;

	i=fwrite(&buff[cur+1],1,a5_end-cur,fout);
	if(i!=a5_end-cur)
		return(1);
	return(0);
}

Do_A6d()
{
	int a6_end=0x400;
	long a6_tend;
	int cur=0x400;
	int i;
	unsigned int u1,u2;
	int a6_t1;
	static unsigned char cpa_data[]={
			0x40,0x09,0x31,0x20,0x30,0x20,0x30,0x20,0x30,0x20,0x30,
			0x86,0x4};
	
	a6_tend=0x400+length;		/* calc the end of the data */
	
	cur-=Gen_Lxx(cur,a6_tend-cur);		/* do the LCN */
	buff[cur--]=0x04;
	a6_t1=cur;
	
	if(nl)		/* if we know the number of lines */
	{
		cur-=Gen_Len(cur,nl);		/* do the nl */
		buff[cur--]=0x81;
	}
	
	cur-=Gen_Len(cur,pl);		/* do the pl */
	buff[cur--]=0x80;
	
	buff[cur--]=cp;		/* do the compression */
	buff[cur--]=0x1;
	buff[cur--]=0x82;
	
	cur-=Gen_Lxx(cur,a6_t1-cur);		/* do the LRC */
	buff[cur--]=0xa2;
	
	for(i=3;i>=0;i--)
	{
		buff[cur--]=c1[i];
	}
	
	for(i=sizeof(cpa_data)-1;i>=0;i--)
	{
		buff[cur--]=cpa_data[i];
	}
	
	cur-=Gen_Lxx(cur,a6_t1-cur);		/* do the LCA */
	buff[cur--]=0x31;
	
	cur-=Gen_Lxx(cur,a6_tend-cur);		/* do the LA6*/
	buff[cur--]=0xa3;
	
	i=fwrite(&buff[cur+1],1,a6_end-cur,fout);
	if(i!=a6_end-cur)
		return(1);
	
	u1=fread(buff,1,0x8000,fin);
	while(u1>0)
	{
		
		u2=fwrite(buff,1,u1,fout);
		if(u2!=u1)
			return(2);
		u1=fread(buff,1,0x8000,fin);
	}
	return(0);
}
Do_A6i()
{
	int a6_end=0x400;
	int cur=0x400;
	int i;
	unsigned int u1,u2;
	int a6_t1;
	static unsigned char cpa_data[]={
			0x40,0x09,0x31,0x20,0x30,0x20,0x30,0x20,0x30,0x20,0x30,
			0x86,0x4};
	
	buff[cur--]=0x80;
	buff[cur--]=0x04;
	a6_t1=cur;
	
	if(nl)		/* if we know the number of lines */
	{
		cur-=Gen_Len(cur,nl);		/* do the nl */
		buff[cur--]=0x81;
	}
	
	cur-=Gen_Len(cur,pl);		/* do the pl */
	buff[cur--]=0x80;
	
	buff[cur--]=cp;		/* do the compression */
	buff[cur--]=0x1;
	buff[cur--]=0x82;
	
	cur-=Gen_Lxx(cur,a6_t1-cur);		/* do the LRC */
	buff[cur--]=0xa2;
	
	for(i=3;i>=0;i--)
	{
		buff[cur--]=c1[i];
	}
	
	for(i=sizeof(cpa_data)-1;i>=0;i--)
	{
		buff[cur--]=cpa_data[i];
	}
	
	cur-=Gen_Lxx(cur,a6_t1-cur);		/* do the LCA */
	buff[cur--]=0x31;
	
	buff[cur--]=0x80;
	buff[cur--]=0xa3;
	
	i=fwrite(&buff[cur+1],1,a6_end-cur,fout);
	if(i!=a6_end-cur)
		return(1);
	
	u1=fread(buff,1,0x8000,fin);
	while(u1>0)
	{
		
		u2=fwrite(buff,1,u1,fout);
		if(u2!=u1)
			return(2);
		u1=fread(buff,1,0x8000,fin);
	}
	for(i=0;i<4;buff[i++]=0);
	u2=fwrite(buff,1,4,fout);
	if(u2!=4)
		return(3);
	
	return(0);
}

	
	
	

