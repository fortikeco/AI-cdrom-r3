// This may look like C code, but it is really -*- C++ -*-
/*
 ************************************************************************
 *
 *			   Grayscale Image
 *
 *    Write the image into the file in the  Portable GrayMap (pgm) format
 * 
 * The program writes a "binary" (RAWBITS) pgm file of the following format
 *   - A "magic number" for identifying the file type.  A pgm
 *     file's RAWBITS magic number is the two characters "P5".
 *   - Whitespace (blanks, TABs, CRs, LFs).
 *   - A width, formatted as ASCII characters in decimal.
 *   - Whitespace.
 *   - A height, again in ASCII decimal.
 *   - Whitespace.
 *   - The maximum gray value, again in ASCII decimal. For RAWBITS pgm file
 *	   the maximum grayscale value cannot exceed 255.
 *   - A _single_ character of whitespace (typically a newline).
 *   - Width * height gray values, each as plain bytes, between
 *     0 and the specified maximum value, stored consecutivly, 
 *     starting at the top-left corner of the graymap, proceding in normal
 *     English reading order. 
 *     A value of 0 means black, and the maximum value means white.
 *
 * For more detail, see documentation on PBMPLUS package (specifically,
 * pgm(5)).
 *
 * $Id: write_pgm.cc,v 1.1 1994/01/12 20:57:02 oleg Exp oleg $
 *
 ************************************************************************
 */

#include "image.h"
#include "endian_io.h"

#include <iostream.h>

#pragma implementation

/*
 *------------------------------------------------------------------------
 *			   Class PGMFile
 *	 designed to contain the control info about the image
 *		as defined in the Portable GrayMap file 
 */

class PGMWFile : public EndianIO
{
friend class IMAGE;

private:
  int pixmap_width;			// Dimensions of the graymap
  int pixmap_height;
  int max_gray_value;			// Maximum value of a graymap pixel

  const IMAGE& image;			// Image being processed
  const char * title;			// Title for the image in the file

  void write_image_data();

public:
  PGMWFile(const IMAGE& _image);	// Constructor
  ~PGMWFile()	{}			// Destructor
  void set_title(const char * user_title);
  void write_image(const char * file_name);
};

/*
 *------------------------------------------------------------------------
 *			Construct the PGMWFile
 *   by filling out the fields of the structure from the IMAGE 
 */

PGMWFile::PGMWFile(const IMAGE& _image) : image(_image)
{
  assure(image.q_depth() <= 8,
	 "Sorry, the program cannot write images with depth > 8");

  pixmap_width = image.q_ncols();
  pixmap_height = image.q_nrows();
  max_gray_value = (1<<image.q_depth())-1;
  title = image.q_name();
}

/*
 *------------------------------------------------------------------------
 *			Set up the title for the image
 * image.name == "" && user title == ""  ---> resulting title = ""
 * image.name != "" && user title == ""  ---> resulting title = image.name
 * image.name == "" && user title != ""  ---> resulting title = user title
 * image.name != "" && user title != ""  ---> 
 *			resulting title = "image name/user title"
 *
 * Note that XWdump::title has been already set to image.title.
 * If it is changed, the XWdump::header_size should be modified as well
 */

void PGMWFile::set_title(const char * user_title)
{
  if( strlen(user_title) == 0 )
    return;

  register int old_title_len = strlen(title);
  
  if( strlen(title) == 0 )		// No image title
    title = user_title;
  else
    title = 
     strcat(
      strcat(
       strcpy((char *)calloc(strlen(title)+1+strlen(user_title)+1,sizeof(char)),title),
       "/"),
      user_title);
}

/*
 *------------------------------------------------------------------------
 *		       Writing the Portable GrayMap
 */

void PGMWFile::write_image(const char * file_name)
{
  
  fstream::open(file_name,ios::out);
  					// Writing the header
  
  char buffer[80];
  sprintf(buffer,"P5\n%d %d\n%d\n",pixmap_width,pixmap_height,max_gray_value);
  
  register char * p;			// This poor thing is because of
  for(p=&buffer[0]; *p != '\0'; p++)	// buggy Think C++
    write_byte(*p);
    
  write_image_data();
  
  close();
}


/*
 *------------------------------------------------------------------------
 *			Write out the pixel matrix 
 *		  with 'bits_per_pixel'representation
 */

void PGMWFile::write_image_data()
{
  assert( max_gray_value < 256 );
  
  register int row, col;
  for( row = 0; row < pixmap_height; ++row )
    for( col = 0; col < pixmap_width; ++col )
      write_byte( image(row,col) );
}


/*
 *------------------------------------------------------------------------
 *			       Root modules 
 *		for writing the image and displaying it
 */

void IMAGE::write_pgm(const char * file_name,const char * title) const
{
  is_valid();

  message("\nPreparing a PGM file with name '%s'\n",file_name);
  PGMWFile pgmfile(*this);
  pgmfile.set_title(title);
  pgmfile.write_image(file_name);
}
