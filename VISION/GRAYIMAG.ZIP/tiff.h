// This may look like C code, but it is really -*- C++ -*-
/*
 ************************************************************************
 *
 * 			Tag Image File Format (TIFF)
 *
 * Based on Rev 5.0 from:
 *    Developer's Desk		Window Marketing Group
 *    Aldus Corporation		Microsoft Corporation
 *    411 First Ave. South	16011 NE 36th Way
 *    Suite 200			Box 97017
 *    Seattle, WA  98104	Redmond, WA  98073-9717
 *    206-622-5500		206-882-8080
 *
 * Copyright (c) 1988, 1990 by Sam Leffler.
 * All rights reserved.
 *
 * This file is provided for unrestricted use provided that this
 * legend is included on all tape media and as a part of the
 * software program in whole or part.  Users may copy, modify or
 * distribute this file at will.
 *
 * Severely modified to define classes of all important TIFF file
 * data structures, by me.
 *
 * $Id: tiff.h,v 1.2 1994/06/20 18:09:00 oleg Exp oleg $
 *
 ************************************************************************
 */

#ifndef _TIFF_
#define	_TIFF_

/*
 *------------------------------------------------------------------------
 *				TIFF file header
 * It is always written at the very beginning of the TIFF file
 */

class TIFFHeader
{
  unsigned short magic;		// magic number (defines byte order)
  unsigned short version;	// TIFF version number
  unsigned long  diroffset;	// byte offset to first directory

  const unsigned short TIFF_BIGENDIAN = 0x4d4d;	   // Interpretation of magic
  const unsigned short TIFF_LITTLEENDIAN = 0x4949;
  const unsigned short TIFF_VERSION = 42;	   // Interpretation of version

public:
  TIFFHeader(void) : magic(TIFF_BIGENDIAN), version(TIFF_VERSION),
		     diroffset(sizeof(*this)) // Meaning the DIR follows 
		     {}			      // immediately
  TIFFHeader(EndianIO& file);
  ~TIFFHeader(void) {}
  void write(EndianIO& file);
  unsigned long directory_offset(void) const { return diroffset; }
};

/*
 *------------------------------------------------------------------------
 *			TIFF Image File Directories 
 * are comprised of a table of field descriptors of the form shown below.  
 * The table is sorted in ascending order by tag.  The values associated 
 * with each entry are disjoint and may appear anywhere in the file (so 
 * long as they are placed on a word boundary).
 *
 * If the value is 4 bytes or less, then it is placed in the offset field 
 * to save space.  If the value is less than 4 bytes, it is left-justified 
 * in the offset field.
 */

class TIFFDirEntry
{
public:
  unsigned short tag;		// see below
  unsigned short type;		// data type; see below
  unsigned long  count;		// number of items; length in spec
  unsigned long  val_offset;	// byte offset to field data

protected:
  TIFFDirEntry(void) {}			// For use from derived classes only

public:
  enum DataType {
    BYTE = 1,			// 8-bit unsigned integer
    ASCII = 2,			// 8-bit bytes w/ last byte null
    SHORT = 3,			// 16-bit unsigned integer
    LONG = 4,			// 32-bit unsigned integer
    RATIONAL = 5		// 64-bit fractional (numerator+denominator)
    };

  TIFFDirEntry(const short _tag, const DataType _type, const long _count,
	       const long _value)
    : tag(_tag), type(_type), count(_count), val_offset(_value) {}


  ~TIFFDirEntry(void) {}
};

/* Types as defined in the TIFF standard for SUN3 */

typedef unsigned char  BYTE;         /* 8-bits */
typedef unsigned char  ASCII;        /* 8-bits */
typedef unsigned short SHORT;        /* 16 bits */
typedef unsigned int   LONG;         /* 32 bits */
typedef unsigned long  RATIONAL;     /* 2 LONG's numerator : denominator  */

#define INFINITY  99999

/*
 *------------------------------------------------------------------------
 * 			   TIFF Tag Definitions
 *
 * Those marked with a + are obsoleted by revision 5.0
 */
#define	TIFFTAG_SUBFILETYPE		254	/* subfile data descriptor   */
#define	    FILETYPE_REDUCEDIMAGE	0x1	/* reduced resolution version*/
#define	    FILETYPE_PAGE		0x2	/* one page of many	     */
#define	    FILETYPE_MASK		0x4	/* transparency mask	     */

#define	TIFFTAG_OSUBFILETYPE		255	/* +kind of data in subfile  */
#define	    OFILETYPE_IMAGE		1	/* full resolution image data*/
#define	    OFILETYPE_REDUCEDIMAGE	2	/* reduced size image data   */
#define	    OFILETYPE_PAGE		3	/* one page of many	     */

#define	TIFFTAG_IMAGEWIDTH		256	/* image width in pixels     */
#define	TIFFTAG_IMAGELENGTH		257	/* image height in pixels    */
#define	TIFFTAG_BITSPERSAMPLE		258	/* bits per channel (sample) */

#define	TIFFTAG_COMPRESSION		259	/* data compression technique*/
#define	    COMPRESSION_NONE		1	/* dump mode		     */
#define	    COMPRESSION_CCITTRLE	2	/* CCITT modified Huffman RLE*/
#define	    COMPRESSION_CCITTFAX3	3	/* CCITT Group 3 fax encoding*/
#define	    COMPRESSION_CCITTFAX4	4	/* CCITT Group 4 fax encoding*/
#define	    COMPRESSION_LZW		5	/* Lempel-Ziv  & Welch	     */
#define	    COMPRESSION_NEXT		32766	/* NeXT 2-bit RLE	     */
#define	    COMPRESSION_CCITTRLEW	32771	/* #1 w/ word alignment      */
#define	    COMPRESSION_PACKBITS	32773	/* Macintosh RLE	     */
#define	    COMPRESSION_THUNDERSCAN	32809	/* ThunderScan RLE 	     */
#define	    COMPRESSION_PICIO		32900	/* old Pixar picio RLE	     */
#define	    COMPRESSION_SGIRLE		32901	/* Silicon Graphics RLE      */

#define	TIFFTAG_PHOTOMETRIC		262	/* photometric interpretation*/
#define	    PHOTOMETRIC_MINISWHITE	0	/* min value is white	     */
#define	    PHOTOMETRIC_MINISBLACK	1	/* min value is black	     */
#define	    PHOTOMETRIC_RGB		2	/* RGB color model	     */
#define	    PHOTOMETRIC_PALETTE		3	/* color map indexed	     */
#define	    PHOTOMETRIC_MASK		4	/* holdout mask		     */
#define	    PHOTOMETRIC_DEPTH		32768	/* z-depth data		     */

#define	TIFFTAG_THRESHHOLDING		263	/* +thresholding used on data*/
#define	    THRESHHOLD_BILEVEL		1	/* b&w art scan		     */
#define	    THRESHHOLD_HALFTONE		2	/* or dithered scan	     */
#define	    THRESHHOLD_ERRORDIFFUSE	3	/* usually floyd-steinberg   */

#define	TIFFTAG_CELLWIDTH		264	/* +dithering matrix width   */
#define	TIFFTAG_CELLLENGTH		265	/* +dithering matrix height  */
#define	TIFFTAG_FILLORDER		266	/* +data order within a byte */
#define	    FILLORDER_MSB2LSB		1	/* most significant -> least */
#define	    FILLORDER_LSB2MSB		2	/* least significant -> most */

#define	TIFFTAG_DOCUMENTNAME		269	/* name of doc. image is from*/
#define	TIFFTAG_IMAGEDESCRIPTION	270	/* info about image	     */
#define	TIFFTAG_MAKE			271	/* scanner manufacturer name */
#define	TIFFTAG_MODEL			272	/* scanner model name/number */
#define	TIFFTAG_STRIPOFFSETS		273	/* offsets to data strips    */

#define	TIFFTAG_ORIENTATION		274	/* +image orientation	     */
#define	    ORIENTATION_TOPLEFT		1	/* row 0 top, col 0 lhs	     */
#define	    ORIENTATION_TOPRIGHT	2	/* row 0 top, col 0 rhs	     */
#define	    ORIENTATION_BOTRIGHT	3	/* row 0 bottom, col 0 rhs   */
#define	    ORIENTATION_BOTLEFT		4	/* row 0 bottom, col 0 lhs   */
#define	    ORIENTATION_LEFTTOP		5	/* row 0 lhs, col 0 top      */
#define	    ORIENTATION_RIGHTTOP	6	/* row 0 rhs, col 0 top      */
#define	    ORIENTATION_RIGHTBOT	7	/* row 0 rhs, col 0 bottom   */
#define	    ORIENTATION_LEFTBOT		8	/* row 0 lhs, col 0 bottom   */

#define	TIFFTAG_SAMPLESPERPIXEL		277	/* samples per pixel	     */
#define	TIFFTAG_ROWSPERSTRIP		278	/* rows per strip of data    */
#define	TIFFTAG_STRIPBYTECOUNTS		279	/* bytes counts for strips   */
#define	TIFFTAG_MINSAMPLEVALUE		280	/* +minimum sample value     */
#define	TIFFTAG_MAXSAMPLEVALUE		281	/* maximum sample value      */
#define	TIFFTAG_XRESOLUTION		282	/* pixels/resolution in x    */
#define	TIFFTAG_YRESOLUTION		283	/* pixels/resolution in y    */

#define	TIFFTAG_PLANARCONFIG		284	/* storage organization	     */
#define	    PLANARCONFIG_CONTIG		1	/* single image plane 	     */
#define	    PLANARCONFIG_SEPARATE	2	/* separate planes of data   */

#define	TIFFTAG_PAGENAME		285	/* page name image is from   */
#define	TIFFTAG_XPOSITION		286	/* x page offset of image lhs*/
#define	TIFFTAG_YPOSITION		287	/* y page offset of image lhs*/
#define	TIFFTAG_FREEOFFSETS		288	/* +byte offset to free block*/
#define	TIFFTAG_FREEBYTECOUNTS		289	/* +sizes of free blocks     */

#define	TIFFTAG_GRAYRESPONSEUNIT	290	/* gray scale curve accuracy */
#define	    GRAYRESPONSEUNIT_10S	1	/* tenths of a unit	     */
#define	    GRAYRESPONSEUNIT_100S	2	/* hundredths of a unit	     */
#define	    GRAYRESPONSEUNIT_1000S	3	/* thousandths of a unit     */
#define	    GRAYRESPONSEUNIT_10000S	4	/* ten-thousandths of a unit */
#define	    GRAYRESPONSEUNIT_100000S	5	/* hundred-thousandths	     */
#define	TIFFTAG_GRAYRESPONSECURVE	291	/* gray scale response curve */
#define	TIFFTAG_GROUP3OPTIONS		292	/* 32 flag bits		     */
#define	    GROUP3OPT_2DENCODING	0x1	/* 2-dimensional coding	     */
#define	    GROUP3OPT_UNCOMPRESSED	0x2	/* data not compressed	     */
#define	    GROUP3OPT_FILLBITS		0x4	/* fill to byte boundary     */
#define	TIFFTAG_GROUP4OPTIONS		293	/* 32 flag bits		     */
#define	    GROUP4OPT_UNCOMPRESSED	0x2	/* data not compressed	     */
#define	TIFFTAG_RESOLUTIONUNIT		296	/* units of resolutions	     */
#define	    RESUNIT_NONE		1	/* no meaningful units	     */
#define	    RESUNIT_INCH		2	/* english		     */
#define	    RESUNIT_CENTIMETER		3	/* metric		     */
#define	TIFFTAG_PAGENUMBER		297	/* page numbers of multi-page*/
#define	TIFFTAG_COLORRESPONSEUNIT	300	/* color scale curve accuracy*/
#define	    COLORRESPONSEUNIT_10S	1	/* tenths of a unit	     */
#define	    COLORRESPONSEUNIT_100S	2	/* hundredths of a unit	     */
#define	    COLORRESPONSEUNIT_1000S	3	/* thousandths of a unit     */
#define	    COLORRESPONSEUNIT_10000S	4	/* ten-thousandths of a unit */
#define	    COLORRESPONSEUNIT_100000S	5	/* hundred-thousandths	     */

#define	TIFFTAG_COLORRESPONSECURVE	301	/* RGB response curve	     */
#define	TIFFTAG_SOFTWARE		305	/* name & release	     */
#define	TIFFTAG_DATETIME		306	/* creation date and time    */
#define	TIFFTAG_ARTIST			315	/* creator of image	     */
#define	TIFFTAG_HOSTCOMPUTER		316	/* machine where created     */
#define	TIFFTAG_PREDICTOR		317	/* prediction scheme w/ LZW  */
#define	TIFFTAG_WHITEPOINT		318	/* image white point	     */
#define	TIFFTAG_PRIMARYCHROMATICITIES	319	/* primary chromaticities    */
#define	TIFFTAG_COLORMAP		320	/* RGB map for pallette image*/
#define	TIFFTAG_BADFAXLINES		326	/* lines w/ wrong pixel count*/
#define	TIFFTAG_CLEANFAXDATA		327	/* regenerated line info     */
#define	     CLEANFAXDATA_CLEAN		0	/* no errors detected 	     */
#define	     CLEANFAXDATA_REGENERATED	1	/* receiver regenerated lines*/
#define	     CLEANFAXDATA_UNCLEAN	2	/* uncorrected errors exist  */
#define	TIFFTAG_CONSECUTIVEBADFAXLINES	328	/* max consecutive bad lines */

		/* tags 32995-32999 are private tags registered to SGI 	     */
#define	TIFFTAG_MATTEING		32995	/* alpha channel is present  */

#endif /* _TIFF_ */
