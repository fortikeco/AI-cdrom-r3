// This may look like C code, but it is really -*- C++ -*-
/*
 ************************************************************************
 *
 *			   Grayscale Image
 *
 *	  Verify the class Rectangle member functions and friends
 *
 * $Id: vrectangle.cc,v 1.1 1992/08/20 14:31:52 oleg Exp $
 *
 ************************************************************************
 */

#include "image.h"
#include <builtin.h>
#include <ostream.h>

static IMAGE Test_image(16,32,8); //(256,512,8);

/*
 *----------------------------------------------------------------------
 * 	      		Image - Rectangle conversions
 */

static void verify_image_rectangle_conversions(void)
{
  cout << "\nVerify Rectangle to image conversions\n";

  const int pattern = 145;

  {
    cout << "\tVerify the clipped image has now nothing to do with the "
            " parent\n";
    Test_image = pattern;
    IMAGE im1 = Test_image.square_of(min(Test_image.q_nrows(),
					 Test_image.q_ncols()),rowcol(0,0));
    im1 += 1;
    assert( Test_image == pattern );

    IMAGE im2 ((Rectangle) Test_image);
    assert( im2 == Test_image );

    im2 += 1;
    assert( !(im2 == Test_image) );
    assert( Test_image == pattern );

    IMAGE im3 = Test_image.rectangle(rowcol(0,0),
				     rowcol(Test_image.q_nrows()-1,
					    Test_image.q_ncols()-1));
    assert( im3 == Test_image );
    Test_image -= 1;
    assert( !(im2 == Test_image) );
    assert( Test_image == pattern-1 );
    assert( im3 == pattern );
  }

  {
    cout << "\tCheck two different clippings from the image\n";
    Test_image = pattern;
    const int size = min(Test_image.q_nrows(),Test_image.q_ncols()) / 2;
    if( size > 3 )
    {
      Test_image.square_of(size,rowcol(1,3)) += 5;
      IMAGE im1(Test_image.rectangle(rowcol(0,2),rowcol(size-1,2+size-1)));
      im1 += 5;
      im1.rectangle(rowcol(1,1),rowcol(1+size-2,1+size-2)) -= 5;
      IMAGE im2(Test_image.square_of(size,rowcol(1,3)));
      assure( im1 == im2, "Image are different" );
    }
  }

  {
    cout << "\tCheck clipping 'degenerated' rectangles\n";

    IMAGE im1 = Test_image.rectangle(rowcol(0,0),
				     rowcol(0,Test_image.q_ncols()-1));
    assert( im1.q_nrows() == 1 && im1.q_ncols() == Test_image.q_ncols() );

    IMAGE im2 = Test_image.rectangle(rowcol(0,1),
				     rowcol(Test_image.q_nrows()-1,1));
    assert( im2.q_ncols() == 1 && im2.q_nrows() == Test_image.q_nrows() );
  }

  {
    cout << "\tImage-to-image assignments considered as rectangles\n";
    IMAGE im = Test_image;
    im.clear();
    Test_image = pattern;
    assert( !(Test_image == im) );
    Rectangle(im) = (Rectangle)Test_image;
    assert( Test_image == im );
    assert( im == pattern );
  }

  cout << "\nDone\n\n";
}


/*
 *----------------------------------------------------------------------
 * 	      Testing operations on square blocks of images
 */
					// Verify the pixels over the square
					// area have the value what is expected
static void verify_pixel_value_over_square
	(const int size, const rowcol rc, const GRAY val)
{
  register int i,j;
  for(i=rc.row(); i<rc.row()+size; i++)
    for(j=rc.col(); j<rc.col()+size; j++)
      if( Test_image(i,j) != val )
	_error("Pixel [%d,%d] has the value 0x%x different from expected 0x%x",
	       i,j,Test_image(i,j),val);

					// Test the values beyond the 
					// square area boundaries.
					// They are supposed to be different
  if( 
     ( rc.row() + size < Test_image.q_nrows() &&
       (i = rc.row()+size, j = rc.col()+size-1, Test_image(i,j) == val) ) ||
     ( rc.col() + size < Test_image.q_ncols() &&
       (i = rc.row()+size-1, j = rc.col()+size, Test_image(i,j) == val) ) ||
     ( rc.row() > 0 &&
       (i = rc.row()-1, j = rc.col(), Test_image(i,j) == val) ) ||
     ( rc.col() > 0 &&
       (i = rc.row(), j = rc.col()-1, Test_image(i,j) == val) )
   )
    _error("Pixel [%d,%d] beyond the square area has the same value 0x%x "
	   " as pixels within the area\n"
	   " The prev operation must have written beyond the square area",
	   i,j,val);
}

static void test_pixel_op_over_square(const int size)
{
  const int pattern = 154;
  register int i,j;

  cout << "\n\nTest reading/writing pixels and pixel modifications\n"
          "over square blocks\n\n";
  cout << "Size of the square block being tested " << size << "\n\n";

  Test_image.clear();

  cout << "\nBlock writing a pattern 0x" << hex(pattern) << "...\n";
  cout << "and performing the entire set of tests "
          "as for the whole image above ...";

  for(i=0; i<Test_image.q_nrows() - size; i+=5)
    for(j=0; j<Test_image.q_ncols() - size; j+=3)
    {
      Test_image.sure_within(rowcol(i,j));
      Test_image.square_of(size,rowcol(i,j)) = pattern;
      verify_pixel_value_over_square(size,rowcol(i,j),pattern);

      double sum;
      if( ( sum = sum_over(Test_image.square_of(size,rowcol(i,j))) ) !=
	  size*size*(double)pattern )
	_error("Total sum of all the pixels over the square %g differs "
	       "from the expected value %g",sum,size*size*(double)pattern);

      Test_image.square_of(size,rowcol(i,j)) ^= ((1<<GRAY_MAXBIT)-1);
      verify_pixel_value_over_square(size,rowcol(i,j),0xffff - pattern);

      const int test_val = 0x7e;
      Test_image.square_of(size,rowcol(i,j)) = test_val;
      verify_pixel_value_over_square(size,rowcol(i,j),test_val);

      Test_image.square_of(size,rowcol(i,j)) += 7;
      verify_pixel_value_over_square(size,rowcol(i,j),test_val+7);
      assure( Test_image >= 0, "Negative pixel unexpected");

      Test_image.square_of(size,rowcol(i,j)) -= 2*test_val;
      verify_pixel_value_over_square(size,rowcol(i,j),test_val+7-2*test_val);
      assure( !(Test_image > 0), "Non-Negative pixel unexpected");

      Test_image.square_of(size,rowcol(i,j)) -= -2*test_val+7;
      verify_pixel_value_over_square(size,rowcol(i,j),test_val);

      Test_image.square_of(size,rowcol(i,j)) |= 0x03;
      verify_pixel_value_over_square(size,rowcol(i,j),test_val | 0x03);

      Test_image.square_of(size,rowcol(i,j)) &= 0xff - 0x03;
      verify_pixel_value_over_square(size,rowcol(i,j),test_val & (0xff-0x03));

      Test_image.square_of(size,rowcol(i,j)) ^= 0x02;
      verify_pixel_value_over_square(size,rowcol(i,j),test_val);

      Test_image.square_of(size,rowcol(i,j)) *= 2;
      verify_pixel_value_over_square(size,rowcol(i,j),2*test_val);

      Test_image.square_of(size,rowcol(i,j)) <<= 1;
      verify_pixel_value_over_square(size,rowcol(i,j),4*test_val);

      Test_image.square_of(size,rowcol(i,j)) >>= 2;
      verify_pixel_value_over_square(size,rowcol(i,j),test_val);

      Test_image.square_of(size,rowcol(i,j)) = 0;
    }

  cout << "\nDone\n\n";
}


/*
 *----------------------------------------------------------------------
 * 	      Testing operations on rectangular blocks of images
 */
					// Verify the pixels in the rectangle
					// have the value what is expected
static void verify_pixel_value_over_rectangle
	(const rowcol uppleft, const rowcol lowright, const GRAY val)
{
  register int i,j;
  for(i=uppleft.row(); i<=lowright.row(); i++)
    for(j=uppleft.col(); j<=lowright.col(); j++)
      if( Test_image(i,j) != val )
	_error("Pixel [%d,%d] has the value 0x%x different from expected 0x%x",
	       i,j,Test_image(i,j),val);

					// Test the values beyond the 
					// rectangular area boundaries.
					// They ought to be different
  rowcol rc;
  if( 
     ( lowright.row()+1 < Test_image.q_nrows() &&
       Test_image(rc = lowright + rowcol(1,0)) == val ) ||
     ( lowright.col()+1 < Test_image.q_ncols() &&
       Test_image(rc = lowright + rowcol(0,1)) == val ) ||
     ( uppleft.row() > 0 &&
       Test_image(rc = uppleft - rowcol(1,0)) == val )  ||
     ( uppleft.col() > 0 &&
       Test_image(rc = uppleft - rowcol(0,1)) == val )
   )
    _error("Pixel [%d,%d] beyond the rectangular area has the same value 0x%x "
	   " as pixels within the area\n"
	   " The prev operation must have written beyond the square area",
	   rc.row(),rc.col(),val);
}

static void test_pixel_op_over_rectangle(const int nrows, const int ncols)
{
  const int pattern = 104;
  register int i,j;

  cout << "\n\nTest reading/writing pixels and pixel modifications\n"
          "over rectangular blocks " << nrows << " by " << ncols << "\n\n";

  Test_image.clear();

  cout << "\nBlock writing a pattern 0x" << hex(pattern) << "...\n";
  cout << "and performing the entire set of tests "
          "as for the whole image in vimage ...";

  for(i=0; i<Test_image.q_nrows() - nrows; i+=5)
    for(j=0; j<Test_image.q_ncols() - ncols; j+=3)
    {
      rowcol uppleft(i,j), lowright(i+nrows-1,j+ncols-1);
      Test_image.sure_within(uppleft);
      Test_image.sure_within(lowright);
      Test_image.rectangle(uppleft,lowright) = pattern;
      verify_pixel_value_over_rectangle(uppleft,lowright,pattern);

      double sum;
      if( ( sum = sum_over(Test_image.rectangle(uppleft,lowright)) ) !=
	  nrows*ncols*(double)pattern )
	_error("Total sum of all the pixels over the rectangle %g differs "
	       "from the expected value %g",sum,nrows*ncols*(double)pattern);

      Test_image.rectangle(uppleft,lowright) ^= ((1<<GRAY_MAXBIT)-1);
      verify_pixel_value_over_rectangle(uppleft,lowright,0xffff - pattern);

      const int test_val = 0x7e;
      Test_image.rectangle(uppleft,lowright) = test_val;
      verify_pixel_value_over_rectangle(uppleft,lowright,test_val);

      Test_image.rectangle(uppleft,lowright) += 7;
      verify_pixel_value_over_rectangle(uppleft,lowright,test_val+7);
      assure( Test_image >= 0, "Negative pixel unexpected");

      Test_image.rectangle(uppleft,lowright) -= 2*test_val;
      verify_pixel_value_over_rectangle(uppleft,lowright,
					test_val+7-2*test_val);
      assure( !(Test_image > 0), "Non-Negative pixel unexpected");

      Test_image.rectangle(uppleft,lowright) -= -2*test_val+7;
      verify_pixel_value_over_rectangle(uppleft,lowright,test_val);

      Test_image.rectangle(uppleft,lowright) |= 0x03;
      verify_pixel_value_over_rectangle(uppleft,lowright,test_val | 0x03);

      Test_image.rectangle(uppleft,lowright) &= 0xff - 0x03;
      verify_pixel_value_over_rectangle(uppleft,lowright,
					test_val & (0xff-0x03));

      Test_image.rectangle(uppleft,lowright) ^= 0x02;
      verify_pixel_value_over_rectangle(uppleft,lowright,test_val);

      Test_image.rectangle(uppleft,lowright) *= 2;
      verify_pixel_value_over_rectangle(uppleft,lowright,2*test_val);

      Test_image.rectangle(uppleft,lowright) <<= 1;
      verify_pixel_value_over_rectangle(uppleft,lowright,4*test_val);

      Test_image.rectangle(uppleft,lowright) >>= 2;
      verify_pixel_value_over_rectangle(uppleft,lowright,test_val);

      {
	IMAGE im(Test_image);
	im.rectangle(uppleft,lowright) = test_val;
	Test_image.rectangle(uppleft,lowright) = 0;
	Test_image.rectangle(uppleft,lowright) = 
	  im.rectangle(uppleft,lowright);
	verify_pixel_value_over_rectangle(uppleft,lowright,test_val);
      }	
	
      Test_image.rectangle(uppleft,lowright) = 0;
    }

  cout << "\nDone\n\n";
}

/*
 *------------------------------------------------------------------------
 *			The testing routing module
 */

main()
{
  verify_image_rectangle_conversions();

  test_pixel_op_over_square(Test_image.q_nrows());
  test_pixel_op_over_square(Test_image.q_nrows()/3);
  test_pixel_op_over_square(1);

  test_pixel_op_over_rectangle(Test_image.q_nrows(),Test_image.q_ncols());
  int size = min(Test_image.q_nrows(),Test_image.q_ncols());
  size = ( size > 2 ? size / 2 : size );
  test_pixel_op_over_rectangle(size,size);
  test_pixel_op_over_rectangle((size == 4 ? 5 : 4),size);
  test_pixel_op_over_rectangle(1,size);
  test_pixel_op_over_rectangle(size,1);
}

