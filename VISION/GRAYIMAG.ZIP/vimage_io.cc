// This may look like C code, but it is really -*- C++ -*-
/*
 ************************************************************************
 *
 *			   Grayscale Image
 *
 *	  	Verify reading/writing of various image formats
 *
 * $Id: vimage_io.cc,v 1.1 1994/02/07 15:50:58 oleg Exp oleg $
 *
 ************************************************************************
 */

#include "image.h"
#include <builtin.h>
#include <ostream.h>

static IMAGE Test_image(16,32,8); //(256,512,8);

					// Verify the pixels have the value
					// that is expected
static void verify_pixel_value(const GRAY val)
{
  register int i,j;
  for(i=0; i<Test_image.q_nrows(); i++)
    for(j=0; j<Test_image.q_ncols(); j++)
      if( Test_image(i,j) != val )
	_error("Pixel [%d,%d] has the value 0x%x different from expected 0x%x",
	       i,j,Test_image(i,j),val);
}

static char * Image_file_name = "/tmp/aa";

				// Write different kinds of image file formats
				// into the file named Image_file_name
static void write_xwd(const IMAGE& image)
{
  image.write_xwd(Image_file_name);
}

static void write_pgm(const IMAGE& image)
{
  image.write_pgm(Image_file_name);
}

static void write_tiff(const IMAGE& image)
{
  image.write_tiff(Image_file_name);
}

static void write_default(const IMAGE& image)
{
  image.write(Image_file_name);
}


				// Check reading and writing of a test image
static void test_image_io(void (*writer)(const IMAGE& image))
{
  cout << "\n\n\tWriting the Test_image and reading it back\n";
  Test_image = 154; Test_image(0,0) = 0; Test_image(1,0) = 1;
  writer(Test_image);
  IMAGE read_back(Image_file_name,1);
  Test_image -= read_back;
  verify_pixel_value(0);

  cout << "\nDone\n";
}

				// Test the I/O using a real image
static void real_image_io(const IMAGE& image, 
			  void (*writer)(const IMAGE& image))
{
  cout << "\n\n\tWriting a real image and reading it back\n";
  
  start_timer();
  writer(image);
  cout << "\nIt took " << return_elapsed_time(0) 
       << " sec to write the image\n";

  start_timer();
  IMAGE read_again_image(Image_file_name);
  cout << "\nIt took " << return_elapsed_time(0) 
      << " sec to read the image\n";
  assert( read_again_image == image );

  cout << "\nDone\n";
}



main(void)
{
  cout << "\n\nTest image input/output operations\n";

  test_image_io(write_xwd);
  test_image_io(write_pgm);
  test_image_io(write_tiff);
  test_image_io(write_default);

  IMAGE image("pictures/512.xwd");
  real_image_io(image,write_xwd);
  real_image_io(image,write_pgm);
  real_image_io(image,write_tiff);
  real_image_io(image,write_default);
}
