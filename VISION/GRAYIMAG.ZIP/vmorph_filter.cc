// This may look like C code, but it is really -*- C++ -*-
/*
 ************************************************************************
 *
 *			   Grayscale Image
 *
 * 		  Morphological filtration of the image
 *	
 *				Verification
 *
 ************************************************************************
 */

#include "morph_filter.h"

#include <ostream.h>


				// Verify the morphological filtration
				// for the pattern of size 1
static void test_pattern_size1(void)
{
  IMAGE im(7,7,8);
  IMAGE imt(im);
  BinaryPattern pattern(Square,1);

  cout << "\n\nMake sure that each morphological filtration operation"
          "\nwith the square pattern of size 1 yields the identical image\n";

  cout << "\nTest image is " << im.q_nrows() << "x" << im.q_ncols() <<
          "x" << im.q_depth();

  im.clear();
  im.square_of(2,rowcol(2,2)) = 2;
  imt = im;
  assert( (erosion(imt,pattern), imt == im) );
  assert( (dilation(imt,pattern), imt == im) );
  assert( (opening(imt,pattern), imt == im) );
  assert( (closing(imt,pattern), imt == im) );

  im.clear();
  im.square_of(3,rowcol(2,2)) = 2;
  imt = im;
  assert( (erosion(imt,pattern), imt == im) );
  assert( (dilation(imt,pattern), imt == im) );
  assert( (opening(imt,pattern), imt == im) );
  assert( (closing(imt,pattern), imt == im) );


  im.clear();
  im.square_of(4,rowcol(2,2)) = 2;
  imt = im;
  assert( (erosion(imt,pattern), imt == im) );
  assert( (dilation(imt,pattern), imt == im) );
  assert( (opening(imt,pattern), imt == im) );
  assert( (closing(imt,pattern), imt == im) );


  im(3,3) = 1; im(3,4) = 0;
  imt = im;
  assert( (erosion(imt,pattern), imt == im) );
  assert( (dilation(imt,pattern), imt == im) );
  assert( (opening(imt,pattern), imt == im) );
  assert( (closing(imt,pattern), imt == im) );

  cout << "\nDone\n";
}


				// Check out to see whether opening and
				// closing of the image containing boxes
				// with the box of the same size change
				// nothing

static void test_equal_by_equal_1(const int size)
{
  cout << "\nMake sure that opening and closing a box with the box of the same"
          "\nsize changes nothing\n";
  
  cout << "\nBox of the size " << size << " at the upper left corner"
          "\nof an image " << form("%dx%d",2*size+1,2*size+2);

  IMAGE im(2*size+1,2*size+2,8);
  BinaryPattern pattern(Square,size);
  im.clear();
  im.square_of(size,rowcol(0,0)) = 2;
  IMAGE imt(im), im_dil(im), im_er(im);

  im_dil.square_of(2*size-1,rowcol(0,0)) = 2;
  cout << "\nDilated box should have size " << 2*size+1;
  assert( (imt=im, dilation(imt,pattern), imt == im_dil) );

  im_er.square_of(1,rowcol(0,0)) = 2;
  cout << "\nErosed box should be reduced to a one point";
  assert( (imt=im, erosion(imt,pattern), imt == im_er) );

  cout << "\nClosing and opening should keep the box the same";
  assert( (imt=im, opening(imt,pattern), imt == im) );
  assert( (imt=im, closing(imt,pattern), imt == im) );

  cout << "\nDone\n";
}

static void test_equal_by_equal_2(const int size)
{
  cout << "\nMake sure that opening and closing a box with the box of the same"
          "\nsize changes nothing. But the image border has to be "
	  "kept in mind\n";
  
  cout << "\nBox of the size " << size << " at the lower right corner"
          "\nof an image " << form("%dx%d",2*size+1,2*size+2);

  IMAGE im(2*size+1,2*size+2,8);
  BinaryPattern pattern(Square,size);

  im.clear();
  im.square_of(size,rowcol(size+1,size+2)) = 3;
  IMAGE imt(im), im_dil(im), im_er(im);

  im_dil = im;
  cout << "\nDilated box is the same as the original one due to the clipping";
  assert( (imt=im, dilation(imt,pattern), imt == im_dil) );

  im_er.square_of(1,rowcol(size+1,size+2)) = 3;
  cout << "\nErosed box should be reduced to a one point";
  assert( (imt=im, erosion(imt,pattern), imt == im_er) );

  cout << "\nOpening is the same as erasing now";
  assert( (imt=im, opening(imt,pattern), imt == im_er) );

  cout << "\nClosing should keep the box the same";
  assert( (imt=im, closing(imt,pattern), imt == im) );

  cout << "\nDone\n";
}

				// Check to see that in case of the filter with
				// the size larger than the image box,
				// erosing eroses the box altogether,
				// and so does closing.
				// On the opposite, dilation expands
				// the box to the size n1+n2-1, and
				// opening returns the box to the original
				// size
				// Opening and closing boxes larger than the
				// filter size should keep them intact.
static void test_nonequal(const int size)
{
  cout << "\nVerifying filtration of boxes of different size\n";
  
  cout << "\nTwo boxes of the size " << size-1 << " and " << size+1 <<
          "\nin an image " << form("%dx%d",4*size+3,4*size+5);

  IMAGE im(5*size+3,5*size+5,8);
  BinaryPattern pattern(Square,size);

  im.clear();
  im.square_of(size-1,rowcol(1,1)) = 4;
  im.square_of(size+1,rowcol(3*size+1,2*size+3)) = 1;
  IMAGE imt(im), im_er(im), im_dil(im), im_cl(im);

				// Theoretical dilated image
  im_dil.square_of(2*size-2,rowcol(1,1)) = 4;
  im_dil.square_of(2*size,rowcol(3*size+1,2*size+3)) = 1;
  cout << "\nDilated boxes should be expanded ";
  assert( (imt=im, dilation(imt,pattern), imt == im_dil) );

				// Theoretical erosed image
  im_er.square_of(2,rowcol(3*size+1,2*size+3)) = 1;
  cout << "\nSmall box should disappear on erosion";
  assert( (imt=im, erosion(imt,pattern), imt == im_er) );

				// Theoretical opened image
  cout << "\nOpening should keep the boxes intact";
  assert( (imt=im, opening(imt,pattern), imt == im) );

  cout << "\nClosing erases the smaller box";
  im_cl.square_of(size+1,rowcol(3*size+1,2*size+3)) = 1;
  assert( (imt=im, closing(imt,pattern), imt == im_cl) );

  cout << "\nDone\n";
}

				// Root module
main()
{
  test_pattern_size1();

  test_equal_by_equal_1(2);
  test_equal_by_equal_1(5);
  test_equal_by_equal_2(5);
  test_equal_by_equal_2(15);

  test_nonequal(2);
  test_nonequal(5);
}
