// This may look like C code, but it is really -*- C++ -*-
/*
 ************************************************************************
 *
 *			Verify integer and bit I/O
 *
 ************************************************************************
 */

#include "endian_io.h"
#include <ostream.h>
#include <std.h>

/*
 *------------------------------------------------------------------------
 *			Reading and checking functions
 */

static void read_and_check_long(EndianIO& i_stream, const long ethalon)
{
  long read = i_stream.read_long("Reading a long integer");
  if( read != ethalon )
    _error("The read long int %d differs from what was expected %d",
	   read,ethalon);
}

static void read_and_check_short(EndianIO& i_stream, const short ethalon)
{
  short read = i_stream.read_short("Reading a short integer");
  if( read != ethalon )
    _error("The read short int %d differs from what was expected %d",
	   read,ethalon);
}

static void read_and_check_byte(EndianIO& i_stream, const char ethalon)
{
  char read = i_stream.read_byte("Reading a byte");
  if( read != ethalon )
    _error("The read byte %d differs from what was expected %d",
	   read,ethalon);
}

/*
 *------------------------------------------------------------------------
 *		Reading and writing ethalon patterns
 */

const unsigned long Pattern [] =
 { 1, (unsigned)-1, 0, 0xffff0000, 0x0000ffff, 0x5a5a5a5a, 0xa5a5a5a5 };

static void write_patterns(EndianIO& o_stream)
{
  {
    unsigned long * p = (unsigned long *)Pattern; 
    for(; (char *)p < (char *)Pattern + sizeof(Pattern); p++)
      o_stream.write_long(*p);
  }
  {
    unsigned short * p = (unsigned short *)Pattern; 
    for(; (char *)p < (char *)Pattern + sizeof(Pattern); p++)
      o_stream.write_short(*p);
  }
  {
    unsigned char * p = (unsigned char *)Pattern; 
    for(; (char *)p < (char *)Pattern + sizeof(Pattern); p++)
      o_stream.write_byte(*p);
  }
}

static void read_and_check_patterns(EndianIO& i_stream)
{
  {
    unsigned long * p = (unsigned long *)Pattern; 
    for(; (char *)p < (char *)Pattern + sizeof(Pattern); p++)
      read_and_check_long(i_stream,*p);
  }
  {
    unsigned short * p = (unsigned short *)Pattern; 
    for(; (char *)p < (char *)Pattern + sizeof(Pattern); p++)
      read_and_check_short(i_stream,*p);
  }
  {
    unsigned char * p = (unsigned char *)Pattern; 
    for(; (char *)p < (char *)Pattern + sizeof(Pattern); p++)
      read_and_check_byte(i_stream,*p);
  }
}

/*
 *------------------------------------------------------------------------
 *			Verify reading/writing integers in
 *		  littleendian mode (most significant byte last)
 */

static void test_littleendian()
{
  cout << "\n--> Test reading/writing integers in the littleendian mode\n";

  cout << "Opening the output stream to file /tmp/aa\n";
  EndianIO stream("/tmp/aa",ios::out);
  assert( stream.writable() && !stream.readable() );
  stream.set_littlendian();

  cout << "Writing patterns\n";
  write_patterns(stream);
  stream.close();

  cout << "Opening the file as a reading stream through cat\n";
  EndianIO istream;
  istream.open("cat /tmp/aa |",ios::in);
  assert( !istream.writable() && istream.readable() );
  istream.set_littlendian();

  cout << "Reading what we've written back\n";
  read_and_check_patterns(istream);
  istream.close();

  cout << "\nDone\n";
}

/*
 *------------------------------------------------------------------------
 *			Verify reading/writing integers in
 *		  bigendian mode (most significant byte first)
 */

static void test_bigendian()
{
  cout << "\n--> Test reading/writing integers in the bigendian mode\n";

  cout << "Opening the output stream to file /tmp/aa through cat\n";
  EndianIO stream("| cat > /tmp/aa",ios::out);
  assert( stream.writable() && !stream.readable() );
  stream.set_bigendian();

  cout << "Writing patterns\n";
  write_patterns(stream);
  stream.close();

  cout << "Opening the file as a reading stream straight\n";
  EndianIO istream;
  sleep(1);
  istream.open("/tmp/aa",ios::in);
  assert( !istream.writable() && istream.readable() );
  istream.set_bigendian();

  cout << "Reading what we've written back\n";
  read_and_check_patterns(istream);
  istream.close();

  cout << "\nDone\n";
}

/*
 *------------------------------------------------------------------------
 *		Test the mixed int/bit stream I/O
 */

static void test_int_bit_IO()
{
  cout << "\n--> Test mixed int/bit stream I/O with file attachments\n";

  cout << "Opening the output stream to file /tmp/aa through cat\n";
  EndianIO stream("| cat > /tmp/aa",ios::out);
  assert( stream.writable() && !stream.readable() );
  stream.set_bigendian();

  cout << "Writing integer patterns\n";
  write_patterns(stream);

  cout << "Attaching the bitstream\n";
  BitIO bitstream;
  bitstream.open(stream);
  assert( bitstream.writable() && !bitstream.readable() );

  cout << "Writing 8 bits of ones followed by 3*8 zero bits several times\n";
  register int i;
  for(i=0; i<5; i++)
  {
    register int i;
    for(i=0; i<8; i++)
      bitstream.put_bit(1);
    for(i=0; i<3*8; i++)
      bitstream.put_bit(0);
  }
  bitstream.put_bit(1);			// Put two extra bits
  bitstream.put_bit(1);
  bitstream.close();
  {
    cout << "Attaching the second bitstream\n";
    BitIO bitstream;
    bitstream.open(stream);
    assert( bitstream.writable() && !bitstream.readable() );

    cout << "Writing 8 bits of zeros followed by 3*8 one bits several times\n";
    register int i;
    for(i=0; i<5; i++)
    {
      register int i;
      for(i=0; i<8; i++)
	bitstream.put_bit(0);
      for(i=0; i<3*8; i++)
	bitstream.put_bit(1);
    }
    bitstream.put_bit(0);			// Put two extra bits
    bitstream.put_bit(1);
  }
  stream.close();

  cout << "Opening the file as a reading stream straight\n";
  EndianIO istream;
  sleep(1);
  istream.open("/tmp/aa",ios::in);
  assert( !istream.writable() && istream.readable() );
  istream.set_bigendian();

  cout << "Reading what we've written back\n";
  read_and_check_patterns(istream);

  cout << "Attaching the input bitstream\n";
  BitIO ibitstream;
  ibitstream.open(istream);
  assert( !ibitstream.writable() && ibitstream.readable() );

  system("ls -l /tmp/aa; od -x /tmp/aa");
  cout << "Reading the bit pattern\n";
  for(i=0; i<5; i++)
  {
    register int i;
    for(i=0; i<8; i++)
      assert( ibitstream.get_bit() == 1 );
    for(i=0; i<3*8; i++)
      assert( ibitstream.get_bit() == 0 );
  }
  assert( ibitstream.get_bit() == 1 );
  assert( ibitstream.get_bit() == 1 );
  ibitstream.close();
  {
    cout << "Attaching the second input bitstream\n";
    BitIO ibitstream;
    ibitstream.rdbuf()->sync();
    ibitstream.open(istream);
    assert( !ibitstream.writable() && ibitstream.readable() );

    cout << "Reading the bit pattern\n";
    for(i=0; i<5; i++)
    {
      register int i;
      for(i=0; i<8; i++)
	assert( ibitstream.get_bit() == 0 );
      for(i=0; i<3*8; i++)
	assert( ibitstream.get_bit() == 1 );
    }
    assert( ibitstream.get_bit() == 0 );
    assert( ibitstream.get_bit() == 1 );
  }
  cout << "\nDone\n";
}

/*
 *------------------------------------------------------------------------
 *			Root module
 */

main()
{
  cout << "\n\n\t\tVerify integer stream I/O in big/little endian modes"
          "\n\t\t\t\tand bit stream I/O\n\n";
  test_littleendian();
  test_bigendian();
  test_int_bit_IO();
}
