/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/

#define	MAXPOINTS	3
#define	NOT_A_POINT	(-9999)

typedef struct {
	int	x, y;
} Point;

struct object {
	ObjectType	type;
	int		state;
	Point		point[MAXPOINTS];
	char		*text;
	Set		subobjects;
	char		highlight;
};

void	Erase(), Draw();
void	EraseOn(), EraseOff();

void	LineDraw();
void	LineTransform();
int	LineDistance();

void	RectDraw();
void	RectTransform();
int	RectDistance();

void	TextDraw();
void	TextTransform();
int	TextDistance();

void	CircleDraw();
void	CircleTransform();
int	CircleDistance();

void	SetDraw();
void	SetTransform();
int	SetDistance();

Bool	AlwaysOK(), AlwaysBad(), VlinePoint();

extern struct dope {
	ObjectType	type;
	char		*name;
	int		npoints;
	Bool		(*point)();
	void		(*draw)();
	void		(*transform)();
	int		(*distance)();  /* actually distance squared */
} dope[];
