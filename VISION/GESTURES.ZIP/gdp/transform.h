/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/

typedef Matrix Transformation;

Transformation	AllocTran();	/* Only call which allocs mem */
Transformation	IdentityTran();	/* Transformation t;  sets t to identity */
Transformation	TranslateTran();/* Transformation t; int x, y; */
Transformation	RotateTran();	/* Transformation t; int degrees; */
Transformation	RotateCosSinTran(); /* Transformation t; double a*cosine,a*sine;*/
Transformation	ScaleTran(); 	/* Transformation t; double dilation; */

void	ApplyTran(); 		/* int x, y; Transformation t; int *xp, *yp; */
#define	ComposeTran(r, a, b) 	/* Transformation r, a, b;  r = a o b */ \
			(MatrixMultiply((a), (b), (r)), (r))
double	TransScale();		/* Transformation t; */

