/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
void StInit();
void StRedraw();
Element StNewObj();	/* ObjectType t; */
void StDelete(); 	/* Element e; */
void StUpdatePoint();	/* Element e; int point_number, x, y; */
void StMove();		/* Element e; int x, y; */
void StTransform();	/* Element e; Transformation t */
Element StPick();	/* int x, y */
Element StEdit();	/* Element e; */
Element StCopyElement();/* Element e; */


Set CopySet();
