/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
/*
  Operations on objects
 */

typedef struct object *Object;

typedef	enum {
	Nothing,
	Line,
	Vline,
	Rect,
	Vrect,
	Text,
	Circle,
	SetOfObjects,
} ObjectType;


Object	CreateObject();		/* ObjectType */

Bool	UpdatePoint();		/* Object; int which_point; int x, y; */

Object	CopyObject();
void	FreeObject();
