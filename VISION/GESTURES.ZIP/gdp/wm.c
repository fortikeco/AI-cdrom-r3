/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
/*
  interface from objects to window manager
*/

#include "bool.h"
#include "util.h"
#include "gdev.h"
#include <stdio.h>

void
WmClear()
{
	GDEVstart();
}

void
WmInit(program)
char *program;
{
	GDEVinit(NULL);
	GDEVsets("currentfunction", "xor");
	GDEVseti("thickness", 0);	/* gives fast line drawing */
	GDEVsets("program", program ? program : "Dean's window");
	WmClear();
}

WmFlush()
{
	GDEVflush();
}

void
EraseOn()
{ /* GDEVsets("currentcolor", "white"); */
}

void
EraseOff()
{
	/* GDEVsets("currentcolor", "black"); */
}
