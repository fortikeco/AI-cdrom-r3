typedef int Bool;

#ifndef TRUE

#	define TRUE	1
#	define FALSE	0

#endif
