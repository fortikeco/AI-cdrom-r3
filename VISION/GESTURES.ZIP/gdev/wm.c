/***********************************************************************

wm.c - WM (old andrew window manager) back end for GDEV graphics routines

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/


/*
  WM driver for GDEV device independent graphics routines

 Variables supported (assigned via GDEVsets):

   The following must be set after the call to GDEVinit but before the
   first call to GDEVstart:

	program  	name of program to use
	font 		name of font to use

   The following may be called at any time:

	currentcolor	"black" or "white"
	currentfunction	"copy" or "xor"   (xor doesn't seem to do anything
						useful though)


 */

#include "gdrv.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include "wmclient.h"

#ifndef TRUE
#	define TRUE 1
#	define FALSE  0
#endif


typedef int COORD;


program(graphics)
static struct wm_window *WMwin;
static	char *WMprogram = "graphics";
static	char *WMfont = "Gacha12";
static	int   mouseinterest = 0;
#define	MENU_CHAR	('a'&037)
#define	INIT_WIDTH	(-1.0)

static COORD Height, Width = INIT_WIDTH;

static WMcurrentcolor(), WMcurrentfunction(), WMinput();

WMinit()
{
	GDRVvar_addr("program", (Pointer) &WMprogram);
	GDRVvar_addr("font", (Pointer) &WMfont);
	GDRVvar_fcn("currentcolor", WMcurrentcolor, NULL);
	GDRVvar_fcn("currentfunction", WMcurrentfunction, NULL);
	GDRV00topleft();
	GDRVfdnotify(FD_POLL, WMinput);
}


WMstart()
{

	if(WMwin) {
		wm_ClearWindow();
		return;
	}
	/* first time */
	WMwin = wm_NewWindow(0);
	if(WMwin  == NULL)
		GDEVerror("No more windows from wm\n");
	GDRVfdnotify(fileno(winin), WMinput);
	wm_SetProgramName(WMprogram);
	wm_ClearWindow();
	WMSelectFont(WMfont);
	WMgetsizes();
	WMflush();
	GDRVrefresh();
}

static
WMgetsizes()
{
	wm_GetDimensions(&Width, &Height);
}

WMflush()
{
	fflush(winout);
}

WMstop()
{
	WMflush();
}

WMline(x1, y1, x2, y2)
COORD x1, y1, x2, y2;
{
#ifdef DEBUG
	printf("line %g %g  %g %g\n", x1, y1, x2, y2);
#endif
	wm_MoveTo((int) x1, (int) y1);
	wm_DrawTo((int) x2, (int) y2);
}


WMrect(xpos, ypos, x2, y2)
COORD xpos, ypos, x2, y2;
{
	COORD height = y2 - ypos;
	COORD width = x2 - xpos;
	wm_FillTrapezoid((int)xpos, (int)ypos, (int)width, 
		(int)xpos, (int)y2, (int)width,  -1, 020);
}

WMtext(x, y, text)
COORD x, y;
char *text;
{
#ifdef DEBUG
	printf("text %g %g %s\n", x, y,text);
#endif
	wm_DrawString((int) x, (int)y, wm_AtLeft | wm_AtBaseline, text);
}

WMpoint(x, y)
COORD x, y;
{
	int thickness = 1;
#ifdef DEBUG
	printf("point  %g %g\n", x, y);
#endif
	wm_FillTrapezoid((int)x, (int)y, (int)thickness, (int)x, 
		(int)(y + thickness), (int)thickness,  -1, 020);
}
WMsetdim(w, h)
COORD w, h;
{
}

WMgetdim(wp, hp)
COORD *wp, *hp;
{
	COORD ox = Width, oy = Height;

	WMgetsizes();

	if(ox != INIT_WIDTH && (ox != Width || oy != Height))
		printf("WM: Size changed unexpectedly!\n");
	/* If the above printf never comes up, we can get rid of the call to
	   WMgetsizes and everything else above this line */

	*wp = Width;
	*hp = Height;
}

WMmenuitem(itemname, retval, addflag)
char *itemname;
int retval;
int addflag;
{
    int r, r2;
    char item[300];


    if(addflag) {
	sprintf(item, "%s,%s:%c%c", WMprogram, itemname, MENU_CHAR, retval);
	wm_AddMenu(item);
    }
    else {
	sprintf(item, "%s,%s", WMprogram, itemname, retval);
	wm_AddMenu(item);
   }
}

WMmouseinterest(event)
int event;
{
	register oldinterest = mouseinterest;

	switch(event) {
	case MOUSE_EVENT(MIDDLE_BUTTON, DOWN_TRANSITION):
	case MOUSE_EVENT(MIDDLE_BUTTON, UP_TRANSITION):
	case MOUSE_EVENT(MIDDLE_BUTTON, DOWN_MOVEMENT):
		printf("WM: middle button reserved for menus\n"); break;
	case MOUSE_EVENT(LEFT_BUTTON, DOWN_TRANSITION):
		mouseinterest |= MouseMask(LeftButton, DownTransition); break;
	case MOUSE_EVENT(RIGHT_BUTTON, DOWN_TRANSITION):
		mouseinterest |= MouseMask(RightButton, DownTransition); break;
	case MOUSE_EVENT(LEFT_BUTTON, UP_TRANSITION):
		mouseinterest |= MouseMask(LeftButton, UpTransition); break;
	case MOUSE_EVENT(RIGHT_BUTTON, UP_TRANSITION):
		mouseinterest |= MouseMask(RightButton, UpTransition); break;
	case MOUSE_EVENT(LEFT_BUTTON, DOWN_MOVEMENT):
		mouseinterest |= MouseMask(LeftButton, DownMovement); break;
	case MOUSE_EVENT(RIGHT_BUTTON, DOWN_MOVEMENT):
		mouseinterest |= MouseMask(RightButton, DownMovement); break;
	}
	wm_SetMouseInterest(mouseinterest);
}

static
WMinput()
{
	FILE *rf[1];
	register int c;
	struct timeval timeout;

	timeout.tv_sec = 0;
	timeout.tv_usec = 0;
	rf[0] = winin;
	if(fselect(1, rf, 0, 0, &timeout) <= 0)
		return;

	switch(c = getc(winin)) {
	case wm_MouseInputToken:
		WMmouseinput();
		break;
	case MENU_CHAR:
		GDRVmenu(getc(winin));
		break;
	default:
		GDRVputc(c);
		break;
	}
}

WMmouseinput()
{
	register int event;
	int act, x, y;

	wm_SawMouse(&act, &x, &y);
	switch(act) {
	case MouseMask(LeftButton, DownTransition):
		event = MOUSE_EVENT(LEFT_BUTTON, DOWN_TRANSITION); break;
	case MouseMask(RightButton, DownTransition):
		event = MOUSE_EVENT(RIGHT_BUTTON, DOWN_TRANSITION); break;
	case MouseMask(LeftButton, UpTransition):
		event = MOUSE_EVENT(LEFT_BUTTON, UP_TRANSITION); break;
	case MouseMask(RightButton, UpTransition):
		event = MOUSE_EVENT(RIGHT_BUTTON, UP_TRANSITION); break;
	case MouseMask(LeftButton, DownMovement):
		event = MOUSE_EVENT(LEFT_BUTTON, DOWN_MOVEMENT); break;
	case MouseMask(RightButton, DownMovement):
		event = MOUSE_EVENT(RIGHT_BUTTON, DOWN_MOVEMENT); break;
	}
	GDRVmouse(event, x, y, 0);
}

FlagRedraw(op, win)
struct wm_window *win;
{
	WMgetsizes();
	GDRVrefresh();
}

static
WMcurrentcolor(var, value, arg)
char *var, *value, *arg;
{
	switch(value[0]) {
	case 'w':	wm_SetFunction(f_white);	break;
	default:	wm_SetFunction(f_black);	break;
	}
}

static
WMcurrentfunction(var, value, arg)
char *var, *value, *arg;
{
	switch(value[0]) {
	case 'x':	wm_SetFunction(f_invert);	break;
	default:	wm_SetFunction(f_copy);		break;
	}
}

static
WMeventstring(var, value, arg)
char *var, *value, *arg;
{
	switch(*value) {
	default:
		printf("WMeventstring(%s,%s)???\n", var, value);
		break;
	}
}

static
WMSelectFont(name)
char *name;
{
	register struct font *f;
	static struct font *Gacha12b;

	if(Gacha12b == NULL)
		Gacha12b = wm_DefineFont("Gacha12b");
	if((f = wm_DefineFont(name)) == NULL) {
		printf("Can't find font %s\n", name);
		f = Gacha12b;
	}
	wm_SelectFont(f);
}

