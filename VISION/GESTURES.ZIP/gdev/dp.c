/***********************************************************************

dp.c - DP back end for GDEV graphics routines

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
#include <stdio.h>
#include "gdrv.h"

#define	UNIT	(1<<7)		/* factor used for roundoff */

typedef int COORD;

typedef struct gfile {
	int gdevhandle;
	FILE *f;
	char *dpfile;
	int thickness;
	int font;
} *Gfile;

#define MAXFILES	10
static struct gfile gfiles[MAXFILES];
static int nfiles;

/*
  GDEV driver for dp output

	
	Variables recognized:
		dpfile 		name of file to write
		dptext		inserts text directly into the dp file
		dpfont		integer representing dp font (see table below)
		thickness	thickness of lines
 */

#define	DEFAULT_THICKNESS	1
#define	DEFAULT_FONT		1

static struct {
	char	*font, *perq;
} fonts[] = {
	{ "r 7 0 Courier", "6x10" },		/* font 1 */
	{ "r 8 0 Courier", "6x13" },		/* font 2 */
	{ "r 10 0 Courier", "8x13" },		/* font 3 */
	{ "r 12 0 Courier", "9x15" },		/* font 4 */
	{ "r 10 0 Helvetica", "helv10" },	/* font 5 */
	{ "b 10 0 Helvetica", "helv10b" },	/* font 6 */
	{ "r 12 0 Helvetica", "helv12" },	/* font 7 */
	{ "i 12 0 Helvetica", "helv12i" },	/* font 8 */
	{ "b 12 0 Helvetica", "helv12b" },	/* font 9 */
	{ "r 10 0 Times", "timrom10" },		/* font 10 */
	{ "i 10 0 Times", "timrom10i" },	/* font 11 */
	{ "b 10 0 Times", "timrom10b" },	/* font 12 */
	{ "r 12 0 Times", "timrom12" },		/* font 13 */
	{ "i 12 0 Times", "timrom12i" },	/* font 14 */
	{ "b 12 0 Times", "timrom12b	" },	/* font 15 */
};


static int  DPinserttext();
static int  DPdpfile();
static int  DPthickness();
static int  DPdpfont();

static int filecount = 0;

Pointer
DPinit(gdevhandle) int gdevhandle;
{
	register Gfile g;

	if(nfiles == 0) {	/* first time called */
		GDRVvar_fcn(gdevhandle, "dptext", DPinserttext, NULL);
		GDRVvar_fcn(gdevhandle, "dpfile", DPdpfile, NULL);
		GDRVvar_fcn(gdevhandle, "thickness", DPthickness, NULL);
		GDRVvar_fcn(gdevhandle, "dpfont", DPdpfont, NULL);
	}
	if(nfiles >= MAXFILES)
		GDEVerror("DPinit: too many open files");
	g = &gfiles[nfiles++];
	g->gdevhandle = gdevhandle;
	g->thickness = DEFAULT_THICKNESS;
	g->font = DEFAULT_FONT;
	return (Pointer) g;
}

DPstart(g)
register Gfile g;
{
	long time(), t;
	int i;

	if(g->f == NULL) {
		char filename[50];
		if(g->dpfile == NULL) {
			sprintf(filename, "dp%d.out", filecount++);
			g->dpfile = filename;
		}
		printf("Creating %s\n", g->dpfile);
		g->f = fopen(g->dpfile, "w");
		if(g->f == NULL)
			GDEVerror("DPstart: Can't create %s\n", g->dpfile);

		fprintf(g->f, "; DP ver. 5.89\n");
		time(&t);
		fprintf(g->f, "; Created by GDEV at %s", ctime(&t));
		for(i = 0; i < sizeof(fonts)/sizeof(fonts[0]); i++)
			fprintf(g->f, "@font %d %s\n@perqFont %d %s\n",
				i+1, fonts[i].font, i+1, fonts[i].perq);
		fprintf(g->f, "@layer 1 STANDARD RWO\n");
	}
}

DPstop(g) Gfile g;
{
	if(g->f) fclose(g->f);
	g->f = NULL;
	g->dpfile = NULL;
}

DPflush(g) Gfile g;
{
	if(g->f) fflush(g->f);
}

DPline(g, x1, y1, x2, y2)
Gfile g;
int x1, y1, x2, y2;
{
	fprintf(g->f, "L %d %d %d %d %d 1 1048577 1\n",
		x1, y1, x2, y2, g->thickness);
}

DPpoint(g, x, y)
Gfile g;
int x, y;
{
	int x1 = x - g->thickness/2;
	DPline(g, x1, y, x1 + g->thickness, y);
}

DPrect(g, x1, y1, x2, y2)
Gfile g;
int x1, y1, x2, y2;
{
	DPline(g, x1, y1, x2, y1);
	DPline(g, x2, y1, x2, y2);
	DPline(g, x2, y2, x1, y2);
	DPline(g, x1, y2, x1, y1);
}

DPtext(g, x, y, txt)
Gfile g;
int x, y;
char *txt;
{
	/* cheats, since it doesn't calc bounding box of string */
	fprintf(g->f, "S %d %d %d %d %d 1 1 %s\n", x, y, x, y, g->font, txt);
}

DPsetdim(g, x, y)
Gfile g;
int x, y;
{
	/* ignored */
}

DPgetdim(g, x, y)
Gfile g;
int *x, *y;
{
	*x = 6*UNIT; *y = 6*UNIT;
}

static int
DPinserttext(g, var, text, arg)
Gfile g;
char *var, *text, *arg;
{
	fprintf(g->f, "%s", text);
}

static
DPthickness(g, var, value, arg) Gfile g; char *var; int value; char *arg; {
	g->thickness = value;
}

static
DPdpfile(g, var, value, arg) Gfile g; char *var, *value, *arg; {
	g->dpfile = value;
}

static
DPdpfont(g, var, value, arg) Gfile g; char *var; int value; char *arg; {
	g->font = value;
}

