/***********************************************************************

ps.c - Postscript back end for GDEV graphics routines

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
#include <stdio.h>
#include "gdrv.h"

#define	UNIT	10000			/* COORD is thousandth of an inch */

typedef int COORD;

static	int xdim = (72*13)/2, ydim = 72*9;

/* per file structure */

typedef struct gfile {
	int gdevhandle;
	FILE *f;
	char *psfile;
	COORD height, width;
	int pagenumber;
} *Gfile;

#define MAXFILES	10
static struct gfile gfiles[MAXFILES];
static int nfiles;

/*
  GDEV driver for ps output

	
	Variables recognized:
		psfile 	name of file to write
		pstext	inserts text directly into the ps file
*/

static int  PSinserttext();
static int  PSpsfile();
static int  PSthickness();

Pointer
PSinit(gdevhandle) int gdevhandle;
{
	register Gfile g;

	if(nfiles == 0) {	/* first time called */
		GDRVvar_fcn(gdevhandle, "pstext", PSinserttext, NULL);
		GDRVvar_fcn(gdevhandle, "psfile", PSpsfile, NULL);
		GDRVvar_fcn(gdevhandle, "thickness", PSthickness, NULL);
	}
	if(nfiles >= MAXFILES)
		GDEVerror("PSinit: too many open files");
	g = &gfiles[nfiles++];
	g->gdevhandle = gdevhandle;
	g->width = xdim;
	g->height = ydim;
	g->pagenumber = 0;
	return (Pointer) g;
}

PSstart(g)
register Gfile g;
{
	if(g->f == NULL) {
		char filename[50];
		if(g->psfile == NULL) {
			sprintf(filename, "gdev%d.ps", g->gdevhandle);
			g->psfile = filename;
		}
		printf("Creating %s\n", g->psfile);
		g->f = fopen(g->psfile, "w");
		if(g->f == NULL)
			GDEVerror("PSstart: Can't create %s\n", g->psfile);
		PSprolog(g);
	}
	++g->pagenumber;
	PSpage(g);
}

PSprolog(g)
register Gfile g;
{
	static char *prolog[] = {
	"%!PS-Adobe-1.0",
	"%%Title: gdev.ps",
	"%%Creator: GDEV",
	"%%CreationDate: Whenever",
	"%%Pages: (atend)",
	"%%DocumentFonts: (atend)",
	"%%BoundingBox:  0 0 572 720",
	"%%EndComments",
	"/spoofdict 25 dict def",
	"spoofdict begin",
	"/bdf {bind def} bind def",
	"/ldf {load def} bdf",
	"/xdf {exch def} bdf",
	"/M /moveto ldf",
	"/RM /rmoveto ldf",
	"/L /lineto ldf",
	"/RL /rlineto ldf",
	"/dbeg {gsave dup scale 2 setlinecap /s 6 def} bdf",
	"/dplus {dbeg /s2 s 2 div def 0 s2 RM 0 s neg RL",
	"  s2 s2 RM s neg 0 RL stroke grestore} bdf",
	"/dcross {dbeg /s2 s 1.414 div def s2 2 div neg dup RM s2 s2 RL",
	"  0 s2 neg RM s2 neg s2 RL stroke grestore} bdf",
	"/dbox {dbeg /s2 s 1.414 div def s2 2 div neg dup RM s2 0 RL",
	"   0 s2 RL s2 neg 0 RL 0 s2 neg RL stroke grestore} bdf",
	"/ddiamond {dbeg /s2 s 2 div def 0 s2 RM s2 neg s2 neg RL",
	"  s2 s2 neg RL s2 s2 RL s2 neg s2 RL stroke grestore} bdf",
	"/dstar {dup gsave exch dplus grestore dcross} bdf",
	"/ddot {dbeg currentpoint s 2 div 0 360 arc fill grestore} bdf",
	"/pnt {gsave 1 setlinecap M 0 0 RL stroke grestore} bdf",
	"/xt {gsave 4 2 roll translate exch rotate} bdf",
	"/ltext {xt 0 0 M show grestore} bdf",
	"/rtext {xt dup stringwidth pop neg 0 M show grestore} bdf",
	"/ctext {xt dup stringwidth pop 2 div neg 0 M show grestore} bdf",
	"%%EndProlog",
	0
	};

	PSdump(g, prolog);
}

PSdump(g, p)
register Gfile g;
register char **p;
{
	while(*p)
		fprintf(g->f, "%s\n", *p++);
}

PSpage(g)
register Gfile g;
{

	static char *newpage[] = {
		"2 setlinecap",
		"0 setgray",
		"72 72 M",
		"1 setlinewidth",
		"[] 0 setdash",
		"72 72 translate",
		"/Times-Roman findfont 10 scalefont setfont",
		0
	};

	if(g->pagenumber > 1)
		fprintf(g->f, "showpage\n");
	fprintf(g->f, "%%%%Page: ? %d\n", g->pagenumber);
	PSdump(g, newpage);
}

PSstop(g)
register Gfile g;
{
	
	static char *epilog[] = {
		"showpage",
		"%%Trailer",
		"end",
		"%%DocumentFonts: Times-Roman",
		0
	};
	if(g->f) {
		PSdump(g, epilog);
		fprintf(g->f, "%%%%Pages: %d\n", g->pagenumber);
		fclose(g->f);
		g->f = NULL;
	}
}

PSflush(g) Gfile g;
{
	if(g->f) fflush(g->f);
}

PSline(g, x1, y1, x2, y2)
Gfile g;
int x1, y1, x2, y2;
{
	fprintf(g->f, "%d %d M %d %d L stroke\n", x1, y1, x2, y2);
}

PSpoint(g, x, y)
Gfile g;
int x, y;
{
	fprintf(g->f, "point %d %d\n", x, y);
	PSrect(x-1,y-1,x+1,y+1);
}

PSrect(g, x1, y1, x2, y2)
Gfile g;
int x1, y1, x2, y2;
{
	fprintf(g->f, "%d %d M %d %d L %d %d L %d %d L closepath fill\n",
		x1, y1, x1, y2, x2, y2, x2, y1);
}

PStext(g, x, y, txt)
Gfile g;
int x, y;
char *txt;
{
	fprintf(g->f, "%d %d 0 (%s) ltext\n", x, y, txt);
}

PSsetdim(g, x, y)
Gfile g;
int x, y;
{
	g->width = x; g->height = y;
	/*
	fprintf(g->f, "height=%g\n", g->width/(double) UNIT);
	fprintf(g->f, "width=%g\n", g->height/(double) UNIT);
	*/
}

PSgetdim(g, x, y)
Gfile g;
int *x, *y;
{
	*x = g->width; *y = g->height;
}

static int
PSinserttext(g, var, text, arg)
Gfile g;
char *var, *text, *arg;
{
	fprintf(g->f, "%s", text);
}

static
PSpsfile(g, var, value, arg)
Gfile g;
char *var, *value, *arg;
{
	g->psfile = value;
}

static
PSthickness(g, var, value, arg)
Gfile g; char *var; int value; char *arg;
{
	/*
	fprintf(g->f, "thickness=%d\n", value);
	*/
}

