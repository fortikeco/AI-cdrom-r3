/***********************************************************************

poof.c - spoof back end for GDEV graphics routines

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
#include <stdio.h>
#include "gdrv.h"

#define	UNIT	10000			/* COORD is thousandth of an inch */

typedef int COORD;

static	int xdim = 65000, ydim = 90000;	/* thousandths of inches */

/* per file structure */

typedef struct gfile {
	int gdevhandle;
	FILE *f;
	char *pooffile;
	COORD height, width;
	int pagenumber;
} *Gfile;

#define MAXFILES	10
static struct gfile gfiles[MAXFILES];
static int nfiles;

/*
  GDEV driver for poof output

	
	Variables recognized:
		pooffile 	name of file to write
		pooftext	inserts text directly into the poof file
*/

static int  POOFinserttext();
static int  POOFpooffile();
static int  POOFthickness();

Pointer
POOFinit(gdevhandle) int gdevhandle;
{
	register Gfile g;

	if(nfiles == 0) {	/* first time called */
		GDRVvar_fcn(gdevhandle, "pooftext", POOFinserttext, NULL);
		GDRVvar_fcn(gdevhandle, "pooffile", POOFpooffile, NULL);
		GDRVvar_fcn(gdevhandle, "thickness", POOFthickness, NULL);
	}
	if(nfiles >= MAXFILES)
		GDEVerror("POOFinit: too many open files");
	g = &gfiles[nfiles++];
	g->gdevhandle = gdevhandle;
	g->width = xdim;
	g->height = ydim;
	g->pagenumber = 0;
	return (Pointer) g;
}

POOFstart(g)
register Gfile g;
{
	if(g->f == NULL) {
		char filename[50];
		if(g->pooffile == NULL) {
			sprintf(filename, "poof%d.out", g->gdevhandle);
			g->pooffile = filename;
		}
		printf("Creating %s\n", g->pooffile);
		g->f = fopen(g->pooffile, "w");
		if(g->f == NULL)
			GDEVerror("POOFstart: Can't create %s\n", g->pooffile);
		fprintf(g->f, "verbose=no\n");
	}
	if(++g->pagenumber > 1)
		fprintf(g->f, "newpage\n");
}

POOFstop(g) Gfile g;
{
	if(g->f) fclose(g->f);
}

POOFflush(g) Gfile g;
{
	if(g->f) fflush(g->f);
}

POOFline(g, x1, y1, x2, y2)
Gfile g;
int x1, y1, x2, y2;
{
	fprintf(g->f, "line %d %d %d %d\n", x1, y1, x2, y2);
}

POOFpoint(g, x, y)
Gfile g;
int x, y;
{
	fprintf(g->f, "point %d %d\n", x, y);
}

POOFrect(g, x1, y1, x2, y2)
Gfile g;
int x1, y1, x2, y2;
{
	fprintf(g->f, "rect %d %d %d %d\n", x1, y1, x2, y2);
}

POOFtext(g, x, y, txt)
Gfile g;
int x, y;
char *txt;
{
	fprintf(g->f, "mltext %d %d\n%s\n", x, y, txt);
}

POOFsetdim(g, x, y)
Gfile g;
int x, y;
{
	g->width = x; g->height = y;
	fprintf(g->f, "height=%g\n", g->width/(double) UNIT);
	fprintf(g->f, "width=%g\n", g->height/(double) UNIT);
}

POOFgetdim(g, x, y)
Gfile g;
int *x, *y;
{
	*x = g->width; *y = g->height;
}

static int
POOFinserttext(g, var, text, arg)
Gfile g;
char *var, *text, *arg;
{
	fprintf(g->f, "%s", text);
}

static
POOFpooffile(g, var, value, arg)
Gfile g;
char *var, *value, *arg;
{
	g->pooffile = value;
}

static
POOFthickness(g, var, value, arg)
Gfile g; char *var; int value; char *arg;
{
	fprintf(g->f, "thickness=%d\n", value);
}

