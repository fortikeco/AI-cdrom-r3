/***********************************************************************

xdev.c - X10 back end for GDEV graphics routines

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
/*
  X driver for GDEV device independent graphics routines

 Variables supported (assigned via GDEVsets):

   The following must be set after the call to GDEVinit but before the
   first call to GDEVstart:

	program  	name of program to use
	font 		name of font to use
	Xgeometry 	geometry to use (eg =300x200-0+0)
	Xdefault	I'm not really sure what this does
	Xevents		"expand" or "compress"

   The following may be called at any time:

	currentcolor	"black" or "white"
	currentfunction	"copy" or "xor"   (xor doesn't seem to do anything
						useful though)
	GDEVseti...
	cursor		cursor-number
	pushregion	"x y w h"	pushes a window pixmap on the stack,
					clearing the area
	popregion	""		pops a window pixmap off the stack
	
	thickness	in-pixels


 */

#include <stdio.h>
#include "gdrv.h"
#include <X/Xlib.h>
#include <X/XMenu.h>

#ifndef TRUE
#	define TRUE 1
#	define FALSE  0
#endif


#undef DEBUG

#define MENU_EVENT	MOUSE_EVENT(MIDDLE_BUTTON, DOWN_TRANSITION)

typedef int COORD;

/* statics */

#define	INIT_WIDTH	(-1.0)

static Pixmap WhiteTile, BlackTile;

/* line drawing */

#define	NVERTEX	10240

int linecalls = 0;

#define	NWINDOWS	10
static int nwindows;

#define NALTERNATEFONTS	10

typedef struct gwindow {
	Window win;
	int gdevhandle;
	char *program;
	char *font;
	COORD height, width;
	int xcorner, ycorner;
	FontInfo *wfontinfo;
	int inputmask;
	XMenu *menu;
	int pane;
	int  currentcolor;
	int  currentfunction;
	int  thickness;
	int  xlineshift, ylineshift;
	Pattern linetype;
	char *Xgeometry;
	char *Xdefault;
	Vertex *vertex;
	int curvertex;
	Cursor cursor;
	int nalternatefonts;
	struct alternatefont {
		int	 key;	
		char	 *font;
		FontInfo *wfontinfo;
		short	*widths;
	} alternatefont[NALTERNATEFONTS];
} *Gwindow;

static struct gwindow initialw = {
	NULL,				/* win */
	-1,				/* gdevhandle */
	"xdev",				/* program */
	"timrom12b",			/* font */
	-1, INIT_WIDTH,			/* height, width */	
	0, 0,				/* xcorner, ycorner */
	NULL,				/* wfontinfo */
	ExposeRegion | KeyPressed,	/* inputmask */
	NULL,				/* menu */
	0,				/* pane */
	BlackPixel,			/* currentcolor */
	GXcopy,				/* currentfunction */
	1,				/* thickness */
	0, 0,				/* xlineshift, ylineshift */
	SolidLine,			/* linetype */
	NULL,				/* Xgeometry */
	"=1000x300-0+460",		/* Xdefault */
	NULL,				/* vertex */
	0,				/* curvertex */
	0,				/* cursor */
};

static struct gwindow window[NWINDOWS];

static
XDEVcurrentcolor(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	lineflush(w);
	switch(value[0]) {
	case 'w':	w->currentcolor = WhitePixel;	break;
	default:	w->currentcolor = BlackPixel;	break;
	}
}

static
XDEVcurrentfunction(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	lineflush(w);
	switch(value[0]) {
	case 'x':	w->currentfunction = GXinvert;	break;
	default:	w->currentfunction = GXcopy;	break;
	}
}

static
XDEVcurrentlinetype(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	lineflush(w);
	switch(value[0]) {
	case 's':	w->linetype = SolidLine;	break;
	case 'd':	w->linetype = DottedLine;	break;
	}
}


static
XDEVcurrentcursor(w, var, value, arg)
Gwindow w;
char *var, *arg;
int value;
{
	/* printf("cursor = %d\n", value); */
	XDefineCursor(w->win, value);
}

static
XDEVthickness(w, var, value, arg)
Gwindow w;
char *var, *arg;
int value;
{
	lineflush(w);
	if(w->currentfunction == GXinvert && (value&01)==0)
		value++;	/* odd values work better in Xor mode */

	w->thickness = value;
	w->xlineshift = -value / 2;
	w->ylineshift = -value / 2;
}


static
XDEVmap(w, var, value, arg)
Gwindow w;
char *var, *arg, *value;
{
	XMapWindow(w->win);
}

static
XDEVunmap(w, var, value, arg)
Gwindow w;
char *var, *arg, *value;
{
	XUnmapWindow(w->win);
}

static int
XDEVstringwidth(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	static short _widths[128];
	register short *widths = _widths;
	register int sum;
	register char *p;
	register struct alternatefont *af;

	if(_widths['A'] == 0 ) {
		computewidths(w->wfontinfo, widths);
	}

	for(af = &w->alternatefont[0];
	    af < &w->alternatefont[w->nalternatefonts]; af++)
		if(*value == af->key) {
			widths = af->widths;
			value++;
			break;
		}


	for(sum = 0, p = value; *p != '\0'; )
		sum += widths[*p++ & 0177];

	return sum;
}

static
computewidths(fontinfo, widths)
FontInfo *fontinfo;
short *widths;
{

/*
	XStringWidth(value, w->wfontinfo, 0, 0);
	XQueryWidth(value, w->wfontinfo->id);
	XCharWidths...

	all have this bizzare off-by-one error, e.g. they treat
		IBM as HAL
*/
	char chars[128];
	register char *p;
	for(p = chars; p < &chars[127]; p++)
		*p = p - chars - 1;  /* handle bizzare bug */
	XCharWidths(chars, 127, fontinfo->id, widths);
}

static int
XDEVstringheight(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	return w->wfontinfo->height;
}

static
XDEVeventstring(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	switch(*value) {
	case 'c': case 'C':
		XCompressEvents();
		break;
	case 'e': case 'E':
		XExpandEvents();
		break;
	default:
		printf("XDEVeventstring(%s,%s)???\n", var, value);
		break;
	}
}

static
XDEVprogram(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	w->program = value;
}

static
XDEVfont(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	w->font = value;
}

static
XDEValternatefont(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	register struct alternatefont *af =
		&w->alternatefont[w->nalternatefonts++];

	if(w->nalternatefonts > NALTERNATEFONTS)
		xerror("too many fonts");
	af->font = value;
	if ((af->wfontinfo = XOpenFont (af->font)) == NULL)
		xerror("XOpenFont (%s) failed!\n", af->font);
	af->key = w->nalternatefonts;	/* changable via XDEVassignfont */
	af->widths = (short *)malloc(128*sizeof(short));
	if(af->widths == NULL)
		xerror("XDEValternatefont: no mem");
	computewidths(af->wfontinfo, af->widths);
}

/* if a text string begins (first char) with value, use current font */
static
XDEVassignfont(w, var, value, arg)
Gwindow w;
char *var; int value; char *arg;
{
	register struct alternatefont *af =
		&w->alternatefont[w->nalternatefonts - 1];

	if(w->nalternatefonts == 0)
		xerror("XDEVassignfonts: no current alternate font");
	af->key = value;
}

static
XDEVXgeometry(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	w->Xgeometry = value;
}

static
XDEVXdefault(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	w->Xdefault = value;
}

#define	PSTACKSIZE	10
static int pstacktop;
static struct pstack {
	Pixmap pixmap;
	int x, y, w, h;
} pstack[PSTACKSIZE];

static
XDEVpushregion(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	register struct pstack *p = &pstack[pstacktop++];
	if(pstacktop > PSTACKSIZE)
		xerror("PSTACKSIZE");
	if(sscanf(value, "%d %d %d %d", &p->x, &p->y, &p->w, &p->h) != 4)
		xerror("XDEVXpushregion");
	p->w++, p->h++;	/* can't really hurt */
	XDEVgetsizes(w);
	if(p->w > w->width - p->x) p->w = w->width - p->x;
	if(p->h > w->height - p->y) p->h = w->height - p->y;

	p->pixmap = XPixmapSave(w->win, p->x, p->y, p->w, p->h);
	XPixSet(w->win, p->x, p->y, p->w, p->h, WhitePixel);
}

static
XDEVpopregion(w, var, value, arg)
Gwindow w;
char *var, *value, *arg;
{
	register struct pstack *p = &pstack[--pstacktop];
	if(pstacktop < 0) xerror("XDEVXpopregion");
	XPixmapPut(w->win, 0, 0, p->x, p->y, p->w, p->h, p->pixmap,
		GXcopy, AllPlanes);
	XFreePixmap(p->pixmap);
}

/*
  initilization - doesn't create a window, since the program may supply
  variables which alter the window's shape
 */

#define cursor_width 16
#define cursor_height 16
#define cursor_x_hot 0
#define cursor_y_hot 0
static short cursor_bits[] = {
   0x001f, 0x0007, 0x000f, 0x001d,
   0x0039, 0x0070, 0x00e0, 0x01c0,
   0x0380, 0x0700, 0x0e00, 0x1c00,
   0x3800, 0x1000, 0x0000, 0x0000
};

#define cursor_mask_width 16
#define cursor_mask_height 16
#define cursor_mask_x_hot 15
#define cursor_mask_y_hot 0
static short cursor_mask_bits[] = {
   0x003f, 0x003f, 0x001f, 0x003f,
   0x007f, 0x00fb, 0x01f0, 0x03e0,
   0x07c0, 0x0f80, 0x1f00, 0x3e00,
   0x7c00, 0x3800, 0x1000, 0x0000
};

Pointer
XDEVinit(gdevhandle)
int gdevhandle;
{
	int XDEVinput();
	Gwindow w;

	if(nwindows == 0) {	/* first time called */
		if (XOpenDisplay (NULL) == NULL)
			xerror("could not open display!");

		GDRV00topleft(gdevhandle);

		GDRVvar_fcn(gdevhandle, "program", XDEVprogram, NULL);
		GDRVvar_fcn(gdevhandle, "font", XDEVfont, NULL);
		GDRVvar_fcn(gdevhandle,
				"alternatefont", XDEValternatefont, NULL);
		GDRVvar_fcn(gdevhandle, "assignfont", XDEVassignfont, NULL);
		GDRVvar_fcn(gdevhandle, "Xgeometry", XDEVXgeometry, NULL);
		GDRVvar_fcn(gdevhandle, "Xdefault", XDEVXdefault, NULL);
		GDRVvar_fcn(gdevhandle, "Xevents", XDEVeventstring, NULL);

		GDRVvar_fcn(gdevhandle, "pushregion", XDEVpushregion, NULL);
		GDRVvar_fcn(gdevhandle, "popregion", XDEVpopregion, NULL);

		GDRVvar_fcn(gdevhandle,
				"currentcolor", XDEVcurrentcolor, NULL);
		GDRVvar_fcn(gdevhandle,
				"currentfunction", XDEVcurrentfunction, NULL);
		GDRVvar_fcn(gdevhandle,
				"currentlinetype", XDEVcurrentlinetype, NULL);
		GDRVvar_fcn(gdevhandle,
				"currentcursor", XDEVcurrentcursor, NULL);
		GDRVvar_fcn(gdevhandle,
				"thickness", XDEVthickness, NULL);
		GDRVvar_fcn(gdevhandle,
				"stringwidth", XDEVstringwidth, NULL);
		GDRVvar_fcn(gdevhandle,
				"stringheight", XDEVstringheight, NULL);
		GDRVvar_fcn(gdevhandle, "map", XDEVmap, NULL);
		GDRVvar_fcn(gdevhandle, "unmap", XDEVunmap, NULL);

		GDRVfdnotify(FD_POLL, XDEVinput);
		GDRVfdnotify(dpyno(), XDEVinput);

		WhiteTile = XMakeTile (WhitePixel); 
		BlackTile = XMakeTile (BlackPixel);

		initialw.cursor = XCreateCursor(cursor_width, cursor_height,
				    cursor_bits, cursor_mask_bits,
				    cursor_x_hot, cursor_y_hot,
				    WhitePixel, BlackPixel, GXxor);

	}

	if(nwindows >= NWINDOWS)
		xerror("NWINDOWS");
	w = &window[nwindows++];
	*w = initialw;
	w->gdevhandle = gdevhandle;
	return (Pointer) w;
}

static
XDEVgetsizes(w)
Gwindow w;
{
	WindowInfo info;

	if( ! XQueryWindow(w->win, &info) )
		xerror("XQueryWindow");

	w->width = info.width;
	w->height = info.height;
	w->xcorner = info.x;
	w->ycorner = info.y;
}
 
XDEVstart(w)
Gwindow w;
{
	if(w->win == 0) {
		OpaqueFrame frame;
		char *XDEVGetDefault();

		frame.bdrwidth = 1;
		frame.border = BlackTile;
		frame.background = WhiteTile;

		if(w->Xgeometry == NULL)
			w->Xgeometry = XDEVGetDefault(w->program, "Geometry");
		w->win = XCreate (w->program, w->program, w->Xgeometry,
			w->Xdefault, &frame, 50, 50);
		if (w->win == 0)
			xerror("XCreate failed!");

		w->vertex = (Vertex *) malloc((NVERTEX+2) * sizeof(Vertex));
		if(w->vertex == NULL)
			xerror("Vertex malloc");

		if ((w->wfontinfo = XOpenFont (w->font)) == NULL)
			xerror("XOpenFont (%s) failed!\n", w->font);

		XSelectInput(w->win, w->inputmask);

		XDefineCursor(w->win, w->cursor);

		XDEVgetsizes(w);
	}

	XClear(w->win);
	XMapWindow(w->win);
}

XDEVflush(w)
Gwindow w;
{
	XRaiseWindow(w->win);	/* try it */
	lineflush(w);
	XFlush();
}

XDEVstop(w)
Gwindow w;
{
	XDEVflush(w);
}

static
lineflush(w)
register Gwindow w;
{
	if(w->curvertex > 0) {
		if(w->linetype == SolidLine)
		     XDraw (w->win, w->vertex, w->curvertex,
			w->thickness, w->thickness,
			w->currentcolor, w->currentfunction, AllPlanes);
		else {
			/* printf("Linetype=%x (%x %x)\n", linetype, SolidLine, DottedLine); */
		    XDrawDashed (w->win, w->vertex, w->curvertex,
			w->thickness, w->thickness,
			w->currentcolor, w->linetype, w->currentfunction,
			AllPlanes);
		}

		linecalls = 0;
		w->curvertex = 0;
	}
}

XDEVline(w, x1, y1, x2, y2)
register Gwindow w;
COORD x1, y1, x2, y2;
{
	register Vertex *v;
	static push1first = TRUE;

	linecalls++;
		/* heuristic:
			if push1first = TRUE client likely to do:
				line(x1, y1, x2, y2);
				line(x2, y2, x3, y3);
			    (so we first push x1,y1 then x2,y2 so
				the duplicated point is pushed last)
			if push1first = FALSE client likely to do:
				line(x1, y1, x2, y2);
				line(x3, y3, x1, y1);
			    (so we first push x2,y2 then x1,y1 so
				the duplicated point is pushed last)
		*/

	if(w->curvertex >= NVERTEX)
		lineflush(w);
	v = &w->vertex[w->curvertex-1];

	x1 += w->xlineshift; x2 += w->xlineshift;
	y1 += w->ylineshift; y2 += w->ylineshift;

	/* fancy line caching doesn't work if w->currentfunction == GXinvert */
	if(w->currentfunction == GXinvert) {
			++v; ++w->curvertex;
			v->x = x1; v->y = y1; v->flags = VertexDontDraw;
			++v; ++w->curvertex;
			v->x = x2; v->y = y2; v->flags = 0;
	}
	else if(w->curvertex > 0 && v->x == x1 && v->y == y1) {
		++v; ++w->curvertex;
		v->x = x2; v->y = y2; v->flags = 0;
	}
	else if(w->curvertex > 0 && v->x == x2 && v->y == y2) {
		++v; ++w->curvertex;
		v->x = x1; v->y = y1; v->flags = 0;
	}
	else {
		if(w->curvertex > 1) {
			--v;
			if(v->x == x1 && v->y == y1)
				push1first = FALSE;
			else if(v->x == x2 && v->y == y2)
				push1first = TRUE;
			++v;
		}
		if(push1first) {
			++v; ++w->curvertex;
			v->x = x1; v->y = y1; v->flags = VertexDontDraw;
			++v; ++w->curvertex;
			v->x = x2; v->y = y2; v->flags = 0;
		} else {
			++v; ++w->curvertex;
			v->x = x2; v->y = y2; v->flags = VertexDontDraw;
			++v; ++w->curvertex;
			v->x = x1; v->y = y1; v->flags = 0;
		}
	}

#ifdef DEBUG
	printf("line %d %d  %d %d\n", x1, y1, x2, y2);
#endif

}

XDEVrect(w, x, y, x2, y2)
Gwindow w;
COORD x, y, x2, y2;
{
	int rh = y2 - y;
	int rw = x2 - x;
	static Vertex v[5];

	v[0].x = x; v[0].y = y; v[0].flags = 0;
	v[1].x = rw; v[1].y = 0; v[1].flags = VertexRelative;
	v[2].x = 0; v[2].y = rh; v[2].flags = VertexRelative;
	v[3].x = -rw; v[3].y = 0; v[3].flags = VertexRelative;
	v[4] = v[0];

	XDraw(w->win, v, 5, 1, 1, w->currentcolor, w->currentfunction,
			AllPlanes);
	/* should be XDrawFilled but I couldnt get it to work */
}

XDEVtext(w, x, y, text)
Gwindow w;
COORD x, y;
register char *text;
{
	int xoff = 0, yoff = -15;
	register int fid;
	register struct alternatefont *af;

#ifdef DEBUG
	printf("text %d %d %s\n", x, y, text);
#endif

	fid = w->wfontinfo->id;
	for(af = &w->alternatefont[0];
	    af < &w->alternatefont[w->nalternatefonts]; af++)
		if(*text == af->key) {
			fid = af->wfontinfo->id;
			text++;
			break;
		}

	XTextMaskPad (w->win, x+xoff, y+yoff, text, strlen (text),
		fid, 0, 0, w->currentcolor, 
		w->currentfunction, AllPlanes); /* is w->currentcolor right? */

}

XDEVpoint(w, x, y)
Gwindow w;
COORD x, y;
{
#ifdef DEBUG
	printf("point  %d %d\n", x, y);
#endif

	XDEVrect(w, x + w->xlineshift, y + w->ylineshift,
		x+w->thickness, y+w->thickness);
}

XDEVsetdim(w, width, height)
Gwindow w;
COORD width, height;
{
	XChangeWindow(w->win, width, height);
}

XDEVgetdim(w, wp, hp)
Gwindow w;
COORD *wp, *hp;
{
	COORD ox = w->width, oy = w->height;

	XDEVgetsizes(w);

	if(ox != INIT_WIDTH && (ox != w->width || oy != w->height))
		printf("XDEV: Size changed unexpectedly!\n");
	/* If the above printf never comes up, we can get rid of the call to
	   XDEVgetsizes and everything else above this line */

	*wp = w->width;
	*hp = w->height;
}

XDEVmenuitem(w, itemname, retval, addflag)
Gwindow w;
char *itemname;
int retval;
int addflag;
{
    char *data;
    int r;

    if(w->menu == NULL) {
	int XDEVevent();

	if( (w->menu = XMenuCreate(RootWindow, w->program)) == NULL)
		xerror("XMenuCreate");
	if((w->pane = XMenuAddPane(w->menu, w->program, TRUE)) == XM_FAILURE)
		xerror("XMenuAddPane");
	XMenuEventHandler(XDEVevent);
	XDEVmouseinterest(w, MENU_EVENT);
    }

    if(addflag) {
	data = (char *) retval;
	if(XMenuAddSelection(w->menu, w->pane, data, itemname, TRUE) == XM_FAILURE)
		xerror("XMenuAddSelection");
    }
    else {
	if((r = XMenuFindSelection(w->menu, w->pane, itemname)) == XM_FAILURE)
		xerror("XMenuFindSelection");
	if( XMenuDeleteSelection(w->menu, w->pane, r) == XM_FAILURE)
		xerror("XMenuDeleteSelection");
   }
}

XDEVmouseinterest(w, event)
Gwindow w;
int event;
{
	register oldmask = w->inputmask;

	if(event & DOWN_TRANSITION)
		w->inputmask |= ButtonPressed;
	if(event & UP_TRANSITION)
		w->inputmask |= ButtonReleased;
	if(event & DOWN_MOVEMENT) {
		switch(event & BUTTON_MASK) {
		case LEFT_BUTTON:
			w->inputmask |= LeftDownMotion; break;
		case MIDDLE_BUTTON:
			w->inputmask |= MiddleDownMotion; break;
		case RIGHT_BUTTON:
			w->inputmask |= RightDownMotion; break;
		}
	}

	if(w->inputmask != oldmask)
		XSelectInput(w->win, w->inputmask);
}

/* map x window handles into internal structure */

static Gwindow
XDEVLookupGwindow(win)
Window win;
{
	register Gwindow w;
	for(w = window; w < &window[nwindows]; w++)
		if(w->win == win)
			return w;
	/* xerror("LookupGwindow"); */
	printf("LookupGwindow\n");
	return &window[0];
}

/* structure used to communicate between XDEVinput and XDEVevent */

struct menubutton {
	int	activate;
	int	x, y;
	Window	win;
};

static
XDEVinput()
{
	XEvent xevent, moved_event;
	struct menubutton menubutton;

	menubutton.activate = FALSE;
	moved_event.type = 0;
	while(XPending() > 0) {
	    XNextEvent(&xevent);
	    /* we try to process only the last MouseMoved, but if the input
	       window changes, we punt on this idea */
	    if(moved_event.type == MouseMoved &&
	       moved_event.window != xevent.window) {
	    		XDEVevent(&moved_event, &menubutton);
			moved_event.type = 0;
	    }
	    /* similarly for menu button */
	    if( menubutton.activate &&
		menubutton.win != xevent.window ) {
			DoMenu(&menubutton);
			menubutton.activate = FALSE;
		}

	    switch((int) xevent.type) {
	    case MouseMoved:
		/* only the last mouse move event is saved so that tracking
		   appears faster */
		moved_event = xevent;
		break;
	    case ButtonPressed:
	    case ButtonReleased:
		moved_event.type = 0;
		/* fall into ... */
	    default:
	    	XDEVevent(&xevent, &menubutton);
	    }
	}

	if(moved_event.type == MouseMoved)
	    XDEVevent(&moved_event, &menubutton);

	if( menubutton.activate)
		DoMenu(&menubutton);

}


#include <sys/time.h>

static
XDEVevent(xe, menubuttonp)
register XEvent *xe;
struct menubutton *menubuttonp;
{
    struct timeval tv;
    register Gwindow w = XDEVLookupGwindow(xe->window);

    if(xe->type == ButtonPressed || xe->type == ButtonReleased ||
       xe->type == MouseMoved)
    {
	register XButtonEvent *xb = (XButtonEvent *) xe;

	register int event;
	int x, y;
	static Window dummy;
	static int lastbutton = 0;
	static int button[] =
		{ RIGHT_BUTTON, MIDDLE_BUTTON, LEFT_BUTTON };

	if(xb->type == ButtonPressed || xb->type == ButtonReleased) {
		lastbutton = button[xb->detail & ValueMask];
		XInterpretLocator(w->win, &x, &y, &dummy, xb->location);
	} else { /* mouse moved - use as hint (page 18 Xlib V10 manual) */
		XUpdateMouse(w->win, &x, &y, &dummy);
	}
	event = MOUSE_EVENT(lastbutton,
		xb->type == ButtonPressed ? DOWN_TRANSITION :
		xb->type == ButtonReleased ? UP_TRANSITION :
					    DOWN_MOVEMENT);

	XInterpretLocator(w->win, &x, &y, &dummy, xb->location);
	gettimeofday(&tv, NULL);
	
	/* printf("event=%x x=%d y=%d\n", event, x, y); */

	GDRVmouse(w->gdevhandle,
		  event, x, y, (tv.tv_sec * 1000) + (tv.tv_usec / 1000));

	/* special check for middle button to bring up menu */

	if(event == MENU_EVENT) {
		menubuttonp->activate = TRUE;
		XInterpretLocator(RootWindow, &menubuttonp->x, &menubuttonp->y,
			&dummy, xb->location);
		menubuttonp->win = xe->window;
	}
  }
  else if(xe->type == ExposeWindow || xe->type == ExposeRegion)
  {
	XDEVgetsizes(w);
	GDRVrefresh(w->gdevhandle);
   }
  else if(xe->type == KeyPressed)
  {
	int nbytes;
	register char *result = XLookupMapping(xe, &nbytes);
	while(--nbytes >= 0) {
		GDRVwindow(w->gdevhandle);
		GDRVputc(*result++);
	}
  }
  else printf("Funny X event %d (0x%x)\n", xe->type, xe->type);
}

DoMenu(mb)
struct menubutton *mb;
{
        register Gwindow w = XDEVLookupGwindow(mb->win);
	char *retval;
	int a_pane = w->pane;
	int a_sel = 0;
	int mx, my, mw, mh;
	int menux, menuy;

	WindowInfo wi, ri;	/* plot window, and root window, resp */
	int wrightx, wlowery, rrightx, rlowery;
 
	if(w->menu == NULL)
		return;

	if( ! XQueryWindow(w->win, &wi) )
		xerror("XQueryWindow win");
	if( ! XQueryWindow(RootWindow, &ri) )
		xerror("XQueryWindow root");
	if(XMenuLocate(w->menu, a_pane, a_sel, mb->x, mb->y,
		&mx, &my, &mw, &mh) == XM_FAILURE) {
			printf("XMenuLocate\n");
			return;
	}

	mw+=2; mh+=2; wi.width+=2; wi.height+=2 ;  /* avoid boundary conds */

	wrightx = wi.x + wi.width; wlowery = wi.y + wi.height;
	rrightx = ri.x + ri.width; rlowery = ri.y + ri.height;

	menux = mx; menuy = my;


	if(wi.x - mw > ri.x) /* Try to fix menu to the left of win */
		menux = wi.x - mw;
	else if(wrightx + mw < rrightx) /* right */
		menux = wrightx;
	else if(wi.y - mh > ri.y) /* above */
		menuy = wi.y - mh;
	else if(wlowery + mh < rlowery) /* below */
		menuy = wlowery;

	menux += mb->x - mx;
	menuy += mb->y - my;

	/* Try to locate menu off screen */
	XWarpMouse(RootWindow, menux, menuy);
	if(XMenuActivate(w->menu, &a_pane, &a_sel,
		    menux, menuy,
		    ButtonReleased, &retval) == XM_SUCCESS)
			GDRVmenu(w->gdevhandle,  (int) retval );
	XWarpMouse(RootWindow, mb->x, mb->y);
	XDEVflush(w);

}

/*VARARGS1*/
xerror(a, b, c, d)
char *a;
{
	printf("XDEV error: ");
	printf(a, b, c, d);
	if(!strncmp(a, "XMenu", 5))
		printf("(%s)", XMenuError());
	printf("\n");
	exit(1);
}

/*
 * XGetDefault ignores the program name in all but the first call to it.
 * Thus, if XGetDefault("prog1", "Geometry") is called first,
 * XGetDefault("prog2", "Geometry") will necessarily return the same
 * result.  Since there's no easy way to get around this, we first look
 * up XGetDefault("prog2", "prog2_Geometry") before we look up
 * XGetDefault("prog2", "Geometry"), so in .Xdefaults the user can have
 * entries like:
	prog1.Geometry:=500x500+0+0
	prog1.prog2_Geometry:=500x500+0-0
 */


char *
XDEVGetDefault(program, name)
char *program, *name;
{
	char n[200], *r;

	sprintf(n, "%s_%s", program, name);
	if((r = XGetDefault(program, n)) == NULL)
		r = XGetDefault(program, name);
	return r;
}

