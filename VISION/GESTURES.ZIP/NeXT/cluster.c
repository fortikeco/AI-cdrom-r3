/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/

#include "matrix.h"
#include "util.h"
#include "cluster.h"
#include <stdio.h>

extern DumpDsm();
extern DumpDend();
extern DumpDendGraphHelp();
static int setleaves();

int clusterdebug = 0;
#define D if(clusterdebug > 0)

/*
 given a lower triangular matrix dsm[i][j] i>j of dissimilarity meaures
 compute the dendrogram using the group average method.
 The matrix is overwritten during the Cluster call
 */

#define	MAXNODES	(2*MAXUNITS)
static struct dendrogram dend[MAXNODES];
static int nextnode;
static int nextrank;

static
DendInit()
{
	nextnode = 0;
	nextrank = 1;
}

static Dendrogram
DendLeaf(unit)
int unit;
{
	register Dendrogram d;
	if(nextnode >= MAXNODES)
		error("DendLeaf: increase MAXNODES");
	d = &dend[nextnode++];
	d->unit = unit;
	d->rank = 0;
	d->threshold = 0.0;
	d->left = dend->right = NULL;
	return d;
}

static Dendrogram
DendInner(left, right, threshold)
register Dendrogram left, right;
double threshold;
{
	Dendrogram d;
	if(nextnode >= MAXNODES)
		error("DendINNER: increase MAXNODES");
	d = &dend[nextnode++];
	d->rank = nextrank++;
	d->left = left;
	d->right = right;
	d->threshold = threshold;
	d->unit = left->unit < right->unit ? left->unit : right->unit;
	return d;
}

#define	DSM(i,j)	((i)>(j) ? dsm[i][j] : dsm[j][i])
#define	DSM_LVAL(i,j)	(*((i)>(j) ? &dsm[i][j] : &dsm[j][i]))

Dendrogram
Cluster(dsm)
register Matrix dsm;
{
	register int i, j, k, m, n;

	short	group[MAXUNITS];
		/* group[i] gives the minimum unit number of the group whose
		   dissimilaritys are in row dsm[i] */

	short	minj[MAXUNITS], mini;
		/* dsm[i][ min[i] ] gives the minimum value of row dsm[i] */

	short	nn[MAXUNITS];
		/* nn[i] is then number of elements in group group[i] */

	double newdsm[MAXUNITS];
	double alphak, alpham, beta, gamma;
	Dendrogram d = NULL, dend[MAXUNITS];

	DendInit();

	if(NROWS(dsm) != NCOLS(dsm))
		error("Cluster expects a square matrix (got %d x %d)",
			NROWS(dsm), NCOLS(dsm));

	n = NROWS(dsm);
	if(n > MAXUNITS)
		error("Cluster can't deal with more than %d units (got %d)",
			MAXUNITS, n);
	
	/* set the groups initially to be the individual units */
	for(i = 0; i < n; i++) {
		group[i] = i;
		nn[i] = 1;
		dend[ group[i] ] = DendLeaf(i);
	}

	/* initialize the minj's */
	for(i = 1; i < n; i++) {
		minj[i] = 0;
		for(j = 0; j < i; j++)
			if( dsm[i][j] < dsm[i][ minj[i] ] )
				minj[i] = j;
	}

	/* main loop */
	for(; n > 1; n--) {

		/* find the smallest element in the matrix */
		mini = 1;
		for(i = 1; i < n; i++)
			if(dsm[i][ minj[i] ] < dsm[mini][ minj[mini] ])
				mini = i;
		/* now, smallest element is dsm[mini][ minj[mini] ] */

		k = minj[mini], m = mini;

		D {
		    for(i = 1; i < n; i++)
			printf("minj[%d]=%d (%g) ",
				i, minj[i], dsm[i][minj[i]]);
		    printf("mini=%d (%g)\n", mini, dsm[mini][minj[mini]]);
		    DumpDsm(dsm, n, group);

		    printf("Combining rows %d and %d (groups %d and %d)\n",
			k, m, group[k], group[m]);
		}


		if(k >= m) error("Cluster: k>=m!");

		/* make the dendrogram */
		dend[ group[k] ] = d = DendInner( dend[ group[k] ],
						  dend[ group[m] ],
		    				  dsm[mini][minj[mini]] );
		D DumpDend(d,0);

		/* Now we calulate the new dissimilarities between the merger
		   of k and m and every other row i in the table */
		alphak = nn[k] / (double) (nn[k] + nn[m]);
		alpham = nn[m] / (double) (nn[k] + nn[m]);
		for(j = 0; j < n; j++)
			if(j != k && j != m)
			     newdsm[j] = alphak * DSM(j,k) + alpham * DSM(j,m);
			else
			     newdsm[j] = -666.66;

		D {
			for(j = 0; j < n; j++)
			     printf("newdsm[%d (group %d)] = %g ",
				j, group[j], newdsm[j]);
			printf("\n");
		}

		/* Now we merge rows and columns k and m, k < m */

		/* row k */
		minj[k] = 0;
		for(j = 0; j < k; j++) {
			dsm[k][j] = newdsm[j];
			if(dsm[k][j] < dsm[k][ minj[k] ]) /* fix min */
				minj[k] = j;
		}

		/* column k */
		for(i = k+1; i < n; i++) {
			dsm[i][k] = newdsm[i];
			if(dsm[i][k] < dsm[i][ minj[i] ])
				minj[i] = k;
		}

		/* move the last row of the table into the vacated mth row 
			and column */
		group[m] = group[n-1];

		/* row m */
		minj[m] = 0;
		for(j = 0; j < m; j++) {
			dsm[m][j] = dsm[n-1][j];
			if(dsm[m][j] < dsm[m][ minj[m] ]) /* fix min */
				minj[m] = j;
		}

		/* column m */
		for(i = m+1; i < n; i++) {
			dsm[i][m] = dsm[n-1][i];
			if(dsm[i][m] < dsm[i][ minj[i] ])
				minj[i] = m;
		}

		for(i = 1; i < n-1; i++)
		   if(minj[i] == k || minj[i] == m) {
			minj[i] = 0;
			for(j = 0; j < i; j++)
				if( dsm[i][j] < dsm[i][ minj[i] ] )
					minj[i] = j;
		   }

#define INEFFICIENT
#ifdef INEFFICIENT
		/* recalculate the mins as consistency check */
		{ int nminj[MAXUNITS];
		  for(i = 1; i < n-1; i++) {
			nminj[i] = 0;
			for(j = 0; j < i; j++)
				if( dsm[i][j] < dsm[i][ nminj[i] ] )
					nminj[i] = j;
		   }
		   for(i = 1; i < n-1; i++)
			if(dsm[i][nminj[i]] != dsm[i][minj[i]])
			    printf("\n****min error dsm[%d][nminj[%d]=%d]=%g != dsm[%d][minj[%d]=%d]=%g****\n", 
				i, i, nminj[i], dsm[i][nminj[i]],
				i, i, minj[i], dsm[i][minj[i]]);
		}
#endif


	} /* end main loop */

	/* return the last dendrogram */
	return d;
}

DumpDsm(dsm, n, group)
Matrix dsm;
int n;
short group[];
{
	register i, j;

	for(i = 0; i < n; i++) {
		printf("%4d ", group[i]);
		for(j = 0; j < i; j++)
			printf(" %6.2f", dsm[i][j]);
		printf("\n");
	}
	printf("GROUP");
	for(j = 0; j < n; j++) 
		printf(" %4d  ", group[j]);
	printf("\n");
}

double
Group(d, ngroups, grouping)
Dendrogram d;
int ngroups;
short grouping[];
{
	Dendrogram group[MAXUNITS];
	double threshold = 0.0;

	int g, ng, maxg, maxrank;

	D DumpDend(d, 0);

	ng = 1;
	group[0] = d;

	while(ng < ngroups) {
		maxg = -1; maxrank = -1;
		for(g = 0; g < ng; g++)
			if(group[g]->left != NULL &&	/* inner node */
			   group[g]->rank > maxrank)
				maxrank = group[maxg=g]->rank;
		if(maxg < 0)
			break;
		threshold = group[maxg]->threshold;
		group[ng++] = group[maxg]->right;
		group[maxg] = group[maxg]->left;
	}
		
	D for(g = 0; g < ng; g++) {
		printf("Group: group %d of %d \n", g, ng);
		DumpDend(group[g], 0);
	}

	for(g = 0; g < ng; g++)
		setleaves(group[g], g, grouping);

	return threshold;
}

static int
setleaves(d, g, grouping)
register Dendrogram d;
int g;
short grouping[];
{
	if(d->left) {
		setleaves(d->left, g, grouping);
		setleaves(d->right, g, grouping);
	}
	else
		grouping[d->unit] = g;
}

DumpDend(d, depth)
register Dendrogram d;
int depth;
{
	register int i;

	if(depth == 0)
		printf("-------------\n");
	for(i = 0; i < depth; i++)
		printf("  ");
	printf("%d U%d R%d T%g\n", depth, d->unit, d->rank, d->threshold);
	if(d->left) {
		DumpDend(d->left, depth+1);
		DumpDend(d->right, depth+1);
	}
	if(depth == 0)
		printf("-------------\n");
}

void
PrintGrouping(d, ngroups)
Dendrogram d;
int ngroups;
{
	
	short grouping[MAXUNITS];
	register int i, j, n;
	double t;

	n = d->rank + 1;
	t = Group(d, ngroups, grouping);

	printf("-- data clustered into %d groups, threshold %g --\n",
		ngroups, t);
	for(i = 0; i < ngroups; i++) {
		printf("   group %d: ", i);
		for(j = 0; j < n; j++)
			if(grouping[j] == i)
				printf("%d ", j);
		printf("\n");
	}
	printf("--------\n");
}

PrintGroupCounts(d, ngroups)
Dendrogram d;
int ngroups;
{
	
	short grouping[MAXUNITS];
	register int i, j, n;
	double t;
	int count[MAXUNITS];

	n = d->rank + 1;
	t = Group(d, ngroups, grouping);

	for(i = 0; i < ngroups; i++)
		count[i] = 0;

	for(j = 0; j < n; j++)
		count[ grouping[j] ]++;

	for(i = 0; i < ngroups; i++)
		printf("%d ", count[i]);
}

DendPrintUnits(d)
register Dendrogram d;
{
	if(d->left)
		DendPrintUnits(d->left), DendPrintUnits(d->right);
	else
		printf("%d ", d->unit);
}

int
DendNUnits(d)
register Dendrogram d;
{
	if(d->left)
		return DendNUnits(d->left) + DendNUnits(d->right);
	else
		return 1;
}

int
DendUnits(d, units)
register Dendrogram d;
short units[];
{
	register int n;
	if(d->left) {
		n = DendUnits(d->left, &units[0]);
		return n + DendUnits(d->right, &units[n]);
	}
	units[0] = d->unit;
	return 1;
}

DumpDendGraph(d)
register Dendrogram d;
{
	double x, y;
	int leafx = 0;
	DumpDendGraphHelp(d, &leafx, &x, &y);
}


DumpDendGraphHelp(d, leafxp, xp, yp)
register Dendrogram d;
int *leafxp;
double *xp, *yp;
{
	double xleft, yleft, xright, yright;
	if(d->left) {
		DumpDendGraphHelp(d->left, leafxp, &xleft, &yleft);
		DumpDendGraphHelp(d->right, leafxp, &xright, &yright);
		*xp = (xleft + xright) / 2;
		*yp = d->threshold;
		*yp = d->rank;
		printf("Node %g %g left %g %g right %g %g\n",
			*xp, *yp, xleft, yleft,  xright, yright);
		return;
	}
	*xp = (double) (*leafxp)++;
	*yp = d->threshold; 	/* should be zero */
	*yp = d->rank; 	/* should be zero */
	printf("Leaf %g %g %d\n", *xp, *yp, d->unit);
}

