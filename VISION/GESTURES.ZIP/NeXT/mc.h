/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/

/*
  Multi-finger classifier
 */


#define	MAXMCLASSES	50
#define	MAXPATHCLASSES	200

typedef	struct mclassdope *mClassDope;	/* multi-path classifier */
typedef int mClassIndex;		/* multi-class index */
typedef struct decisiontree *DecisionTree;
typedef struct mclassifier *mClassifier;

#define MAXPATHS 4
#define MAXCLASSEXAMPLES 50
typedef struct mexample *mExample;
struct mexample {
	Vector	pf[MAXPATHS];
	Vector 	gf;
	char	*examplename;
	short	ci[MAXPATHS];
		/* ci[i] gives the resulting class index
		   when pf[i] is classified */
};

struct mclassdope {
	char 		*classname;
	mClassIndex	number;
	char		*retval;

	int		nexamples;
	int		npaths;
	sClassDope	scd[MAXPATHS];
	struct mexample	example[MAXCLASSEXAMPLES];
};

/* The classification of multi finger input works a follows:
	There are P paths which are classified (call the resulting class
	indices c1, c2, ... cP) and one global classification (call it c0).
	c1..cP rearranged into sorted order, and the vector c0,c1...cP
	is used to step through the decision tree, i.e. the resultant
	mclass is
		mc->decisiontree->next[c0]->next[c1]->...->next[cP]->mclass
	if any of the next fields or mclass is NULL, the input must be
	rejected.
*/

struct decisiontree {
	mClassDope	mclass;	/* the class, if no more paths */
	DecisionTree	*next;	/* array of decision trees, indexed
					by sClassIndex  */
};

#define MCT_SORT	0	/* sort paths, separate classifier per
				   class index */

#define MCT_CLUSTER	1	/* don't sort paths, one classifier (pathcl[0])
					for all paths */

struct mclassifier {
	sClassifier	pathcl[MAXPATHS], globalcl;
	DecisionTree	decisiontree;
	int		nmclasses;
	mClassDope	*mclassdope;
	int		npathclasses;	/* number of path classes */
	int		type;
	/* sClassifier	ambigpathcl[MAXPATHS]; */
};


mClassifier	mNewClassifier();
void		mSortPaths();		/* mc */
void		mAddExample();		/* mc, classname, mfv, examplename */
void		mDoneAdding();		/* mc */
mClassDope	mClassNameLookup();	/* mc, classname */
mClassDope	mClassify();		/* mc, mfv */
