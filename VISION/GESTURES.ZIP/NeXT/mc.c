/***********************************************************************

mc.c - multifinger gesture classifier

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 1, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (in ../COPYING); if not, write to the Free
Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***********************************************************************/


#define N_AMBIG	5

#include "bitvector.h"
#include "matrix.h"
#include "util.h"
#include "sc.h"
#include "mc.h"
#include "mcf.h"

#include <stdio.h>
#include <string.h>

static void DtAdd();
extern mDumpDt();
extern mCluster();
extern qsort();

mClassifier
mNewClassifier()
{
	register mClassifier mc;

	mc = allocate(1, struct mclassifier);
	mc->type = MCT_CLUSTER;
	mc->pathcl[0] = sNewClassifier();
	/* mc->ambigpathcl[0] = sNewClassifier(); */
	mc->globalcl = sNewClassifier();
	mc->mclassdope = allocate(MAXMCLASSES, mClassDope);
	mc->nmclasses = 0;
	mc->npathclasses = 0;
	mc->decisiontree = allocate(1, struct decisiontree);
	return mc;
}

void
mSortPaths(mc)
register mClassifier mc;
{
	register int i;
	mc->type = MCT_SORT;
	for(i = 1; i < MAXPATHS; i++) {
		mc->pathcl[i] = sNewClassifier();
		/* mc->ambigpathcl[i] = sNewClassifier(); */
	}
}

void
mDoneAdding(mc)
register mClassifier mc;
{
	static void mSortTrain();
	if(mc->type == MCT_SORT)
		mSortTrain(mc);
	else
		mCluster(mc);

}

static void
mSortTrain(mc)
register mClassifier mc;
{
	Vector gf, pf[MAXPATHS];
	register int i;
	int e;
	sClassIndex c[MAXPATHS+1];
	register DecisionTree dt;
	MFV mfv;
	char *mclassname, *mexamplename;
	mClassDope mcd;
	int npaths;
	int mapping[200];
	mClassIndex m;
	mExample me;

	/* TODO: look at every missclassification of single paths and put
	   them all into the same equivalence class */

	/* CheckAmbiguities(mc); */
	printf("\n");
	for(i = 0 ; i < MAXPATHS; i++) {
		printf("Removing ambiguities from path classifier %d\n", i);
		sRemoveAmbiguities(mc->pathcl[i], N_AMBIG, mapping);
	}
		
	printf("Removing ambiguities from global classifier\n");
	sRemoveAmbiguities(mc->globalcl, N_AMBIG, mapping);


#ifdef notneeded
	for(i = 0; i < MAXPATHS; i++) {
		printf("path %d...", i);
		sDoneAdding(mc->pathcl[i]);
		/* printf("ambig path %d...", i);
		sDoneAdding(mc->ambigpathcl[i]); */
	}
#endif

#ifdef kaka
	while( (*getfcn)(&mclassname, &mfv, &mexamplename) )  {
		if(mclassname == NULL) {
			printf("2nd pass, mclassname==NULL\n");
			continue;
		}

		mcd = mClassNameLookup(mc, mclassname);
		if(mcd == NULL) {
			printf("2nd pass, mcd==NULL\n");
			continue;
		}
	}
#endif

	for(m = 0; m < mc->nmclasses; m++) {
	    mcd = mc->mclassdope[m];
	    mclassname = mcd->classname;
	    for(e = 0; e < mcd->nexamples; e++) {
		me = &mcd->example[e];
		mexamplename = me->examplename;
		gf = me->gf;
		npaths = mcd->npaths;
		for(i = 0; i < npaths; i++)
			pf[i] = me->pf[i];

		/* begin c[] calc */
		c[npaths] = sClassify(mc->globalcl, gf)->number;
		for(i = 0; i < npaths; i++) {
			c[i] = sClassify(mc->pathcl[i], pf[i])->number;
		}
		/* end c[] calc */


		/*
		printf("In 2nd pass, calling DtAdd ");
		for(i = 0; i <= npaths; i++) printf("%d ", c[i]);
		printf("-> %s\n", mcd->classname);
		*/

		DtAdd(mc->decisiontree, c, npaths+1, mcd);
	    }
	}
}

mClassDope
mClassNameLookup(mc, classname)
mClassifier mc;
char *classname;
{
	register int i;
	register mClassDope mcd;

	for(i = 0; i < mc->nmclasses; i++) {
		mcd = mc->mclassdope[i];
		if(STREQ(mcd->classname, classname))
			return mcd;
	}
	return NULL;

}

void
mAddExample(mc, classname, mfv, examplename)
register mClassifier mc;
char *classname;
char *examplename;
MFV mfv;
{
	register mClassDope mcd;
	mExample me;
	register int i;

	Vector gf, pf[MAXPATHS];
	sClassIndex c[MAXPATHS+1];
	int npaths;
	char sclassname[100];
	char sexamplename[100];
	char *ename;
	sClassDope scd;

	mcd = mClassNameLookup(mc, classname);
	if(mcd == NULL) {
		mcd = mc->mclassdope[mc->nmclasses] =
			allocate(1, struct mclassdope);
		mcd->classname = scopy(classname); /* DMA 030891-1 scopy */
		mcd->number = mc->nmclasses;
		mcd->npaths = MfvNPaths(mfv);
		if(mcd->npaths > MAXPATHS)
			error("mAddExample: %s too many (%d) paths",
				classname, mcd->npaths);
		++mc->nmclasses;
	}

	if(mcd->nexamples >= MAXCLASSEXAMPLES)
		error("mAddExample: too many examples of class %s", classname);

	if(mcd->npaths != MfvNPaths(mfv))
	   error("mAddExample: wrong number of paths in class %s (%d not %d)",
			classname, MfvNPaths(mfv), mcd->npaths);

	if(mc->type == MCT_SORT && mcd->npaths > 1) {
		int sorting[MAXPATHS];
		printf("%s:", examplename);
		MfvSortPaths(mfv, sorting);
		for(i = 0; i < mcd->npaths; i++)
			printf("%d", sorting[i]);
		printf(" ");
	}

	/* save example */
	me = &mcd->example[mcd->nexamples++];
	for(i = 0; i < mcd->npaths; i++)
		me->pf[i] = VectorCopy( MfvPathCalc(mfv, i) );
	me->gf = VectorCopy( MfvGlobalCalc(mfv) );
	me->examplename = scopy(examplename); /* DMA 030891-1 scopy */

	/* train */
	switch(mc->type) {
	case MCT_SORT:

		/* here compute npaths, gf, pf.
		   just get them from example */

		npaths = mcd->npaths;
		gf = me->gf;
		for(i = 0; i < npaths; i++)
			pf[i] = me->pf[i];
		
		/* compute class names */

		sprintf(sclassname, "%s-GLOBAL", mcd->classname);
		sAddExample(mc->globalcl, sclassname, gf, me->examplename);
		c[npaths] = sClassNameLookup(mc->globalcl, sclassname)->number;

		for(i = 0; i < npaths; i++) {
			sprintf(sclassname, "%s-path%d", mcd->classname, i);
			sprintf(sexamplename, "%s-path%d",
				me->examplename, i);
			sAddExample(mc->pathcl[i], sclassname,
				pf[i], ename=scopy(sexamplename));
			scd = sClassNameLookup(mc->pathcl[i], sclassname);
			c[i] = scd->number;

			if(mcd->nexamples == 1)
				mcd->scd[i] = scd;
			else if(mcd->scd[i] != scd)
					error("%s: class %s != %s",
					  sexamplename, 
					  mcd->scd[i]->name, scd->name);

			/*
			if(mcd->nexamples <= N_AMBIG) {
				sAddExample(mc->ambigpathcl[i], sclassname,
					pf[i], ename);
			}
			*/
		}

		/*
		printf("calling DtAdd ");
		for(i = 0; i <= npaths; i++) printf("%d ", c[i]);
		printf("-> %s\n", mcd->classname);
		*/

		DtAdd(mc->decisiontree, c, npaths+1, mcd);

		break;

	case MCT_CLUSTER:
		break;
	
	default:
		error("mc->type");
	}
}

static void
DtAdd(dt, c, n, mcd)
register DecisionTree dt;
sClassIndex c[];
int n;
mClassDope mcd;
{
	register int i;
	int np;

/*
	printf("DtAdd(%x", dt); for(i=0; i<n; i++) printf("%d ", c[i]); printf("-> %s\n", mcd->classname);
*/

	if(dt == NULL)
		return;
	if(n == 0) {
		if(dt->mclass != NULL && dt->mclass != mcd) {
			printf("DT Conflict between %s and %s\n",
				mcd->classname, dt->mclass->classname);
			return;
		}
		dt->mclass = mcd;
		return;
	}
	/* TODO: get true value instead of MAXPATHCLASSES */
	/* hard to do, since we haven't computed it yet */
	np = MAXPATHCLASSES;
	if(dt->next == NULL) {
		dt->next = allocate(np, DecisionTree);
		for(i = 0; i < np; i++)
			dt->next[i] = NULL;
		dt->mclass = mcd;
	}
	if(*c < 0 || *c >= np) {
		printf("DT *c=%d out of range\n", *c);
		return;
	}

	if(dt->next[ *c ] == NULL) {
		register DecisionTree t = allocate(1, struct decisiontree);
		t->mclass = NULL;
		t->next = NULL;
		dt->next[ *c ] = t;
		if(dt->mclass != NULL && dt->mclass != mcd)
			dt->mclass = NULL;
	}

	DtAdd(dt->next[ *c ], c+1, n-1, mcd);
}

int classindexcmp(a,b) sClassIndex *a, *b; { return *a - *b; }

int _sorting[MAXPATHS];
sClassDope _scd[MAXPATHS], _gc;

mClassDope
mClassify(mc, mfv)
register mClassifier mc;
register MFV mfv;
{
	int n, npaths;
	Vector gf, pf[MAXPATHS];
	register int i;
	sClassIndex c[MAXPATHS+1];
	register DecisionTree dt;
	mClassDope lastmclass;

	switch(mc->type) {
	case MCT_SORT:
		/* begin c[] calc */
		npaths = MfvNPaths(mfv);
		MfvSortPaths(mfv, _sorting);
		gf = MfvGlobalCalc(mfv);
		c[npaths] = (_gc = sClassify(mc->globalcl, gf))->number;
		for(i = 0; i < npaths; i++) {
			pf[i] = MfvPathCalc(mfv, i);
			c[i] = (_scd[i]=sClassify(mc->pathcl[i], pf[i]))->number;
		}
		/* end c[] calc */
		break;

	case MCT_CLUSTER:
		/* begin c[] calc */
		npaths = MfvNPaths(mfv);
		gf = MfvGlobalCalc(mfv);
		c[npaths] = (_gc = sClassify(mc->globalcl, gf))->number;
		for(i = 0; i < npaths; i++) {
			pf[i] = MfvPathCalc(mfv, i);
			c[i] = (_scd[i]=sClassify(mc->pathcl[0], pf[i]))->number;
		}
		qsort(c, npaths, sizeof(c[0]), classindexcmp);
		/* end c[] calc */

	default:
		error("mc->type2");
	}

	lastmclass = NULL;
	for(dt = mc->decisiontree, i = 0; i <= npaths; i++) {
		if(dt == NULL)
			return lastmclass;
		lastmclass = dt->mclass;
		if(dt->next == NULL)
			return lastmclass;
		dt = dt->next[ c[i] ];
	}
	if(dt == NULL)
		return lastmclass;
	return dt->mclass;
}

mDump(mc)
register mClassifier mc;
{
	sClassIndex c[MAXPATHS+1];
	mDumpDt(mc->decisiontree, c, 0);
}

mDumpDt(dt, c, n)
DecisionTree dt;
sClassIndex c[];
int n;
{
	int i;

	if(dt == NULL)
		return;
	if(dt->mclass) {
		for(i = 0; i < n; i++)
			printf("%2d ", c[i]);
		printf("-> %s\n", dt->mclass->classname);
	}
	if(dt->next == NULL)
		return;

	for(i = 0; i < MAXMCLASSES; i++) {
		c[n] = i;
		mDumpDt(dt->next[i], c, n+1);
	}
}
