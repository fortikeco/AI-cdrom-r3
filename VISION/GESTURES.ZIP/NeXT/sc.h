/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/


/*
 single path classifier
   rewritten here instead of reusing code for sanity reasons
*/

#define	MAXSCLASSES	200
#define	MAXEXAMPLES	100

typedef struct sclassifier *sClassifier; /* single feature-vector classifier */
typedef int		    sClassIndex; /* single feature-vector class index */
typedef struct sclassdope  *sClassDope;	 /* single feature-vector class dope */

struct sclassdope {
	char 		*name;
	sClassIndex	number;
	Vector		sum, average;
	Matrix		sumcov;

	int		nexamples;
	struct sexample {
		Vector		fv;
		char		*examplename;
	} example[MAXEXAMPLES];
};

#define	SCF_BLUR	001

struct sclassifier {
	int		nfeatures;
	int		nclasses;
	sClassDope	*classdope;
	BitVector	features;

	Vector		cnst;	/* term of discrimination function */
	Vector		*w;	/* array of coefficient weights and constant */
	Matrix		invavgcov; /* inverse covariance matrix */
	int		flags;
};

sClassifier sNewClassifier();
sClassDope sClassNameLookup();	/* sc, classname */
void       sAddExample();	/* sc, classname, y */
void	   sDoneAdding();	/* sc */
sClassDope sClassify();		/* sc, fv */
sClassDope sClassifyAD();	/* sc, fv, ap, dp */
Matrix	   SumCov();		/* sc, scd */
void	sRemoveAmbiguities();  /* sc, nambigexamples, resultingscd[] */
double MahalanobisDistance();	/* Vector v, u; Matrix sigma */
