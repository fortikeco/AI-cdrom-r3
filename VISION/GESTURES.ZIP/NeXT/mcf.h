/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/

/*
 MFV - computes and stores multi-path feature vectors
 */

#define	NGLOBALFEATURES	9
#define	NPATHFEATURES	12
#define	MAXPATHS	4


#define	NQUICKFEATURES	5

/* global features */

#define	GF_DUR		0	/* duration of gesture */
#define	GF_BB_LEN	1	/* length of bounding box diagonal */
#define	GF_BB_TH	2	/* angle of bounding box diagonal */
#define	GF_F_TO_F_LEN	3	/* first point in first path to first point
				   in last path, weighted by time difference
				   between path start times */
#define	GF_F_TO_F_SIN	4	/* sine of FF angle, weighted by time diff */
#define	GF_F_TO_F_COS	5	/* cos of FF angle, weighted by time diff */


#define	GF_F_TO_L_LEN	6	/* first point of first path to last point
				   of last path, weighted by (above) time df */
#define	GF_F_TO_L_SIN	7	/* sine of FL angle, weighted by time diff */
#define	GF_F_TO_L_COS	8	/* cos of FL angle, weighted by time diff */

/* path features */

/* #define	PF_DUR		0	/* duration of path */ 
#define	PF_START	0	/* start time */
#define	PF_INIT_COS	1	/* initial angle (cos) */
#define	PF_INIT_SIN	2	/* initial angle (sin) */
#define	PF_BB_LEN	3	/* length of bounding box diagonal */
#define	PF_BB_TH	4	/* angle of bounding box diagonal */
#define	PF_SE_LEN	5	/* length between start and end points */
#define	PF_SE_COS	6	/* cos of angle between start and end points */
#define	PF_SE_SIN	7	/* sin of angle between start and end points */
#define	PF_LEN		8	/* arc length of path */
#define	PF_TH		9	/* total angle traversed */
#define	PF_ATH		10	/* sum of abs vals of angles traversed */
#define	PF_SQTH		11	/* sum of squares of angles traversed */
/* #define	PF_MAXV		12	/* maximum speed */

typedef struct mfv {
	/* settable parameters */

	int		flags;		/* currently undefined */
	double		distsq_threshold;  /* distance (squared) threshold */
	int		npathfeatures, nglobalfeatures;

	/* computed on every point */
	int		npaths; 	/* total number of paths */
	int		npoints;  	/* # of points in feature vector */
	long		starttime;
	long		endtime;
	double		minx, maxx, miny, maxy;

	/* per path information */

	struct path {
		/* these values are set on the path's first point */

		int		index;
		double		startx, starty; /* starting point */
		long		starttime;

		/* this one is set after three points */

		double		initial_sin, initial_cos;
					/* initial angle to x axis */

		/* these are updated incrementatally upon every point */

		int		npoints;	/* number of points in path */

		double		dx2, dy2; 	/* differences: endx-prevx
								endy-prevy */
		double		magsq2;		/* dx2*dx2 + dy2*dy2 */

		double		endx, endy; 	/* last point added */
		long		endtime;

		double		minx, maxx, miny, maxy;  /* bounding box */

		double		path_r, path_th; /* total length and rotation
							(in rads) */
		double		abs_th;		/* sum of absolute values of
							path angles */
		double		sharpness;	/* sum of non-linear function
						    of abs vals of path angles
						    counting acute angles
						    heavier */
		double		maxv;

	/* these are computed when the feature vector is needed */

		double		box_r, box_th;	/* bounding box 
						    (diagonal length & angle) */
		double		end_r, end_sin, end_cos;
				    /* computed from start and end points */

		Vector		py;	/* Actual path feature vector */
	} path[MAXPATHS];

	Vector		gy;	/* Actual global feature vector */

	int		ntimeouts;
	int		nquickfeatures;
	Vector		qy;	/* quick feature vector */

	struct path *sortedpath[MAXPATHS];
} *MFV;


/*
  Flags
 */

MFV	MfvAlloc();	/* int flags */
void	MfvInit();	/* MFV mfv */
int	MfvAddPoint();	/* MFV mfv; double x, y; long t; int path */
int	MfvNPaths();	/* mfv */
void	MfvSortPaths();	/* mfv */
Vector	MfvPathCalc();	/* MFV mfv, int path */
Vector	MfvGlobalCalc();	/* MFV mfv */

void	MfvDump();	/* mfv */
void	MfvNoPoint();
