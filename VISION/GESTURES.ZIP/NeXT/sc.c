
/***********************************************************************

sc.c - classifies a single feature vector, and creates classifiers

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 1, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (in ../COPYING); if not, write to the Free
Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***********************************************************************/

#include "bitvector.h"
#include "matrix.h"
#include "util.h"
#include "sc.h"
#include <stdio.h>
#include <math.h>
#include <string.h>

extern FixClassifier();
extern sDumpClassifier();

sClassifier
sNewClassifier()
{
	register sClassifier sc = allocate(1, struct sclassifier);
	sc->nfeatures = -1;
	SET_BIT_VECTOR(sc->features);
	sc->nclasses = 0;
	sc->classdope = allocate(MAXSCLASSES, sClassDope);
	sc->w = NULL;
	return sc;
}

int
sNClasses(sc)
register sClassifier sc;
{
	return sc->nclasses;
}

sClassDope
sClassNameLookup(sc, classname)
register sClassifier sc;
register char *classname;
{
	register int i;
	register sClassDope scd;

	for(i = 0; i < sc->nclasses; i++) {
		scd = sc->classdope[i];
		if(STREQ(scd->name, classname))
			return scd;
	}
	return NULL;
}

static sClassDope
sAddClass(sc, classname)
register sClassifier sc;
char *classname;
{
	register sClassDope scd;

	scd = sc->classdope[sc->nclasses] =
		allocate(1, struct sclassdope);
	scd->name = scopy(classname);
	scd->number = sc->nclasses;
	scd->nexamples = 0;
	scd->sumcov = NULL;
	++sc->nclasses;
	return scd;
}

void
sAddExample(sc, classname, y, examplename)
register sClassifier sc;
char *classname;
Vector y;
char *examplename;
{
	register sClassDope scd;
	register int i;

	scd = sClassNameLookup(sc, classname);
	if(scd == NULL)
		scd = sAddClass(sc, classname);

	if(scd->nexamples >= MAXEXAMPLES)
		printf("Class %s, too many examples\n", scd->name);

	if(sc->nfeatures == -1)
		sc->nfeatures = NROWS(y);
	else if(sc->nfeatures != NROWS(y)) {
		PrintVector(y, "sAddExample: funny feature vector nrows!=%d", 
			sc->nfeatures);
		return;
	}

	if(scd->nexamples == 0) {
		scd->sum = NewVector(sc->nfeatures);
		scd->average = NewVector(sc->nfeatures);
		for(i = 0; i < sc->nfeatures; i++)
			scd->sum[i] = 0.0;
	}

	scd->example[scd->nexamples].fv = VectorCopy(y);
	scd->example[scd->nexamples].examplename = examplename;
	scd->nexamples++;

	for(i = 0; i < sc->nfeatures; i++)
		scd->sum[i] += y[i];
}

sBlur(sc)
register sClassifier sc;
{
	sc->flags |= SCF_BLUR;
}

void
sDoneAdding(sc)
register sClassifier sc;
{
	register int i, j;
	int c, e;
	int ne, denom;
	double oneoverdenom;
	register Matrix s;
	register Matrix avgcov;
	Vector avg;
	double det;
	register sClassDope scd;


	printf("Training classifier %x, please wait...", sc); fflush(stdout);

	if(sc->nclasses == 0) {
		printf("No classes\n");
		return;
	}

	/* Given covariance matrices for each class (* number of examples - 1)
	    compute the average (common) covariance matrix */

	avgcov = NewMatrix(sc->nfeatures, sc->nfeatures);
	ZeroMatrix(avgcov);
	ne = 0;
	for(c = 0; c < sc->nclasses; c++) {
		scd = sc->classdope[c];
		ne += scd->nexamples;
		s = SumCov(sc, scd);
		for(i = 0; i < sc->nfeatures; i++)
			for(j = i; j < sc->nfeatures; j++)
				avgcov[i][j] += s[i][j];
	}

	denom = ne - sc->nclasses;
	if(denom <= 0) {
		printf("no examples, denom=%d\n", denom);
		return;
	}

	oneoverdenom = 1.0 / denom;
	for(i = 0; i < sc->nfeatures; i++)
		for(j = i; j < sc->nfeatures; j++) {
			avgcov[i][j] *= oneoverdenom;
			avgcov[j][i] = avgcov[i][j];
		}

	/* invert the avg covariance matrix */

	sc->invavgcov = NewMatrix(sc->nfeatures, sc->nfeatures);
	det = InvertMatrix(avgcov, sc->invavgcov);
	if(fabs(det) <= 1.e-6) {
		FixClassifier(sc, avgcov);
	}
	
	/* now compute discrimination functions */
	sc->w = allocate(sc->nclasses, Vector);
	sc->cnst = NewVector(sc->nclasses);
	for(c = 0; c < sc->nclasses; c++) {
		scd = sc->classdope[c];
		sc->w[c] = NewVector(sc->nfeatures);
		VectorTimesMatrix(scd->average, sc->invavgcov, sc->w[c]);
		sc->cnst[c] = -0.5 * InnerProduct(sc->w[c], scd->average);
		/* should add log(priorprob class c) to cnst[c] */
	}

	/* done */
	printf("Done\n");
	FreeMatrix(avgcov);
	return;
}

sClassDope
sClassify(sc, fv)
sClassifier sc;
Vector fv;
 {
	return sClassifyAD(sc, fv, NULL, NULL);
 }

sClassDope
sClassifyAD(sc, fv, ap, dp)
sClassifier sc;
Vector fv;
double *ap;
double *dp;
{
	double maxdisc, disc[MAXSCLASSES];
	register int i, maxclass;
	double denom, exp();
	register sClassDope scd;

	if(sc->w == NULL)
		error("sClassifyAD: %x no trained classifier", sc);

	for(i = 0; i < sc->nclasses; i++)
		disc[i] = InnerProduct(sc->w[i], fv) + sc->cnst[i];

	maxclass = 0;
	for(i = 1; i < sc->nclasses; i++)
		if(disc[i] > disc[maxclass])
			maxclass = i;

	scd = sc->classdope[maxclass];

	if(ap) {	/* calculate probability of non-ambiguity */
		for(denom = 0, i = 0; i < sc->nclasses; i++)
			denom += exp(disc[i] - disc[maxclass]);
		*ap = 1.0 / denom;
	}

	if(dp) 	/* calculate distance to mean of chosen class */
		*dp = MahalanobisDistance(fv, scd->average, sc->invavgcov);

	return scd;
}

Matrix
SumCov(sc, scd)
register sClassifier sc;
register sClassDope scd;
{

	double oneovern;
	register int i, j;
	Vector efv, nfv;
	int e;

	if(scd->nexamples == 0) {
		printf("SumCOv: no examples\n");
		return NULL;
	}

	oneovern = 1.0 / scd->nexamples;
	for(i = 0; i < sc->nfeatures; i++)
		scd->average[i] = scd->sum[i] * oneovern;

	if( ! scd->sumcov)
		scd->sumcov = NewMatrix(sc->nfeatures, sc->nfeatures);

	/* start with null matrix */
	ZeroMatrix(scd->sumcov);

	/* compute upper triangular part */
	nfv = NewVector(sc->nfeatures);
	for(e = 0; e < scd->nexamples; e++) {
	    for(i = 0; i < sc->nfeatures; i++)
		nfv[i] = scd->example[e].fv[i] - scd->average[i];
	    for(i = 0; i < sc->nfeatures; i++)
	       for(j = i; j < sc->nfeatures; j++)
		scd->sumcov[i][j] += nfv[i] * nfv[j];

	     /* compute the lower part of the triangular matrix */
	    for(i = 0; i < sc->nfeatures; i++)
	        for(j = i+1; j < sc->nfeatures; j++)
	  	    scd->sumcov[j][i] = scd->sumcov[i][j];
	}

	return scd->sumcov;
}

/*
 Compute (v-u)' sigma (v-u)
 */

double
MahalanobisDistance(v, u, sigma)
register Vector v, u;
register Matrix sigma;
{
	register i;
	static Vector space;
	double result;

	if(space == NULL || NROWS(space) != NROWS(v)) {
		if(space) FreeVector(space);
		space = NewVector(NROWS(v));
	}


	for(i = 0; i < NROWS(v); i++)
		space[i] = v[i] - u[i];

#ifdef PIQ_DEBUG
	printf("\n");
	for(i = 0; i < NROWS(v); i++)
		printf("%g(%g-%g) ", space[i], v[i], u[i]);
#endif

	result =  QuadraticForm(space, sigma);

#ifdef PIQ_DEBUG
	printf(" %g ", result);
#endif

	return result;
}

FixClassifier(sc, avgcov)
register sClassifier sc;
Matrix avgcov;
{
	int i;
	double det;
	BitVector bv;
	Matrix m, r;

	/* just add the features one by one, discarding any that cause
	   the matrix to be non-invertible */
	printf("fixing...");
	CLEAR_BIT_VECTOR(bv);
	for(i = 0; i < sc->nfeatures; i++) {
		BIT_SET(i, bv);
		m = SliceMatrix(avgcov, bv, bv);
		r = NewMatrix(NROWS(m), NCOLS(m));
		det = InvertMatrix(m, r);
		if(fabs(det) <= 1.e-6) {
			printf("-f%d ", i);
			BIT_CLEAR(i, bv);
		}
		else {
			printf("+f%d ", i);
		}
		FreeMatrix(m);
		FreeMatrix(r);
	}

	ASSIGN_BIT_VECTOR(sc->features, bv);
	m = SliceMatrix(avgcov, sc->features, sc->features);
	r = NewMatrix(NROWS(m), NCOLS(m));
	det = InvertMatrix(m, r);
	if(fabs(det) <= 1.e-6)
		error("Can't fix classifier!");
	DeSliceMatrix(r, 0.0, sc->features, sc->features, sc->invavgcov);
/*
	PrintMatrix(r, "\nbefore deslicing\n");
	PrintMatrix(sc->invavgcov, "\nafter deslicing\n");
*/
	FreeMatrix(m);
	FreeMatrix(r);

#ifdef old
	/*
	PrintMatrix(avgcov,
		"avgcov: singular average covariance matrix");
	*/
	printf(" avgcov: singular average covariance matrix\n");
	printf(" examples: ");
	for(c = 0; c < sc->nclasses; c++) {
	    scd = sc->classdope[c];
	    for(e = 0; e < scd->nexamples; e++) {
		printf("%s ", scd->example[e].examplename);
	    }
	}
	printf("\n");

	det = InvertSingularMatrix(avgcov, sc->invavgcov);

	if(fabs(det) <= 1.e-6 && sc->flags & SCF_BLUR &&
	   ne < (MAXEXAMPLES*sc->nclasses*.4)) {
		Vector y = NewVector(sc->nfeatures);
		Vector std = NewVector(sc->nfeatures);
		int r;
		char newname[100];
#			define NRAND	1000
#			define	VAR	0.20

		printf("Blurring %d examples..", ne); fflush(stdout);

		for(c = 0; c < sc->nclasses; c++) {
		    scd = sc->classdope[c];
		    for(i = 0; i < sc->nfeatures; i++)
			std[i] = sqrt(scd->sumcov[i][i]);
		    ne = scd->nexamples;
		    for(e = 0; e < ne; e++) {
		      for(i = 0; i < sc->nfeatures; i++) {
			r = (rand() % (2*NRAND+1)) - NRAND;
			y[i] = scd->example[e].fv[i] +
				std[i]*(VAR/NRAND)*r;

		      }
		      /*
			printf("%g(%g+%g*%g) ",
				y[i], scd->example[e].fv[i],
				std[i], VAR*r);
			printf("\n");
		      */

		      sprintf(newname, "%s-D",
			  scd->example[e].examplename);
		      sAddExample(sc, scd->name, y, scopy(newname));
		    }
		}
		
		FreeMatrix(avgcov);
		FreeVector(y);
		FreeVector(std);
		sDoneAdding(sc);
		return;
	}
#endif
}

/* Copy classifier classes, but not examples */

sClassifier
sSkeletalCopy(sc)
register sClassifier sc;
{
	register sClassifier rc = sNewClassifier();
	register sClassDope scd, rcd;
	register sClassIndex c;

	for(c = 0; c < sc->nclasses; c++) {
		scd = sc->classdope[c];
		rcd = sAddClass(rc, scd->name);
		if(rcd->number != scd->number)
			error("sSkeletalCopy1");
	}
	return rc;
}


/* union alg */
 
static
combine(c1, c2, n, map)
sClassIndex c1, c2;
int n;
int map[];
{
	register sClassIndex c, min, max;

	min = map[c1], max = map[c2];
	if(min > max) min = map[c2], max = map[c1];
	for(c = 0; c < n; c++)
		if(map[c] == max)
			map[c] = min;
}

static
sMergeClasses(sc, c1, c2)
sClassifier sc;
sClassIndex c1, c2;
{
	char newname[200];
	register int e, i;

	register sClassDope scd1 = sc->classdope[c1], scd2 = sc->classdope[c2];

	if(scd1->nexamples == 0)
		error("%x: MergeClasses %d(%s) no examples (already merged)",
			sc, c1, scd1->name);
	if(scd2->nexamples == 0)
		error("%x: MergeClasses2 %d(%s) no examples (already merged)",
			sc, c2, scd2->name);

	for(e = 0; e < scd2->nexamples; e++) {
		scd1->example[scd1->nexamples].fv = scd2->example[e].fv;
		scd1->example[scd1->nexamples].examplename =
			scd2->example[e].examplename;
		scd1->nexamples++;
	}

	for(i = 0; i < sc->nfeatures; i++)
		scd1->sum[i] += scd2->sum[i];

	scd2->nexamples = 0;
	sprintf(newname, "%s=%s", scd1->name, scd2->name);
	free(scd1->name), scd1->name = scopy(newname);
}

void
sRemoveEmptyClasses(sc)
register sClassifier sc;
{
	register sClassIndex c, nc;
	register sClassDope scd;

	for(nc = c = 0; c < sc->nclasses; c++) {
		scd = sc->classdope[c];
		if(scd->nexamples != 0)
			sc->classdope[nc++] = sc->classdope[c];
	}
	sc->nclasses = nc;
}

#define	THRESH	.03	/* if more than 3% are misclassified, combine */

void
sRemoveAmbiguities(sc, nambigexamples, map)
register sClassifier sc;
int nambigexamples; /* per class */
int map[];
{
	register sClassDope scd;
	register sClassIndex c, c2;
	register sClassifier ambigc;
	register sClassDope acd;
	register int e;
	int nclassified;
	Matrix m;

	for(c = 0; c < sc->nclasses; c++)
		map[c] = c;

	if(sc->nclasses <= 1)
		return;

	ambigc = sSkeletalCopy(sc);
	for(c = 0; c < sc->nclasses; c++) {
		scd = sc->classdope[c];
		for(e = 0; e < scd->nexamples && e < nambigexamples; e++)
			sAddExample(ambigc, scd->name, scd->example[e].fv, 
					scd->example[e].examplename);
	}
	printf("ambig classifier for %x ", sc);
	sDoneAdding(ambigc);

	/* now that the classifier is built, go through remaining examples
	   looking for misclassified ones */

	nclassified = 0;
	m = NewMatrix(sc->nclasses, sc->nclasses);
	ZeroMatrix(m);

	for(c = 0; c < sc->nclasses; c++) {
	    scd = sc->classdope[c];
	    for(e = nambigexamples; e < scd->nexamples; e++) {
		acd = sClassify(ambigc, scd->example[e].fv);


		/* m is a triangular matrix: m[i][j] counts how
		   many times class i was classified as class j
		   or class j as class i */

		if(acd->number <= scd->number)
			++m[acd->number][scd->number];
		else
			++m[scd->number][scd->number];

/*

		printf("%s: %s %s %s\n", me->examplename,
			scd->name, mcd->scd[p]->name, 
			scd->number==mcd->scd[p]->number ? "" : "!!!!");
*/
	    }
	}

	for(c = 0; c < sc->nclasses; c++) {
		for(c2 = c+1; c2 < sc->nclasses; c2++) {
		    if(m[c][c2] > 0) {
			printf("%s and %s %g confused, %g+%g correct, %4.1f%%\n", 
				sc->classdope[c]->name,
				sc->classdope[c2]->name,
				m[c][c2],
				m[c][c],
				m[c2][c2],
				(100.0 * m[c][c2])/(m[c][c2]+m[c][c]+m[c2][c2])
				);

			if(m[c][c2]/(m[c][c2]+m[c][c]+m[c2][c2]) >= THRESH) {
				printf("Combining %s and %s\n", 
					sc->classdope[c]->name,
					sc->classdope[c2]->name);
				combine(c, c2, sc->nclasses, map);
			}
		    }
		}
	}

	FreeMatrix(m);

	for(c = 0; c < sc->nclasses; c++) {
		printf("Class %d: ", c);
		for(c2 = 0; c2 < sc->nclasses; c2++)
			if(map[c2] == c)
				printf("%s ", sc->classdope[c2]->name);
		printf("\n");

	}

	for(c = 0; c < sc->nclasses; c++)
		if(c != map[c])
			sMergeClasses(sc, map[c], c);
	sRemoveEmptyClasses(sc);
	sDumpClassifier(sc);
	sDoneAdding(sc);
	return;
}

sDumpClassifier(sc)
register sClassifier sc;
{
	register sClassIndex c;
	register sClassDope scd;


	printf("\n----Classifier %x, %d features:-----\n", sc, sc->nfeatures);
	printf("%d classes: ", sc->nclasses);
	for(c = 0; c < sc->nclasses; c++)
		printf("%s  ", sc->classdope[c]->name);
	printf("\n---------\n\n");
}
