/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/

#include "util.h"
#include "functab.h"
#include "stdio.h"
/*
 Format of a function table:

	name npoints minx maxx
	y1 y2 ...
 */


static
FuncTab
NewFuncTab(name, npoints, minx, maxx)
char *name;
int npoints;
double minx, maxx;
{
	register FuncTab ft = allocate(1, struct functab);
	ft->name = scopy(name);
	ft->n = npoints;
	ft->points = allocate(ft->n, double);
	if(maxx < minx + 1.0e-5)
		error("%s: maxx %g < minx %g + 1.0e-5", ft->name, maxx, minx);
	if(ft->n <= 1)
		error("%s: too few points %d", ft->name, ft->n);
	ft->scale = (ft->n - 1) / (maxx - minx) ;
	ft->offset = -minx * ft->scale + 0.5;	/* .5 for rounding */
	return ft;
}

FuncTab
ReadFuncTab(f)
FILE *f;
{
	register FuncTab ft;
	char name[50];
	int npoints;
	double minx, maxx;
	double y;
	register int i;

	if(fscanf(f, "%s %d %lf %lf", name, npoints, &minx, &maxx) != 4)
		error("ReadFuncTab: bad header");
	ft = NewFuncTab(name, npoints, minx, maxx);
	for(i = 0; i < ft->n; i++) {
		if(fscanf(f, "%lf", &y) != 1)
			error("%s: Error reading %d'th point", ft->name, i);
		ft->points[i] = y;
	}
	return ft;
}

FuncTab
GenFuncTab(name, npoints, minx, maxx, f)
char *name;
int npoints;
double minx, maxx;
double (*f)();
{
	register int i;
	double y;
	register FuncTab ft = NewFuncTab(name, npoints, minx, maxx);
	for(i = 0; i < npoints; i++)
		ft->points[i] = (*f)(minx + (i*(maxx-minx))/(npoints-1));
	return ft;
}

double
EvalFuncTab(ft, x)
register FuncTab ft;
double x;
{
	int index = ft->scale * x + ft->offset;
	if(index < 0 || index >= ft->n)
		error("%s(%g): index=%d n=%d", ft->name, x, index, ft->n);
	return ft->points[index];
}

