
/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
/*
 Create different mClassifiers depending on the number of paths
 */

typedef struct npclassifier {
	mClassifier 	mc[MAXPATHS];
} *npClassifier;

npClassifier	npNewClassifier();
void		npAddExample();		/* npc, classname, mfv */
void		npDoneAdding();		/* npc */
void		npSortPaths();		/* npc */
mClassDope	npClassNameLookup();	/* npc, classname */
mClassDope	npClassify();		/* npc, mfv */

