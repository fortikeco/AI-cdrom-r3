/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
#include "bitvector.h"
#include "matrix.h"
#include "util.h"
#include "sc.h"
#include "mc.h"
#include "npc.h"
#include "mcf.h"
#include "stdio.h"

npClassifier
npNewClassifier()
{
	register npClassifier npc;
	register int p;

	npc = allocate(1, struct npclassifier);
	for(p = 0; p < MAXPATHS; p++)
		npc->mc[p] = mNewClassifier();
	return npc;
}

void
npSortPaths(npc)
register npClassifier npc;
{
	register int p;

	for(p = 0; p < MAXPATHS; p++)
		mSortPaths(npc->mc[p]);
}

void
npDoneAdding(npc)
register npClassifier npc;
{
	register int p;

	for(p = 0; p < MAXPATHS; p++)
		mDoneAdding(npc->mc[p]);
}

void
npAddExample(npc, classname, mfv, examplename)
register npClassifier npc;
char *classname, *examplename;
MFV mfv;
{
	mAddExample(npc->mc[ MfvNPaths(mfv) ], classname, mfv, examplename);
}

mClassDope
npClassNameLookup(npc, classname)
npClassifier npc;
char *classname;
{
	register int p;
	register mClassDope mcd;

	for(p = 0; p < MAXPATHS; p++)
		if((mcd = mClassNameLookup(npc->mc[p], classname)) != NULL)
			return mcd;
	return NULL;
}

mClassDope
npClassify(npc, mfv)
register npClassifier npc;
register MFV mfv;
{
	return mClassify(npc->mc[ MfvNPaths(mfv) ], mfv);
}
