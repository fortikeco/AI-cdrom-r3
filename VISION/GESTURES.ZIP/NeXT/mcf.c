/***********************************************************************

mcf.c - converts multi-path input data into a set of feature vectors

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 1, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program (in ../COPYING); if not, write to the Free
Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***********************************************************************/

#include <stdio.h>
#include <math.h>

#include "matrix.h"
#include "mcf.h"
#include "util.h"
#include "functab.h"

static lcs();

/*
 Abstract data type encapsulating incremental computation of a feature
 global.
	Calls:
		mfv = MfvAlloc(flags);initial allocation of a feature vector
		MfvInit(mfv);	clears feature vector
		MfvAddPoint(mfv, x, y, t, path) adds a point
		n = MfvNPaths(mfv)  number of paths
		MfvSortPaths(mfv)   normalized path ordering
		y = MfvPathCalc(mfv, path) returns the path feature vector
		y = MfvGlobalCalc(p, mfv)	returns the global feature vector
		MfvDump(mfv);	prints out contents
		MfvPlot();	dump stored functions

*/

/* initialization */


#define	INF	(1.0e6)
int PlotPwl = 0;
int calcverbose = 0;

#define	P	if(PlotPwl)
#define	C	if(calcverbose)


#define	PwlInit(x) 	(PPwlNull(&x), PPwlSetName(&x, "x"))

static FuncTab acos2;

/* Pwl Pabs_th, Ppath_r, Ppath_th, Pth, Pcos2, Ppath, Psharpness; */

static
MfvFirstTime()
{
	double invcos2();
	acos2 = GenFuncTab("acos2", 100, -1.0, 1.0, invcos2);
	P {
	/*
		PwlInit(Psharpness);
		PwlInit(Pabs_th);
		PwlInit(Ppath_r);
		PwlInit(Ppath_th);
		PwlInit(Pth);
		PwlInit(Pcos2);
		PwlInit(Ppath);
	*/
	}
}

void
MfvPlot()
{
	P {
		FILE *f = fopen("calc.pwl", "w"); 
		if(f == NULL) error("Can't create calc.pwl");
		printf("calc.pwl "); fflush(stdout);
		/* PPwlWrite(&Psharpness, f); */
		/* PPwlWrite(&Pabs_th, f); */
		/* PPwlWrite(&Ppath_r, f); */
		/* PPwlWrite(&Ppath_th, f); */
		/* PPwlWrite(&Pth, f); */
		/* PPwlWrite(&Pcos2, f); */
		/* PPwlWrite(&Ppath, f); */
		fclose(f);
		printf("written\n");
	}
}

MFV
MfvAlloc(flags)
int flags;
{
	register MFV mfv;
	register struct path *p;
	static called;

	if( ! called) 	/* first time called */
		called = 1, MfvFirstTime();
	
	mfv = allocate(1, struct mfv);
	mfv->flags = flags;
	mfv->npathfeatures = NPATHFEATURES;
	mfv->nglobalfeatures = NGLOBALFEATURES;
	mfv->nquickfeatures = NQUICKFEATURES;

	mfv->gy = NewVector(mfv->nglobalfeatures);
	for(p = &mfv->path[0]; p < &mfv->path[MAXPATHS]; p++)
		p->py = NewVector(mfv->npathfeatures);

	/* mfv->qy = NewVector(mfv->nquickfeatures); */

	MfvInit(mfv);
	return mfv;
}

void
MfvInit(mfv)
register MFV mfv;
{
	register struct path *p;
	register int i;

	/* actually, this all could be implemented with a structure copy
	   much more efficiently (except for pointers) */

	mfv->npoints = 0;
	mfv->npaths = 0;
	mfv->minx = INF;
	mfv->maxx = -INF;
	mfv->miny = INF;
	mfv->maxy = -INF;
	mfv->distsq_threshold = .0005;

	for(p = &mfv->path[0]; p < &mfv->path[MAXPATHS]; p++) {

		p->index = p - mfv->path;
		mfv->sortedpath[p->index] = p;

		p->npoints = 0;
		for(i = 0; i < mfv->npathfeatures; i++)
			p->py[i] = 0.0;
	}
	

	for(i = 0; i < mfv->nglobalfeatures; i++)
		mfv->gy[i] = 0.0;

	/*
	mfv->ntimeouts = 0;
	for(i = 0; i < mfv->nquickfeatures; i++)
		mfv->qy[i] = 0.0;
	*/
}

int
MfvAddPoint(mfv, x, y, t, path) 
register MFV mfv;
double x, y;
long t;
int path;
{
	register struct path *p;
	double dx1, dy1, magsq1;
	double dot, cos2, th;
	double d, v;
	long lasttime;

	if(path > mfv->npaths)
		error("MfvAddPoint: path %d > npaths=%d", path, mfv->npaths);
	if(path >= MAXPATHS)
		error("MfvAddPoint: path %d >= MAXPATHS=%d", path, MAXPATHS);

	if(++mfv->npoints == 1) {
		mfv->starttime = t;
	}

	mfv->endtime = t;
	if(x < mfv->minx) mfv->minx = x;
	if(x > mfv->maxx) mfv->maxx = x;
	if(y < mfv->miny) mfv->miny = y;
	if(y > mfv->maxy) mfv->maxy = y;

	/* P PPwlInsertAfterCurrentPoint(&Ppath, x, y); */

	p = &mfv->path[path];
	if(++p->npoints == 1) {		/* first point in path */
		mfv->npaths++;
		p->starttime = p->endtime = t;
		p->startx = x; p->starty = y;
		p->endx = x; p->endy = y;
		p->starttime = t;
		p->initial_sin = p->initial_cos = 0;
		p->minx = p->maxx = x;
		p->miny = p->maxy = y;
		p->maxv = 0;
		p->abs_th = 0;
		p->sharpness = 0;
		p->path_th = 0;
		p->path_r = 0;
		return 1;
	}
	else {
		dx1 = x - p->endx; dy1 = y - p->endy;
		magsq1 = dx1 * dx1 + dy1 * dy1;
		if(magsq1 < mfv->distsq_threshold) {
			p->npoints--;
			return 0;		/* ignore this point */
		}
	}

	lasttime = p->endtime;
	p->endtime = t;
	if(x < p->minx) p->minx = x;
	if(x > p->maxx) p->maxx = x;
	if(y < p->miny) p->miny = y;
	if(y > p->maxy) p->maxy = y;

	if(p->npoints >= 3) {
		if(p->npoints == 2 || p->npoints == 3) {
				/* calculate initial theta */
			double magsq, dx, dy, recip;
			dx = x - p->startx; dy = y - p->starty;
			magsq = dx * dx + dy * dy;
			if(magsq < mfv->distsq_threshold)  {
				magsq = magsq1, dx = dx1, dy = dy1;
				if(p->npoints==3)
					printf("initial theta\n");
			}
			/* find angle w.r.t. positive x axis e.g. (1,0) */
			recip = 1 / sqrt(magsq);
			p->initial_cos = dx * recip;
			p->initial_sin = dy * recip;
		}

		dot = dx1 * p->dx2 + dy1 * p->dy2;
		cos2 = dot*dot / (magsq1 * p->magsq2);
		if(dot < 0) cos2 = -cos2;

		th = EvalFuncTab(acos2, cos2);
		p->abs_th += th;
		p->sharpness += th*th;
		if(dx1 * p->dy2 < p->dx2 * dy1)	/* sin th < 0 ? */
			th = -th;
		p->path_th += th;

		P {
		 /* PPwlInsertAfterCurrentPoint(&Pcos2, (double) p->npoints, cos2); */
		 /* PPwlInsertAfterCurrentPoint(&Pth, (double) p->npoints, th); */
		}
	}

	d = sqrt(magsq1);
	p->path_r += d;
	if(p->endtime > lasttime &&
		(v = d / (p->endtime - lasttime)) > p->maxv)
			p->maxv = v;

	C printf("sqrt(%g) ", magsq1), fflush(stdout);

	p->endx = x; p->endy = y;
	p->dx2 = dx1; p->dy2 = dy1; p->magsq2 = magsq1;

	P {
	  /* PPwlInsertAfterCurrentPoint(&Ppath_r, (double) p->npoints, p->path_r); */
	  /* PPwlInsertAfterCurrentPoint(&Ppath_th, (double) p->npoints, p->path_th); */
	  /* PPwlInsertAfterCurrentPoint(&Pabs_th, (double) p->npoints, p->abs_th); */
	  /* PPwlInsertAfterCurrentPoint(&Psharpness, (double) p->npoints, p->sharpness); */
	}

	return 1;
}

/*
  MfvNoPoint is called when no input points have been input for a while,
  and simply increases the timeout count
*/

void
MfvNoPoint(mfv, t)
register MFV mfv;
long t;
{
	mfv->ntimeouts++;
}


/*
  things to consider
	normalization of lengths by bounding box len? 
*/

int
MfvNPaths(mfv)
register MFV mfv;
{
	return mfv->npaths;
}

Vector
MfvPathCalc(mfv, path)
register MFV mfv;
int path;
{
	/* for now assume one path */
	register struct path *p;
	if(path > mfv->npaths)
		error("MfvAddPoint: path %d > npaths=%d", path, mfv->npaths);

	p = mfv->sortedpath[path];
	p->py[PF_START] = (p->starttime - mfv->starttime) * .01;
	p->py[PF_INIT_COS] = p->initial_cos;
	p->py[PF_INIT_SIN] = p->initial_sin;
	p->py[PF_BB_LEN] = hypot(p->maxx - p->minx, p->maxy - p->miny);
	p->py[PF_BB_TH] = atan2(p->maxy - p->miny, p->maxx - p->minx);
	p->py[PF_SE_LEN] = hypot(p->endx - p->startx, p->endy - p->starty);
	if(p->py[PF_SE_LEN] < mfv->distsq_threshold * mfv->distsq_threshold) {
		p->py[PF_SE_COS] = 0;
		p->py[PF_SE_SIN] = 0;
	}
	else {
		p->py[PF_SE_COS] = (p->endx - p->startx) / p->py[PF_SE_LEN];
		p->py[PF_SE_SIN] = (p->endy - p->starty) / p->py[PF_SE_LEN];
	}
	p->py[PF_LEN] = p->path_r;
	p->py[PF_TH] = p->path_th;
	p->py[PF_ATH] = p->abs_th;
	p->py[PF_SQTH] = p->sharpness;
#ifdef PF_MAXV
	p->py[PF_MAXV] = p->maxv * 10000;
#endif
	return p->py;
}

/*
 * global (Gestalt) features
 */

Vector
MfvGlobalCalc(mfv)
register MFV mfv;
{
	double dx, dy, w;

	register struct path *p0 = &mfv->path[0], *pn = &mfv->path[mfv->npaths-1];
	mfv->gy[GF_DUR] = (mfv->endtime - mfv->starttime) * .01;

	dx = mfv->maxx - mfv->minx;
	dy = mfv->maxy - mfv->miny;
	mfv->gy[GF_BB_LEN] = hypot(dx, dy);
	mfv->gy[GF_BB_TH] = atan2(dy, dx);

	if(p0 != pn) {	/* npaths > 1 */
	    w = (pn->starttime - p0->starttime) * .01;
	    lcs(mfv, pn->startx - p0->startx, pn->starty - p0->starty, w,
		&mfv->gy[GF_F_TO_F_LEN], 
		&mfv->gy[GF_F_TO_F_COS], &mfv->gy[GF_F_TO_F_SIN]);

	    lcs(mfv, pn->endx - p0->startx, pn->endy - p0->starty, w,
		&mfv->gy[GF_F_TO_L_LEN], 
		&mfv->gy[GF_F_TO_L_COS], &mfv->gy[GF_F_TO_L_SIN]);
	}
	return mfv->gy;
}

static
lcs(mfv, dx, dy, w, lenp, cosp, sinp)
register MFV mfv;
double dx, dy, w, *lenp, *cosp, *sinp;
{
	*lenp = hypot(dx, dy);
	if(*lenp * *lenp < mfv->distsq_threshold) {
		*cosp = *sinp = 0;
	}
	else {
		*cosp = dx / *lenp;
		*sinp = dy / *lenp;
	}
}

/*
 * MfvQuickCalc - return a vector of features that can be calculated quickly.
		 This is basically a subset of the set of features returned
		 by MfvCalc, and it is used to see if we have enough of a
		 gesture to classify it (correctly)
 */


/* quick features */

#define	QF_DUR		0	/* (time) duration of path */
#define	QF_LEN		1	/* arc length of path */
#define	QF_ATH		2	/* sum of abs vals of angles traversed */
#define	QF_SQTH		3	/* sum of squares of angles traversed */
#define	QF_NPOINTS	4	/* number of points so far */

Vector
MfvQuickCalc(mfv)
register MFV mfv;
{
	register struct path *p = &mfv->path[0];
	mfv->qy[QF_DUR] = (p->endtime - p->starttime) * .01;
	mfv->qy[QF_LEN] = p->path_r;
	mfv->qy[QF_ATH] = p->abs_th;
	mfv->qy[QF_SQTH] = p->sharpness;
	mfv->qy[QF_NPOINTS] = p->npoints;
	return mfv->qy;
}


void
MfvDump(mfv)
register MFV mfv;
{

}

/*
 given m = cos^2(t) * sign(cos(t)) return t
 t should be between 0 and pi 
 m will be between -1 and 1
 */

double
invcos2(m)
double m;
{
	if(m < 0)
		return acos(-sqrt(-m));
	else
		return acos(sqrt(m));
}

#define 	TIME_THRESH	100	/* milliseconds */
#define		XY_THRESH	100	/* in pixels */

#define		BIG_ENOUGH(x,t)	((x) >= (t) || (x) <= (-t))

static int
pathcmp(p1, p2)
register struct path **p1, **p2;
{
	register int dx, dy;
	
	dx = (*p1)->starttime - (*p2)->starttime;
	C printf(" %d%d", (*p1)->index, (*p2)->index);
	if(BIG_ENOUGH(dx, TIME_THRESH)) {
		C printf("T ");
		return dx;
	}
	dx = (*p1)->startx - (*p2)->startx;
	if(BIG_ENOUGH(dx, XY_THRESH)) {
		C printf("X ");
		return dx;
	}

	dy = (*p1)->starty - (*p2)->starty;
	if(BIG_ENOUGH(dy, XY_THRESH)) {
		C printf("Y ");
		return dy;
	}
	if(abs(dy) > abs(dx)) {
		C printf("y ");
		return dy;
	} else {
		C printf("x ");
		return dx;
	}
}

void
MfvSortPaths(mfv, sorting)
register MFV mfv;
int sorting[];
{
	register int i;

	if(mfv->npaths > 1) {
		qsort(mfv->sortedpath, mfv->npaths,
			sizeof(mfv->sortedpath[0]), pathcmp);
	}
	if(sorting) {
		for(i = 0; i < mfv->npaths; i++)
			sorting[i] = mfv->sortedpath[i]->index;
	}
}
