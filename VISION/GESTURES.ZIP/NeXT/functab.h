/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/


typedef struct functab {
	double	*points;
	char *name;
	int	n;
	double	scale, offset;
} *FuncTab;

FuncTab ReadFuncTab();	/* FILE *f; */
FuncTab GenFuncTab();	/* char *name; int npoints; double minx, maxx,(*f)();*/
double EvalFuncTab(); 	/* FuncTab ft; double x; */
