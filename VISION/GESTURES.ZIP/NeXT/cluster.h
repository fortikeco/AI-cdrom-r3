/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
typedef struct dendrogram *Dendrogram;


struct dendrogram {
	short	unit;		/* unit number (matrix index) if this is
				   a leaf node, otherwise it's the
				   minimum unit number in this cluster */
	short	rank;		/* number indicating when this node was
				   created.  The larger the number, the
				   more general, and thus closer to the
				   root this node is. */
	double	threshold;	/* distance threshold below which this
				   splits into two groups */
	Dendrogram left, right;	/* Sub-clusters, or NULL if leaf node */
};

#define	MAXUNITS	150


Dendrogram   Cluster();   /* Matrix dsm */

double	     Group();    /* Dendrogram d, int ngroups, short grouping[],
				returns min threshold */

extern DumpDendGraph();
extern DendPrintUnits();
extern DendNUnits();

extern int clusterdebug;

