/***********************************************************************

Copyright (C) 1991 Dean Rubine

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See ../COPYING for
the full agreement.

**********************************************************************/
#include "matrix.h"
#include "util.h"
#include "bitvector.h"
#include "sc.h"
#include "mc.h"
#include "mcf.h"
#include "stdio.h"
#include "cluster.h"

extern mClusterClass();
extern ExamplesUsed();
int ExampleUsedHelp();
extern AnalyzeClusterSizes();
extern goodcluster();


int groupdebug = 0;

mCluster(mc)
register mClassifier mc;
{
	register int i;

	for(i = 0; i < mc->nmclasses; i++)
		mClusterClass(mc->mclassdope[i]);
}



double
distance2(v1, v2, var)
register Vector v1, v2, var;
{
	double t, d2 = 0;
	register i;

	for(i = 0; i < NROWS(var); i++) {
		t = v1[i] - v2[i];
		if(var[i] >= 1.0e-10)
			d2 += (t * t)/var[i];
	}
	return d2;
}


mClusterClass(mcd)
register mClassDope mcd;
{
	register int e, p, i, j, n;
	int nf = NROWS(mcd->example[0].pf[0]);
	Vector avg = NewVector(nf), var = NewVector(nf);
	Matrix dsm;
	double t;
	double distance2();
	Dendrogram d;

	printf("\n------Clustering class %s, %d examples, %d paths------\n",
		mcd->classname, mcd->nexamples, mcd->npaths);

	if(mcd->npaths == 1)
		printf("Not bothering since only one path\n");

	ZeroVector(avg);
	for(e = 0; e < mcd->nexamples; e++)
	    for(p = 0; p < mcd->npaths; p++)
	        for(i = 0; i < nf; i++)
			avg[i] += mcd->example[e].pf[p][i];
	n = mcd->nexamples * mcd->npaths;
	for(i = 0; i < nf; i++)
		avg[i] /= n;

	ZeroVector(var);
	for(e = 0; e < mcd->nexamples; e++)
	    for(p = 0; p < mcd->npaths; p++)
	        for(i = 0; i < nf; i++) {
			t = (mcd->example[e].pf[p][i] - avg[i]);
			var[i] += t*t;
		}
	for(i = 0; i < nf; i++)
		var[i] /= (n-1);


/*
	PrintVector(avg, "average of path features");
	PrintVector(var, "variance of path features");
*/

	dsm = NewMatrix(n, n);
	for(i = 0; i < n; i++)
		for(j = 0; j < i; j++)
			dsm[i][j] = distance2(
				mcd->example[i/mcd->npaths].pf[i%mcd->npaths],
				mcd->example[j/mcd->npaths].pf[j%mcd->npaths],
				var);

	d = Cluster(dsm);
	FreeVector(avg);
	FreeVector(var);
	FreeMatrix(dsm);
	ExamplesUsed(d, mcd);
#ifndef yomama
}
#else



#ifdef whocares
   {
	int ngroups;
	short grouping[MAXCLASSEXAMPLES*MAXPATHS];
	int count, total;
#define MAXCOUNT 6 
	int counthist[ 7 /*MAXGROUPS*/ ][ MAXCOUNT ], gc[7], gsize[7];

	for(ngroups = 2; ngroups <= 2*mcd->npaths; ngroups++) {

		for(i = 0; i < ngroups; i++) {
		    gsize[i] = 0;
		    for(j = 0; j < MAXCOUNT; j++)
			counthist[i][j] = 0;
		}

		/* PrintGrouping(d, ngroups);	/* debug */
		/* PrintGroupCounts(d, ngroups);	/* debug */
		printf("%d groups  ", ngroups);
		printf(" ");

		Group(d, ngroups, grouping);
		for(e = 0; e < mcd->nexamples; e++) {
		    count = 0;
		    for(i = 0; i < ngroups; i++)
			gc[i] = 0;
		    for(p = 0; p < mcd->npaths; p++) {
			i = e*mcd->npaths + p;
			gc[ grouping[i] ]++;
			gsize[ grouping[i] ]++;
		        for(j = i+1; j < (e+1)*mcd->npaths; j++) {
			/*
				printf("[%d]%d==[%d]%d?%d  ", i, grouping[i],
					j, grouping[j],
						grouping[i] == grouping[j]);
			*/
				if(grouping[i] == grouping[j])
					count++;
			}
		    }
		    printf("%d  ", count);
		    for(i = 0; i < ngroups; i++)
			counthist[i][ gc[i] ]++;
		}
		printf("\n");
		printf(" counts:");
	        for(i = 0; i < ngroups; i++) {
		    printf("G%d(%d): ", i, gsize[i]);
		    if(gsize[i] <= mcd->nexamples &&
		       gsize[i] >= mcd->nexamples - 2) {
			if(counthist[i][1] == gsize[i])
				printf("*C*");
			if(counthist[i][1] == gsize[i]-1)
				printf("*A*");
		    }
		    for(j = 1; j < 6; j++)
			if(counthist[i][j] != 0)
				printf("%d %d's ", counthist[i][j], j);
		    
		}
		printf("\n");

	}

    }
#endif


}
#undef BV_TYPE_NAME
#undef BITS_PER_VECTOR
#define BV_TYPE_NAME Bv128
#define BITS_PER_VECTOR	128
#include "bitvector.h"

/*
 * given a dendrogram, return a bit vector if the examples used in it
 */

ExamplesUsed(d, mcd)
mClassDope mcd;
register Dendrogram d;
{
	register int i;
	Dendrogram clusters[MAXCLASSEXAMPLES*MAXPATHS];
	int nclusters;
	Bv128 bv;

	nclusters = 0;
	ExampleUsedHelp(d, mcd->nexamples, mcd->npaths, bv,
				clusters, &nclusters);
	printf("%d clusters found ", nclusters);
	AnalyzeClusterSizes(mcd, nclusters, clusters);
}

int
ExampleUsedHelp(d, nexamples, npaths, bv, clusters, nclustersp)
register Dendrogram d;
int nexamples, npaths, *nclustersp;
Bv128 bv;
Dendrogram clusters[];
{
	int e;
	Bv128 bvleft, bvright;
	int lres, rres;

	if(d->left) {
		lres = ExampleUsedHelp(d->left, nexamples, npaths,
			bvleft, clusters, nclustersp);

		rres = ExampleUsedHelp(d->right, nexamples, npaths,
			bvright, clusters, nclustersp);


		/* invariant: ExampleUsedHelp will return 1 iff d
		   has not been entered in cluster list yet, 0 otherwise */

		if(lres && rres) {	/* both subtree have no dups, see
						if they can be combined */
			AND(bv, bvright, bvleft);
			if(NO_BITS_SET(bv)) {
				OR(bv, bvright, bvleft);
				return 1;
			}
			/* can't be combined, make clusters */
			clusters[ (*nclustersp)++ ] = d->left;
			clusters[ (*nclustersp)++ ] = d->right;
			return 0;
		}
		if(lres && !rres) {   /* left side OK, right side has dups */
			clusters[ (*nclustersp)++ ] = d->left;
			return 0;
		}
		if(!lres && rres) {   /* right side OK, left side has dups */
			clusters[ (*nclustersp)++ ] = d->right;
			return 0;
		}
		if(!lres && !rres) {   /* both sides alread have dups */
			return 0;
		}
	}
	e = d->unit / npaths;
	CLEAR_BIT_VECTOR(bv);
	BIT_SET(e, bv);
	return 1;
}

#define		BIG_ENOUGH	0.75

AnalyzeClusterSizes(mcd, nclusters, clusters)
register mClassDope mcd;
int nclusters;
Dendrogram clusters[];
{
	int threshold = mcd->nexamples * BIG_ENOUGH;
	register int i, count;
	int clustersizes[150];
	short units[150];
	int ndistinct;
	int distinctgroup[MAXCLASSEXAMPLES*MAXPATHS];
	register int j;

	for(i = 0; i < nclusters; i++)
		clustersizes[i] =  DendNUnits(clusters[i]);
	for(i = 0; i < nclusters; i++)
		printf("%d ", clustersizes[i]);

	/* count the number of clusters >= threshold */
	for(count = 0, i = 0; i < nclusters; i++)
		if(clustersizes[i] >= threshold)
			count++;
	switch(mcd->npaths) {
	case 2:
		switch(count) {
		case 0: printf("AA"); ndistinct = 1; break;
		case 1: printf("probably AA"); ndistinct = 1; break;
		case 2: printf("AB"); ndistinct = 2; break;
		}
		break;

	case 3:
		switch(count) {
		case 0: printf("AAA"); ndistinct = 1; break;
		case 1: printf("AAB"); ndistinct = 2; break;
		case 2: printf("probably ABC"); ndistinct = 3; break;
		case 3: printf("ABC"); ndistinct = 3; break;
		}
		break;

	default:
		error("AnalyzeClusterSizes, can't handle %d paths", mcd->npaths);
	}

	
	if(ndistinct == 1) {
	    for(j = 0; j < mcd->nexamples * mcd->npaths; j++)
		distinctgroup[j] = 0;
	}
	else {
	    for(j = 0; j < mcd->nexamples * mcd->npaths; j++)
		distinctgroup[j] = -1;
	    for(count = 0, i = 0; i < nclusters; i++) {
		if(clustersizes[i] >= threshold) {
			if(clustersizes[i] != DendUnits(clusters[i], units))
				error("DendUnits error");
			for(j = 0; j < clustersizes[i]; j++)
				distinctgroup[ units[j] ] = count;
			count++;
		}
	    }
	    {
		int xcount;
		for(i = 0; i < mcd->nexamples*mcd->npaths; i += mcd->npaths) {
			xcount = 0;
	    		for(j = 0; j < mcd->npaths; j++)
				if(distinctgroup[i+j] != -1)
					xcount++;
			if(xcount == ndistinct - 1)
	    			for(j = 0; j < mcd->npaths; j++)
				    if(distinctgroup[i+j] == -1)
				    	distinctgroup[i+j] = ndistinct-1;
		}
	    }
	}
	printf("\n%d distinct groups: ", ndistinct);
	for(j = 0; j < mcd->nexamples * mcd->npaths; j++)
		printf("%s%d", j%mcd->npaths==0 ? "/" : " ",
				distinctgroup[j]);
	printf("\n");

	count = 0;
	for(j = 0; j < mcd->nexamples * mcd->npaths; j++)
		if(distinctgroup[j] == -1)
			count++;

	/* if(count > 0) */ { 
	    char sclassname[100];
	    sClassifier s = sNewClassifier();
	    sClassDope sdg[10];
	    int sdginv[10];
	    sClassDope sd;
	    int e, g;

	    printf("# unknowns: %d\n", count);
	    if(ndistinct == 1)
		return;

	    for(j = 0; j < mcd->nexamples * mcd->npaths; j++) {
		if( distinctgroup[j] != -1 ) {
			sprintf(sclassname, "cl%d", distinctgroup[j]);
			sAddExample(s, sclassname,
				mcd->example[j/mcd->npaths].pf[j%mcd->npaths]);
		}
	    }

	    sBlur(s);
	    sDoneAdding(s);

	    for(i = 0; i < ndistinct; i++) {
		sprintf(sclassname, "cl%d", distinctgroup[j]);
	    	sdg[i] = sClassNameLookup(s, sclassname);
	    }
	    for(i = 0; i < 10; i++) sdginv[i] = -1;
	    for(i = 0; i < ndistinct; i++)
		if(sdg[i]) sdginv[ sdg[i]->number ] = i;

	    for(j = 0; j < mcd->nexamples * mcd->npaths; j++) {
		sd = sClassify(s, mcd->example[j/mcd->npaths].
		       pf[j%mcd->npaths]);
		       
		if( distinctgroup[j] != -1 ) {
		    if(sd != sdg[ distinctgroup[j] ]) {
				printf("Cluster != classifier (# %d)\n", j);
		    }
		}
		else {  /* distinctgroup[j] == -1 */
		    g = sdginv[ sd->number ];
		    distinctgroup[i] = g;
		}
	   }

	   printf("         regroups: ");
	   for(j = 0; j < mcd->nexamples * mcd->npaths; j++)
		printf("%s%d", j%mcd->npaths==0 ? "/" : " ",
				distinctgroup[j]);


	}
/*
		    if(g == -1)
			printf("-1 group - shouldn't happen!\n");
		    e = (j/mcd->npaths)*mcd->npaths;
		    for(i = e; i < e + mcd->npaths; i++)
			if(distinctgroup[i] == g)
				xx;
*/
}
#endif

typedef struct {
	char	ex[MAXCLASSEXAMPLES];
	int	count;
} Dope;



ExamplesUsed(d, mcd)
mClassDope mcd;
register Dendrogram d;
{
	register int i;
	Dendrogram clusters[MAXCLASSEXAMPLES*MAXPATHS];
	int nclusters;
	Dope dope;

	nclusters = 0;
	ExampleUsedHelp(d, mcd->nexamples, mcd->npaths, &dope,
				clusters, &nclusters);
	printf("%d clusters found ", nclusters);
	if(groupdebug) {
		printf("\n-----begin d----\n");
		DumpDendGraph(d);
		printf("-----end d----\n");
	}
		
	AnalyzeClusterSizes(mcd, nclusters, clusters);
	printf("\n");
}


int
ExampleUsedHelp(d, nexamples, npaths, dope, clusters, nclustersp)
register Dendrogram d;
int nexamples, npaths, *nclustersp;
register Dope *dope;
Dendrogram clusters[];
{
	register int e;
	Dope dleft, dright;
	int lres, rres;

	if(d->left) {
		lres = ExampleUsedHelp(d->left, nexamples, npaths,
			&dleft, clusters, nclustersp);

		rres = ExampleUsedHelp(d->right, nexamples, npaths,
			&dright, clusters, nclustersp);

		if(lres && rres) {
		    	for(e = 0; e < nexamples; e++)
				dope->ex[e] = dleft.ex[e] + dright.ex[e];
			dope->count = dleft.count + dright.count;
			if(goodcluster(d, dope, nexamples, npaths)) {
				clusters[ (*nclustersp)++ ] = d;
				return 0;
			}
			return 1;
		}
		else if(lres && !rres) {
			/*
			clusters[ (*nclustersp)++ ] = d->left;
			return 0;
			*/

			*dope = dleft;
			return 1;

		}
		else if(!lres && rres) {
			/*
			clusters[ (*nclustersp)++ ] = d->right;
			return 0;
			*/

			*dope = dright;
			return 1;
		}
		else
			return 0;
	}

	for(e = 0; e < nexamples; e++)
		dope->ex[e] = 0;
	e = d->unit / npaths;
	dope->ex[e] = 1;
	dope->count = 1;
	return 1;
}

goodcluster(d, dope, nexamples, npaths)
Dendrogram d;
register Dope *dope;
int nexamples;
int npaths;
{
	register int e;
	int nperexample = (dope->count+2)/nexamples;
	int badcount;

	printf("gc: ");
	for(e = 0; e < nexamples; e++) printf("%d ", dope->ex[e]);
	printf("\n");

/*
	if( dope->count%nexamples >= 2)
		return 0;
*/
	if(nperexample == 0)
		return 0;

	for(badcount = 0, e = 0; e < nexamples; e++)
		if(dope->ex[e] != nperexample)
			badcount++;
	if(badcount >= 2)
		return 0;
	printf("good cluster: "); DendPrintUnits(d); printf("\n");
	return 1;
}

AnalyzeClusterSizes(mcd, nclusters, clusters)
register mClassDope mcd;
int nclusters;
Dendrogram clusters[];
{
	register int i, count;
	int clustersizes[150];
	short units[150];
	int ndistinct;
	int distinctgroup[MAXCLASSEXAMPLES*MAXPATHS];
	register int j;

	for(i = 0; i < nclusters; i++)
		clustersizes[i] =  DendNUnits(clusters[i]);
	for(i = 0; i < nclusters; i++)
		printf("%d ", clustersizes[i]);
	printf("\n");

	for(i = 0; i < nclusters; i++) {
		printf("  %d: ", i);
		DendPrintUnits(clusters[i]);
		printf("\n");
	}
}
