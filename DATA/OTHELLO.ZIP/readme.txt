1. Title of Domain Theory:
       Domain theory for Othello in Prolog.

       Used in research on generating features for inductive learning 
       systems.

2. Sources:
       Tom Fawcett (fawcett@cs.umass.edu)
       COINS Deptartment, LGRC
       University of Massachusetts
       Amherst, MA  10373
       February, 1991.

3. Past Usage:
	"A Hybrid Method for Feature Generation"
	T. Fawcett and P. Utgoff
	Eighth International Workshop on Machine learning
	Northwestern University, Evanston Illinois.  1991.
	pp. 137-141

	"Automatic Feature Generation for Problem Solving Systems"
	T. Fawcett and P. Utgoff.  
	Ninth International Conference on Machine Learning
	Aberdeen, Scotland. 1992.  pp 144-153.

4. Relevant Information Paragraph:
       The Code ("othello.theory") is well documented.

5. Type of Domain: Relational

