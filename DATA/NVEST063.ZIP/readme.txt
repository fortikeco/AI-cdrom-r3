DATA DISK 3
NEUROVE$T JOURNAL (TM)
JUNE 1993

********************* What is NEUROVE$T JOURNAL? ************************

Welcome to the Data Disk #3 provided by NEUROVE$T JOURNAL, the world's premier
journal for investing with neural networks and emerging technologies. We 
provide an independent forum for the exploration and application of the next
generation of tools for investing and trading in the markets.

Our readers include investors and traders, developers and researchers, money
managers and investment advisors. Features include: how-to articles, case
studies, tutorials, product and books reviews, news, and much more.

If you would like to know more about NEUROVE$T JOURNAL, you can send for 
information by writing to:
	
			NEUROVE$T JOURNAL
			P.O. Box 764
			Haymarket, VA 22069
			USA

Please let us know if you might be interested in either subscribing to or 
writing for the Journal, or both. If you might be interested in writing for
the Journal, you should first read through the AUTHORS file.

********************** Contents of Data Disks ****************************

There are three Data Disks distributed by NEUROVE$T JOURNAL. All disks 
include daily data on the stock market as described below in "Data Disk 
Description." Each disk includes:

	1. One .TXT (tab-delimited) file for each year of market data
	   (For example: 1992.TXT).
	2. One .CSV (comma-delimited) file for each year of market data
	   (For example: 1992.CSV).
	3. README: this readme file.
	4. AUTHORS: a file that contains a call for papers, articles and 
	   material for the Journal, including brief general guidelines.

DATA DISK #1 includes over 20 years of up-to-date daily market data as
described below. It is distributed to subscribers who complete a questionnaire
that is used to help us provide readers with the most appropriate information.

DATA DISK #2 includes over 10 years of up-to-date daily market data as
described below. It is distributed to all new subscribers.

DATA DISK #3 includes over 4 years of daily market data that will be 
periodically updated and made available for free distribution (Distribution
must follow the rules described below in DISTRIBUTION).

The exploration and application of new technologies to investing and 
trading in the markets often requires the availability of much data. 
Since the Journal promotes such activities in this area, such is the reason 
for making this data available. Also, since market cycles typically last 
approximately 4 years, we have selected that period as the minimum length 
of data necessary for serious investors, developers and researchers to perform 
their work.

DISTRIBUTION: Distribution of Data Disk #3 is encouraged. However, such
distribution must include all files mentioned above (.TXT, .CSV, README, and
AUTHORS). Compressed files must use the name NVE$T@@@.***, where "@@@"
refers to the date (month # and last # of the year) of the file and 
where "***" refers to the proper suffix for the compression method used. 
For example: "NVE$T063.ZIP" would be used for a file date June 1993 and 
compressed using PKZIP.

*********************** Data Disk Description *****************************

1. Make a copy of this disk. Store the original in a safe place.
2. Each disk should contain two files for each year of data. These are
   indicated by the .TXT or .CSV suffixes.
   a. Files labeled .TXT are tab-delimited ASCII files.
   b. Files labeled .CSV are comma-delimited, or comma-separated-value files.
3. Most of the popular spreadsheet software programs can read comma-
   delimited or .CSV files.
4. Most neural network, and other data-driven, software programs can read
   the tab-delimited or .TXT files.   
5. Documentation that comes with your software program should tell you what
   data formats are compatible with your program. In the unlikely case that 
   your program cannot directly read either tab-delimited or comma-delimited 
   data files, you will need to utilize a software conversion tool to convert 
   the data to the desired format.

Data on the files are sorted into the following columns:

  DATE   DJIA   DJTA   NYVD(000)   DJBA   DJUA   SP500H   SP500L   SP500C 

DATE is the daily date for those days that the U.S. markets were open.
DJIA is the daily close for the Dow Jones Industrial Average.
DJTA is the daily close for the Dow Jones Transportation Average.
NYVD(000) is the daily total volume for the New York Stock Exchange.
DJBA is the daily close for the Dow Jones 20 Bond Average.
DJUA is the daily close for the Dow Jones Utility Average.
SP500H is the daily high for the S&P 500 index.
SP500L is the daily low for the S&P 500 index.
SP500C is the daily close for the S&P 500 index.

****************************** Use of Data *********************************

Data enclosed in the Data Disk files from NEUROVE$T JOURNAL have been checked
for accuracy. However, we do not guarantee the correctness of the data, and 
do not assume any responsibility resulting from their use.

********************************** End *************************************