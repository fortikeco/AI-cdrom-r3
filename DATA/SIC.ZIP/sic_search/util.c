/*
 * This code file was created for the TIPSTER project.
 *
 * code file: util
 * created:
 * purpose:
 * functions:
 */


void toLower(s1)
     
     char * s1;
     
{
    char * aux = s1;
    
    
    while (*aux) {
      *aux = isupper(*aux) ? tolower(*aux) : *aux;
      *aux++;
    }
}


