/*
 * This header file was created for the TIPSTER project.
 *
 * header file: search
 * created:
 */

#include <stdio.h>
#include "sic_search.h"

/* global result */
Score_Code sic_result[MAXCODENUM]; /* this is defined to be
								      MAXCODENUM elements long */

/*
 * External Routines
 */
extern	void	add_code_counts();
extern	void	clear_code_counts();
extern	int		get_code_struct();
extern	void	init_sic_search();
