/*
 * This code file was created for testing purposes.
 *  by: Heather D. Pfeiffer
 *
 * code file:  test
 * created:    12/3/92
 * purpose:    This is just a test program to see if the new sic_lookup
 *             function is working correctly when input is entered on
 *             the command line.
 */

#include <stdio.h>
#include <strings.h>
#include "sic_search.h"

void
main( argc, argv )
	int		argc;
	char	*argv[];
{
	char	terms[80];
	int		returncode, i;

	if (argc > 1) {
		for (i=1; i < argc; i++) {
			if (i > 1)
				strcat( terms, argv[i] );
			else
				strcpy(terms, argv[i]);
			if (i < (argc - 1))
				strcat( terms, " ");
		}
	}else
		strcpy( terms, "mfg" );
	returncode = sic_lookup( terms );

	printf("For the terms\n - `%s',\n the following was returned:\n",
		   terms );
	for(i=0; i < returncode; i++) {
		printf("\tsic_result[%d].code - `%hd' and ",
			   i, sic_result[i].code);
		printf("sic_result[%d].score - `%d' \n",
			   i, sic_result[i].score );
		fflush( stdout );
	}
	
}/*main*/
