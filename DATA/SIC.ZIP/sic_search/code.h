/*
 * This header file was created for the TIPSTER project.
 *
 * header file: code_count
 * created:
 * purpose:
 * externs:
 */

#include "sic_search.h"

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include "stemmer.h"
#include "map_file.h"
#include "bm.h"

/* default file names */
#define DEF_INDEX_FILE  "sicindex"
#define DEF_CODE_BASE 	"code.base"
#define DEF_CODE_INDEX 	"code.index"
#define DEF_SEAR_DIR	"/usr/tipster/data/sic_search/"

static struct line_offset_chain{
    int line_start;
    int line_end;
    int dups;
    struct line_offset_chain * next;
    };

/* Global data structures */


static char  	*sic_index=NULL, *code_base = NULL, *code_index = NULL;
static int 		sic_size,        base_size,         index_size;

static struct  line_offset_chain *line_offset_array[MAXCODENUM];
static int code_counts[MAXCODENUM];
static int count_flag[MAXCODENUM];
static int	max_dups[MAXCODENUM];
static int max_count;

/*
 * External Routines
 */
extern	void	add_code_counts();
extern	int		get_code_struct();
extern	char	*get_code_list();
extern	char	*get_line_list();
extern	void	clear_code_counts();
extern	void	init_sic_search();

/* Local routines */
static 	void	clear_count_flags();
static	char	*get_codes();
static	void	add_line_offset();
static	char	*get_line();
static	void	swap_elm();
static	void	swap_code_counts();
