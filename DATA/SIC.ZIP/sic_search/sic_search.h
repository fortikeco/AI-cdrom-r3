/*
 * This header file was created for the TIPSTER project.
 *  for: Jim Cowie
 *
 * header file: sic_search
 * created:		12/4/92
 * purpose:		Defines how to use the `sic_lookup' function from
 *              the library `ssear'.
 * externs:
 *   int sic_lookup( terms )
 *
 *   input:
 *          terms: This is the words that the user is looking
 *                 for codes that use these terms.
 *
 *   output:
 *          sic_lookup(): The return of the function is a return code
 *                        with the following meanings:
 *                          0              : No scores where given to any
 *                                           of the codes analysised.
 *                          1 - MAXCODENUM : Number of codes that
 *                                           have scores over 0.
 *
 *   global return:
 *          sic_results: An array of a structure that returns the
 *                       codes that use these terms and their scores.
 *                       Note: results are returned with highest
 *                             scores first continuing to a score
 *                             of 0 (initialization value).
 *
 *
 * environment:
 *   There are four environment variables used with this function;
 *    all have built-in defaults and are primarily available
 *    for portability:
 *
 *   SIC_INDEX_FILE:	sic index file.
 *   SIC_CODE_BASE: 	sic code base file.
 *   SIC_CODE_INDEX:	sic code index file.
 *   SIC_SEAR_DIR:		directory where the sic data files can
 *                      be found - default defined by TIPSTER
 *                      define in Makefile with `make install'.
 *
 *   NOTE: all of these variables can be defined into the environment
 *         by sourcing the file `.ssear_env' in the /usr/tipster/include
 *         directory.
 */

#define MAXCODENUM		100		/* Maximum number of codes available */
#define MAXCOUNTWRIT	32		/* Maximum number of digits
								   available for the score of a code */
#define	WORDSIZE		80      /* Maximum word size handled in code */


typedef struct score_code {
	   int 	 score;		/* score value for code - 0 means no reference */
	   short code;		/* code number - never excedes MAXCODENUM      */
} Score_Code;

/*
 * Global array that results are returned in.
 *   NOTE: this array is always reinitialized on calling sic_lookup.
 */
extern Score_Code sic_result[]; /* this is defined to be
								   MAXCODENUM elements long */


extern int	sic_lookup(/* terms */ );

