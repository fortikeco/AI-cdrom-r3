/*
 * This header file was created for the TIPSTER project.
 *
 * header file: util
 * created:
 * purpose:
 * externs:
 */

#ifndef _util_h
#define _util_h

extern void toLower(/* char	*str */);

#endif /* _util_h */
