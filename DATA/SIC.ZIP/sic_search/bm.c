#include <stdio.h>

/* boyer moore searching in memory */
#define MAXCHAR 128

#define min(a,b) ((a) < (b) ? a : b)
#define max(a,b) ((a) > (b) ? a : b)


struct PattDesc {
  char *Start, *Pattern;
  int PatLen;
  unsigned short int *Skip1, *Skip2;
};

extern char * malloc();

MakeSkip(Pattern,Skip1,Skip2,PatLen)
char Pattern[];
unsigned short int Skip1[], Skip2[];
int PatLen;
/* generate the skip tables for Boyer-Moore string search algorithm.
* Skip1 is the skip depending on the character which failed to match
* the pattern, and Skip2 is the skip depending on how far we got into
* the pattern. Pattern is the search pattern and PatLen is strlen(Pattern) */
{
	int *BackTrack; /* backtracking table for t when building skip2 */
	int c; /* general purpose constant */
	int j,k,t,tp; /* indices into Skip's and BackTrack */

	if (!(BackTrack = (int *) malloc(PatLen * (sizeof (int))))){
		fprintf(stderr,"bm: can't allocate space\n");
		exit(2);
	} /* if */
	for (c=0; c<=MAXCHAR; ++c)
		Skip1[c] = PatLen;
	for (k=0;k<PatLen;k++) {
		Skip1[Pattern[k]] = PatLen - k - 1;
		Skip2[k] = 2 * PatLen - k - 1;
	} /* for */
	for (j=PatLen - 1,t=PatLen;j >= 0; --j,--t) {
		BackTrack[j] = t;
		while (t<PatLen && Pattern[j] != Pattern[t]) {
			Skip2[t] = min(Skip2[t], PatLen - j - 1);
			t = BackTrack[t];
		} /* while */
	} /* for */
	for (k=0;k<=t;++k)
		Skip2[k] = min(Skip2[k],PatLen+t-k);
	tp=BackTrack[t];
	while(tp<PatLen) {
		while(t<PatLen) {
			Skip2[t] = min(Skip2[t],tp-t+PatLen);
			++t;
		} /* while */
		tp = BackTrack[tp];
	} /* while */
	cfree(BackTrack);
} /* MakeSkip */


/* makes a pattern descriptor */
struct PattDesc *MakeDesc(Pattern)
char *Pattern;
{
    struct PattDesc *Desc;
    Desc = (struct PattDesc *) malloc(sizeof(struct PattDesc));
    if (!(Desc->Skip1 = (unsigned short int *)
	  malloc( sizeof(int) * (MAXCHAR + 1)))){
	fprintf(stderr,"bm: can't allocate space\n");
	exit(2);
    }				/* if */
    if (!(Desc->Skip2 = (unsigned short int *)
	  malloc(sizeof(int) * strlen(Pattern)))){
	fprintf(stderr,"bm: can't allocate space\n");
	exit(2);
    }				/* if */
    Desc->Pattern=Pattern;
    Desc->PatLen = strlen(Desc->Pattern);
    MakeSkip(Desc->Pattern,Desc->Skip1,
	     Desc->Skip2,Desc->PatLen);
    return(Desc);
}

int Search(Pattern, PatLen, EndBuff, Skip1, Skip2, Desc)
char Pattern[];
int PatLen;
char *EndBuff;
unsigned short int Skip1[], Skip2[];
struct PattDesc *Desc;
{
    register char *k,		/* indexes text */
    *j;				/* indexes Pattern */
    register int Skip;		/* skip distance */
    char *PatEnd,
    *BuffEnd;			/* pointers to last char in Pattern and Buffer */
    BuffEnd = EndBuff;
    PatEnd = Pattern + PatLen - 1;

    k = Desc->Start;
    Skip = PatLen-1;
    while ( Skip <= (BuffEnd - k) ) {
	j = PatEnd;
	k = k + Skip;
	while (*j == *k) {
	    if (j == Pattern) {
		/* found it. Start next search
		 * just after the pattern */
		Desc -> Start = k + Desc->PatLen;
		return(1);
	    }			/* if */
	    --j; --k;
	}			/* while */
	Skip = max(Skip1[*(unsigned char *)k],Skip2[j-Pattern]);
    }				/* while */
    Desc->Start = k+Skip-(PatLen-1);
    return(0);
}				/* Search */

char *srch(pattern, buffer, size)
char *pattern, *buffer;
int size;
{
    struct PattDesc *d, *MakeDesc();
    d = MakeDesc(pattern);

    d->Start = buffer;
    if (Search(pattern, strlen(pattern),
	       buffer+size, d->Skip1, d->Skip2, d)) {
	return d->Start;
    }
    else return NULL;
}
