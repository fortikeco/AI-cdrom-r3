#ifndef _bm_h
#define _bm_h

char *srch(/* char *pattern, char *buffer, int size */);

#endif /* _bm_h */
