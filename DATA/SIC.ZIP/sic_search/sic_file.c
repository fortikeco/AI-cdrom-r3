/*
 * Get SIC codes for a file of terms
 *  Jim Cowie
 *
 * created:    1/2/93
 */

#include <stdio.h>
#include <strings.h>
#include "sic_search.h"

static void	build_line();

void
main( argc, argv )
	int		argc;
	char	*argv[];
{
	char	terms[2000];
	int     numchars;
	int		returncode, i;
	FILE    *infile;
	
	if (argc > 1) {
             infile = fopen(argv[1],"r");
             if (infile == NULL){
                   printf("Unable to open %s\n",argv[1]);
                   exit(-1);
		}
	}else{
		printf("No file to open\n");
		exit(-1);
	}
	build_line(terms,infile);
	fclose(infile);
        
	returncode = sic_lookup( terms );

	printf("For the terms\n - `%s',\n the following was returned:\n",
		   terms );
	for(i=0; i < returncode; i++) {
		printf("\tsic_result[%d].code - `%hd' and ",
			   i, sic_result[i].code);
		printf("sic_result[%d].score - `%d' \n",
			   i, sic_result[i].score );
		fflush( stdout );
	}
	
}/*main*/

static void
build_line(terms,infile)
    char * terms;
    FILE * infile;
{
    char * result;
	char temp[WORDSIZE];
	
    result = fgets(temp, WORDSIZE, infile);
    while(result != NULL){
       temp[strlen(temp)-1] = ' ';
	   temp[strlen(temp)] = '\0';
	   if ((strcmp(temp,"")) && (strcmp(temp," ")))
		   strcat(terms,temp);
       result = fgets(temp, WORDSIZE, infile);
   }
    terms[strlen(terms)-1] = '\0';
}
