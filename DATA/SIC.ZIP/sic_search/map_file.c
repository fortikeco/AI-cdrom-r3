#include <sys/types.h>
#include <sys/mman.h>
#include <stdio.h>
#include "map_file.h"

int file_size(filename)
char *filename;
{
    FILE *f;
    int r;

    f = fopen(filename, "r");

    if (!f) {
	fprintf(stderr, "map_file: cannot open %s\n", filename);
	return NULL;
    }

    fseek(f, 0, 2);
    r = ftell(f);
    fclose(f);
    return r;
}

/* code which when given a file name will return a pointer to memory
   which contains a read-only copy of the contents of the file.  this
   is done with virtual memory tricks, not by reading the file */

char *map_file(filename, len, off)
char *filename;
int len, off;
{
    FILE *f;
    char *r;

    f = fopen(filename, "r");

    if (!f) {
	fprintf(stderr, "map_file: cannot open %s\n", filename);
	return NULL;
    }

    if (len == 0) {
	len = file_size(filename);
    }

    r = mmap(NULL, len, PROT_READ, MAP_SHARED, fileno(f), off);
    if (!r) {
	fprintf(stderr, "map_file: cannot map file %s\n", filename);
	perror("map_file");
    }

    fclose(f);

    return r;
}


    
