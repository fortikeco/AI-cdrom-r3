
#include "code.h"

/************************* Sic Search Routines ***************************/
void 
init_sic_search()
{
	char	*ind_env, *base_env, *code_env, *dir_env;
	char	buffer[BUFSIZ];

	if ((dir_env = getenv("SIC_SEAR_DIR")) == NULL)
		dir_env = strdup( DEF_SEAR_DIR );
	
	if ((base_env = getenv("SIC_CODE_BASE")) == NULL)
		base_env = strdup( DEF_CODE_BASE );
	sprintf( buffer, "%s%s\0", dir_env, base_env );
	base_size = file_size(buffer);
	code_base = map_file(buffer, base_size, 0);


	if ((ind_env = getenv("SIC_INDEX_FILE")) == NULL)
		ind_env = strdup( DEF_INDEX_FILE );
	sprintf( buffer, "%s%s\0", dir_env, ind_env );
	sic_size = file_size(buffer);
	sic_index = map_file(buffer, sic_size, 0);


	if ((code_env = getenv("SIC_CODE_INDEX")) == NULL)
		code_env = strdup( DEF_CODE_INDEX );
	sprintf( buffer, "%s%s\0", dir_env, code_env );
	index_size = file_size(buffer);
	code_index = map_file(buffer, index_size, 0);

}

void
add_code_counts(word)
	char  *word;

{
	char  *r, *s, *str;
	int   code, start, count;

	toLower(word);
	r = get_codes(word);
	clear_count_flags();
	if (r) {
		while ((s = index(r, '\n')) != NULL) {
			*s = '\0';
			sscanf(r, "%*s %d %d %d", &code, &start, &count);
			/* fprintf(stdout,"%s, %d, %d\n",word,code,start); */
			if (count_flag[code] == 0) {
			    count_flag[code] = 1;
				code_counts[code]++;
			/* fprintf(stdout," count, %d, %d\n",code,code_counts[code]); */
				if (code_counts[code] > max_count)
					max_count = code_counts[code];
			}
			add_line_offset(code, start, count);
			r = s + 1;
		}
	}
}

void
clear_code_counts()
{
	int i;
	
	/* dirty method */
	for (i=0; i < MAXCODENUM; i++) {
	   line_offset_array[i] = NULL;
	   code_counts[i] = 0;
	   max_dups[i] = 0;
	   /* added by HDP */
	   sic_result[i].score = 0;
	   sic_result[i].code = (short)i;
   }
	max_count = 0;
}


int
get_code_struct()
{
	int		j, i, iflag;

	iflag = -1; /* current location for insert into array */
	for (j = max_count; j > 0; j--) {
		for (i = 0; i < MAXCODENUM; i++) {
			/* if (code_counts[i] == j) { */
			if (code_counts[i] == j) {
				if ((++iflag) == MAXCODENUM) {
					fprintf(stdout, "To many swaps\n");
					fflush( stdout );
					return( iflag );
				}else{
					/* do inline swap of array */
					swap_elm( sic_result, i, iflag );
					/* assign a score */
					sic_result[iflag].score = j;
					/* fix up code_counts */
					swap_code_counts( code_counts, i, iflag );
					/* Debug
					printf("iflag - sic_result[%d] is score `%d' and code `%d'\n",
						   iflag, sic_result[iflag].score,
						   sic_result[iflag].code);
					printf("i - sic_result[%d] is score `%d' and code `%d'\n",
						   i, sic_result[i].score,
						   sic_result[i].code);
					fflush(stdout);
					End Debug */
				}
			}
		}
	}
	return( iflag+1 );
}/*get_code_struct*/


/*************************** Sic Tool Routines ****************************/
char           *
get_code_list()
{

	int             i, j, jflag;
	char            *list, tmp[MAXCOUNTWRIT+5];

	list = (char *)malloc( sizeof( char ) );
	strcpy(list, "" );
	for (j = max_count; j > 0; j--) {
		jflag = 1;
		for (i = 0; i < MAXCODENUM; i++) {
			if (code_counts[i] == j) {
				if (jflag == 1) {
			    	sprintf(tmp,"--%d--\n",j);
					list = (char *)realloc( list,
										    (strlen(list) + strlen(tmp))
										    * sizeof( char ) );
			    	strcat(list,tmp);
			    	jflag = 0;
			    }
				sprintf(tmp, "%d\n", i);
				list = (char *)realloc( list,
									   (strlen(list) + strlen(tmp))
									   * sizeof( char ) );
				strcat(list, tmp);
			}
		}
	}
	return list;
}


char           *
get_line_list(code)
{

	int             i, j;
	char           *line, *list;
	struct line_offset_chain *temp;
	extern char    *get_line();

	list = (char *)malloc( sizeof( char ) );
	strcpy(list, "");

	for (j = max_dups[code]; j >= 0; j--) {

		temp = line_offset_array[code];

		while (temp) {
			if (temp->dups == j) {
				line = get_line(temp->line_start, temp->line_end + 1);
				list = (char *)realloc( list,
									   (strlen(list) + strlen(line))
									   * sizeof( char ) );
				strcat(list, line);
				free(line);
			}
			temp = temp->next;
		}

	}
	return list;
}


/**************************** Local Routines ****************************/
static void
clear_count_flags()
{
	int i;
	
	for (i=0; i < MAXCODENUM; i++) {
	   count_flag[i] =0;
	   }
}


/* get the code list given a spelling form */
static char *get_codes(form)
char *form;
{
    char *result, *ref = NULL;
    char *pattern, stem[WORDSIZE];
    int offset, count, stemret;

	if ((stemret = stemmer(form, stem)) >= 0)
		toLower(stem);
	else if (stemret != -2)
		strcpy(stem, form);
	else {
		printf("User needs to define a STEM_METHOD\n");
		exit( -1 );
	}
	pattern = malloc(strlen(stem) + 3);
	sprintf(pattern, "\n%s ", stem);

	ref = srch(pattern, code_index, index_size);
	free(pattern);

    if (ref) {
		if (sscanf(ref, " %d %d", &offset, &count) == 2) {
			count = count-offset+1;
			result = malloc(count+1);
			strncpy(result, code_base+offset, count);
			result[count] = 0;
			return result;
		}
		else {
			fprintf(stderr, "internal file error, get_codes\n");
			fflush( stderr );
			exit(1);
		}
    }
    else return NULL;
}

static void
add_line_offset(code, start, end)
	int             code;
	int             start;
	int             end;
{
	struct line_offset_chain *temp, *new, *move;

	new = (struct line_offset_chain *)
		malloc(sizeof(struct line_offset_chain));
	new->line_start = start;
	new->line_end = end;
	new->dups = 0;
	new->next = NULL;

	temp = line_offset_array[code];
	if (temp == NULL) {
		line_offset_array[code] = new;
	} else {


		while (temp->next) {
			if (temp->line_start == start) {
				/*
				 * this line already goes with this code so
				 * give it more weight but don't add it to
				 * the list but move it to the front of the list	 */
				 				 
				 				 
/*			fprintf(stdout," dup %d, %d\n",code,start); */
					code_counts[code]++;
/*			fprintf(stdout,"  count %d, %d\n",code,code_counts[code]); */

					if (code_counts[code] > max_count)
						max_count = code_counts[code];
					temp->dups++;
					if (temp->dups > max_dups[code])
						max_dups[code] = temp->dups;

				return;
			}
			temp = temp->next;
		}
		temp->next = new;
	}
}

static char           *
get_line(offset, count)
	int             offset;
	int             count;
{
	char           *result;

	result = malloc(count + 1);
	strncpy(result, sic_index + offset, count);
	result[count] = 0;
	return result;
}

static void
swap_elm( sic_result, from, to )
	Score_Code	sic_result[];
	int			from, to;
{
	Score_Code	temp;

	bcopy(&sic_result[to], &temp, sizeof( Score_Code ) );
	bcopy(&sic_result[from], &sic_result[to], sizeof( Score_Code ) );
	bcopy(&temp, &sic_result[from], sizeof( Score_Code ) );
}/*swap_elm*/

static void
swap_code_counts( code_counts, from, to )
	int	code_counts[];
	int	from, to;
{
	int	temp;

	temp = code_counts[to];
	code_counts[to] = code_counts[from];
	code_counts[from] = code_counts[to];
}/*swap_code_counts*/
