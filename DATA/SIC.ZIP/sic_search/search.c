
#include "search.h"

int
sic_lookup(terms)
	char	*terms;
{
	int    result, len;
	char   word[WORDSIZE];
	char   *str;
	static	init_lookup = 0;

	if (!init_lookup) {
		init_sic_search();
		init_lookup++;
	}
	clear_code_counts();
	str = (char *)malloc( strlen(terms) + 3 );
	strcpy( str, terms );
	strcat( str, "\n");
	result = sscanf(str, "%[^ -\n]", word);
	/*fprintf(stdout, "word - `%s' and result - %d\n",
			word, result );*/
	while (result == 1) {
		len = strlen(word);
		add_code_counts(word);
		str = str + len + 1;
		while (*str == ' ')
			str++;
		result = sscanf(str, "%[^ -\n]", word);
	}
	return( get_code_struct() );
}
