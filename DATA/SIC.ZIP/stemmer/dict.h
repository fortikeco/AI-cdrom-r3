/*
 * This header file was created for the CRL LDOCE Project
 *  by: Jim Cowie
 *  modified by: Heather D. Pfeiffer
 *
 * code file: dict
 * created:   11/16/92
 * purpose:
 * functions:
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <malloc.h>
#include <string.h>


/* #define	DEF_DICTIONARY	"/usr/slator/dict/all" */
#define DEF_INDEX		"/usr/slator/dict/sort"
#define DEF_SUBINDEX	"/usr/slator/dict/subindex"

#define WELCOMEPROMPT	"\"Dictionary process ready.\"\n"
#define ENDOFITEM	"NIL\n"
#define KEYLEN	 50

typedef struct inode {
   struct inode *inext;
   char *iword;
   long int iaddress;
}Inode;

typedef struct iinode {
   struct iinode *iinext;
   Inode *iibelow;
}IInode;

static IInode *iifirst = NULL;

static Inode *first = NULL;

static int firstrand = 1;
static int position;

static char head[KEYLEN];

static FILE *index, *subindex;


/*
 * Local routines
 */
static Inode	*ialloc();
static IInode	*iialloc();
static Inode	*mkinode();
static IInode	*mkiinode();
static void		mkilist();
static void		mkiilist();

static Inode	*getinode();

static char		*strsave();
static long int getestimate();
static long int	findfrom();
