/*
 * This header file was created for the TIPSTER project.
 *  by: Jim Cowie, William Ogden
 *  modified by: Heather D. Pfeiffer
 *
 * header file: stem
 * created:     11/16/92
 */

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

#include "stemmer.h"

/*
 * Global Defines
 */

/* return codes */
#define UNAVL_STEMMER	-3
#define UNDEF_STEMMER	-2
#define UNDEF_DICT		-1

/* buffer sizes */

/******* The next section of includes, defines, globals and externs *******/
/*******   are for the `STEWORD' stemmer.                           *******/
/* following code should be included in main 

init_ldoce();

int stemword(char *, char *); returns -1 if no LDOCE definition
exists, 0 if definition exists in unmodified form and a positive number
if a stemmed form is found, 99 is returned for numbers , 101, 102, 103
returned for punctuation. */

#include <fcntl.h>

#define HEADWORD  0XF1
#define MAXBLCKS  40
#define BLCKLEN  512
#define LASTONE  29384
#define USED 2

#define NF 1
#define NB 2
#define NF_NF
#define NF_NB 3
#define TRUE 1
#define FALSE 0
#define READ 1
#define WRITE 2

/* Constants for suffix modification
   and flagging */
#define GO '0'
#define ES '1'
#define ERDT '2'
#define G2 '3'
#define Y2 '4'
#define ERDT2 '5'
#define G3 '6'
#define Y3 '7'
#define NOGO '9'
#define ISH 'a'
#define FOUND 'y'
#define NOT_FOUND 'z'

/* SUFFIX TAGS */
#define S_FIX '0'
#define ED_FIX '1'
#define ING_FIX '2'
#define ER_FIX '3'
#define LY_FIX '4'
#define EST_FIX '5'
/* END OF SUFFIX TAGS */

static unsigned char ldoce_buf[USED*BLCKLEN];
static unsigned int debug = 0;
static int linecount = 0, prev_buf = 0;
static unsigned int jcdebug = 0;

static unsigned char holdreq, holdopt;
static int jcwhold;
static int count;
static char tmpchar;
static unsigned char keep_word[20], state[2];
static int buf, inbf, modcnt;
static int holdint; unsigned char no_def;
static unsigned char sem1[3], sem2[3], pos[11], subfields[11], def[600];
static unsigned char word[12];
static unsigned char strbuf[600];

static int	stem();
static int	modify_word();

/*
 * Externals to access dictionary files
 */
extern void		init_ldoce();
extern long	int	rdaddress();



/******* The next section of includes, defines, globals and externs *******/
/*******   are for the `ISPELL' stemmer.                            *******/
static int pid;
static FILE *out, *in;
static int to[2], from[2];

/*
 * global variables
 */
char *program = "test";

/*
 * Local Routines
 */

extern	int		stemword();
extern	void	init_ispell();
extern	int		sendandget_ispell();


/***************************************************************************/
/*      Add here any externals to routines if new stemmers are added       */
/***************************************************************************/
