/*
 * This header file was created for the TIPSTER project
 *  by: Heather D. Pfeiffer
 *  for: Jim Cowie
 *
 * header file: stemmer
 * created:     11/30/92
 * purpose:     Defines how to use the stemmer function from the
 *              library `stemmer'.
 * externs:
 *   int	stemmer( query_word, stem_word )
 *
 *   input:
 *          query_word: This is the word that the user is looking
 *                      for a stem word too.
 *
 *   output:
 *          stem_word: This is the stem word; NOTE: the calling
 *                     function must allocate the space for this
 *                     word.
 *
 *          stemmer(): The return of the function is a return code
 *                     with the following meanings:
 *                        -3 : This stemming function (facility)
 *                             has not been implemented yet in the
 *                             stemmer function.
 *                        -2 : The stemming function (facility)
 *                             is some how unavailable or it may
 *                             be undefined; NOTE: if the environment
 *                             variable `STEM_METHOD' is not
 *                             defined (see below).
 *                        -1 : The dictionary can not stem the
 *                             word.
 *                         0 : The word is itself a stem.
 *                      1-98 : Number of modifications from the
 *                             query_word to get to the stem_word.
 *                        99 : The word starts with a number.
 *                       101 : The word is punctuation.
 *                       102 : The word is punctuation.
 *                       103 : The word is punctuation.
 *
 *
 * environment:
 *   There are three environment variables used with this function;
 *    only the environment variable `STEM_METHOD' must be defined ..
 *    the other two have built-in defaults and are primarily available
 *    for portability:
 *
 *   STEM_METHOD:   the stem method that the analyst would like to use;
 *                  currently possible - `stemword'.
 *   STEM_INDEX:    the stem index file to use.
 *   STEM_SUBINDEX: the stem subindex file to use.
 *
 *   NOTE: all of these variables can be defined into the environment
 *         by sourcing the file `.stem_env' in the /usr/tipster/include
 *         directory.
 */

extern	int	stemmer();

/*
 * Global Typedefs
 */

/* defines the type of stemmers available;
    NOTE: if one addes a stemmer, they need to add a `Stem_Type' to
	      use in the stemmer function.
*/
typedef enum {
	STEMWORD,
	ISPELL
} Stem_Type;



