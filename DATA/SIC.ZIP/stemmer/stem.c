/*
 * This code file was created for the TIPSTER project.
 *  by: Jim Cowie and William Ogden
 *  modified by: Heather D. Pfeiffer
 *
 * code file: stem
 * created:   11/2/92
 */

#include "stem.h"

/********************** Following code done by HDP **************************/
int stemmer( query_word, stem_word )
	char	*query_word;
	char	stem_word[];
{
	static	short 		  init_stemmer = 0;
	static	char  		  *oldenv = NULL;
	static  Stem_Type	  found;
	int			  		  returnval = UNAVL_STEMMER;
	char		  		  *envmethod;

	if ((envmethod = getenv("STEM_METHOD")) != NULL) {
		/* Debug
		printf("Env method for STEM_METHOD - `%s'\n",
			   envmethod);
		fflush( stdout );
		   End debug */
		if ((oldenv == NULL) ||
			(strcmp( oldenv, envmethod ) != 0)) {
			oldenv = strdup( envmethod );
			init_stemmer = 0;

/* Add code here if one adds a new Stem_Type */
			if ((strcmp( envmethod, "stemword")) == 0)
				found = STEMWORD;
			else if ((strcmp( envmethod, "ispell" )) == 0)
				found = ISPELL;
			else
				return( UNAVL_STEMMER );
		}
	}else
		return( UNDEF_STEMMER );

/* Add code here if one adds a new Stem_Type */
	switch (found) {
	  case STEMWORD:
		if (!init_stemmer) {
			init_ldoce();
			init_stemmer = 1;
		}
		returnval = stemword( query_word, stem_word );
		break;
	  case ISPELL:
		if (!init_stemmer) {
			init_ispell( "ispell", "-a" );
			init_stemmer = 1;
		}
		returnval = sendandget_ispell( query_word, stem_word );
		break;
	  default:
		return( UNAVL_STEMMER );
		break;
	}/* switch */
	
}/* stemmer */

			

/********************** Following code done by J. Cowie *********************/
/*---------------*/

int stemword(wordin,wordout)
char * wordin, * wordout;{
int found;

    found = stem(wordin,wordout);
    if (found > 0){
#ifdef DEBUG
         printf("original %s, final %s\n",wordin,wordout); 
#endif DEBUG
         }
      else{
#ifdef DEBUG
         printf("not found unstemmed - %s\n",wordin);
#endif DEBUG
        } 
   return(found); 
}

static int
stem(in_word,result_word)
char  * in_word, * result_word;
{
int result;

   keep_word[0] = 0;
   strcpy(keep_word,in_word);
   /* move characters converting to lower case */
   for(buf=0,inbf=0;keep_word[buf];buf++){
       result_word[inbf]=keep_word[buf]|040;
       inbf++;
       }
   result_word[inbf]=0;

/* See if number or pucntutation */

   tmpchar = result_word[0];
   if ((tmpchar >='0') && (tmpchar <= '9')){
        return(99);
        }

   if((tmpchar  >='a')&&(tmpchar <='z')){
       modcnt=0;
       state[0]=GO;
       while(state[0]!=NOT_FOUND&state[0]!=FOUND){
           buf=rdaddress(result_word);
           if(buf>0){
               /*extract(keep_word,result_word,result,holdvers,holdint); */
             result = 1;
/*
               result = check_entry(buf);
*/
               if (result) state[0]=FOUND;/* Terminate loop */
                     else{
                       modify_word(result_word,state);
                       modcnt++;
                      }
               }
           else{
               modify_word(result_word,state);
               modcnt++;
               }
            }
       if(state[0]==NOT_FOUND){
           return(UNDEF_DICT);
           }
        else{
           return(modcnt);
           }
       }
   else{
       switch(tmpchar){
           case ',':
           case '.':
           case ':':
           case '!':
           case ';':
           case '?':
               return(101);
           case '-':
           case ')':
           case '(':
                return(102);
           default:
               return(103);
           }
       } 
   }


/*------------*/


/* Do suffix alteration */
static int
modify_word(wordin,state)
    unsigned char *wordin, *state;
{	
int w_len, xint;
unsigned char hold[10];

while(state[0]!=NOT_FOUND){
w_len=strlen(wordin);
switch(state[0]){
    case GO:
         switch(wordin[w_len-1]){
             case 's':
                 if(w_len<2)goto failed;
                 if(!strcmp(wordin+w_len-3,"ous"))goto failed;
                 if(!strcmp(wordin+w_len-4,"ness")){
                        wordin[w_len-4]=0;
                        return;
                        }
                 if(!strcmp(wordin+w_len-2,"ss"))goto failed;
                 wordin[w_len-1]=0;
                 state[0]=ES;
                 return;
             case 'd':
                 if(w_len<2)goto failed;
                 if(strcmp(wordin+w_len-2,"ed"))goto failed;
                 wordin[w_len-1]=0;
                 state[0]=ERDT;
                 return;
             case 'g':
                 if(w_len<3)goto failed;
                 if(strcmp(wordin+w_len-3,"ing"))goto failed;
                  wordin[w_len-3]='e';
                 wordin[w_len-2]=0;
                 state[0]=G2;
                 return;
             case 'h':
                 if(w_len<5)goto failed;
                 if(strcmp(wordin+w_len-3,"ish"))goto failed;
                  wordin[w_len-3]=0;
                 state[0]=ISH;
                 return;
             case 'r':
                 if(w_len<2)goto failed;
                 if(strcmp(wordin+w_len-2,"er"))goto failed;
                 wordin[w_len-1]=0;
                 state[0]=ERDT;
                 return;
             case 'y':
                 if(w_len<2)goto failed;
                 if(!strcmp(wordin+w_len-2,"ly")){
                 wordin[w_len-2]=0;
                 state[0]=Y2;
                   }
                else{
                    wordin[w_len-1]=0;
                    state[0]=NOGO;
                    }
                 return;
             case 't':
                 if(w_len<3)goto failed;
                 if(strcmp(wordin+w_len-3,"est"))goto failed;
                 wordin[w_len-2]=0;
                 state[0]=ERDT;
                 return;
              default:
                 state[0]=NOT_FOUND;
                 return;
                }
          case ES:
                 if(w_len<2)goto failed;
                 if(wordin[w_len-1]!='e'){
                     if(!strcmp(wordin+w_len-3,"ing")){state[0]='0';
                                continue;
                                }
                           else{
                         goto failed;}
                     }
                 wordin[w_len-1]=0;
                 if(wordin[w_len-2]=='i')wordin[w_len-2]='y';
                 state[0]=NOGO;
                 return;
     case ERDT:
         wordin[w_len-1]=0;
         state[0]=ERDT2;
         return;
     case ERDT2:
          if(w_len<2)goto failed;
          if(wordin[w_len-1]=='i')wordin[w_len-1]='y';
             else{
                 if(wordin[w_len-2]==wordin[w_len-1]){
                       wordin[w_len-1]=0;
                       }
                  else goto failed;
                  }
          state[0]=NOGO;
          return;
    case G2:
          wordin[w_len-1]=0;
          state[0]=G3;
          return;
     case G3:
        if(wordin[w_len-2]!=wordin[w_len-1])goto failed;
        wordin[w_len-1]=0;
        state[0]=NOGO;
        return;
     case ISH:
          if(w_len<2)goto failed;
          if(wordin[w_len-1]=='u'){
              wordin[w_len]='e';
              wordin[w_len+1]=0;
              }
             else{
                 if(wordin[w_len-2]==wordin[w_len-1]){
                       wordin[w_len-1]=0;
                       }
                  else goto failed;
                  }
          state[0]=NOGO;
          return;
     case Y2:
        switch(wordin[w_len-1]){
          case 'p':
          case 't':
          case 'b':
             wordin[w_len]='l';
             wordin[w_len]='e';
             wordin[w_len+1]=0;
             break;
          case 'i':
             wordin[w_len-1]='y';
             break;
          case 'l':
             if(w_len>3){
                 if(!strcmp(wordin+w_len-3,"cal")){
                       wordin[w_len-2]=0;
                       state[0]=NOGO;
                       return;
                       }
                  else{
                      wordin[w_len]='e';
                      wordin[w_len+1]=0;
                      state[0]=Y3;
                      return;
                      }
                 }
             goto failed;
           case 'u':
              wordin[w_len]='e';
              wordin[w_len+1]=0;
              break;
           case 'g':
           case 'd':
              state[0]='0';
              continue;
          default: goto failed;
          }
       state[0]=NOGO;
       return;
    case Y3:
        wordin[w_len-1]='l';
        state[0]=NOGO;
        return;
    default:
        state[0]=NOT_FOUND;
       }
   }
failed:
    state[0]=NOT_FOUND;
    return;
}

/********************** Following code done by W. Ogden *********************/
/*---------------*/

/*
 * The ``prog_name'' parameter is the full path name of the program
 * to be run.
 * Example:
 *
 * init_ispell("/usr/local/bin/ispell", "-a");
 *
 * After this call, the 2 FILE * variables will contain the file
 * pointers that can be used with functions like fprintf(), fscanf(),
 * etc.
 *
 * To close the forked process, simply do:
 * fclose(in);
 * fclose(out);
 *
 * To make sure all the data gets to the forked process, do:
 * fflush(out) after doing the needed fprintf(), etc.
 */

void
init_ispell(prog_name, param)
char *prog_name, *param;
{
    if (pipe(to) || pipe(from)) {
	fprintf(stderr, "%s: cannot open connection to MT System\n", program);
	exit(1);
    }
    if ((pid = fork())) {       /* parent process */
	close(to[0]);   /* close read side of pipe */
	close(from[1]); /* close write side of pipe */
	out = fdopen(to[1],"w"); 
	in = fdopen(from[0],"r");
	if (in == NULL || out == NULL) {
	    fprintf(stderr, "%s: fdopen failed\n", program);
	    exit(1);
	}
	setbuf(in,NULL);
	setbuf(out,NULL);
	return;
    } else {             /* child process */
	close(to[1]);    /* close write side of pipe */
	close(from[0]);  /* close read side of pipe */
	if (dup2(to[0], 0) != 0) { /* read side = stdin */
	    fprintf(stderr,"%s: expected to duplicate stdin but failed\n",
		    program);
	    exit(1);
	}
	if (dup2(from[1], 1) != 1) { /* write side = stdout */
	    fprintf(stderr,"%s: expected to duplicate stdout but failed\n",
		    program);
	    exit(1);
	}
	setbuf(stdin,NULL);
	setbuf(stdout,NULL);

        execlp(prog_name, prog_name, param, NULL);
	fprintf(stderr,"%s: exec failed\n", program);
	exit(1);
    }
}

int
sendandget_ispell(query_word, stem_word)
char *query_word, stem_word[];
{
    char inbuf[BUFSIZ];

	fprintf(out, "%s\n", query_word);
    fscanf(in, "%[^\n]", inbuf);
    /* Remove terminating newline since fscanf doesn't seem to want to
       find it. */
    (void) getc(in);
	tmpchar = inbuf[0];
	switch(tmpchar){
	  case '+':
     	stem_word[0] = '\0';
       	sscanf(inbuf, "%*s %s", stem_word);
        return( 1 );
		break;
	  case '*':
		if((query_word[0]  >='a')&&(query_word[0] <='z')){
			return( 0 );
		}else
			switch (query_word[0]) {
			  case ',':
			  case '.':
			  case ':':
			  case '!':
			  case ';':
			  case '?':
				return(101);
			  case '-':
			  case ')':
			  case '(':
                return(102);
			  default:
				return(103);
			}
		break;
	  default:
		if ((query_word[0] >= '0') && (query_word[0] <= '9'))
			return(99);
		else
			return( UNDEF_DICT );
		break;
	}
}
