/*
 * This code file was created for the CRL LDOCE Project
 *  by: Jim Cowie
 *
 * code file: dict
 * created:   11/16/92
 */

#include "dict.h"

/* ---- CRL LDOCE INTERFACE */
void
init_ldoce()
{
    long int address;
	char	*ind_env;
	char	*subind_env;
	
/*    if ((dict = fopen (DICTIONARY, "r")) == NULL)
	printf("%s: cannot open %s\n", DICTIONARY); */

	if ((ind_env = getenv("STEM_INDEX")) == NULL)
		ind_env = strdup( DEF_INDEX );
    if ((index = fopen (ind_env, "r")) == NULL) {
    	printf("%s: cannot open %s\n", ind_env);
		fflush(stdout);
	}

    if ((subind_env = getenv("STEM_SUBINDEX")) == NULL)
		subind_env = strdup( DEF_SUBINDEX );
    if ((subindex = fopen (subind_env, "r")) == NULL) {
		printf("%s: cannot open %s\n", subind_env);
		exit(-2);
    }
	
    mkilist();
    mkiilist();
    if ((index <= 0) || (subindex <= 0)) {
		printf("Permission denied\n");
		fflush(stdout);
		exit(-2);
    }
}

long int
rdaddress(key)
char * key;
{
  long int address;
  int scan;
  if (feof(index) != 0)
     rewind (index);
  fseek (index, getestimate(key), 0);
  address = findfrom (key);
  return (address);
}


/*********************** Local Routines ***************************/
static Inode *
ialloc()
{
   return ((struct inode *) calloc(1, sizeof (struct inode)));
}

static IInode *
iialloc()
{
   return ((struct iinode *) calloc(1, sizeof (struct iinode)));
}

static Inode *
mkinode(next, key, val)
char *key;
long int val;
Inode *next;
{
   Inode *p;
   p = ialloc();
   p->inext = next;
   p->iword = strsave (key);
   p->iaddress = val;
   return p;
}

static IInode *
mkiinode(next, below)
IInode *next;
Inode *below;
{
   IInode *p;
   
   p = iialloc();
   p->iinext = next;
   p->iibelow = below;
   return p;
}

static void
mkilist()
{
   int scan;
   long int val;
   char key [KEYLEN];
   Inode *last;

   scan = fscanf (subindex, "(%s . %ld)", key, &val);
   getc (subindex);
   first = mkinode (NULL, key, val);
   last = first;
   scan = fscanf (subindex, "(%s . %ld)", key, &val);

   while (scan != EOF)
     {
       getc (subindex);
       last->inext = mkinode (NULL, key, val);
       last = last->inext;
       scan = fscanf (subindex, "(%s . %ld)", key, &val);
     }
}

static void
mkiilist()
{
   Inode *below;
   IInode *last;
   int icount;

   below = first;
   iifirst = mkiinode (NULL, below);
   last = iifirst;

   while (below != NULL)
     {
       icount = 0;
       while ((icount < 20) && (below != NULL))
         {
           icount++;
           below = below->inext;
	 }
       if (below == NULL) return;
       last->iinext = mkiinode (NULL, below);
       last = last->iinext;
     }
}

static Inode *
getinode(key)
char key[];
{
  int  match;
  IInode *p, *nextp;

  match = -1;
  nextp = iifirst;
  while (! ((match > 0) || (nextp == NULL)))
     {
       p = nextp;
       nextp = p->iinext;
       if (nextp != NULL)
          match = strcmp(nextp->iibelow->iword, key);
     }
  return(p->iibelow);
}

static char *
strsave(s)
char *s;
{
  char *p;

  if ((p = calloc(1, strlen(s)+1)) != NULL)
       strcpy(p, s);
     return(p);
}

static long int
getestimate(key)
char key[];
{
  int  match;
  Inode *p;
  long int estimate;
  char word[KEYLEN];

  match = -1;
  p = getinode(key);
  while (! ((match > 0) || (p == NULL)))
     {
       estimate = p->iaddress;
       match = strcmp(p->iword, key);
       p = p->inext;
     }
  if (estimate < 1200){
     return(0);
     }
  return (estimate - 1100);
}

static long int
findfrom(key)
char *key;
{
int scan, match, c;
long int address;
char word[KEYLEN];

c = getc(index);
if (c != '(')
   while (getc(index) != '\n');
if (c == '(')
   ungetc(c, index);


match = -1;
while (! ((scan == EOF) || (match >= 0)))
   {
     scan = fscanf (index, "(%s", word);
     match = strcmp (word, key);
     if (match == 0)
        {
         fscanf (index, " . %ld)", &address);
#ifdef DEBUG
         printf("%s exists\n",key);
#endif DEBUG
         return(address);
	}
     c = getc(index);
     while (! ((c == '\n') || (c == EOF)))
        c = getc(index);
   }
#ifdef DEBUG
  printf("%s not found\n",key);
#endif DEBUG
  return (0);
}
