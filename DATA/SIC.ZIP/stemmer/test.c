/*
 * This code file was created for testing purposes.
 *  by: Heather D. Pfeiffer
 *
 * code file:  test
 * created:    12/3/92
 * purpose:    This is just a test program to see if the new stemmer
 *             function is working correctly.
 */

#include <stdio.h>
#include <strings.h>
#include "stemmer.h"

void
main( argc, argv )
	int		argc;
	char	*argv[];
{
	char	stem[80];
	char	query[80];
	int		returncode;

	stem[0] = '\0';
	if (argc > 1)
		strcpy( query, argv[1] );
	else
		strcpy( query, "salaries" );
	returncode = stemmer( query, stem );

	printf(" For `%s' - `%s' was found with return code `%d'\n",
		   query, stem, returncode );
	fflush( stdout );
	
}/*main*/
