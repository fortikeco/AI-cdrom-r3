1. Title of Database: Mechalnalysis (diagnosis of faults in
                                     electro-machanical devices
				     from vibration measurements)
2. Sources:
   (a) Original owners of database:

	F. Bergadano, A. Giordana, L. Saitta, M. Botta

	University of Torino, Italy
	Corso Svizzera 185, Torino - tel. (39) 11 7712002
	e-mail: bergadan@itoinfo.bitnet

	F. Bracadori, D. De Marchi

	Sogesta, Localita' Crocicchio, Urbino, Italy

   (b) Donor of database: Enichem (Eni), Ravenna through Sogesta (Eni), Urbino.
   (c) Date received: June 1990
3. Past Usage:
   (a) F. Bergadano, A. Giordana, L. Saitta, F. Brancadori, D. De Marchi:
       "Integrated Learning in a real Domain"
       Proc. VII ML Conference, Austin TX, 1990
   (b) Indication of what attribute(s) were being predicted: class.
   (c) Indication of study's results: results are described in the paper.
4. Relevant Information Paragraph:
   we could not put one instance per line because
   every instance contains many components, every
   components has 8 attributes, and the number of
   components varies. Every instance
   is then given in a separate file.
5. Number of Instances: 209
6. Number of Attributes for every example component: 8
7. Attributes:

   0 - dummy (always 1) - used for numbering - ignore
   1 - class - classification (1..6, the same for components of one example)
   2 - # - component number (integer)
   3 - sup - support in the machine where measure was taken (1..4)
   4 - cpm - frequency of the measure (integer)
   5 - mis - measure  (real)
   6 - misr - earlier measure (real)
   7 - dir - filter, type of the measure and direction:
		       {vo=<no filter, velocity, horizontal>,
			va=<no filter, velocity, axial>,
			vv=<no filter, velocity, vertical>,
			ao=<no filter, amplitude, horizontal>,
			aa=<no filter, amplitude, axial>,
			av=<no filter, amplitude, vertical>,
			io=<filter, velocity, horizontal>,
			ia=<filter, velocity, axial>,
			iv=<filter, velocity, vertical>}
   8 - omega - rpm of the machine (integer, 
				   the same for components of one example)

8. Missing Attribute Values: none (when measures are
   missing, the corresponding component will not be included
   in the example, but for components that are included,
   all attributes are given)
9. Class Distribution: 69 69 14 13 16 28
    However, this classification is sometimes wrong because of
    the requirement that only one class per example be given.
    If a learning system can handle multiple classifications,
    the "class" attribute should be changed according to the
    information given in the file "trueclass".

10. The file THEORY contains a Horn feature theory that has been
used by ml-smart to generate the results reported in
"learn08.ambi (ambiguity), learn08.err (error rate) , learn08.mat
(confusion matrix)" for the learning set.
The analogous files "test08.ambi, test08.err and test08.mat" report
the results for the test set.

11. The files "predicates.fr , semantics.fr" contains the operational
definition of the predicates, how they can be deduced from the
original relation obj containing all the learning set.
In order to make the data set usable from a system FOIL like
the predicates have been posed in extensional form.
The files contained in the directory LEARN corresponds to such
extensions for the learning set, whereas the ones in TEST
are the same for the test set.
Be aware that ML-SMART can learn numerical constants.
Here, the extension have been generated using the dfault values
suggested by the teacher !!!!!

12. The format of the tuple in the relation is as follows:
(a) F the identifier of the sample (see file obj).
(b) mu
the truth degree of the assertion. This value can range from 0.5 
to 1.0. Here probably the values are just boolean (1.0).
(c) X1, X2, ...
The numerical identifiers of the items (components of the
example F to which the variables in the predicate are bound.

