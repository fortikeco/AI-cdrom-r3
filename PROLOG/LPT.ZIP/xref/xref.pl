:- quietspy(on).

:- library(record).
/*  Note! This defines member/2, so I've commented out the
    definition in XRFTTY.PL. Uncomment it if not using
    Poplog.
*/

rec(F) :-
    reconsult(F),
    write(F), write(' reconsulted'), nl.


:- rec('[POPX.XREF]XRF.PL').
:- rec('[POPX.XREF]XRFCOL.PL').
:- rec('[POPX.XREF]XRFDEF.PL').
:- rec('[POPX.XREF]XRFMOD.PL').
:- rec('[POPX.XREF]XRFOUT.PL').
:- rec('[POPX.XREF]XRFTTY.PL').
