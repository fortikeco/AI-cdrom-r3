/*  MARS.PL  */


/*  Sweet prices for Lesson 5.  */


costs(twix,14).
costs(marathon,15).
costs(nutty,14).
costs(yorkie,22).
costs(mars,15).
costs(bounty,15).
costs(bournville,22).
costs(peperami,22).
costs(satsuma,5).
costs(banana,15).
costs(snowball,8).
costs(lumpfish_caviar,1099).

likes(chris,bounty).
likes(steve,peperami).
likes(dai,mars).
likes(kit,mars).
likes(adam,bournville).
likes(david,satsuma).
likes(peter,lumpfish_caviar).
