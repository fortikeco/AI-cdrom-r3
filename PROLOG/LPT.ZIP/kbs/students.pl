/*  STUDENT.PL  */


/*
Course details for Supplement 5. Almost certainly should acknowledge
this. But as with Saxon, I'm not sure of the origin. Perhaps from the
Portuguese book of Prolog examples?

Sample questions:

    Do the same as for exercise 1 [saxon], but load the file "students".

    The knowledge base in this file defines three predicates:

    (1) "student". This has two arguments. The first is the name of a
student, and the second is one of the courses he or she is taking.

    (2) "tutor". This is like "student", but the first argument is the
name of a tutor, and the second is a course he or she is teaching.

    (3) "course". This has three arguments. The first is the name of a
course; the second is a day; the third is a room name. Each fact for
this predicate states where one class of the corresponding course is
taught.

Please write a question to discover: Is there a student such that a
tutor teaches him or her two different courses in the same room?
*/


student( robert, logic ).
student( julia, music ).
student( julia, logic ).
student( julia, surf ).
student( mary, science ).
student( mary, art ).
student( mary, physics ).


tutor( luis, logic ).
tutor( luis, surf ).
tutor( albert, logic ).
tutor( peter, music ).
tutor( peter, art ).
tutor( peter, science ).
tutor( peter, physics ).


course( logic, monday, room1 ).
course( logic, friday, room2 ).
course( surf, sunday, beach ).
course( maths, tuesday ,room1 ).
course( maths, friday, room2 ).
course( science, thursday, room1 ).
course( science, friday, room2 ).
course( art, tuesday, room1 ).
course( physics, thursday, room3 ).
course( physics, saturday, room2 ).
