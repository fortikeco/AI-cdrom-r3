/*  SAXON.PL  */


/*
This can be used for extra practice on comparisons. Possibly I should
acknowledge somone, but I can't remember where these facts came from.

Sample questions:

  You now have a number of facts describing the reigns of Britain's
Saxon and Danish kings, up to the Norman Conquest. Each fact is an
unconditional fact of three arguments, defining predicate "reigned". The
first argument is an atom giving the name of the king; the second is the
year in which his reign began; the third the year in which it ended.

  Please load (not restore) this file, and answer the following questions:

(1) Which king(s) started their reigns before the year 900?

(2) Which king(s) ended their reigns in the same year as the Norman
    Conquest?

(3) Which kings(s) started their reigns after the year 1040?

(4) Who reigned between 939 and 1016 AD?
*/


reigned( egbert,827,839 ).
reigned( ethelwulf,839,858 ).
reigned( ethelbald,858,860 ).
reigned( ethelbert,858,865 ).
reigned( ethelred,865,871 ).
reigned( alfred_the_great,871,899 ).
reigned( edward_the_elder,899,924 ).
reigned( athelstan,924,939 ).
reigned( edmund,939,946 ).
reigned( eadred,946,955 ).
reigned( eadwig,955,959 ).
reigned( edgar,959,975 ).
reigned( edward_the_martyr,975,978 ).
reigned( ethelred_the_unready,978,1016 ).
reigned( edmund_ironside,1016,1016 ).
reigned( canute,1017,1035 ).
reigned( harold_i,1035,1040 ).
reigned( hardicanute,1040,1042 ).
reigned( edward_the_confessor,1042,1066 ).
reigned( harold_ii,1066,1066 ).
