ph( 'Albion' , 'Hollybush Row' , 'Morrells' ).
ph( 'Ampleforth Arms' , 'Collinwood Road' , 'Halls' ).
ph( 'Ampney Cottage' , 'Cowley Road' , 'Ind Coope' ).
ph( 'Anchor' , 'Polstead Road' , 'Halls' ).
ph( 'Apollo' , 'St Aldates' , 'Morlands' ).
ph( 'Bakers Arms' , 'Cardigan Street' , 'Ind Coope' ).
ph( 'Bear' , 'Alfred Street' , 'Ind Coope' ).
ph( 'Bell' , 'Old High Street' , 'Ind Coope' ).
ph( 'Berkshire House' , 'Abingdon Road' , 'Morrells' ).
ph( 'Black Boy' , 'Old High Street' , 'Morrells' ).
ph( 'Black Swan' , 'Crown Street' , 'Morrells' ).
ph( 'Blackbird' , 'Blackbird Leys Road, Cowley' , 'Unknown' ).
ph( 'Bookbinders Arms' , 'Vernon Street' , 'Morrells' ).
ph( 'Bricklayers Arms' , 'Church Lane, Marston' , 'Halls' ).
ph( 'Brittania' , 'London Road, Headington' , 'Ind Coope' ).
ph( 'Bulldog' , 'St Aldates' , 'Courage' ).
ph( 'Bullingdon Arms' , 'Cowley Road' , 'Ind Coope' ).
ph( 'Bullingdon Arms' , 'Marsh Road' , 'Morlands' ).
ph( 'Bullnose Morris' , 'Watlington Road, Cowley' , 'Unknown' ).
ph( 'Butchers Arms' , 'Wilberforce Street, Headington' , 'Unknown' ).
ph( 'Cape of Good Hope' , 'The Plain' , 'Morrells' ).
ph( 'Carpenters Arms' , 'Botley Road' , 'Morrells' ).
ph( 'Carpenters Arms' , 'Nelson Street' , 'Morrells' ).
ph( 'Cavalier' , 'Copse Lane' , 'Ind Coope' ).
ph( 'Chequers' , 'High Street' , 'Ind Coope' ).
ph( 'Chequers' , 'Quarry Hollow' , 'Ind Coope' ).
ph( 'Chequers Inn' , 'St Thomas Street' , 'Halls' ).
ph( 'Cherwell Arms' , 'Water Eaton Road' , 'Ind Coope' ).
ph( 'Coach and Horses' , 'St Clements' , 'Morrells' ).
ph( 'Corner House' , 'Hollow Way' , 'Ind Coope' ).
ph( 'Cricketers Arms' , 'Iffley Road' , 'Morlands' ).
ph( 'Cricketers Arms' , 'Temple Road, Cowley' , 'Morrells' ).
ph( 'Cross Keys' , 'South Hinksey' , 'Morrells' ).
ph( 'Crown' , 'Canal Street' , 'Ind Coope' ).
ph( 'Crown' , 'Cornmarket' , 'Charrington' ).
ph( 'Crown' , 'Cowley Road' , 'Ind Coope' ).
ph( 'Crown' , 'Lake Street' , 'Free House' ).
ph( 'Crown and Thistle' , 'Old Road' , 'Morrells' ).
ph( 'Dewdrop' , 'Banbury Road' , 'Courage' ).
ph( 'Dolly' , 'Frewin Court' , 'Charrington' ).
ph( 'Donnington Arms' , 'Howard Street' , 'Ind Coope' ).
ph( 'Duke of Cambridge' , 'Little Clarendon Street' , 'Free House' ).
ph( 'Duke of Edinburgh' , 'St Clements' , 'Ind Coope' ).
ph( 'Duke of Monmouth' , 'Abingdon Road' , 'Ind Coope' ).
ph( 'Duke of York' , 'Norfolk Street' , 'Morrells' ).
ph( 'Eagle and Child' , 'St Giles' , 'Ind Coope' ).
ph( 'Eagle Tavern' , 'Magdalen Road' , 'Courage' ).
ph( 'Eastgate Hotel' , 'High Street' , 'Free House' ).
ph( 'Edward VII' , 'Vicarage Road' , 'Ind Coope' ).
ph( 'Elm Tree' , 'Cowley Road' , 'Morrells' ).
ph( 'Exeter Hall' , 'Oxford Road' , 'Ind Coope' ).
ph( 'Fair Rosamund' , 'Elms Rise' , 'Morrells' ).
ph( 'Fairview' , 'Glebelands' , 'Courage' ).
ph( 'Fir Tree Tavern' , 'Iffley Road' , 'Morrells' ).
ph( 'Fishes' , 'North Hinksey Lane' , 'Morrells' ).
ph( 'Folly' , 'Whitehouse Road' , 'Free House' ).
ph( 'Fox' , 'North Way, Barton' , 'Morrells' ).
ph( 'Fox and Hounds' , 'Abingdon Road' , 'Morrells' ).
ph( 'Friar' , 'Marston Road' , 'Halls' ).
ph( 'Friar Bacon' , 'Elsfield Way' , 'Morrells' ).
ph( 'Gardeners Arms' , 'North Parade' , 'Morrells' ).
ph( 'Gardeners Arms' , 'Plantation Road' , 'Morrells' ).
ph( 'General Elliott' , 'South Hinksey' , 'Morrells' ).
ph( 'George' , 'Botley Road' , 'Morrells' ).
ph( 'George' , 'Cowley Road, Littlemore' , 'Morrells' ).
ph( 'Globe' , 'Cranham Street' , 'Morrells' ).
ph( 'Gloucester Arms' , 'Friars Entry' , 'Ind Coope' ).
ph( 'Grandpont Arms' , 'Edith Road' , 'Ind Coope' ).
ph( 'Grapes' , 'George Street' , 'Morrells' ).
ph( 'Greyhound' , 'Worcester Street' , 'Ind Coope' ).
ph( 'Golden Ball' , 'Cowley Road,Littlemore' , 'Morrells' ).
ph( 'Golden Cross' , 'Cornmarket' , 'Free House' ).
ph( 'Half Moon' , 'St Clements' , 'Ind Coope' ).
ph( 'Harcourt Arms' , 'Cranham Terrace' , 'Ind Coope' ).
ph( 'Head of the River' , 'Folly Bridge' , 'Ind Coope' ).
ph( 'Hollybush Inn' , 'West Street' , 'Courage' ).
ph( 'Horse and Jockey' , 'Woodstock Road' , 'Morrells' ).
ph( 'Isis Hotel' , 'Iffley Lock' , 'Morrells' ).
ph( 'Jack Russell' , 'Old Marston' , 'Morlands' ).
ph( 'Jericho Tavern' , 'Walton Street' , 'Free House' ).
ph( 'Jolly Farmers' , 'Paradise Street' , 'Scottish & Newcastle' ).
ph( 'Jolly Postboys' , 'Florence Park Road' , 'Morrells' ).
ph( 'Kings Arms' , 'Banbury Road' , 'Ind Coope' ).
ph( 'Kings Arms' , 'Parks Road' , 'Free House' ).
ph( 'Kite' , 'Mill Street' , 'Morrells' ).
ph( 'Lamb and Flag' , 'St Giles' , 'Ushers' ).
ph( 'Lord Napier' , 'Observatory Street' , 'Ind Coope' ).
ph( 'Magdalen Arms' , 'Magdalen Road' , 'Ind Coope' ).
ph( 'Marlborough Arms' , 'St Thomas Street' , 'Morrells' ).
ph( 'Marlborough Head' , 'Oxford Road, Littlemore' , 'Ind Coope' ).
ph( 'Marlborough House' , 'Western Road' , 'Ind Coope' ).
ph( 'Marsh Harrier' , 'Marsh Road' , 'Morrells' ).
ph( 'Masons Arms' , 'Quarry School Place' , 'Unknown' ).
ph( 'Mitre' , 'Turl Street' , 'Free House' ).
ph( 'Nags Head' , 'Hythe Bridge Street' , 'Halls' ).
ph( 'Nelson' , 'Between Towns Road' , 'Ind Coope' ).
ph( 'New Inn' , 'Cowley Road' , 'Ind Coope' ).
ph( 'New Inn' , 'Nelson Street' , 'Ind Coope' ).
ph( 'Nuffield Arms' , 'Littlemore Road' , 'Unknown' ).
ph( 'Oranges and Lemons' , 'St Clements' , 'Ind Coope' ).
ph( 'Original Swan' , 'Oxford Road, Cowley' , 'Ind Coope' ).
ph( 'Old Gate House' , 'Botley Road' , 'Ind Coope' ).
ph( 'Old Tom' , 'St Aldates' , 'Morrells' ).
ph( 'Osney Arms' , 'Botley Road' , 'Ind Coope' ).
ph( 'Ox' , 'Rose Hill' , 'Morrells' ).
ph( 'Paradise House' , 'Paradise Street' , 'Morrells' ).
ph( 'Pennyfarthing' , 'Pennyfarthing Place' , 'Morrells' ).
ph( 'Perch' , 'Binsey' , 'Ind Coope' ).
ph( 'Plasterers Arms' , 'Marston Road' , 'Morrells' ).
ph( 'Plough' , 'First Turn, Wolvercote' , 'Morrells' ).
ph( 'Port Mahon' , 'St Clements' , 'Morrells' ).
ph( 'Prince of Wales' , 'Charles Street' , 'Ind Coope' ).
ph( 'Prince of Wales' , 'Church Way, Iffley' , 'Free House' ).
ph( 'Prince of Wales' , 'Cowley Road' , 'Morrells' ).
ph( 'Prince of Wales' , 'Horspath Road' , 'Morrells' ).
ph( 'Prince of Wales' , 'Walton Street' , 'Morrells' ).
ph( 'Princes Castle' , 'Barton Village Road' , 'Unknown' ).
ph( 'Quarry Gate' , 'Wharton Road' , 'Unknown' ).
ph( 'Queens Arms' , 'Church Hill Road, Cowley' , 'Courage' ).
ph( 'Queens Arms' , 'Littlemore' , 'Unknown' ).
ph( 'Queens Arms' , 'Park End Street' , 'Morrells' ).
ph( 'Radcliffe Arms' , 'Cranham Street' , 'Watneys' ).
ph( 'Red Lion' , 'Gloucester Green' , 'Ind Coope' ).
ph( 'Red Lion' , 'Oxford Road, Marston' , 'Ind Coope' ).
ph( 'Red Lion' , 'Wolvercote' , 'Ind Coope' ).
ph( 'Red Lion' , 'Woodstock Road' , 'Ind Coope' ).
ph( 'Red,White and Blue' , 'Stockmore Street' , 'Morlands' ).
ph( 'Roebuck' , 'Market Street' , 'Courage' ).
ph( 'Rose and Crown' , 'North Parade' , 'Ind Coope' ).
ph( 'Royal Blenheim' , 'St Ebbes' , 'Ind Coope' ).
ph( 'Royal Greenjacket' , 'Chester Street' , 'Ind Coope' ).
ph( 'Royal Oak' , 'Woodstock Road' , 'Ind Coope' ).
ph( 'Royal Oxford Hotel' , 'Park End Street' , 'Ind Coope' ).
ph( 'Royal Standard' , 'London Road' , 'Morrells' ).
ph( 'St Michaels Tavern' , 'St Michael Street' , 'Free House' ).
ph( 'Scholar Gipsy' , 'The Avenue, Kennington' , 'Unknown' ).
ph( 'Seacourt Bridge' , 'Botley Road' , 'Ind Coope' ).
ph( 'Seven Stars' , 'Lake Street' , 'Morrells' ).
ph( 'Shelley Arms' , 'Cricket Road' , 'Ind Coope' ).
ph( 'Shotover Arms' , 'London Road' , 'Ind Coope' ).
ph( 'Six Bells' , 'Beaumont Road' , 'Morrells' ).
ph( 'Somerset House' , 'Marston Road' , 'Ind Coope' ).
ph( 'Star Royal' , 'Rectory Road' , 'Watneys' ).
ph( 'Swan' , 'Marston Street' , 'Watneys' ).
ph( 'Tandem' , 'Kennington Road, Kennington' , 'Unknown' ).
ph( 'Temple Bar' , 'Temple Street' , 'Ind Coope' ).
ph( 'Three Horseshoes' , 'Oxford Road, Marston' , 'Ind Coope' ).
ph( 'Tree Hotel' , 'Church Way' , 'Morrells' ).
ph( 'Trout' , 'Godstow Road' , 'Charrington' ).
ph( 'Turf Tavern' , 'Bath Place' , 'Free House' ).
ph( 'University & City Arms' , 'Cowley Road' , 'Ind Coope' ).
ph( 'Victoria Arms' , 'Marston Ferry' , 'Ind Coope' ).
ph( 'Victoria Arms' , 'Walton Street' , 'Ind Coope' ).
ph( 'Walton Ale Stores' , 'Walton Street' , 'Ind Coope' ).
ph( 'Watermans Arms' , 'South Street' , 'Morlands' ).
ph( 'Welsh Pony Hotel' , 'George Street' , 'Morrells' ).
ph( 'Westgate' , 'Bonn Square' , 'Morrells' ).
ph( 'Wharf House' , 'Thames Street' , 'Ind Coope' ).
ph( 'Wheatsheaf' , 'High Street' , 'Morrells' ).
ph( 'White Hart' , 'Oxford Road, Marston' , 'Morrells' ).
ph( 'White Hart' , 'St Andrews Road' , 'Ind Coope' ).
ph( 'White Hart' , 'Wolvercote' , 'Ind Coope' ).
ph( 'White Hart' , 'Wytham' , 'Ind Coope' ).
ph( 'White Horse' , 'Broad Street' , 'Ind Coope' ).
ph( 'White Horse' , 'London Road' , 'Morrells' ).
ph( 'Woodstock Arms' , 'Woodstock Road' , 'Morrells' ).
