BOOT=c:/pl/boot
export BOOT
./pl -o c:/pl/pl.wic -b $BOOT/init.pl -c $BOOT/load.pl
