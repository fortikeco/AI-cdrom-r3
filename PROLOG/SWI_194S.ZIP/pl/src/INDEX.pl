/*  INDEX.pl,v 1.3 1994/11/22 15:10:41 jan Exp

    Creator: make/0

    Purpose: Provide index for autoload
*/

index((retractall), 1, foo, 't.pl').
