/*  $Id: parms.pl,v 1.3 1994/11/04 14:17:33 jan Exp $

    Copyright (c) 1990 Jan Wielemaker. All rights reserved.
    jan@swi.psy.uva.nl

    Purpose: Installation dependant parts of the prolog code
*/

:- user:assert(library_directory('.')).
:- user:assert(library_directory(lib)).
:- user:assert(library_directory('~/lib/prolog')).
:- user:assert((
	library_directory(Lib) :-
		feature(home, Home),
		concat(Home, '/library', Lib))).


$default_editor(vi).
