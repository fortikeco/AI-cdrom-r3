
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

#include <stream.h>
#include "hash_table.h"
#include "string_table.h"
#include "tags.h"
#include "instr.h"
#include "scan.h"
#include "memory.h"
#include "inst_args.h"
#include "inst_table.h"
#include "assembler.h"
#include "main.h"
#include "control.h"
#include "top_level.h"

Scan SCAN;
Memory M(SCAN);

void init()
{
  init_instr_args(SCAN);
  init_instr_types(SCAN);
  init_run_time_tables();
  M.allocate();
  init_code();
  M.init();
  init_commands();
}  

void print_usage()
{
  cout << "options: [-e][-c][-h][-t]\n-e -> execute\n-c -> print code\n";
  cout << "-h -> print this message\n";
  exit(0);
}

main(int, char**)
{
/*
  for (--argc; argc; --argc, argv++) {
    switch (argv[1][1]) {
    case 'e':
      exec_flag = 1;
      break;
    case 'c':
      code_flag = 1;
      break;
    case 'h':
      print_usage();
      break;
    case 't':
      trace_flag = 1;
      break;
    }
  }*/
  init();
  top_level();
}
