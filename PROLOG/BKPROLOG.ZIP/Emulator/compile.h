
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

enum {
  COMPILE_MODE,
  LOAD_MODE
  };

istream* get_loadable_file(char* name, int mode);
