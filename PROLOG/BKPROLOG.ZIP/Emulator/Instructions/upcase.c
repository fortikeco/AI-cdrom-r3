
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

#include <stream.h>
#include <ctype.h>

extern int strlen(char*);
main()
{
  char buf[80];
  char* p;
  char* p0;

  cin >> buf;
  p = buf;
  p0 = p + strlen(buf);
  for (; p < p0; p++)
    *p = (islower(*p)) ? toupper(*p) : *p;
  cout << buf;
}
