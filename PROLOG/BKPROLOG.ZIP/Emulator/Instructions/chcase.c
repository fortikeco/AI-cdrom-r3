
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

#include <stream.h>
#include <ctype.h>

extern int strlen(char*);
main()
{
  char buf1[80];
  char buf2[80];
  char* p = buf1;
  char* q = buf2;
  char* p0;
  int first_flag = 1;

  cin >> buf1;
  if (strlen(buf1) >= 80) {
    cerr << "Too long an input\n";
    exit(1);
  }

  p0 = p + strlen(buf1);

  for (; p < p0; p++) {
    if (*p == '_') {
      first_flag = 1;
    } else if (first_flag) {
      first_flag = 0;
      *q++ = toupper(*p);
    } else {
      *q++ = *p;
    }
  }
  *q = '\0';
  cout << buf2;
}
