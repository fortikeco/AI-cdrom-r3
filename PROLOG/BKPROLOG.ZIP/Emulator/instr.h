
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

struct Instr {
  int ID;
  void (*exec)();
  int count;
  Cell arg1;
  Cell arg2;
  Cell arg3;
};

typedef Instr* InstrPtr;
