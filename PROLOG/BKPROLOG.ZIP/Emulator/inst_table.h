
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

enum {
#define NAMES
#define use(String,ID,Function,Arg1,Arg2,Arg3)ID,
#include "instructions.h"
#undef use
#undef NAMES
  LAST_INSTRUCTION
  };

#define NAMES
#define use(String,ID,Function,Arg1,Arg2,Arg3)\
extern void Function();
#include "instructions.h"
#undef use
#undef NAMES

struct InstrType {
  char* name;
  int ID;
  int ArgType[3];
  void (*exec)();
  void fill(Instr& instr, char** p);
  void update(Instr& instr, int update_what);
  void print(Instr& instr);
};

extern InstrType instr_types[];
extern HashTable instr_ID;
extern void init_instr_types(Scan& scanner);

