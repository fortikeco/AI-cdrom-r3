
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

extern CellPtr H, H2, TR, TR2, B, B2, E, E2;
extern CellPtr HMIN, HMAXSOFT, HMAXHARD;
extern InstrPtr P;
extern unsigned char* MKMIN;
extern void garbage_collector();
enum {
  MARK_COPY, 
  MARK_COMPACT, 
  MARK_THRESHOLD, 
  MARK_COPY_FAST_COPY,
  MARK_COMPACT_FAST_COPY
};
extern int WHICH_GC;
extern int GC_COUNTER;
extern int gc_scanned;
extern int gc_copy_scanned;
extern int gc_survivors;
extern int tr_survivors;
extern int tr_scanned;
extern float gc_time;
extern int DISPLAY_GC;
extern int GC_COUNT_LIMIT;
extern int CHECK_GC_LIMIT;
