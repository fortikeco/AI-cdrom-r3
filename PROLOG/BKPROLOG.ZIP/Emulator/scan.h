
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

enum {SCAN_EOF, SCAN_DEF_PROC, SCAN_DEF_LABEL, SCAN_INSTR, SCAN_TABLE};

class Scan : public StringTable {
  int procedure;
  int end;
  void place_pointers();
  char* input_buffer;
  int buffer_size;
  public:
  Scan(int max_len_length = 256) {
    procedure = intern("procedure");
    end = intern("end");
    status = SCAN_INSTR;
    buffer_size = max_len_length;
    input_buffer = new char[max_len_length];
  }
  int status;
  int intern_p0;		/* the internal identifier of p[0] */
  char* p[4];			/* pointers to the four possible fields */
  void next_line();
  void print_state();
};
