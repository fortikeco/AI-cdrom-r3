
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

class StringTable : public HashTable {
  char* next_string;
  int string_space_left;
  HashTable arity_table;
  char* save_string_copy(char*);
  void alloc_string_space();
  int string_space_size;
  char* new_string(int length);
  void reenter_old_data(int, HashTableEntry**);
  void reintern(int key, int hash);
 public:
  StringTable(int string_size =4098, int hash_size =1001);
  void rehash();
  int intern(char*);
  int get_arity(int);
  int atom_to_functor(int atom, int arity);
  int functor_to_atom(int functor);
  void print();
};
