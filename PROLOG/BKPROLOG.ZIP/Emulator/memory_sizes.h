
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

use("code",CODE_SIZE,1,P0,Instr)
use("assert",RESERVED_SIZE,1,R0,Cell)
use("heap",HEAP_SIZE,10,H0,Cell)
use("trail",TRAIL_SIZE,3,TR0,Cell)
use("env",ENV_SIZE,1,E0,Cell)
use("cp",CP_SIZE,1,B0,Cell)
