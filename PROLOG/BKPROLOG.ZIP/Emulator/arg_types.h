
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

struct ArgDataRecord {
  unsigned types;
  int count;
  ArgDataRecord* next;
};

struct ArgDataRecordHead {
  int arity;
  int count;
  ArgDataRecord* next;
  void fill();
  void print();
};

class ArgTypes {
  static HashTable* addr_to_record;
 public:
  void init();
  void fill(Cell proc_addr);
  void print();
};

