
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

%	concat (con1, con6)
%	These two tests are simple examples of the concat predicate
%	con1 is determinate, con6 is non-determinate getting all 6 answers

main :- concat1, !, concat6.

concat1 :- concat([a,b,c],[d,e],X),  % con1
	write(X),nl.
concat6 :- concat(X,Y,[a,b,c,d,e]),  % con6
	write(X),nl,
	write(Y),nl,nl,
	fail.

concat([],L,L).
concat([X|L1],L2,[X|L3]) :- concat(L1,L2,L3).

