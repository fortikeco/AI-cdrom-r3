
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

rewrite(Atom,Atom) :-
	atomic(Atom),!.
rewrite(Old,New) :-
	functor(Old,F,N),
	functor(Mid,F,N),
	rewrite_args(N,Old,Mid),
	( equal(Mid,Next) -> rewrite(Next,New); New=Mid).
