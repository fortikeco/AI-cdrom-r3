
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- 
getputblock(get,[X,Y,Z],[get(A,X,x(1)),get(B,Y,x(2)),get(C,Z,x(3))|D]-E,1).

getputblock(Type, [A|Args], [X|Rest]-Link, N) :-
	X=..[Type,T,A,x(N)], !,
	(atomic(A) -> T=constant; true),
	N1 is N+1,
	getputblock(Type, Args, Rest-Link, N1).
getputblock(_, [], Link-Link, _).
