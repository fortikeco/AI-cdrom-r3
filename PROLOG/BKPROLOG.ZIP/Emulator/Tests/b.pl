
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- do(100).
do(0):- write(complete), nl.
do(N) :- virtual(X), build_struct(10,N,X), N1 is N - 1, do(N1).

build_struct(I,N,S) :- functor(S,blub,I), rewrite_args(I,N,S).

rewrite_args(I,N,S) :- rewrite_args(I,_,N,S).
rewrite_args(0,_,_,_) :- !.
rewrite_args(I,X,N,S) :- arg(I,S,X), I1 is I - 1, rewrite_args(I1,X,N,S).

virtual(_).
virtual(X).
