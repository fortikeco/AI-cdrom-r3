
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- name(X,[97,98,99]), name(blub,Y), write(X), write(Y), nl.

