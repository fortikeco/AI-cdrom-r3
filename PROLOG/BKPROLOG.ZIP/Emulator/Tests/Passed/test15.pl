
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :-
	write(population_of_china_is_),
	population(china, Y),
	write(Y), nl, nl, !,
	population(X,Y),
	write(X), write('-->'), write(Y), nl.

population(france, 54).
population(italy,61).
population(vietnam,54).
population(usa,220).
population(ussr,250).
population(china,1000).
population(japan,120).

