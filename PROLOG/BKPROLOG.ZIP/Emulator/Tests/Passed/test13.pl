
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* some arithmetic */
main :- a(X), b(Y), c(Z), W is Z*Z - X*X - Y*Y, W == 0, write(ok), nl.

a(X) :- X is 1 + 1 + 1.
b(Y) :- X is 1 + 1, Y is X + X.
c(Z) :- X is 2, Y is 3, Z is X + Y.
