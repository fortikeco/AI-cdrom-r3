
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- X = [a|W], a(X), write(X), nl.

a([a|B]).
