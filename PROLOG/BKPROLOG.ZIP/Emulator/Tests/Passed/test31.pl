
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- X = [a(_1,_2,_3)|_4], a(X,Y,Z), write(Y), write(Z), nl.

a([A|B],Func,Arity) :- A =.. [Func|Arg], length(Arg, Arity).