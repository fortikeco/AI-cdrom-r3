
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- t_redex([7|fac],H_20).

t_redex([_y,_x|_op], _res) :-
	atom(_op),
	write(wrong), nl.
