
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :-
	a(`(b)), write(ok), nl.
main :- write(wrong), nl.

a(b(X)).
a(`(X)).