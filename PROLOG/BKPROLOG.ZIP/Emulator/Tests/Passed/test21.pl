
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :-
	write(['ok?','ok?','ok?','ok?','ok?','ok?','ok?','ok?','ok?','ok?']),
	nl,
	L = [X0,X1,X2,X3,X4,X5,X6,X7,X8,X9],
	X9 = X8, X9 = X7, X9 = X6, X9 = X5, X9 = X4,
	X9 = X3, X9 = X2, X9 = X1, X9 = X0, X9 = ok,
	write(L),
	nl.


