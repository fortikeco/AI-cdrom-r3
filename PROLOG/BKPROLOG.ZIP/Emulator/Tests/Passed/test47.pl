
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/*
 * simple set and access 
 * right now, the compiler only recognizes assert and retract
 * as built-ins, not set and access.
 * in this test and the followings, we will use 
 * assert ---> for set
 * retract ---> for access
 */

main :- set(1), do_incr(24).

do_incr(0).
do_incr(N) :- N1 is N - 1, incr, do_incr(N1).

incr :-
	access(Count),
	NCount is Count + 1,
	write(Count), nl,
	set(NCount).

access(N) :- access(0,N).
set(N) :- set(0,N).

