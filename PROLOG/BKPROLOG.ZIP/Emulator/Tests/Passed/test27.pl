
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a(X,_), write(X).

a([X|Y],[X,Y]) :- c, b(Y,_).
b(X,[a|X]).
c.