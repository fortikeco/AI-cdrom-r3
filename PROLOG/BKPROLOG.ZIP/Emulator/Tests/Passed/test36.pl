
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a, b.

a :- [X,Y] =.. [A|B], write(A), write(B), nl.
b :- [] =.. [A|B], write(A), write(B), nl.
