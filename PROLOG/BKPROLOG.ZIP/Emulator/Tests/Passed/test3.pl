
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Tests list processing */

main :- append([ok1,wg1,ok2,wg2], [ok3,wg3], X),
	filter(X, [ok3, ok2, ok1], Y),
	write(Y), nl.

append([],X,X).
append([X|Xs],Y,[X|Zs]) :- append(Xs,Y,Zs).

member(X,[X|Xs]).
member(X,[_|Xs]) :- member(X,Xs).

filter([], T, []).
filter([X|Xs], T, [X|Zs]) :- member(X, T), !, filter(Xs, T, Zs).
filter([X|Xs], T, Zs) :- filter(Xs, T, Zs).


