
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a, b, c.

a :- arg(1,[ok1,ok2],X), write(X), nl.
b :- arg(2,[ok1|ok2],X), write(X), nl.
c :- arg(2,[ok1,ok3],[X]), write(X), nl.

