
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- X =.. [3,A], write(X), nl.
main :- X =.. [3], write(X), nl.
