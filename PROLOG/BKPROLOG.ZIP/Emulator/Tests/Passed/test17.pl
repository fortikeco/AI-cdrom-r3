
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- e(Y), built_list(4,Y,X), e(Y), write(X), nl.

built_list(0,_,[]).
built_list(N, Y, [[Y]|[Z]]) :- N1 is N - 1, built_list(N1, Y, Z).

e(Y).