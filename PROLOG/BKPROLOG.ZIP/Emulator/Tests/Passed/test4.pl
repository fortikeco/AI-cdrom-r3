
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/*
 * set and access bug buster
 * assert ---> for set
 * retract ---> for access
 * test also unification
 */

main :-
	set(a([X,Y], [Y,X], [X,Y], [Y,X])),
        fail.
main :-
	access(X),
	write(X), nl, nl,
	set(b(X,X,X,X)),
	fail.
main :- access(b(X,Y,Z,W)),
	X = a(A,B,C,D),
	A = [ok1,ok2],
	write(W), nl, nl.

	
access(N) :- access(0,N).
set(N) :- set(0,N).

