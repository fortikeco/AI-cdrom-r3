
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* testing if-then-elses */

main :- prove(if(a, b, c), [b,c], []), write(ok), nl.

prove(Wff, True, False) :-
	(truep(Wff, True) -> true;
	 falsep(Wff, False) -> fail;
	 Wff = if(If, Then, Else) ->
		(truep(If, True) -> prove(Then, True, False);
		 falsep(If, False) -> prove(Else, True, False);
		 prove(Then, [If|True], False), 
		 prove(Else, True, [If|False]))), !.

truep(t,_) :- !.
truep(Wff,Tlist) :- member(Wff,Tlist).

falsep(f,_) :- !.
falsep(Wff,Flist) :- member(Wff,Flist).

member(X,[X|_]) :- !.
member(X,[_|T]) :- member(X,T).




