
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- 
	write('ok?'),
	nl,
	a([a,b(c,d),[f,g|Z]]),
	b([X],Z),
	write(X),
	nl.

a([a,b(c,d),[f,g,X]]) :- b(X).
b(ok).
b(X,X).


