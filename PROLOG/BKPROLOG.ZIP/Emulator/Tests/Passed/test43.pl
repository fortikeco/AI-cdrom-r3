
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a, b, c.

a :- arg(1,a(ok1,ok2,ok3),X), write(X), nl.
b :- arg(2,a(ok1,ok2,ok3),X), write(X), nl.
c :- arg(3,a(ok1,ok2,ok3),X), write(X), nl.

