
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* environment trimming */

main :- a(X1, X2, X3, X4, X5, X6),
	b(X1, X2, X3, X4, X5, X6),
	c(X1, X2, X3, X4, X5, X6),
	write(X6), nl.
	
a(X1, X2, X3, X4, X5, X6).

b(X1, X2, X3, X4, X5, X6) :-
	X1 = [Y1|X2],
	X2 = [Y2|X3],
	X3 = [Y3|X4],
	X4 = [Y4|X5],
	X5 = [Y5|X6].

c(X1, X2, X3, X4, X5, X6) :- X1 = [1, 2, 3, 4, 5 | ok].
