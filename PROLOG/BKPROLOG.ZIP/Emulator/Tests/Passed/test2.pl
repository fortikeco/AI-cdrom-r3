
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- Z = [X,Y,A,B], X = A, A = a, Y = B, B = b, X = Y.