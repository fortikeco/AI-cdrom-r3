
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a(X).
a(X) :- !, V = [A|X], B =.. V, write(B), write(V), nl.

