
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :-
	write(['ok1?','ok2?','ok3?']), nl,
	a(R,[ok1|X]),
	a([b|X],[b|Y]),
	a(Y,Z),
	a(Z,[ok2,ok3]),
	write(R), nl.

a(X,X).
