
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :-
	write('ok?'), nl,
	reduce((12 + 24) - 6 - 18, X),
	a(X,Y),
	write(Y), nl.

a(12,ok).

reduce(A+B,C) :-
	reduce(A,A1),
	reduce(B,B1),
	C is A1 + B1.
reduce(A-B,C) :-
	reduce(A,A1),
	reduce(B,B1),
	C is A1 - B1.
reduce(A,A) :- integer(A), !.

