
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a(b).

a(a).
a(c).
a(b) :- write(ok), nl.
a(d).
