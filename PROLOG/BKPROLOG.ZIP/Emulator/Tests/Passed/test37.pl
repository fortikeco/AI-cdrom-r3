
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a, b.

a :- functor([X,Y], A, B), write(A), write(B), nl.
b :- functor([], A, B), write(A), write(B), nl.
