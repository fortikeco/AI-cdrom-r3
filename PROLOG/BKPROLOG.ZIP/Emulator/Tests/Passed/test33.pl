
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a, b.

a :- functor(a(X), Y, Z), write(Y), write(Z), nl.
b :- functor(X, b, 4), write(X), nl.
