
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- X = a(Y,Z), Y = 3, call(X).

a(1,2) :- write(wrong), nl.
a(1,3) :- write(wrong), nl.
a(3,4) :- write(ok), nl.

