
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- long_deref.

long_deref :-
	X = [X1,X2,X3,X4,X5,X6,X7,X8],
	X8 = X7,
	X8 = X6,
	X8 = X5,
	X8 = X4,
	X8 = X3,
	X8 = X2,
	X8 = X1.

	