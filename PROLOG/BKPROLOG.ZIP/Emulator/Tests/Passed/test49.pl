
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- X = a(a(1),a(2)), a(X,X).
a(X,X).
