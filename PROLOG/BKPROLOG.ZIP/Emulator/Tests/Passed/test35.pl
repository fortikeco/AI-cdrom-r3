
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- functor(true, X, Y), write(X), write(Y), nl.
