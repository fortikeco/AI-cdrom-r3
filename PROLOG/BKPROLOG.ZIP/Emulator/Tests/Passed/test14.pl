
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a(Z), fringe(Z, X), X = [], write(ok), nl.
	
fringe([],[]).
fringe(L,[L]) :- atomic(L), !.
fringe([X|Xs],Z) :- fringe(X,Y), fringe(Xs,Ys), append(Y,Ys,Z).

append([],X,X).
append([X|Xs],Y,[X|Zs]) :- append(Xs,Y,Zs).

a(X) :- e, b(B,A), e, bb(A,B,X).
b(X,Y) :- e, [a|X] = [a,Y].
bb(A,B,C) :- e, d(C, [A,B], [B|A]).
d(A,B,C) :- e, A = [B,B,C|C].
e.