
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :-
	X =.. [ok0,ok1,ok2,ok3], write(X), nl,
	Y =.. [ok4], write(Y), nl,
	ok5 =.. [M], write(M), nl,
	b(1,2) =.. [b,1,2],
	ok6(ok7,ok8) =.. L, write(L), nl,
	d(4,ok9,ok10) =.. [d,4|Z], write(Z), nl.

