
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a(Y), b([Y],Y).
a(_).
b([1],2).
