
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :-
	[a,b] = [X,_], write(X),
	Y = [Z,W], E =.. [X|Y], write(E), nl.

