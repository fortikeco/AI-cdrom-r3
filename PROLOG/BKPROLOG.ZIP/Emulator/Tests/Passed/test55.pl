
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- a1(X).
a1(X) :- a2(X,Y).
a2(X,Y) :- a3(X,Y,Z).
a3(X,Y,Z) :- a4(X,Y,Z,W).
a4(X,Y,Z,W) :- 	R = a(Z,W), d(Z,W), c(Z,Y), b(X), d(X,Y),
	set(2,a(Z,W)), fail.
a4(_,_,_,_) :- access(2, Z), write(Z), nl.

a(_).
b(1).
c(y(X),X).
d(X,X).
