
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* backtracking */

main :- a(X1), a(X2), a(X3), a(X4), 
	a(X5), a(X6), a(X7), a(X9),
	a(Xa), a(Xb), a(Xc), a(Xd),
	a(Y1), a(Y2), a(Y3), a(Y4), 
	fail.
main :- write(ok), nl.

a(b).
a(c(d,E)).
