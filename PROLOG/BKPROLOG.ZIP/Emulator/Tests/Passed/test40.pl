
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- functor(X, 3, 1), write(X), nl.
main :- functor(X, 3, 0), write(X), nl.
