
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* this is for testing switching */

main :- a(','(1,2),X), write(X), nl.

a(',,'(1,2), no).
a(b(1,2), no).
a(','(1,2), ok).
a('.'(1,2), no).
a(z(1,2), no).
