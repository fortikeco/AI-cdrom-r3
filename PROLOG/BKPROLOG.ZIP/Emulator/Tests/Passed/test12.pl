
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- calllist([a1,a2,a3,a4,a5]).

calllist(E) :- var(E), !.
calllist([H|T]) :- call(H), calllist(T).

a1 :- write(ok1), nl.
a2 :- write(ok2), nl.
a3 :- write(ok3), nl.
a4 :- write(ok4), nl.
a5 :- write(ok5), nl.
