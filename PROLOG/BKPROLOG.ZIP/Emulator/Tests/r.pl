
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

rewrite_args(0,_,_) :- !.
rewrite_args(N,Old,Mid) :- 
	arg(N,Old,OldArg),
	arg(N,Mid,MidArg),
	rewrite(OldArg,MidArg),
	N1 is N-1,
	rewrite_args(N1,Old,Mid).
