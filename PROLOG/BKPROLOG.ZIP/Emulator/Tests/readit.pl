
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

main :- save(readit,1), read_clause(0).
main :- halt.

read_clause(N) :-
	read(Cl),
        (Cl=(:-(Directive)) ->
                handle_directive(Directive),
		read_clause(N);
		(Cl == end_of_file -> fail; 
		    write_clause(Cl,N),
		    N1 is N + 1,
		    read_clause(N1))).

handle_directive(X) :- X.

write_clause(Cl,N) :-
	write('read_one_clause('), write(N), write(',('),
	write_canonical(Cl), write(')).'), nl.
 