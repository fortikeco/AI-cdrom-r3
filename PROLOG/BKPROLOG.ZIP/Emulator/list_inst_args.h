
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

use("Var",ARG_VAR,Var)
use("Atom",ARG_ATOM,Atom)
use("Table",ARG_TABLE,Table)
use("Int",ARG_INT,Int)
use("Const",ARG_CONST,Const)
use("Label",ARG_LABEL,Label)
use("Proc",ARG_PROC,Proc)
use("NoArg",ARG_NOARG,NoArg)
use("BuiltIn",ARG_BUILTIN,BuiltIn)
