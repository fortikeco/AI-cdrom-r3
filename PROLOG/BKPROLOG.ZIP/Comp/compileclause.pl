
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

% Compile a Clause:

compileclause(Clause, Finalcode, Link) :- 
	pretrans(Clause, Pretrans),
	Pretrans=[Head|Body], colvars(Head, HeadVars),
		permvars(Pretrans, Vars, Perms),
	unravel(Pretrans, Unravel, Perms),
	partobj(Unravel, PartObj, Perms),
		permalloc(Perms),
	valvar(PartObj, HeadVars),
			varlist(Unravel, VarList),
			lifetime(VarList, LifeList, Forward, Backward),
	varinit(Forward, Backward, PartObj, Newobj),
			tempalloc(VarList, LifeList),
	objcode(Newobj, ObjCode),
	excess(ObjCode,ObjCode2),
	envsize(ObjCode2, MaxSize),
	voidalloc(ObjCode2, VCode),
	assn_elim(VCode, ACode),
	peephole(ACode, AlmostFinalcode, [], MaxSize),
	herve_peephole(AlmostFinalcode, Finalcode, Link),
	!.
