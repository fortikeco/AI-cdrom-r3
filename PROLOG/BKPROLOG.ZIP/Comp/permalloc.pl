
/* Copyright (C) 1988, 1989 Herve' Touati, Aquarius Project, UC Berkeley */

/* Copyright Herve' Touati, Aquarius Project, UC Berkeley */

% Trivial permalloc
% Variables at end of list are numbered lowest.

permalloc(PermVars) :-
	permalloc(PermVars, _).

permalloc([y(I)|Vars], I) :-
	permalloc(Vars, I1),
	I is I1+1 .
permalloc([], 0).
