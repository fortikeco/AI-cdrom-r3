                   Welcome to PCBreeze II
                              
                   Shareware Version 2.1
                              
             Copywrite 1987-1990 KEPIC Pty Ltd
               All Rights Reserved Worldwide
                              
PCBreeze II  is an  easy to  use but  powerful PCB  (Printed
Circuit Board)  CAD tool.  This version of PCBreeze is being
distributed as  "shareware" -  it is  not in  any  way  free
software. You  may use  PCBreeze  II  for  a  limited  trial
period. If  you wish  to continue  using PCBreeze II you may
register PCBreeze and receive the latest enhanced version, a
fully printed  and bound  manual and  user support. For more
details on  registering see  the PCBreeze  II opening screen
and user  documentation. By  using PCBreeze  II you agree to
the terms  and conditions  set out  in the  software license
detailed in the PCBreeze documentation (in the expanded file
PCBREEZE.TXT).

Full instructions on the installation and use of PCBreeze II
may be  found in the compressed file PCBREEZE.KEP. To expand
the file  into a  readable form  use the  expansion  program
EXPAND.EXE. for example:

> EXPAND

will take  the compressed document file in the current drive
and directory  and will  create PCBREEZE.TXT  in the current
drive and directory. ( Note: there may not be enough room to
do this  on a  360k   5 1/4"  disk. If this is the case then
just make  a copy  of the  disk and  delete all files except
PCBREEZE.KEP and EXPAND.EXE and then expand the manual).

                             or

If you  had PCBREEZE.KEP  in the  A: drive and wanted to put
PCBreeze and it's documentation in C:\PCB :

A:> EXPAND C:\PCB
