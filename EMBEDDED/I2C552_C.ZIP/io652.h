
/*				IO652.H

   Special header for 80C652 family I/O.
   This file is supposed to be used with the in-line functions
   that are enabled with compiler command line option: -e

   For more information about the in-line functions, study
   file BIO51.C
*/


/* Pre-defined SFR byte addresses: */

#define   P0	  0x80
#define   P1	  0x90
#define   P2	  0xA0
#define   P3	  0xB0
#define   PSW	  0xD0
#define   ACC	  0xE0
#define   B	  0xF0
#define   SP	  0x81
#define   DPL	  0x82
#define   DPH	  0x83
#define   PCON	  0x87
#define   TCON	  0x88
#define   TMOD	  0x89
#define   TL0	  0x8A
#define   TL1	  0x8B
#define   TH0	  0x8C
#define   TH1	  0x8D
#define   IE	  0xA8
#define   IP	  0xB8
#define   S0CON	  0x98
#define   S0BUF	  0x99
#define	  S1CON   0xD8
#define   S1STA   0xD9
#define   S1DAT   0xDA
#define   S1ADR   0xDB

/* Pre-defined SFR bit addresses.
   The reason for the "bit" name-extension is just to
   clearly separate bit addresses from other names. */

  
/*========PSW========*/

#define   CY_bit	  0xD7
#define   AC_bit	  0xD6
#define   F0_bit	  0xD5
#define   RS1_bit	  0xD4
#define   RS0_bit	  0xD3
#define   OV_bit	  0xD2
#define   P_bit		  0xD0

/*========TCON=======*/

#define   TF1_bit	  0x8F
#define   TR1_bit	  0x8E
#define   TF0_bit	  0x8D
#define   TR0_bit	  0x8C
#define   IE1_bit	  0x8B
#define   IT1_bit	  0x8A
#define   IE0_bit	  0x89
#define   IT0_bit	  0x88

/*========IE=========*/

#define   EA_bit	  0xAF
#define   ET2_bit	  0xAD
#define   ES_bit	  0xAC
#define   ET1_bit	  0xAB
#define   EX1_bit	  0xAA
#define   ET0_bit	  0xA9
#define   EX0_bit	  0xA8

/*========IP=========*/

#define   PT2_bit	  0xBD
#define   PS_bit	  0xBC
#define   PT1_bit	  0xBB
#define   PX1_bit	  0xBA
#define   PT0_bit	  0xB9
#define   PX0_bit	  0xB8

/*========P0=========*/

#define   P0_7_bit	  0x87
#define   P0_6_bit	  0x86
#define   P0_5_bit	  0x85
#define   P0_4_bit	  0x84
#define   P0_3_bit	  0x83
#define   P0_2_bit	  0x82
#define   P0_1_bit	  0x81
#define   P0_0_bit	  0x80

/*========P1=========*/

#define   P1_7_bit	  0x97
#define   P1_6_bit	  0x96
#define   P1_5_bit	  0x95
#define   P1_4_bit	  0x94
#define   P1_3_bit	  0x93
#define   P1_2_bit	  0x92
#define   P1_1_bit	  0x91
#define   P1_0_bit	  0x90

/*========P2=========*/

#define   P2_7_bit	  0xA7
#define   P2_6_bit	  0xA6
#define   P2_5_bit	  0xA5
#define   P2_4_bit	  0xA4
#define   P2_3_bit	  0xA3
#define   P2_2_bit	  0xA2
#define   P2_1_bit	  0xA1
#define   P2_0_bit	  0xA0

/*========P3=========*/

#define   RD_bit	  0xB7
#define   WR_bit	  0xB6
#define   T1_bit	  0xB5
#define   T0_bit	  0xB4
#define   INT1_bit	  0xB3
#define   INT0_bit	  0xB2
#define   TXD_bit	  0xB1
#define   RXD_bit	  0xB0

#define   P3_7_bit	  0xB7
#define   P3_6_bit	  0xB6
#define   P3_5_bit	  0xB5
#define   P3_4_bit	  0xB4
#define   P3_3_bit	  0xB3
#define   P3_2_bit	  0xB2
#define   P3_1_bit	  0xB1
#define   P3_0_bit	  0xB0

/*========SCON========*/

#define   SM0_bit	  0x9F
#define   SM1_bit	  0x9E
#define   SM2_bit	  0x9D
#define   REN_bit	  0x9C
#define   TB8_bit	  0x9B
#define   RB8_bit	  0x9A
#define   TI_bit	  0x99
#define   RI_bit	  0x98

/*========S1CON=======*/

#define   CR0_bit         0xD8
#define   CR1_bit         0xD9
#define   AA_bit          0xDA
#define   SI_bit          0xDB
#define   STO_bit         0xDC
#define   STA_bit         0xDD
#define   ENS1_bit        0xDE
                                                 