#include <stdio.h>
#include <string.h>
#include <io652.h>

typedef unsigned char		byte;
typedef unsigned int		word;
typedef unsigned long int	lword;

#define I2C_STATUS	0x1B
#define NUMBYTXMIT	0x1C
#define NUMBYTRECV	0x1D
#define SLA		0x1F
#define BACKUPW		0x5F
#define MTD		0x60
#define MTD_1		0x61
#define RTD		0x70
#define	I2C_BUSY	0x2C
#define	I2C_ERROR	0x2D
#define	MAX_STRING_SIZE	0x100
#define WAIT_FLAG	0x10

/* declarations for pcf8577 chips       */

#define	PCF8577		0x74	/* primary address for pcf8577          */
#define	PCF8577A	0x76	/* primary address for pcf 8577a        */

/* declarations for pcf8591 chips       */

#define	PCF8591_CONT	0x44	/*                                      */

/* declarations for tda8444 chips       */

#define	DAC_AUTO_FILL	0x00	/*                                      */

/* declarations for tda8432 chips       */

#define	VERT_CHIP	0x8C	/*                                      */
#define	H_FREQ_REG	0x00	/*                                      */
#define	H_PHASE_REG	0x01	/*                                      */
#define	VERT_SIZE_REG	0x02	/*                                      */
#define	VERT_LIN_REG	0x03	/*                                      */
#define	VERT_S_C_REG	0x04	/*                                      */
#define	VERT_SHIFT_REG	0x05	/*                                      */
#define	VERT_COMP_REG	0x06	/*                                      */
#define	V_PICT_WID_REG	0x07	/*                                      */
#define	E_W_PARAB_REG	0x08	/*                                      */
#define	E_W_CORNER_REG	0x09	/*                                      */
#define	TRAPEZIUM_REG	0x0A	/*                                      */
#define	HORZ_COMP_REG	0x0B	/*                                      */
#define	VERT_CONT_REG	0x0F	/*                                      */

/* declarations for pcf8583 chips       */

#define	CPU_CLOCK_RAM	0xA0	/*                                      */
#define	TIME_CONTROL	0x00	/*                                      */
#define	SECOND_REG	0x02	/*                                      */
#define	MINUTES		0x03	/*                                      */
#define	HOURS		0x04	/*                                      */
#define	DAYS		0x06	/*                                      */

typedef struct
{
	byte second;
	byte minute;
	byte hour;
	byte day;
	byte month;
	byte year;
	byte dow;
	word btime;
} time;

/*******************************************************************************
*
*	routine	-	delay
*
*******************************************************************************/

void delay(word ticks)
{
	extern void load_delay(word);

	load_delay(ticks);
	while(read_bit(WAIT_FLAG))
		;
}

/*******************************************************************************
*
*	routine	-	make_btime
*
*******************************************************************************/

lword make_btime(byte hr, byte min, byte sec)
{
	extern byte bcd_to_byte(byte);
	lword result;
	
	result = 0l;
	result = bcd_to_byte(hr) * 3600;
	result += (bcd_to_byte(min) * 60);
	result += bcd_to_byte(sec);
	return(result);
}

/*******************************************************************************
*
*	section -	i2c bus interface input / output routines.
*
********************************************************************************
*
*	routine	-	xmit_i2c
*
*******************************************************************************/

void xmit_i2c(byte address)
{
	extern void i2c_xmit(byte);
	
	i2c_xmit(address);
	if(read_bit(I2C_ERROR))
		printf("ERROR %02x AT %02x\r\n", input(I2C_STATUS), input(SLA));
}

/*******************************************************************************
*
*	routine	-	recv_i2c
*
*******************************************************************************/

void recv_i2c(byte address)
{
	extern void i2c_recv(byte);

	i2c_recv(address);
	if(read_bit(I2C_ERROR))
		printf("ERROR %02x AT %02x\r\n", input(I2C_STATUS), input(SLA));
}

/*******************************************************************************
*
*	routine	-	write_pcf8574
*
*******************************************************************************/

void write_pcf8574(byte address, byte data)
{
	output(MTD, data);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, 0);
	xmit_i2c(address);
}

/*******************************************************************************
*
*	routine	-	read_pcf8574
*
*******************************************************************************/

byte read_pcf8574(byte address)
{
	byte data;

	output(NUMBYTRECV, 1);
	recv_i2c(address);
	data = input(RTD);
	return(data);
}

/*******************************************************************************
*
*	routine	-	write_pcf8582
*
*******************************************************************************/

void write_pcf8582(byte address, byte mem_addr, byte data)
{
	extern void put_sfr(byte, byte);

	output(MTD ,mem_addr);
	put_sfr(MTD + 1, data);
	output(NUMBYTXMIT, 2);
	output(NUMBYTRECV, 0);
	xmit_i2c(address);
}

/*******************************************************************************
*
*	routine	-	puts_pcf8582
*
*******************************************************************************/

void puts_pcf8582(byte address, byte mem_addr, char data[])
{
	extern void delay(word);
	byte count;

	for(count = 0; data[count] != '\0'; count++)
	{
		write_pcf8582(address, mem_addr + count, data[count]);
		delay(2);
	}
	write_pcf8582(address, mem_addr + count, '\0');
}

/*******************************************************************************
*
*	routine	-	putw_pcf8582
*
*******************************************************************************/

void putw_pcf8582(byte address, byte mem_addr, word data)
{
	extern void delay(word);

	write_pcf8582(address, mem_addr + 1, data & 0xFF);
	delay(2);
	write_pcf8582(address, mem_addr, data / 256);
	delay(2);
}

/*******************************************************************************
*
*	routine	-	putl_pcf8582
*
*******************************************************************************/

void putl_pcf8582(byte address, byte mem_addr, lword data)
{
	word value;

	value = data % 0x10000L;
	putw_pcf8582(address, mem_addr + 2, value);
	value = data / 0x10000L;
	putw_pcf8582(address, mem_addr, value);
}

/*******************************************************************************
*
*	routine	-	read_pcf8582
*
*******************************************************************************/

byte read_pcf8582(byte address, byte mem_addr)
{
	output(MTD, mem_addr);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, 1);
	xmit_i2c(address);
	return(input(RTD));
}

/*******************************************************************************
*
*	routine	-	getw_pcf8582
*
*******************************************************************************/

word getw_pcf8582(byte address, byte mem_addr)
{
	word temp;

	output(MTD, mem_addr);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, 2);
	xmit_i2c(address);
	temp = (input(RTD) * 256) + input(RTD + 1);
	return(temp);
}

/*******************************************************************************
*
*	routine	-	getl_pcf8582
*
*******************************************************************************/

lword getl_pcf8582(byte address, byte mem_addr)
{
	extern byte get_sfr(byte);
	lword temp;
	int count;

	temp = 0L;
	output(MTD, mem_addr);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, 4);
	xmit_i2c(address);
	for(count = 0; count < 4; count++)
	{
		temp = (temp * 256L) + get_sfr(RTD + count);
	}
	return(temp);
}

/*******************************************************************************
*
*	routine	-	gets_pcf8582
*
*******************************************************************************/

char *gets_pcf8582(byte address, byte mem_addr, byte no_bytes)
{
	extern byte get_sfr(byte);
	static char string[MAX_STRING_SIZE];
	byte count;

	output(MTD, mem_addr);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, no_bytes);
	xmit_i2c(address);
	if(! read_bit(I2C_ERROR))
	{
		for(count = 0; count < no_bytes; count++)
		{
			string[count] = get_sfr(RTD + count);
		}
		string[count] = '\0';
		return(&string[0]);
	}
	else
	{
		return(NULL);
	}
}

/*******************************************************************************
*
*	routine	-	write_pcf8583
*
*******************************************************************************/

void write_pcf8583(byte address, byte mem_addr, byte data)
{
	extern void put_sfr(byte, byte);

	output(MTD ,mem_addr);
	put_sfr(MTD + 1, data);
	output(NUMBYTXMIT, 2);
	output(NUMBYTRECV, 0);
	xmit_i2c(address);
}

/*******************************************************************************
*
*	routine	-	puts_pcf8583
*
*******************************************************************************/

void puts_pcf8583(byte address, byte mem_addr, char data[])
{
	byte count;
	for(count = 0; data[count] != '\0'; count++)
	{
		write_pcf8583(address, mem_addr + count, data[count]);
	}
	write_pcf8583(address, mem_addr + count, '\0');
}

/*******************************************************************************
*
*	routine	-	read_pcf8583
*
*******************************************************************************/

byte read_pcf8583(byte address, byte mem_addr)
{
	output(MTD, mem_addr);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, 1);
	xmit_i2c(address);
	return(input(RTD));
}

/*******************************************************************************
*
*	routine	-	gets_pcf8583
*
*******************************************************************************/

char *gets_pcf8583(byte address, byte mem_addr, byte no_bytes)
{
	extern byte get_sfr(byte);
	static char string[MAX_STRING_SIZE];
	byte count;

	output(MTD, mem_addr);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, no_bytes);
	xmit_i2c(address);
	if(! read_bit(I2C_ERROR))
	{
		for(count = 0; count < no_bytes; count++)
		{
			string[count] = get_sfr(RTD + count);
		}
		string[count] = '\0';
		return(&string[0]);
	}
	else
	{
		return(NULL);
	}
}

/*******************************************************************************
*
*	routine	-	gett_pcf8583
*
*******************************************************************************/

time *gett_pcf8583()
{
	extern byte get_sfr(byte);
	static time present;

	output(MTD, SECOND_REG);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, 5);
	xmit_i2c(CPU_CLOCK_RAM);
	if(! read_bit(I2C_ERROR))
	{
		present.second = get_sfr(RTD);
		present.minute = get_sfr(RTD + 1);
		present.hour   = get_sfr(RTD + 2) & 0x3f;
		present.day    = get_sfr(RTD + 3) & 0x3f;
		present.dow    = (get_sfr(RTD + 4) & 0xe0) >> 5;
		present.btime  = make_btime(present.hour, present.minute, present.second);
	}
	return(&present);
}

/*******************************************************************************
*
*	routine	-	write_pcf8577
*
*******************************************************************************/

void write_pcf8577(byte address, byte data)
{
	extern void put_sfr(byte, byte);

	output(MTD, address);
	put_sfr(MTD + 1, data);
	output(NUMBYTXMIT, 2);
	output(NUMBYTRECV, 0);
	xmit_i2c(PCF8577);
}

/*******************************************************************************
*
*	routine	-	write_pcf8577A
*
*******************************************************************************/

void write_pcf8577A(byte address, byte data)
{
	extern void put_sfr(byte, byte);

	output(MTD, address);
	put_sfr(MTD + 1, data);
	output(NUMBYTXMIT, 2);
	output(NUMBYTRECV, 0);
	xmit_i2c(PCF8577A);
}

/*******************************************************************************
*
*	routine	-	write_tda8444
*
*******************************************************************************/

void write_tda8444(byte address, byte dac_number, byte data)
{
	extern void put_sfr(byte, byte);

	output(MTD, dac_number);
	put_sfr(MTD + 1, data);
	output(NUMBYTXMIT, 2);
	output(NUMBYTRECV, 0);
	xmit_i2c(address);
}

/*******************************************************************************
*
*	routine	-	write_tda8432
*
*******************************************************************************/

void write_tda8432(byte address, byte port, byte data)
{
	extern void put_sfr(byte, byte);

	output(MTD, port);
	put_sfr(MTD + 1, data);
	output(NUMBYTXMIT, 2);
	output(NUMBYTRECV, 0);
	xmit_i2c(address);
}

/*******************************************************************************
*
*	routine	-	fill_tda8444
*
*******************************************************************************/

void fill_tda8444(byte address, byte data[])
{
	extern void put_sfr(byte, byte);
	int i;

	output(MTD, 0);
	for(i = 1; i < 9; i++)
	{
		put_sfr(MTD + i, data[i]);
	}
	output(NUMBYTXMIT, 9);
	output(NUMBYTRECV, 0);
	xmit_i2c(address);
}

/*******************************************************************************
*
*	routine	-	write_pcf8591
*
*******************************************************************************/

void write_pcf8591(byte address, byte data)
{
	extern void put_sfr(byte, byte);

	output(MTD, PCF8591_CONT);
	put_sfr(MTD + 1, data);
	output(NUMBYTXMIT, 2);
	output(NUMBYTRECV, 0);
	xmit_i2c(address);
}

/*******************************************************************************
*
*	routine	-	read_pcf8591
*
*******************************************************************************/

byte *read_pcf8591(byte address)
{
	extern byte get_sfr(byte);
	byte i;
	static byte adc_values[4];

	output(MTD, PCF8591_CONT);
	output(NUMBYTXMIT, 1);
	output(NUMBYTRECV, 5);
	xmit_i2c(address);
	for(i = 0; i < 4; i++)
	{
		adc_values[i] = get_sfr(RTD + i + 1);
	}
	return(&adc_values[0]);
}
                                                                                 