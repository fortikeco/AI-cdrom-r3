/* M16EXT:C */

/*
 * (C) Copyright 1991
 * All Rights Reserved
 *
 * Alan R. Baldwin
 * 721 Berkeley St.
 * Kent, Ohio  44240
 */

#include <stdio.h>
#include <setjmp.h>
#include "asm.h"

char	*cpu	= "Motorola 68HC16";
char	*dsft	= "ASM";
int	hilo	= 1;
