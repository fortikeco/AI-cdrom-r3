/***********************
    Program: 68705R3 simulator
    File: sim_r3 - main program / user interface.
    Notes: This program is written in 'plain vanilla' C and should easily
	port to any computer that has rudimentary control of its cursor
	position.  Using defines in SIM.H, it has been successfully run
	on IBM-PC compiled with Microsoft C 5.0, and on an Atari 520ST
	compiled with Mark Williams C 3.0.  The 520ST emulates a DEC VT52
	for cursor control.  It should be easy to adapt this code to drive
	other terminals/emulations, ie, VT100, ADM-3, etc.
    Changes:
	1.21 - 8 July 1989 - Added clear of external interrupt latch to
		sim_reset() in instr.c - This is to agree with 68705 reset.
		The only symptom of this in rev 1.2 would be if someone
		issues 'I' (interrupt) and then 'X' (reset) without
		servicing the interrupt, the interrupt would persist. 

***********************/
#include <stdio.h>

#define SIMR3_C
#include "sim.h"

#ifdef MSC
#include <graph.h>
#include <conio.h>
#include <ctype.h>
#endif

int display_enabled, log_enabled, promptline_full;
int external_intr, timer_external_input;
int disassemble = 0;
long int cycle_count;

int trace_ena = 0;
int breakaddr;

FILE *logfile;

unsigned int sym_nmbr[ 4095];
char sym_tbl[ 1023];

int sim_halt()
/* called from here and from instr.c on invalid op code */
{
    trace_ena = 0;
    settextposition( 1, 65);
    printf( "Halted ");
    fflush(stdout);
}

main()
{
    int exitflag = 0;
    char cmdbuff[100];
    char rspbuff[100];

    display_enabled = 1;
    log_enabled = 1;
    logfile = fopen( "SIM_R3.LOG", "w");
    promptline_full = 0;
    external_intr = 0;       /* latched /INT ; 0 = no INT latched */
    timer_external_input = 0;

    clearscreen();
    settextposition(1, 1);
    printf( "68705R3 Simulator V1.21  8-July-1989\n" );
    printf(
"R - disp/chg regs	L file - load Sx & reset	E - toggle TIE  G - Go\n");
    printf(
"T - trace on/off	B addr - Break at address (go)  I - /INT      S - Step\n");
    printf(
"X - Reset      M addr - Mem view/mod   Z - Disassem     H - Halt      Q - Quit\n");

/* use command line for symbol table feature */
    printf(
"                                                        Y - load symbol table\n");

    settextposition( PROMPTLINE+1, 1);
    printf(
"______________________________________________________________________________"
    );

    settextposition( 1, 50);
    printf("Disp+log ON ");
    sim_halt();
    clearline(PROMPTLINE);
    settextposition( PROMPTLINE, 1);


    /* here is the main loop */
    while (!exitflag)
    {
	/* Check for keyboard input */
	if (kbhit())
	{
	    char cmdchar;
	    char tempchar;

	    clearline(PROMPTLINE);
	    settextposition( PROMPTLINE, 1);
	    fgets( cmdbuff, 80, stdin);
	    cmdchar = tolower( cmdbuff[0]);
	    if (cmdchar == 'r')
	    {
		sprintf( rspbuff,
		"PC= %03x, A= %02x, X= %02x, SP= %03x, CCR=%02x (",
		    pgm_model.pc, pgm_model.a, pgm_model.x, pgm_model.sp,
		    pgm_model.ccr);
		if (pgm_model.ccr & CC_H)
		    strcat( rspbuff, "H");
		if (pgm_model.ccr & CC_I)
		    strcat( rspbuff, "I");
		if (pgm_model.ccr & CC_N)
		    strcat( rspbuff, "N");
		if (pgm_model.ccr & CC_Z)
		    strcat( rspbuff, "Z");
		if (pgm_model.ccr & CC_C)
		    strcat( rspbuff, "C");
		strcat( rspbuff, ")  Change?(reg) ");
		showprompt( rspbuff);
		fgets( cmdbuff, 80, stdin);
		tempchar = tolower( cmdbuff[0]);
		if (tempchar == 'p')
		{
		    showprompt("Enter new PC: ");
		    fgets( cmdbuff, 80, stdin);
		    sscanf( cmdbuff, "%x", &pgm_model.pc);
		}
		if (tempchar == 's')
		{
		    showprompt("Enter new SP: ");
		    fgets( cmdbuff, 80, stdin);
		    sscanf( cmdbuff, "%x", &pgm_model.sp);
		}
		if (tempchar == 'a')
		{
		    showprompt("Enter new A: ");
		    fgets( cmdbuff, 80, stdin);
		    sscanf( cmdbuff, "%x", &pgm_model.a);
		}
		if (tempchar == 'x')
		{
		    showprompt("Enter new X: ");
		    fgets( cmdbuff, 80, stdin);
		    sscanf( cmdbuff, "%x", &pgm_model.x);
		}
		if (tempchar == 'c')
		{
		    showprompt("Enter new CCR (in hex): ");
		    fgets( cmdbuff, 80, stdin);
		    sscanf( cmdbuff, "%x", &pgm_model.ccr);
		}
		clearline( PROMPTLINE);
	    }
	    if (cmdchar == 'l')
		load( &cmdbuff[1]); /* skip command char */

/* Symbol table load here */
	    if (cmdchar == 'y')
		load_sym( &cmdbuff[1]); /* skip command char */

	    if (cmdchar == 'e')
	    {
		timer_external_input = (timer_external_input)? 0 : 1;
		sprintf(rspbuff, "Timer ext input is now %1d",
		                            timer_external_input);
		showprompt( rspbuff);
	    }
	    if (cmdchar == 't')
	    {
		display_enabled = (display_enabled) ? 0 : 1;
		if (display_enabled)
		{
		    showprompt("Enable logfile also? (Y/N): ");
		    fgets( cmdbuff, 80, stdin);
		    settextposition( 1, 50);
		    if (cmdbuff[0] != 'n' && cmdbuff[0] != 'N')
		    {
			printf("Disp+log ON ");
			log_enabled = 1;
		    }
		    else
		    {
			printf("Display ON  ");
			log_enabled = 0;
		    }
		}
		else
		{
		    settextposition( 1, 50);
		    printf("Disp+log OFF");
		}
	    }
	    if (cmdchar == 'b' || cmdchar == 'g' || cmdchar == 's')
	    {
		if (cmdchar == 'b')
		    sscanf( &cmdbuff[1], "%x", &breakaddr);
		if (cmdchar != 's')
		    trace_ena = 1;
		else
		    trace_ena = 2; /* step */
		settextposition( 1, 65);
		printf( "RUNNING");
	    }
	    if (cmdchar == 'i')
	    {
	    	external_intr = 1;
		showprompt("External interrupt latched");
	    }
	    if (cmdchar == 'x')
		sim_reset();
	    if (cmdchar == 'm')
	    {
		int addr, data, endm, numcvts;

		addr = 0x10;  /* Default */
		sscanf( &cmdbuff[1], "%x", &addr);

		endm = 0;
		while (!endm)
		{
		    if (addr > 4095 || addr < 0)
			addr = 0x10; /* Wrap to RAM = default */
		    data = sim_read( addr);
		    sprintf( rspbuff, "%03x %02x      ", addr, data);
		    showprompt(rspbuff);
		    settextposition( PROMPTLINE, 8); 
		    cmdbuff[0] = '\n';
		    fgets( cmdbuff, 80, stdin);
		    if (cmdbuff[0] != '\n')
		    {
			numcvts = sscanf( cmdbuff, "%x", &data);
			if (numcvts == 1)
			    sim_writef( addr, data);
			else
			    endm = 1;
		    }
		    addr++;
		}
		clearline( PROMPTLINE);
	    }
	    if (cmdchar == 'h')
	    {
	        sim_halt();
	    }
	    if (cmdchar == 'q')
		exitflag = 1;
	    if (cmdchar == 'z')
	    {
		struct program_model saveregs;
		int ic, addr, savelogena, savedispena;

		saveregs = pgm_model;
		disassemble = 1;
		savelogena = log_enabled;
		savedispena = display_enabled;
		log_enabled = 0;
		display_enabled = 1;

		delete_line( PROMPTLINE+2);
		settextposition( 49,1);
		printf(" *** Disassembly follows ****");

		if (cmdbuff[1] != '\n')
		{
		    ic = sscanf(&cmdbuff[1], "%x", &addr);
		    if (ic == 1)
			pgm_model.pc = addr;
		}

		for (ic = 0; ic < 40; ic++)
		{
		    sim_instr();
		}
		delete_line( PROMPTLINE+2);
		settextposition( 49,1);
		printf (" *** End disassembly ****");

		disassemble = 0;
		pgm_model = saveregs;
		log_enabled =  savelogena;
		display_enabled = savedispena;
	    }
	    if (cmdchar == '\n')
	    {
		settextposition( PROMPTLINE+1, 1);
		printf(
"______________________________________________________________________________"
		);
	    };
	    settextposition(PROMPTLINE, 1);
	} /* end if kbhit */

	if (trace_ena)
	{
	    instr_or_intr(); /* do an instruction */
	    if (pgm_model.pc == breakaddr)
	    {
		sim_halt();
		trace_ena = 0;
		showprompt("BREAKPOINT reached");
	    }
	    if (trace_ena == 2)
	    {
		sim_halt();
		trace_ena = 0;
	    }
	}
    } /* end while !exitflag */
    sim_halt();
    fclose( logfile);
    showprompt("Logfile closed - normal exit");
    settextposition(25,1);
    exit( 0);
}


    

showprompt( buff)
char buff[];
{
    if (promptline_full)
	clearline( PROMPTLINE);
    settextposition( PROMPTLINE, 1);
    printf( buff);
    fflush(stdout);
    promptline_full = 1;
}

clearline( linenum)
int linenum;
{
    settextposition( linenum, 1);
#ifdef MSC
    printf(
"										");
    settextposition( linenum, 1);
#endif
#ifdef VT52
    settextposition( linenum, 1);
    printf( "\033K");    /* escape K - clear cursor pos through end of line */
    settextposition( linenum, 1);
#endif
    if (linenum == PROMPTLINE)
	promptline_full = 0;
}

settextposition( line, col)
int line,col;
{
#ifdef MSC
    _settextposition( line, col);       /* Microsoft C 5.0 and up */
#endif
#ifdef VT52
    printf("\033Y%c%c", 31+line, 31+col); /* escape Y row col  */
	/* row and col are 0 to max with an offset of 32 */
    fflush( stdout);
#endif
}

clearscreen()
{
#ifdef MSC
    _clearscreen( _GCLEARSCREEN );       /* Microsoft C 5.0 and up */
#endif
#ifdef VT52
    printf("\033E");  /* escape E - Clear & Home */
#endif
}

#ifdef VT52
/* Assume this is for ATARI ST, which does VT52 emulation */
/* We must supply our own version for the Microsoft C routine kbhit() */

#include <osbind.h>

int kbhit()
{
    return( Cconis() ); /* Check console input status */
}
#endif

/******************** end of file sim_r3.c ***************************/
