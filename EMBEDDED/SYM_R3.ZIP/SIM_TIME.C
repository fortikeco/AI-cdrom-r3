/************************
    Program: 68705R3 simulator
    File: sim_time.c 
	initialize and simulate timer tics
************************/
#include "sim.h"

/* #define DEBUG */   /* uncomment to see timer count on prompt line */

static int internal_count; /* counts up to prescaler value */
static int prescale;
static int tcr_copy;
static int previous_timer_ext_in;

sim_timer_init()
/* Called from sim_reset */
{
    int mor;
    
    mor = sim_readf(MASK_OPT_REG);
    internal_count = 0;
    sim_write( TIMER_DATA, 0xFF);

    tcr_copy = 0x40 | (mor & 0x37);

    if (mor & 0x40)     /* TOPT bit (bit 6 in MOR) is set */
	tcr_copy |= 0x10;   /* TIE (Timer external input enable) */

    sim_write( TIMER_CONTROL, tcr_copy );  /* Causes sim_timer_ctrl call */
}

sim_timer_ctrl()
/* Called when TCR is written to */
{
    tcr_copy = sim_readf( TIMER_CONTROL);
    if (tcr_copy & 0x08)     /* Prescaler clear */
	internal_count = 0;
    prescale = 1 << (tcr_copy & 0x07);
#ifdef DEBUG
    printf( "Prescale = %d", prescale);
#endif
}

sim_timer_update( ticks)
int ticks;
{
    int tmode, temp, td;

    tmode = tcr_copy & 0x30;  /* TIN and TIE */
    if (tmode == 0x00)
	temp = ticks;
    else if (tmode == 0x10)
    {
	if (timer_external_input)
	    temp = ticks;
	else
	    temp = 0;
    }
    else if (tmode == 0x20)
	temp = 0;
    else if (tmode == 0x30)
    {
	if (timer_external_input && !previous_timer_ext_in)
	    temp = 1;
	else
	    temp = 0;
    }
    previous_timer_ext_in = timer_external_input; /* save for next time */

    internal_count += temp;

    /* Prescale should never be 0, but test to prevent hang */
    while ((internal_count >= prescale) && (prescale != 0))
    {
	internal_count -= prescale;
	td = sim_readf( TIMER_DATA);
	td--;
	if (td == 0)
	    sim_write(TIMER_CONTROL, tcr_copy | 0x80); /* Timer Interrupt Req */
	    /* Note: sim_write causes sim_timer_ctrl to be called */
	if (td < 0)
	    td = 0xFF;
	sim_write( TIMER_DATA, td);
    }
#ifdef DEBUG
    td = sim_readf( TIMER_DATA);
    printf( "Internal count = %d, td = %d    ", internal_count, td);
#endif
}
