#include <stdio.h>
#include "sim.h"

#ifdef MSC
#include <graph.h>
#endif

unsigned char mem[ 4095];

/* arrays for symbols */
extern unsigned int  sym_nmbr[ 4095];
extern char sym_tbl[ 1023];

int sim_read( addr)
int addr;
{
   int data, done;
   char c;
   char buff[80];

    done = data = 0;
    /* Don't prompt user for values if we are disassembling */
    if (!disassemble)
    {
	if (addr >= 0 && addr < 4)
	{
	    if (mem[addr+4] != 0xFF)   /* FF in DDR = all outputs */
	    {
		c = (char) ((int)'A' + addr);
		sprintf(buff, "Enter read value for port %c: ", c);
		showprompt( buff);
		fgets( buff, 80, stdin);

		/* To prevent scrolling unecessarily  through memory */

		if ( 0 == sscanf( buff, "%d", &data))
		{
		  sim_halt();
		  goto readend;
		}
	    }
	    data = data & (~mem[addr+4]) | mem[addr] & mem[addr+4];
	    clearline( PROMPTLINE);
	    done = 1;
	}
	else if (addr == AD_REG)
	{
	    showprompt( "Enter read value for ADC register: ");
	    fgets( buff, 80, stdin);
	    sscanf( buff, "%d", &data);
	    clearline( PROMPTLINE);
	    done = 1;
	}
    }
    if (done) goto readend;
    if (addr >= 4 && addr < 8)
	data = 0xFF;    /* port data direction regs are write only */
    else if ((addr == TIMER_CONTROL) && (mem[MASK_OPT_REG] & 0x40))
	data = (mem[addr] & 0xF7) | 0x37;
    else if (addr >= 0 && addr <= 4095)
	data = mem[addr];
    else if (addr == RW_A)
	data = pgm_model.a;
    else if (addr == RW_X)
	data = pgm_model.x;
    else if (addr == RW_SP)
	data = pgm_model.sp;
readend:
    return(data);
}

int sim_write( addr, data)
int addr, data;
{
    if (!disassemble)
    {
	if (addr >= 0 && addr <= 0x7F)  /* permit write to RAM, ports only */
	    mem[addr] = data;
	else if (addr == RW_A)
	    pgm_model.a = data;
	else if (addr == RW_X)
	    pgm_model.x = data;
	else if (addr == RW_SP)
	    pgm_model.sp = data;
	if (addr == TIMER_CONTROL)
	    sim_timer_ctrl();
    }
}

int sim_writef( addr, data)
int addr, data;
/* write forced - Just like sim_write but can write to PROM */
/* Called from non-simulation things like 'M' (mem mod) and 'L' (load sx) */
{
    if (addr <= 0x7F)
	sim_write( addr, data);   /* handle special cases, all in RAM, I/O */
    else
    {
        mem[addr] = data;     /* Always succeeds - can write to PROM */
    }
}

int sim_readf( addr)
int addr;
/* read forced - simply returns mem[addr] - no prompts, no nothing */
/* Used by sim_timer to read TCR as if it were the timer - the user */
/* program cannot read most bits of the TCR in MOR controlled mode */
{
    return( mem[addr] );
}

int sim_bitread( addr, bit)
int addr, bit;
/* If bit is an output bit in a port, no need to ask user for value */
/* in that case don't call sim_read, or it would ask */
/* NOTE: returns byte value just like sim_read, not just one bit */
/*    The bit argument is only used to check for out bit in port */
/*    This is so the trace can show the value of the byte, which */
/*    the processor really reads */
{
    int data;

    if (( addr >= 0 && addr < 4) && (mem[addr+4] & (1<<bit)) )
	data = mem[addr];
    else
        data = sim_read( addr);
    return( data);
}

/*********************************************************************/
int load_moto_hex( infile)
FILE *infile;
/* opens infile and reads S0, S1 and S9 records.  S0 records are ignored.
   S9 records terminate input.  Checksums on all records are ignored.
*/
{
    int i, j, addr, data, state, count, error, cc, s9;

    state = 0;
    s9 = 0;

    while ( (i = fgetc( infile)) != EOF && !s9)
    {
	j = (i >= 'A') ? i - 55 : i - '0'; /* if i is hex digit, j is value*/
	switch( state)
	{
	case 0:       /* Look for 'S' = beginning of record */
	    if (i == 'S')
	    {
#ifdef DEBUG
    printf( "Found 'S'-");
#endif
		state = 1;
		count = 0;
		cc = 0;
		addr = 0;
	    }
	    break;
	case 1:       /* Get character after 'S' = record type */
	    if (i == '1')
		state = 2;
	    else if (i == '9')
		s9 = 1;       /* exit input loop */
	    else
		state = 0;  /* Skip S0 records - look for next 'S' */
	    break;
	case 2:      /* Get byte count for this record */
#ifdef DEBUG
    printf( "Count-");
#endif
	    count <<= 4;
	    count += j;
	    cc++;
	    if (cc == 2)
	    {
#ifdef DEBUG
    printf( "  Count = %d\n", count);
#endif
		state = 3;
		addr = 0;
		cc = 0;
	    }
	    break;
	case 3:     /* Get start address for this record */
#ifdef DEBUG
    printf( "Addr-");
#endif
	    addr <<= 4;
	    addr += j;
	    cc++;
	    if (cc == 4)
	    {
		state = 4;
		data = 0;
		cc = 0;
#ifdef DEBUG
    printf( "  Addr = %d\n", addr);
#endif
		count -= 2;
		if (count == 1)
		    state = 0;     /* Skip checksum, look for 'S' */
	    }
	    break;
	case 4:     /* Get data bytes, 2 chars each */
#ifdef DEBUG
    printf( "Data-");
#endif
	    data <<= 4;
	    data += j;
	    cc++;
	    if (cc == 2)
	    {
		sim_writef( addr, data);
#ifdef DEBUG
    printf( "Wrote %d to %d\n", data, addr);
#endif
		addr++;
		data = 0;
		cc = 0;
		count--;
		if (count == 1)
		    state = 0;  /* Skip checksum, look for 'S' */
	    }
	    break;
	}  /* end switch */
    } /* end while */
    return( !s9);       /* Error is didn't end with S9 record */
} /* end load_moto_hex */



int sym_writef_init()
{

  int i;

  for( i=0; i<4096; i++)
  {
    sym_nmbr[ i] = i;
  }

}

int sym_writef( sym_val, i)
int sym_val,i;
{
    sym_nmbr[ i] = sym_val + 4096;
}

int load_sym_data( infile)
FILE *infile;
{
    int i, s9;

    char n[5];
    static char *sym_tbl_ptr;

    s9 = 0;

    while( fgetc(infile) != '\f');

    sym_tbl_ptr = sym_tbl;

    while( fscanf( infile, "%s %5x", n, &i) != EOF)
    {
      sym_writef( sym_tbl_ptr - sym_tbl, i);
      sym_tbl_ptr = sym_tbl_ptr + sprintf( sym_tbl_ptr, "%s", n) + 1;

    }

    return(!s9);

} /* end load_sym_data */

int load_sym( filename)
char filename[];
/* returns 0 if no error, 1 if error */
{

    FILE *infile;
    int retval;
    char fname[64];
    char *cP;
    int i;
    char n[5];


    sym_writef_init();

    i = 0;
    cP = fname;
    while (filename[i] != '\n' && i < 64)
    {
	if (filename[i] != ' ' && filename[i] != '\x09')  /* skip white */
	    *cP++ = filename[i];
	i++;
    }
    *cP++ = '\0';   /* Null terminate string */

    infile = fopen( fname, "r");
    if (infile != NULL)
	retval = load_sym_data( infile);
    else
	retval = 2;

    settextposition( PROMPTLINE,1);

    if (retval)
    {
       if (retval == 2)
	   printf  ("*** CANNOT OPEN FILE %s ***", fname);
       else
	   printf( "*** ERROR LOADING FILE %s ***", fname);
    }
    else
    {
       printf( "File %s loaded", fname);
    }
    promptline_full = 1;
    return( retval);

}/* end load_sym */

int load( filename)
char filename[];
/* returns 0 if no error, 1 if error */
{
    FILE *infile;
    int retval;
    char fname[64];
    char *cP;
    int i;

    i = 0;
    cP = fname;
    while (filename[i] != '\n' && i < 64)
    {
	if (filename[i] != ' ' && filename[i] != '\x09')  /* skip white */
	    *cP++ = filename[i];
	i++;
    }
    *cP++ = '\0';   /* Null terminate string */

    infile = fopen( fname, "r");
    if (infile != NULL)
	retval = load_moto_hex( infile);
    else
	retval = 2;
    settextposition( PROMPTLINE,1);
    if (retval)
    {
       if (retval == 2)
	   printf  ("*** CANNOT OPEN FILE %s ***", fname);
       else
	   printf( "*** ERROR LOADING FILE %s ***", fname);
    }
    else
    {
       printf( "File %s loaded", fname);
       sim_reset();
    }
    promptline_full = 1;
    return( retval);
}/* end load */


