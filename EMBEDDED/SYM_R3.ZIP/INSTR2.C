/******
	Program: 68705R3 simulator
	File: INSTR2.C
	Notes: This file contiains the code for individual 6805 instructions.
		It uses routines in INSTR.C
******/

#include "sim.h"

#ifdef MSC
#include <graph.h>
#endif

#define RW_A -1
#define RW_X -2
#define RW_SP -3

/************************************************************************/
/* Routines to set condition code register bits for numeric op result   */

int ccr_c( value)
int value;
{
    if (value < 0)
    {
	value += 256;
	pgm_model.ccr |= CC_C;
    }
    else if (value > 255)
    {
	value -= 256;
	pgm_model.ccr |= CC_C;
    }
    else
	pgm_model.ccr &= ~CC_C;
    return( value);
}

int ccr_z( value)
int value;
{
    if (value == 0)
	pgm_model.ccr |= CC_Z;
    else
	pgm_model.ccr &= ~CC_Z;
    return( value);
}

int ccr_n( value)
int value;
{
    if (value & 0x80)
	pgm_model.ccr |= CC_N;
    else
	pgm_model.ccr &= ~CC_N;
    return( value);
}
/************************************************************************/
int std_ccr(value)
int value;
/* Set C, Z and N bits in ccr based on value */
/* This is appropriate for SUB, CMP, SBC, CPX etc numeric instructions */
{
    value = ccr_c( value);
    value = ccr_z( value);
    value = ccr_n( value);
}
/************************************************************************/

sub( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    pgm_model.a -= data;
    pgm_model.a = std_ccr( pgm_model.a);
    append_rw( 0, RW_A, pgm_model.a);
}

cmp( mode)
int mode;
{
    int addr, data, result;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    result = pgm_model.a - data;
    result = std_ccr( result);
}

sbc( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    pgm_model.a -= data;
    if (pgm_model.ccr & CC_C)
	pgm_model.a--;
    pgm_model.a = std_ccr( pgm_model.a);
    append_rw( 0, RW_A, pgm_model.a);
}

cpx( mode)
int mode;
{
    int addr, data, result;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    result = pgm_model.x - data;
    result = std_ccr( result);
}

and( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    pgm_model.a &= data;
    pgm_model.a = ccr_n( pgm_model.a);
    pgm_model.a = ccr_z( pgm_model.a);
    append_rw( 0, RW_A, pgm_model.a);
}

bit( mode)
int mode;
{
    int addr, data, result;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    result = pgm_model.a & data;
    result = ccr_n( result);
    result = ccr_z( result);
}

lda( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    pgm_model.a = data;
    pgm_model.a = ccr_n( pgm_model.a);
    pgm_model.a = ccr_z( pgm_model.a);
    append_rw( 0, RW_A, pgm_model.a);
}

sta( mode)
int mode;
/* Note: mode is never IMMEDIATE */
{
    int addr, data, temp;

    addr = get_ea( mode);
    sim_write( addr, pgm_model.a);
    append_rw( 0, addr, pgm_model.a);   /* 1 = Read, 0 = Write */
    temp = ccr_n( pgm_model.a);
    temp = ccr_z( pgm_model.a);
}

eor( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    pgm_model.a ^= data;
    pgm_model.a = ccr_n( pgm_model.a);
    pgm_model.a = ccr_z( pgm_model.a);
    append_rw( 0, RW_A, pgm_model.a);
}

adc( mode)
int mode;
{
    int addr, data, result;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    result = pgm_model.a + data;
    if (pgm_model.ccr & CC_C)
	result++;
    if (  ((pgm_model.a & 0x08) & (data & 0x08)) ||
          ((data & 0x08) & (~result & 0x08)) ||
          ((pgm_model.a & 0x08) & (~result & 0x08)) )
	pgm_model.ccr |= CC_H;
    else
	pgm_model.ccr &= ~CC_H;
    pgm_model.a = std_ccr( result);
    append_rw( 0, RW_A, pgm_model.a);
}

ora( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    pgm_model.a |= data;
    pgm_model.a = ccr_n( pgm_model.a);
    pgm_model.a = ccr_z( pgm_model.a);
    append_rw( 0, RW_A, pgm_model.a);
}

add( mode)
int mode;
{
    int addr, data, result;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    result = pgm_model.a + data;
    if (  ((pgm_model.a & 0x08) & (data & 0x08)) ||
          ((data & 0x08) & (~result & 0x08)) ||
          ((pgm_model.a & 0x08) & (~result & 0x08)) )
	pgm_model.ccr |= CC_H;
    else
	pgm_model.ccr &= ~CC_H;
    pgm_model.a = std_ccr( result);
    append_rw( 0, RW_A, pgm_model.a);
}

jmp( mode)
int mode;
{
    if (!disassemble)
	pgm_model.pc = get_ea( mode);
    /* condition codes are not affected */
/*  symbol table addition */
    append_rw( 1, pgm_model.pc, 0);
}

jsr( mode)
int mode;
{
    int addr;

    addr = get_ea( mode);
    if (!disassemble)
    {
	push( pgm_model.pc & 0xFF);    /* PCL */
	push(((pgm_model.pc & 0xF00) >> 8) | 0xF000);      /* PCH */
	pgm_model.pc = addr;
/*  symbol table addition */
    append_rw( 1, pgm_model.pc, 0);

    }
}

bsr( mode)
int mode;  /* Must be REL */
{
    jsr( mode);    /* identical to JSR except for address mode, */
                   /* which is handled by get_ea() */
}

ldx( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    pgm_model.x = data;
    data = ccr_n( data);
    data = ccr_z( data);
/* patch for x_reg */
    append_rw( 0, RW_X, pgm_model.x);

}

stx( mode)
{
    int addr, data;

    addr = get_ea( mode);
    sim_write( addr, pgm_model.x);
    append_rw( 0, addr, pgm_model.x);   /* 1 = Read, 0 = Write */
    data = pgm_model.x;
    data = ccr_n( data);
    data = ccr_z( data);
}

bset( bit)
int bit;
{
    int addr, data;

    addr = get_ea( DIRECT);
    data = sim_bitread( addr, bit);  /* Returns byte value just like simread */
                                     /* Bit is used to check bit in ports */
				     /* See sim_mem.c */
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    data |= 1<<bit;
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

bclr( bit)
int bit;
{
    int addr, data;

    addr = get_ea( DIRECT);
    data = sim_bitread( addr, bit);   /* See note above */
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    data &= ~(1<<bit);
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

brset( bit)
int bit;
{
    int addr, data;

    addr = get_ea( DIRECT);
    data = sim_bitread( addr, bit);  /* Returns byte value just like simread */
                                     /* Bit is used to check bit in ports */
				     /* See sim_mem.c */
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    addr = get_ea( BTB);   /* Bit Test & Branch - branch rel */
    if (data & (1 << bit))
    {
	if (!disassemble)
	    pgm_model.pc = addr;
	pgm_model.ccr |= CC_C;
    }
    else
	pgm_model.ccr &= ~CC_C;
}

brclr( bit)
int bit;
{
    int addr, data;

    addr = get_ea( DIRECT);
    data = sim_bitread( addr, bit);       /* See note above */
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    addr = get_ea( BTB);   /* Bit Test & Branch - branch rel */
    if (data & (1 << bit))
	pgm_model.ccr |= CC_C;
    else
    {
	if (!disassemble)
	    pgm_model.pc = addr;
	pgm_model.ccr &= ~CC_C;
    }
}

branch( brtype)
int brtype;
{
    int addr, brflag;

    addr = get_ea( REL);
    switch (brtype)
    {
    case 0: /* BRA */
	brflag = 1;
	break;
    case 1: /* BRN */
	brflag = 0;
	break;
    case 2: /* BHI */
	brflag= ((pgm_model.ccr & CC_C) == 0) && ((pgm_model.ccr & CC_Z) == 0);
	break;
    case 3: /* BLS */
	brflag= ((pgm_model.ccr & CC_C) != 0) || ((pgm_model.ccr & CC_Z) != 0);
	break;
    case 4: /* BCC */
	brflag = ((pgm_model.ccr & CC_C) == 0);
	break;
    case 5: /* BCS */
	brflag = ((pgm_model.ccr & CC_C) != 0);
	break;
    case 6: /* BNE */
	brflag = ((pgm_model.ccr & CC_Z) == 0);
	break;
    case 7: /* BEQ */
	brflag = ((pgm_model.ccr & CC_Z) != 0);
	break;
    case 8: /* BHCC */
	brflag = ((pgm_model.ccr & CC_H) == 0);
	break;
    case 9: /* BHCS */
	brflag = ((pgm_model.ccr & CC_H) != 0);
	break;
    case 10: /* BPL */
	brflag = ((pgm_model.ccr & CC_N) == 0);
	break;
    case 11: /* BMI */
	brflag = ((pgm_model.ccr & CC_N) != 0);
	break;
    case 12: /* BMC */
	brflag = ((pgm_model.ccr & CC_I) == 0);
	break;
    case 13: /* BMS */
	brflag = ((pgm_model.ccr & CC_I) != 0);
	break;
    case 14: /* BIL */
	brflag = external_intr;
	break;
    case 15: /* BIH */
	brflag = !external_intr;
	break;
    default:
	brflag = 0;
	break;
    }
    if (brflag && !disassemble)
    {
	pgm_model.pc = addr;
/*  symbol table addition */
    append_rw( 1, pgm_model.pc, 0);
    }
}

neg( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    data = 0 - data;
    data = std_ccr( data);    /* will get value in 0-255 and set C, N, Z */
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

com( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    data ^= 0xFF;
    data = ccr_n( data);
    data = ccr_z( data);
    pgm_model.ccr |= CC_C;      /* Carry always set */
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

lsr( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    if (data & 0x01)
        pgm_model.ccr |= CC_C;
    else
	pgm_model.ccr &= ~CC_C;
    data >>= 1;
    data = ccr_n( data);     /* N will always be 0 */
    data = ccr_z( data);
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

ror( mode)
int mode;
{
    int addr, data, newdata;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
/* eliminate any "carries" from being shifted in */
    newdata = (( data >>1) & 0x01FF);
    if (pgm_model.ccr & CC_C)
	newdata |= 0x80;
    if (data & 0x01)
        pgm_model.ccr |= CC_C;
    else
	pgm_model.ccr &= ~CC_C;
    newdata = ccr_n( newdata);
    newdata = ccr_z( newdata);
    sim_write( addr, newdata);
    append_rw( 0, addr, newdata);   /* 1 = Read, 0 = Write */
}

asr( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    if (data & 0x01)
        pgm_model.ccr |= CC_C;
    else
	pgm_model.ccr &= ~CC_C;
    data >>= 1;
    if (data & 0x40)
	data |= 0x80;        /* hold bit 7 constant */
    data = ccr_n( data);
    data = ccr_z( data);
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

lsl( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    data <<= 1;
    data = std_ccr( data);       /* if b7 was on, C will be set and data */
                                 /* corrected by subtracting 256 - perfect! */ 
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

rol( mode)
int mode;
{
    int addr, data, newdata;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
/* eliminate numbers in A and X register from increasing */
    newdata = (( data <<1) & 0x01FF);
    if (pgm_model.ccr & CC_C)
	newdata |= 0x01;
    if (data & 0x80)
        pgm_model.ccr |= CC_C;
    else
	pgm_model.ccr &= ~CC_C;
    newdata = ccr_n( newdata);
    newdata = ccr_z( newdata);
    sim_write( addr, newdata);
    append_rw( 0, addr, newdata);   /* 1 = Read, 0 = Write */
}

dec( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    data -= 1;
    if (data < 0)
	data = 255;
    data = ccr_n( data);
    data = ccr_z( data);
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

inc( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    data += 1;
    if (data >= 256)
	data = 0;
    data = ccr_n( data);
    data = ccr_z( data);
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

tst( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    /* No operation on data, or, if you prefer data = data - 0 */
    data = ccr_n( data);
    data = ccr_z( data);
}

clr( mode)
int mode;
{
    int addr, data;

    addr = get_ea( mode);
    data = sim_read( addr);
    append_rw( 1, addr, data);   /* 1 = Read, 0 = Write */
    data = 0;
    data = ccr_n( data);
    data = ccr_z( data);
    sim_write( addr, data);
    append_rw( 0, addr, data);   /* 1 = Read, 0 = Write */
}

swi(mode)
int mode;
{
    rinterrupt( 0xFFC);    /* in instr.c */
}

rts(mode)
int mode;
{
    if (!disassemble)
    {
	pgm_model.pc = (( pull() & 0x0F ) << 8);
	pgm_model.pc +=  pull();
    }
}

rti(mode)
int mode;
{
    pgm_model.ccr = pull() & 0x1F;
    pgm_model.a = pull();
    pgm_model.x = pull();
    rts( mode);
}

tax( mode)
int mode;
{
    pgm_model.x = ( 0x00FF & pgm_model.a );
    append_rw( 0, RW_X, pgm_model.x);   /* 1 = Read, 0 = Write */
}

txa( mode)
int mode;
{
    pgm_model.a = ( 0x00FF & pgm_model.x );
    append_rw( 0, RW_A, pgm_model.a);   /* 1 = Read, 0 = Write */
}

clc( mode)
int mode;
{
    pgm_model.ccr &= ~CC_C;
}

sec( mode)
int mode;
{
    pgm_model.ccr |= CC_C;
}

cli( mode)
int mode;
{
    pgm_model.ccr &= ~CC_I;
}

sei( mode)
int mode;
{
    pgm_model.ccr |= CC_I;
}

nop( mode)
int mode;
{
    /* no operation */
    return( mode);
}

rsp( mode)
int mode;
{
    pgm_model.sp = 0x7F;
}

mul( mode)
int mode;
{
    int data;

    data = pgm_model.a * pgm_model.x;
    pgm_model.a = data & 0x00ff;
    pgm_model.x = (data >> 8) & 0x00ff;
    append_rw( 0, RW_A, pgm_model.a);
    append_rw( 0, RW_X, pgm_model.x);
    pgm_model.ccr &= ~CC_C;
    pgm_model.ccr &= ~CC_H;

}

stop( mode)
int mode;
{
     pgm_model.ccr &= ~CC_I;
}

wait( mode)
int mode;
{
    pgm_model.ccr &= ~CC_I;
}

/**************** end of file instr2.c **********************************/

