/********
	program: 68705R3 simulator
	file: instr.c - instruction table, instruction and interrupt
		simulation.  See instr2.c for individual instruction
		routines.
	Author: Joseph Schachner
	Notes: 
********/

#include <stdio.h>
#include "sim.h"

#ifdef MSC
#include <dos.h>
#endif

extern FILE *logfile;

extern unsigned int sym_nmbr[];
extern char sym_tbl[];

struct instruction_table_entry {
    PFI function;
    int argument;
    char *name;
    int ncycles;
};

/* The following three items are filled by routines in here and instr2
   and are printed out nicely formatted from sim_instr, below 
*/
char mne[40];
char opcode[40];
char rw[40];

/* Part of this string is used to fill between fields, as needed */
char blanks[]="                                        ";  /* 40 blanks */

char inval_str[]="Invalid op";

invalid( mode)
int mode;
{
    sim_halt();
}

extern int brset(),brclr(),bset(),bclr(),branch(),neg(),mul();
extern int com(),lsr(),ror(),asr(),lsl(),rol(),dec(),inc(),tst(),clr(),rti();
extern int rts(),swi(),stop(),wait();
extern int tax(),clc(),sec(),cli(),sei(),rsp(),nop(),txa();
extern int sub(),cmp(),sbc(),cpx(),and(),bit(),lda(),sta(),eor(),adc(),ora();
extern int add(),jmp(),bsr(),jsr(),ldx(),stx();


struct instruction_table_entry instr_tbl[] =
{
    { brset, 0, "BRSET0", 5 },
    { brclr, 0, "BRCLR0", 5 },
    { brset, 1, "BRSET1", 5 },
    { brclr, 1, "BRCLR1", 5 },
    { brset, 2, "BRSET2", 5 },
    { brclr, 2, "BRCLR2", 5 },
    { brset, 3, "BRSET3", 5 },
    { brclr, 3, "BRCLR3", 5 },
    { brset, 4, "BRSET4", 5 },
    { brclr, 4, "BRCLR4", 5 },
    { brset, 5, "BRSET5", 5 },
    { brclr, 5, "BRCLR5", 5 },
    { brset, 6, "BRSET6", 5 },
    { brclr, 6, "BRCLR6", 5 },
    { brset, 7, "BRSET7", 5 },
    { brclr, 7, "BRCLR7", 5 },
    { bset, 0, "BSET0", 5 },
    { bclr, 0, "BCLR0", 5 },
    { bset, 1, "BSET1", 5 },
    { bclr, 1, "BCLR1", 5 },
    { bset, 2, "BSET2", 5 },
    { bclr, 2, "BCLR2", 5 },
    { bset, 3, "BSET3", 5 },
    { bclr, 3, "BCLR3", 5 },
    { bset, 4, "BSET4", 5 },
    { bclr, 4, "BCLR4", 5 },
    { bset, 5, "BSET5", 5 },
    { bclr, 5, "BCLR5", 5 },
    { bset, 6, "BSET6", 5 },
    { bclr, 6, "BCLR6", 5 },
    { bset, 7, "BSET7", 5 },
    { bclr, 7, "BCLR7", 5 },
    { branch, 0, "BRA", 3 },
    { branch, 1, "BRN", 3 },
    { branch, 2, "BHI", 3 },
    { branch, 3, "BLS", 3 },
    { branch, 4, "BCC", 3 },
    { branch, 5, "BCS", 3 },
    { branch, 6, "BNE", 3 },
    { branch, 7, "BEQ", 3 },
    { branch, 8, "BHCC",3 },
    { branch, 9, "BHCS",3 },
    { branch, 10, "BPL",3 },
    { branch, 11, "BMI",3 },
    { branch, 12, "BMC",3 },
    { branch, 13, "BMS",3 },
    { branch, 14, "BIL",3 },
    { branch, 15, "BIH",3 },
    { neg,  DIRECT, "NEG", 5 },
    { invalid,  DIRECT, inval_str, 0 },
    { invalid,  DIRECT, inval_str, 0 },
    { com,  DIRECT, "COM", 5 },
    { lsr,  DIRECT, "LSR", 5 },
    { invalid,  DIRECT, inval_str, 0 },
    { ror,  DIRECT, "ROR", 5 },
    { asr,  DIRECT, "ASR", 5 },
    { lsl,  DIRECT, "LSL", 5 },
    { rol,  DIRECT, "ROL", 5 },
    { dec,  DIRECT, "DEC", 5 },
    { invalid,  DIRECT, inval_str, 0 },
    { inc,  DIRECT, "INC", 5 },
    { tst,  DIRECT, "TST", 4 },
    { invalid,  DIRECT, inval_str, 0 },
    { clr,  DIRECT, "CLR", 5 },
    { neg,  ACCUM, "NEGA", 3 },
    { invalid,  ACCUM, inval_str, 0 },
  /*{ invalid,  ACCUM, inval_str, 0 },*/
    { mul,  INH, "MUL", 11 },
    { com,  ACCUM, "COMA", 3 },
    { lsr,  ACCUM, "LSRA", 3 },
    { invalid,  ACCUM, inval_str, 0 },
    { ror,  ACCUM, "RORA", 3 },
    { asr,  ACCUM, "ASRA", 3 },
    { lsl,  ACCUM, "LSLA", 3 },
    { rol,  ACCUM, "ROLA", 3 },
    { dec,  ACCUM, "DECA", 3 },
    { invalid,  ACCUM, inval_str, 0 },
    { inc,  ACCUM, "INCA", 3 },
    { tst,  ACCUM, "TSTA", 3 },
    { invalid,  ACCUM, inval_str, 0 },
    { clr,  ACCUM, "CLRA", 3 },
    { neg,  XREG, "NEGX", 3 },
    { invalid,  XREG, inval_str, 0 },
    { invalid,  XREG, inval_str, 0 },
    { com,  XREG, "COMX", 3 },
    { lsr,  XREG, "LSRX", 3 },
    { invalid,  XREG, inval_str, 0 },
    { ror,  XREG, "RORX", 3 },
    { asr,  XREG, "ASRX", 3 },
    { lsl,  XREG, "LSLX", 3 },
    { rol,  XREG, "ROLX", 3 },
    { dec,  XREG, "DECX", 3 },
    { invalid,  XREG, inval_str, 0 },
    { inc,  XREG, "INCX", 3 },
    { tst,  XREG, "TSTX", 3 },
    { invalid,  XREG, inval_str, 0 },
    { clr,  XREG, "CLRX", 3 },
    { neg,  AT_X_BYTE_OFFSET, "NEG", 6 },
    { invalid,  AT_X_BYTE_OFFSET, inval_str, 0 },
    { invalid,  AT_X_BYTE_OFFSET, inval_str, 0 },
    { com,  AT_X_BYTE_OFFSET, "COM", 6 },
    { lsr,  AT_X_BYTE_OFFSET, "LSR", 6 },
    { invalid,  AT_X_BYTE_OFFSET, inval_str, 0 },
    { ror,  AT_X_BYTE_OFFSET, "ROR", 6 },
    { asr,  AT_X_BYTE_OFFSET, "ASR", 6 },
    { lsl,  AT_X_BYTE_OFFSET, "LSL", 6 },
    { rol,  AT_X_BYTE_OFFSET, "ROL", 6 },
    { dec,  AT_X_BYTE_OFFSET, "DEC", 6 },
    { invalid,  AT_X_BYTE_OFFSET, inval_str, 0 },
    { inc,  AT_X_BYTE_OFFSET, "INC", 6 },
    { tst,  AT_X_BYTE_OFFSET, "TST", 5 },
    { invalid,  AT_X_BYTE_OFFSET, inval_str, 0 },
    { clr,  AT_X_BYTE_OFFSET, "CLR", 6 },
    { neg,  AT_X, "NEG ,X", 5 },
    { invalid,  AT_X, inval_str, 0 },
    { invalid,  AT_X, inval_str, 0 },
    { com,  AT_X, "COM ,X", 5 },
    { lsr,  AT_X, "LSR ,X", 5 },
    { invalid,  AT_X, inval_str, 0 },
    { ror,  AT_X, "ROR ,X", 5 },
    { asr,  AT_X, "ASR ,X", 5 },
    { lsl,  AT_X, "LSL ,X", 5 },
    { rol,  AT_X, "ROL ,X", 5 },
    { dec,  AT_X, "DEC ,X", 5 },
    { invalid,  AT_X, inval_str, 0 },
    { inc,  AT_X, "INC ,X", 5 },
    { tst,  AT_X, "TST ,X", 4 },
    { invalid,  AT_X, inval_str, 0 },
    { clr,  AT_X, "CLR ,X", 5 },
    { rti,  INH, "RTI", 9 },
    { rts,  INH, "RTS", 6 },
    { invalid,  INH, inval_str, 0 },
    { swi,  INH, "SWI", 10 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
   /* { invalid,  INH, inval_str, 0 },*/
    { stop, INH, "STOP", 2 },
   /* { invalid,  INH, inval_str, 0 },*/
    { wait, INH, "WAIT", 2 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { invalid,  INH, inval_str, 0 },
    { tax, INH, "TAX", 2 },
    { clc, INH, "CLC", 2 },
    { sec, INH, "SEC", 2 },
    { cli, INH, "CLI", 2 },
    { sei, INH, "SEI", 2 },
    { rsp, INH, "RSP", 2 },
    { nop, INH, "NOP", 2 },
    { invalid,  INH, inval_str, 0 },
    { txa, INH, "TXA", 2 },
    { sub, IMM, "SUB", 2 },
    { cmp, IMM, "CMP", 2 },
    { sbc, IMM, "SBC", 2 },
    { cpx, IMM, "CPX", 2 },
    { and, IMM, "AND", 2 },
    { bit, IMM, "BIT", 2 },
    { lda, IMM, "LDA", 2 },
    { invalid,  IMM, inval_str, 0 },
    { eor, IMM, "EOR", 2 },
    { adc, IMM, "ADC", 2 },
    { ora, IMM, "ORA", 2 },
    { add, IMM, "ADD", 2 },
    { invalid,  IMM, inval_str, 0 },
    { bsr, REL, "BSR", 6 },
    { ldx, IMM, "LDX", 2 },
    { invalid,  IMM, inval_str, 0 },
    { sub, DIRECT, "SUB", 3 },
    { cmp, DIRECT, "CMP", 3 },
    { sbc, DIRECT, "SBC", 3 },
    { cpx, DIRECT, "CPX", 3 },
    { and, DIRECT, "AND", 3 },
    { bit, DIRECT, "BIT", 3 },
    { lda, DIRECT, "LDA", 3 },
    { sta, DIRECT, "STA", 4 },
    { eor, DIRECT, "EOR", 3 },
    { adc, DIRECT, "ADC", 3 },
    { ora, DIRECT, "ORA", 3 },
    { add, DIRECT, "ADD", 3 },
    { jmp, DIRECT, "JMP", 2 },
    { jsr, DIRECT, "JSR", 5 },
    { ldx, DIRECT, "LDX", 3 },
    { stx, DIRECT, "STX", 4 },
    { sub, EXT, "SUB", 4 },
    { cmp, EXT, "CMP", 4 },
    { sbc, EXT, "SBC", 4 },
    { cpx, EXT, "CPX", 4 },
    { and, EXT, "AND", 4 },
    { bit, EXT, "BIT", 4 },
    { lda, EXT, "LDA", 4 },
    { sta, EXT, "STA", 5 },
    { eor, EXT, "EOR", 4 },
    { adc, EXT, "ADC", 4 },
    { ora, EXT, "ORA", 4 },
    { add, EXT, "ADD", 4 },
    { jmp, EXT, "JMP", 3 },
    { jsr, EXT, "JSR", 6 },
    { ldx, EXT, "LDX", 4 },
    { stx, EXT, "STX", 5 },
    { sub, AT_X_WORD_OFFSET, "SUB", 5 },
    { cmp, AT_X_WORD_OFFSET, "CMP", 5 },
    { sbc, AT_X_WORD_OFFSET, "SBC", 5 },
    { cpx, AT_X_WORD_OFFSET, "CPX", 5 },
    { and, AT_X_WORD_OFFSET, "AND", 5 },
    { bit, AT_X_WORD_OFFSET, "BIT", 5 },
    { lda, AT_X_WORD_OFFSET, "LDA", 5 },
    { sta, AT_X_WORD_OFFSET, "STA", 6 },
    { eor, AT_X_WORD_OFFSET, "EOR", 5 },
    { adc, AT_X_WORD_OFFSET, "ADC", 5 },
    { ora, AT_X_WORD_OFFSET, "ORA", 5 },
    { add, AT_X_WORD_OFFSET, "ADD", 5 },
    { jmp, AT_X_WORD_OFFSET, "JMP", 4 },
    { jsr, AT_X_WORD_OFFSET, "JSR", 7 },
    { ldx, AT_X_WORD_OFFSET, "LDX", 5 },
    { stx, AT_X_WORD_OFFSET, "STX", 6 },
    { sub, AT_X_BYTE_OFFSET, "SUB", 4 },
    { cmp, AT_X_BYTE_OFFSET, "CMP", 4 },
    { sbc, AT_X_BYTE_OFFSET, "SBC", 4 },
    { cpx, AT_X_BYTE_OFFSET, "CPX", 4 },
    { and, AT_X_BYTE_OFFSET, "AND", 4 },
    { bit, AT_X_BYTE_OFFSET, "BIT", 4 },
    { lda, AT_X_BYTE_OFFSET, "LDA", 4 },
    { sta, AT_X_BYTE_OFFSET, "STA", 5 },
    { eor, AT_X_BYTE_OFFSET, "EOR", 4 },
    { adc, AT_X_BYTE_OFFSET, "ADC", 4 },
    { ora, AT_X_BYTE_OFFSET, "ORA", 4 },
    { add, AT_X_BYTE_OFFSET, "ADD", 4 },
    { jmp, AT_X_BYTE_OFFSET, "JMP", 3 },
    { jsr, AT_X_BYTE_OFFSET, "JSR", 6 },
    { ldx, AT_X_BYTE_OFFSET, "LDX", 4 },
    { stx, AT_X_BYTE_OFFSET, "STX", 5 },
    { sub, AT_X, "SUB ,X", 3 },
    { cmp, AT_X, "CMP ,X", 3 },
    { sbc, AT_X, "SBX ,X", 3 },
    { cpx, AT_X, "CPX ,X", 3 },
    { and, AT_X, "AND ,X", 3 },
    { bit, AT_X, "BIT ,X", 3 },
    { lda, AT_X, "LDA ,X", 3 },
    { sta, AT_X, "STA ,X", 4 },
    { eor, AT_X, "EOR ,X", 3 },
    { adc, AT_X, "ADC ,X", 3 },
    { ora, AT_X, "ORA ,X", 3 },
    { add, AT_X, "ADD ,X", 3 },
    { jmp, AT_X, "JMP ,X", 2 },
    { jsr, AT_X, "JSR ,X", 5 },
    { ldx, AT_X, "LDX ,X", 3 },
    { stx, AT_X, "STX ,X", 4 }
};

struct program_model pgm_model;

/**********************************************************************/
int sim_reset()
{
    /* See figure 7-7 in 6805 tech data for reset, intr handling desc */

    pgm_model.ccr = CC_I;
    rsp( INH);          /* reset stack pointer to $7F */
    sim_write( PORT_A_DDR, 0 );
    sim_write( PORT_B_DDR, 0 );
    sim_write( PORT_C_DDR,0  );
    external_intr = 0;   /* clear INT request latch */
    sim_write( TIMER_CONTROL, 0x7F);
    sim_write( MISC_REGISTER, 0xFF);
    sim_timer_init();   /* prescaler and ctr to all 1, set TCR bit */
                        /* see 5-8 , 6805 tech data, for more. */
    
    /* Load options from MOR into control logic */
    /* partially done by sim_timer_init, above */

    pgm_model.pc = (sim_read( 0xFFE) << 8) + sim_read( 0xFFF);    
    cycle_count = 0;
}
/**********************************************************************/
int get_ea( addr_mode )
/* Called by most routines in instr2.c.  Returns the address from which
   data is to be fetched (or to which to write), based on address mode
   and an appropriate number of bytes at the current pc, which is assumed
   to point to the byte after the instruction.
   (Exception: bit-test-and-branch instructions call this routine twice:
   the first time mode is DIRECT to get the address of the byte to test,
   and the second time mode is BTB to get the address to which to branch.)
*/
{
    int retval, i, j;
    char buff[40];

    switch (addr_mode)
    {
    case ACCUM:
	retval = RW_A;
	break;
    case XREG:
	retval = RW_X;
	break;
    case AT_X:
	retval = pgm_model.x;
	break;
    case AT_X_BYTE_OFFSET:
	retval = sim_read( pgm_model.pc);
	if (display_enabled)
	{
            sprintf( buff, "   $%x,X", retval);
            strcat( mne, buff);
	    sprintf( buff, " %02x", retval);
	    strcat( opcode, buff);
        }
	retval += pgm_model.x;
	pgm_model.pc++;
	break;
    case AT_X_WORD_OFFSET:
	i = sim_read( pgm_model.pc);
	pgm_model.pc++;
	j = sim_read( pgm_model.pc);
	pgm_model.pc++;
        retval = i * 256 + j;
        if (display_enabled)
        {
            sprintf( buff, "   $%x,X", retval);
            strcat( mne, buff);
	    sprintf( buff, " %02x %02x", i, j);
	    strcat( opcode, buff);
        }
	retval += pgm_model.x;
	break;
    case IMM:
	i = sim_read( pgm_model.pc);
	retval = pgm_model.pc;
	pgm_model.pc++;
        if (display_enabled)
        {
	    sprintf( buff, "   #$%02x", i);
            strcat( mne, buff);
	    sprintf( buff, " %02x", i);
	    strcat( opcode, buff);
 	}
	break;	
    case DIRECT:
	retval = sim_read( pgm_model.pc);
	pgm_model.pc++;
	if (display_enabled)
	{
	    sprintf( buff, "   $%02x", retval);
            strcat( mne, buff);
	    sprintf( buff, " %02x", retval);
	    strcat( opcode, buff );
	}
	break;
    case EXT:
	i = sim_read( pgm_model.pc);
	pgm_model.pc++;
	j = sim_read( pgm_model.pc);
	pgm_model.pc++;
        retval = i * 256 + j;
        if (display_enabled)
        {
            sprintf( buff, "   $%03x", retval);
            strcat( mne, buff);
	    sprintf( buff, " %02x %02x", i, j);
	    strcat( opcode, buff);
        }
	break;
    case BTB: /* second of two bytes for BTB - first is DIRECT, second REL */
	j = i = sim_read( pgm_model.pc);
	pgm_model.pc++;
	if (i > 127)
	    i -= 256;
	retval = pgm_model.pc + i;
	if (display_enabled)
	{
	    sprintf( buff, ",$%03x", retval);
            strcat( mne, buff);
	    sprintf( buff, " %02x", j);
	    strcat( opcode, buff );  /* skip 2 of 3 leading spaces */
	}
	break;
    case REL:
	j = i = sim_read( pgm_model.pc);
	pgm_model.pc++;
	if (i > 127)
	    i -= 256;
	retval = pgm_model.pc + i;
	if (display_enabled)
	{
	    sprintf( buff, "   $%03x", retval);
            strcat( mne, buff);
	    sprintf( buff, " %02x", j);
	    strcat( opcode, buff );  /* skip 2 of 3 leading spaces */
	}
	break;
    default:
        retval = -1;
    }
    return( retval);
}
/**********************************************************************/
int sim_instr()
/* Called from instr_or_intr, below, to do instruction at pc */
/* Also called from sim_r3.c for disassembly */
{
    int iopcode, i, j;

    iopcode = sim_read( pgm_model.pc );
    sprintf( opcode, "%03x  %02x", pgm_model.pc, iopcode);
    pgm_model.pc++;
    strcpy( mne, instr_tbl[iopcode].name);
    rw[0] = '\0';    /* empty string */
    if (!disassemble)
	sim_timer_update( instr_tbl[iopcode].ncycles );    

    (*instr_tbl[iopcode].function)( instr_tbl[iopcode].argument);

    if (!disassemble)
	cycle_count += instr_tbl[iopcode].ncycles;
    if (display_enabled)
    {
	settextposition( 7, 1);
	delete_line(PROMPTLINE+2);
	settextposition( 49, 1);
	printf( "%s", opcode );
	settextposition( 49, 19);
	printf( "%s", mne);
	if (!disassemble)
	{
	    settextposition( 49, 40);
	    printf( "%s", rw); /* nothing in rw if disassemble, see append_rw*/
	    settextposition( 49, 70);
	    printf( "%9ld", cycle_count);
	}
	settextposition( PROMPTLINE, 1);  /* return cursor to default pos */
	
	if (log_enabled)       /* Note: never true if disassemble */
	{
	    fprintf( logfile, "%s", opcode);
            i = strlen( opcode);
	    fprintf( logfile, "%s", &blanks[40-19+i]);
	    fprintf( logfile, "%s", mne );
	    i = strlen( mne);
	    fprintf( logfile, "%s", &blanks[40-(40-19)+i]);
	    fprintf( logfile, "%s", rw);
	    i = strlen( rw);
	    fprintf( logfile, "%s", &blanks[40-(70-40)+i]);
	    fprintf( logfile, "%9ld\n", cycle_count);
	}
    }
}
/**********************************************************************/
int pull()
/* The 6805 has no user "pull" instruction.  That's why this routine is
   here, instead of in instr2.c.  This routine used by rts, rti in instr2
*/
{
    if (pgm_model.sp < 0x7F)
	pgm_model.sp++;
    else
	pgm_model.sp = 0x61;
    return( sim_read( pgm_model.sp));
}
/**********************************************************************/
int push( value)
int value;
/* The 6805 series has no user "push" instruction.  That's why this routine
   is here, instead of in instr2.c.  This routine used by 'interrupt', below
*/
{
    sim_write( pgm_model.sp, value);
    if (pgm_model.sp > 0x61)
	pgm_model.sp--;
    else
	pgm_model.sp = 0x7F; 
}
/**********************************************************************/
int rinterrupt( vector_addr)
/* Stack registers, fetch vector, and display a message */
{
    push( pgm_model.pc & 0xFF);				/* PCL */
    push( ((pgm_model.pc & 0xF00) >> 8) | 0xF0 );	/* PCH */
    push( pgm_model.x);					/*  X  */
    push( pgm_model.a);					/*  A  */
    push( pgm_model.ccr | 0xE0 );			/* CCR */
    pgm_model.ccr |= CC_I;   /* Mask interrupts */
    pgm_model.pc = sim_read( vector_addr)  * 256;
    pgm_model.pc += sim_read( vector_addr + 1 ) ;
    pgm_model.pc &= 4095;
    if (display_enabled)
    {
	settextposition( 7, 1);
	delete_line(PROMPTLINE+2);
	settextposition( 49, 1);
	if (vector_addr == 0xFFC)
	   printf( "==> Interrupt service, SWI");
	else if (vector_addr == 0xFFA)
	   printf( "==> Interrupt service, INT");
	else if (vector_addr == 0xFF8)
	   printf( "==> Interrupt service, INT2 or TIMER");
	if (pgm_model.sp > 0x7A)
	   printf("   *** WARNING: Stack overflow");
	if (log_enabled)
	{
	    if (vector_addr == 0xFFC)
	        fprintf(logfile, "==> Interrupt service, SWI");
	    else if (vector_addr == 0xFFA)
	        fprintf(logfile, "==> Interrupt service, INT");
	    else if (vector_addr == 0xFF8)
	        fprintf(logfile, "==> Interrupt service, INT2 or TIMER");
	    if (pgm_model.sp > 0x7A)
	        fprintf(logfile,"   *** WARNING: Stack overflow\n");
	    else
		fprintf(logfile, "\n");
	}
    }
}
/**********************************************************************/
int instr_or_intr()
/* called from main to do one instruction */
{
    int i,j;

    if (!(pgm_model.ccr & CC_I))
    {
	if (external_intr)
	{
	    external_intr = 0;   /* clear INT request latch */
	    rinterrupt( 0xFFA);   /* vector address = INT */
	}
	else
	{
	    i = sim_read( TIMER_CONTROL);
	    j = sim_read( MISC_REGISTER);
	    if ( (( i & 0xC0) == 0x80) || ((j & 0xC0) == 0x80) )
		rinterrupt( 0xFF8); /* vector address = timer or INT2 */
	}
    }
    sim_instr();    /* SWI is handled as a regular instruction */
}

/**********************************************************************/
append_rw( readflag, addr, data)
int readflag;   /* 1 = Read, 0 = Write */
int addr, data;
/* Used by routines in instr2.c to show bytes read, written */
{
    char buff[50];
    char *sym_tbl_ptr;
    int *sym_nmbr_ptr, ndx;

    sym_nmbr_ptr = sym_nmbr;

    if (display_enabled && !disassemble)
    {
	if (addr >= 0)
	{
/* Symbol table "linked list" */
	    if (( ndx = *( sym_nmbr_ptr +  addr)) >= 4096)
	    {
	      sym_tbl_ptr = sym_tbl;
	      sym_tbl_ptr += ndx - 4096;

	      if (readflag)
		sprintf( buff, "%s=>%02x ", sym_tbl_ptr, data);
	      else
		sprintf( buff, "%s<=%02x ", sym_tbl_ptr, data);
	      goto endloop;
	    }

	    if (readflag)
		sprintf( buff, "%03x=>%02x ", addr, data);
	    else
		sprintf( buff, "%03x<=%02x ", addr, data);
	}
	else
	{
	    char rname[20];

	    if (addr == RW_A)
		strcpy( rname, "ACCUM");
	    else if (addr == RW_X)
		strcpy( rname, "X_REG");
	    else if (addr == RW_SP)
		strcpy( rname, "SP");
	    if (readflag)
		sprintf( buff, "%s=>%02x ", rname, data);
	    else
		sprintf( buff, "%s<=%02x ", rname, data);
	}
endloop:
;

       strcat( rw, buff);
    }
}



delete_line( lineno)
int lineno;
{
#ifdef MSC

    union REGS regs;

    lineno--;            /* DOS BIOS counts lines from 0, not 1 */
    regs.h.ah = 6;       /* Service 6 = scroll text window up */
    regs.h.al = 1;       /* Number of lines to scroll up */
    regs.h.ch = lineno;  /* row# of up left */
    regs.h.cl = 0;       /* column# of up left */
    regs.h.dh = 49;      /* row# of low right */
    regs.h.dl = 79;      /* column# of low right */
    regs.h.bh = 7;       /* foreground white, background black, no blink */
    int86( 16, &regs, &regs);
#endif
#ifdef VT52
    settextposition( lineno, 1);
    printf("\033M");    /* escape M = delete line the cursor is on */
			/* the rest moves up one line, last line is free */
#endif
}

/************************ end of file instr.c ***************************/
