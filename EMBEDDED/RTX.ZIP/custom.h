

/*---------------------------------------------------------------------
   Customizable Parameters
   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   
   Make sure all parameters here are customized to your needs.


 ---------------------------------------------------------------------*/

                                    /* -- max number of tasks ------ */
#define MAX_TASKS             32

                                    /* -- max chars in task name --- */
#define MAX_TASK_NAME         16             

                                    /* -- max number of clock timers */
#define MAX_TIMERS            16

                                    /* -- do not make smaller ------ */
#define MIN_STACK_SIZE       128             /* bytes */

                                    /* -- time slice for a task ---- */
#define TIME_SLICE             9             /*        ticks      */
                                             /*   6  = 1/3 second */
                                             /*   9  = 1/2 second */
                                             /*  12  = 2/3 second */
                                             /*  18  =   1 second */


                                    /* -- enter in the enum list the
                                          names of any custom event flags -- */
enum {

   NOT_WAITING = 0,                 /* keep this line here */
   COM1_RING,
   COM1_TX_EMPTY,
   COM1_DATA_AVAILABLE,
   COM1_CHANGE_CARRIER,

   COM2_RING,
   COM2_TX_EMPTY,
   COM2_DATA_AVAILABLE,
   COM2_CHANGE_CARRIER,

   COM3_RING,
   COM3_TX_EMPTY,
   COM3_DATA_AVAILABLE,
   COM3_CHANGE_CARRIER,

   COM4_RING,
   COM4_TX_EMPTY,
   COM4_DATA_AVAILABLE,
   COM4_CHANGE_CARRIER,




   LAST_EVENT                       /* -- keep this entry alone -- */
   } customEvents;
