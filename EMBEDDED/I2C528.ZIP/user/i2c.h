/* Header file with declarations for 8xC528 I2C-routines */

void INIT_IIC(char Own_Adr,char *Slave_Ptr);
void DIS_IIC(void);
void IIC_TEST_DEVICE(char Sl_Adr);
void IIC_WRITE(char Sl_Adr,char Count,char *Source_Ptr);
void IIC_WRITE_SUB(char Sl_Adr,char Count,char *Source_Ptr,char Sub_Adr);
void IIC_WRITE_SUB_SWINC(char Sl_Adr,char Count,char *Source_Ptr,char Sub_Adr);
void IIC_WRITE_MEMORY(char Sl_Adr,char Count,char *Source_Ptr,char Sub_Adr);
void IIC_WRITE_SUB_WRITE(char Sl_Adr,char Count1,char *Source_Ptr1,char Sub_Adr,char Count2,char *Source_Ptr2);
void IIC_WRITE_SUB_READ(char Sl_Adr,char Count1,char *Source_Ptr1,char Sub_Adr,char Count2,char *Dest_Ptr2);
void IIC_WRITE_COM_WRITE(char Sl_Adr,char Count1,char *Source_Ptr1,char Count2, char *Source_Ptr2);
void IIC_WRITE_REP_WRITE(char Sl_Adr1,char Count1,char *Source_Ptr1,char Sl_Adr2,char Count2,char *Source_Ptr2);
void IIC_WRITE_REP_READ(char Sl_Adr1,char Count1,char *Source_Ptr1,char Sl_Adr2,char Count2,char *Dest_Ptr2);
void IIC_READ(char Sl_Adr,char Count,char *Dest_Ptr);
void IIC_READ_STATUS(char Sl_Adr,char *Dest_Ptr);
void IIC_READ_SUB(char Sl_Adr,char Count,char *Source_Ptr,char Sub_Adr); 
void IIC_READ_REP_READ(char Sl_Adr1,char Count1,char *Dest_Ptr1,char Sl_Adr2,char Count2,char *Dest_Ptr2);
void IIC_READ_REP_WRITE(char Sl_Adr1,char Count1,char *Dest_Ptr1,char Sl_Adr2,char Count2,char *Source_Ptr2);


 









