#include <c:\applic\i2c\i2c.h>

         rom  char              LCD_Tab[]={0xFC,0x60,0xDA,0xF2,0x66,0xB6,0x3E,
                                           0xE0,0xFE,0xE6}; 

void main()

{
       
        #define Clock_Adr       0xA2
        #define LCD_Adr         0x74
        #define Cl_Sub_Adr      0x01    

        rom  char               * Tab_Ptr;
        data char               Time_Buffer[4];
        data char               * Time_Ptr;
        data char               LCD_Buffer[5];
        data char               * LCD_Ptr;
   
        INIT_IIC(0x22,&Time_Buffer);
        LCD_Buffer[0]=0; /* LCD control word */
        Time_Buffer[0]=0;
        Time_Buffer[1]=0;
        IIC_WRITE(Clock_Adr,2,&Time_Buffer); /* Initialise clock */

        while (1)      /* Program loop */
              {
               IIC_READ_SUB(Clock_Adr,4,&Time_Buffer,Cl_Sub_Adr);
                                                    /* Get time */
               LCD_Ptr = &LCD_Buffer[1]; /* Initialise pointers */
               Time_Ptr = &Time_Buffer[3];
               Tab_Ptr = (LCD_Tab+(*Time_Ptr >> 4)); /* 10-HR's */ 
               *(LCD_Ptr++) = *Tab_Ptr;
               Tab_Ptr = (LCD_Tab+(*(Time_Ptr--) & 0x0F)); /* HR's */
               *(LCD_Ptr++) = *Tab_Ptr;
               Tab_Ptr = (LCD_Tab+(*Time_Ptr >> 4)); /* 10-MIN's */
               *(LCD_Ptr++) = (*Tab_Ptr | 0x01); /* dp */
               Tab_Ptr = (LCD_Tab+(*Time_Ptr & 0x0F)); /* MIN's */
               *LCD_Ptr = *Tab_Ptr;
               Time_Ptr = &Time_Buffer[1]; /* Check sec's for blinking */
               LCD_Ptr = &LCD_Buffer[1];
               if ((*Time_Ptr & 0x01)>0)    
                  *LCD_Ptr = (*LCD_Ptr | 0x01);
               IIC_WRITE(LCD_Adr,5,&LCD_Buffer); /* Display time */
              }              
}


