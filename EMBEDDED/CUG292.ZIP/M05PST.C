/* m05pst.c */

/*
 * (C) Copyright 1989,1990
 * All Rights Reserved
 *
 * Alan R. Baldwin
 * 721 Berkeley St.
 * Kent, Ohio  44240
 */

#include <stdio.h>
#include <setjmp.h>
#include "asm.h"
#include "m6805.h"

struct	mne	mne[] = {

	/* machine */

	NULL,	".setdp",	S_SDP,		0,	0,

	/* system */

	NULL,	"CON",		S_ATYP,		0,	A_CON,
	NULL,	"OVR",		S_ATYP,		0,	A_OVR,
	NULL,	"REL",		S_ATYP,		0,	A_REL,
	NULL,	"ABS",		S_ATYP,		0,	A_ABS|A_OVR,
	NULL,	"NOPAG",	S_ATYP,		0,	A_NOPAG,
	NULL,	"PAG",		S_ATYP,		0,	A_PAG,

	NULL,	".byte",	S_BYTE,		0,	0,
	NULL,	".db",		S_BYTE,		0,	0,
	NULL,	".word",	S_WORD,		0,	0,
	NULL,	".dw",		S_WORD,		0,	0,
	NULL,	".ascii",	S_ASCII,	0,	0,
	NULL,	".asciz",	S_ASCIZ,	0,	0,
	NULL,	".blkb",	S_BLK,		0,	1,
	NULL,	".ds",		S_BLK,		0,	1,
	NULL,	".blkw",	S_BLK,		0,	2,
	NULL,	".page",	S_PAGE,		0,	0,
	NULL,	".title",	S_TITLE,	0,	0,
	NULL,	".sbttl",	S_SBTL,		0,	0,
	NULL,	".globl",	S_GLOBL,	0,	0,
	NULL,	".area",	S_DAREA,	0,	0,
	NULL,	".even",	S_EVEN,		0,	0,
	NULL,	".odd",		S_ODD,		0,	0,
	NULL,	".if",		S_IF,		0,	0,
	NULL,	".else",	S_ELSE,		0,	0,
	NULL,	".endif",	S_ENDIF,	0,	0,
	NULL,	".include",	S_INCL,		0,	0,
	NULL,	".radix",	S_RADIX,	0,	0,
	NULL,	".org",		S_ORG,		0,	0,
	NULL,	".module",	S_MODUL,	0,	0,

	/* 6805 */

	NULL,	"neg",		S_TYP1,		0,	0x30,
	NULL,	"com",		S_TYP1,		0,	0x33,
	NULL,	"lsr",		S_TYP1,		0,	0x34,
	NULL,	"ror",		S_TYP1,		0,	0x36,
	NULL,	"asr",		S_TYP1,		0,	0x37,
	NULL,	"asl",		S_TYP1,		0,	0x38,
	NULL,	"lsl",		S_TYP1,		0,	0x38,
	NULL,	"rol",		S_TYP1,		0,	0x39,
	NULL,	"dec",		S_TYP1,		0,	0x3A,
	NULL,	"inc",		S_TYP1,		0,	0x3C,
	NULL,	"tst",		S_TYP1,		0,	0x3D,
	NULL,	"clr",		S_TYP1,		0,	0x3F,

	NULL,	"sub",		S_TYP2,		0,	0xA0,
	NULL,	"cmp",		S_TYP2,		0,	0xA1,
	NULL,	"sbc",		S_TYP2,		0,	0xA2,
	NULL,	"cpx",		S_TYP2,		0,	0xA3,
	NULL,	"and",		S_TYP2,		0,	0xA4,
	NULL,	"bit",		S_TYP2,		0,	0xA5,
	NULL,	"lda",		S_TYP2,		0,	0xA6,
	NULL,	"sta",		S_TYP2,		0,	0xA7,
	NULL,	"eor",		S_TYP2,		0,	0xA8,
	NULL,	"adc",		S_TYP2,		0,	0xA9,
	NULL,	"ora",		S_TYP2,		0,	0xAA,
	NULL,	"add",		S_TYP2,		0,	0xAB,
	NULL,	"jmp",		S_TYP2,		0,	0xAC,
	NULL,	"jsr",		S_TYP2,		0,	0xAD,
	NULL,	"ldx",		S_TYP2,		0,	0xAE,
	NULL,	"stx",		S_TYP2,		0,	0xAF,

	NULL,	"bset",		S_TYP3,		0,	0x10,
	NULL,	"bclr",		S_TYP3,		0,	0x11,

	NULL,	"brset",	S_TYP4,		0,	0x00,
	NULL,	"brclr",	S_TYP4,		0,	0x01,

	NULL,	"bra",		S_BRA,		0,	0x20,
	NULL,	"brn",		S_BRA,		0,	0x21,
	NULL,	"bhi",		S_BRA,		0,	0x22,
	NULL,	"bls",		S_BRA,		0,	0x23,
	NULL,	"bcc",		S_BRA,		0,	0x24,
	NULL,	"bhs",		S_BRA,		0,	0x24,
	NULL,	"bcs",		S_BRA,		0,	0x25,
	NULL,	"blo",		S_BRA,		0,	0x25,
	NULL,	"bne",		S_BRA,		0,	0x26,
	NULL,	"beq",		S_BRA,		0,	0x27,
	NULL,	"bhcc",		S_BRA,		0,	0x28,
	NULL,	"bhcs",		S_BRA,		0,	0x29,
	NULL,	"bpl",		S_BRA,		0,	0x2A,
	NULL,	"bmi",		S_BRA,		0,	0x2B,
	NULL,	"bmc",		S_BRA,		0,	0x2C,
	NULL,	"bms",		S_BRA,		0,	0x2D,
	NULL,	"bil",		S_BRA,		0,	0x2E,
	NULL,	"bih",		S_BRA,		0,	0x2F,
	NULL,	"bsr",		S_BRA,		0,	0xAD,

	NULL,	"nega",		S_INH,		0,	0x40,
	NULL,	"coma",		S_INH,		0,	0x43,
	NULL,	"lsra",		S_INH,		0,	0x44,
	NULL,	"rora",		S_INH,		0,	0x46,
	NULL,	"asra",		S_INH,		0,	0x47,
	NULL,	"asla",		S_INH,		0,	0x48,
	NULL,	"lsla",		S_INH,		0,	0x48,
	NULL,	"rola",		S_INH,		0,	0x49,
	NULL,	"deca",		S_INH,		0,	0x4A,
	NULL,	"inca",		S_INH,		0,	0x4C,
	NULL,	"tsta",		S_INH,		0,	0x4D,
	NULL,	"clra",		S_INH,		0,	0x4F,

	NULL,	"negx",		S_INH,		0,	0x50,
	NULL,	"comx",		S_INH,		0,	0x53,
	NULL,	"lsrx",		S_INH,		0,	0x54,
	NULL,	"rorx",		S_INH,		0,	0x56,
	NULL,	"asrx",		S_INH,		0,	0x57,
	NULL,	"aslx",		S_INH,		0,	0x58,
	NULL,	"lslx",		S_INH,		0,	0x58,
	NULL,	"rolx",		S_INH,		0,	0x59,
	NULL,	"decx",		S_INH,		0,	0x5A,
	NULL,	"incx",		S_INH,		0,	0x5C,
	NULL,	"tstx",		S_INH,		0,	0x5D,
	NULL,	"clrx",		S_INH,		0,	0x5F,

	NULL,	"rti",		S_INH,		0,	0x80,
	NULL,	"rts",		S_INH,		0,	0x81,
	NULL,	"swi",		S_INH,		0,	0x83,
	NULL,	"stop",		S_INH,		0,	0x8E,
	NULL,	"wait",		S_INH,		0,	0x8F,

	NULL,	"tax",		S_INH,		0,	0x97,
	NULL,	"clc",		S_INH,		0,	0x98,
	NULL,	"sec",		S_INH,		0,	0x99,
	NULL,	"cli",		S_INH,		0,	0x9A,
	NULL,	"sei",		S_INH,		0,	0x9B,
	NULL,	"rsp",		S_INH,		0,	0x9C,
	NULL,	"nop",		S_INH,		0,	0x9D,
	NULL,	"txa",		S_INH,		S_END,	0x9F,

};
