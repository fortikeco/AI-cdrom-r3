
{uses dos;}

const	maxidslength = 3000;
	maxordchar   =  255;
	HashWidth    =  245;	{== 500-127 identifier Hash table size	==}
	maxidnbr     =  500;	{== maxidnbr - maxordchar should be prime ==}
	linelength   =  100;

	{===============================================================}
	{ These next constants are used by the checker and analyzer to	}
	{ correctly report errors (at appropriate positions) when	}
	{ implementation maxima are overstepped when processing texts.	}
	{===============================================================}

	maxlevnbr    =   15;	{== max nesting possible in proofs	==}
	maxsntlength = 5000;	{== max number of tokens in sentence	==}

	{===============================================================}
	{ These next constants are used to name the temporary files	}
	{ which are used during the run.  These constants are provided	}
	{ for compatibility between the various versions of the program.}
	{===============================================================}

	errorsfilename	  = 'unit=2';
	checkerinfilename = 'unit=3';
	notaccfilename	  = 'unit=4';

type	natural = 0..maxint;

	{===============================================================}
	{ These are the types needed to pass information between the	}
	{ scanner and the analyzer:					}
	{								}
	{ wordkind - storage used for any type of token except for	}
	{	     identifier numbers					}
	{								}
	{ tokenword- stores the token information passed between the	}
	{	     scanner and analyzer.				}
	{===============================================================}
	  
	wordkind = ( eot, possy, nowsy, endsy, letsy, considersy, nojust,
		    bysy, atomsy, equalsy, identifier, bound, constant,
		    declared, conjsy, notsy, forsy, environsy, beginsy,
		    lparent, rparent, lbracket, rbracket, reservesy,
		    givensy, beingsy, besy, comma, semicolon, labelsy,
		    nonequalsy, orsy, iffsy, impliessy, holdssy, stsy,
		    exsy, proofsy, assumesy, suchsy, andsy, thussy, hencesy, 
		    thensy, contradisy, thesissy, errorsy, thatsy );
	tokenword = record kind: wordkind; idnbr, pos: natural end;

	{===============================================================}
	{ These types are used internally by the scanner but needed for	}
	{ variables which must persist between calls			}
	{								}
	{ charkind - denotes the classes of characters which the	}
	{	     scanner recognizes.  These are used to separate	}
	{	     the input stream in order to scan quickly.		}
	{ bitekind - stores the type of token which is being passed.	}
	{	     The token is one of:				}
	{		breserved   - reserved word			}
	{		bidentifier - identifier			}
	{		bcolon	    - colon reserved punctuation	}
	{		bnonequality- the not-equals reserved relation	}
	{		berror	    - an error token			}
	{		beot	    - finished conversation		}
	{		bonecharbite- one character reserved word	}
	{ bite	   - saves a representation of a token for internal use	}
	{	     to the scanner					}
	{ palpha   - a portable version of alpha: declared explicitly	}
	{===============================================================}

	charkind = ( allowedchar, letterordigit, apostrophe , colon, gt, 
		     lt, otherchar );
	bitekind = ( breserved, bidentifier, bcolon, bnonequality, 
		     bonecharbite, berror, beot );
	bite =	record
		   case bkind : bitekind of
			bidentifier : ( bidnbr : natural );
			breserved, bnonequality, bonecharbite :
			    ( bwordkind : wordkind )
		end;

	linetype = array [ 1..linelength ] of char;
	errrec   = record errnbr, pos : natural end;
	palpha	 = packed array [ 1..10 ] of char;
	time1_t  = packed array [ 1..32 ] of char;
	
var	errorsfile : file of errrec;
	errors	: errrec;

	{===============================================================}
	{ These variables needed by the scanner:			}
	{								}
	{ chkind	- holds the class of character for each of the	}
	{		  1..maxordchar characters for quick recognition}
	{ rspel		- an array used to compare potential identifiers}
	{		  to see if they are actually reserved words	}
	{===============================================================}

	chkind	: array [ char ] of charkind;
	rspel	: packed array [ 1..13 ] of char;
	onecharsy	: array [ char ] of wordkind;
	lastbite, nextbite : bite;	{== remembers two tokens 	    ==}
	bitenbr		: natural;	{== current token's occurance number =}
	idcnt		: natural;	{== number of identifiers seen	    ==}
	identslength	: natural;	{== total length of the identifiers ==}
	cc, llh		: natural;	{== position of current char input, ==}
					{==  and length, respectively	    ==}
	line, espel	: linetype;	{== input line, blank line to erase ==}
	spelling	: linetype;	{== stores an identifier	    ==}
	token: (*file of*) tokenword;	{== passed from scanner to parser   ==}

{=======================================================================}
{  Identifiers:  Identifiers are passed to the analyzer as a natural 	}
{	number.  If the identifier is a single character, then the	}
{	identifier's number is the ord() value of that character (the	}
{	range of these numbers is 1..maxordchar.  If the identifier is	}
{	more than a single character, the identifier is numbered in	}
{	maxordchar+1..maxidnbr, and its character representation is	}
{	stored into a character pool for comparison with incoming	}
{	identifiers.							}
{									}
{	Additions of (len>1) identifiers are made whenever a_newly	}
{	encountered_ identifier is scanned.  The identifier is hashed	}
{	into an identifier number.  Collisions for identifier numbers	}
{	are resolved by linear probing based on the initial hash value.	}
{	Identifiers are never deleted.					}
{									}
{  Identifier Storage:  Identifiers of greater than one character in	}
{	length are stored in a character pool, and are indexed into by	}
{	an array of natural numbers:					}
{									}
{	idents	a fixed length character storage pool indexed into by	}
{		xids.  Additions are made sequentially starting from	}
{		the first address				.	}
{									}
{	xids	an array of 'pointers' (natural numbers) into the	}
{		identifier pool pointing to the identifier's character	}
{		name.  Each entry contains a start and length value	}
{		which records the offset from zero into idents where	}
{		the identifier starts, and a length of the identifier.	}
{									}
{=======================================================================}

	xids	: array [ maxordchar..maxidnbr ] of
			record start, length : natural end;
	idents	: array [ 1..maxidslength ] of char;
	scannerstarted : boolean;


{== If separate compilation, be sure to clear up global definitions  =
=}
#ifndef MIZAR_INLINE
procedure msescanner (*  var token : tokenword *);
  external;
procedure InitScanner; external;
procedure mseanalyzer; external;
procedure mseerrprin; external;
procedure reseterrorsfile; external;	{== Main's file commands ==}
procedure closeerrorsfile; external;
procedure rewriteerrorsfile; external;
#endif
