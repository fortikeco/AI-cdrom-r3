#ifndef	HEAP
# define	HEAP
typedef struct {
	int	hp_size, hp_nxt;
	char	**hp_heap;
	int	(*hp_func)();
} heap;

heap	*hp_make();	/* int (*cmp)(), hp_size */
int	hp_enter();	/* heap *hp, char *elt */
char	*hp_delmin();	/* heap *hp */
#endif	HEAP
