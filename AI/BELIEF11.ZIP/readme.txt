Copyright 1989, 1990 Russell G. Almond

The BELIEF package was developed in SUN Common LISP, on a SUN 3/160 at
the Harvard University department of Statistics.  
The program was developed in part with the support of Army Research
Contract DAAL03-86K-0042, Arthur P. Dempster, principle investigator.
The machine was purchased with funds from ONR N 00014-K-85-0745 Peter
J. Huber, principle investigator.
Continuing support for the BELIEF package is being provided by the
University of Washington, Department of Statistics through the
courtesy of  Werner Stuzle and John McDonald of the same orginization
(the author, Russell Almond is solely responsible for the content).


License is granted to copy this program for education or research
purposes, with the restriction that no portion of this program may be
copied without also copying this notice.  All other rights reserved.
 

