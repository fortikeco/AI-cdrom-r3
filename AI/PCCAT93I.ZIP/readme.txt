                  COSMIC Software Catalog for PC-Compatibles
                             International Version

                           Installation Instructions



CATALOG INSTALLATION:

      The COSMIC Software Catalog requires approximately 5 M-bytes of disk
space to install correctly, which can be on either a local hard disk or a
network (shared-access) drive.  (Network administrators: please read the
section on network installation.)

1.  To begin, you must create a directory for the COSMIC Software Catalog. 
(If you already have a COSMIC Software Catalog directory, you may skip this
step and install to your existing catalog directory.)  Although not required,
we suggest naming the directory "\COSMIC."  We will assume in the following
examples that you are installing the catalog to C:\COSMIC (on your local hard
disk).

example:  C> md \COSMIC

Note: You do not type the "C>" when typing the above command--it merely
represents the DOS prompt.


2.  Next, you must change to this new directory.

example:  C> cd \COSMIC


3.  Transfer the file PCCAT93I.ZIP to your new directory.  If you do not have
PKWARE's PKUNZIP.EXE already installed on your machine, transfer the
PKUNZIP.EXE to your new directory as well.


4.  The next step is to "unzip" PCCAT93I.ZIP with the PKUNZIP utility:

C> pkunzip PCCAT93I


PKUNZIP will display the names of the files as they are "exploded" from the
PCCAT93I.ZIP file and created in the catalog directory.  (If installing over
an existing older version of the COSMIC Software Catalog, you will be prompted
to overwrite each of the old files.)  Pay close attention to the messages
PKUNZIP displays to verify that your catalog is uncorrupted.


6.  You must now rebuild the indexes that the catalog program uses. 
To rebuild the indexes, run the catalog program with the "reindex" parameter:

C> cosmicat reindex


Important note:  If the program aborts with either an "out of memory" error or
"internal error" message, you may need to include the command "SET CLIPPER=E0"
in your AUTOEXEC.BAT file.  This tells the program not to use expanded memory
which seems to cause a problem on some machines.  You must also have
"FILES=20" (at least 20) in your CONFIG.SYS file.

After the indexing is complete, you will return to the DOS prompt.  You may
now delete the PCCAT93I.ZIP file from the catalog directory.  If you have any
problems with the COSMIC Software Catalog, please feel free to call COSMIC at
(706) 542-3265 for assistance.



The catalog documentation (included in the ZIP file) has an introductory
overview as well as catalog usage instructions.  However, please ignore the
Installation section (section II) of the documentation, as this pertains to
those who receive the catalog on diskette.




==============================================================================

NETWORK INSTALLATION:

The COSMIC Software Catalog can be installed on a network, where several users
may share access to the catalog.  This section explains how to finish
installing the catalog for a file-sharing environment.  This should normally
be done only by the network administrator, for whom this section was written.


1.  The first thing to consider is where to store the program and data files. 
The catalog data files (KEYWORD.DBF, MASTER.DBF and MASTER.DBT) and their
indexes (FSNMAST.NTX, FSNKEY.NTX and KEYKEY.NTX) must all be together in the
same directory.  COSMICAT.EXE (the executable catalog program) could be stored
in a separate directory and referenced explicitly--but, this being an
arbitrary decision and for simplicity's sake, we do not recommend doing this.  
If you correctly installed the catalog on a network drive using the
instructions given at the beginning of the Catalog Installation section, you
actually need not worry yourself with this particular step.


2.  A much more important and complex issue is deciding where the HOLDSAVE.DBF
and its index (HSFSN.NTX) will be written for each user.  Programs selected by
the search procedure are stored in HOLDSAVE.DBF--a work file the program
creates.  Since these files are created, kept, and erased at the user's
discretion, these private (non-shared) files should be unique for each user of
the catalog.

Furthermore, because these HOLDSAVE files are generated in whichever directory
was current when the catalog was run, COSMICAT must be invoked from a drive or
directory that is unique to the user--this could be a user's local hard disk
or a personal network drive/directory.  If you choose to invoke from a user's
local hard disk, however, you must realize that users without a hard disk will
be precluded from using the catalog.


3.  You must also create an ASCII-text file named PATHNAME.TXT that contains
the full path to the catalog data files.  This file should be stored in the
directory with the catalog program (COSMICAT.EXE).  Before running the
catalog, PATHNAME.TXT must be copied from the catalog directory to the user's
current directory.  This tells the catalog program where to look for the
catalog data.  As an example, if the catalog was installed on the network
drive N: under \COSMIC, you could build the PATHNAME.TXT at the DOS prompt by
typing:

copy con N:\COSMIC\PATHNAME.TXT
N:\COSMIC\
^Z

(The "^Z" (Ctrl-Z) followed by a return ends the file and the message
"1 file(s) copied" is displayed.)


4.  The procedure of switching the user to an appropriate drive/directory,
copying the PATHNAME.TXT to that directory, and invoking COSMICAT can be done
in a batch file in the user's PATH.  The following is an example of how a
batch file could be written at the DOS prompt:

copy con N:\BAT\PCCAT.BAT
echo off
cls
C:
cd\
set clipper=E0
copy N:\COSMIC\PATHNAME.TXT
N:\COSMIC\cosmicat %1
del PATHNAME.TXT
set clipper=
^Z


In our example batch file we switch to the root directory on the user's local
hard disk, set the environmental variable CLIPPER=E0 (see the explanation in
the previous section), copy the PATHNAME.TXT to the user's directory, invoke
the catalog program (notice the "%1" allows for the "reindex" parameter), and
when the user is through, we can erase the pathname file from the user's local
drive and release the clipper environmental variable.  In our example here,
the batch file is stored in "N:\BAT" directory, which is presumably in the
user's path.

Network administrators that have questions about network installation should
feel free to call COSMIC at (706) 542-3265.

Again, the catalog documentation (included in the ZIP file) has an
introductory overview as well as catalog usage instructions.  However, please
ignore the Installation section (section II) of the documentation, as this
pertains to those who receive the catalog on diskette.
                                                               
