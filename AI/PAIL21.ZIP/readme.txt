@MSGID: 1:124/2206.0 96700241
From: mike@idsia.ch

Would it be possible/useful to include the following text
on the AI CD-Rom?

Many thanks

--Michael Rosner
Director, Portable AI Lab Project, IDSIA, Lugano Switzerland
========================================================
PORTABLE AI LAB

An Integrated Toolkit of AI Techniques and Tools

The Portable AI Lab is a computing environment containing a collection
of state-of-the-art AI tools, examples, and documentation.  It is
aimed at those involved in AI courses (i.e. in both teaching and
learning) at university level or equivalent.  It has been developed
under Swiss National Research Programme PNR 23 on AI and Robotics by
IDSIA Lugano in collaboration with IFI, University of Zurich and the
Laboratoire d'IA at the EPFL, Lausanne. The system is available free
of charge.

The design of Portable AI Lab is motivated by the conviction that the
acquisition of expertise in AI depends on extensive practical
experience with a broad range of AI problems. It is important that the
student come to appreciate the typically interdisciplinary nature of
such problems in so far as they often involve more than one subdomain.
The system has enough built-in functionality to enable its users to
get such experience without having to build all the supporting tools
from scratch and is intended to encourage the exploration of
subdomains and the relationships between them.


The functionality is provided though a number of modules covering
different AI application domains and associated techniques.  Each
module comprises a state-of-the-art computational theory, fully
implemented and documented, over the domain in question, together with
a representative set of running examples. PAIL is intended to support
teaching activities by providing sufficient computational material for
a user to explore the domain of a given module, and sufficient
documentation to enable him to retrieve the key literature references,
understand the architecture and specifics of the implementation, and
change the latter if desired.

The system consists of modules concerned with:

    - Theorem Proving
    - Natural Language
    - Rule-Based Inference
    - Truth Maintenance Systems
    - Learning
    - Knowledge Acquisition
    - Genetic Algorithms
    - Neural Networks

In addition, a "pool" facility is provided for sharing data across
modules.  The whole system is implemented in Common Lisp + Common
Windows in a a uniform style and this is intended to encourage the
user to design and implement interfaces between different modules.
Currently, the system will run on a SPARC station with 16+ M of memory.

Further details from Michael Rosner, IDSIA, Corso Elvezia 36, 6900
Lugano, Switzerland, email mike@idsia.ch, fax +41 91 22 89 94.
===================================================================
