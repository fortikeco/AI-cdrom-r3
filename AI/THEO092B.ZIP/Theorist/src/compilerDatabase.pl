%   Module : compilerDatabase
%   Authors: Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with facts, metas, hypothesis,
%            and askables database in their compiled format.  This database will
%            be used to stored the compiled (versus interpreter and input) forms
%            of the user's input formulas.
%
%   Currently this module is just a stub with no functionality.  See the
%   documentation in module database for a description of the Theorist
%   database modules.
%
%   The current Theorist version does not take advantage of Scott Goodwin's
%   and David Poole's compiler technology.  The next release should!

:- module(compilerDatabase, [
   ]).

sccs_id('"@(#) 11/26/91 09:39:26 compilerDatabase.pl 1.1"').

/* pred
*/
