%   Module : format
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates to redirect Quintus Prolog's format/1 predicate
%            into character lists (type chars) and atoms.
%
%   Quintus Prolog's library contains a set of routines in charsio.pl
%   that are used to execute a goal where all standard output stream
%   operations are directed to a character list (type chars).  This
%   module extends the format/[1,2] built-in predicate to be able
%   to format directly into a chars object.  This chars object can then
%   be converted into an atom when needed.  Note that the charsio.pl
%   library should have separated the byte stream object from the character
%   processing library.  A new Quintus Prolog stream, called a byte stream,
%   could have been created for general use outside of charsio.pl.
%   This byte stream object can be used in place of any Quintus Prolog
%   stream for writing to and reading from.

:- module(format, [
	formatToAtom/3,
	formatToChars/3
   ]).

:- use_module(library(charsio), [
	with_output_to_chars/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:28 format.pl 1.1"').

:- mode
	formatToAtom(+, +, -),
	formatToChars(+, +, -).

/* pred
	formatToAtom(Atom, List, Atom),
	formatToChars(Atom, List, Chars).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Formatting                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   formatToChars(+ControlString, +Arguments, -Chars)
%   is true when Arguments is interpreted by ControlString and written
%   to the character list (type chars) Chars.  See the Quintus Prolog
%   documentation of format/[1,2] for a description of ControlString and
%   Arguments.  Chars is a proper list whose elements are the characters
%   produced by writting ControlString into it.

formatToChars(ControlString, Arguments, Chars) :-
	with_output_to_chars(format(ControlString, Arguments), Chars).



%   formatToAtom(+ControlString, +Arguments, -Atom)
%   is true when Atom is a proper Prolog atom generated from the character
%   string produced by interpreting Arguments using ControlString.  See
%   the Quintus Prolog documentation of format/[1,2] for a description of
%   ControlString and Arguments.
%   If the character string produced by format/1 is too long to fit into
%   an atom (Quintus Prolog Release 3.0 limits atoms to 1023 characters) an
%   exception is raised.

formatToAtom(ControlString, Arguments, Atom) :-
	formatToChars(ControlString, Arguments, Chars),
	length(Chars, Length),
	Length < 1024,
	atom_chars(Atom, Chars).
