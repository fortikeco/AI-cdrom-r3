%   Module : interrupt
%   Authors: Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Foreign interface for Theorist interrupt handler.

:- module(interrupt, [
	establishInterruptHandler/2,
	sendInterrupt/0
   ]).

sccs_id('"@(#) 11/26/91 09:39:32 interrupt.pl 1.1"').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Interrupt handling            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

establishInterruptHandler(HelpMessage, HelpCommandList) :-
	atom(HelpMessage),
	atom(HelpCommandList),
	cEstablishInterruptHandler(HelpMessage, HelpCommandList, _, ReturnValue),
	ReturnValue =:= 0.

sendInterrupt :-
	cSendInterrupt(_, ReturnValue),
	ReturnValue =:= 0.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loading foreign files         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

foreign_file('interrupt.o', [cEstablishInterruptHandler, cSendInterrupt]).

foreign(cEstablishInterruptHandler, c, cEstablishInterruptHandler(+string, +string, -integer, [-integer])).
foreign(cSendInterrupt, c, cSendInterrupt(-integer, [-integer])).

:- load_foreign_files(['interrupt.o'], []).
