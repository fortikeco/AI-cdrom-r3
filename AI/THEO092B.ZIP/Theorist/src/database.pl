%   Module : database
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with facts, metas, hypothesis,
%            and askables database independent of the interpreted, input, or
%            compiled databases.
%
%   Currently there are four database modules: database,
%   inputDatabase, interpreterDatabase, and compilerDatabase.
%   The module, database, contains predicates generic to the other three
%   database modules.  InputDatabase is used to store input facts and
%   hypothesis.  Since Theorist must transform this information before
%   storing them, the original syntactic structure of the input data
%   is maintained in the inputDatabase.  The interpreterDatabase contains
%   transformed input formulas the Theorist interpreter manipulates.
%   The compilerModule contains transformed input formulas the Theorist
%   compiler manipulates.

:- module(database, [
	assertDatabaseItem/1,
	clearDatabaseConfirm/0,
	clearDatabaseConfirm/1,
	databaseAssert/3,
	existingDatabaseObject/2,
	inputDatabase/1,
	listDatabase/0,
	listDatabase/1,
        ppDatabase/1,
	restoreDatabase/1,
	saveDatabase/1
   ]).

:- use_module(library(basics), [
	memberchk/2
   ]),
   use_module(library(files), [
	file_exists/2
   ]),
   use_module(library(lists), [
	is_list/1
   ]),
   use_module(interpreterDatabase, [
	assertInterpreterDatabase/1,
	clearInterpreterDatabaseSection/1,
	ppInterpreterDatabaseItem/1,
	restoreInterpreterDatabase/2,
	saveInterpreterDatabase/0
   ]),
   use_module(inputDatabase, [
	assertInputDatabase/1,
	clearInputDatabaseSection/1,
	ppInputDatabaseItem/1,
	restoreInputDatabase/2,
	saveInputDatabase/0
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
% To avoid circular imports between this module and module commandDispatcher
% absolute references to commandDispatcher:inputLoop/0 are made in
% this file.  This problems stems from an error in Quintus Prolog's
% 'qpc' compiler.  The next release should fix this.
%   use_module(commandDispatcher, [
%	inputLoop/0
%   ]),
   use_module(ask, [
	yesno/2
   ]),
   use_module(variableBinding, [
        replaceVariables/3
   ]).

sccs_id('"@(#) 11/26/91 09:39:27 database.pl 1.1"').

:- mode
	assertDatabaseItem(+),
	clearDatabaseConfirm(+),
 	databaseAssert(+, +, +),
	existingDatabaseObject(+, +),
	inputDatabase(+),
	listDatabase(+),
	ppDatabase(+),
	restoreDatabase(+),
	saveDatabase(+),

	listDatabaseSections(+),
	listOneSection(+),
	clearDatabaseSections(+),
	clearOneSection(+),
	clearDatabase(+),
	confirmClear(+),
	confirmSave(+).

/* pred
	assertDatabaseItem(T),
	clearDatabaseConfirm(T),
	databaseAssert(T, T, T),
	existingDatabaseObject(T, T),
	inputDatabase(T),
	listDatabase(T),
	ppDatabase(T),
	restoreDatabase(T),
	saveDatabase(T),

	listDatabaseSections(List),
	listOneSection(+),
	clearDatabaseSections(List),
	clearOneSection(T),
	clearDatabase(T),
	confirmClear(T),
	confirmSave(T).
*/



%   assertDatabaseItem(+InputFormula)
%   is true when InputFormula is successfully asserted into the appropriate
%   databases.  As a side effect, if the current input stream is not the
%   user's input stream, a version of InputFormula is written to the
%   user's output stream.

assertDatabaseItem(fact(UserFormula, InterpreterFormula, Variables)) :- !,
	replaceVariables(UserFormula, Variables, NewUserFormula),
	UserFact = fact(NewUserFormula),
	assertInputDatabase(UserFact),
	assertInterpreterDatabase(fact(InterpreterFormula)).
assertDatabaseItem(hypothesis(Hyp, UserFormula, InterpreterFormula, Variables)) :- !,
	replaceVariables(Hyp, Variables, InputHyp),
	replaceVariables(UserFormula, Variables, NewUserFormula),
	UserHyp = hypothesis(InputHyp, NewUserFormula),
	assertInputDatabase(UserHyp),
	assertInterpreterDatabase(hypothesis(Hyp, InterpreterFormula)).
assertDatabaseItem(Item) :-		% Take care of askable and meta.
	assertInterpreterDatabase(Item).



%   saveDatabase(+RelativeFile)
%   is true if all the database predicates are successfully written
%   to File.

saveDatabase(RelativeFile) :-
	absolute_file_name(RelativeFile, File),
	(   file_exists(File, write) ->
	    confirmSave(File)
	;   true
	),
	(   current_output(OutputStream),
	    tell(File) ->
	    saveInputDatabase,
	    saveInterpreterDatabase,
	    told,
	    set_output(OutputStream)
	;   print_message(error, cannotAccessFile(File))
	).



%   restoreDatabase(+RelativeFile)
%   is true if all the clauses in File are successfully restored into
%   the Theorist database.

restoreDatabase(RelativeFile) :-
	absolute_file_name(RelativeFile, File),
	(   file_exists(File, read),
	    open(File, read, StreamIn) ->
	    restoreInputDatabase(StreamIn, LastReadTerm),
	    (   LastReadTerm \== end_of_file ->
	        restoreInterpreterDatabase(StreamIn, _)
	    ;   true
	    ),
	    close(StreamIn)
	;   print_message(error, cannotAccessFile(File))
	).



%   inputDatabase(+List)
%   is true if the files in List are successfully loaded.

inputDatabase([]).
inputDatabase([RelativeFileName|RestOfFiles]) :-
	absolute_file_name(RelativeFileName, File),
	(   file_exists(File, read) ->
	    print_message(informational, loadFile(File)),
	    seeing(Last),
	    see(File),
	    commandDispatcher:inputLoop,
	    seen,
	    see(Last)
	;   print_message(error, cannotAccessFile(File))
	),
	inputDatabase(RestOfFiles).



%   listDatabase()
%   is true if each database section from { facts, hypotheses, askables,
%   answers } is listed to the current output stream.

listDatabase :-
	theoristResource(database, databasesAtomList, AtomList),
	listDatabase(AtomList).
listDatabase(A) :-
	nl,
	(   is_list(A) ->
	    listDatabaseSections(A)
	;   listDatabaseSections([A])
	).



%   listDatabaseSections(+List)
%   is true if List is a list of any of { facts, hypotheses, askables,
%   answers } and each object in List is successfully listed on the
%   current output stream.

listDatabaseSections([]).
listDatabaseSections([H|T]) :-
	listOneSection(H),
	listDatabaseSections(T).



%   listOneSection(+Atom)
%   is true if the database section Atom is listed to the current
%   output stream.

listOneSection(Atom) :-
	theoristResource(database, databasesAtomList, AtomList),
	functor(Atom, Functor, _),
	(   memberchk(Functor, AtomList) ->
	        ppDatabase(Atom)
	;   print_message(error, unknownListOption(Atom)),
	    nl
	).



%   clearDatabaseConfirm()
%   clearDatabaseConfirm(+Section)
%   is true if each database Section from {facts, hypotheses, askables,
%   answers} is successfully removed from the Theorist database.  The user
%   is prompted for confirmation before proceeding.

clearDatabaseConfirm :-
	theoristResource(database, databasesAtomList, AtomList),
	clearDatabaseConfirm(AtomList).

clearDatabaseConfirm(A) :-
	confirmClear(A),
	clearDatabase(A).



%   clearDatabase
%   clearDatabase(+Section)
%   is true if each database Section from {facts, hypotheses, askables,
%   answers} is successfully removed from the Theorist database.

clearDatabase :-
	theoristResource(database, databasesAtomList, AtomList),
	clearDatabase(AtomList).

clearDatabase(A) :-
	(   atomic(A) ->
	    clearDatabaseSections([A])
	;   clearDatabaseSections(A)
	).



%   clearDatabaseSections(+List)
%   is true if each database section in List is successfully cleared (removed
%   from the Theorist database).  A check is made to make sure each object
%   in List is a valid section.  If not, a warning message is printed.

clearDatabaseSections([]).
clearDatabaseSections([Section|T]) :-
	theoristResource(database, databasesAtomList, AtomList),
	(   \+ memberchk(Section, AtomList) ->
	    nl, print_message(error, unknownClearOption(Section)), nl
	;   clearOneSection(Section)
	),
	clearDatabaseSections(T).



%   clearOneSection(+Section)
%   is true if Section is a valid database section and is successfully
%   cleared (retracted from the theorist database).

clearOneSection(Section) :-
	clearInputDatabaseSection(Section),
	clearInterpreterDatabaseSection(Section).



%   databaseAssert(+Module, +Head, +Body)
%   is true if (Head :- Body) is successfully asserted into the Theorist
%   database within module Module.  For now we assume that Body must
%   be the atom 'true'.  This predicate checks to make sure that Head has
%   not already been asserted into the database.  The use of the predicate
%   numbervars to ground both Head and the database term is used to resolve
%   the situation where two terms can unify but are not identical and
%   therefore each should be asserted into the database.  For example,
%       fact a(A, B, C) <- b(B, C, A).
%       fact a(A, B, C) <- b(C, B, A).
%   which are asserted into the database as:
%       fact(a(A, B, C), [b(B, C, A)]).
%       fact(a(A, B, C), [b(C, B, A])]).
%   can unify, but are not identical clauses.

databaseAssert(Module, Head, _) :-
	(   existingDatabaseObject(Module, Head) -> true
	;   \+ \+ Module:assertz((Head :- true)) % Undo compiler bindings
	).



%   existingDatabaseObject(+Object)
%   is true if Object is already asserted into the database.

existingDatabaseObject(Module, Object) :-
	numbervars(Object, 0, _),
	functor(Object, Functor, ArgLength),
	functor(TempObject, Functor, ArgLength),
	call(Module:TempObject),
	numbervars(TempObject, 0, _),
	TempObject == Object.



%   ppDatabase(+DatabaseFunctor)
%   is true if DatabaseFunctor specifies one of {facts, hypotheses, askable,
%   answers, metas} and the specified database set is pretty printed to the
%   current output.  If DatabaseFunctor represents a particular database entry,
%   it is pretty printed to the current output.

ppDatabase(DatabaseFunctor) :-
	(   ppInputDatabaseItem(DatabaseFunctor) ->
	    true
	;   ppInterpreterDatabaseItem(DatabaseFunctor)
	).



%   confirmClear(+A)
%   is true if the user wants to clear the database designated by
%   A.  A can be an atom or list of atoms.

confirmClear(A) :-
	theoristResource(messageString, clearString, Astring),
	yesno(Astring, [A]).



%   confirmSave(+F)
%   is true if the user confirms a file overwrite.

confirmSave(F) :-
	theoristResource(messageString, overwriteString, Astring),
	yesno(Astring, [F]).
