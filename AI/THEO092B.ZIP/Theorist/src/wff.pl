%   Module : wff
%   Authors: George Ferguson, Scott Goodwin, Pat Fitzsimmons,
%            Abdul Sattar, Bonita Wong.
%   Updated: 11/26/91
%   Defines: Conversions of PC well formed formulas (wffs) to clause form and of
%            clauses to Prolog rules/facts.  Also defines other wff manipulation
%            predicates.

:- module(wff, [
	convertToClauses/2,
	convertToProlog/2,
	negate/2,
	ppWff/1,
	ppWithLetterVars/3
   ]).

:- use_module(library(strings), [
	gensym/2
   ]),
   use_module(term, [
	replace/4
   ]).

sccs_id('"@(#) 11/26/91 09:39:39 wff.pl 1.1"').

:- mode
	convertToClauses(+, -),
	convertToProlog(+, -),
	negate(?, ?),
	ppWff(+),
	ppWithLetterVars(+, +, +),

	ppWff(+, +),
	step1(+, -),
	step2(+, -),
	step4(+, +, -),
	step5(+, -),
	step5a(+, +, -, -),
	step5b(+, +, -),
	step6(+, -),
	step7(+, -),
	step8(+, -),
	genFunc(+, -),
	makeRule(+, -),
	makeBody(+, -),
	ppWff(+, +).

/* pred
	convertToClauses(T, T),
	convertToProlog(T, T),
	negate(T, T),
	ppWff(T),
	ppWithLetterVars(T, T, T),

	ppWff(T, T)
	step1(T, T),
	step2(T, T),
	step4(T, T, T),
	step5(T, T),
	step5a(T, T, T, T),
	step5b(T, T, T),
	step6(T, T),
	step7(T, T),
	step8(T, T),
	genFunc(T, T),
	makeRule(T, T),
	makeBody(T, T),
	ppWff(T, T).
*/


%   convertToClauses(+Wff, -List)
%   is true when Wff is 1st order PC wff in prefix form and List is the list
%   of clauses corresponding to it.
%   From Nilsson(1980), p.146-149.

convertToClauses(Wff, List) :-
	step1(Wff, Wff1),
	step2(Wff1, Wff2),
	% step3( Standardize Variables Apart ),
	step4(Wff2, [], Wff3),
	step5(Wff3, Wff4),
	step6(Wff4, Wff5),
	step7(Wff5, Wff6),
	step8(Wff6, List),
	!.



%   step1 :  Implications out.

step1('$IFF'(X1, Y1), '$AND'(X2, Y2)) :-
	step1('$IMP'(X1, Y1), X2),
	step1('$IMP'(Y1, X1), Y2),
	!.
step1('$IMP'(X1, Y1), '$OR'('$NOT'(X2), Y2))  :-
	step1(X1, X2),
	step1(Y1, Y2),
	!.
step1('$BIMP'(X1, Y1), '$OR'('$NOT'(Y2), X2))  :-
	step1(X1, X2),
	step1(Y1, Y2),
	!.
step1('$AND'(X1, Y1), '$AND'(X2, Y2)) :-
	step1(X1, X2),
	step1(Y1, Y2),
	!.
step1('$OR'(X1, Y1), '$OR'(X2, Y2)) :-
	step1(X1, X2),
	step1(Y1, Y2),
	!.
step1('$NOT'(X1), '$NOT'(X2)) :-
	step1(X1, X2),
	!.
step1('$ALL'(X, F1), '$ALL'(X, F2)) :-
	step1(F1, F2),
	!.
step1('$EX'(X, F1), '$EX'(X, F2)) :-
	step1(F1, F2),
	!.
step1(X, X).



%   step2 : Negations in.

step2('$NOT'('$AND'(X1, Y1)), '$OR'(X2, Y2)) :-
	step2('$NOT'(X1), X2),
	step2('$NOT'(Y1), Y2),
	!.
step2('$NOT'('$OR'(X1, Y1)), '$AND'(X2, Y2)) :-
	step2('$NOT'(X1), X2),
	step2('$NOT'(Y1), Y2),
	!.
step2('$NOT'('$NOT'(F1)), F2) :-
	step2(F1, F2),
	!.
step2('$NOT'('$ALL'(X, F1)), '$EX'(X, F2)) :-
	step2('$NOT'(F1), F2),
	!.
step2('$NOT'('$EX'(X, F1)), '$ALL'(X, F2)) :-
	step2('$NOT'(F1), F2),
	!.
step2('$AND'(X1, Y1), '$AND'(X2, Y2)) :-
	step2(X1, X2),
	step2(Y1, Y2),
	!.
step2('$OR'(X1, Y1), '$OR'(X2, Y2)) :-
	step2(X1, X2),
	step2(Y1, Y2),
	!.
step2('$NOT'(X1), '$NOT'(X2)) :-
	step2(X1, X2),
	!.
step2('$ALL'(X, F1), '$ALL'(X, F2)) :-
	step2(F1, F2),
	!.
step2('$EX'(X, F1), '$EX'(X, F2)) :-
	step2(F1, F2),
	!.
step2(X, X).



%   step4 : Skolemize and record definitions.

step4('$ALL'(X, F1), NestedVars, '$ALL'(X, F2)) :-
	step4(F1, [X|NestedVars], F2),
	!.
step4('$EX'(X, F1), NestedVars, F3) :-
	genFunc(NestedVars, Fsk),
	replace(X, F1, Fsk, F2),
	step4(F2, NestedVars, F3),
	!.
step4('$AND'(X1, Y1), N, '$AND'(X2, Y2)) :-
	step4(X1, N, X2),
	step4(Y1, N, Y2),
	!.
step4('$OR'(X1, Y1), N, '$OR'(X2, Y2)) :-
	step4(X1, N, X2),
	step4(Y1, N, Y2),
	!.
step4('$NOT'(X1), N, '$NOT'(X2)) :-
	step4(X1, N, X2),
	!.
step4(X, _, X).



%   step5 : Convert to prenex form.

step5(F1, F2) :-
	step5a(F1, [], L, Ft),
	step5b(L, Ft, F2),
	!.



%   step5a(F1, Li, Lo, F2)
%   is true when F1 is some nested wff and L1 is a list of universally
%   quantified variables ALREADY removed from F1, and L2 a list of all
%   the other universally quantified variables removed to get F2 which
%   has no '$ALL's.

step5a('$ALL'(X, F1), L1, [X|L2], F2) :-
	step5a(F1, L1, L2, F2),
	!.
step5a('$AND'(X1, Y1), Li, Lo, '$AND'(X2, Y2)) :-
	step5a(X1, Li, Lt, X2),
	step5a(Y1, Lt, Lo, Y2),
	!.
step5a('$OR'(X1, Y1), Li, Lo, '$OR'(X2, Y2)) :-
	step5a(X1, Li, Lt, X2),
	step5a(Y1, Lt, Lo, Y2),
	!.
step5a('$NOT'(X1), Li, Lo, '$NOT'(X2)) :-
	step5a(X1, Li, Lo, X2),
	!.
step5a(X, L, L, X).



%   step5b(L, F1, F2)
%   is true when L is a list of variables that was created when the
%   '$ALL' functions were stripped to get F1, and F2 is the nested
%   wff which has all those '$ALL' functions in the front of F1.

step5b([], F, F ) :- !.
step5b([H|L], F1, '$ALL'(H,F2)) :- step5b( L,F1,F2 ).



%   step6 : convert to conjunctive normal form.

step6('$OR'(X1, '$AND'(Y1, Z1)), '$AND'(W1, W2)) :-
	step6(Y1, Y2),
	step6(Z1, Z2),
	step6('$OR'(X1, Y2), W1),
	step6('$OR'(X1, Z2), W2),
	!.
step6('$OR'('$AND'(X1, Y1), Z1), '$AND'(W1, W2)) :-
	step6(X1, X2),
	step6(Y1, Y2),
	step6('$OR'(X2, Z1), W1),
	step6('$OR'(Y2, Z1), W2),
	!.
step6('$AND'(X1, Y1), '$AND'(X2, Y2)) :-
	step6(X1, X2),
	step6(Y1, Y2),
	!.
step6('$OR'(X1, Y1), '$OR'(X2, Y2)) :-
	step6(X1, X2),
	step6(Y1, Y2),
	!.
step6('$NOT'(X1), '$NOT'(X2)) :-
	step6(X1, X2),
	!.
step6('$ALL'(X, F1), '$ALL'(X, F2)) :-
	step6(F1, F2),
	!.
step6(X, X).



%   step7 : Drop universal quantifiers.

step7('$ALL'(_, F1), F2) :-
	step7(F1, F2),
	!.
step7('$AND'(X1, Y1), '$AND'(X2, Y2)) :-
	step7(X1, X2),
	step7(Y1, Y2),
	!.
step7('$OR'(X1, Y1), '$OR'(X2, Y2)) :-
	step7(X1, X2),
	step7(Y1, Y2),
	!.
step7('$NOT'(X1), '$NOT'(X2)) :-
	step7(X1, X2),
	!.
step7(X, X).



%   step8 : Break into list of disjunctions.

step8('$AND'(X, Y), L) :-
	step8(X, L1),
	step8(Y, L2),
	append(L1, L2, L),
	!.
step8(X, [X]).



%   genFunc(?V, ?Fsk)
%   is true if Fsk is a function with functor of the form '$Fsk#'
%   (# = some digit) and arguments V.

genFunc(V, Fsk) :-
	gensym('$Fsk', Funct),
	Fsk =.. [Funct|V].



%   convertToProlog(+C, -P)
%   is true when C is a list of general clauses (disjunctions of literals
%   of form 'X' or '$NOT(X)') and P is the corresponding list of Prolog
%   fact/rules.

convertToProlog([], []) :- !.
convertToProlog([C|T], [R1|R2]) :-
	makeRule(C, R1),
	convertToProlog(T, R2).



%   makeRule(C,R)
%   is true when C is a disjunction of literals and R is the list whose
%   only member is the Prolog rule/fact corresponding to this. The head
%   of the rule is the right argument of the outermost '$OR' and the tail
%   is the negations of all the other disjuncts. In fact, the order should
%   be irrelevant IF CONTRAPOSITIVES ARE MADE LATER.  The rule is represented
%   by a list [H|T] where H is the antecedent and T a list of consequents.

makeRule('$OR'(X,Y), [Y|B]) :-
	makeBody(X, B),
	!.
makeRule(X, [X]).



%   makeBody(?F, ?B)
%   is true when F is a disjunction of literals (nested '$OR's) and B
%   is the list [b1,b2,...,bn] such that each bi corresponds to the
%   negation of a literal in F. That is  $OR(b1,$OR(b2,...)) becomes 
%   $AND(n(b1), $AND(n(b2)...)) which we represent as a list for use in
%   `fact(H, B)'.

makeBody('$OR'(X, Y), B) :-
	makeBody(X, B1),
	makeBody(Y, B2),
	append(B1, B2, B),
	!.
makeBody(L, [NL]) :-
	negate(L, NL).	% form Theorist negation



%   negate(?G, ?NG)
%   is true when NG is the Theorist-negation of G, $NOT(G).

negate('$NOT'(G), G) :-
	\+ G = '$NOT'(_), !.
negate(G, '$NOT'(G)) :-
	\+ G = '$NOT'(_).



%   ppWithLetterVars(+Item, Module, PrintPredicate)
%   is true if Item is pretty printed to the current output stream using
%   the PrintPredicate from Module as the printing mechanism.  Make sure
%   all variables in Item will be printed with letters.

ppWithLetterVars(Item, Module, PrintPredicate) :-
        (   numbervars(Item, 0, _),             % Make trace variables come out
            Call =.. [PrintPredicate, Item],    % as letters for easier reading.
            call(Module:Call),                  % Print Item.
            fail                                % Undo numbervars/3 bindings.
        ;   true
        ).



%   ppWff(+Formula)
%   is true if Formula is pretty printed to the current output stream
%   starting at column Column and ending at NewColumn.

ppWff('$NOT'(G)) :-
	write('~('),
	ppWff(G),
	write(')'), !.
ppWff('$AND'(G1, G2)) :-
	ppWff(G1),
	write(' & '),
	ppWff(G2), !.
ppWff('$OR'(G1, G2)) :-
	ppWff(G1),
	write(' | '),
	ppWff(G2), !.
ppWff('$IFF'(G1, G2)) :-
	ppWff(G1),
	write(' <-> '),
	ppWff(G2), !.
ppWff('$IMP'(G1, G2)) :-
	ppWff(G1),
	write(' -> '),
	ppWff(G2), !.
ppWff('$BIMP'(G1, G2)) :-
	ppWff(G1),
	write(' <- '),
	ppWff(G2), !.
ppWff('$ALL'(X, G)) :-
	write('all '),
	write(X),
	write(' '),
	ppWff(G),
	!.
ppWff('$EX'(X, G)) :-
	write('ex '),
	write(X),
	write(' '),
	ppWff(G),
	!.
ppWff([A, B|T]) :-
	ppWff(A),
	write(' & '),
	ppWff([B|T]), !.
ppWff([A]) :-
	ppWff(A), !.
ppWff(X) :-
	write(X).
