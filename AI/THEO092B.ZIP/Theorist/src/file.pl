%   Module : file
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with file access not available
%            in the Quintus library.
%
%   The current version of these predicates "slup" an entire
%   file into memory and writes the edited file out to disk.
%   This is extremely inefficient and will be changed in the next
%   release.
%
%   See file.c for more details.

:- module(file, [
	freeFileCharPtr/1,
	readFileIntoCharPtr/2,
	writeCharPtrIntoFile/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:27 file.pl 1.1"').

:- mode
	freeFileCharPtr(+),
	readFileIntoCharPtr(+, -),
	writeCharPtrIntoFile(+, +).

/* pred
	FileCharPtr ::= char_ptr(Address)

	freeFileCharPtr(FileCharPtr),
	readFileIntoCharPtr(String, FileCharPtr),
	writeCharPtrIntoFile(String, FileCharPtr).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialization-release        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   readFileIntoCharPtr(+FileName, -FileCharPtr)
%   is true when the text in FileName is "slurpped" into
%   a string and returned as a FileCharPtr structure.  Note
%   that this is an extremely inefficient hack.  Large text
%   files require large amounts of memory - but this will
%   do until more time is allocated to building a "real"
%   text editor.

readFileIntoCharPtr(FileName, char_ptr(Address)) :-
	cReadFileIntoCharPtr(FileName, _ErrorNumber, Address),
	Address =\= 0.



%   writeCharPtrIntoFile(+FileName, +CharPtr)
%   is true when the string pointed to by CharPtr is
%   written to the disk file FileName.  If FileName
%   already exists, it is overwritten.  Fail if FileName
%   does not exist.

writeCharPtrIntoFile(FileName, char_ptr(Address)) :-
	integer(Address),
	Address =\= 0,
	cWriteCharPtrIntoFile(FileName, Address, _ErrorNumber, ReturnValue),
	ReturnValue =:= 0.



%   freeFileCharPtr(+FileCharPtr)
%   is true when the memory block containing the text of
%   a file is release back to the system.

freeFileCharPtr(char_ptr(Address)) :-
	integer(Address),
	cFreeFileCharPtr(Address, _ErrorNumber, ReturnValue),
	ReturnValue =:= 0.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loading foreign files         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

foreign_file('file.o', [cReadFileIntoCharPtr, cWriteCharPtrIntoFile, cFreeFileCharPtr]).
foreign(cReadFileIntoCharPtr, c, cReadFileIntoCharPtr(+atom, -integer, [-address(char)])).
foreign(cWriteCharPtrIntoFile, c, cWriteCharPtrIntoFile(+atom, +address(char),
							-integer, [-integer])).
foreign(cFreeFileCharPtr, c, cFreeFileCharPtr(+address(char), -integer, [-integer])).

:- load_foreign_files(['file.o'], []).
