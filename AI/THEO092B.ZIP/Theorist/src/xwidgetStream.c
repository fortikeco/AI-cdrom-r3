/*  File   : widgetStream.c
    Author : Daniel Lanovaz
    Origin : March 1991
    Update : 11/26/91
    Purpose: Defines C functions for the widget stream (input/output) functions.

    See the documentation in xwidgetStream.pl for more details.
*/

#ifndef lint
  static  char SCCSid[] = "@(#) 11/26/91 09:39:12 xwidgetStream.c 1.1";
#endif/*lint*/

#include <X11/Intrinsic.h>
#include "quintus.h"

#define BufferSize 256

typedef struct {
	QP_stream      qpinfo;
	Widget         widget;
	char          *callbackPredString;
	char          *callbackModuleString;
	int            lastReadSize;
	unsigned char  buffer[BufferSize + sizeof(long int)];
} WidgetStream;

#define CoerceWidgetStream(x) ((WidgetStream *) (x))

static int
CopyString(source, dest, destMaxLen, length)
unsigned char *source;
unsigned char *dest;
int            destMaxLen;
int           *length;
{
	int len = 0;

	if (source && dest && length) {
		while (*source && len < destMaxLen) {
			*dest++ = *source++;
			++len;
		}
		*dest   = '\0';
		*length = len;
		return QP_SUCCESS;
	}

	if (length) *length = 0;
	return QP_ERROR;
}

static int
WidgetStreamRead(qpstream, bufferPtr, sizePtr)
QP_stream      *qpstream;
unsigned char **bufferPtr;
long int       *sizePtr;
{
	WidgetStream  *widgetStream = CoerceWidgetStream(qpstream);
	int            result;
	int            length;
	unsigned char *charPtr;
	unsigned char *buffer       = (unsigned char *) *bufferPtr;
	QP_pred_ref    prologQuery  = QP_predicate(widgetStream->callbackPredString,
							2, widgetStream->callbackModuleString);

	widgetStream->qpinfo.magic.byteno += widgetStream->lastReadSize;
	if (prologQuery == (QP_pred_ref) QP_ERROR) {
		widgetStream->qpinfo.errno = QP_errno;
		return QP_ERROR;
	}

	result = QP_query(prologQuery, widgetStream->widget, &charPtr);
	if (result != QP_SUCCESS) {
		widgetStream->qpinfo.errno = QP_errno;
		return QP_ERROR;
	}

	if (CopyString(charPtr, buffer, BufferSize, &length) == QP_ERROR) {
		return QP_ERROR;
	}

	/* Note that memory for the character pointer, charPtr, was allocated
	 * from within the Prolog predicate prologQuery.  That predicate
	 * assumes the character pointer is freed within this function!
	 */
	QP_free(charPtr);

	if (length < BufferSize) {
		buffer[length++] = '\n';
		buffer[length]   = '\0';
	}

	widgetStream->lastReadSize = length;
	*sizePtr   = length;
	*bufferPtr = widgetStream->buffer;

	if (buffer[length-1] == '\n') {
		return QP_FULL;
	} else {
		return QP_PART;
	}
}

static int
WidgetStreamWrite(qpstream, bufferPtr, sizePtr)
QP_stream      *qpstream;
unsigned char **bufferPtr;
long int       *sizePtr;
{
	WidgetStream *widgetStream = CoerceWidgetStream(qpstream);
	int           len          = (int) *sizePtr;
	int           result;
	char         *buffer       = (char *) *bufferPtr;
	QP_pred_ref   prologQuery  = QP_predicate(widgetStream->callbackPredString,
							2, widgetStream->callbackModuleString);

	if (len == 0) {
		buffer[0]  = '\0';
		*sizePtr   = widgetStream->qpinfo.max_reclen;
		*bufferPtr = widgetStream->buffer;
		return QP_SUCCESS;
	}

	/* This should never happen as the length of widgetStream->buffer should never
	 * be greater than BufferSize.   However, if this situation does arise, truncate
	 * the output length.  A better solution to to write the output buffer in
	 * BufferSize chunks.
	 */
	if (len > BufferSize) len = BufferSize;

	buffer[len] = '\0';
	if (prologQuery == (QP_pred_ref) QP_ERROR) {
		widgetStream->qpinfo.errno = QP_errno;
		return QP_ERROR;
	}

	result = QP_query(prologQuery, widgetStream->widget, widgetStream->buffer);
	if (result != QP_SUCCESS) {
		widgetStream->qpinfo.errno = QP_errno;
		return QP_ERROR;
	}

	widgetStream->qpinfo.magic.byteno += len;
	*sizePtr   = widgetStream->qpinfo.max_reclen;
	*bufferPtr = widgetStream->buffer;
	return QP_SUCCESS;
}

static int
WidgetStreamClose(qpstream)
QP_stream *qpstream;
{
	WidgetStream *widgetStream = CoerceWidgetStream(qpstream);

	(void) QP_free(widgetStream);
	return QP_SUCCESS;
}

QP_stream *
cCreateWidgetOutputStream(widget, callbackPredicate, callbackModule, errorNumber)
Widget  widget;
QPatom  callbackPredicate;
QPatom  callbackModule;
int    *errorNumber;
{
	WidgetStream *stream;
	QP_stream    *option;
	char         *callbackPredString   = QP_string_from_atom(callbackPredicate);
	char         *callbackModuleString = QP_string_from_atom(callbackModule);

	*errorNumber = 0;

	if ((stream = (WidgetStream *) QP_malloc(sizeof(WidgetStream)))
		== ((WidgetStream *) 0)) {
		*errorNumber = QP_errno;
		return QP_NULL_STREAM;
	}

	option = &stream->qpinfo;
	QU_stream_param("", QP_WRITE, QP_FMT_UNKNOWN, option);
/*	QU_stream_param("", QP_WRITE, QP_DELIM_TTY, option); */
	option->max_reclen  = BufferSize;
/**	option->max_reclen  = 0; **/	/* Unbuffered output */
/**	option->flush_type  = QP_FLUSH_FLUSH; **/
	option->trim        = 0;
	option->line_border = '\n';
	option->format      = QP_DELIM_TTY; 
	option->seek_type   = QP_SEEK_ERROR;
	option->write       = WidgetStreamWrite;
	option->flush       = WidgetStreamWrite;
	option->close       = WidgetStreamClose;

	QP_prepare_stream(&stream->qpinfo, stream->buffer);

	if (QP_register_stream(&stream->qpinfo) == QP_ERROR) {
		(void) stream->qpinfo.close(&stream->qpinfo);
		*errorNumber = QP_errno;
		return QP_NULL_STREAM;
	}

	stream->widget               = widget;
	stream->callbackPredString   = callbackPredString;
	stream->callbackModuleString = callbackModuleString;

/** Art M.  QP_add_tty ***/
	(void) QP_add_tty(&stream -> qpinfo, "xwin");

	return (QP_stream *) stream;
}

QP_stream *
cCreateWidgetInputStream(widget, callbackPredicate, callbackModule, errorNumber)
Widget  widget;
QPatom  callbackPredicate;
QPatom  callbackModule;
int    *errorNumber;
{
	WidgetStream *stream;
	QP_stream    *option;
	char         *callbackPredString   = QP_string_from_atom(callbackPredicate);
	char         *callbackModuleString = QP_string_from_atom(callbackModule);

	*errorNumber = 0;

	if ((stream = (WidgetStream *) QP_malloc(sizeof(WidgetStream)))
		== ((WidgetStream *) 0)) {
		*errorNumber = QP_errno;
		return QP_NULL_STREAM;
	}

	option = &stream->qpinfo;
	QU_stream_param("", QP_READ, QP_FMT_UNKNOWN, option);
/**	QU_stream_param("", QP_READ, QP_DELIM_TTY, option); **/
	option->max_reclen  = BufferSize;
/**	option->flush_type  = QP_FLUSH_FLUSH; **/
	option->trim        = 0;
	option->line_border = '\n';
	option->format      = QP_DELIM_TTY;
	option->seek_type   = QP_SEEK_ERROR;
	option->read        = WidgetStreamRead;
	option->flush       = WidgetStreamRead;
	option->close       = WidgetStreamClose;

	QP_prepare_stream(&stream->qpinfo, stream->buffer);

	if (QP_register_stream(&stream->qpinfo) == QP_ERROR) {
		(void) stream->qpinfo.close(&stream->qpinfo);
		*errorNumber = QP_errno;
		return QP_NULL_STREAM;
	}

	stream->widget               = widget;
	stream->callbackPredString   = callbackPredString;
	stream->callbackModuleString = callbackModuleString;

/** Art M.  QP_add_tty ***/
	(void) QP_add_tty(&stream -> qpinfo, "xwin");

	return (QP_stream *) stream;
}

/* */
