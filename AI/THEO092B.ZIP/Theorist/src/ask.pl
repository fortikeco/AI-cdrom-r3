%   Module : ask
%   Authors: Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Yes/No questions with formatted prompts.
%   SeeAlso: library(ask)
%
%   Adapted from code written by Richard A. O'Keefe - library(ask) of Quintus
%   Prolog version 2.4.2, Quintus Computer Systems, Inc.  This is virtually
%   an exact copy of selected library(ask) and library(prompt) predicates
%   with an additional Format argument added where necessary.
%
%   The proper way of structuring this module is to rewrite both library(ask)
%   and library(prompt) to be able to handle formatted prompts.  Since we wish
%   to keep Theorist as small as possible, we opted to implement the minimum
%   to get formatted yes/no prompts.
%
%   This file has been modified slightly until XTheorist can re-map Quintus
%   Prolog's standard input and output streams to the streams that feed the
%   command pane's text widget.  The Quintus tty... predicates always write or read
%   to the standard output - we wish this to be our text widget defined
%   streams.  For now, we have changed all tty predicates to standard i/o
%   predicates.

:- module(ask, [
	ask/3,
	askAndAcceptNewline/3,
	yesno/2
   ]).

:- use_module(library(ctypes), [
	is_endline/1,
	is_graph/1,
	is_newline/1,
	to_lower/2
   ]),
   use_module(library(lists), [
	is_list/1
   ]).

sccs_id('"@(#) 11/26/91 09:39:23 ask.pl 1.1"').

:- mode
	ask(+, +, ?),
	askAndAcceptNewline(+, +, ?),
	yesno(+, +),

	promptedChar(+, +, ?),
	formattedPrompt(+, +),
	formattedPrompt_(+, +).

/* pred
	ask(T, T, T),
	askAndAcceptNewline(T, T, T),
	yesno(T, T),

	promptedChar(T, T, T),
	formattedPrompt(T, T),
	formattedPrompt_(T, T).
*/

%   ask(+Question, +Format, ?Answer)
%   displays the Question on the  terminal  and  reads  a  one-character
%   answer  from the terminal.  But because you normally have to type "X
%   <CR>" to get the computer to attend to you, it skips to the  end  of
%   the line.   The character returned will have ASCII code in the range
%   33..126 (that is, it won't be a space or a control character).

ask(Question, Format, Answer) :-
        repeat,
            promptedChar(Question, Format, Char),
            is_graph(Char),
        !,
        Answer = Char.



%   askAndAcceptNewline(+Question, +Format, ?Answer)
%   is exactly the same as ask/3 except that newline characters can be
%   returned.

askAndAcceptNewline(Question, Format, Answer) :-
        repeat,
            promptedChar(Question, Format, Char),
            ( is_graph(Char) ; is_newline(Char) ),
        !,
        Answer = Char.



%   yesno(+Question, +Format)
%   asks the user Question, and succeeds if the answer is y or Y, fails if the
%   answer is n or N, and repeats Question if it is anything else.  Format is a
%   list used to fill in the format characters in Question - see format/2 in the
%   Quintus Prolog Reference Manual.

yesno(Question, Format) :-
	repeat,
	    promptedChar(Question, Format, Char),
	    to_lower(Char, Answer),
	    (   Answer =:= "y" -> !, true
	    ;   Answer =:= "n" -> !, fail
	    ;   formattedPrompt('Please answer Yes or No followed by RETURN', []), nl, %ttynl,
	        fail
	    ).


%   promptedChar(+Prompt, +Format, ?Char)
%   writes Prompt to the terminal and reads a line of characters from the
%   terminal.  Prompt is formatted using Format.  The character is returned
%   in Char.  If Prompt is a list of lists, Format must be a list of format
%   lists.

promptedChar(Prompt, Format, Char) :-
	formattedPrompt(Prompt, Format),
	get0(C1), %ttyget0(C1),
	(   is_endline(C1)
	;   repeat,
	        get0(C2), %ttyget0(C2),
	        is_endline(C2)
	), !,
	Char = C1.


%   prompt(+ListOrPrompt, +Format)
%   writes a prompt (or a list of terms making up a prompt) to the terminal,
%   starting at the beginning of a new line, and forcing the output out
%   without adding a newline.  If ListOrPrompt is a list, Format is a list
%   of format lists, otherwise Format is simply a format list.  Note that a
%   list of character codes will NOT be printed as it it were a string.
%   This may be reconsidered.

formattedPrompt(ListOrPrompt, Format) :-
	%current_output(OldTell), set_output(user_output),
	    formattedPrompt_(ListOrPrompt, Format),
	    current_output(OldTell), % added!
	    flush_output(OldTell). %ttyflush,
	%set_output(OldTell).

formattedPrompt_([], _) :- !.
formattedPrompt_([Head|Tail], [Format|RestOfFormats]) :- !,
	(   is_list(Format) ->
	    formattedPrompt_(Head, Format)
	;   formattedPrompt_(Head, [])		% This should be an error, but
	),					% we use a default null list.
	formattedPrompt_(Tail, RestOfFormats).
formattedPrompt_([Head|Tail], _Format) :- !,
	formattedPrompt_(Head, []),
	formattedPrompt_(Tail, []).
formattedPrompt_(Ch, _) :-
	integer(Ch), Ch >= 0, Ch =< 255, !,
	put(Ch).
formattedPrompt_(Other, Format) :-
	(   is_list(Format) ->
	    format(Other, Format)
	;   format(Other, [])			% This should be an error, but
	).					% we use a default null list.
