%   Module : xcommandPane
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Generic command pane.
%
%   A CommandPane is a paned widget consisting of two panes:
%   a history pane and a command pane.  The History pane is a
%   list of the last <n> commands entered into the command
%   pane.  The command pane is a text entry window that is specifically
%   designed to contain a user prompt.  It restricts text entry
%   to a command prompt region.  Commands entered into this region
%   are placed into the history list pane.  The user cannot place
%   the cursor before the current prompt region, nor can the user
%   erase the prompt or any text before the current prompt region.
%   However, it is possible to copy text from before the current
%   prompt.
%
%   The command pane is divided into two sections:
%
%       |---------------------------------------------|
%       | History Pane                                |
%       -----------------------------------------------
%       | Command Pane                                |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       -----------------------------------------------
%
%       History pane: Contains a list of the most recent user
%                 level commands.  Clicking on one of these
%                 commands places it into the current prompt
%                 line.  Double clicking re-executes the command.
%       Command pane: Contains a text entry window for the user
%                 to enter XTheorist commands.
%
%   The following resources are supported (not yet implemented):
%
%   Name                        Type                    Default
%   ----                        ----                    -------
%   xmNpromptString             String                  '>'
%   xmNhistoryItems             List                    []
%   xmNhistoryMaxItems          Integer                 100
%   xmNhistoryVisibleItemCount  Integer                 8
%   xmNinterruptProc            Proc                    commandInterrupt
%
%
%   The Command pane has associated with it a set of input and output
%   streams.  The output stream is used to write text into the pane.
%   The input stream is used as a sink for each command that is
%   successfully entered.
%
%       --------------------------
%       | Command Pane           |
%       |                        |
%       |                        | <- OutputStream <- Prolog's standard output
%       |                        | -> InputStream -> Prolog's standard input
%       -------------------------|
%
%   *NOTE* The character pointer returned by xmTextWidget:xmTextGetSelection/4
%	must be freed by the application.  Within this file,
%	xmTextGetSelection/4 is called when reading text from the XmText
%	widget.  commandPaneActivate/3 calls xmTextGetSelection.  However,
%	the string is not freed within this predicate because the CharPtr
%	result must be passed back into the calling C function.  It is
%	within this C function that the string is freed.  The second
%	place where xmTextGetSelection/4 is called, doneCommandInput/0,
%       frees the CharPtr result.
%
%% NOTE: (paraphrased From email with Quintus corp. technical support)
%%	The representation of events in proxt was changed from release
%%	3.0 and 3.1 in Quintus prolog.  Most people are not bothered
%%	by that if they use "library(xif)" however, here we are doing
%%	something more sophisticated which is not covered by that.
%%	Two changes are necessitated, both marked with (1) in comments.
%%	This will be fixed for the next release of Quintus prolog --
%%	therefore, those changes can probably be un-done at that
%%	time.						...art mulder

:- module(xcommandPane, [
	createCommandPane/6,
	executeCommand/2
   ]).

:- use_module(library(proxt), [
	proxtStringToCharPtr/2,
	xmCreatePanedWindow/4,
	xmCreateScrolledList/4,
	xmCreateScrolledText/4,
	xmListAddItemUnselected/3,
	xmListDeselectPos/2,
	xmListDeletePos/2,
	xmListSetBottomPos/2,
	xmStringFree/1,
	xmTextGetLastPosition/2,
	xmTextReplace/4,
	xmTextSetInsertionPosition/2,
	xtAddActions/1,
	xtAddCallback/4,
	xtDispatchEvent/1,
	xtManageChild/1,
	xtNextEvent/1,
	xtOverrideTranslations/2,
	xtParseTranslationTable/2
   ]),
   use_module(library(proxl), [
	dispatch_event/3
   ]),
   use_module(library(structs)),	%% (1)
   use_module(library(critical), [
	critical/1
   ]),
   use_module(library(strings), [
	gensym/2
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(window, [
	rootWidget/2
   ]),
   use_module(stream, [
	registerTtyStream/2
   ]),
   use_module(xwidgetStream, [
	createWidgetInputStream/4,
	createWidgetOutputStream/4
   ]),
   use_module(xmTextWidget, [
	xmTextAddMotionVerifyCallback/2,
	xmTextAddModifyVerifyCallback/2,
	xmTextFreeSelection/1,
	xmTextGetSelection/4,
	xmTextShowPosition/2
   ]),
   use_module(parser, [
	getCommand/1
   ]),
   use_module(interrupt, [
	sendInterrupt/0
   ]),
   use_module(xstring, [
	charPtrToXmString/2,
	xmStringToCharPtr/2
   ]).

:- dynamic
	% commandWidget(Widget, Shell, WidgetType, WidgetName)
	% is true when Widget is a widget of WidgeType named WidgetName for
	% the command pane represented by Shell.  This predicate is
	% used to maintain global access to important Widgets.
	commandWidget/4.

:- extern(commandPaneMotionVerify(+address('Widget'), +integer, +integer, +integer, +integer)).
:- extern(commandPaneModifyVerify(+address('Widget'), +integer, +integer, +integer, +integer)).
:- extern(commandStreamInput(+address('Widget'), -address(char))).
:- extern(commandStreamOutput(+address('Widget'), +address(char))).

sccs_id('"@(#) 11/26/91 09:39:42 xcommandPane.pl 1.1"').

:- mode
	createCommandPane(+, +, +, -, -, -).

/* pred
	createCommandPane(Widget, Atom, AttributeList, Widget, Stream, Stream).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   createCommandPane(+Parent, +Name, +AttributeList, -CommandPane, -InputStream,
%                     -OutputStream)
%   is true when CommandPane is the newly created command with Parent and
%   name Name.  The command pane has attributes Attributes.

createCommandPane(Parent, Name, AttributeList, CommandPane, InputStream, OutputStream) :-
	xmCreatePanedWindow(Parent, Name, AttributeList, CommandPane),
	xtManageChild(CommandPane),
	addHistoryPane(CommandPane),
	addCommandPane(CommandPane, InputStream, OutputStream).

addHistoryPane(Commands) :-
	theoristResource(widgetName, commandPaneHistoryPane, HistoryPaneName),
	xmCreateScrolledList(Commands, HistoryPaneName,
				[xmNselectionPolicy(xmSINGLE_SELECT)],
				HistoryPane),
	xtManageChild(HistoryPane),
	xtAddCallback(HistoryPane, xmNsingleSelectionCallback, xcommandPane:historyPaneSelection, _),
	rootWidget(Commands, Shell),
	assert((commandWidget(HistoryPane, Shell, widget, historyPane) :- !)).

addCommandPane(Commands, InputStream, OutputStream) :-
	theoristResource(widgetName, commandPaneCommandPane, CommandPaneName),
	xmCreateScrolledText(Commands, CommandPaneName, [xmNeditMode(xmMULTI_LINE_EDIT)], CommandPane),
	xtManageChild(CommandPane),
	xtAddActions([action(commandInterrupt,commandInterrupt, _)]),
	proxtStringToCharPtr('<Key>Return: activate()
Ctrl<Key>C: commandInterrupt()', Translation),
	xtParseTranslationTable(Translation, TranslationTable),
	xtOverrideTranslations(CommandPane, TranslationTable),
	xtAddCallback(CommandPane, xmNactivateCallback, xcommandPane:commandPaneActivate, _),
	xmTextAddMotionVerifyCallback(CommandPane, commandPaneMotionVerify),
	xmTextAddModifyVerifyCallback(CommandPane, commandPaneModifyVerify),
	rootWidget(Commands, Shell),
	assert((commandWidget(0, Shell, textPosition, start) :- !)),

	createWidgetInputStream(CommandPane, commandStreamInput, _, InputStream),
	createWidgetOutputStream(CommandPane, commandStreamOutput, _, OutputStream),

	gensym(pipe, PipeName),
	registerTtyStream(PipeName, InputStream),
	registerTtyStream(PipeName, OutputStream),

	assert((commandWidget(CommandPane, Shell, widget, scrolledText) :- !)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HistoryPane                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   historyPaneSelection(+Widget, +ClientData, +CallData)
%   is true when a selection was made in the history pane and the selected
%   item replaces the current input prompt lines input data.  Double
%   clicking on a selected item causes that item to be copies to the current
%   input prompt line and executed.  Note that checking the time field of
%   the event field of the CallData structure we can determine a double
%   click response.

historyPaneSelection(Widget, _ClientData, [_Reason, _Event, item(ItemString),
						_ItemLength, item_position(Position)]) :-
	xmStringToCharPtr(ItemString, Command),
	commandWidget(ScrolledText, _Shell, widget, scrolledText),
	displayCommand(ScrolledText, Command),
	xmListDeselectPos(Widget, Position).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CommandPane                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   commandPaneActivate(+Widget, +ClientData, +CallData)
%   is true when the user has pressed the return key in the command
%   pane and the current command is executed.

commandPaneActivate(Widget, _, _) :-
	rootWidget(Widget, Shell),
	commandWidget(StartPosition, Shell, textPosition, start),
	xmTextGetLastPosition(Widget, EndPosition),
	nl,
	(   StartPosition =:= EndPosition ->
	    LastPosition is EndPosition + 1
	;   LastPosition = EndPosition
	),
	critical((
		xmTextGetSelection(Widget, StartPosition, LastPosition, Selection),
		Selection \== char_ptr(0),
		xmTextGetLastPosition(Widget, RealLastPosition),
		xmTextSetInsertionPosition(Widget, RealLastPosition),
		( retract((commandWidget(_, Shell, stream, input) :- !)), ! ; true ),
		assert((commandWidget(Selection, Shell, stream, input) :- !))
	)).

commandPaneModifyVerify(WidgetPtr, _CurrInsert, NewInsert, StartPos, EndPos) :-
	rootWidget(widget(WidgetPtr), Shell),
	commandWidget(Position, Shell, textPosition, start),
	NewInsert >= Position,
	(   StartPos < EndPos -> % Backspace
	    StartPos >= Position
	;   true
	).

commandPaneMotionVerify(WidgetPtr, _CurrInsert, NewInsert, StartPos, EndPos) :-
	rootWidget(widget(WidgetPtr), Shell),
	commandWidget(Position, Shell, textPosition, start),
	NewInsert >= Position,
	(   StartPos < EndPos -> % Backspace
	    StartPos >= Position
	;   true
	).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Stream Input/Output           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Old Version (1)
%% commandStreamInput(WidgetPtr, CharPtr) :-
%% 	Widget = widget(WidgetPtr),
%% 	rootWidget(Widget, Shell),
%% 	repeat,
%% 		xtNextEvent(XEvent),
%% 		(   xtDispatchEvent(XEvent),
%% 		    dispatch_event(XEvent, never_exit, _) -> true
%% 		;   true
%% 		),
%% 		commandWidget(char_ptr(CharPtr), Shell, stream, input),
%% 	!,
%% 	retract((commandWidget(_, Shell, stream, input) :- !)).

%% New Version (1)
%%	The Call to cast/3 will turn xt events into x events, so that
%%	they can be handled by proxl.
commandStreamInput(WidgetPtr, CharPtr) :-
	Widget = widget(WidgetPtr),
	rootWidget(Widget, Shell),
	repeat,
		xtNextEvent(XtEvent),		%% NOTE XtEvent, NOT XEvent
		(   xtDispatchEvent(XtEvent),	%% ditto
		    cast(XtEvent, xevent, XEvent),
		    dispatch_event(XEvent, never_exit, _) -> true
		;   true
		),
		commandWidget(char_ptr(CharPtr), Shell, stream, input),
	!,
	retract((commandWidget(_, Shell, stream, input) :- !)).

commandStreamOutput(WidgetPtr, CharPtr) :-
	Widget = widget(WidgetPtr),
	integer(CharPtr),
	CharPtr =\= 0,
	xmTextGetLastPosition(Widget, Position),
	xmTextReplace(Widget, Position, Position, char_ptr(CharPtr)),
	xmTextGetLastPosition(Widget, LastPosition),
	xmTextShowPosition(Widget, LastPosition),
	updateTextStartPosition(Widget).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Updating                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

updateTextStartPosition(Widget) :-
	rootWidget(Widget, Shell),
	xmTextGetLastPosition(Widget, LastPosition),
	critical((
		retract((commandWidget(_, Shell, textPosition, start) :- !)),
		assert((commandWidget(LastPosition, Shell, textPosition, start) :- !))
	)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Interrupts                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

commandInterrupt(_Widget, _ClientData, _XEvent) :-
	sendInterrupt.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Command Execution             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

displayCommand(Widget, Command) :-
	rootWidget(Widget, Shell),
	commandWidget(StartPosition, Shell, textPosition, start),
	xmTextGetLastPosition(Widget, EndPosition),
	(   Command = char_ptr(_) ->
	    CommandCharPtr = Command
	;   atom(Command),
	    proxtStringToCharPtr(Command, CommandCharPtr)
	),
	xmTextReplace(Widget, StartPosition, EndPosition, CommandCharPtr).

executeCommand(_Widget, Command) :-
	% There should only be one command pane active per XTheorist session!
	commandWidget(ScrolledText, _Shell, widget, scrolledText),
	displayCommand(ScrolledText, Command),
	commandPaneActivate(ScrolledText, _, _).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Messages                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- multifile user:message_hook/3.

user:message_hook(startCommandInput, _, _) :-
	startCommandInput.
	%fail.

user:message_hook(doneCommandInput, _, _) :-
	doneCommandInput,
	fail.

startCommandInput :-
	% There should only be one command pane active per XTheorist session!
	% Therefore, no need for the Shell object.
	commandWidget(ScrolledText, _Shell, widget, scrolledText),
	xmTextGetLastPosition(ScrolledText, LastPosition),
	critical((
		( retract((commandWidget(_, Shell, commandPosition, start) :- !)), ! ; true ),
		assert((commandWidget(LastPosition, Shell, commandPosition, start) :- !))
	)).

doneCommandInput :-
	commandWidget(ScrolledText, _, widget, scrolledText),
	commandWidget(StartPosition, _, commandPosition, start),
	commandWidget(HistoryPane, _, widget, historyPane),
	xmTextGetLastPosition(ScrolledText, LastPosition),
	EndPosition is LastPosition - 1,	% Skip carriage return at end.
	critical((
		xmTextGetSelection(ScrolledText, StartPosition, EndPosition, Selection),
		charPtrToXmString(Selection, XmString),
		xmTextFreeSelection(Selection),
		historyListAddItem(HistoryPane, XmString),
		xmStringFree(XmString)
	)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% History List                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

historyListAddItem(HistoryPane, XmString) :-
	(   commandWidget(HistoryItemCount, _, historyItem, count) ->
	    theoristResource(commandPane, commandHistoryLength, MaxHistoryItems),
	    (   HistoryItemCount =:= MaxHistoryItems ->
		NewHistoryCount = HistoryItemCount,
		xmListDeletePos(HistoryPane, 1)
	    ;   NewHistoryCount is HistoryItemCount + 1,
		critical((
			retract((commandWidget(_, _, historyItem, count) :- !)),
			assert((commandWidget(NewHistoryCount, _, historyItem, count) :- !))
		))
	    )
	;   NewHistoryCount = 1,
	    assert((commandWidget(NewHistoryCount, _, historyItem, count) :- !))
	),
	xmListAddItemUnselected(HistoryPane, XmString, 0),
	xmListSetBottomPos(HistoryPane, 0).
