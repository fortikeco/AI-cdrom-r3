%   Module : interpreterDatabase
%   Authors: George Ferguson, Scott Goodwin, Pat Fitzsimmons,
%            Abdul Sattar, Bonita Wong.
%   Updated: 11/26/91
%   Defines: Predicates dealing with facts, metas, hypothesis,
%            and askables database used by the Theorist interpreter.
%
%   See module database for a description of Theorist's database structure.

:- module(interpreterDatabase, [
	answerWasTrue/1,
	askable/1,
	askableIsTrue/1,
	assertInterpreterDatabase/1,
	clearInterpreterDatabaseSection/1,
	fact/2,
	hypothesis/3,
	listInterpreterDatabase/0,
	listInterpreterDatabase/1,
	meta/1,
        ppInterpreterDatabaseItem/1,
	proveMeta/1,
	restoreInterpreterDatabase/2,
	saveInterpreterDatabase/0,
	wasAsked/1
   ]).

:- dynamic
	askable/1,
	fact/2,
	hypothesis/3,
	meta/1,
	answer/2.

:- use_module(library(basics), [
	memberchk/2
   ]),
   use_module(library(sets), [
        union/3
   ]),
% To avoid circular imports between this module and module database
% absolute references to database:databaseAssert/3 are made in
% this file.  This problems stems from an error in Quintus Prolog's
% 'qpc' compiler.  The next release should fix this.
%   use_module(database, [
%       databaseAssert/3
%   ]).
   use_module(wff, [
	negate/2,
	ppWff/1,
	ppWithLetterVars/3
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(ask, [
	ask/3
   ]).

sccs_id('"@(#) 11/26/91 09:39:31 interpreterDatabase.pl 1.1"').


:- mode
	answerWasTrue(+),
	askable(-),
	askableIsTrue(+),
	assertInterpreterDatabase(+),
	clearInterpreterDatabaseSection(+),
	fact(-, -),
	hypothesis(-, -),
	listInterpreterDatabase(+),
	meta(-),
	ppInterpreterDatabaseItem(+),
	proveMeta(+),
	restoreInterpreterDatabase(+, -),
	wasAsked(?),

	assertFacts(+),
	assertHypotheses(+, +),
	assertContrapositives(+, +),
	assertContrapositives(+, +, +),
	listInterpreterDatabaseSection(+),
	evalAskableResponse(+, +).

/* pred
	answerWasTrue(T),
	askable(T),
	askableIstrue(T),
	assertInterpreterDatabase(T),
	clearInterpreterDatabaseSection(T),
	fact(T, T),
	hypothesis(T, T),
	listInterpreterDatabase(T),
	meta(T),
	ppInterpreterDatabaseItem(T),
	proveMeta(T),
	restoreInterpreterDatabase(T, T),
	wasAsked(T),

	assertFacts(T),
	assertHypotheses(T, T),
	assertContrapositives(T, T),
	assertContrapositives(T, T, T),
	listInterpreterDatabaseSection(T),
	evalAskableResponse(T, T).
*/



%   assertInterpreterDatabase(+Item)
%   is true if Item is a fact, hypothesis, askable, or meta and is asserted
%   into the interpreter database.

assertInterpreterDatabase(fact(Fact)) :- !,
	assertFacts(Fact).
assertInterpreterDatabase(hypothesis(Name, [])) :- !,
	database:databaseAssert(interpreterDatabase, hypothesis(Name, Name, []), true).
assertInterpreterDatabase(hypothesis(N, Hyp)) :- !,
	assertHypotheses(Hyp, N).
assertInterpreterDatabase(Item) :-		% Take care of askable and meta.
	database:databaseAssert(interpreterDatabase, Item, true).
	


%   assertFacts(+List)
%   is true when List is a list of facts or rules in the format [G|B] which
%   as a side-effect are asserted.

assertFacts([]).
assertFacts([[G|B]|T]) :-
	(   B == [] ->
	    database:databaseAssert(interpreterDatabase, fact(G, B), true)
	;   assertContrapositives(G, B)
	),
	assertFacts(T).



%   assertHypotheses(+HypothesisList, +Name)
%   is true if Name is the name of Hypothesis and as a side effect all
%   hypotheses in HypothesisList are asserted into the database.

assertHypotheses([], _).
assertHypotheses([[Goal|Body]|Goals], Name) :-
	database:databaseAssert(interpreterDatabase, hypothesis(Name, Goal, Body), true),
	assertHypotheses(Goals, Name).



%   assertContrapositives(+Goal, +Body)
%   is true if the rule (Goal :- Body) (where Body is a list of conjuncts) is
%   successfully asserted into the database.

assertContrapositives(Goal, Body) :-
	assertContrapositives(Body, Goal, []).



%   assertContrapositives(+G, +B1, +B2)
%   is always true and asserts the rule G :- B1,B2 where B1 and B2 are
%   lists of conjuncts.  Note that this implementation is extremely inefficient.
%   It can be altered if the order of asserting contrapositives into the
%   database is *not* important.

assertContrapositives([], G, B) :-
	database:databaseAssert(interpreterDatabase, fact(G, B), true).
assertContrapositives([B1|Bn], G, L) :-
	append([B1|Bn], L, B),
	database:databaseAssert(interpreterDatabase, fact(G, B), true),
	negate(G, NG),
	negate(B1, NB1),
	append(L, [NG], L1),
	assertContrapositives(Bn, NB1, L1).


%   assertHypothesisContrapositives(+Name)
%   is true if Name is both a meta and object level hypotheses
%   litatom and it is asserted into the hypothesis database.

assertHypothesisContrapositives(Name) :-
	database:databaseAssert(interpreterDatabase, hypothesis(Name, Name, []), true).



%   saveInterpreterDatabase
%   is true if all the database predicates are successfully written
%   to the current output stream.

saveInterpreterDatabase :-
	theoristResource(messageString, interpreterDatabaseLabel, DatabaseLabel),
	theoristResource(database, interpreterDatabaseList, AtomList),
	nl, write(DatabaseLabel), write('.'), nl,
	saveInterpreterDatabase(AtomList).



%   saveInterpreterDatabase(+List)
%   is true if List is a list of {fact, hypothesis, askable, meta, or
%   answer} and each database section is successfully saved to the
%   current output stream.

saveInterpreterDatabase([]).
saveInterpreterDatabase([Head|Tail]) :-
	saveInterpreterDatabaseSection(Head),
	saveInterpreterDatabase(Tail).



%   saveInterpreterDatabaseSection(+Section)
%   is true if the database Section is successfully saved to the current
%   output stream.

saveInterpreterDatabaseSection(fact) :-
	fact(X, Y),
	writeq(fact(X, Y)), write('.'), nl,
	fail.
saveInterpreterDatabaseSection(fact).

saveInterpreterDatabaseSection(hypothesis) :-
	hypothesis(X, Y, Z),
	writeq(hypothesis(X, Y, Z)), write('.'), nl,
	fail.
saveInterpreterDatabaseSection(hypothesis).

saveInterpreterDatabaseSection(askable) :-
	askable(X),
	writeq(askable(X)), write('.'), nl,
	fail.
saveInterpreterDatabaseSection(askable).

saveInterpreterDatabaseSection(meta) :-
	meta(X),
	writeq(meta(X)), write('.'), nl,
	fail.
saveInterpreterDatabaseSection(meta).

saveInterpreterDatabaseSection(answer) :-
	answer(X, Y),
	writeq(answer(X, Y)), write('.'), nl,
	fail.
saveInterpreterDatabaseSection(answer).



%   restoreInterpreterDatabase(+StreamIn, LastReadTerm)
%   is true if all the clauses in StreamIn are successfully read into
%   the interpreter database.

restoreInterpreterDatabase(StreamIn, LastReadTerm) :-
	repeat,
	   (   read(StreamIn, LastReadTerm),
	       LastReadTerm \== end_of_file ->
	       database:databaseAssert(interpreterDatabase, LastReadTerm, true),
	       fail
	   ;   true
	   ),
	!.				% Remove repeat choice point



%   clearInterpreterDatabaseSection(+Section)
%   is true if Section is a valid database section and is successfully
%   cleared (retracted from the theorist database).

clearInterpreterDatabaseSection(facts)      :- retractall(fact(_, _)).
clearInterpreterDatabaseSection(hypotheses) :- retractall(hypothesis(_, _, _)).
clearInterpreterDatabaseSection(askables)   :- retractall(askable(_)).
clearInterpreterDatabaseSection(answers)    :- retractall(answer(_, _)).
clearInterpreterDatabaseSection(metas)      :- retractall(meta(_)).



%   listInterpreterDatabase
%   is true if all items in the interpreter database are pretty printed to
%   the current output stream.

listInterpreterDatabase :-
	theoristResource(database, databasesAtomList, AtomList),
	nl,
	listInterpreterDatabaseSection(AtomList).
listInterpreterDatabase(A) :-
	nl,
	(   atomic(A) ->
	    listInterpreterDatabaseSection([A])
	;   listInterpreterDatabaseSection(A)
	).

listInterpreterDatabaseSection([]).
listInterpreterDatabaseSection([Head|Tail]) :-
	theoristResource(database, databasesAtomList, AtomList),
	(   memberchk(Head, AtomList) ->
	    ppInterpreterDatabaseItem(Head)
	;   print_message(error, unknownListOption(Head)),
	    nl
	),
	listInterpreterDatabaseSection(Tail).



%   ppInterpreterDatabaseItem(+DatabaseItem)
%   is true if DatabaseItem specifies one of {facts, hypotheses, askable,
%   answers metas} and the specified database set is pretty printed to the
%   current output.  If DatabaseItem represents a particular formula, it
%   is pretty printed to the current output.

ppInterpreterDatabaseItem(facts) :-
	fact(Head, Body),
	ppWithLetterVars(fact(Head, Body),
                         interpreterDatabase,
                         ppInterpreterDatabaseItem),
	fail.
ppInterpreterDatabaseItem(facts) :-
	(   fact(_, _) ->		% If fact exists, space it out.
	    nl
	;   true
	).

ppInterpreterDatabaseItem(fact(Head, Body)) :-
	write('fact '),
	ppWff(Head),
	(   Body \== [] ->
	    write(' <- '),
	    ppWff(Body)
	;   true
	),
	write('.'), nl.

ppInterpreterDatabaseItem(hypotheses) :-
	hypothesis(Name, Hyp, Body),
	ppWithLetterVars(hypothesis(Name, Hyp, Body),
	                 interpreterDatabase,
	                 ppInterpreterDatabaseItem),
	fail.
ppInterpreterDatabaseItem(hypotheses) :-
	(   hypothesis(_, _, _) ->	% If hypothesis exists, space it out.
	    nl
	;   true
	).

ppInterpreterDatabaseItem(hypothesis(Name, Hyp, Body)) :-
	write('hypothesis '),
	ppWff(Name),
	(   Hyp \== [] ->
		write(' : '),
		ppWff(Hyp),
		(   Body \== [] ->
			write(' <- '),
			ppWff(Body)
		;   true
		)
	;   true
	),
	write('.'), nl.

ppInterpreterDatabaseItem(askables) :-
	askable(Ask),
	ppInterpreterDatabaseItem(askable(Ask)),
	fail.
ppInterpreterDatabaseItem(askables) :-
	(   askable(_) ->		% If askable exists, space it out.
	    nl
	;   true
	).

ppInterpreterDatabaseItem(askables(Ask)) :-
	askable(Ask),
	ppInterpreterDatabaseItem(askable(Ask)),
	fail.
ppInterpreterDatabaseItem(askables(Ask)) :-
	(   \+ \+ askable(Ask) ->		% If askable exists,
	    nl					% space it out.
	;   true
	).

ppInterpreterDatabaseItem(askable(Ask)) :-
	write('askable '),
	ppWithLetterVars(Ask, wff, ppWff),
	write('.'), nl.

ppInterpreterDatabaseItem(answers) :-
        answer(Result, Answer),
	ppInterpreterDatabaseItem(answer(Result, Answer)),
        fail.
ppInterpreterDatabaseItem(answers) :-
	(   answer(_, _) ->		% If answer exists, space it out.
	    nl
        ;   true
        ).

ppInterpreterDatabaseItem(answer(Answer, Goal)) :-
        write('answer '),
        ppWithLetterVars(Goal, wff, ppWff),
	write(' is '),
	write(Answer),
        write('.'), nl.


ppInterpreterDatabaseItem(metas) :-
	meta(Meta),
	ppInterpreterDatabaseItem(meta(Meta)),
	fail.
ppInterpreterDatabaseItem(metas) :-
	(   meta(_) ->			% If metas exist, space it out.
	    nl
	;   true
	).

ppInterpreterDatabaseItem(metas(Meta)) :-
	meta(Meta),
	ppInterpreterDatabaseItem(meta(Meta)),
	fail.
ppInterpreterDatabaseItem(metas(Meta)) :-
	(   \+ \+ meta(Meta) ->		% If askables exist, space it out.
	    nl
	;   true
	).

ppInterpreterDatabaseItem(meta(Meta)) :-
	write('meta '),
	ppWithLetterVars(Meta, wff, ppWff),
	write('.'), nl.



%   proveMeta(+Goal)
%   is true if Goal is a meta predicate that can be proven.  Note that all meta
%   predicates are proven in module user.

proveMeta(Goal) :-
    meta(Goal),
    call(user:Goal).



%   askableIsTrue(+G) 
%   is true if the user answers true to the question G.

askableIsTrue(G) :-
	print_message(help, askAskable(G)),
	theoristResource(messageString, answerAskableString, AnswerString),
	ask(AnswerString, [], Response),
	evalAskableResponse(Response, G).



%   wasAsked(?G)
%   is true if there is an answer recorded for G.

wasAsked(G) :-
	answer(_, G), !.



%   answerWasTrue(+G)
%   is true if G has already been asked and was true, or
%   not G was asked with answer false, otherwise fails.

answerWasTrue(G) :-
	(   answer(true, G) ->
	    true	
	;   negate(G, NG),
	    answer(false, NG)
	).



%   evalAskableResponse(+G, +R)
%   is true if R is the character 't', false otherwise.
%   As a side-effect, the response is asserted for later uses.

evalAskableResponse(0't, G) :-
	database:databaseAssert(interpreterDatabase, answer(true, G), true), !.
evalAskableResponse(0'f, G) :-
	database:databaseAssert(interpreterDatabase, answer(false, G), true), !,
	fail.
evalAskableResponse(Response, G) :-
	database:databaseAssert(interpreterDatabase, answer(unknown, G), true),
	(   Response \== 0'u ->
	    print_message(error, illegalResponse)
	),
	fail.
