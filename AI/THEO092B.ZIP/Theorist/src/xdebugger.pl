%   Module : xdebugger
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: XTheorist Debugger Window
%
%   XTheorist's debugger window is used to navigate through the
%   proof tree and display goals, variable bindings, and a trace
%   history.
%
%   The format and contents of this window has not been finalized
%   yet.

:- module(xdebugger, [
	debuggerOpen/1
   ]).

:- use_module(library(proxt), [
	xtManageChild/1
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(xmenu, [
	createMenuButtons/4
   ]),
   use_module(xdialog, [
	createNotYetImplementedDialog/2,
	dialogWindowOnTop/1
   ]),
   use_module(xhelp, [
	helpOpenOn/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:43 xdebugger.pl 1.1"').

% :- mode

/* pred
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   debuggerOpen(Widget)
%   is true when XTheorist's editor window is created and displayed.
%   Widget is the parent of the debugger widget.

debuggerOpen(Widget) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Menubar                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   menuBarData(+MenuItemList)
%   is true if MenuItemList is a list of menuItem structures
%   that specify the items within each debugger menu.
%   See documentation in module menu for a description of the
%   MenuItemList datastructure.

menuBarData([
	menuItem(file,		_,	_,	xdebugger:fileMenuData,	_),
	helpMenuItem(help,	_,	_,	xdebugger:helpMenuData,	_)
	]).

fileMenuData([
	]).

helpMenuData([
	menuItem(helpOnXTheorist,	xdebugger:helpOnXTheorist,  '', _, _),
	menuItem(helpOnThisWindow,	xdebugger:helpOnThisWindow, '', _, _)
	]).

helpOnXTheorist(Widget, _, _) :-
	helpOpenOn(Widget, 'XTheorist').

helpOnThisWindow(Widget, _, _) :-
	helpOpenOn(Widget, 'Debugger').
