%   Module : tokenizer
%   Authors: George Ferguson, Scott Goodwin, Pat Fitzsimmons,
%            Abdul Sattar, Bonita Wong.
%   Updated: 11/26/91
%   Defines: Theorist input syntax tokenizer.

:- module(tokenizer, [
	tokenize/2
   ]).

:- use_module(library(ctypes), [
	is_digit/1,
	is_lower/1,
	is_space/1,
	is_upper/1,
	is_white/1
   ]),
   use_module(library(strings), [
	gensym/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:38 tokenizer.pl 1.1"').

%   This module breaks an input stream into the tokens passed to the Theorist
%   parser.  The productions used in the Parser module but not defined are:
%
%	<variable>       --> <name> starting with [A-Z].
%	<number>         --> <integer> |
%	                     <float>.
%	<integer>        --> [sign] <naturalNumber>.
%	<float>          --> [sign] <unsignedFloat>.
%	<naturalNumber>  --> <digitList> |
%	                     <float>.
%	<unsignedFloat>  --> <digitList> '.' <digitList> [<exponent>].
%	<exponent>       --> expInd [sign] <digitList>.
%	<digitList>      --> <digit> <digitList>.
%	<digit>          --> 0|1|2|3|4|5|6|7|8|9|0.
%	<sign>           --> '+' |
%	                     '-'.
%
%	<comment>        --> '/*' <name> '*/'	|
%                            '%' <name> eol.
%	<constant>       --> {<string> starting with [a-z]} |
%	                     singleQuote <string> singleQuote.
%	<name>           --> {any sequence of characters}.
%
%	eof              --> {end of input file}.
%	eol              --> '.'   |
%	                     ';'
%	and              --> 'and' |
%	                     '&'
%	not              --> 'not' |
%	                     '~'
%	implies          --> '->'  |
%	                     '=>'
%	backImplies      --> '<-'  |
%	                     '<='  |
%	                     ':-'
%       iff              --> '<=>' |
%                            '<->'
%	comma            --> ','
%	bar              --> '|'
%	lparen           --> '('
%	rparen           --> ')'
%	lbracket         --> '['
%	rbracket         --> ']'
%	expInd           --> 'e'   |
%	                     'E'.
%	singleQuote      --> '''.
%	slash            --> '/'.
%	asterik          --> '*'.
%	fullStop         --> '.'   |
%	                     ';'.
%
%   White space and comments as in C are ignored.



%   tokenize(N,T)
%   is true when N is the character that was just read on the new
%   input line, and T is the list of tokens that results from reading
%   the rest of the input up to and including an 'eol' or 'eof' token.

tokenize(N, [Token|Rest]) :-
	token(N, Token, N1),
	checkEOL(Token, N1, Rest).

checkEOL(eol, _, [])         :- !.
checkEOL(_, eol, [eol])      :- !.	% Carriage return means we are done.
checkEOL(controlD, _, [eol]) :- !.	% ^D takes effect immediately
checkEOL(_, N1, R)           :- tokenize(N1,R).



%   token(C, T, N)
%   is true when C is the current input character, T is the next token
%   in the input (including C) and N is the next character in the input
%   (ie the pushed back char).

token(N, T, Next) :-
	N >= 0, N =< 31,
	!,
	getChar(N1),
	token(N1, T, Next).
token(-1, controlD, -1) :- !.	% ^D exits Theorist

token(N, T, Next) :-		% skip white space
	is_space(N),
	!,
	getChar(N1),
	token(N1, T, Next).

token(N, T, Next) :-		% skip comments
	commentStart(N, N1),
	scanComment(N1, N2), !,
	token(N2, T, Next).
token(0'%, T, Next) :-
	getChar(N1),
	scanRestOfLine(N1, N2), !,
	token(N2, T, Next).

% reserve characters
token(0';, eol, Next)      :- !, getChar(Next).
token(0'., eol, Next)      :- !, getChar(Next).
token(0'(, lparen, Next)   :- !, getChar(Next).
token(0'), rparen, Next)   :- !, getChar(Next).
token(0'[, lbracket, Next) :- !, getChar(Next).
token(0'], rbracket, Next) :- !, getChar(Next).
token(0'|, bar, Next)      :- !, getChar(Next).
token(0'&, and, Next)      :- !, getChar(Next).
token(0'~, not, Next)      :- !, getChar(Next).
token(0',, comma, Next)    :- !, getChar(Next).

token(N, T, Next) :- colon(N, T, Next), !.		% color or ':-'

token(N, T, Next) :- backArrow(N, T, Next), !.		% '<=' or '<-'

token(N, T, Next) :- implication(N, T, Next), !.	% '=>' or '->'

token(N, var(T), Next) :-				% variables
	is_upper(N), !,
	variable(N, T, Next).
token(N, var(T), Next) :-
	N = 0'_, !,
	variable(N, T, Next).

token(N, name(Name), Next) :-			% simple names
	is_lower(N), !,
	simpleName(N, Name, Next).

token(0'', name(T), Next) :-			% quoted names
	!,
	quoteName(T, Next).

token(N, Token, Next) :-			% numbers
	sign(N),
	getChar(N1),
	is_digit(N1),
	getChar(N2),
	number(N2, N3, Next),
	!,
	name(T, [N,N1|N3]),
	(   integer(T) ->
	    Token = integer(T)
	;   Token = num(T)
	).
token(N, Token, Next) :-
	is_digit(N),
	getChar(N1),
	number(N1, N2, Next),
	!,
	name(T, [N|N2]),
	(   integer(T) ->
	    Token = integer(T)
	;   Token = num(T)
	).

token(N, error(C), Next) :-			% illegal char.
	name(C, [N]), !,
	getChar(Next).


colon(0':, T, Next) :-
	getChar(N1),
	colonImplication(N1, T, Next).

colonImplication(0'-, back_implies, Next) :-
	getChar(Next), !.
colonImplication(Next, colon, Next) :-
	\+ Next = 0'-.

backArrow(0'<, Token, Next) :-
	getChar(N1),
	(N1 = 0'= , ! ; N1 = 0'-),
	getChar(N2),
	doubleArrow(N2, Token, Next).

doubleArrow(0'>, iff, Next) :-
	getChar(Next), !.
doubleArrow(Next, back_implies, Next) :-
	\+ Next = 0'>.

implication(N, Token, Next) :-		% Check for implication (=> or ->).
	(N == 0'= , ! ; N == 0'-),	% Note that if we check for a '-'
	getChar(N1),			% and the next character is not a '>'
	(   N == 0'-,			% then we must check for a negative
	    is_digit(N1) ->		% integer.
	    getChar(N2),
	    number(N2, N3, Next),
	    name(T, [N,N1|N3]),
	    (   integer(T) ->
	        Token = integer(T)
	    ;   Token = num(T)
	    )
	;   N1 == 0'>,
	    Token = implies,
	    getChar(Next)
	).

commentStart(0'/, Next) :-		% strip off comments
	getChar(0'*),
	getChar(Next).

scanComment(-1, _) :- !, fail.		% Fail if end_of_file encountered.
scanComment(C, Next) :-
	(   C = 0'* ->
	    getChar(N),
	    (   N = 0'/ ->
	        getChar(Next)
	    ;   scanComment(N, Next)
	    )
	;   getChar(N),
	    scanComment(N, Next)
	).

%   scanRestOfLine(+CurrentChar, -NextChar)
%   is true if the rest of a line (up to an including the carriage return)
%   is gobbled.

scanRestOfLine(-1, -1)   :- !.		% Succeed if end_of_file encountered.
scanRestOfLine(10, Next) :- getChar(Next), !.
scanRestOfLine(_, Next)  :-
	getChar(N1),
	scanRestOfLine(N1, Next).


% tokenize simple names that start with a lower case letter

simpleName(N, C, Next) :-
	collectNameChars(N, NL, Next),
	name(C, NL).

collectNameChars(N, [N|R], Next) :-
	nameChar(N),
	!,
	getChar(N1),
	collectNameChars(N1, R, Next).
collectNameChars(N, [], N).


%   tokenize names that are contained within single quotes
quoteName(C, Next) :-
	getChar(N1),
	collectQuoteNameChars(N1, NL, Next),
	name(C, NL).

collectQuoteNameChars(-1, _, _) :- !, fail.	% Fail if end_of_file reached.
collectQuoteNameChars(N, N2, Next) :-
	N = 0'',
	!,
	getChar(N1),
	continueIfEmbeddedQuotes(N1,N2,Next).
collectQuoteNameChars(N, [N|N2], Next) :-
	\+ N = 0'',
	getChar(N1),
	collectQuoteNameChars(N1, N2, Next).

continueIfEmbeddedQuotes(Next, [], Next) :-
	Next =\= 0'', !.
continueIfEmbeddedQuotes(N, [N|N2], Next) :-
	N = 0'',
	getChar(N1),
	collectQuoteNameChars(N1, N2, Next).

% tokenize variables
variable(N, V, Next) :-
	collectNameChars(N, NL, Next),
	(   NL = [0'_] ->
	    gensym('_', V)
	;   name(V, NL)
	).


% tokenize numbers
number(N, [N|N2], Next) :-
	(   N = 0'. ->
	    getChar(N1),
	    float(N1, N2, Next)
	;   exponentInd(N) ->
	    getChar(N1),
	    exponent(N1, N2, Next)
	;   is_digit(N) ->
	    getChar(N1),
	    number(N1, N2, Next)
	), !.
number(0'., [], eol) :- !.
number(Next, [], Next).

float(N, N1, Next) :-
	is_digit(N),
	float_(N, N1, Next).

float_(N, [N|N2], Next) :-
	(   is_digit(N) ->
	    getChar(N1),
	    float_(N1, N2, Next)
	;   exponentInd(N) ->
	    getChar(N1),
	    exponent(N1, N2, Next)
	), !.
float_(Next, [], Next).

exponent(N, [N|N2], Next) :-
	sign(N),
	!,
	getChar(N1),
	digits(N1, N2, Next).
exponent(N, N1, Next) :-
	digits(N, N1, Next).

exponentInd(0'E).
exponentInd(0'e).

sign(0'-).
sign(0'+).

digits(N, [N|N2], Next) :-
	is_digit(N),
	!,
	getChar(N1),
	digits(N1, N2, Next).
digits(Next, [], Next).

% character classes
nameChar(N) :- is_lower(N), !.
nameChar(N) :- is_upper(N), !.
nameChar(N) :- is_digit(N), !.
nameChar(0'_) :- !.
nameChar(0'/).



%   getChar(Char)
%   gets the next character from the input stream.  If the next
%   character is an end_of_file character, then reposition
%   the stream so that the end_of_file character can be
%   re-read.

getChar(Char) :-
	current_input(Stream),
	stream_position(Stream, Position),
	get0(Char),
	(   Char =:= -1 ->
	    stream_position(Stream, _, Position)
	;   true
	).
