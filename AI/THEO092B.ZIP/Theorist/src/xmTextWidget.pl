%   Module : xmTextWidget
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with XmText widgets that are not available
%            in ProXT.
%
%   In particular, ProXT and ProXL have no way of handling xmNmotionVerifyCallbacks
%   properly.  The user should be able to set the "doit" field of the CallData
%   structure to TRUE or FALSE.  However, this is not possible in the current
%   release (3.0) of Quintus Prolog.  The workaround is to make the Callback a
%   C function and set the CallData structure from C.
%
%   *NOTE* The character pointer returned by xmTextGetSelection/4 must be freed
%          by the application!

:- module(xmTextWidget, [
	xmTextAddMotionVerifyCallback/2,
	xmTextAddModifyVerifyCallback/2,
	xmTextFreeSelection/1,
	xmTextGetSelection/4,
	xmTextShowPosition/2
   ]).

:- meta_predicate
	xmTextAddModifyVerifyCallback(+, :),
	xmTextAddMotionVerifyCallback(+, :).

:- mode
	xmTextFreeSelection(+),
	xmTextGetSelection(+, +, +, -),
	xmTextShowPosition(+, +).

sccs_id('"@(#) 11/26/91 09:39:47 xmTextWidget.pl 1.1"').

/* pred
	xmTextAddModifyVerifyCallback(Widget, Callback),
	xmTextAddMotionVerifyCallback(Widget, Callback),
	xmTextFreeSelection(CharPtr),
	xmTextGetSelection(Widget, Integer, Integer, CharPtr),
	xmTextShowPosition(Widget, Integer).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Accessing                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   xmTextGetSelection(+Widget, +StartPosition, +EndPosition, -CharPtr)
%   is true when CharPtr is bound to the current Widget text selection.  This
%   predicate was created to avoid a error in the Motif library of Quintus
%   Prolog Release 3.0 that causes fatal errors to occur when the XmText widget
%   selection mechanism is used.  See the code for cXmTextGetSelection for
%   a description of the work-around.

xmTextGetSelection(Widget, StartPosition, EndPosition, char_ptr(CharPtr)) :-
	Widget = widget(WidgetPtr),
	integer(WidgetPtr),
	var(CharPtr),
	cXmTextGetSelection(WidgetPtr, StartPosition, EndPosition, CharPtr, ReturnValue),
	ReturnValue =:= 0.

%   xmTextFreeSelection(+CharPtr)
%   is true when the memory held by CharPtr is released to the system.
%   This predicate is used in conjunction with xmTextGetSelection/4 to
%   free the CharPtr it returns.

xmTextFreeSelection(char_ptr(CharPtr)) :-
	integer(CharPtr),
	cXmTextFreeSelection(CharPtr, ErrorNumber),
	ErrorNumber =:= 0.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Text Adjustment               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   xmTextShowPosition(+Widget, +Position)
%   is true when the text widget represented by Widget is
%   scrolled so that the text at Position is visible within
%   the text viewing rectangle.  This predicate simply calls
%   the motif XmTextShowPosition routine - not available in
%   Quintus Prolog Release 3.0.

xmTextShowPosition(Widget, Position) :-
	Widget = widget(WidgetPtr),
	integer(WidgetPtr),
	integer(Position),
	cXmTextShowPosition(WidgetPtr, Position, ReturnValue),
	ReturnValue =:= 0.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Callback addition             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xmTextAddMotionVerifyCallback(XmTextWidget, Callback) :-
	XmTextWidget = widget(WidgetPtr),
	integer(WidgetPtr),
	Callback = Module:Predicate,
	atom(Module),
	atom(Predicate),
	cXmTextAddMotionVerifyCallback(WidgetPtr, Module, Predicate, _ErrorNumber, ReturnValue),
	ReturnValue =:= 0.


xmTextAddModifyVerifyCallback(XmTextWidget, Callback) :-
	XmTextWidget = widget(WidgetPtr),
	integer(WidgetPtr),
	Callback = Module:Predicate,
	atom(Module),
	atom(Predicate),
	cXmTextAddModifyVerifyCallback(WidgetPtr, Module, Predicate, _ErrorNumber, ReturnValue),
	ReturnValue =:= 0.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Foreign functions             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

foreign_file('xmTextWidget.o',
	[cXmTextAddMotionVerifyCallback,
	 cXmTextAddModifyVerifyCallback,
	 cXmTextFreeSelection,
	 cXmTextGetSelection,
	 cXmTextShowPosition]).
foreign(cXmTextAddMotionVerifyCallback, c,
	cXmTextAddMotionVerifyCallback(+address('Widget'), +atom, +atom, -integer, [-integer])).
foreign(cXmTextAddModifyVerifyCallback, c,
	cXmTextAddModifyVerifyCallback(+address('Widget'), +atom, +atom, -integer, [-integer])).
foreign(cXmTextFreeSelection, c,
	cXmTextFreeSelection(+address(char), [-integer])).
foreign(cXmTextGetSelection, c,
	cXmTextGetSelection(+address('Widget'), +integer, +integer, -address(char), [-integer])).
foreign(cXmTextShowPosition, c,
	cXmTextShowPosition(+address('Widget'), +integer, [-integer])).

:- load_foreign_files(['xmTextWidget.o'], []).
