%   Module : inputDatabase
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with facts, metas, hypothesis,
%            and askables database in their input format.  This database is
%            used so that source listings can appear as close as possible to
%            the users orginal input syntax.
%
%   See the documentation in module database for a description of the Theorist
%   database modules.

:- module(inputDatabase, [
	assertInputDatabase/1,
	clearInputDatabaseSection/1,
	ppInputDatabaseItem/1,
	restoreInputDatabase/2,
	saveInputDatabase/0
   ]).

:- dynamic
	fact/1,
	hypothesis/2.

:- use_module(wff, [
	ppWff/1
   ]),
% To avoid circular imports between this module and module database
% absolute references to database:databaseAssert/3 are made in
% this file.  This problems stems from an error in Quintus Prolog's
% 'qpc' compiler.  The next release should fix this.
%   use_module(database, [
%	databaseAssert/3
%   ]).
   use_module(resource, [
	theoristResource/3
   ]).

sccs_id('"@(#) 11/26/91 09:39:29 inputDatabase.pl 1.1"').


:- mode
	assertInputDatabase(+),
	clearInputDatabaseSection(+),
	ppInputDatabaseItem(+),
	restoreInputDatabase(+, -).

/* pred
	assertInputDatabase(T),
	clearInputDatabaseSection(T),
	ppInputDatabaseItem(T),
	restoreInputDatabase(T, T).
*/

%    assertInputDatabase(+InputFormula)
%    is true if InputFormula is successfully asserted into the input database.
%    The input database is used to store the users input formulas before they
%    are converted by the interpreter and compiler to unrecognisable forms.

assertInputDatabase(InputFormula) :-
	database:databaseAssert(inputDatabase, InputFormula, true).



%    clearInputDatabaseSection(+Section)
%    is true if Section is successfully cleared from the input database.

clearInputDatabaseSection(facts) :- !,
	retractall(fact(_)).
clearInputDatabaseSection(hypotheses) :- !,
	retractall(hypothesis(_, _)).
clearInputDatabaseSection(_).



%    ppInputDatabaseItem(+Item)
%    is true if Item is pretty printed to the current output stream.

ppInputDatabaseItem(facts) :-
	fact(Fact),
	ppInputDatabaseItem(fact(Fact)),
	fail.
ppInputDatabaseItem(facts) :-
	(   fact(_) ->			% If facts exist, space them out.
	    nl
	;   true
	).

ppInputDatabaseItem(facts(Fact)) :-
	fact(Fact),
	ppInputDatabaseItem(fact(Fact)),
	fail.
ppInputDatabaseItem(facts(Fact)) :-
	(   \+ \+ fact(Fact) ->			% If facts exist, space them out.
	    nl
	;   true
	).

ppInputDatabaseItem(fact(Fact)) :-
	write('fact '),
	ppWff(Fact),
	write('.'),
	nl.

ppInputDatabaseItem(hypotheses) :-
	hypothesis(Name, Hyp),
	ppInputDatabaseItem(hypothesis(Name, Hyp)),
	fail.
ppInputDatabaseItem(hypotheses) :-
	(   hypothesis(_, _) ->		% If hypotheses exist, space them out.
	    nl
	;   true
	).

ppInputDatabaseItem(hypotheses(Name)) :-
	hypothesis(Name, Hyp),
	ppInputDatabaseItem(hypothesis(Name, Hyp)),
	fail.
ppInputDatabaseItem(hypotheses(Name)) :-
	(   \+ \+ hypothesis(Name, _) ->	% If hypotheses exist,
	    nl                                  % space them out.
	;   true
	).

ppInputDatabaseItem(hypothesis(Name, Hyp)) :-
	write('hypothesis '),
	ppWff(Name),
	(   Hyp \== [] ->
		write(' : '),
		ppWff(Hyp)
	;   true
	),
	write('.'),
	nl.

%   restoreInputDatabase(+StreamIn, LastReadTerm)
%   is true if the input database is successfully restored from StreamIn.
%   LastReadTerm is bound to the last term read from StreamIn.

restoreInputDatabase(StreamIn, LastReadTerm) :-
	theoristResource(messageString, interpreterDatabaseLabel, InterpreterDatabaseLabel),
	read(StreamIn, ATerm),		% Read input database label
	(   ATerm \== end_of_file,
	    repeat,
	        read(StreamIn, LastReadTerm),
	        (   LastReadTerm \== end_of_file,
	            LastReadTerm \== InterpreterDatabaseLabel ->
	            database:databaseAssert(inputDatabase, LastReadTerm, true),
	            fail
	        ;   true
	        ),
	    !		% Remove repeat choice point
	;   LastReadTerm = ATerm
	).



%   saveInputDatabase
%   is true if the input database is saved on the current output stream.

saveInputDatabase :-
	theoristResource(messageString, inputDatabaseLabel, InputDatabaseLabel),
	theoristResource(database, inputDatabaseList, AtomList),
	nl, write(InputDatabaseLabel), write('.'), nl,
	saveInputDatabase(AtomList).

saveInputDatabase([]).
saveInputDatabase([Head|Tail]) :-
	saveInputDatabaseSection(Head),
	saveInputDatabase(Tail).

saveInputDatabaseSection(fact) :-
	fact(X),
	writeq(fact(X)), write('.'), nl,
	fail.
saveInputDatabaseSection(fact).

saveInputDatabaseSection(hypothesis) :-
	hypothesis(X, Y),
	writeq(hypothesis(X, Y)), write('.'), nl,
	fail.
saveInputDatabaseSection(hypothesis).
