/*  File   : xmTextWidget.c
    Author : Daniel Lanovaz
    Origin : March 1991
    Update : 11/26/91
    Purpose: Defines C functions for the XmText widget that cannot
             be suitably handled in Prolog using ProXT and ProXL.

    See the documentation in xmTextWidget.pl for more details.
*/

#ifndef lint
  static  char SCCSid[] = "@(#) 11/26/91 09:39:11 xmTextWidget.c 1.1";
#endif/*lint*/

#include <X11/Intrinsic.h>
#include "Xm/Xm.h"
#include "Xm/Text.h"
#include "quintus.h"

typedef struct {
	char *motionVerifyModule;
	char *motionVerifyPredicate;
} MotionVerifyCallbackData;

typedef struct {
	char *modifyVerifyModule;
	char *modifyVerifyPredicate;
} ModifyVerifyCallbackData;

static void
MotionVerifyCallback(widget, clientData, callData)
Widget                        widget;
MotionVerifyCallbackData     *clientData;
XmTextVerifyCallbackStruct   *callData;
{
	int         result;
	QP_pred_ref motionQuery = QP_predicate(clientData->motionVerifyPredicate, 5,
						clientData->motionVerifyModule);

	if (motionQuery == (QP_pred_ref) QP_ERROR) {
		return;
	}

	result = QP_query(motionQuery, widget,
			callData->currInsert,
			callData->newInsert,
			callData->startPos,
			callData->endPos);

	/* There should be a way to propagate exceptions back to
	 * the calling world.
	 */
	if (result == QP_SUCCESS) {
		callData->doit = TRUE;
	} else {
		callData->doit = FALSE;
	}
}

static void
ModifyVerifyCallback(widget, clientData, callData)
Widget                        widget;
ModifyVerifyCallbackData     *clientData;
XmTextVerifyCallbackStruct   *callData;
{
	int         result;
	QP_pred_ref modifyQuery = QP_predicate(clientData->modifyVerifyPredicate, 5,
						clientData->modifyVerifyModule);

	if (modifyQuery == (QP_pred_ref) QP_ERROR) {
		return;
	}

	result = QP_query(modifyQuery, widget,
			callData->currInsert,
			callData->newInsert,
			callData->startPos,
			callData->endPos);

	/* There should be a way to propagate exceptions back to
	 * the calling world.
	 */
	if (result == QP_SUCCESS) {
		callData->doit = TRUE;
	} else {
		callData->doit = FALSE;
	}
}

int
cXmTextAddMotionVerifyCallback(widget, module, callbackPredicate, errorNumber)
Widget  widget;
QPatom  module;
QPatom  callbackPredicate;
int    *errorNumber;
{
	MotionVerifyCallbackData *clientData;

	if ((clientData = (MotionVerifyCallbackData *) QP_malloc(sizeof(MotionVerifyCallbackData)))
		== ((MotionVerifyCallbackData *) 0)) {
		*errorNumber = QP_errno;
		return QP_ERROR;
	}

	clientData->motionVerifyPredicate = QP_string_from_atom(callbackPredicate);
	clientData->motionVerifyModule    = QP_string_from_atom(module);

	XtAddCallback(widget, XmNmotionVerifyCallback, MotionVerifyCallback, clientData);
	return QP_SUCCESS;
}

int
cXmTextAddModifyVerifyCallback(widget, module, callbackPredicate, errorNumber)
Widget  widget;
QPatom  module;
QPatom  callbackPredicate;
int    *errorNumber;
{
	ModifyVerifyCallbackData *clientData;

	if ((clientData = (ModifyVerifyCallbackData *) QP_malloc(sizeof(ModifyVerifyCallbackData)))
		== ((ModifyVerifyCallbackData *) 0)) {
		*errorNumber = QP_errno;
		return QP_ERROR;
	}

	clientData->modifyVerifyPredicate = QP_string_from_atom(callbackPredicate);
	clientData->modifyVerifyModule    = QP_string_from_atom(module);

	XtAddCallback(widget, XmNmodifyVerifyCallback, ModifyVerifyCallback, clientData);
	return QP_SUCCESS;
}

int
cXmTextShowPosition(widget, position)
Widget widget;
int    position;
{
	XmTextShowPosition(widget, position);
	return QP_SUCCESS;
}

int
cXmTextGetSelection(widget, startPosition, endPosition, selection)
Widget   widget;
int      startPosition;
int      endPosition;
char   **selection;
{
	char *textString;
	char *buffer;
	int   length;

	if (selection == NULL) return QP_ERROR;
	*selection = 0;

	length = endPosition - startPosition;
	if (length < 0) return QP_ERROR;
	if (length == 0) return QP_SUCCESS;

	textString = XmTextGetString(widget);
	if (textString == NULL) return QP_ERROR;
	if (strlen(textString) < endPosition) {
		XtFree(textString);
		return QP_ERROR;
	}

	buffer = (char *) QP_malloc(length + 1);
	if (buffer == NULL) {
		XtFree(textString);
		return QP_ERROR;
	}

	textString += startPosition;
	strncpy(buffer, textString, length);
	XtFree(textString);
	buffer[length] = '\0';

	*selection = buffer;
	return QP_SUCCESS;
}

int
cXmTextFreeSelection(selection)
char *selection;
{
	QP_free(selection);
	return QP_SUCCESS;
}
