%   Module : xmenu
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Simple menu building package.
%
%   This module defines a simple menu building module.  It it loosly
%   based on the simple menu library package described in the book:
%
%        Young, Douglas A., "The X Window System Programming and
%            Applications with Xt: OSF/Motif Edition", Prentice-Hall
%            Inc., 1990, pp. 96-109.
%
%   The following structures are used in this implementation.  The main
%   structure that defines menu information is a user defined predicate
%   of arity 1.  The predicate is defined as:
%
%       menu(-ItemList).
%
%       ItemList: is a list of structures of the form:
%
%       menuItem(-ButtonName	(Atom),
%                -Callback	(Predicate),
%                -CallbackData	(AnyTerm)).
%
%       subMenuItem(-ButtonName   (Atom),
%                   -Submenu      (Predicate),
%                   -Submenutitle (Atom)).
%
%       separatorMenuItem.
%
%       helpMenuItem(-ButtonName   (Atom),
%                    -Callback     (Predicate),
%                    -CallbackData (Structure)).
%
%       helpSubMenuItem(-ButtonName   (Atom),
%                       -Submenu      (Predicate),
%                       -SubmenuTitle (Atom)).
%
%       The 'menuItem' functor indicates a regular menu item entry.
%       The 'subMenuItem' functor indicates a menu containing a submenu structure.
%       The 'separatorMenuItem' indicates a separator (horizontal separator line)
%           is to be placed in the menu.
%       The 'helpMenuItem' functor indicates this menu entry is to be treated
%           as the help menu button and treated accordingly by the Motif menu
%           bar widget (this usually means placing the menu entry to the far
%           right of the menu bar.
%       The 'helpSubMenuItem' functor indicates a special Motif help menu entry
%           (as in 'helpMenuItem'), but indicates the help menu contains a
%           subMenu.
%
%       ButtonName: is an atom that describes the name of the item button.
%       Callback: is a predicate of arity 3, defined as follows:
%                 callback(+Widget, +ClientData, +CallData)
%                 where Widget is the MenuItem that was selected, ClientData
%                 is the information specified in the menuItem/5 CallbackData
%                 argument, and CallData is system defined information.
%       CallbackData: A structure passed to the Callback predicate as the
%                 ClientData argument.
%       Submenu: is a predicate name (of arity 1) defined exactly as menu/1 above.
%                 If Submenu is a variable, there is no submenu specified for
%                 the current menuItem, otherwise this predicate is used to
%                 build the submenu.
%       SubmenuTitle: is an atom that defines the title of the submenu.  If this
%                 argument is a variable, there is no name attached to the submenu.
%
%   Note that the predicate name does not have to be 'menu' for the actual
%   name is passed as an argument to the menu creation predicate (see the
%   example below).
%
%   To create a menu of the following form (where a submenu is rooted at
%   Item2):
%
%       ------------
%       | Menu   |
%       -----------
%       | Item1   |-----------
%       | Item2 ->| SubMenuA |
%       | Item3   |----------|
%       ----------- Item 2 A |
%                 | Item 2 B |
%                 ------------
%
%   the following menuItem/5 predicates must be declared.  Note that when
%   each Itemxx button is pressed, the predicate doIt/3 is called, which
%   simply prints out the name of the Item Button.
%
%       subMenuA([
%            menuItem('Item 2 A', doIt, 'Item 2 A'),
%            menuItem('Item 2 B', doIt, 'Item 2 B'),
%            ]).
%
%       menuData([
%           menuItem('Item 1', doIt, 'Item One'),
%           subMenuItem('Item 2', subMenuA, 'SubMenuA'),
%           menuItem('Item 3', doIt, 'Item Three')
%           ]).
%
%       doIt(Widget, ClientData, CallData) :-
%		write(ClientData).
%
%   To actually create the menu structure, use the predicate createMenuButtons/3:
%       :- dynamic menuWidget/4.
%
%       ...
%       xmCreatePopupMenu(PopupMenu, Shell, menu, 0),
%       createMenuButtons('Menu', PopUpMenu, menuData, menuButtonPredicate).


:- module(xmenu, [
	createMenuButtons/4,
	disableMenuItems/3,
	enableMenuItems/3
   ]).

:- use_module(library(proxt), [
	xmCreatePulldownMenu/4,
	xtAddCallback/4,
	xtCreateWidget/5,
	xtCreateManagedWidget/5,
	xtManageChildren/1,
	xtSetSensitive/2,
	xtSetValues/2
   ]),
   use_module(window, [
	rootWidget/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:48 xmenu.pl 1.1"').

:- mode
	createMenuButtons(+, +, +, +),
	    createMenuButtons1(+, +, +, +),
	        createMenuButton(+, +, +, +, +, -),
	        createSubMenuButton(+, +, +, +, +, -),
	            assertButton(+, +, +),
	disableMenuItems(+, +, +),
	enableMenuItems(+, +, +),
	    enableOrDisableMenuItems(+, +, +, +),
	        enableOrDisableMenuItems_(+, +, +, +).

/* pred
	State ::= true | false.

	createMenuButtons(Atom, Widget, List, Module:Predicate),
	    createMenuButtons1(List, Widget, List, Module:Predicate),
	        createMenuButton(Atom, Predicate, AnyTerm, Widget, Module:Predicate, Widget),
	        createSubMenuButton(Atom, Predicate, Atom, Widget, Module:Predicate, Widget),
	            assertButton(Module:Predicate, Atom, Widget),
	disableMenuItems(Widget, Predicate, [Widget]),
	enableMenuItems(Widget, Predicate, [Widget]),
	    enableOrDisableMenuItems(Widget, Predicate, [Widget], State),
	        enableOrDisableMenuItems_(List, Widget, Predicate, State).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%   createMenuButtons(+Title, +Menu, +MenuStructure, +ButtonPredicate)
%   is true if a menu structure defined by the predicate group MenuStructure
%   attaches to Menu a menu labeled Title.  Note that this predicate
%   has the side affect of attaching the submenu structure to Menu.
%   ButtonPredicate is the predicate functor for asserting each button
%   into the callers module.  This is a method for the caller to retrieve
%   each button by name - ButtonPredicate is a predicate of arity four with
%   the form ButtonPredicate(Shell, Type, Name, Widget).

createMenuButtons(Title, Menu, MenuStructure, ButtonPredicate) :-
	(   nonvar(Title) ->
	    xtCreateManagedWidget(Title, xmLabelWidgetClass, Menu, [], _),
	    xtCreateManagedWidget(separator, xmSeparatorWidgetClass, Menu, [], _)
	;   true
	),
	Module:MenuStrucPred = MenuStructure,
	MenuProc =.. [MenuStrucPred, ItemList],
	Module:call(MenuProc),
	createMenuButtons1(ItemList, Menu, [], ButtonPredicate).



%   createMenuButtons1(+ItemList, +Menu, +ButtonList, +ButtonPredicate)
%   is true when each menu item in ItemList is added to Menu.  ButtonList
%   is a list of buttons, one for each item in ItemList.  This list is used
%   when creation is complete to manage all buttons at once rather than
%   individually.  ButtonPredicate is the predicate (Module:Predicate)
%   that is asserted into Module so the caller can access each new Button.

createMenuButtons1([], _, Buttons, _) :- xtManageChildren(Buttons).
createMenuButtons1([helpMenuItem(ButtonName,
			     Callback,
			     CallbackData)|RestItems],
		   Menu, Buttons, ButtonPredicate) :-
	createMenuButton(ButtonName, Callback, CallbackData, Menu, ButtonPredicate, Button),
	xtSetValues(Menu, [xmNmenuHelpWidget(Button)]),
	createMenuButtons1(RestItems, Menu, [Button|Buttons], ButtonPredicate).
createMenuButtons1([helpSubMenuItem(ButtonName,
			     SubMenu,
			     SubMenuName)|RestItems],
		   Menu, Buttons, ButtonPredicate) :-
	createSubMenuButton(ButtonName, SubMenu, SubMenuName, Menu, ButtonPredicate, Button),
	xtSetValues(Menu, [xmNmenuHelpWidget(Button)]),
	createMenuButtons1(RestItems, Menu, [Button|Buttons], ButtonPredicate).
createMenuButtons1([menuItem(ButtonName,
			     Callback,
			     CallbackData)|RestItems],
		   Menu, Buttons, ButtonPredicate) :-
	createMenuButton(ButtonName, Callback, CallbackData, Menu, ButtonPredicate, Button),
	createMenuButtons1(RestItems, Menu, [Button|Buttons], ButtonPredicate).
createMenuButtons1([subMenuItem(ButtonName,
			     SubmenuProc,
			     SubmenuName)|RestItems],
		   Menu, Buttons, ButtonPredicate) :-
	createSubMenuButton(ButtonName, SubmenuProc, SubmenuName, Menu, ButtonPredicate, Button),
	createMenuButtons1(RestItems, Menu, [Button|Buttons], ButtonPredicate).
createMenuButtons1([separatorMenuItem|RestItems], Menu, Buttons, ButtonPredicate) :-
	xtCreateManagedWidget(separator, xmSeparatorWidgetClass, Menu, [], _Button),
	createMenuButtons1(RestItems, Menu, Buttons, ButtonPredicate).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Button creation               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   createMenuButton(+ButtonName, +Callback, +CallbackData, +Menu, +ButtonPreciate, -Button)
%   is true when Button is a menu item button of Menu with ButtonName.  The predicate
%   Callback (with client data CallbackData), is invoked when the button is pressed.
%   ButtonPredicate is the Module:Predicate structure that is asserted into Module
%   so that Button can be accessed.

createMenuButton(ButtonName, Callback, CallbackData, Menu, ButtonPredicate, Button) :-
            xtCreateWidget(ButtonName, xmPushButtonWidgetClass, Menu, [], Button),
            xtAddCallback(Button, xmNactivateCallback, Callback, CallbackData),
            assertButton(ButtonPredicate, ButtonName, Button).



%   createSubMenuButton(+ButtonName, +SubmenuProc, +SubmenuName, +Menu, +ButtonPredicate, -Button)
%   is true when Button is a subMenu item button of Menu with name ButtonName.  SubmenuProc
%   is the predicate that specifies the format of the submenu with root name SubmenuName.
%   ButtonPredicate is the Module:Predicate structure that is asserted into Module so that
%   Button can be accessed.

createSubMenuButton(ButtonName, SubmenuProc, SubmenuName, Menu, ButtonPredicate, Button) :-
        (   var(SubmenuProc) ->
            xtCreateWidget(ButtonName, xmLabelWidgetClass, Menu, [], Button),
            assertButton(ButtonPredicate, ButtonName, Button)
        ;   (   var(SubmenuName) ->
                xmCreatePulldownMenu(Menu, '', [], SubMenu)
            ;   xmCreatePulldownMenu(Menu, SubmenuName, [], SubMenu)
            ),
            xtCreateWidget(ButtonName, xmCascadeButtonWidgetClass, Menu,
                                [xmNsubMenuId(SubMenu)], Button),
            assertButton(ButtonPredicate, ButtonName, Button),
            createMenuButtons(SubmenuName, SubMenu, SubmenuProc, ButtonPredicate)
        ).



%   assertButton(+ButtonPredicate, +ButtonName, +Button)
%   is true when ButtonPredicate is asserted into the callers module
%   with ButtonName and Button as arguments.
%   ButtonPredicate is the predicate functor for asserting each button
%   into the callers module.  This is a method for the caller to retrieve
%   each button by name - ButtonPredicate is a predicate of arity four with
%   the form ButtonPredicate(Shell, Type, Name, Widget).

assertButton(Module:Predicate, ButtonName, Button) :-
	rootWidget(Button, Shell),
	AssertPredicate =.. [Predicate, Button, Shell, menuItem, ButtonName],
	Module:assert((AssertPredicate :- !)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Disabling-enabling            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   enableMenuItems(+Widget, +WidgetMap, +MenuItems)
%   is true when all MenuItems have their sensitivity turned on.
%   WidgetMap is a predicate of arity four defined as:
%   WidgetMap(Widget, Shell, WidgetType, WidgetName).  This predicate,
%   usually defined in the callers module, is used to map an element
%   of MenuItems to a Widget.  MenuItems is a list of WidgetNames.

enableMenuItems(Widget, WidgetMap, MenuItems) :-
        enableOrDisableMenuItems(Widget, WidgetMap, MenuItems, 1).

%   disableFileMenuItems(+Widget, +WidgetMap, +MenuItems)
%   is true when all menu items have their sensitivity turned off.
%   WidgetMap is a predicate of arity four defined as:
%   WidgetMap(Widget, Shell, WidgetType, WidgetName).  This predicate,
%   usually defined in the callers module, is used to map an element
%   of MenuItems to a Widget.  MenuItems is a list of WidgetNames.

disableMenuItems(Widget, WidgetMap, MenuItems) :-
        enableOrDisableMenuItems(Widget, WidgetMap, MenuItems, 0).

%   enableOrDisableFileMenuItems(+Widget, +State)
%   is true when all the menu items who must have their sensitivity
%   (they can be selected or not) changed to State (true or false).

enableOrDisableMenuItems(Widget, WidgetMap, MenuItems, State) :-
        rootWidget(Widget, RootWidget),
        enableOrDisableMenuItems_(MenuItems, RootWidget, WidgetMap, State).

enableOrDisableMenuItems_([], _, _, _).
enableOrDisableMenuItems_([Item|Items], RootWidget, WidgetMap, State) :-
	Module:Predicate = WidgetMap,
        WidgetAccessPred =.. [Predicate, Widget, RootWidget, menuItem, Item],
	Module:call(WidgetAccessPred),
        xtSetSensitive(Widget, State),
        enableOrDisableMenuItems_(Items, RootWidget, WidgetMap, State).
