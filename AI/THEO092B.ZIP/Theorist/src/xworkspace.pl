%   Module : xworkspace
%   Author : Daniel Lanovaz
%   Updated: 12/3/91
%   Defines: XTheorist Workspace Window
%
%   XTheorist's workspace window is the main interaction window
%   between XTheorist and the user.  From the workspace the user
%   can enter information and query for explanations.
%
%   The workspace window is divided into four sections:
%
%       -----------------------------------------------
%       | File Options Window History            Help | <-MenuBar
%       |---------------------------------------------|
%       | History Pane                                |
%       -----------------------------------------------
%       | Command Pane                                |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       -----------------------------------------------
%       | Command Buttons                             |
%       -----------------------------------------------
%
%       Menu bar: Contains five menus, File, Options, Window,
%                 History, and Help.
%       History pane: Contains a list of the most recent user
%                 level commands.  Clicking on one of these
%                 commands places it into the current prompt
%                 line.  Double clicking re-executes the command.
%       Command pange: Contains a text entry window for the user
%                 to enter XTheorist commands.
%       Command Buttons: A row of four buttons used to interrupt
%                 and control the explanation process.  They include
%                 Interrupt, Next Answer, No More Answers, and
%                 Remaining Answers.
%
%   For a more detailed description of the workspace window,
%   consult the User's Guide.


:- module(xworkspace, [
	workspaceAbort/0,
	workspaceOpen/3
   ]).

:- use_module(library(proxt), [
	xmCreateForm/4,
	xmCreateMenuBar/4,
	xmCreatePushButton/4,
	xtAddCallback/4,
	xtCreateWidget/5,
	xtManageChild/1,
	xtRealizeWidget/1,
	xtSetSensitive/2,
	xtUnmanageChild/1
   ]),
   use_module(library(xif), [
	xif_initialize/3
   ]),
   use_module(xcommandPane, [
	createCommandPane/6,
	executeCommand/2
   ]),
   use_module(xmenu, [
	createMenuButtons/4,
	disableMenuItems/3,
	enableMenuItems/3
   ]),
   use_module(xbrowser, [
	browserOpen/0
   ]),
   use_module(xeditor, [
	editorOpenAndLoad/0
   ]),
   use_module(xdebugger, [
	debuggerOpen/1
   ]),
   use_module(xlogo, [
	aboutXTheoristOpen/0
   ]),
   use_module(window, [
	destroyWidgetRootWindow/1,
	rootWidget/2
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(xdialog, [
	createFileSelectionDialog/5,
	createNotYetImplementedDialog/2,
	createYesNoDialog/10,
	dialogWindowOnTop/1
   ]),
   use_module(xhelp, [
	helpOpenOn/2
   ]),
   use_module(format, [
	formatToAtom/3
   ]),
   use_module(xstring, [
	xmStringToString/2
   ]).

:- dynamic
        % workspaceWidget(Widget, Shell, WidgetType, WidgetName)
        % is true when Widget is a widget of WidgeType named WidgetName for
        % the workspace represented by Shell.  This predicate is
	% used for global access to widget objects.
        workspaceWidget/4.

sccs_id('"@(#) 12/3/91 12:06:15 xworkspace.pl 1.2"').

:- mode
	openWorkspace(+),

	addCommands(+),
	addCommandPane(+),
	addCommandButtons(+),
	addInterruptButton(+),
	addMenuBar(+),
	addNextAnswerButton(+),
	addNoMoreAnswersButton(+),
	addRemainingButton(+),
	addSeparator(+),
	fileMenuData(-),
	helpMenuData(-),
	menuBarData(-),
	optionsMenuData(-),
	resourceDatabaseName(+, -),
	windowMenuData(-).

/* pred
	openWorkspace(Widget),

	resourceDatabaseName(Atom, Atom).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%   workspaceOpen(-Shell, -InputStream, -OutputStream)
%   is true when XTheorist's workspace window is created and displayed.
%   Shell is the toplevel widget shell.  InputStream and OutputStream
%   and the streams used to send/receive information from the command
%   pane.

workspaceOpen(Shell, InputStream, OutputStream) :-
	(   workspaceWidget(Shell, Shell, widget, shell) -> true
        ; resource:theoristResource(widgetName, xTheorist, XTheorist),
          resource:theoristResource(widgetName, xTheoristClass, XTheoristClass),
	    xif_initialize(XTheorist, XTheoristClass, Shell),
            workspaceOpenWithStreams(Shell, InputStream, OutputStream),
	    assert((workspaceWidget(Shell, Shell, widget, shell) :- !))
	),
        xtRealizeWidget(Shell).

%   workspaceOpenWithStreams(+Shell, -InputStream, -OutputStream)
%   is true when XTheorist's workspace window is created and displayed
%   and whose parent widget is Shell.

workspaceOpenWithStreams(Shell, InputStream, OutputStream) :-
	theoristResource(widgetName, workspace, WorkspaceName),
	xmCreateForm(Shell, WorkspaceName, [], Workspace),
	xtManageChild(Workspace),
	addMenuBar(Workspace, MenuBar),
	addCommandButtons(Workspace, CommandButtons),
	addCommandPane(Workspace, MenuBar, CommandButtons, InputStream, OutputStream).

addMenuBar(Workspace, MenuBar) :-
	theoristResource(widgetName, workspaceMenuBar, MenuBarName),
	xmCreateMenuBar(Workspace, MenuBarName, [], MenuBar),
	xtManageChild(MenuBar),
	createMenuButtons(_, MenuBar, xworkspace:menuBarData, xworkspace:workspaceWidget).

addCommandPane(Workspace, TopAttachment, BottomAttachment, InputStream, OutputStream) :-
	theoristResource(widgetName, workspaceUserCommands, UserCommandsName),
	createCommandPane(Workspace, UserCommandsName,
		[xmNbottomWidget(BottomAttachment), xmNtopWidget(TopAttachment)],
		UserCommands, InputStream, OutputStream),
	xtManageChild(UserCommands).

addCommandButtons(Workspace, CommandButtons) :-
	theoristResource(widgetName, workspaceCommandButtons, CommandButtonsName),
	xmCreateForm(Workspace, CommandButtonsName, [], CommandButtons),
	xtManageChild(CommandButtons),
	addInterruptButton(CommandButtons),
	addSeparator(CommandButtons),
	addNextAnswerButton(CommandButtons),
	addNoMoreAnswersButton(CommandButtons),
	addRemainingButton(CommandButtons).

addInterruptButton(CommandButtons) :-
	theoristResource(widgetName, workspaceInterruptButton, InterruptButtonName),
	xmCreatePushButton(CommandButtons, InterruptButtonName, [], InterruptButton),
	xtManageChild(InterruptButton),
	xtAddCallback(InterruptButton, xmNactivateCallback, xworkspace:interruptButtonActivate, _),
	rootWidget(CommandButtons, Shell),
	assert((workspaceWidget(InterruptButton, Shell, button, interruptButton) :- !)).

addSeparator(CommandButtons) :-
	theoristResource(widgetName, workspaceSeparatorButton, SeparatorButtonName),
	xtCreateWidget(SeparatorButtonName, xmSeparatorGadgetClass, CommandButtons, [], SeparatorButton),
	xtManageChild(SeparatorButton).

addNextAnswerButton(CommandButtons) :-
	theoristResource(widgetName, workspaceNextButton, NextAnswerButtonName),
	xmCreatePushButton(CommandButtons, NextAnswerButtonName,
		[xmNsensitive(false)], NextAnswerButton),
	xtManageChild(NextAnswerButton),
	% should be
	%xtSetSensitive(NextAnswerButton, false),
	xtAddCallback(NextAnswerButton, xmNactivateCallback, xworkspace:nextAnswerButtonActivate, _),
	rootWidget(CommandButtons, Shell),
	assert((workspaceWidget(NextAnswerButton, Shell, button, nextAnswerButton) :- !)).

addNoMoreAnswersButton(CommandButtons) :-
	theoristResource(widgetName, workspaceNoMoreButton, NoMoreAnswerButtonName),
	xmCreatePushButton(CommandButtons, NoMoreAnswerButtonName,
		[xmNsensitive(false)], NoMoreAnswerButton),
	xtManageChild(NoMoreAnswerButton),
	xtAddCallback(NoMoreAnswerButton, xmNactivateCallback, xworkspace:noMoreAnswerButtonActivate, _),
	rootWidget(CommandButtons, Shell),
	assert((workspaceWidget(NoMoreAnswerButton, Shell, button, noMoreAnswerButton) :- !)).

addRemainingButton(CommandButtons) :-
	theoristResource(widgetName, workspaceRemainingButton, RemainingButtonName),
	xmCreatePushButton(CommandButtons, RemainingButtonName,
		[xmNsensitive(false)], RemainingButton),
	xtManageChild(RemainingButton),
	xtAddCallback(RemainingButton, xmNactivateCallback, xworkspace:remainingButtonActivate, _),
	rootWidget(CommandButtons, Shell),
	assert((workspaceWidget(RemainingButton, Shell, button, remainingButton) :- !)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Menubar                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   menuBarData(+MenuItemList)
%   is true if MenuItemList is a list of menuItem structures
%   that specify the items within each workspace menu.
%   See documentation in module menu for a description of the
%   MenuItemList datastructure.

menuBarData([
	subMenuItem(file,	xworkspace:fileMenuData,	_),
	subMenuItem(options,	xworkspace:optionsMenuData,	_),
	subMenuItem(window,	xworkspace:windowMenuData,	_),
	helpSubMenuItem(help,	xworkspace:helpMenuData,	_)
	]).

fileMenuData([
	menuItem(fileEdit,	xworkspace:fileEdit, _),
	menuItem(fileLoad,	xworkspace:fileLoad, _),
	separatorMenuItem,
	menuItem(fileQuit,	xworkspace:fileQuit, _)
	]).

optionsMenuData([
	menuItem(optionsFormat,	xworkspace:optionsFormat, _)
	]).

windowMenuData([
	menuItem(windowBrowser,		xworkspace:windowBrowser,  _),
	menuItem(windowDebugger,	xworkspace:windowDebugger, _)
	]).

helpMenuData([
	menuItem(helpOnXTheorist,	xworkspace:helpOnXTheorist,  _),
	menuItem(helpOnThisWindow,	xworkspace:helpOnThisWindow, _),
	separatorMenuItem,
	menuItem(aboutXTheorist,	xworkspace:aboutXTheorist,   _)
	]).



%   fileEdit(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the file menu's
%   edit command is executed.

fileEdit(_, _, _) :-
	editorOpenAndLoad.

%   fileLoad(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the file menu's
%   load command is executed.

fileLoad(Widget, _, _) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, workspaceFileSelectionDialog, DialogName),
	(   workspaceWidget(FileSelection, Shell, dialog, DialogName) ->
	    dialogWindowOnTop(FileSelection)
	;   createFileSelectionDialog(Widget, DialogName,
		fileLoadOK, dialogCancel, FileSelection),
	    assert((workspaceWidget(FileSelection, Shell, dialog, DialogName) :- !))
	),
	xtManageChild(FileSelection).

%   fileQuit(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the file menu's
%   quit command is executed.

fileQuit(Widget, _, _) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, workspaceQuitDialog, QuitDialogName),
	(   workspaceWidget(QuitDialog, Shell, dialog, QuitDialogName) ->
	    dialogWindowOnTop(QuitDialog)
	;   theoristResource(messageString, exitTheoristString, ExitTheoristMessage),
	    createYesNoDialog(Widget, QuitDialogName, ExitTheoristMessage,
		fileQuitOK, QuitDialog,
		dialogCancel, QuitDialog,
		dialogCancel, QuitDialog, QuitDialog),
	    assert((workspaceWidget(QuitDialog, Shell, dialog, QuitDialogName) :- !))
	),
	xtManageChild(QuitDialog).

%   optionsFormat(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the options menu's
%   format command is executed.

optionsFormat(Widget, _, _) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).

%   windowBrowser(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the window menu's
%   browser command is executed.

windowBrowser(_, _, _) :-
	browserOpen.

%   windowDebugger(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the window menu's
%   debugger command is executed.

windowDebugger(Widget, _, _) :-
	debuggerOpen(Widget).

%   windowLogo(+Widget, +ClientData, +CallData)
%   display the XTheorist logo window.

aboutXTheorist(_, _, _) :-
	aboutXTheoristOpen.

%   helpOnXTheorist(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the help menu's
%   helpOnXTheorist command is executed.

helpOnXTheorist(Widget, _, _) :-
	helpOpenOn(Widget, 'XTheorist').

%   helpOnThisWindow(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the help menu's
%   helpOnThisWindow command is executed.

helpOnThisWindow(Widget, _, _) :-
	helpOpenOn(Widget, 'Workspace').



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CommandButtons                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   interruptButtonActivate(+Widget, +ClientData, +CallData)
%   is true when the workspace's interrupt button has been pressed
%   and the corresponding action was invoked.

%%  Art's try at interrupts...
%%
%% interruptButtonActivate(_, _, _).
interruptButtonActivate(Widget, _, _) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).

%   nextAnswerButtonActivate(+Widget, +ClientData, +CallData)
%   is true when the workspace's nextAnswer button has been pressed
%   and the corresponding action was invoked.

nextAnswerButtonActivate(Widget, _, _) :-
	executeCommand(Widget, ';').

%   noMoreAnswerButtonActivate(+Widget, +ClientData, +CallData)
%   is true when the workspace's noMoreAnswer button has been pressed
%   and the corresponding action was invoked.

noMoreAnswerButtonActivate(Widget, _, _) :-
	executeCommand(Widget, '').

%   remainingButtonActivate(+Widget, +ClientData, +CallData)
%   is true when the workspace's remaining button has been pressed
%   and the corresponding action was invoked.

remainingButtonActivate(_, _, _).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Dialog Callbacks              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fileLoadOK(Widget, Dialog, [_, _, value(Value), _]) :-
%	xmStringToString(xmstring(Value), NewFileName),
	xmStringToString(Value, NewFileName),
	theoristResource(messageString, consultCommandString, ConsultCommand),
	formatToAtom(ConsultCommand, [NewFileName], Command),
	xtUnmanageChild(Dialog),
	executeCommand(Widget, Command).

fileQuitOK(Widget, Dialog, _) :-
	rootWidget(Widget, Shell),
	retractall(workspaceWidget(_, Shell, _, _)),
	xtUnmanageChild(Dialog),
	destroyWidgetRootWindow(Shell),
	halt.

dialogCancel(_, Dialog, _) :-
	xtUnmanageChild(Dialog).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% User Aborts                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   workspaceAbort
%   is true when an abort has been signalled - clean up any necessary
%   state.

workspaceAbort :-
	workspaceWidget(Shell, Shell, widget, shell),
	workspaceWidget(NextAnswerButton, Shell, button, nextAnswerButton),
	workspaceWidget(NoMoreAnswerButton, Shell, button, noMoreAnswerButton),
	workspaceWidget(RemainingButton, Shell, button, remainingButton),
	xtSetSensitive(NextAnswerButton, 0),
	xtSetSensitive(NoMoreAnswerButton, 0),
	xtSetSensitive(RemainingButton, 0),
	workspaceWidget(Shell, Shell, widget, shell),
	enableMenuItems(Shell, xworkspace:workspaceWidget, [file, options, window, help]).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Messages                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   The following predicates extend the defintion of user:message_hook/3
%   to process messages relevant to the exection of commands.  The following
%   sequence of message sends occur when the user is typing commands from
%   the command pane of the workspace window:
%
%   <printTheoristPrompt>
%   >> send startCommandInput message
%   <readCommandInput>
%   >> send doneCommandInput message
%   >> send startExplanations message
%   for each explanation do
%       <processExplanation>
%       >> send explanation message
%       <printExplanation>
%       >> send nextExplanation message
%   endFor
%   >> send doneExplanations message
%
%   See module commandDispatcher, processCommand/2, for more details.

:- multifile user:message_hook/3.

user:message_hook(startExplanations, _, _) :-
	workspaceWidget(Shell, Shell, widget, shell),
	disableMenuItems(Shell, xworkspace:workspaceWidget, [file, options, window, help]),
	fail.

user:message_hook(doneExplanations, _, _) :-
	workspaceWidget(Shell, Shell, widget, shell),
	enableMenuItems(Shell, xworkspace:workspaceWidget, [file, options, window, help]),
	fail.

user:message_hook(explanation, _, _) :-
	workspaceWidget(Shell, Shell, widget, shell),
	workspaceWidget(NextAnswerButton, Shell, button, nextAnswerButton),
	workspaceWidget(NoMoreAnswerButton, Shell, button, noMoreAnswerButton),
	workspaceWidget(RemainingButton, Shell, button, remainingButton),
	xtSetSensitive(NextAnswerButton, 1),
	xtSetSensitive(NoMoreAnswerButton, 1),
	xtSetSensitive(RemainingButton, 1),
	fail.

user:message_hook(nextExplanation, _, _) :-
	workspaceWidget(Shell, Shell, widget, shell),
	workspaceWidget(NextAnswerButton, Shell, button, nextAnswerButton),
	workspaceWidget(NoMoreAnswerButton, Shell, button, noMoreAnswerButton),
	workspaceWidget(RemainingButton, Shell, button, remainingButton),
	xtSetSensitive(NextAnswerButton, 0),
	xtSetSensitive(NoMoreAnswerButton, 0),
	xtSetSensitive(RemainingButton, 0),
	fail.

user:message_hook(exitTheorist, _, _) :-
	workspaceWidget(Shell, Shell, widget, shell),
	fileQuit(Shell, _, _).
