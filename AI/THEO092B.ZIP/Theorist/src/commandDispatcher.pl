%   Module : commandDispatcher
%   Authors: George Ferguson, Scott Goodwin, Pat Fitzsimmons,
%            Abdul Sattar, Bonita Wong, Daniel Lanovaz, Art Mulder.
%   Updated: 3/3/92
%   Defines: Main command execution program module.
%
%   The following theorist commands are supported:
%
%	askable    <atomicLiteral>
%	clear
%	clear      <constArg>
%	end, halt, quit, bye, ^D
%	explain    <formula>
%	explainAll <formula>
%	fact       <formula>
%	help
%	help       <constArg>
%	history
%	hypothesis <atomicLiteral> : <formula>
%       compile    <constArg>
%	consult    <constArg>
%	list
%	list       <constArg>
%	listall
%       load       <constArg>
%	meta       <atomicLiteral>
%	redo
%	redo       <integer>
%	redo       <command>
%	restore    <constant>
%	save       <constant>
%	unix       cd
%	unix       cd(<constant>)
%	unix       shell
%	unix       <constant>
%
%   See module Parser for a description of the command argument syntax.

:- module(commandDispatcher, [
	doCommand/1,
	inputLoop/0,
	ppCommand/1,
	processCommand/2
   ]).

:- use_module(library(files), [
	file_exists/2
   ]),
   use_module(library(environ), [	%% ...art mulder
	environ/2
   ]),
   use_module(library(unix), [
	more/1
   ]),
   use_module(ask, [
	yesno/2
   ]),
   use_module(wff, [
	convertToClauses/2,
	convertToProlog/2,
	ppWff/1,
	ppWithLetterVars/3
   ]),
   use_module(interpreter, [
	explain/1,
	explainAll/1
   ]),
   use_module(parser, [
	getCommand/1
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(database, [
	assertDatabaseItem/1,
	clearDatabaseConfirm/0,
	clearDatabaseConfirm/1,
	inputDatabase/1,
	listDatabase/0,
	listDatabase/1,
	restoreDatabase/1,
	saveDatabase/1
   ]),
   use_module(interpreterDatabase, [
	listInterpreterDatabase/0,
	listInterpreterDatabase/1
   ]),
   use_module(commandHistory, [
	commandHistoryLength/2,
	nth1CommandHistory/3,
	pushCommandHistory/3,
	printCommandHistory/1
   ]),
   use_module(variableBinding, [
        replaceVariables/3
   ]),
   use_module(prolog, [
	loadPrologFile/1
   ]).

sccs_id('"@(#) 3/3/92 10:52:30 commandDispatcher.pl 1.2"').

:- mode
	doCommand(+),
	doHelp(+),

	executeCommand(+, +, -),
	ppCommand(+),
		ppCommand_(+),
	processCommand(+, +),
	processCommandException(+).

/* pred
	doCommand(Term),
	doHelp(list(Term)),

	ppCommand(Term),
		ppCommand_(Term),
	executeCommand(Command, CommandHistory, CommandHistory),
	processCommand(Term, CommandHistory),
	processCommandException(Term).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Processing                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   processCommand(+PromptString, +CommandHistory)
%   is true when each user command is executed successfully.  Note that to avoid
%   a considerable amount of heap garbage from collecting, this recursive
%   predicate performs garbage collection after each command is executed.
%   CommandHistory is a history of commands the user has issued.

processCommand(PromptString, CommandHistory) :-
	write(PromptString),
	current_output(OutputStream), flush_output(OutputStream),
	on_exception(Exception, (
		sendStartCommandInputMessage,
		getCommand(Command),
		sendDoneCommandInputMessage,
		sendStartExplanationsMessage,
		(   executeCommand(Command, CommandHistory, NewCommandHistory) -> true
		;   true
		),
		sendDoneExplanationsMessage
		), processCommandException(Exception)),
	!,
	garbage_collect,
	processCommand(PromptString, NewCommandHistory).  % Repeat forever.



%   inputLoop
%   is always true - just like run but non-interactive.
%   Note that the command history functionality is not available during
%   non-interactive input.

inputLoop :-
	repeat,
	    getCommand(Command),
	    (   Command == end -> true
	    ;   doCommand(Command),
	        fail
	    ),
	!.
	


%   executeCommand(+Command, +CommandHistory, -NewCommandHistory)
%   is true if Command is successfully executed and added to CommandHistory
%   to create NewCommandHistory.

executeCommand(redo, CommandHistory, NewCommandHistory) :- !,
	commandHistoryLength(CommandHistory, Length),
	(   nth1CommandHistory(Length, CommandHistory, ToDoCommand) ->
	    executeCommand(ToDoCommand, CommandHistory, NewCommandHistory)
	;   CommandHistory = NewCommandHistory
	).
executeCommand(redo(RedoNum), CommandHistory, NewCommandHistory) :-
	integer(RedoNum), !,
	(   nth1CommandHistory(RedoNum, CommandHistory, ToDoCommand) ->
	    executeCommand(ToDoCommand, CommandHistory, NewCommandHistory)
	;   CommandHistory = NewCommandHistory
	).
executeCommand(redo(RedoCommand), CommandHistory, NewCommandHistory) :- !,
	(   nth1CommandHistory(_, CommandHistory, RedoCommand) ->
	    executeCommand(RedoCommand, CommandHistory, NewCommandHistory)
	;   print_message(error, commandMatchFailed),
	    CommandHistory = NewCommandHistory
	).
executeCommand(history, CommandHistory, NewCommandHistory) :- !,
	pushCommandHistory(history, CommandHistory, NewCommandHistory),
	printCommandHistory(NewCommandHistory).
executeCommand(Command, CommandHistory, NewCommandHistory) :-
	pushCommandHistory(Command, CommandHistory, NewCommandHistory),
	doCommand(Command).



%   doCommand(+Command)
%   is true if Command is a valid Theorist command and it executed successfully.

doCommand(end) :-
	(   user:message_hook(exitTheorist, _, _) -> true
	;   theoristResource(messageString, exitTheoristString, Astring),
	    (   current_output(Stream),
	        line_position(Stream, 0) ->
	        true
	    ;   nl
	    ),
	    yesno(Astring, []),
	    halt
	).

doCommand(eof).

doCommand(syntaxError) :-
	print_message(error, syntaxError).

doCommand(fact(Fact, Variables)) :-
	convertToClauses(Fact, ListOfClauses),
	convertToProlog(ListOfClauses, PrologClauses),
	assertDatabaseItem(fact(Fact, PrologClauses, Variables)).

doCommand(hypothesis(Name, Variables)) :-
	assertDatabaseItem(hypothesis(Name, [], [], Variables)).
doCommand(hypothesis(Name, Formula, Variables)) :-
	convertToClauses(Formula, Clauses),
	convertToProlog(Clauses, PrologClauses),
	assertDatabaseItem(hypothesis(Name, Formula, PrologClauses, Variables)).

doCommand(askable(Askable)) :-
	assertDatabaseItem(askable(Askable)).

doCommand(meta(Meta)) :-
	assertDatabaseItem(meta(Meta)).

doCommand(explain(Formula)) :-
	convertToClauses(Formula, Clauses),
	explain(Clauses).

doCommand(explainAll(Formula)) :-
	convertToClauses(Formula, Clauses),
	explainAll(Clauses).

doCommand(compile(_File)).

doCommand(load(File)) :-
	loadPrologFile(File).

doCommand(consult(File)) :-
	(   atomic(File) ->
	    inputDatabase([File])
	;   inputDatabase(File)
	).

%   Help is commented out until it can be fixed for Quintus Prolog
%   Release 3.0.

%% try uncommenting the following for QP 3.1.1 (...art m)
%% Original:
%% ----
%% doCommand(help). %  :-
%% %	theoristResource(messageString, helpFile, HelpFile),
%% %	doHelp([HelpFile]).
%% doCommand(help(_A)). %  :-		% atomic arg to help
%% % 	(   atomic(A) ->
%% % 	    doHelp([A])
%% % 	;   doHelp(A)
%% % 	).
%% ----
%% New:
%% ----
doCommand(help)  :-
 	theoristResource(messageString, helpFile, HelpFile),
 	doHelp([HelpFile]).
doCommand(help(A))  :-		% atomic arg to help
 	(   atomic(A) ->
 	    doHelp([A])
 	;   doHelp(A)
 	).
%% ----

doCommand(list) :-
	listDatabase.
doCommand(list(A)) :-
	listDatabase(A).

doCommand(listall) :-
	listInterpreterDatabase.
doCommand(listall(A)) :-
	listInterpreterDatabase(A).

doCommand(clear) :-
	( clearDatabaseConfirm, ! ; true).
doCommand(clear(Item)) :-
	( clearDatabaseConfirm(Item), ! ; true).

doCommand(save(File)) :-
	saveDatabase(File).

doCommand(restore(File)) :-
	restoreDatabase(File).

doCommand(unix(cd(Path))) :- !,
	( unix(cd(Path)), ! ; true).
doCommand(unix(cd)) :- !,
	( unix(cd), ! ; true).

% Removed because of problems with QUI.
%doCommand(unix(shell)) :- !,
%	( unix(shell), ! ; true).

doCommand(unix(Command)) :-
	( unix(system(Command)), ! ; true ).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Help                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   doHelp(+List)
%   is true if the help commands in List are successfully displayed.

doHelp([]).
doHelp([H|T]) :-
	name(H, Subject),
	theoristResource(messageString, helpDirectory, HelpDir),
	name(HelpDir, HelpDirList),
	theoristResource(messageString, helpExtension, HelpExt),
	name(HelpExt, HelpExtList),
	append(HelpDirList, Subject, F1),
	append(F1, HelpExtList, File),
	name(F,File),
%%	    more(F)
	(   file_exists(F, read) ->
	    page(F)
	;   print_message(error, noHelpFile(H))
	),
	doHelp(T).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Printing                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   ppCommand(+Command)
%   is true if Command is pretty printed to the current output stream.

ppCommand(fact(Item, Variables)) :- !,
	replaceVariables(Item, Variables, NewItem),
	write('fact '),
	ppWff(NewItem).
ppCommand(hypothesis(Name, Hyp, Variables)) :- !,
	replaceVariables(Name, Variables, NewName),
	replaceVariables(Hyp, Variables, NewHyp),
	write('hypothesis '),
	ppWff(NewName),
	write(' : '),
	ppWff(NewHyp).
ppCommand(Command) :-
	ppWithLetterVars(Command, commandDispatcher, ppCommand_).

ppCommand_(meta(Item)) :- !,
	write('meta '),
	ppWff(Item).
ppCommand_(askable(Item)) :- !,
	write('askable '),
	ppWff(Item).
ppCommand_(input(Item)) :- !,
	write('input '),
	write(Item).
ppCommand_(save(Item)) :- !,
	write('save '),
	write(Item).
ppCommand_(restore(Item)) :- !,
	write('restore '),
	write(Item).
ppCommand_(clear(Item)) :- !,
	write('clear '),
	write(Item).
ppCommand_(explain(Item)) :- !,
	write('explain '),
	ppWff(Item).
ppCommand_(explainAll(Item)) :- !,
	write('explainAll '),
	ppWff(Item).
ppCommand_(help(Item)) :- !,
	write('help '),
	write(Item).
ppCommand_(list(facts(A))) :- !,
	write('list facts '),
	write(A).
ppCommand_(list(hypotheses(A))) :- !,
	write('list hypotheses '),
	write(A).
ppCommand_(list(askables(A))) :- !,
	write('list askables '),
	write(A).
ppCommand_(list(metas(A))) :- !,
	write('list metas '),
	write(A).
ppCommand_(list(Item)) :- !,
	write('list '),
	write(Item).
ppCommand_(unix(Item)) :- !,
	write('unix '),
	write(Item).
ppCommand_(X) :- write(X).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Messages                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   sendStartExplanationsMessage
%   is true when a message is broadcast to the entire world
%   that explanation execution is about to begin.  This is used,
%   for instance, by the graphical user interface to set-up
%   menus and buttons prior to execution.

sendStartExplanationsMessage :-
	(   user:message_hook(startExplanations, _, _) -> true
	;   true
	).

%   sendDoneExplanationsMessage
%   is true when a message is broadcast to the entire world
%   that explanation execution is complete.  This is used, for
%   instance, by the graphical user interface to set-up
%   menus and buttons after explanation completion.

sendDoneExplanationsMessage :-
	(   user:message_hook(doneExplanations, _, _) -> true
	;   true
	).

%   sendStartCommandInputMessage
%   is true when a message is broadcast that Theorist is about
%   to start reading an input command.

sendStartCommandInputMessage :-
	(   user:message_hook(startCommandInput, _, _) -> true
	;   true
	).

%   sendDoneCommandInputMessage
%   is true when a message is broadcase that Theorist is done
%   reading a command from the standard input.

sendDoneCommandInputMessage :-
	(   user:message_hook(doneCommandInput, _, _) -> true
	;   true
	).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Exception handling            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   processCommandException(+Exception)
%   an exception (Exception) has occurred while processing
%   a command.  Fix up the state of XTheorist as if the
%   command had completed successfully and then re-raise
%   the exception.

processCommandException(Exception) :-
	sendDoneCommandInputMessage,
	sendDoneExplanationsMessage,
	raise_exception(Exception).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Private.  Utility             % ...art mulder
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% page: analagous to the unix "more" command.
%       The library function "more" in the "unix" library
%       does not work (Quintus Prolog 3.1.1).  so work around it.
%
% - check PAGER environment variable.
% - lacking that, get default from resources.
page(File) :-
        theoristResource(messageString, defaultPager, DefaultPager),
        (   environ('PAGER', Pager) -> true
%       ;   Pager = '/usr/ucb/more'
        ;   Pager = DefaultPager
        ),
        name(Pager,PagerList),                  %% Convert to list format.
        name(File,FileList),
        append(PagerList, " ", Temp),           %% Concatenate together
        append(Temp, FileList, CommandList),
        name(UnixCommand,CommandList),          %% Convert Back to Constant.
	unix(shell(UnixCommand)).               %% ... & execute.

%%%%%%%
% END %
%%%%%%%

