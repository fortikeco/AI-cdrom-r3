%   Module : xstring
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with ProXT strings.
%
%   This module contains additional predicates for manipulating ProXT
%   string objects.  Currently three string objects are supported:
%
%       CharPtr  = char_ptr(IntegerID)
%       XmString = xmstring(IntegerID)
%       String   = atom

:- module(xstring, [
	charPtrToXmString/2,
	xmStringToCharPtr/2,
	xmStringToString/2,
	xmStringToString/3,
	stringToXmString/2,
	stringToXmString/3
   ]).

:- use_module(library(proxt), [
	proxtCharPtrToString/2,
	proxtGetDefaultCharset/1,
	proxtStringToCharPtr/2,
	xmStringCreate/3,
	xmStringGetLtoR/4
   ]),
   use_module(library(proxl), [
   ]).

sccs_id('"@(#) 11/26/91 09:39:49 xstring.pl 1.1"').

:- mode
	charPtrToXmString(+, -),
	xmStringToCharPtr(+, -),
	xmStringToString(+, -),
	xmStringToString(+, +, -),
	stringToXmString(+, -),
	stringToXmString(+, +, -).

/* pred
	charPtrToXmString(CharPtr, XmString),
	xmStringToCharPtr(XmString, CharPtr),
	xmStringToString(XmString, String),
	xmStringToString(XmString, XmStringCharset, String),
	stringToXmString(String, XmString),
	stringToXmString(String, XmStringCharset, XmString).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Converting                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

charPtrToXmString(CharPtr, XmString) :-
	proxtGetDefaultCharset(DefaultCharset),
	xmStringCreate(CharPtr, DefaultCharset, XmString).

xmStringToString(XmString, String) :-
	proxtGetDefaultCharset(DefaultCharset),
	xmStringToString(XmString, DefaultCharset, String).

xmStringToString(XmString, CharSet, String) :-
	xmStringGetLtoR(XmString, CharSet, CharPtr, true),
	proxtCharPtrToString(CharPtr, String).

xmStringToCharPtr(XmString, CharPtr) :-
	xmStringToString(XmString, String),
	proxtStringToCharPtr(String, CharPtr).

stringToXmString(String, XmString) :-
	proxtGetDefaultCharset(DefaultCharset),
	stringToXmString(String, DefaultCharset, XmString).

stringToXmString(String, Charset, XmString) :-
	proxtStringToCharPtr(String, CharPtr),
	xmStringCreate(CharPtr, Charset, XmString).
