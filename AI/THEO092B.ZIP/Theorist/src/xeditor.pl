%   Module : xeditor
%   Author : Daniel Lanovaz
%   Updated: 2/6/92
%   Defines: XTheorist Editor Window
%
%   XTheorist's edit window is used to edit source database information
%   stored in a disk file.  The editor can be used to modify the source
%   using a standard Motif text edit widget.  The modified source can
%   be loaded directly into XTheorist.
%
%   The edit window is divided into two sections:
%
%       -----------------------------------------------
%       | File Misc                              Help | <-MenuBar
%       |---------------------------------------------|
%       | Text Edit Pane                              |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       -----------------------------------------------
%
%   Menu bar: Contains three menus: File, Misc, and Help.
%   Text Edit pane: Contains the source editable text.
%
%   For a more detailed description of the edit window, consult
%   the User's Guide.
%
%   This file is divided into the following sections.  Note that
%   depending on the size of the source code, it may be necessary
%   (beneficial) to divide this file into primitive object files.

:- module(xeditor, [
	editorOpen/0,
	editorOpen/1,
	editorOpenOn/1,
	editorOpenAndLoad/0
   ]).

:- use_module(library(proxt), [
	proxtStringToCharPtr/2,
	xmCreateForm/4,
	xmCreateMenuBar/4,
	xmCreateScrolledText/4,
	xmTextGetInsertionPosition/2,
	xmTextGetString/2,
	xmTextReplace/4,
	xmTextSetString/2,
	xtAddCallback/4,
	xtAppCreateShell/6,
	xtManageChild/1,
	xtParent/2,
	xtRealizeWidget/1,
	xtRemoveCallback/4,
	xtSetKeyboardFocus/2,
	xtSetSensitive/2,
	xtSetValues/2,
	xtUnmanageChild/1
   ]),
   use_module(library(proxl), [
	default_display/1,
	display_xdisplay/2
   ]),
   use_module(library(critical), [
	critical/1
   ]),
   use_module(library(files), [
	file_exists/1,
	file_exists/2
   ]),
   use_module(library(strings), [
	gensym/2
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(xmenu, [
	createMenuButtons/4,
	disableMenuItems/3,
	enableMenuItems/3
   ]),
   use_module(window, [
	destroyWidgetRootWindow/1,
	rootWidget/2,
	windowName/2
   ]),
   use_module(xstring, [
	stringToXmString/2,
	xmStringToString/2
   ]),
   use_module(file, [
	readFileIntoCharPtr/2,
	writeCharPtrIntoFile/2,
	freeFileCharPtr/1
   ]),
   use_module(xdialog, [
	createErrorDialog/4,
	createFileSelectionDialog/5,
	createYesNoDialog/10,
	createNotYetImplementedDialog/2,
	dialogWindowOnTop/1,
	releaseDialogs/1
   ]),
   use_module(format, [
	formatToAtom/3
   ]),
   use_module(xcommandPane, [
	executeCommand/2
   ]),
   use_module(xhelp, [
	helpOpenOn/2
   ]).

:- dynamic
	% editorWidget(Widget, Shell, WidgetType, WidgetName)
	% is true when Widget is a widget of WidgeType named WidgetName for
	% the editor represented by Shell.  This predicate is
	% used to maintain global access to important Widgets.
	editorWidget/4.

sccs_id('"@(#) 2/6/92 10:22:21 xeditor.pl 1.2"').

% :- mode

/* pred
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   editorOpen
%   is true when XTheorist's editor window is created and displayed.

editorOpen :-
	editorOpen(_).

%   editorOpenOn(+FileName)
%   is true when XTheorist's editor window is created and displayed
%   for the disk file FileName.

editorOpenOn(_FileName).



%   editorOpen(-Editor)
%   is true when an editor window is created and displayed.  Editor is bound
%   to the toplevel editor widget.

editorOpen(Editor) :-
        theoristResource(widgetName, xTheorist, XTheorist),
        theoristResource(widgetName, xTheoristClass, XTheoristClass),
	default_display(Display),
	display_xdisplay(Display, XDisplay),
	xtAppCreateShell(XTheorist, XTheoristClass, shellWidgetClass,
		xtdisplay(XDisplay), [], Shell),
%%		xdisplay(XDisplay), [], Shell),
	editorOpen(Shell, Editor),
	xtRealizeWidget(Shell),
	scrolledTextKeyboardFocus(Shell),
	generateNextDefaultWindowName(EditorWindowName),
	setEditorWindowName(Shell, EditorWindowName).



%   editorOpenAndLoad
%   is true when a XTheorist editor window is created and displayed
%   and the user is prompted to select a file.

editorOpenAndLoad :-
	editorOpen(Editor),
	fileEdit(Editor, _, _).



%   openEditor(+Shell)
%   is true when XTheorist's editor window is created and displayed.
%   The parent of the new window is Shell.

editorOpen(Shell, Editor) :-
	theoristResource(widgetName, editor, EditorName),
	xmCreateForm(Shell, EditorName, [], Editor),
	xtManageChild(Editor),
	addMenuBar(Editor, MenuBar),
	addTextPane(Editor, MenuBar, _).

addMenuBar(Editor, MenuBar) :-
	theoristResource(widgetName, editorMenuBar, MenuBarName),
	xmCreateMenuBar(Editor, MenuBarName, [], MenuBar),
	xtManageChild(MenuBar),
	createMenuButtons(_, MenuBar, xeditor:menuBarData, xeditor:editorWidget),
	fileNoFileMenuItems(ItemList),
	disableMenuItems(Editor, xeditor:editorWidget, ItemList).

addTextPane(Editor, MenuBar, ScrolledText) :-
	theoristResource(widgetName, editorTextPane, TextPaneName),
	theoristResource(widgetName, editorScrolledText, ScrolledTextName),
	xmCreateForm(Editor, TextPaneName, [xmNtopWidget(MenuBar)], TextForm),
	xtManageChild(TextForm),
	xmCreateScrolledText(TextForm, ScrolledTextName, [xmNeditMode(xmMULTI_LINE_EDIT)], ScrolledText),
	xtManageChild(ScrolledText),
	xtSetSensitive(ScrolledText, 0),
	xtAddCallback(ScrolledText, xmNmodifyVerifyCallback, xeditor:modifyVerifyCallback, _),
	rootWidget(Editor, Shell),
	assert((editorWidget(ScrolledText, Shell, widget, ScrolledTextName) :- !)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Menubar                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   menuBarData(+MenuItemList)
%   is true if MenuItemList is a list of menuItem structures
%   that specify the items within each editor menu.
%   See documentation in module menu for a description of the
%   MenuItemList datastructure.

menuBarData([
	subMenuItem(file,	xeditor:fileMenuData,	_),
	subMenuItem(misc,	xeditor:miscMenuData,	_),
	helpSubMenuItem(help,	xeditor:helpMenuData,	_)
	]).

fileMenuData([
	menuItem(fileEdit,	xeditor:fileEdit,	_),
	menuItem(fileCompile,	xeditor:fileCompile,	_),
	menuItem(fileInsert,	xeditor:fileInsert,	_),
	menuItem(fileSave,	xeditor:fileSave,	_),
	menuItem(fileSaveAs,	xeditor:fileSaveAs,	_),
	separatorMenuItem,
	menuItem(fileQuit,	xeditor:fileQuit,	_)
	]).

miscMenuData([
	menuItem(miscFindReplace,	xeditor:miscFindReplace,	_),
	menuItem(miscGoto,		xeditor:miscGoto,	_)
	]).

helpMenuData([
	menuItem(helpOnThisWindow,	xeditor:helpOnThisWindow, _)
	]).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Menubar Callbacks             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fileEdit(Widget, _, _) :-
	rootWidget(Widget, Shell),
	(   editorWidget(_OldFileName, Shell, fileName, value),
	    editorWidget(textModified, Shell, modified, value) ->
	    theoristResource(widgetName, editorSaveChangesDialog, SaveChangesName),
	    theoristResource(messageString, saveChanges, SaveChanges),
	    displayYesNoDialog(Widget, SaveChangesName, SaveChanges,
	        fileEditSave, SaveChangesDialog,
		fileEditNoSave, SaveChangesDialog,
		dialogCancel, SaveChangesDialog, SaveChangesDialog)
	;   displayFileSelectionDialog(Widget, FileSelection),
	    xtManageChild(FileSelection)
	).

fileInsert(Widget, _, _) :-
	displayFileInsertSelectionDialog(Widget, FileSelection),
	xtManageChild(FileSelection).

fileCompile(Widget, _, _) :-
	rootWidget(Widget, Shell),
	(   editorWidget(textModified, Shell, _, _) ->
	    fileSave(Widget, _, _)
	;   true
	),
	editorWidget(FileName, Shell, fileName, value),
	theoristResource(messageString, consultCommandString, ConsultCommand),
	formatToAtom(ConsultCommand, [FileName], Command),
	executeCommand(Widget, Command).

fileSave(Widget, _, _) :-
	rootWidget(Widget, Shell),
	editorWidget(textModified, Shell, _, _),
	editorWidget(FileName, Shell, fileName, value),
	theoristResource(widgetName, editorScrolledText, ScrolledTextName),
	editorWidget(ScrolledText, Shell, widget, ScrolledTextName),
	saveTextToFile(ScrolledText, FileName),
	retract((editorWidget(textModified, Shell, _, _) :- !)).

fileSaveAs(Widget, _, _) :-
	displaySaveAsDialog(Widget, _).

fileQuit(Widget, _, _) :-
	rootWidget(Widget, Shell),
	(   editorWidget(_FileName, Shell, fileName, value),
	    editorWidget(textModified, Shell, modified, value) ->
	    theoristResource(widgetName, editorSaveChangesDialog, SaveChangesName),
	    theoristResource(messageString, saveChanges, SaveChanges),
	    displayYesNoDialog(Widget, SaveChangesName, SaveChanges,
	        fileQuitSave, SaveChangesDialog,
		fileQuitNoSave, SaveChangesDialog,
		dialogCancel, SaveChangesDialog, SaveChangesDialog),
	    fail
	;   fileQuitNoSave(Widget, _, _)
	).

miscFindReplace(Widget, _, _) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).

miscGoto(Widget, _, _) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).

helpOnThisWindow(Widget, _, _) :-
	helpOpenOn(Widget, 'Editor').



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Editor Callbacks              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   modifyVerifyCallback(+Widget, +ClientData, +CallData)
%   is true when the user has modified the text edit window in some way.
%   Record this fact.

modifyVerifyCallback(Widget, _ClientData, _CallData) :-
	rootWidget(Widget, Shell),
	(   editorWidget(textModified, Shell, modified, value) -> true
	;   assert((editorWidget(textModified, Shell, modified, value) :- !))
	).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Dialogs                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

displayYesNoDialog(Widget, DialogName, Message,
		YesCommand,    YesCommandData,
		NoCommand,     NoCommandData,
		CancelCommand, CancelCommandData, Dialog) :-
	rootWidget(Widget, Shell),
	(   editorWidget(Dialog, Shell, dialog, DialogName) ->
	    xtRemoveCallback(Dialog, xmNokCallback, _, _),
	    xtRemoveCallback(Dialog, xmNcancelCallback, _, _),
	    xtRemoveCallback(Dialog, xmNhelpCallback, _, _),
	    xtAddCallback(Dialog, xmNokCallback, YesCommand, YesCommandData),
	    xtAddCallback(Dialog, xmNcancelCallback, NoCommand, NoCommandData),
	    xtAddCallback(Dialog, xmNhelpCallback, CancelCommand, CancelCommandData),
	    dialogWindowOnTop(Dialog)
	;   createYesNoDialog(Widget, DialogName, Message,
		YesCommand,    YesCommandData,
		NoCommand,     NoCommandData,
		CancelCommand, CancelCommandData, Dialog),
	    assert((editorWidget(Dialog, Shell, dialog, DialogName) :- !))
	),
        xtManageChild(Dialog).

displayFileSelectionDialog(Widget, FileSelection) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, editorFileSelectionDialog, FileSelectionDialogName),
	(   editorWidget(FileSelection, Shell, dialog, FileSelectionDialogName) ->
	    dialogWindowOnTop(FileSelection)
	;   createFileSelectionDialog(Widget, FileSelectionDialogName,
		fileEditOK, dialogCancel, FileSelection),
	    assert((editorWidget(FileSelection, Shell, dialog, FileSelectionDialogName) :- !))
	).

displayFileInsertSelectionDialog(Widget, FileSelection) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, editorFileInsertSelectionDialog, FileInsertionDialogName),
	(   editorWidget(FileSelection, Shell, dialog, FileInsertionDialogName) ->
	    dialogWindowOnTop(FileSelection)
	;   createFileSelectionDialog(Widget, FileInsertionDialogName,
		fileInsertOK, dialogCancel, FileSelection),
	    assert((editorWidget(FileSelection, Shell, dialog, FileInsertionDialogName) :- !))
	).

displayErrorDialog(Widget, ErrorMessage) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, errorDialog, ErrorDialogName),
	(   editorWidget(ErrorDialog, Shell, dialog, ErrorDialogName) ->
	    stringToXmString(ErrorMessage, ErrorString),
	    xtSetValues(ErrorDialog, [xmNmessageString(ErrorString)]),
	    dialogWindowOnTop(ErrorDialog)
	;   createErrorDialog(Widget, ErrorDialogName, ErrorMessage, ErrorDialog),
	    assert((editorWidget(ErrorDialog, Shell, dialog, ErrorDialogName) :- !))
	),
	xtManageChild(ErrorDialog).

displaySaveAsDialog(Widget, SaveAsDialog) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, editorSaveAsDialog, SaveAsDialogName),
	(   editorWidget(SaveAsDialog, Shell, dialog, SaveAsDialogName) ->
	    dialogWindowOnTop(SaveAsDialog)
	;   createFileSelectionDialog(Widget, SaveAsDialogName,
		fileSaveAsOK, dialogCancel, SaveAsDialog),
	    assert((editorWidget(SaveAsDialog, Shell, dialog, SaveAsDialogName) :- !))
	),
	xtManageChild(SaveAsDialog).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Dialog Callbacks              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   fileEditOK(+Widget, +ClientData, +CallData)
%   is true when the user has selected the OK button of the
%   FileSelectionBox and the selected file is successfully read
%   into the editor.  The CallData contains a pointer to a
%   string indicating the selected file.

fileEditOK(Widget, Dialog, [_, _, value(Value), _]) :-
	rootWidget(Widget, Shell),
%%	xmStringToString(xmstring(Value), RelativeFileName),
	xmStringToString(Value, RelativeFileName),
	absolute_file_name(RelativeFileName, NewFileName),
	(   file_exists(NewFileName, read),
	    readInFile(NewFileName, Dialog),
	    fileNoFileMenuItems(ItemList),
	    enableMenuItems(Widget, xeditor:editorWidget, ItemList),
	    critical((
	    	( retract((editorWidget(_, Shell, fileName, value) :- !)) ; true ),
	    	assert((editorWidget(NewFileName, Shell, fileName, value) :- !))
	    )),
	    xtUnmanageChild(Dialog),
	    theoristResource(widgetName, editorScrolledText, ScrolledTextName),
	    editorWidget(ScrolledText, Shell, widget, ScrolledTextName),
	    xtSetSensitive(ScrolledText, 1),
	    scrolledTextKeyboardFocus(Shell) -> true
	;   theoristResource(messageString, newFileString, NewFileString),
	    theoristResource(widgetName, editorNewFileDialog, DialogName),
	    displayYesNoDialog(Widget, DialogName, NewFileString,
		newFileOK, [NewFileDialog, Dialog, NewFileName],
		dialogCancel, NewFileDialog,
		dialogCancel, NewFileDialog, NewFileDialog),
	    xtManageChild(NewFileDialog)
	).

fileInsertOK(Widget, Dialog, [_, _, value(Value), _]) :-
	rootWidget(Widget, Shell),
%%	xmStringToString(xmstring(Value), RelativeFileName),
	xmStringToString(Value, RelativeFileName),
	absolute_file_name(RelativeFileName, FileName),
	(   file_exists(FileName, read),
	    readFileIntoCharPtr(FileName, FileCharPtr),
	    theoristResource(widgetName, editorScrolledText, ScrolledTextName),
	    editorWidget(ScrolledText, Shell, widget, ScrolledTextName),
	    xmTextGetInsertionPosition(ScrolledText, Position),
	    xmTextReplace(ScrolledText, Position, Position, FileCharPtr),
	    freeFileCharPtr(FileCharPtr),
	    xtUnmanageChild(Dialog),
	    scrolledTextKeyboardFocus(Shell) -> true
	;   theoristResource(errorString, cannotAccessFileString, AccessString),
	    formatToAtom(AccessString, [FileName], AccessAtom),
	    displayErrorDialog(Widget, AccessAtom)
	).

fileSaveAsOK(Widget, Dialog, [_, _, value(Value), _]) :-
	rootWidget(Widget, Shell),
%%	xmStringToString(xmstring(Value), RelativeFileName),
	xmStringToString(Value, RelativeFileName),
	absolute_file_name(RelativeFileName, FileName),
	editorWidget(OldFileName, Shell, fileName, value),
	(   OldFileName \== FileName,
	    file_exists(FileName) ->
	    theoristResource(widgetName, editorOverwriteDialog, OverwriteDialogName),
	    theoristResource(messageString, overwriteString, OverwriteString),
	    formatToAtom(OverwriteString, [FileName], OverwriteAtom),
	    displayYesNoDialog(Widget, OverwriteDialogName, OverwriteAtom,
	        overwriteFile, FileName,
		dialogCancel, OverwriteDialog,
		dialogCancel, OverwriteDialog, OverwriteDialog)
	;   overwriteFile(Widget, FileName, _),
	    scrolledTextKeyboardFocus(Shell),
	    xtUnmanageChild(Dialog)
	).
	
saveChangesCancel(Widget, Dialog, _CallData) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, editorSaveChangesDialog, SaveChangesName),
	retract((editorWidget(_SaveChangesDialog, Shell, dialog, SaveChangesName) :- !)),
	xtUnmanageChild(Dialog).

dialogCancel(Widget, Dialog, _CallData) :-
	scrolledTextKeyboardFocus(Widget),
	xtUnmanageChild(Dialog).

fileQuitSave(Widget, _, _) :-
	fileSave(Widget, _, _),
	fileQuitNoSave(Widget, _, _).

fileQuitNoSave(Widget, _, _) :-
	rootWidget(Widget, Shell),
	(   findall(DialogWidget, clause(editorWidget(DialogWidget, Shell, dialog, _), !), DialogList) ->
	    releaseDialogs(DialogList)
	;   true
	),
	retractall(editorWidget(_, Shell, _, _)),
	destroyWidgetRootWindow(Widget).

fileEditSave(Widget, Dialog, _) :-
	fileSave(Widget, _, _),
	xtUnmanageChild(Dialog),
	fileEdit(Widget, _, _).

fileEditNoSave(Widget, Dialog, _) :-
	xtUnmanageChild(Dialog),
	displayFileSelectionDialog(Widget, FileSelection),
	xtManageChild(FileSelection).

overwriteFile(Widget, FileName, _) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, editorScrolledText, ScrolledTextName),
	editorWidget(ScrolledText, Shell, widget, ScrolledTextName),
	saveTextToFile(ScrolledText, FileName),
	( retract((editorWidget(textModified, Shell, _, _) :- !)), ! ; true ),
	critical((
		retract((editorWidget(_OldFileName, Shell, fileName, value) :- !)),
		assert((editorWidget(FileName, Shell, fileName, value) :- !))
	)),
	theoristResource(widgetName, editorSaveAsDialog, SaveAsDialogName),
	editorWidget(SaveAsDialog, Shell, dialog, SaveAsDialogName),
	xtUnmanageChild(SaveAsDialog),
	xtUnmanageChild(Widget),
	setEditorWindowName(ScrolledText, FileName).

newFileOK(Widget, [NewFileDialog, FileEditDialog, NewFileName], _) :-
	rootWidget(Widget, Shell),
	theoristResource(widgetName, editorScrolledText, ScrolledTextName),
	editorWidget(ScrolledText, Shell, widget, ScrolledTextName),
	fileNoFileMenuItems(ItemList),
	proxtStringToCharPtr('', FileCharPtr),
	critical((
		enableMenuItems(Widget, xeditor:editorWidget, ItemList),
		( retract((editorWidget(_, Shell, fileName, value) :- !)) ; true ),
		assert((editorWidget(NewFileName, Shell, fileName, value) :- !)),
		xmTextSetString(ScrolledText, FileCharPtr),
		( retract((editorWidget(textModified, Shell, _, _) :- !)), ! ; true )
	)),
	xtUnmanageChild(NewFileDialog),
	xtUnmanageChild(FileEditDialog),
	xtSetSensitive(ScrolledText, 1),
	scrolledTextKeyboardFocus(Shell),
	setEditorWindowName(Shell, NewFileName).
	



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File Accessing                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

readInFile(FileName, FileSelectionBox) :-
	rootWidget(FileSelectionBox, RootWidget),
	theoristResource(widgetName, editorScrolledText, ScrolledTextName),
	editorWidget(ScrolledText, RootWidget, widget, ScrolledTextName),
	readFileIntoCharPtr(FileName, FileCharPtr),
	xmTextSetString(ScrolledText, FileCharPtr),
	freeFileCharPtr(FileCharPtr),
	setEditorWindowName(RootWidget, FileName).

%   fileNoFileMenuItems(-ItemList)
%   is true when ItemList is a list of menu items that needs to be disable/enabled
%   when there is no file (or a file respectively) to edit.

fileNoFileMenuItems([fileCompile, fileInsert, fileSave, fileSaveAs, misc]).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Private                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   setEditorWindowName(+Widget, +Name)
%   is true when the name of the root window for Widget is Name.
%   Note that it is the root widget of Widget whose window name
%   is set.

setEditorWindowName(Widget, Name) :-
	windowName(Widget, Name).

%   generateNextDefaultWindowName(-Name)
%   is true when Name is the next default name for an editor window.
%   This facility ensures that each new editor instance contains a
%   unique name.

generateNextDefaultWindowName(Name) :-
	theoristResource(widgetName, editorWindowDefaultPrefix, EditorDefaultPrefix),
	gensym(EditorDefaultPrefix, Name).

%   saveTextToFile(+ScrolledText, +FileName)
%   is true when the entire text contents of ScrolledText is written
%   to FileName.  If any error occurs such that the text is not saved,
%   an error dialog is displayed.

saveTextToFile(ScrolledText, FileName) :-
	(   xmTextGetString(ScrolledText, TextString),
	    writeCharPtrIntoFile(FileName, TextString) -> true
	;   theoristResource(errorString, cannotAccessFileString, AccessString),
	    formatToAtom(AccessString, [FileName], AccessAtom),
	    displayErrorDialog(ScrolledText, AccessAtom),
	    fail
	).

%   scrolledTextKeyboardFocus(+Widget)
%   is true when the keyboard focus is set to the scrolled text widget
%   of the editor.
%   Note that this code is a *hack* to correct the following problem:
%       1] The user selects a menu, displaying the menu's item list.
%       2] The user does not select a menu item, but clicks elsewhere
%          on the screen to close the menu's item list.
%       3] The system does not seem to restore keyboard focus to the
%          scrolled text view.
%   I do not fully understand the problem.  The following code seemed
%   to correct the problem (a better way must be found)!

scrolledTextKeyboardFocus(Widget) :-
	rootWidget(Widget, Shell),
	editorWidget(Text, Shell, widget, scrolledText),
	xtParent(Text, Parent),
	xtSetKeyboardFocus(Parent, Text).
