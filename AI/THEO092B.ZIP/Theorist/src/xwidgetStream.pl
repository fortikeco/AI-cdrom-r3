%   Module : xwidgetStream
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with widget stream input/output.
%
%   This module permits the creation of a stream attached to
%   a particular widget.  The user is responsible for defining
%   the Prolog predicate that, when passed the widget and
%   a text string that represents data written to the stream,
%   does what is necessary to place that text string into the
%   widget (or whatever the application requires).
%
%   An example is a WidgetStream attached to a Motif XmTextWidget.
%   The user can redirect Prolog's standard outputstream to
%   the widget stream.  The Callback predicate would then place
%   into the XmTextWidget any data that is written to the stream.
%
%   The current implementation only create input and output
%   streams of type QP_DELIM_TTY (see the Quintus Prolog Release 3.0
%   stream documentation).  It is the users responsibility to register
%   these streams (this should be changed to permit parameterized
%   creation of these streams!).

:- module(xwidgetStream, [
	createWidgetInputStream/4,
	createWidgetOutputStream/4
   ]).

:- meta_predicate
	createWidgetInputStream(+, :, -, -),
	createWidgetOutputStream(+, :, -, -).

sccs_id('"@(#) 11/26/91 09:39:51 xwidgetStream.pl 1.1"').

/* pred
	createWidgetInputStream(Address(Widget), Integer, Address).
	createWidgetOutputStream(Address(Widget), Integer, Address).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

createWidgetInputStream(Widget, Callback, ErrorNumber, Stream) :-
	Widget = widget(WidgetPtr),
	integer(WidgetPtr),
	Callback = Module:Predicate,
	atom(Module),
	atom(Predicate),
	cCreateWidgetInputStream(WidgetPtr, Predicate, Module, ErrorNumber, CStream),
	ErrorNumber =:= 0,
	CStream =\= 0,
	stream_code(Stream, CStream).

createWidgetOutputStream(Widget, Callback, ErrorNumber, Stream) :-
	Widget = widget(WidgetPtr),
	integer(WidgetPtr),
	Callback = Module:Predicate,
	atom(Module),
	atom(Predicate),
	cCreateWidgetOutputStream(WidgetPtr, Predicate, Module, ErrorNumber, CStream),
	ErrorNumber =:= 0,
	CStream =\= 0,
	stream_code(Stream, CStream).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loading foreign files         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

foreign_file('xwidgetStream.o', [cCreateWidgetInputStream, cCreateWidgetOutputStream]).
foreign(cCreateWidgetOutputStream, c,
	cCreateWidgetOutputStream(+address('Widget'), +atom, +atom, -integer, [-address('QP_stream')])).
foreign(cCreateWidgetInputStream, c,
	cCreateWidgetInputStream(+address('Widget'), +atom, +atom, -integer, [-address('QP_stream')])).

:- load_foreign_files(['xwidgetStream.o'], []).
