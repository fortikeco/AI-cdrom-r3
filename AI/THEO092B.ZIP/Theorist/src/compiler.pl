%   Module : compiler
%   Authors: Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: The Theorist Compiler.
%
%   Current Theorist does not take advantage of Scott Goodwin's and
%   David Poole's compiler technology - this should change in the
%   next release!

:- module(compiler, [
   ]).

sccs_id('"@(#) 11/26/91 09:39:25 compiler.pl 1.1"').

%:- mode

/* pred
*/
