%   Module : xtheorist
%   Author : Daniel Lanovaz, Art Mulder
%   Updated: 2/6/92
%   Defines: XTheorist Workspace Window
%
%% This is a *duplicate* of "xtheorist.pl" -- the main xtheorist module.
%%
%% The purpose of this duplicate is to permit easy testing of Xtheorist
%% without continually modifying the main program driver, with all
%% the risks inherent in that.
%%
%% Usage:
%% - change into the source directory.
%% - Start Quintus prolog (either "qui" for xwindows, or "prolog"
%%   for text-only).
%% - Issue the command to compile xtrace:
%%	[xtrace].
%% - Go for a break while Quintus Prolog loads in everything.  :-)
%%   How long this takes depends on whether or not there are any object
%%   files present of the other prolog theorist modules.
%% - Proceed with tracing xtheorist.
%%
%% - what happens next depends on what debugging commands you have
%%   embedded into the code.  At the very least, the initial "trace"
%%   command should be present.
%%
%% - See the Quintus Prolog Manual, "section E: debugging" for information
%%   on tracing prolog code.
%%

:- module(xtheorist, [
	xtheorist/0,
	xtheoristMainLoop/0
   ]).

:- use_module(xworkspace, [
	workspaceAbort/0,
	workspaceOpen/3
   ]),
   use_module(theorist, [
	theorist/0,
	resumeTheorist/0
   ]).

:- dynamic
        % xtheoristWidget(Widget, Shell, WidgetType, WidgetName)
        % is true when Widget is a widget of WidgeType named WidgetName for
        % the editor represented by Shell.  This predicate is
        % used to maintain global access to important Widgets.
        xtheoristWidget/4.

sccs_id('"@(#) 2/6/92 10:43:01 xtrace.pl 1.2"').

%%--------------------------------
%% Start the debugger.     ...art
%%--------------------------------
:- trace.
%% :- spy xworkspace:fileLoadOK/3.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   xtheorist
%   is true when the xTheorist system starts.  A workspace window
%   is created and the main event loop is entered.  Catch any
%   unhandled exceptions and report them as a fatal error (i.e.
%   this should *never* happen).

%% THE COMMAND "trace" SHOULD BE HERE, OR THE DEBUGGER WILL
%% NOT START.
xtheorist :-
	trace,
	initializeXTheorist,
%% Test the i/o streams...
%%	write('1: Enter Something in Single Quotes.'),
%%	read(DummyInput),
%%	write('You just entered...'),
%%	write(DummyInput),
	theorist.

%   initializeXTheorist
%   is true when XTheorist is initialized before execution begins.

initializeXTheorist :-
	(   xtheoristWidget(_, _, xtheorist, xtheoristInitialized) -> true
	;   workspaceOpen(Shell, InputStream, OutputStream),
	    assert(xtheoristWidget(InputStream, Shell, stream, input)),
	    assert(xtheoristWidget(OutputStream, Shell, stream, output)),
	    installInputOutputStreams,
	    assert((xtheoristWidget(_, _, xtheorist, xtheoristInitialized) :- !))
	).

%   xtheoristMainLoop
%   is true when the input/output streams for the workspace window
%   are initialized and the Theorist engine's execution is resumed.
%   Note that resumeTheorist/0 does not re-initialize theorist as
%   theorist/0 does within startXTheorist/0.  This predicate is used
%   during development to restart the XTheorist system after halting
%   execution.

xtheoristMainLoop :-
	installInputOutputStreams,
	resumeTheorist.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Messages                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- multifile user:message_hook/3.

user:message_hook(priorityAbort(_), _, _) :-
	(   xtheoristWidget(_, _, xtheorist, xtheoristInitialized) ->
	    installInputOutputStreams,
	    workspaceAbort,
	    resumeTheorist
	;   xtheorist
	).

user:message_hook(resumeTheorist, _, _) :-
	installInputOutputStreams,
	fail.

user:message_hook(MessageTerm, Severity, Lines) :-
	xtheoristWidget(OutputStream, _, stream, output),
	(   severityPrefix(Severity, Prefix) ->
	    (   nonvar(Lines) ->
		print_message_lines(OutputStream, Prefix, Lines)
	    ;   fail
	    )
	;   raise_exception(domain_error(
		print_message(Severity, MessageTerm), 1,
		one_of([help, error, warning, informational]),
		Severity))
	).

severityPrefix(help,		'').
severityPrefix(error,		'! ').
severityPrefix(warning,		'* ').
severityPrefix(informational,	'% ').



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Private                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%    installInputOutputStreams
%    is true when the XTheorist workspace input/output streams
%    are reset to be the current user_input and user_output
%    streams.

installInputOutputStreams :-
	xtheoristWidget(InputStream, _, stream, input),
	xtheoristWidget(OutputStream, _, stream, output),
	set_input(InputStream),
	set_output(OutputStream).
%%
%% Test the i/o streams...
%%	write('Enter Something in Single Quotes'),
%%	read(InputStream,DummyInput),
%%	read(DummyInput),
%%	write('You just entered...'),
%%	write(DummyInput).
