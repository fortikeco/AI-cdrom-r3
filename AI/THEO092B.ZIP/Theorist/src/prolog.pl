%   Module : prolog
%   Authors: Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with loading foreign Prolog code.

:- module(prolog, [
	loadPrologFile/1
   ]).

:- use_module(library(files), [
	file_exists/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:34 prolog.pl 1.1"').

:- mode
	loadPrologFile(+).

/* pred
	loadPrologFile(Atom).
*/

%   loadPrologFile(+File)
%   is true when File contains Quintus Prolog source code and
%   it is successfully consulted.

loadPrologFile(File) :-
	absolute_file_name(File, AbsoluteFile),
	(   file_exists(AbsoluteFile, read) ->
	    consult(user:AbsoluteFile)
	;   print_message(error, cannotAccessFile(AbsoluteFile))
	).
