%   Module : xlogo
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: XTheorist Logo Window
%
%   XTheorist's logo window displays a bitmap containing the XTheorist
%   logo and credit to most of the developers.

:- module(xlogo, [
	aboutXTheoristOpen/0
   ]).

:- use_module(library(proxt), [
	xmCreateForm/4,
	xmCreateLabel/4,
	xmCreateMenuBar/4,
	xtAppCreateShell/6,
	xtManageChild/1,
	xtRealizeWidget/1
   ]),
   use_module(library(proxl), [
	copy_plane/9,
	create_pixmap/2,
	default_display/1,
	display_xdisplay/2,
	free_pixmap/1,
	get_pixmap_attributes/2,
	proxl_xlib/3,
	put_window_attributes/2,
	read_bitmap_file/2,
	restack_window/2
   ]),
   use_module(library(xif), [
	widget_window/2
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(xmenu, [
	createMenuButtons/4
   ]),
   use_module(xhelp, [
	helpOpenOn/2
   ]),
   use_module(window, [
	destroyWidgetRootWindow/1,
	rootWidget/2,
	windowName/2
   ]).

:- dynamic
        % logoWidget(Widget, Shell, WidgetType, WidgetName)
        % is true when Widget is a widget of WidgeType named WidgetName for
        % the editor represented by Shell.  This predicate is
	% used for global access to widget objects.
        logoWidget/4.

sccs_id('"@(#) 11/26/91 09:39:46 xlogo.pl 1.1"').

% :- mode

/* pred
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   aboutXTheoristOpen
%   is true when XTheorist's logo window is created and displayed.

aboutXTheoristOpen :-
	theoristResource(widgetName, aboutXTheorist, LogoName),
	(   logoWidget(Logo, _, widget, LogoName) ->
	    rootWidget(Logo, RootWidget),
	    widget_window(RootWidget, LogoWindow),
	    put_window_attributes(LogoWindow, [mapped(true)]),
	    restack_window(LogoWindow, top)
        ;   theoristResource(widgetName, xTheorist, XTheorist),
            theoristResource(widgetName, xTheoristClass, XTheoristClass),
            default_display(Display),
            display_xdisplay(Display, XDisplay),
            xtAppCreateShell(XTheorist, XTheoristClass, shellWidgetClass,
	        xtdisplay(XDisplay), [], Shell),
%%	        xdisplay(XDisplay), [], Shell),
	    logoOpen(Shell),
	    xtRealizeWidget(Shell),
	    windowName(Shell, 'About XTheorist')	% Hack! Should be in resource database.
	).

%   logoOpen(+Shell)
%   is true when XTheorist's logo window is created and displayed.
%   The new widget's parent is Shell.

logoOpen(Shell) :-
	theoristResource(widgetName, aboutXTheorist, LogoName),
	createLogo(Pixmap),
	get_pixmap_attributes(Pixmap, [size(Width, Height)]),
	FormWidth is Width + 25,
	FormHeight is Height + 50,
	xmCreateForm(Shell, LogoName, [xmNwidth(FormWidth), xmNheight(FormHeight)], Logo),
	xtManageChild(Logo),
	addMenuBar(Logo, MenuBar),
	addDrawingArea(Logo, MenuBar, Pixmap, _),
	assert((logoWidget(Logo, Shell, widget, LogoName) :- !)).

addMenuBar(Logo, MenuBar) :-
	theoristResource(widgetName, aboutXTheoristMenuBar, MenuBarName),
	xmCreateMenuBar(Logo, MenuBarName, [], MenuBar),
	xtManageChild(MenuBar),
	createMenuButtons(_, MenuBar, xlogo:menuBarData, xlogo:logoWidget).

addDrawingArea(Logo, MenuBar, Pixmap, DrawingArea) :-
	theoristResource(widgetName, aboutXTheoristDrawingArea, LogoDrawingAreaName),
	proxl_xlib(Pixmap, pixmap, PixmapID),
	xmCreateLabel(Logo, LogoDrawingAreaName,
		[xmNtopWidget(MenuBar),
		 xmNlabelType(xmPIXMAP),
		 xmNlabelPixmap(PixmapID)], DrawingArea),
	xtManageChild(DrawingArea).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Menubar                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   menuBarData(+MenuItemList)
%   is true if MenuItemList is a list of menuItem structures
%   that specify the items within each logo menu.
%   See documentation in module menu for a description of the
%   MenuItemList datastructure.

menuBarData([
	subMenuItem(file,	xlogo:fileMenuData,	_),
	helpSubMenuItem(help,	xlogo:helpMenuData,	_)
	]).

fileMenuData([
	menuItem(fileQuit,	xlogo:fileQuit,	_)
	]).

helpMenuData([
	menuItem(helpOnXTheorist,	xlogo:helpOnXTheorist,  _),
	menuItem(helpOnThisWindow,	xlogo:helpOnThisWindow, _)
	]).

fileQuit(_Widget, _ClientData, _CallData) :-
	theoristResource(widgetName, aboutXTheorist, LogoName),
	logoWidget(Logo, _, widget, LogoName),
	rootWidget(Logo, Shell),
	widget_window(Shell, ShellWindow),
	put_window_attributes(ShellWindow, [mapped(false)]).

helpOnXTheorist(Widget, _, _) :-
	helpOpenOn(Widget, 'XTheorist').

helpOnThisWindow(Widget, _, _) :-
	helpOpenOn(Widget, 'Logo').



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Private                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

createLogo(Pixmap) :-
	theoristResource(messageString, xTheoristLogo, LogoFile),
	read_bitmap_file(LogoFile, Bitmap),
	get_pixmap_attributes(Bitmap, [size(Width, Height)]),
	create_pixmap(Pixmap, [size(Width, Height)]),	% Use default screen depth.
	copy_plane(Pixmap, 0, 0, Bitmap, 0, 0, Width, Height, 1).
	% For some reason free_pixmap/1 fails!  So make sure createLogo/1 succeeds.
	% free_pixmap(Bitmap).
