/*  File   : pipe.c
    Author : Daniel Lanovaz
    Origin : March 1991
    Update : 11/26/91
    Purpose: C functions dealing with application defined streams.

    This file contains the operating system C interface to generate
    a Quintus Prolog input/output stream pair that functions as a
    pipe.  Writing to the input pipe makes the data available for read
    on the output pipe.  Quintus Prolog stream predicates can be used
    on these streams.

    For more information, see the documentation in pipe.pl.
*/

#ifndef lint
  static  char SCCSid[] = "@(#) 11/26/91 09:39:10 stream.c 1.1";
#endif/*lint*/

#include <stdio.h>
#include <errno.h>
#include "quintus.h"

int
cCreateTtyPipe(prompt, inputStream, inputStreamFD, outputStream, outputStreamFD, errorNumber)
QPatom      prompt;
QP_stream **inputStream;
int        *inputStreamFD;
QP_stream **outputStream;
int        *outputStreamFD;
int        *errorNumber;
{
	int        pipeFD[2];
	QP_stream  option;
	char      *promptString       = QP_string_from_atom(prompt);

	*errorNumber = 0;

	/* pipeFD[0] is read
	   pipeFD[1] is write */
	if (pipe(pipeFD) < 0) {
		*errorNumber = errno;
		return QP_ERROR;
	}

	*inputStreamFD  = pipeFD[0];
	*outputStreamFD = pipeFD[1];

	QU_stream_param("", QP_READ, QP_DELIM_TTY, &option);
	option.format       = QP_DELIM_TTY;
	option.seek_type    = QP_SEEK_ERROR;
	option.prompt       = promptString;
	if ((*inputStream   = QU_fdopen(&option, "", errorNumber, pipeFD[0]))
		== QP_NULL_STREAM) {
		(void) close(pipeFD[0]);
		(void) close(pipeFD[1]);
                *errorNumber = QP_errno;
		return QP_ERROR;
	}
        if (QP_register_stream(*inputStream) == QP_ERROR) {
                (void) QP_close(*inputStream);
                *errorNumber = QP_errno;
                return QP_ERROR;
        }

	QU_stream_param("", QP_WRITE, QP_DELIM_TTY, &option);
	option.format      = QP_DELIM_TTY;
	option.seek_type   = QP_SEEK_ERROR;
	if ((*outputStream = QU_fdopen(&option, "", errorNumber, pipeFD[1]))
		== QP_NULL_STREAM) {
		QP_close(*inputStream);
		(void) close(pipeFD[1]);
		*errorNumber = QP_errno;
		return QP_ERROR;
	}
        if (QP_register_stream(*outputStream) == QP_ERROR) {
                (void) QP_close(*inputStream);
                (void) QP_close(*outputStream);
                *errorNumber = QP_errno;
                return QP_ERROR;
        }

	return QP_SUCCESS;
}

int
cRegisterTtyStream(ttyGroupName, stream, errorNumber)
QPatom     ttyGroupName;
QP_stream *stream;
int       *errorNumber;
{
	char      *ttyGroupNameString = QP_string_from_atom(ttyGroupName);

	if (QP_add_tty(stream, ttyGroupNameString) != QP_SUCCESS) {
		*errorNumber = QP_errno;
		return QP_ERROR;
	}
	return QP_SUCCESS;
}
