%   Module : variableBinding
%   Authors: Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Variable binding lists so that input formula can retain
%            their original variable names.

:- module(variableBinding, [
	replaceVariables/3
   ]).

sccs_id('"@(#) 11/26/91 09:39:38 variableBinding.pl 1.1"').

:- mode
        replaceVariables(+, +, -),

	variableName(+, +, -).

/*
   VariableList    ::= [VariableBinding | VariableList] |
                       [].
   VariableBinding ::= '$BIND'(VariableName, Variable).
   VariableName    ::= <atom>.
   Variable        ::= <variable>.

   pred
	replaceVariables(T, VariableList, T).
*/

%   replaceVariables(+InputFormula, +Variables, -OutputFormula)
%   is true if OutputFormula is InputFormula with all variables in
%   Variables replaced by their user input names.  Variables is a
%   list of the form '$BIND'(VariableName, Variable), where
%   VariableName is an atom representing the original variable input
%   name and Variable is the actual Prolog variable.

replaceVariables(InputFormula, Variables, OutputFormula) :-
	var(InputFormula), !,
	variableName(Variables, InputFormula, OutputFormula).
replaceVariables(InputFormula, Variables, OutputFormula) :-
	functor(InputFormula, Functor, ArgSize),
	functor(OutputFormula, Functor, ArgSize),
	replaceVariables(ArgSize, Variables, InputFormula, OutputFormula).

replaceVariables(0, _, _, _) :- !.
replaceVariables(N, Variables, InputFormula, OutputFormula) :-
	N > 0,
	arg(N, InputFormula, InputFormulaArg),
	arg(N, OutputFormula, OutputFormulaArg),
	replaceVariables(InputFormulaArg, Variables, OutputFormulaArg),
	M is N - 1,
	replaceVariables(M, Variables, InputFormula, OutputFormula).


%   variableName(+Variables, +InputVar, -VarName)
%   is true if InputVar is a variable in Variables and VarName is the
%   atom that originally represented InputVar in the user's program.

variableName([], _, _).
variableName(['$BIND'(VarName, Var)|_], InputVar, VarName) :-
	Var == InputVar, !.
variableName([_|Vars], InputVar, VarName) :-
	variableName(Vars, InputVar, VarName).
