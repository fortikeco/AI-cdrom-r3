%   Module : interpreter
%   Authors: George Ferguson, Scott Goodwin, Pat Fitzsimmons,
%            Abdul Sattar, Bonita Wong.
%   Updated: 11/26/91
%   Defines: The Theorist Interpreter.  Note that this does not explain
%            disjunctive queries.

:- module(interpreter, [
	explain/1,
	explainAll/1
   ]).

:- use_module(library(basics), [
	memberchk/2
   ]),
   use_module(library(ctypes), [
	is_newline/1
   ]),
   use_module(interpreterDatabase, [
	answerWasTrue/1,
	askable/1,
	askableIsTrue/1,
	fact/2,
	hypothesis/3,
	proveMeta/1,
	wasAsked/1
   ]),
   use_module(wff, [
	negate/2,
	ppWff/1
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(ask, [
	askAndAcceptNewline/3
   ]).


sccs_id('"@(#) 11/26/91 09:39:30 interpreter.pl 1.1"').

:- mode
	explain(+),
	explainAll(+),

	explain(+, -),
	negationMemberCheck(+, +),
	negativeMemberCheck(+, +),
	prove(+, +, +, -),
	proveAll(+, +, +, -),
	proveAllNA(+, +, +),
	proveAllNH(+, +, +),
	proveHypothesis(+, +, +, +, +, -),
	proveNA(+, +, +),
	proveNH(+, +, +).

/* pred
	explain(T),
	explainAll(T),

	explain(T, T),
	negationMemberCheck(T, List),
	negativeMemberCheck(T, List),
	prove(T, T, T, T),
	proveAll(T, T, T, T),
	proveAllNA(T, T, T),
	proveAllNH(T, T, T),
	proveHypothesis(T, T, T, T, T, T),
	proveNA(T, T, T),
	proveNH(T, T, T).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Explanations                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   explain(+Goal)
%   is always true and interfaces with explain/2.  After each
%   explanation, the user is prompted if the explanation search
%   should continue - type a semi-colon to continue, otherwise type a
%   carriage return.

explain(Goal) :-
	prompt(OldPrompt, ''),
	(   explain(Goal, Theory),
	    ppAnswerAndTheory(Goal, Theory),
	    sendExplanationMessage,
	    (   notSemiColonResponse ->
	        sendNextExplanationMessage
	    ;   sendNextExplanationMessage,
	        fail
	    )
	;   nl, print_message(help, noMore)
	),
	prompt(_, OldPrompt).



%   explainAll(+Goal)
%   is true if all explanations are found for Goal without
%   asking the user to continue after finding each explanation.

explainAll(Goal) :-
	(   explain(Goal, Theory),
	    ppAnswerAndTheory(Goal, Theory), nl,
	    fail
	;   nl, print_message(help, noMore)
	).



%   notSemiColonResponse
%   is true if the user types any character other than a semi-
%   colon.  A message is displayed if the response character
%   is a newline or if the repsone character is not a semi-colon.

notSemiColonResponse :-
	askAndAcceptNewline('', [], Char),
	(   Char == 0'; ->
	    fail
	;   is_newline(Char) ->
	    nl, print_message(help, noMore)
	;   theoristResource(messageString, moreChoicesString, ChoicesString),
	    format(ChoicesString, []),
	    notSemiColonResponse
	).


%   explain(+Goal, -Theory)
%   is true when Goal is a list of goals which can be explained using
%   the facts and the consistent set of theories, Theory.

explain(Goal, Theory) :-
	proveAll(Goal, [], [], Theory).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Proving                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   proveAll(+Goals, +Ancestors, +InTheory, -OutTheory)
%   is true when all elements in the list of goals, Goals, have been proved
%   with Ancestors and previous theories InTheory, and generating new
%   theories, OutTheory.
%
%   Note that Ancestors should be split into two arguments, the
%   positive and negative ancestors.  This speeds ancestor search
%   considerably.

proveAll([], _, InTheory, InTheory).
proveAll([Goal|Goals], Ancestors, InTheory, OutTheory) :-
	prove(Goal, Ancestors, InTheory, NewTheories),
	proveAll(Goals, Ancestors, NewTheories, OutTheory).



%   prove(+Goal, +Ancestors, +InTheory, -OutTheory)
%   is true when the atomic goal Goal is proved with Ancestors and
%   previous theories InTheory, and generating new theories, OutTheory.

prove(Goal, Ancestors, InTheory, InTheory) :-  % proof by contradiction
	negationMemberCheck(Goal, Ancestors).
prove(Goal, Ancestors, InTheory, OutTheory) :- % fact expands proof tree
	fact(Goal, IfBody),
	proveAll(IfBody, [Goal|Ancestors], InTheory, OutTheory).
prove(Goal, _Ancestors, InTheory, InTheory) :-
	askable(Goal),
	(   wasAsked(Goal) ->	% askable was answered true
	    answerWasTrue(Goal)
	;   negate(Goal, NotGoal),	% askable can't be deduced and is asked
	    \+ wasAsked(NotGoal),
	    \+ proveNA(Goal, [], InTheory),
	    \+ proveNA(NotGoal, [], InTheory),
	    askableIsTrue(Goal)
	).
prove(Goal, _, InTheory, InTheory) :-	% meta evaluates to true
	proveMeta(Goal).
prove(Goal, Ancestors, InTheory, OutTheory) :-	% else need hypothesis
	hypothesis(HypothesisName, Goal, HypothesisBody),
	proveHypothesis(Goal, Ancestors, HypothesisName, HypothesisBody,
			InTheory, OutTheory).



%   proveHypothesis(+Goal, +Ancestors, +HypName, +HypBody, +InTheory, -OutTheory)
%   is true when goal Goal is proved with Ancestors using a hypothesis
%   named NypName which has body HypBody, together with previous theories
%   InTheory, and generating new theories OutTheory.

proveHypothesis(Goal, Ancestors, HypName, HypBody, InTheory, OutTheory) :-
	(   memberchk(HypName, InTheory) ->	% reuse previous hypothesis
	    proveAll(HypBody, [Goal|Ancestors], InTheory, OutTheory)
	;   proveAll(HypBody, [Goal|Ancestors], [HypName|InTheory], OutTheory),
	    negate(Goal, NotGoal),
	    \+ proveNH(NotGoal, [], InTheory)
	).



%   proveNH(+Goal, +Ancestors, +InTheory)
%   is true if Goal is proven with Ancestors and InTheory (as
%   prove/4 above but no new theories can be added). Used to establish
%   consistency.

proveNH(Goal, Ancestors, _) :-	% proof by contradiction
	negationMemberCheck(Goal, Ancestors).
proveNH(Goal, _, InTheory) :-	% use hypothesis of current theory
	hypothesis(HypName, Goal, _),
	memberchk(HypName, InTheory).
proveNH(Goal, Ancestors, InTheory) :-  % fact expands proof tree
	fact(Goal, FactBody),
	proveAllNH(FactBody, [Goal|Ancestors], InTheory).
proveNH(Goal, _, _) :-		% meta evaluates to true
	proveMeta(Goal).
proveNH(Goal, Ancestors, InTheory) :-
	askable(Goal),
	(   wasAsked(Goal) ->	       % askable was answered true
	    answerWasTrue(Goal)
	;   negate(Goal, NotGoal),     % askable can't be deduced and is asked
	    \+ wasAsked(NotGoal),
	    \+ proveNA(Goal, Ancestors, InTheory),
	    \+ proveNA(NotGoal, Ancestors, InTheory),
	    askableIsTrue(Goal)
	).



%   proveAllNH(+Goals, +Ancestors, +InTheory)
%   is true if all the Goals can be proved without introducing new
%   theories as in proveNH/2.

proveAllNH([], _, _).
proveAllNH([Goal|Goals], Ancestors, InTheory) :-
	proveNH(Goal, Ancestors, InTheory),
	proveAllNH(Goals, Ancestors, InTheory).



%   proveNA(+Goal, +Ancestors, +InTheory)
%   is true if Goal is proven with Ancestors and theories InTheory (as prove/4
%   above but no new theories or askables can be used). Used to try and
%   deduce the value of an askable without asking it.

proveNA(Goal, Ancestors, _) :-		% proof by contradiction
	negationMemberCheck(Goal, Ancestors).
proveNA(Goal, _, InTheory) :-		% use hypothesis of current theory
	hypothesis(HypName, Goal, _),
	memberchk(HypName, InTheory).
proveNA(Goal, Ancestors, InTheory) :-   % fact expands proof tree
	fact(Goal, GoalBody),
	proveAllNA(GoalBody, [Goal|Ancestors], InTheory).
proveNA(Goal, _, _) :-                  % meta evaluates to true
	proveMeta(Goal).
proveNA(Goal, _, _) :-                  % we answered true already
	askable(Goal),
	wasAsked(Goal),
	answerWasTrue(Goal).



%   proveAllNA(+Goals, +Ancestors, +InTheory)
%   is true if all the Goals can be proved without introducing new
%   theories or asking new questions as in proveNA/3.

proveAllNA([], _, _).
proveAllNA([Goal|Goals], Ancestors, InTheory) :-
	proveNA(Goal, Ancestors, InTheory),
	proveAllNA(Goals, Ancestors, InTheory).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Printing                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   ppAnswerAndTheory(+Answer, +Theory)
%   is true if Answer and Theory are pretty printed to the current
%   output stream.

ppAnswerAndTheory(Answer, Theory) :-
	theoristResource(messageString, answerString, AnsString),
	theoristResource(messageString, theoryString, TheoryString),
	(   numbervars([Answer, Theory], 0, _),
	    nl,
	    write(AnsString), write('['),
	    ppWff(Answer),    write(']'), nl,
	    write(TheoryString), write('['),
	    (   Theory == [] ->
	        true
	    ;   ppWff(Theory)
	    ),
	    write('] '),
	    fail
	;   true
	).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Membership check              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   negationMemberCheck(+Literal, +Ancestors)
%   is true if the negation of Literal is a member
%   of Ancestors.

negationMemberCheck('$NOT'(Literal), Ancestors) :-
        !,
        memberchk(Literal, Ancestors).
negationMemberCheck(Literal, Ancestors) :-
        negativeMemberCheck(Literal, Ancestors).



%   negativeMemberCheck(+Literal, +Ancestors)
%   is true if Literal is a positive literal and its
%   negation is a member of Ancestors.
%   Unfold the check for 10-20% time savings (same as
%   library(basics) memberchk/2).

negativeMemberCheck(Literal, ['$NOT'(Literal)|_]) :- !.
negativeMemberCheck(Literal, [_, '$NOT'(Literal)|_]) :- !.
negativeMemberCheck(Literal, [_, _, '$NOT'(Literal)|_]) :- !.
negativeMemberCheck(Literal, [_, _, _|Ancestors]) :-
        negativeMemberCheck(Literal, Ancestors).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Messages                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sendExplanationMessage :-
	(   user:message_hook(explanation, _, _) -> true
	;   true
	).

sendNextExplanationMessage :-
	(   user:message_hook(nextExplanation, _, _) -> true
	;   true
	).
