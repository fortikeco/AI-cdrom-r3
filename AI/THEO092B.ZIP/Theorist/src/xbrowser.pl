%   Module : xbrowser
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: XTheorist Browser Window
%
%   XTheorist's browser window is used to navigate through
%   the database information that consists of facts, hypotheses,
%   askables, metas, etc.
%
%   The browser window is divided into four sections:
%
%       -----------------------------------------------
%       | File Options                           Help | <-MenuBar
%       |---------------------------------------------|
%       | File Pane          | Category Pane          |
%       |                    |                        |
%       |                    |                        |
%       |                    |                        |
%       |---------------------------------------------|
%       | Database pane                               |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       |                                             |
%       -----------------------------------------------
%
%   Menu bar: Contains three menus: File, Options, and Help.
%   File Pane: Contains a list of files currently loaded into
%              the system.  You select one of these modules
%              to browse its associated database objects.
%   Category Pane: Contains a list of categories for the selected
%              database object group.  You use this to partition
%              the database into smaller categories for greater
%              organization.
%   Database Pane: Contains a list of database objects owned by
%              the selected category.
%
%   For a more detailed description of the browser window, consult
%   the User's Guide.

:- module(xbrowser, [
	browserOpen/0
   ]).

:- use_module(library(proxt), [
	xmCreateForm/4,
	xmCreateMenuBar/4,
	xmCreatePanedWindow/4,
	xmCreateScrolledText/4,
	xmCreateScrolledList/4,
	xtAppCreateShell/6,
	xtManageChild/1,
	xtRealizeWidget/1,
	xtSetSensitive/2,
	xtSetValues/2
   ]),
   use_module(library(proxl), [
	default_display/1,
	display_xdisplay/2
   ]),
   use_module(xmenu, [
	createMenuButtons/4
   ]),
   use_module(resource, [
	theoristResource/3
   ]),
   use_module(window, [
	destroyWidgetRootWindow/1,
	rootWidget/2,
	windowName/2
   ]),
   use_module(xhelp, [
	helpOpenOn/2
   ]),
   use_module(xdialog, [
	createNotYetImplementedDialog/2
   ]).

:- dynamic
        % browserWidget(Widget, Shell, WidgetType, WidgetName)
        % is true when Widget is a widget of WidgeType named WidgetName for
        % the editor represented by Shell.  This predicate is
        % used to maintain a global access to important Widgets.
        browserWidget/4.

sccs_id('"@(#) 11/26/91 09:39:41 xbrowser.pl 1.1"').

% :- mode

/* pred
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%   browserOpen
%   is true when XTheorist's browser window is created and displayed.

browserOpen :-
        theoristResource(widgetName, xTheorist, XTheorist),
        theoristResource(widgetName, xTheoristClass, XTheoristClass),
	default_display(Display),
	display_xdisplay(Display, XDisplay),
	xtAppCreateShell(XTheorist, XTheoristClass, shellWidgetClass,
		xtdisplay(XDisplay), [], Shell),
%%		xdisplay(XDisplay), [], Shell),
	browserOpen(Shell),
	xtRealizeWidget(Shell),
	windowName(Shell, 'XTheorist Browser').	% Hack! Should be in resource database.

%   browserOpen(+Shell)
%   is true when XTheorist's browser window is created and displayed.
%   The new widget's parent is shell.

browserOpen(Shell) :-
	theoristResource( widgetName, browser, BrowserName),
	xmCreateForm(Shell, BrowserName, [], Browser),
	xtManageChild(Browser),
	addMenuBar(Browser, MenuBar),
	addPanes(Browser, Panes),
	xtSetValues(Panes, [xmNtopWidget(MenuBar)]).

addMenuBar(Browser, MenuBar) :-
	theoristResource(widgetName, browserMenuBar, MenuBarName),
	xmCreateMenuBar(Browser, MenuBarName, [], MenuBar),
	xtManageChild(MenuBar),
	createMenuButtons(_, MenuBar, xbrowser:menuBarData, xbrowser:browserWidget).

addPanes(Browser, Panes) :-
	theoristResource(widgetName, browserPanes, PanesName),
	xmCreatePanedWindow(Browser, PanesName, [], Panes),
	xtManageChild(Panes),
	addSelectionPanes(Panes),
	addDatabasePane(Panes).

addSelectionPanes(Panes) :-
	theoristResource(widgetName, browserSelectionPanes, SelectionPanesName),
	xmCreateForm(Panes, SelectionPanesName, [xmNrubberPositioning(true)], SelectionPanes),
	xtManageChild(SelectionPanes),
	addFilePane(SelectionPanes, _),
	addCategoryPane(SelectionPanes, _).

addDatabasePane(Panes) :-
	theoristResource(widgetName, browserDatabasePane, DatabasePaneName),
	xmCreateScrolledText(Panes, DatabasePaneName,
		[xmNeditMode(xmMULTI_LINE_EDIT)],
		DatabasePane),
	xtSetSensitive(DatabasePane, 0),
	xtManageChild(DatabasePane).

addFilePane(SelectionPanes, FilePane) :-
	theoristResource(widgetName, browserFilePane, FilePaneName),
	xmCreateForm(SelectionPanes, FilePaneName, [], FilePane),
	xmCreateScrolledList(FilePane, filePaneList, [], FilePaneList),
	xtManageChild(FilePaneList),
	xtManageChild(FilePane).

addCategoryPane(SelectionPanes, CategoryPane) :-
	theoristResource(widgetName, browserCategoryPane, CategoryPaneName),
	xmCreateForm(SelectionPanes, CategoryPaneName, [], CategoryPane),
	xmCreateScrolledList(CategoryPane, categoryPaneList, [], CategoryPaneList),
	xtManageChild(CategoryPaneList),
	xtManageChild(CategoryPane).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Menubar                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   menuBarData(+MenuItemList)
%   is true if MenuItemList is a list of menuItem structures
%   that specify the items within each browser menu.
%   See documentation in module menu for a description of the
%   MenuItemList datastructure.

menuBarData([
	subMenuItem(file,	xbrowser:fileMenuData,		_),
	subMenuItem(options,	xbrowser:optionsMenuData,	_),
	helpSubMenuItem(help,	xbrowser:helpMenuData,		_)
	]).

fileMenuData([
        menuItem(fileEdit,      xbrowser:fileEdit, _),
        menuItem(fileLoad,      xbrowser:fileLoad, _),
	separatorMenuItem,
        menuItem(fileQuit,      xbrowser:fileQuit, _)
        ]).

optionsMenuData([
        menuItem(optionsFormat, xbrowser:optionsFormat, _)
        ]).

helpMenuData([
        menuItem(helpOnXTheorist,	xbrowser:helpOnXTheorist,  _),
        menuItem(helpOnThisWindow,	xbrowser:helpOnThisWindow, _)
        ]).

%   fileEdit(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the file menu's
%   edit command is executed.

fileEdit(Widget, _, _) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).

%   fileLoad(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the file menu's
%   load command is executed.

fileLoad(Widget, _, _) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).

%   fileQuit(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the file menu's
%   quit command is executed.

fileQuit(Widget, _, _) :-
	rootWidget(Widget, RootWidget),
	retractall(browserWidget(_, RootWidget, _, _)),
	destroyWidgetRootWindow(Widget).

%   optionsFormat(+Widget, +ClientData, +CallData)
%   is true when the appriate action associated with the options menu's
%   format command is executed.

optionsFormat(Widget, _, _) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).

helpOnXTheorist(Widget, _, _) :-
	helpOpenOn(Widget, 'XTheorist').

helpOnThisWindow(Widget, _, _) :-
	helpOpenOn(Widget, 'Browser').
