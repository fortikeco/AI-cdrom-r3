%   Module : stream
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with application specific streams.
%
%   This module is used to create new Quintus Prolog stream objects.
%   Currently the only supported stream objects are pipes, whereby
%   writing to the input pipe makes the information available to read
%   on the output pipe.  Registration of TTY streams is also supported.
%
%   This module is somewhat of a hack and should be more complete in
%   its handling of stream objects.

:- module(stream, [
	createTtyPipe/6,
	registerTtyStream/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:35 stream.pl 1.1"').

:- mode
	createTtyPipe(+, +, -, -, -, -, -),
	registerTtyStream(+, +).

/* pred
	createTtyPipe(Atom, Atom, Stream, Integer, Stream, Integer, Integer),
	registerTtyStream(Atom, Stream).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

createTtyPipe(Prompt, InputStream, InputStreamFD,
		OutputStream, OutputStreamFD, ErrorNumber) :-
	cCreateTtyPipe(Prompt, CInputStream, InputStreamFD,
		COutputStream, OutputStreamFD, ErrorNumber, ReturnValue),
	(   ReturnValue =:= 0 ->
	    stream_code(InputStream, CInputStream),
	    stream_code(OutputStream, COutputStream)
	;   raise_exception(createTtyPipe(
		createTtyPipe(Prompt, InputStream, OutputStream, ErrorNumber),
		errno(ErrorNumber)))
	).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Registration                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

registerTtyStream(Name, Stream) :-
	atom(Name),
	stream_code(Stream, CStream),
	cRegisterTtyStream(Name, CStream, _ErrorNumber, ReturnValue),
	ReturnValue =:= 0.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loading foreign files         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

foreign_file('stream.o', [cCreateTtyPipe, cRegisterTtyStream]).
foreign(cCreateTtyPipe, c,
	cCreateTtyPipe(+atom, -address('QP_stream'), -integer,
			-address('QP_stream'), -integer, -integer, [-integer])).
foreign(cRegisterTtyStream, c,
	cRegisterTtyStream(+atom, +address('QP_stream'), -integer, [-integer])).

:- load_foreign_files(['stream.o'], []).
