%   Module : theorist
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Theorist main module
%
%   This is the toplevel Theorist module.  It is here where
%   all initialization takes place.

:- module(theorist, [
	theorist/0,
	resumeTheorist/0
   ]).

:- use_module(resource, [
	theoristResource/3
   ]),
   use_module(commandDispatcher, [
	processCommand/2
   ]),
   use_module(commandHistory, [
	emptyCommandHistory/2
   ]),
   use_module(interrupt, [
	establishInterruptHandler/2
   ]).

:- dynamic
	% theoristInitialized
	% is true if Theorist has been initialized and execution started.
	% This predicate is used to make sure that initialization does
	% not happen twice.
	theoristInitialized/0.

sccs_id('"@(#) 11/26/91 09:39:37 theorist.pl 1.1"').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Runtime system predicates     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   runtime_entry(+ArgList)
%   This predicate is declared for the Quintus Prolog runtime system and
%   declares an entry point upon system startup.  In contrast, a
%   stand-alone program starts up at the normal Prolog top level.
%   ArgList is bound to the argument list associated with the startup command.

user:runtime_entry(start) :-
        theorist.

user:runtime_entry(abort) :-
	resumeTheorist.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   theorist
%   is true when the Theorist system starts.

theorist :-
	sendStartTheoristMessage,
        initializeTheorist,
	print_message(help, theoristBanner),
	repeat,
		runTheorist.

%   resumeTheorist
%   is always true. It loops to get a command and execute it
%   until an `end' command is encountered.  This is the entry point
%   when the Theorist system has already been initialized (via the
%   proof of theorist/0).  Catch all unhandled exceptions and report
%   them as a fatal error (i.e. this should *never* happen).  Use
%   repeat/0 to make sure that if any predicate fails that the top-level
%   Theorist execution can still resume (another safety mechanism).

resumeTheorist :-
	repeat,
		sendResumeTheoristMessage,
		runTheorist.

%   runTheorist
%   is true when Theorist's execution loop is started.  This predicate
%   is called after initial set-up or after resuming from a user abort.

runTheorist :-
        theoristResource(commandPane, commandHistoryLength, CommandHistoryLength),
        emptyCommandHistory(CommandHistory, CommandHistoryLength),
        theoristResource(messageString, theoristPromptString, PromptString),
	on_exception(Exception, processCommand(PromptString, CommandHistory),
		unhandledException(Exception)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System configuration          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   initializeTheorist
%   is true if the Theorist system is successfully configured.

initializeTheorist :-
        %prolog_flag(unknown, _, fail),  % Unknown predicates just fail
        nofileerrors,                    % Just fail on system file predicates
        gc,                              % Let's do some garbage collection
        theoristResource(messageString, helpMessage, HelpMessage),
        theoristResource(messageString, helpCommandList, HelpCommandList),
        establishInterruptHandler(HelpMessage, HelpCommandList), % Catch ^C

	assert(theoristInitialized).




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Messages                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   message_hook(+Message, +Severity, +Lines)
%   is true when Message is 'execution_aborted' and Theorist
%   resumes execution.  This permits Theorist to catch
%   all user abort requests.

:- multifile user:message_hook/3.

%user:message_hook(execution_aborted, _, _) :-
user:message_hook(top_level(_, _, _), _, _) :-
	(   user:message_hook(priorityAbort(0), _, _) -> true
	;   theoristInitialized -> resumeTheorist
	;   otherwise -> theorist
	).



%   sendResumeTheoristMessage
%   is true when a message is sent indicating that Theorist is
%   resuming execution from an exception or user abort.

sendResumeTheoristMessage :-
	(   user:message_hook(resumeTheorist, _, _) -> true
	;   true
	).

%   sendStartTheoristMessage
%   is true when a message is sent indicating that Theorist is
%   starting execution for the first time.

sendStartTheoristMessage :-
	(   user:message_hook(startTheorist, _, _) -> true
	;   true
	).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Exception handling            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   unhandledException(+Exception)
%   is true when an unhandled exception, Exception, was found.  Print
%   an appropriate message to the user and try to resume execution
%   as if nothing happened!

unhandledException(Exception) :-
	print_message(error, theoristUnhandledException(Exception)),
	set_input(user_input),
	set_output(user_output),
	fail.
