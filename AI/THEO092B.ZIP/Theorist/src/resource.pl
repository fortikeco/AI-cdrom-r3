%   Module : resource
%   Authors: Daniel Lanovaz, Art Mulder
%   Updated: 3/3/92
%   Defines: Global Theorist resources.
%
%   This resource file was designed to function similar
%   to the resource fork of Macintosh application files.  It
%   is here where language (country) dependent information is
%   stored so that conversions are easier.
%
%   Use theoristResource/3 as a lookup table mapping a category
%   and category name to an object.

:- module(resource, [
	theoristResource/3
   ]).

:- use_module(library(environ), [
	expanded_file_name/2
   ]),
   use_module(format, [
	formatToAtom/3
   ]).

sccs_id('"@(#) 3/3/92 10:52:57 resource.pl 1.6"').

:- mode
	theoristResource(?, ?, ?).

/* pred
	theoristResource(Atom, Atom, Object).
*/

%   theoristResource(?ResourceCategory, ?ResourceName, ?ResourceObject)
%   is true if ResourceName is associated with ResourceObject within
%   ResourceCategory.

/* Program Names, Version number */
  theoristResource( messageString, systemName,     'Theorist') :- !.
  theoristResource( messageString, xSystemName,    'XTheorist') :- !.
  theoristResource( messageString, winSystemName,  'WinTheorist') :- !.
  theoristResource( messageString, pmSystemName,   'PMTheorist') :- !.
  theoristResource( messageString, version,        '0.9.2b') :- !.

/* Location of Theorist Help Files */
  theoristResource( messageString, helpDirectory,  HelpDirectory) :-
%	theoristResource(messageString, version, Version),
        expanded_file_name('$THEORIST_PATH/help/cat1/',  HelpDirectory), !.
%       formatToAtom('$THEORIST_PATH/help/cat1', [Version], UnexpandedFile),
%       expanded_file_name(UnexpandedFile, HelpDirectory), !.

/* Location of XTheorist Logo Bitmap */
  theoristResource( messageString, xTheoristLogo,  XTheoristLogo) :-
%   theoristResource(messageString, version, Version),
    expanded_file_name('$THEORIST_PATH/lib/xTheoristLogo', XTheoristLogo), !.
%   formatToAtom('$THEORIST_PATH/lib/xTheoristLogo', [Version], UnexpandedFile),
%   expanded_file_name(UnexpandedFile, XTheoristLogo), !.

theoristResource( messageString, defaultPager,    '/usr/ucb/more') :- !.

theoristResource( messageString, helpFile,                 'help') :- !.
theoristResource( messageString, helpExtension,            '.1') :- !.
theoristResource( messageString, theoristPromptString,     '[theorist]: ') :- !.
theoristResource( messageString, theoristBanner,  'Theorist Release 0.9.2b [Sun-4, SunOS 4.1].
Copyright (C) 1991, A.I. Research Lab, University of Alberta.  All rights reserved.
Dept. of Comp. Science, U. of Alberta, Edmonton, AB, Canada
') :- !.
theoristResource( messageString, helpMessage,     'XTheorist interruption (h for help)? ') :- !.
theoristResource( messageString, helpCommandList, 'XTheorist interrupt options:
    c    continue - do nothing
    s    suspend  - suspend XTheorist
    a    abort    - cause a XTheorist abort
    e    exit     - irreversible exit from XTheorist
    h    help     - this list
') :- !.
theoristResource( messageString, exitTheoristString, 'Exit Theorist [y/n]? ') :- !.
theoristResource( messageString, noHelpString,       'Sorry, no general help available.') :- !.
theoristResource( messageString, noHelpFileString,   'Sorry, no help available for ~p.') :- !.
theoristResource( messageString, clearString,        'Do you really want to clear ~p? ') :- !.
theoristResource( messageString, overwriteString,    'Overwrite ~p? ') :- !.
theoristResource( messageString, newFileString,      'New File? ') :- !.
theoristResource( messageString, askAskableString,   'Is ~p true?') :- !.
theoristResource( messageString, answerAskableString,'Answer one of (t,f,u): ') :- !.
theoristResource( messageString, answerString,       'Answer is: ') :- !.
theoristResource( messageString, theoryString,       'Theory is: ') :- !.
theoristResource( messageString, noMoreString,       'No (more) answers') :- !.
theoristResource( messageString, moreChoicesString,  'Action (";" for more choices, otherwise <return>): ') :- !.
theoristResource( messageString, consultCommandString, 'consult ~q.') :- !.
theoristResource( messageString, interpreterDatabaseLabel, 'interpreterDatabase') :- !.
theoristResource( messageString, inputDatabaseLabel,       'inputDatabase') :- !.
theoristResource( messageString, saveChanges,              'Save Changes?') :- !.

theoristResource( database, databasesAtomList,        [facts, hypotheses, askables, answers, metas]) :- !.
theoristResource( database, interpreterDatabaseList,  [fact, hypothesis, askable, meta, answer]) :- !.
theoristResource( database, compiledDatabaseList,     []) :- !.
theoristResource( database, inputDatabaseList,        [fact, hypothesis]) :- !.

theoristResource( commandPane, commandHistoryLength,     20) :- !.

theoristResource( errorString, unknownClearOptionString, 'Unknown option to clear: ~p') :- !.
theoristResource( errorString, unknownListOptionString,  'Unknown option to list: ~p') :- !.
theoristResource( errorString, nonExistFileString,       'File ~p does not exist.') :- !.
theoristResource( errorString, cannotAccessFileString,   'Cannot access file ~p.') :- !.
theoristResource( errorString, illegalResponseString,    'Illegal response, assuming unkown since I''m lazy.') :- !.
theoristResource( errorString, commandMatchFailed,       'Command match failed.') :- !.
theoristResource( errorString, syntaxErrorString,        'Syntax error.') :- !.

theoristResource( widgetName, xTheorist, 'XTheorist') :- !.
theoristResource( widgetName, xTheoristClass, 'XTheorist') :- !.

theoristResource( widgetName, editor, editor) :- !.
theoristResource( widgetName, editorWindowDefaultPrefix, 'XTheoristEditor') :- !.
theoristResource( widgetName, editorMenuBar, menuBar) :- !.
theoristResource( widgetName, editorTextPane, textPane) :- !.
theoristResource( widgetName, editorScrolledText, scrolledText) :- !.
theoristResource( widgetName, editorFileSelectionDialog, fileSelectionDialog) :- !.
theoristResource( widgetName, editorFileInsertSelectionDialog, fileInsertSelectionDialog) :- !.
theoristResource( widgetName, editorSaveChangesDialog, saveChangesDialog) :- !.
theoristResource( widgetName, editorSaveAsDialog, saveAsDialog) :- !.
theoristResource( widgetName, editorOverwriteDialog, overwriteDialog) :- !.
theoristResource( widgetName, editorNewFileDialog, newFileDialog) :- !.

theoristResource( widgetName, browser, browser) :- !.
theoristResource( widgetName, browserMenuBar, menuBar) :- !.
theoristResource( widgetName, browserPanes, panes) :- !.
theoristResource( widgetName, browserSelectionPanes, selectionPanes) :- !.
theoristResource( widgetName, browserDatabasePane, databasePane) :- !.
theoristResource( widgetName, browserFilePane, filePane) :- !.
theoristResource( widgetName, browserSectionPane, sectionPane) :- !.
theoristResource( widgetName, browserDatabaseSwitchPane, databaseSwitchPane) :- !.
theoristResource( widgetName, browserInputSwitch, inputSwitch) :- !.
theoristResource( widgetName, browserCompiledSwitch, compiledSwitch) :- !.
theoristResource( widgetName, browserCategoryPane, categoryPane) :- !.

theoristResource( widgetName, workspace, workspace) :- !.
theoristResource( widgetName, workspaceMenuBar, menuBar) :- !.
theoristResource( widgetName, workspaceCommandButtons, commandButtons) :- !.
theoristResource( widgetName, workspaceUserCommands, userCommands) :- !.
theoristResource( widgetName, workspaceInterruptButton, interrupt) :- !.
theoristResource( widgetName, workspaceSeparatorButton, separator) :- !.
theoristResource( widgetName, workspaceNextButton, next) :- !.
theoristResource( widgetName, workspaceNoMoreButton, noMore) :- !.
theoristResource( widgetName, workspaceRemainingButton, remaining) :- !.
theoristResource( widgetName, workspaceFileSelectionDialog, fileSelectionDialog) :- !.
theoristResource( widgetName, workspaceQuitDialog, quitDialog) :- !.

theoristResource( widgetName, commandPaneHistoryPane, historyPane) :- !.
theoristResource( widgetName, commandPaneCommandPane, commandPane) :- !.

theoristResource( widgetName, aboutXTheorist, aboutXTheorist) :- !.
theoristResource( widgetName, aboutXTheoristMenuBar, menuBar) :- !.
theoristResource( widgetName, aboutXTheoristDrawingArea, drawingArea) :- !.

theoristResource( widgetName, errorDialog, errorDialog) :- !.
theoristResource( widgetName, notYetImplementedDialog, notYetImplementedDialog) :- !.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Messages                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- multifile user:parse_message_hook/3.

user:parse_message_hook(theoristUnhandledException(Exception)) -->
	['Disaster, unhandled exception: ~p'-[Exception], nl,
	 'Please submit a "disaster report".'-[], nl].

user:parse_message_hook(theoristPromptString) -->
	['[theorist]: '-[]].

user:parse_message_hook(theoristBanner) -->
	['Theorist Release 0.9.2b [Sun-4, SunOS 4.1].'-[], nl,
	 'Copyright (C) 1991, A.I. Research Lab, University of Alberta,  All rights reserved.'-[], nl,
	 'Dept. of Comp. Science, U. of Alberta, Edmonton, AB, Canada.'-[], nl].

user:parse_message_hook(helpMessage) -->
	['XTheorist interruption (h for help)? '-[]].

user:parse_message_hook(helpCommandList) -->
	['XTheorist interrupt options:'-[], nl,
	 '    c    continue - do nothing'-[], nl,
	 '    s    suspend  - suspend XTheorist'-[], nl,
	 '    a    abort    - cause an XTheorist abort'-[], nl,
	 '    e    exit     - irreversible exit from XTheorist'-[], nl,
	 '    h    help     - this list'-[], nl].

user:parse_message_hook(exitTheorist) -->
	['Exit Theorist [y/n]? '-[]].

user:parse_message_hook(noHelp) -->
	['Sorry, no general help available.'-[]].

user:parse_message_hook(noHelpFile(HelpFile)) -->
	['Sorry, no help available for ~p.'-[HelpFile], nl].

user:parse_message_hook(clear(Object)) -->
	['Do you really want to clear ~p? '-[Object]].

user:parse_message_hook(overwrite(Object)) -->
	['Overwrite ~p.'-[Object]].

user:parse_message_hook(newFile) -->
	['New File?'-[]].

user:parse_message_hook(askAskable(Question)) -->
	['Is ~p true?'-[Question], nl].

user:parse_message_hook(answerAskable) -->
	['Answer one of (t, f, u): '-[]].

user:parse_message_hook(answer) -->
	['Answer is: '-[]].

user:parse_message_hook(theory) -->
	['Theory is: '-[]].

user:parse_message_hook(noMore) -->
	['No (more) answers'-[], nl].

user:parse_message_hook(moreChoices) -->
	['Action (";" for more choices, otherwise <return>): '-[]].

user:parse_message_hook(consultCommand(Command)) -->
	['consult ~q.'-[Command]].

user:parse_message_hook(interpreterDatabaseLabel) -->
	['interpreterDatabase'-[]].

user:parse_message_hook(inputDatabase) -->
	['inputDatabase'-[]].

user:parse_message_hook(saveChanges) -->
	['Save Changes?'-[]].

user:parse_message_hook(unknownClearOption(Option)) -->
	['Unknown option to clear: ~p'-[Option], nl].

user:parse_message_hook(unknownListOption(Option)) -->
	['Unknown option to list: ~p.'-[Option], nl].

user:parse_message_hook(nonExistFile(FileName)) -->
	['File ~p does not exist.'-[FileName]].

user:parse_message_hook(cannotAccessFile(FileName)) -->
	['Cannot access file ~p.'-[FileName], nl].

user:parse_message_hook(illegalResponse) -->
	['Illegal response, assuming unkown since I''m lazy.'-[], nl].

user:parse_message_hook(commandMatchFailed) -->
	['Command match failed.'-[], nl].

user:parse_message_hook(syntaxError) -->
	['Syntax error.'-[], nl].

user:parse_message_hook(loadFile(File)) -->
	['loading file ~w'-[File], nl].
