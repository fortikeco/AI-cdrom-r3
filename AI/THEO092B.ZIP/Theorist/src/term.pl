%   Module : term
%   Authors: George Ferguson, Scott Goodwin, Pat Fitzsimmons,
%            Abdul Sattar, Bonita Wong.
%   Updated: 11/26/91
%   Defines: Term manipulation predicates not in the library.

:- module(term, [
	replace/4		% Elem x Elem x Elem -> Elem
   ]).

sccs_id('"@(#) 11/26/91 09:39:36 term.pl 1.1"').

:- mode
	replace(+, +, +, -).

/* pred
	replace(T, T, T, T).
*/

%   replace(T, F1, S, F2)
%   is true if F2 is the formula which results from replacing all occurrences
%   of variable T in F1 by S.

replace(T, F1, S, F2) :-
	(   atomic(F1) ->
	    F1 = F2
	;   var(F1) ->
	    (   T == F1 ->
	        S = F2
	    ;   F1 = F2
	    )
	;   otherwise ->
	    functor(F1, Name, ArgSize),
	    functor(F2, Name, ArgSize),
	    replace(ArgSize, T, F1, S, F2)
	).

replace(0, _, _, _, _) :- !.
replace(N, T, F1, S, F2) :-
	N > 0,
	arg(N, F1, F1Args),
	arg(N, F2, F2Args),
	replace(T, F1Args, S, F2Args),
	M is N - 1,
	replace(M, T, F1, S, F2).
