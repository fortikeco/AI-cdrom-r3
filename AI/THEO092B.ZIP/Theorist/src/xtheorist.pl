%   Module : xtheorist
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: XTheorist Workspace Window
%
%   This is the toplevel XTheorist module.  It is here where
%   the X Window initialization takes place.  The toplevel
%   shell is stored for future use by modules that create
%   alternate views (windows) on the XTheorist database.

:- module(xtheorist, [
	xtheorist/0,
	xtheoristMainLoop/0
   ]).

:- use_module(xworkspace, [
	workspaceAbort/0,
	workspaceOpen/3
   ]),
   use_module(theorist, [
	theorist/0,
	resumeTheorist/0
   ]).

:- dynamic
        % xtheoristWidget(Widget, Shell, WidgetType, WidgetName)
        % is true when Widget is a widget of WidgeType named WidgetName for
        % the editor represented by Shell.  This predicate is
        % used to maintain global access to important Widgets.
        xtheoristWidget/4.

sccs_id('"@(#) 11/26/91 09:39:49 xtheorist.pl 1.1"').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   xtheorist
%   is true when the xTheorist system starts.  A workspace window
%   is created and the main event loop is entered.  Catch any
%   unhandled exceptions and report them as a fatal error (i.e.
%   this should *never* happen).

xtheorist :-
	initializeXTheorist,
	theorist.

%   initializeXTheorist
%   is true when XTheorist is initialized before execution begins.

initializeXTheorist :-
	(   xtheoristWidget(_, _, xtheorist, xtheoristInitialized) -> true
	;   workspaceOpen(Shell, InputStream, OutputStream),
	    assert(xtheoristWidget(InputStream, Shell, stream, input)),
	    assert(xtheoristWidget(OutputStream, Shell, stream, output)),
	    installInputOutputStreams,
	    assert((xtheoristWidget(_, _, xtheorist, xtheoristInitialized) :- !))
	).

%   xtheoristMainLoop
%   is true when the input/output streams for the workspace window
%   are initialized and the Theorist engine's execution is resumed.
%   Note that resumeTheorist/0 does not re-initialize theorist as
%   theorist/0 does within startXTheorist/0.  This predicate is used
%   during development to restart the XTheorist system after halting
%   execution.

xtheoristMainLoop :-
	installInputOutputStreams,
	resumeTheorist.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Messages                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- multifile user:message_hook/3.

user:message_hook(priorityAbort(_), _, _) :-
	(   xtheoristWidget(_, _, xtheorist, xtheoristInitialized) ->
	    installInputOutputStreams,
	    workspaceAbort,
	    resumeTheorist
	;   xtheorist
	).

user:message_hook(resumeTheorist, _, _) :-
	installInputOutputStreams,
	fail.

user:message_hook(MessageTerm, Severity, Lines) :-
	xtheoristWidget(OutputStream, _, stream, output),
	(   severityPrefix(Severity, Prefix) ->
	    (   nonvar(Lines) ->
		print_message_lines(OutputStream, Prefix, Lines)
	    ;   fail
	    )
	;   raise_exception(domain_error(
		print_message(Severity, MessageTerm), 1,
		one_of([help, error, warning, informational]),
		Severity))
	).

severityPrefix(help,		'').
severityPrefix(error,		'! ').
severityPrefix(warning,		'* ').
severityPrefix(informational,	'% ').



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Private                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%    installInputOutputStreams
%    is true when the XTheorist workspace input/output streams
%    are reset to be the current user_input and user_output
%    streams.

installInputOutputStreams :-
	xtheoristWidget(InputStream, _, stream, input),
	xtheoristWidget(OutputStream, _, stream, output),
	set_input(InputStream),
	set_output(OutputStream).
