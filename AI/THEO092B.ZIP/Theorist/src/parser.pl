%   Module : parser
%   Authors: George Ferguson, Scott Goodwin, Pat Fitzsimmons,
%            Abdul Sattar, Bonita Wong.
%   Updated: 11/26/91
%   Defines: Theorist input syntax parser.
%
%   This module implements the parser of 1st order PC
%   formulae as well as 'tacking on' the Theorist command that the
%   formula is entered as.  Note that keywords are *not* reserved,
%   therefore we have several productions for conjunction
%   since the user can use an ampersand, a comma, or the word
%   `and' as the connective.
%
%   History:	 4 Oct 1988 George Ferguson
%       - used Scott's idea to get precedences
%       - changed from resereved words
%   25 Oct 1988 GF
%       - Removed last vestiges of reserved words
%       - Added keywords `if' and `exists'
%
%   The following Theorist commands are supported:
%
%	askable    <atomicLiteral>
%	clear
%	clear      <constantArg>
%	end, halt, quit, bye, ^D
%	explain    <formula>
%	fact       <formula>
%	help
%	help       <constantArg>
%	history
%	hypothesis <atomicLiteral> : <formula>
%       compile    <constantArg>
%	consult    <constantArg>
%	list
%	list       <constantArg>
%	listall
%       load       <constantArg>
%	meta       <atomicLiteral>
%	redo
%	redo       <integer>
%	redo       <command>
%	restore    <constant>
%	save       <constant>
%	unix       cd
%	unix       cd(<constant>)
%	unix       shell
%	unix       <constant>
%
%   The following is the Theorist grammar productions for the above command
%   arguments:
%
%	<command>       --> <commandKeyword> [<formula>] fullStop
%	<formula>       --> <literal> |
%	                    <literal> <connective> <formula>.
%	<literal>       --> not <formula2> |
%	                    <formula2>.
%	<formula2>      --> '(' <formula> ')' |
%	                    <atomicLiteral>   |
%	                    <quantifier> <variable> <formula>.
%	<atomicLiteral> --> <constant> |
%	                    <constant> '(' <argList> ')'.
%	<list>          --> '[' ']'                          |
%	                    '[' <argList> ']'                |
%	                    '[' <argList> bar <variable> ']' |
%	                    '[' <argList> bar <list> ']'.
%	<argList>       --> <arg> |
%	                    <arg> ',' <argList>.
%	<arg>           --> <atom>     |
%	                    <number>   |
%	                    <variable> |
%	                    <list>.
%	<constantArg>   --> <constant> |
%	                    <number> |
%	                    '[' <constList> ']'.
%	<constList>     --> <constantArg> |
%	                    <constantArg> ',' <constList>.
%	<connective>    --> and         |
%	                    comma       |
%	                    or          |
%	                    bar         |
%	                    implies     |
%	                    backImplies |
%	                    if          |
%                           iff.
%	<quantifier>    --> all    |
%	                    ex     |
%	                    exists.
%	<commandKeyword> -->
%	                     askable	|
%	                     clear	|
%	                     end	|
%	                     quit	|
%	                     halt	|
%	                     bye	|
%	                     exit	|
%	                     explain	|
%                            explainAll |
%	                     fact	|
%	                     help	|
%	                     history	|
%	                     hypothesis	|
%                            compile    |
%	                     consult	|
%	                     list	|
%                            load       |
%	                     meta	|
%	                     redo	|
%	                     restore	|
%	                     save.
%
%    See the module Tokenizer which contains the production rules for:
%	and, comma, or, bar, implies, backImplies, if, all, ex, exists,
%	<variable>, <number>, and <constant>.

:- module(parser, [
	getCommand/1
   ]).

:- use_module(library(basics), [
	member/2
   ]),
   use_module(tokenizer, [
	tokenize/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:33 parser.pl 1.1"').

:- mode
	getCommand(-).

/* pred
	getCommand(T).
*/


%   getCommand(C)
%   is true when C is a valid Theorist command consisting of a functor
%   which is one of the Theorist keywords (fact, hypothesis, etc.)
%   possibly followed by an argument. If the argument is a PC formula,
%   then it is in prefix notation with functors $NOT, $AND, $OR, $ALL,
%   and $EX standing for the logical connectives and quantifiers.

getCommand(C) :-
	get0(N),			% get first char
	tokenize(N, T),			% read line of tokens
	!,
	parse(C, T, []),		% parse it
	!.


%   Production rule grammar for Theorist and 1st Order PC.
%
%   Note: formula(F) has been left-factored, hence the
%   productions for literal and formula2. These
%   also give `not' the highest precedence.
%
%   While parsing a term, we must ensure that objects
%   recognized by the lexer as variables are instantiated
%   consistently. The Vi and Vo variables represent a list
%   of variable bindings of the form '$BIND(Name, V)' which
%   means that the variable represented by the string Name
%   has been instantiated to the (free) variable V.

parse(P)     --> cmd(P), [eol], !.
parse(eof)   --> [eof], !.
parse(syntaxError, _, _) :- !.

cmd(fact(F, V))	         --> [name(fact)], formula(F, [], V).
cmd(hypothesis(A, F, V)) --> [name(hypothesis)],
			     atomicLiteral(A, [], ALV),
			     [colon],
			     formula(F, ALV, V).
cmd(hypothesis(A, V))    --> [name(hypothesis)],
	                     atomicLiteral(A, [], V).
cmd(askable(A))	         --> [name(askable)], atomicLiteral(A, [], _).
cmd(meta(A))	         --> [name(meta)], atomicLiteral(A, [], _).
cmd(explain(F))	         --> [name(explain)], formula(F, [], _).
cmd(explainAll(F))       --> [name(explainAll)], formula(F, [], _).
cmd(consult(A))	         --> [name(consult)], constantArg(A, [], _).
cmd(compile(A))	         --> [name(compile)], constantArg(A, [], _).
cmd(load(A))	         --> [name(load)], constantArg(A, [], _).
cmd(end)	         --> [name(end)]  |
			     [name(halt)] |
			     [name(quit)] |
			     [name(bye)]  |
			     [controlD].
cmd(help)	         --> [name(help)].
cmd(help(A))	         --> [name(help)], constantArg(A, [], _).
cmd(clear)	         --> [name(clear)].
cmd(clear(A))	         --> [name(clear)], constantArg(A, [], _).
cmd(history)	         --> [name(history)].
cmd(list)	         --> [name(list)].
cmd(listall)	         --> [name(listall)].
cmd(listall(A))	         --> [name(listall)], constantArg(A, [], _).
cmd(list(facts(A)))      --> [name(list)],
                             [name(facts)],
                             atomicLiteral(A, [], _).
cmd(list(hypotheses(A))) --> [name(list)],
                             [name(hypotheses)],
                             atomicLiteral(A, [], _).
cmd(list(askables(A)))   --> [name(list)],
                             [name(askables)],
                             atomicLiteral(A, [], _).
cmd(list(metas(A)))      --> [name(list)],
                             [name(metas)],
                             atomicLiteral(A, [], _).
cmd(list(A))	         --> [name(list)], constantArg(A, [], _).
cmd(save(A))	         --> [name(save)], [name(A)].
cmd(redo)	         --> [name(redo)].
cmd(redo(A))	         --> [name(redo)], [integer(A)].
cmd(redo(A))	         --> [name(redo)], atomicLiteral(A, [], _).
cmd(restore(A))	         --> [name(restore)], [name(A)].
cmd(unix(A))	         --> [name(unix)], atomicLiteral(A, [], _).

formula(F, Vi, Vo)    --> literal(F, Vi, Vo).
formula(F, Vi, Vo)    --> literal(F1, Vi, V1),
			  connective(C),
			  formula(F2, V1, Vo),	
			  { F =.. [C, F1, F2] }.

literal('$NOT'(F), Vi, Vo) --> [not], formula2(F, Vi, Vo).
literal('$NOT'(F), Vi, Vo) --> [name(not)], formula2(F, Vi, Vo).
literal(F, Vi, Vo)         --> formula2(F, Vi, Vo).

formula2(F, Vi, Vo) --> [lparen], formula(F, Vi, Vo), [rparen].
formula2(F, Vi, Vo) --> atomicLiteral(F, Vi, Vo).
formula2(F, Vi, Vo) --> quantifier(Q),
		        variable(V, Vi, V1),
		        formula(F1, V1, Vo),
		        { F =.. [Q, V, F1]  }.

%   connectives: comma is also used in argList,
%                bar is also used in lists.

connective('$AND')  --> [and].
connective('$AND')  --> [name(and)].
connective('$AND')  --> [comma].
connective('$OR')   --> [name(or)].
connective('$OR')   --> [bar].
connective('$IMP')  --> [implies].
connective('$IMP')  --> [name(implies)].
connective('$BIMP') --> [back_implies].
connective('$BIMP') --> [name(if)].
connective('$IFF')  --> [iff].
connective('$IFF')  --> [name(iff)].

quantifier('$ALL') -->	[name(all)].
quantifier('$EX')  -->	[name(ex)].
quantifier('$EX')  -->	[name(exists)].

%   atomicLiteral: names or functors + args

atomicLiteral(A,  VL,  VL) --> [name(A)].
atomicLiteral(A,  Vi,  Vo) --> [name(N)], [lparen], argList(Args,Vi,Vo), [rparen],
		               { A =.. [N|Args] }.

%   variables: keep track of the bindings depending on whether we've
%               seen this variable before.

variable(V, VL, VL)                 --> [var(N)],
			                { member('$BIND'(N, V), VL) }.
variable(V, VL, ['$BIND'(N, V)|VL]) --> [var(N)],
					{ \+ member('$BIND'(N,_),VL) }.

%   lists: '[' and ']' are syntactic sugar for delimiting lists.

list(L, V, V)   --> [lbracket], [rbracket], { L = [] }.
list(L, Vi, Vo) --> [lbracket], argList(Args, Vi, Vo), [rbracket],
		    { L = Args }.
list(L, Vi, Vo) --> [lbracket], argList(Args, Vi, V1), [bar],
		    variable(V, V1, Vo), [rbracket],
		    { append(Args, V, L) }.
list(L, Vi, Vo) --> [lbracket], argList(Args, Vi, V1), [bar],
		    list(LL, V1, Vo), [rbracket],
		    { append(Args, LL, L) }.

%   arg/argList can contain variables

arg(Arg, Vi, Vo) --> atomicLiteral(Arg, Vi, Vo).
arg(Arg, Vi, Vo) --> number(Arg, Vi, Vo).
arg(Arg, Vi, Vo) --> variable(Arg, Vi, Vo).
arg(Arg, Vi, Vo) --> list(Arg, Vi, Vo).

argList(L, Vi, Vo) --> arg(Arg, Vi, Vo), { L = [Arg] }.
argList(L, Vi, Vo) --> arg(Arg, Vi, V1),
                       [comma], argList(LL, V1, Vo),
                       { L = [Arg|LL] }.

%   constantArg/constList can't include variables; name(A) becomes simply A

constantArg(Arg, V, V)   --> [name(Arg)].
constantArg(Arg, Vi, Vo) --> number(Arg, Vi, Vo).
constantArg(Arg, Vi, Vo) --> [lbracket], constList(Arg, Vi, Vo), [rbracket].

constList([Arg], Vi, Vo) --> constantArg(Arg, Vi, Vo).
constList(L, Vi, Vo)     --> constantArg(Arg, Vi, V1),
                             [comma], constList(LL, V1, Vo),
                             { L = [Arg|LL] }.

%  A number is either an integer or a floating point number

number(Arg, V, V) --> [integer(Arg)].
number(Arg, V, V) --> [num(Arg)].
