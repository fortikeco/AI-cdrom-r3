/*  File   : main.c
    Author : Daniel Lanovaz
    Origin : March 1991
    Update : 11/26/91
    Purpose: The toplevel main() program for a run-time Theorist system.
*/

#ifndef lint
  static  char SCCSid[] = "@(#) 11/26/91 09:39:09 main.c 1.1";
#endif/*lint*/

#include <stdio.h>
#include "quintus.h"

#define XTheoristModule              "xtheorist"
#define XTheoristStartPredicate      "xtheorist"
#define XTheoristStartPredicateArity 0

main(argc, argv)
int   argc;
char *argv[];
{
	int status;

	status = QP_initialize(argc, argv);

	if (status == QP_SUCCESS) {
		QP_pred_ref xtheoristToplevel =
			QP_predicate(XTheoristStartPredicate, XTheoristStartPredicateArity,
					XTheoristModule);

		if (xtheoristToplevel != (QP_pred_ref) QP_ERROR) {
			QP_query(xtheoristToplevel);
		} else {
			(void) fprintf(stderr, "Prolog query xtheorist:xtheorist/0 failed!\n");
		}
	} else {
		(void) fprintf(stderr, "Could not initialize Quintus Prolog.\n");
	}

	return NULL;
}
