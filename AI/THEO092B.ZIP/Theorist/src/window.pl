%   Module : window
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with ProXT and ProXL windows.
%
%   There are certain operations on X window objects that are
%   not supported in ProXT and ProXL - they are contained in this
%   module.

:- module(window, [
	destroyWidgetRootWindow/1,
	rootWidget/2,
	windowName/2
   ]).

:- use_module(library(proxt), [
	xtParent/2
   ]),
   use_module(library(proxl), [
	destroy_subwindows/1,
	destroy_window/1,
	get_window_attributes/2,
	put_window_attributes/2
   ]),
   use_module(library(xif), [
	widget_window/2
   ]).

sccs_id('"@(#) 11/26/91 09:39:40 window.pl 1.1"').

:- mode
	destroyWidgetRootWindow(+),
	rootWidget(+, -),
	windowName(+, ?).

/* pred
	destroyWidgetRootWindow(Widget),
	rootWidget(Widget, Widget),
	windowName(Widget, Atom).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Destroying                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

destroyWidgetRootWindow(Widget) :-
	rootWidget(Widget, RootWidget),
	widget_window(RootWidget, Window),
	destroy_subwindows(Window),
	destroy_window(Window).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Accessing                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   rootWidget(+Widget, -RootWidget)
%   is true when RootWidget is the root widget of the widget tree
%   that includes Widget.

rootWidget(Widget, RootWidget) :-
        Widget = widget(Number),
        integer(Number),
        Number =\= 0,
        xtParent(Widget, ParentWidget),
        (  ParentWidget \== widget(0) ->
           rootWidget(ParentWidget, RootWidget)
        ;  RootWidget = Widget
        ).

%   windowName(+Widget, ?Name)
%   is true if Name is the current name of the window associated
%   with Widget.

windowName(Widget, Name) :-
        rootWidget(Widget, RootWidget),
        widget_window(RootWidget, Window),
	(   var(Name) ->
	    get_window_attributes(Window, [property('WM_NAME', Name)])
        ;   atom(Name) ->
	    put_window_attributes(Window, [property('WM_NAME', Name)])
	).
