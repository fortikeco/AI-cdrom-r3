%   Module : xhelp
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with the hypertext help facility.

:- module(xhelp, [
	helpOpenOn/2
   ]).

:- use_module(library(proxt), [
	xtManageChild/1
   ]),
   use_module(xdialog, [
	createNotYetImplementedDialog/2
   ]).

:- dynamic
        % helpWidget(Widget, Shell, WidgetType, WidgetName)
        % is true when Widget is a widget of WidgeType named WidgetName for
        % the help window represented by Shell.  This predicate is
        % used to maintain global access to important Widgets.
        helpWidget/4.

sccs_id('"@(#) 11/26/91 09:39:45 xhelp.pl 1.1"').

:- mode
	helpOpenOn(+, +).

/* pred
	helpOpenOn(Widget, Atom).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

helpOpenOn(Widget, _Topic) :-
	createNotYetImplementedDialog(Widget, Dialog),
	xtManageChild(Dialog).
