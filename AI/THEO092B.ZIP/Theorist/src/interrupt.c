/*  File   : interrupt.c
    Author : Daniel Lanovaz
    Origin : March 1991
    Update : 11/26/91
    Purpose: Controlling user interrupts.

    This file contains the C routines callable from Quintus Prolog.
    The function establishInterruptHandler is called when the user
    types the interrupt character (normally ^C).
    The function initializeMessages is used to store the message strings
    from the Theorist resource database 'resource.pl' for printing
    during interrupt handling.

    Note that addresses to the strings in 'resource.pl' are stored in
    this file - it may be necessary to copy the strings if the Prolog
    system does any code shifting?

    The following interrupt choices are currently supported:

	c    continue - do nothing
	s    suspend  - suspend QTheorist
	a    abort    - cause a QTheorist abort
	e    exit     - irreversible exit from QTheorist
	h    help     - this list
*/

#ifndef lint
  static  char SCCSid[] = "@(#) 11/26/91 09:39:09 interrupt.c 1.1";
#endif/*lint*/

#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include "quintus.h"

static char *HelpMessage     = "";
static char *HelpCommandList = "";

static void (*oldInterruptHandler)();

static void
ContinueAction()
{
    return;
}

static void
SuspendAction()
{
    QP_action(QP_STOP);
}

static void
ExitAction()
{
    QP_action(QP_EXIT);
}

static void
AbortAction()
{
    QP_action(QP_ABORT);
}

static void
HelpAction()
{
    QP_printf(HelpCommandList);
}

static void
DebugAction()
{
    (void) signal(SIGINT, oldInterruptHandler);
    QP_action(QP_TRACE);
}

static void
InterruptHandler()
{
    char aChar;

    QP_putchar('\n');
    for(;;) {
        QP_printf(HelpMessage);
        aChar = QP_getchar();
        if (aChar != '\n') {
            while (QP_getchar() != '\n');
        }
        switch(aChar) {
            case 'c': ContinueAction();
                      return;
            case 's': SuspendAction();
                      return;
            case 'e': ExitAction();
                      break;
	    case 'a': AbortAction();
	              break;
            case 'h': HelpAction();
                      break;
            case 'd': DebugAction();
                      break;
        }
    }
}

int
cEstablishInterruptHandler(newHelpMessage, newHelpCommandList, errorNumber)
char *newHelpMessage;
char *newHelpCommandList;
int  *errorNumber;
{
	if ((int) (oldInterruptHandler = signal(SIGINT, InterruptHandler)) == -1) {
		*errorNumber = errno;
		return QP_ERROR;
	} else {
		HelpMessage         = newHelpMessage;
		HelpCommandList     = newHelpCommandList;
	}
	return QP_SUCCESS;
}

int
cSendInterrupt(errorNumber)
int *errorNumber;
{
	if (kill(getpid(), SIGINT) < 0) {
		*errorNumber = errno;
		return QP_ERROR;
	}
	return QP_SUCCESS;
}
