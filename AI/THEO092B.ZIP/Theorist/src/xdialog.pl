%   Module : xdialog
%   Author : Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with X dialog windows.

:- module(xdialog, [
	createErrorDialog/4,
	createFileSelectionDialog/5,
	createNotYetImplementedDialog/2,
	createYesNoDialog/10,
	dialogWindowOnTop/1,
	releaseDialog/1,
	releaseDialogs/1
   ]).

:- meta_predicate
	createFileSelectionDialog(+, +, :, :, -),
	createYesNoDialog(+, +, +, :, +, :, +, :, +, -).

:- use_module(library(proxt), [
	xmCreateFileSelectionDialog/4,
	xmCreateMessageDialog/4,
	xmCreateWarningDialog/4,
	xmFileSelectionBoxGetChild/3,
	xmMessageBoxGetChild/3,
	xtAddCallback/4,
	xtDestroyWidget/1,
	xtParent/2,
	xtSetValues/2,
	xtUnmanageChild/1,
	xtUnmanageChildren/1
   ]),
   use_module(library(proxl), [
	restack_window/2
   ]),
   use_module(library(xif), [
	widget_window/2
   ]),
   use_module(window, [
	rootWidget/2
   ]),
   use_module(xstring, [
	stringToXmString/2
   ]),
   use_module(resource, [
	theoristResource/3
   ]).

:- dynamic
        % dialogWidget(Widget, Shell, WidgetType, WidgetName)
        % is true when Widget is a widget of WidgeType named WidgetName for
        % the dialog represented by Shell.  This predicate is
        % used to maintain global access to important Widgets.
        dialogWidget/4.

sccs_id('"@(#) 11/26/91 09:39:44 xdialog.pl 1.1"').

:- mode
	dialogWindowOnTop(+),
	releaseDialog(+),
	releaseDialogs(+).

/* pred
	WidgetList ::= [Widget|WidgetList].

	dialogWindowOnTop(Widget),
	releaseDialog(Widget),
	releaseDialogs(WidgetList).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Instance Creation             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

createErrorDialog(Widget, DialogName, ErrorMessage, ErrorDialog) :-
	rootWidget(Widget, Shell),
	stringToXmString(ErrorMessage, ErrorString),
	xmCreateMessageDialog(Shell, DialogName,
	    [xmNmessageString(ErrorString)], ErrorDialog),
	xmMessageBoxGetChild(ErrorDialog, xmDIALOG_HELP_BUTTON, HelpButton),
	xtUnmanageChild(HelpButton),
	xmMessageBoxGetChild(ErrorDialog, xmDIALOG_OK_BUTTON, OKButton),
	xtUnmanageChild(OKButton),
	xmMessageBoxGetChild(ErrorDialog, xmDIALOG_CANCEL_BUTTON, CancelButton),
	stringToXmString('OK', OKString),
	xtSetValues(CancelButton, [xmNlabelString(OKString)]).

createYesNoDialog(Widget, DialogName, Message,
		YesCommand,    YesCommandData,
		NoCommand,     NoCommandData,
		CancelCommand, CancelCommandData, Dialog) :-
	rootWidget(Widget, Shell),
	stringToXmString(Message, XmString),
	xmCreateMessageDialog(Shell, DialogName,
	    [xmNmessageString(XmString),
	     xmNautoUnmanage(false)], Dialog),
	xmMessageBoxGetChild(Dialog, xmDIALOG_HELP_BUTTON, HelpButton),
	stringToXmString('Cancel', HelpLabel),
	xtSetValues(HelpButton, [xmNlabelString(HelpLabel)]),
	xmMessageBoxGetChild(Dialog, xmDIALOG_OK_BUTTON, OkButton),
	stringToXmString('Yes', OkLabel),
	xtSetValues(OkButton, [xmNlabelString(OkLabel)]),
	xmMessageBoxGetChild(Dialog, xmDIALOG_CANCEL_BUTTON, CancelButton),
	stringToXmString('No', CancelLabel),
	xtSetValues(CancelButton, [xmNlabelString(CancelLabel)]),
	xtAddCallback(Dialog, xmNokCallback, YesCommand, YesCommandData),
	xtAddCallback(Dialog, xmNcancelCallback, NoCommand, NoCommandData),
	xtAddCallback(Dialog, xmNhelpCallback, CancelCommand, CancelCommandData).

createFileSelectionDialog(Widget, DialogName, OKCommand, CancelCommand, FileSelection) :-
	rootWidget(Widget, Shell),
	xmCreateFileSelectionDialog(Shell, DialogName,[], FileSelection),
	xmFileSelectionBoxGetChild(FileSelection, xmDIALOG_HELP_BUTTON, HelpButton),
	xtUnmanageChild(HelpButton),
	xtAddCallback(FileSelection, xmNokCallback, OKCommand, FileSelection),
	xtAddCallback(FileSelection, xmNcancelCallback, CancelCommand, FileSelection).

%   Note that there is only one "not yet implemented" dialog in the
%   system!

createNotYetImplementedDialog(Widget, Dialog) :-
	theoristResource(widgetName, notYetImplementedDialog, NotYetImplName),
        (   dialogWidget(Dialog, _Shell, dialog, NotYetImplName) ->
            dialogWindowOnTop(Dialog)
	;   xmCreateWarningDialog(Widget, NotYetImplName, [], Dialog),
	    xmMessageBoxGetChild(Dialog, xmDIALOG_CANCEL_BUTTON, CancelButton),
	    xmMessageBoxGetChild(Dialog, xmDIALOG_HELP_BUTTON, HelpButton),
	    xtUnmanageChildren([CancelButton, HelpButton]),
            assert((dialogWidget(Dialog, _Shell, dialog, NotYetImplName) :- !))
	).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Restacking                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dialogWindowOnTop(Widget) :-
        xtParent(Widget, WidgetParent),
        widget_window(WidgetParent, WidgetWindow),
        restack_window(WidgetWindow, top).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Release                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   releaseDialog(+DialogWidget)
%   is true if DialogWidget is unmanaged and destroyed.

releaseDialog(DialogWidget) :-
        DialogWidget = widget(ID),
	integer(ID),
        xtUnmanageChild(DialogWidget),
        xtDestroyWidget(DialogWidget).

%   releaseDialogs(+DialogList)
%   is true if each dialog widget in DialogList is unmanaged and
%   destroyed.

releaseDialogs([]).
releaseDialogs([DialogWidget|Dialogs]) :-
	releaseDialog(DialogWidget),
        releaseDialogs(Dialogs).
