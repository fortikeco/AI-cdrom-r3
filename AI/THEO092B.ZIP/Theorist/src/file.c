/*  File   : file.c
    Author : Daniel Lanovaz
    Origin : March 1991
    Update : 11/26/91
    Purpose: Reading text files into memory and writing to disk.

    The following C routines are used to "slurp" an entire file
    into memory and write an entire memory file out to disk.
    This is a very naive implementation of the text editor, but
    there is no time to make it more efficient.

    See the documentation in file.pl.
*/

#ifndef lint
  static  char SCCSid[] = "@(#) 11/26/91 09:39:08 file.c 1.1";
#endif/*lint*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "quintus.h"

int
cFreeFileCharPtr(charPtr, errorNumber)
char *charPtr;
int  *errorNumber;
{
	int retVal;

	if ((charPtr == NULL) || (errorNumber == NULL)) return QP_ERROR;
	*errorNumber = 0;

	/* There was no documentation on QP_free error codes in our
	 * Release 3.0 manuals, so no error checking is done yet;
	 * beware!
         */
	QP_free(charPtr);

	return QP_SUCCESS;
}
 
char *
cReadFileIntoCharPtr(fileName, errorNumber)
QPatom  fileName;
int    *errorNumber;
{
	char*       fileNameString = QP_string_from_atom(fileName);
	char*       buffer;
	struct stat statBuffer;
	int         numberChars;
	FILE*       filePtr;

	if (errorNumber == NULL) return NULL;
	*errorNumber = 0;

	if (stat(fileNameString, &statBuffer)) return NULL;
	numberChars = statBuffer.st_size;

	buffer = (char *) QP_malloc(numberChars + 1);
	if (!buffer) {
		*errorNumber = QP_errno;
		return NULL;
	}

	filePtr = fopen(fileNameString, "r");
	if (filePtr == NULL) {
		*errorNumber = errno;
		(void) cFreeFileCharPtr(buffer, errorNumber);
		return NULL;
	}

	if (fread(buffer, 1, numberChars, filePtr) != numberChars) {
		*errorNumber = errno;
		(void) cFreeFileCharPtr(buffer, errorNumber);
		(void) fclose(filePtr);
		return NULL;
	}
	(void) fclose(filePtr);

	buffer[numberChars] = '\0';
	return buffer;
}

int
cWriteCharPtrIntoFile(fileName, charPtr, errorNumber)
QPatom  fileName;
char   *charPtr;
int    *errorNumber;
{
	int         numberChars;
	int         result;
	char*       fileNameString = QP_string_from_atom(fileName);
	FILE*       filePtr;

	if ((charPtr == NULL) || (errorNumber == NULL)) return QP_ERROR;
	*errorNumber = 0;

	filePtr = fopen(fileNameString, "w");
	if (filePtr == NULL) return QP_ERROR;

	numberChars = strlen(charPtr);
	result = fwrite(charPtr, 1, numberChars, filePtr);
	(void) fflush(filePtr);
	(void) fclose(filePtr);

	if (result != numberChars) return QP_ERROR;
	else return QP_SUCCESS;
}
