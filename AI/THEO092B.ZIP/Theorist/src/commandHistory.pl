%   Module : commandHistory
%   Authors: Daniel Lanovaz
%   Updated: 11/26/91
%   Defines: Predicates dealing with a command history list.
%
%   A command history is a collection of commands the user has typed from
%   the terminal.  This module permits the storage, printing, and
%   extraction of a command list.  There is a limit on the length of the
%   history list.

:- module(commandHistory, [
	commandHistory/1,
	commandHistoryLength/2,
	emptyCommandHistory/2,
	printCommandHistory/1,
	pushCommandHistory/3,
	nth1CommandHistory/3
   ]).

:- use_module(library(lists), [
	nth1/3,
	nth1/4
   ]).
% To avoid circular imports between this module and module commandDispatcher
% absolute references to commandDispatcher:ppCommand/1 are made in
% this file.  This problems stems from an error in Quintus Prolog's
% 'qpc' compiler.  The next release should fix this.
%   use_module(commandDispatcher, [
%	ppCommand/1
%   ]).

sccs_id('"@(#) 11/26/91 09:39:24 commandHistory.pl 1.1"').

mode :-
	commandHistory(+),
	commandHistoryLength(+, ?),
	emptyCommandHistory(?, ?),
	nth1CommandHistory(?, +, ?),
	pushCommandHistory(+, +, -),
	printCommandHistory(+),

	commandHistoryList(+, ?).

/* pred
	CommandHistory ::= commandHistory(History : List, Length : Integer, MaxLength : Integer).

	commandHistory(CommandHistory),
	commandHistoryLength(CommandHistory, Integer),
	emptyCommandHistory(CommandHistory, Integer),
	nth1CommandHistory(CommandHistory, Integer, Term),
	pushCommandHistory(CommandHistory, Term, CommandHistory),
	printCommandHistory(CommandHistory),

	commandHistoryList(CommandHistory, List).
*/

%   commandHistory(+CommandHistory)
%   is true if CommandHistory is a valid command history object.

commandHistory(CommandHistory) :-
	nonvar(CommandHistory),
	\+ \+ CommandHistory = commandHistory(_, _, _).



%   commandHistoryList(+CommandHistory, ?List)
%   is true when List is the command list contained in CommandHistory.

commandHistoryList(CommandHistory, List) :-
	nonvar(CommandHistory),
	CommandHistory = commandHistory(List, _, _).



%   commandHistoryLength(+CommandHistory, ?Length)
%   is true if Length is equal the the number of commands stored in
%   CommandHistory.

commandHistoryLength(CommandHistory, Length) :-
	nonvar(CommandHistory),
	CommandHistory = commandHistory(_, Length, _).



%   emptyCommandHistory(?CommandHistory, ?MaxLength)
%   is true if CommandHistory is an empty command history (i.e. it contains
%   no command objects) and has a maximum length of MaxLength.

emptyCommandHistory(commandHistory([], 0, MaxLength), MaxLength).



%   nth1CommandHistory(?Nth, +CommandHistory, ?NthCommand)
%   is true when NthCommand is the Nth command of CommandHistory.  This
%   predicate can be used to solve for both Nth and NthCommand.
%   However, CommandHistory must be a proper command history object.

nth1CommandHistory(Nth, CommandHistory, NthCommand) :-
	commandHistory(CommandHistory),
	commandHistoryList(CommandHistory, CommandList),
	commandHistoryLength(CommandHistory, Length),
	(   var(Nth) ->
	    CommandNum = Nth
	;   Nth > 0 ->
	    CommandNum is Length - Nth + 1
	;   CommandNum is -Nth
	),
	nth1(CommandNum, CommandList, NthCommand).



%   pushCommandHistory(+Command, +CommandHistory, -NewHistory)
%   is true when NewHistory is CommandHistory with Command as the most recent
%   command in CommandHistory.  Note that if the length of CommandHistory
%   exceeds its maximum allowable length, the oldest command is lost.

pushCommandHistory(Command,
                   commandHistory(CommandList, MaxLength, MaxLength),
                   commandHistory([Command|NewCommandList], MaxLength,
                                   MaxLength)) :-
	append(NewCommandList, [_], CommandList),
	!.
pushCommandHistory(Command,
                   commandHistory(CommandList, OldLength, MaxLength),
                   commandHistory([Command|CommandList], NewLength,
                                  MaxLength)) :-
	NewLength is OldLength + 1.



%   printcommandHistory(+CommandHistory)
%   is true if CommandHistory is pretty printed to the standard output stream.

printCommandHistory(commandHistory(CommandList, Length, _)) :-
	printCommandHistory(CommandList, Length).

printCommandHistory([], _).
printCommandHistory([Head|Tail], Count) :-
	N is Count - 1,
	printCommandHistory(Tail, N),
	write('    '),
	write(Count),
	write('    '),
	commandDispatcher:ppCommand(Head),
	nl.
