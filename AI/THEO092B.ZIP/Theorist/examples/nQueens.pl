:-use_module(library(basics), [
        member/2
  ]).

add(X, Y, _) :-
	var(X), var(Y), !, fail.
add(X, _, Z) :-
	var(X), var(Z), !, fail.
add(_, Y, Z) :-
	var(Y), var(Z), !, fail.
add(X, Y, Z) :-
	var(X), !,
	X is Z - Y.
add(X, Y, Z) :-
	var(Y), !,
	Y is Z - X.
add(X, Y, Z) :-
	Z is X + Y.

abs(X, Y) :-
	var(X), var(Y), !, fail.
abs(X, Y) :-
	var(X), !,
	(   Y =< 0 ->
	    X is Y * -1
	;   X = Y
	).
abs(X, Y) :-
	(   X =< 0 ->
	    fail
	;   Y = X
	).
