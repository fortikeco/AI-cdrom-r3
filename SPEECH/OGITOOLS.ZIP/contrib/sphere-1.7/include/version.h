/********************************************/
/** NIST Speech Header Resources (SPHERE)  **/
/** Release 1.7 (beta)                     **/
/** Stan Janet (stan@jaguar.ncsl.nist.gov) **/
/** June 1991                              **/
/********************************************/

/* File: version.h */

#ifndef lint
static char version[] = "NIST Sphere Version 1.7";
#endif
