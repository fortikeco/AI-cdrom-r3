/*
 * $Id: littleindian.c,v 2.3 1993/05/11 18:52:04 johans Exp $
 *
 * littleindian.c
 *
 */

/* Speech Library include file directives */
#include <stdio.h>
#include <stdlib.h>

/*
 * LittleIndian()
 *
 *      Returns non-zero when this code is compiled and run on
 * a machine that formats shorts and integers with the least significant
 * byte at address 0. Otherwise it returns 0.
 *
 * returns non 0 if this is a little indian machine.
 *
 */

int LittleIndian()
{
	char b[4];
	int *l = (int *)b;

	*l = 1;
	return( (int)b[0] );
}
