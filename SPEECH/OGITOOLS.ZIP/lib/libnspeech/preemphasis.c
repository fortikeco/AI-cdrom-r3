/*
 * $Id: preemphasis.c,v 2.2 1993/05/07 18:12:22 johans Exp $
 *
 *
 */

/* Standard C library include file directives */
#include <stdio.h>
#include <stdlib.h>

/* speech library header declarations */
#include <speech.h>


void Preemphasis( float alpha, float start, float *wav, int len )
{
	float s;
	float l;
	int i;


	s = start;

	for( i = 1; i < len; i++ ) {

		l = *(wav+i);

		*(wav+i) = *(wav+i) - alpha * s;

		s = l;
	}

}
