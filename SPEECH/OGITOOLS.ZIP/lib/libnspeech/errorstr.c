/*
 * $Id: errorstr.c,v 1.2 1992/04/01 09:51:21 pochmara Exp $
 *
 */

/*
 * Global varable that holds error messages
 */
char *ErrorString;

