#!/bin/sh
#
#  mkdirs.sh
#
#     Checks to see if a directory exist.  If the directory does
#     not exist then it and all needed parents a created.
#
#

echo $1 | tr '/' '\012' |
(
 while read d
 do 
	if [ -z "$d" ]
	then
		parent="/";
		continue;
	fi

	dir="${parent}${d}"

	if [ ! -d "$dir" ]
	then
		echo "creating $dir";
		mkdir $dir;
		chmod 775 $dir;
	fi

	parent="$dir/";
 done )
