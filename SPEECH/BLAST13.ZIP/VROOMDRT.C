#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include "direct.h"
#include "blaster.h"

status_type	voice_stat;

void main()
{

	/* The delay value can be selected from the command line, speeds
	   WILL vary machine to machine, so start trying numbers!
	*/

	int		loop,delay=50;
	char		*snd;

	if(reset_dsp()!=SBOK)
	{
		printf("\nError resetting Sound Blaster.\n");
		exit(1);
	}
	if (load_snd("c:\\temp\\vroom.voc",(sbvoc_type*)&snd)!=SBOK)
	{	
		printf("\nError loading file.\n");
		exit(1);
	}
	if(_argc==2)
		delay=atoi(_argv[1]);
	speaker_on();
	for(loop=0;loop<14312;loop++)
	{
		write_data((int)snd[loop]);
		asmdelay(delay);
	}
	speaker_off();
	unload_snd(snd);
	exit(0);
}
